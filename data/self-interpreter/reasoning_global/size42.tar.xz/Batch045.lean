import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1124617100826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124617100826 : Closed e1124617100826 ∧ code e1124617100826 = 5522663611930 := by decide
private def t_e1124617100826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124617100826 : ¬ IsSelfInterpreter e1124617100826 :=
  wSource (t := t_e1124617100826) (replay_sound (ps := []) (t := e1124617100826) (by decide)) (by decide)
def e1124617121990 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124617121990 : Closed e1124617121990 ∧ code e1124617121990 = 5522663633094 := by decide
theorem cert_e1124617121990 : check e1124617121990 [[]] .width = true := by decide
def e1124617129498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124617129498 : Closed e1124617129498 ∧ code e1124617129498 = 5522663640602 := by decide
private def t_e1124617129498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124617129498 : ¬ IsSelfInterpreter e1124617129498 :=
  wSource (t := t_e1124617129498) (replay_sound (ps := []) (t := e1124617129498) (by decide)) (by decide)
def e1124617138374 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124617138374 : Closed e1124617138374 ∧ code e1124617138374 = 5522663649478 := by decide
theorem cert_e1124617138374 : check e1124617138374 [[]] .width = true := by decide
def e1124617887258 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124617887258 : Closed e1124617887258 ∧ code e1124617887258 = 5522664398362 := by decide
private def t_e1124617887258 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124617887258 : ¬ IsSelfInterpreter e1124617887258 :=
  wSource (t := t_e1124617887258) (replay_sound (ps := []) (t := e1124617887258) (by decide)) (by decide)
def e1124617908422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124617908422 : Closed e1124617908422 ∧ code e1124617908422 = 5522664419526 := by decide
theorem cert_e1124617908422 : check e1124617908422 [[]] .width = true := by decide
def e1124617930266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124617930266 : Closed e1124617930266 ∧ code e1124617930266 = 5522664441370 := by decide
private def t_e1124617930266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124617930266 : ¬ IsSelfInterpreter e1124617930266 :=
  wSource (t := t_e1124617930266) (replay_sound (ps := []) (t := e1124617930266) (by decide)) (by decide)
def e1124617932998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124617932998 : Closed e1124617932998 ∧ code e1124617932998 = 5522664444102 := by decide
theorem cert_e1124617932998 : check e1124617932998 [[]] .width = true := by decide
def e1124618309146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124618309146 : Closed e1124618309146 ∧ code e1124618309146 = 5522664820250 := by decide
private def t_e1124618309146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124618309146 : ¬ IsSelfInterpreter e1124618309146 :=
  wSource (t := t_e1124618309146) (replay_sound (ps := []) (t := e1124618309146) (by decide)) (by decide)
def e1124618318022 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124618318022 : Closed e1124618318022 ∧ code e1124618318022 = 5522664829126 := by decide
theorem cert_e1124618318022 : check e1124618318022 [[]] .width = true := by decide
def e1124618323482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1124618323482 : Closed e1124618323482 ∧ code e1124618323482 = 5522664834586 := by decide
private def t_e1124618323482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1124618323482 : ¬ IsSelfInterpreter e1124618323482 :=
  wSource (t := t_e1124618323482) (replay_sound (ps := []) (t := e1124618323482) (by decide)) (by decide)
def e1124618326214 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1124618326214 : Closed e1124618326214 ∧ code e1124618326214 = 5522664837318 := by decide
theorem cert_e1124618326214 : check e1124618326214 [[]] .width = true := by decide
def e1124643986286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1124643986286 : Closed e1124643986286 ∧ code e1124643986286 = 5522690497390 := by decide
theorem cert_e1124643986286 : check e1124643986286 [[],[.under,.left]] .chain = true := by decide
def e1124643986294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1124643986294 : Closed e1124643986294 ∧ code e1124643986294 = 5522690497398 := by decide
theorem cert_e1124643986294 : check e1124643986294 [[],[.under,.left]] .chain = true := by decide
def e1124643986358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1124643986358 : Closed e1124643986358 ∧ code e1124643986358 = 5522690497462 := by decide
theorem cert_e1124643986358 : check e1124643986358 [[],[.under,.left]] .chain = true := by decide
def e1124643986798 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1124643986798 : Closed e1124643986798 ∧ code e1124643986798 = 5522690497902 := by decide
theorem cert_e1124643986798 : check e1124643986798 [[],[.under,.left]] .chain = true := by decide
def e1124643986806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1124643986806 : Closed e1124643986806 ∧ code e1124643986806 = 5522690497910 := by decide
theorem cert_e1124643986806 : check e1124643986806 [[],[.under,.left]] .chain = true := by decide
def e1124643986862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1124643986862 : Closed e1124643986862 ∧ code e1124643986862 = 5522690497966 := by decide
theorem cert_e1124643986862 : check e1124643986862 [[],[.under,.left]] .chain = true := by decide
def e1124643986874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1124643986874 : Closed e1124643986874 ∧ code e1124643986874 = 5522690497978 := by decide
theorem cert_e1124643986874 : check e1124643986874 [[],[.under,.left]] .chain = true := by decide
def e1124643986902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1124643986902 : Closed e1124643986902 ∧ code e1124643986902 = 5522690498006 := by decide
theorem cert_e1124643986902 : check e1124643986902 [[],[.under,.left]] .chain = true := by decide
def e1124643986906 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1124643986906 : Closed e1124643986906 ∧ code e1124643986906 = 5522690498010 := by decide
theorem cert_e1124643986906 : check e1124643986906 [[],[.under,.left]] .chain = true := by decide
def e1124643987126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1124643987126 : Closed e1124643987126 ∧ code e1124643987126 = 5522690498230 := by decide
theorem cert_e1124643987126 : check e1124643987126 [[],[.under,.left]] .chain = true := by decide
def e1124643987158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1124643987158 : Closed e1124643987158 ∧ code e1124643987158 = 5522690498262 := by decide
theorem cert_e1124643987158 : check e1124643987158 [[],[.under,.left]] .chain = true := by decide
def e1124643987162 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1124643987162 : Closed e1124643987162 ∧ code e1124643987162 = 5522690498266 := by decide
theorem cert_e1124643987162 : check e1124643987162 [[],[.under,.left]] .chain = true := by decide
def e1124643989358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1124643989358 : Closed e1124643989358 ∧ code e1124643989358 = 5522690500462 := by decide
theorem cert_e1124643989358 : check e1124643989358 [[],[.under,.left]] .chain = true := by decide
def e1124643989366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1124643989366 : Closed e1124643989366 ∧ code e1124643989366 = 5522690500470 := by decide
theorem cert_e1124643989366 : check e1124643989366 [[],[.under,.left]] .chain = true := by decide
def e1124643989430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1124643989430 : Closed e1124643989430 ∧ code e1124643989430 = 5522690500534 := by decide
theorem cert_e1124643989430 : check e1124643989430 [[],[.under,.left]] .chain = true := by decide
def e1124643990766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124643990766 : Closed e1124643990766 ∧ code e1124643990766 = 5522690501870 := by decide
theorem cert_e1124643990766 : check e1124643990766 [[],[.under,.left]] .chain = true := by decide
def e1124643990774 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124643990774 : Closed e1124643990774 ∧ code e1124643990774 = 5522690501878 := by decide
theorem cert_e1124643990774 : check e1124643990774 [[],[.under,.left]] .chain = true := by decide
def e1124643991158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1124643991158 : Closed e1124643991158 ∧ code e1124643991158 = 5522690502262 := by decide
theorem cert_e1124643991158 : check e1124643991158 [[],[.under,.left]] .chain = true := by decide
def e1124643992430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1124643992430 : Closed e1124643992430 ∧ code e1124643992430 = 5522690503534 := by decide
theorem cert_e1124643992430 : check e1124643992430 [[],[.under,.left]] .chain = true := by decide
def e1124643992438 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1124643992438 : Closed e1124643992438 ∧ code e1124643992438 = 5522690503542 := by decide
theorem cert_e1124643992438 : check e1124643992438 [[],[.under,.left]] .chain = true := by decide
def e1124643992494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1124643992494 : Closed e1124643992494 ∧ code e1124643992494 = 5522690503598 := by decide
theorem cert_e1124643992494 : check e1124643992494 [[],[.under,.left]] .chain = true := by decide
def e1124643992506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1124643992506 : Closed e1124643992506 ∧ code e1124643992506 = 5522690503610 := by decide
theorem cert_e1124643992506 : check e1124643992506 [[],[.under,.left]] .chain = true := by decide
def e1124643992534 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1124643992534 : Closed e1124643992534 ∧ code e1124643992534 = 5522690503638 := by decide
theorem cert_e1124643992534 : check e1124643992534 [[],[.under,.left]] .chain = true := by decide
def e1124643992538 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1124643992538 : Closed e1124643992538 ∧ code e1124643992538 = 5522690503642 := by decide
theorem cert_e1124643992538 : check e1124643992538 [[],[.under,.left]] .chain = true := by decide
def e1124643992814 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124643992814 : Closed e1124643992814 ∧ code e1124643992814 = 5522690503918 := by decide
theorem cert_e1124643992814 : check e1124643992814 [[],[.under,.left]] .chain = true := by decide
def e1124643992822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124643992822 : Closed e1124643992822 ∧ code e1124643992822 = 5522690503926 := by decide
theorem cert_e1124643992822 : check e1124643992822 [[],[.under,.left]] .chain = true := by decide
def e1124643993198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1124643993198 : Closed e1124643993198 ∧ code e1124643993198 = 5522690504302 := by decide
theorem cert_e1124643993198 : check e1124643993198 [[],[.under,.left]] .chain = true := by decide
def e1124643993210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1124643993210 : Closed e1124643993210 ∧ code e1124643993210 = 5522690504314 := by decide
theorem cert_e1124643993210 : check e1124643993210 [[],[.under,.left]] .chain = true := by decide
def e1124643993398 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124643993398 : Closed e1124643993398 ∧ code e1124643993398 = 5522690504502 := by decide
theorem cert_e1124643993398 : check e1124643993398 [[],[.under,.left]] .chain = true := by decide
def e1124643993402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124643993402 : Closed e1124643993402 ∧ code e1124643993402 = 5522690504506 := by decide
theorem cert_e1124643993402 : check e1124643993402 [[],[.under,.left]] .chain = true := by decide
def e1124643994038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1124643994038 : Closed e1124643994038 ∧ code e1124643994038 = 5522690505142 := by decide
theorem cert_e1124643994038 : check e1124643994038 [[],[.under,.left]] .chain = true := by decide
def e1124643994070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1124643994070 : Closed e1124643994070 ∧ code e1124643994070 = 5522690505174 := by decide
theorem cert_e1124643994070 : check e1124643994070 [[],[.under,.left]] .chain = true := by decide
def e1124643994074 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1124643994074 : Closed e1124643994074 ∧ code e1124643994074 = 5522690505178 := by decide
theorem cert_e1124643994074 : check e1124643994074 [[],[.under,.left]] .chain = true := by decide
def e1124643994230 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1124643994230 : Closed e1124643994230 ∧ code e1124643994230 = 5522690505334 := by decide
theorem cert_e1124643994230 : check e1124643994230 [[],[.under,.left]] .chain = true := by decide
def e1124643994422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124643994422 : Closed e1124643994422 ∧ code e1124643994422 = 5522690505526 := by decide
theorem cert_e1124643994422 : check e1124643994422 [[],[.under,.left]] .chain = true := by decide
def e1124643994426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124643994426 : Closed e1124643994426 ∧ code e1124643994426 = 5522690505530 := by decide
theorem cert_e1124643994426 : check e1124643994426 [[],[.under,.left]] .chain = true := by decide
def e1124644001646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1124644001646 : Closed e1124644001646 ∧ code e1124644001646 = 5522690512750 := by decide
theorem cert_e1124644001646 : check e1124644001646 [[],[.under,.left]] .chain = true := by decide
def e1124644001654 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1124644001654 : Closed e1124644001654 ∧ code e1124644001654 = 5522690512758 := by decide
theorem cert_e1124644001654 : check e1124644001654 [[],[.under,.left]] .chain = true := by decide
def e1124644001718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1124644001718 : Closed e1124644001718 ∧ code e1124644001718 = 5522690512822 := by decide
theorem cert_e1124644001718 : check e1124644001718 [[],[.under,.left]] .chain = true := by decide
def e1124644003054 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1124644003054 : Closed e1124644003054 ∧ code e1124644003054 = 5522690514158 := by decide
theorem cert_e1124644003054 : check e1124644003054 [[],[.under,.left]] .chain = true := by decide
def e1124644003062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1124644003062 : Closed e1124644003062 ∧ code e1124644003062 = 5522690514166 := by decide
theorem cert_e1124644003062 : check e1124644003062 [[],[.under,.left]] .chain = true := by decide
def e1124644003446 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1124644003446 : Closed e1124644003446 ∧ code e1124644003446 = 5522690514550 := by decide
theorem cert_e1124644003446 : check e1124644003446 [[],[.under,.left]] .chain = true := by decide
def e1124644014958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124644014958 : Closed e1124644014958 ∧ code e1124644014958 = 5522690526062 := by decide
theorem cert_e1124644014958 : check e1124644014958 [[],[.under,.left]] .chain = true := by decide
def e1124644014966 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124644014966 : Closed e1124644014966 ∧ code e1124644014966 = 5522690526070 := by decide
theorem cert_e1124644014966 : check e1124644014966 [[],[.under,.left]] .chain = true := by decide
def e1124644015022 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124644015022 : Closed e1124644015022 ∧ code e1124644015022 = 5522690526126 := by decide
theorem cert_e1124644015022 : check e1124644015022 [[],[.under,.left]] .chain = true := by decide
def e1124644015034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124644015034 : Closed e1124644015034 ∧ code e1124644015034 = 5522690526138 := by decide
theorem cert_e1124644015034 : check e1124644015034 [[],[.under,.left]] .chain = true := by decide
def e1124644015062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124644015062 : Closed e1124644015062 ∧ code e1124644015062 = 5522690526166 := by decide
theorem cert_e1124644015062 : check e1124644015062 [[],[.under,.left]] .chain = true := by decide
def e1124644015066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124644015066 : Closed e1124644015066 ∧ code e1124644015066 = 5522690526170 := by decide
theorem cert_e1124644015066 : check e1124644015066 [[],[.under,.left]] .chain = true := by decide
def e1124644015342 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124644015342 : Closed e1124644015342 ∧ code e1124644015342 = 5522690526446 := by decide
theorem cert_e1124644015342 : check e1124644015342 [[],[.under,.left]] .chain = true := by decide
def e1124644015350 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124644015350 : Closed e1124644015350 ∧ code e1124644015350 = 5522690526454 := by decide
theorem cert_e1124644015350 : check e1124644015350 [[],[.under,.left]] .chain = true := by decide
def e1124644015726 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124644015726 : Closed e1124644015726 ∧ code e1124644015726 = 5522690526830 := by decide
theorem cert_e1124644015726 : check e1124644015726 [[],[.under,.left]] .chain = true := by decide
def e1124644015738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124644015738 : Closed e1124644015738 ∧ code e1124644015738 = 5522690526842 := by decide
theorem cert_e1124644015738 : check e1124644015738 [[],[.under,.left]] .chain = true := by decide
def e1124644015926 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124644015926 : Closed e1124644015926 ∧ code e1124644015926 = 5522690527030 := by decide
theorem cert_e1124644015926 : check e1124644015926 [[],[.under,.left]] .chain = true := by decide
def e1124644015930 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124644015930 : Closed e1124644015930 ∧ code e1124644015930 = 5522690527034 := by decide
theorem cert_e1124644015930 : check e1124644015930 [[],[.under,.left]] .chain = true := by decide
def e1124644021686 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1124644021686 : Closed e1124644021686 ∧ code e1124644021686 = 5522690532790 := by decide
theorem cert_e1124644021686 : check e1124644021686 [[],[.under,.left]] .chain = true := by decide
def e1124644021718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1124644021718 : Closed e1124644021718 ∧ code e1124644021718 = 5522690532822 := by decide
theorem cert_e1124644021718 : check e1124644021718 [[],[.under,.left]] .chain = true := by decide
def e1124644021722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1124644021722 : Closed e1124644021722 ∧ code e1124644021722 = 5522690532826 := by decide
theorem cert_e1124644021722 : check e1124644021722 [[],[.under,.left]] .chain = true := by decide
def e1124644021878 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1124644021878 : Closed e1124644021878 ∧ code e1124644021878 = 5522690532982 := by decide
theorem cert_e1124644021878 : check e1124644021878 [[],[.under,.left]] .chain = true := by decide
def e1124644022070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1124644022070 : Closed e1124644022070 ∧ code e1124644022070 = 5522690533174 := by decide
theorem cert_e1124644022070 : check e1124644022070 [[],[.under,.left]] .chain = true := by decide
def e1124644022074 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1124644022074 : Closed e1124644022074 ∧ code e1124644022074 = 5522690533178 := by decide
theorem cert_e1124644022074 : check e1124644022074 [[],[.under,.left]] .chain = true := by decide
def e1124644359022 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124644359022 : Closed e1124644359022 ∧ code e1124644359022 = 5522690870126 := by decide
theorem cert_e1124644359022 : check e1124644359022 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1124644359030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124644359030 : Closed e1124644359030 ∧ code e1124644359030 = 5522690870134 := by decide
private def t_e1124644359030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1124644359030 : ¬ IsSelfInterpreter e1124644359030 :=
  wSource (t := t_e1124644359030) (replay_sound (ps := []) (t := e1124644359030) (by decide)) (by decide)
def e1124644359086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124644359086 : Closed e1124644359086 ∧ code e1124644359086 = 5522690870190 := by decide
theorem cert_e1124644359086 : checkPay e1124644359086 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e1124644359098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124644359098 : Closed e1124644359098 ∧ code e1124644359098 = 5522690870202 := by decide
theorem cert_e1124644359098 : checkPay e1124644359098 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e1124644359126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124644359126 : Closed e1124644359126 ∧ code e1124644359126 = 5522690870230 := by decide
private def t_e1124644359126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1124644359126 : ¬ IsSelfInterpreter e1124644359126 :=
  wSource (t := t_e1124644359126) (replay_sound (ps := []) (t := e1124644359126) (by decide)) (by decide)
def e1124644359130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124644359130 : Closed e1124644359130 ∧ code e1124644359130 = 5522690870234 := by decide
theorem cert_e1124644359130 : check e1124644359130 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1124644359406 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124644359406 : Closed e1124644359406 ∧ code e1124644359406 = 5522690870510 := by decide
theorem cert_e1124644359406 : checkPay e1124644359406 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e1124644359414 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124644359414 : Closed e1124644359414 ∧ code e1124644359414 = 5522690870518 := by decide
theorem cert_e1124644359414 : check e1124644359414 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1124644359790 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124644359790 : Closed e1124644359790 ∧ code e1124644359790 = 5522690870894 := by decide
theorem cert_e1124644359790 : check e1124644359790 [[],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e1124644359802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124644359802 : Closed e1124644359802 ∧ code e1124644359802 = 5522690870906 := by decide
theorem cert_e1124644359802 : check e1124644359802 [[],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e1124644359990 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124644359990 : Closed e1124644359990 ∧ code e1124644359990 = 5522690871094 := by decide
theorem cert_e1124644359990 : check e1124644359990 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1124644359994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124644359994 : Closed e1124644359994 ∧ code e1124644359994 = 5522690871098 := by decide
theorem cert_e1124644359994 : check e1124644359994 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1124660718958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1124660718958 : Closed e1124660718958 ∧ code e1124660718958 = 5522707230062 := by decide
theorem cert_e1124660718958 : check e1124660718958 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660718966 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1124660718966 : Closed e1124660718966 ∧ code e1124660718966 = 5522707230070 := by decide
theorem cert_e1124660718966 : check e1124660718966 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660719022 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1124660719022 : Closed e1124660719022 ∧ code e1124660719022 = 5522707230126 := by decide
theorem cert_e1124660719022 : check e1124660719022 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660719034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1124660719034 : Closed e1124660719034 ∧ code e1124660719034 = 5522707230138 := by decide
def e1124660719062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1124660719062 : Closed e1124660719062 ∧ code e1124660719062 = 5522707230166 := by decide
theorem cert_e1124660719062 : check e1124660719062 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660719066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1124660719066 : Closed e1124660719066 ∧ code e1124660719066 = 5522707230170 := by decide
def e1124660719278 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1124660719278 : Closed e1124660719278 ∧ code e1124660719278 = 5522707230382 := by decide
theorem cert_e1124660719278 : check e1124660719278 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1124660719290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1124660719290 : Closed e1124660719290 ∧ code e1124660719290 = 5522707230394 := by decide
theorem cert_e1124660719290 : check e1124660719290 [[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1124660719338 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1124660719338 : Closed e1124660719338 ∧ code e1124660719338 = 5522707230442 := by decide
theorem cert_e1124660719338 : check e1124660719338 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1124660719446 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1124660719446 : Closed e1124660719446 ∧ code e1124660719446 = 5522707230550 := by decide
theorem cert_e1124660719446 : check e1124660719446 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e1124660719450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1124660719450 : Closed e1124660719450 ∧ code e1124660719450 = 5522707230554 := by decide
theorem cert_e1124660719450 : check e1124660719450 [[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1124660719466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1124660719466 : Closed e1124660719466 ∧ code e1124660719466 = 5522707230570 := by decide
theorem cert_e1124660719466 : check e1124660719466 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1124660720494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1124660720494 : Closed e1124660720494 ∧ code e1124660720494 = 5522707231598 := by decide
theorem cert_e1124660720494 : check e1124660720494 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660720502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1124660720502 : Closed e1124660720502 ∧ code e1124660720502 = 5522707231606 := by decide
theorem cert_e1124660720502 : check e1124660720502 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660720558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1124660720558 : Closed e1124660720558 ∧ code e1124660720558 = 5522707231662 := by decide
theorem cert_e1124660720558 : check e1124660720558 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660720570 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1124660720570 : Closed e1124660720570 ∧ code e1124660720570 = 5522707231674 := by decide
theorem cert_e1124660720570 : check e1124660720570 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660720598 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1124660720598 : Closed e1124660720598 ∧ code e1124660720598 = 5522707231702 := by decide
theorem cert_e1124660720598 : check e1124660720598 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660720602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1124660720602 : Closed e1124660720602 ∧ code e1124660720602 = 5522707231706 := by decide
theorem cert_e1124660720602 : check e1124660720602 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660720878 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1124660720878 : Closed e1124660720878 ∧ code e1124660720878 = 5522707231982 := by decide
theorem cert_e1124660720878 : check e1124660720878 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660720886 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1124660720886 : Closed e1124660720886 ∧ code e1124660720886 = 5522707231990 := by decide
theorem cert_e1124660720886 : check e1124660720886 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660721262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1124660721262 : Closed e1124660721262 ∧ code e1124660721262 = 5522707232366 := by decide
theorem cert_e1124660721262 : check e1124660721262 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1124660721274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1124660721274 : Closed e1124660721274 ∧ code e1124660721274 = 5522707232378 := by decide
theorem cert_e1124660721274 : check e1124660721274 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1124660721462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124660721462 : Closed e1124660721462 ∧ code e1124660721462 = 5522707232566 := by decide
theorem cert_e1124660721462 : check e1124660721462 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1124660721466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124660721466 : Closed e1124660721466 ∧ code e1124660721466 = 5522707232570 := by decide
theorem cert_e1124660721466 : check e1124660721466 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660722094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1124660722094 : Closed e1124660722094 ∧ code e1124660722094 = 5522707233198 := by decide
theorem cert_e1124660722094 : check e1124660722094 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124660722106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1124660722106 : Closed e1124660722106 ∧ code e1124660722106 = 5522707233210 := by decide
theorem cert_e1124660722106 : check e1124660722106 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124660722154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1124660722154 : Closed e1124660722154 ∧ code e1124660722154 = 5522707233258 := by decide
theorem cert_e1124660722154 : check e1124660722154 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124660722286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1124660722286 : Closed e1124660722286 ∧ code e1124660722286 = 5522707233390 := by decide
theorem cert_e1124660722286 : check e1124660722286 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124660722298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1124660722298 : Closed e1124660722298 ∧ code e1124660722298 = 5522707233402 := by decide
theorem cert_e1124660722298 : check e1124660722298 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124660722586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1124660722586 : Closed e1124660722586 ∧ code e1124660722586 = 5522707233690 := by decide
theorem cert_e1124660722586 : check e1124660722586 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124660722902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1124660722902 : Closed e1124660722902 ∧ code e1124660722902 = 5522707234006 := by decide
theorem cert_e1124660722902 : check e1124660722902 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124660722906 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1124660722906 : Closed e1124660722906 ∧ code e1124660722906 = 5522707234010 := by decide
theorem cert_e1124660722906 : check e1124660722906 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124660722922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1124660722922 : Closed e1124660722922 ∧ code e1124660722922 = 5522707234026 := by decide
theorem cert_e1124660722922 : check e1124660722922 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124660722998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1124660722998 : Closed e1124660722998 ∧ code e1124660722998 = 5522707234102 := by decide
theorem cert_e1124660722998 : check e1124660722998 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124660723002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1124660723002 : Closed e1124660723002 ∧ code e1124660723002 = 5522707234106 := by decide
theorem cert_e1124660723002 : check e1124660723002 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1124660723098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1124660723098 : Closed e1124660723098 ∧ code e1124660723098 = 5522707234202 := by decide
theorem cert_e1124660723098 : check e1124660723098 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e1124660726638 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124660726638 : Closed e1124660726638 ∧ code e1124660726638 = 5522707237742 := by decide
theorem cert_e1124660726638 : check e1124660726638 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660726646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124660726646 : Closed e1124660726646 ∧ code e1124660726646 = 5522707237750 := by decide
theorem cert_e1124660726646 : check e1124660726646 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660726702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124660726702 : Closed e1124660726702 ∧ code e1124660726702 = 5522707237806 := by decide
theorem cert_e1124660726702 : check e1124660726702 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660726714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124660726714 : Closed e1124660726714 ∧ code e1124660726714 = 5522707237818 := by decide
theorem cert_e1124660726714 : check e1124660726714 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1124660726742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124660726742 : Closed e1124660726742 ∧ code e1124660726742 = 5522707237846 := by decide
theorem cert_e1124660726742 : check e1124660726742 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660726746 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124660726746 : Closed e1124660726746 ∧ code e1124660726746 = 5522707237850 := by decide
theorem cert_e1124660726746 : check e1124660726746 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1124660727022 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124660727022 : Closed e1124660727022 ∧ code e1124660727022 = 5522707238126 := by decide
theorem cert_e1124660727022 : check e1124660727022 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1124660727030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124660727030 : Closed e1124660727030 ∧ code e1124660727030 = 5522707238134 := by decide
theorem cert_e1124660727030 : check e1124660727030 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1124660727406 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124660727406 : Closed e1124660727406 ∧ code e1124660727406 = 5522707238510 := by decide
theorem cert_e1124660727406 : check e1124660727406 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660727418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124660727418 : Closed e1124660727418 ∧ code e1124660727418 = 5522707238522 := by decide
theorem cert_e1124660727418 : check e1124660727418 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1124660727606 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124660727606 : Closed e1124660727606 ∧ code e1124660727606 = 5522707238710 := by decide
theorem cert_e1124660727606 : check e1124660727606 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660727610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124660727610 : Closed e1124660727610 ∧ code e1124660727610 = 5522707238714 := by decide
theorem cert_e1124660727610 : check e1124660727610 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660733358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1124660733358 : Closed e1124660733358 ∧ code e1124660733358 = 5522707244462 := by decide
theorem cert_e1124660733358 : check e1124660733358 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660733370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1124660733370 : Closed e1124660733370 ∧ code e1124660733370 = 5522707244474 := by decide
theorem cert_e1124660733370 : check e1124660733370 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660733418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1124660733418 : Closed e1124660733418 ∧ code e1124660733418 = 5522707244522 := by decide
theorem cert_e1124660733418 : check e1124660733418 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660733550 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1124660733550 : Closed e1124660733550 ∧ code e1124660733550 = 5522707244654 := by decide
theorem cert_e1124660733550 : check e1124660733550 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660733562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1124660733562 : Closed e1124660733562 ∧ code e1124660733562 = 5522707244666 := by decide
theorem cert_e1124660733562 : check e1124660733562 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660733850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1124660733850 : Closed e1124660733850 ∧ code e1124660733850 = 5522707244954 := by decide
theorem cert_e1124660733850 : check e1124660733850 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660736726 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1124660736726 : Closed e1124660736726 ∧ code e1124660736726 = 5522707247830 := by decide
theorem cert_e1124660736726 : check e1124660736726 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660736730 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1124660736730 : Closed e1124660736730 ∧ code e1124660736730 = 5522707247834 := by decide
theorem cert_e1124660736730 : check e1124660736730 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660736746 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1124660736746 : Closed e1124660736746 ∧ code e1124660736746 = 5522707247850 := by decide
theorem cert_e1124660736746 : check e1124660736746 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660736822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1124660736822 : Closed e1124660736822 ∧ code e1124660736822 = 5522707247926 := by decide
theorem cert_e1124660736822 : check e1124660736822 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660736826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1124660736826 : Closed e1124660736826 ∧ code e1124660736826 = 5522707247930 := by decide
theorem cert_e1124660736826 : check e1124660736826 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660736922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1124660736922 : Closed e1124660736922 ∧ code e1124660736922 = 5522707248026 := by decide
theorem cert_e1124660736922 : check e1124660736922 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1124660874094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124660874094 : Closed e1124660874094 ∧ code e1124660874094 = 5522707385198 := by decide
theorem cert_e1124660874094 : check e1124660874094 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660874102 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124660874102 : Closed e1124660874102 ∧ code e1124660874102 = 5522707385206 := by decide
theorem cert_e1124660874102 : check e1124660874102 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1124660874158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124660874158 : Closed e1124660874158 ∧ code e1124660874158 = 5522707385262 := by decide
theorem cert_e1124660874158 : check e1124660874158 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under]] .identityHead = true := by decide
def e1124660874170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124660874170 : Closed e1124660874170 ∧ code e1124660874170 = 5522707385274 := by decide
theorem cert_e1124660874170 : check e1124660874170 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660874198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1124660874198 : Closed e1124660874198 ∧ code e1124660874198 = 5522707385302 := by decide
theorem cert_e1124660874198 : check e1124660874198 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660874202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1124660874202 : Closed e1124660874202 ∧ code e1124660874202 = 5522707385306 := by decide
theorem cert_e1124660874202 : check e1124660874202 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660874478 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1124660874478 : Closed e1124660874478 ∧ code e1124660874478 = 5522707385582 := by decide
theorem cert_e1124660874478 : check e1124660874478 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e1124660874486 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1124660874486 : Closed e1124660874486 ∧ code e1124660874486 = 5522707385590 := by decide
theorem cert_e1124660874486 : check e1124660874486 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1124660874862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1124660874862 : Closed e1124660874862 ∧ code e1124660874862 = 5522707385966 := by decide
theorem cert_e1124660874862 : check e1124660874862 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660874874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1124660874874 : Closed e1124660874874 ∧ code e1124660874874 = 5522707385978 := by decide
theorem cert_e1124660874874 : check e1124660874874 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1124660875062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1124660875062 : Closed e1124660875062 ∧ code e1124660875062 = 5522707386166 := by decide
theorem cert_e1124660875062 : check e1124660875062 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1124660875066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1124660875066 : Closed e1124660875066 ∧ code e1124660875066 = 5522707386170 := by decide
theorem cert_e1124660875066 : check e1124660875066 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1124661463918 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1124661463918 : Closed e1124661463918 ∧ code e1124661463918 = 5522707975022 := by decide
def e1124661463926 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1124661463926 : Closed e1124661463926 ∧ code e1124661463926 = 5522707975030 := by decide
def e1124661463982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1124661463982 : Closed e1124661463982 ∧ code e1124661463982 = 5522707975086 := by decide
def e1124661463994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1124661463994 : Closed e1124661463994 ∧ code e1124661463994 = 5522707975098 := by decide
private def t_e1124661463994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e1124661463994 : ¬ IsSelfInterpreter e1124661463994 :=
  wSource (t := t_e1124661463994) (replay_sound (ps := []) (t := e1124661463994) (by decide)) (by decide)
end Blc.Floor42
