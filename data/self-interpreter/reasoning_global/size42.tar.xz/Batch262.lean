import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211585099526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211585099526 : Closed e1211585099526 ∧ code e1211585099526 = 5609631610630 := by decide
theorem cert_e1211585099526 : check e1211585099526 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211585099550 : Closed e1211585099550 ∧ code e1211585099550 = 5609631610654 := by decide
theorem cert_e1211585099550 : check e1211585099550 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211585099574 : Closed e1211585099574 ∧ code e1211585099574 = 5609631610678 := by decide
theorem cert_e1211585099574 : check e1211585099574 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211585099578 : Closed e1211585099578 ∧ code e1211585099578 = 5609631610682 := by decide
theorem cert_e1211585099578 : check e1211585099578 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211585099830 : Closed e1211585099830 ∧ code e1211585099830 = 5609631610934 := by decide
theorem cert_e1211585099830 : check e1211585099830 [[],[],[],[]] .sourceHead = true := by decide
def e1211585099918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211585099918 : Closed e1211585099918 ∧ code e1211585099918 = 5609631611022 := by decide
theorem cert_e1211585099918 : check e1211585099918 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211585100002 : Closed e1211585100002 ∧ code e1211585100002 = 5609631611106 := by decide
theorem cert_e1211585100002 : check e1211585100002 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211585100014 : Closed e1211585100014 ∧ code e1211585100014 = 5609631611118 := by decide
theorem cert_e1211585100014 : check e1211585100014 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211585100022 : Closed e1211585100022 ∧ code e1211585100022 = 5609631611126 := by decide
theorem cert_e1211585100022 : check e1211585100022 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211585100214 : Closed e1211585100214 ∧ code e1211585100214 = 5609631611318 := by decide
theorem cert_e1211585100214 : check e1211585100214 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211585100246 : Closed e1211585100246 ∧ code e1211585100246 = 5609631611350 := by decide
theorem cert_e1211585100246 : check e1211585100246 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211585100250 : Closed e1211585100250 ∧ code e1211585100250 = 5609631611354 := by decide
theorem cert_e1211585100250 : check e1211585100250 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211585100406 : Closed e1211585100406 ∧ code e1211585100406 = 5609631611510 := by decide
theorem cert_e1211585100406 : check e1211585100406 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211585100550 : Closed e1211585100550 ∧ code e1211585100550 = 5609631611654 := by decide
theorem cert_e1211585100550 : check e1211585100550 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211585100574 : Closed e1211585100574 ∧ code e1211585100574 = 5609631611678 := by decide
theorem cert_e1211585100574 : check e1211585100574 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211585100598 : Closed e1211585100598 ∧ code e1211585100598 = 5609631611702 := by decide
theorem cert_e1211585100598 : check e1211585100598 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211585100602 : Closed e1211585100602 ∧ code e1211585100602 = 5609631611706 := by decide
theorem cert_e1211585100602 : check e1211585100602 [[],[],[],[]] .sourceHead = true := by decide
def e1211585100686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211585100686 : Closed e1211585100686 ∧ code e1211585100686 = 5609631611790 := by decide
theorem cert_e1211585100686 : check e1211585100686 [[],[],[],[]] .sourceHead = true := by decide
def e1211585107822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211585107822 : Closed e1211585107822 ∧ code e1211585107822 = 5609631618926 := by decide
theorem cert_e1211585107822 : check e1211585107822 [[],[],[],[]] .sourceHead = true := by decide
def e1211585107830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211585107830 : Closed e1211585107830 ∧ code e1211585107830 = 5609631618934 := by decide
theorem cert_e1211585107830 : check e1211585107830 [[],[],[],[]] .sourceHead = true := by decide
def e1211585107894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211585107894 : Closed e1211585107894 ∧ code e1211585107894 = 5609631618998 := by decide
theorem cert_e1211585107894 : check e1211585107894 [[],[],[],[]] .sourceHead = true := by decide
def e1211585109230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585109230 : Closed e1211585109230 ∧ code e1211585109230 = 5609631620334 := by decide
theorem cert_e1211585109230 : check e1211585109230 [[],[],[],[]] .sourceHead = true := by decide
def e1211585109238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585109238 : Closed e1211585109238 ∧ code e1211585109238 = 5609631620342 := by decide
theorem cert_e1211585109238 : check e1211585109238 [[],[],[],[]] .sourceHead = true := by decide
def e1211585109622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211585109622 : Closed e1211585109622 ∧ code e1211585109622 = 5609631620726 := by decide
theorem cert_e1211585109622 : check e1211585109622 [[],[],[],[]] .sourceHead = true := by decide
def e1211585118334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211585118334 : Closed e1211585118334 ∧ code e1211585118334 = 5609631629438 := by decide
theorem cert_e1211585118334 : check e1211585118334 [[],[],[],[]] .sourceHead = true := by decide
def e1211585119198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211585119198 : Closed e1211585119198 ∧ code e1211585119198 = 5609631630302 := by decide
theorem cert_e1211585119198 : check e1211585119198 [[],[],[],[]] .sourceHead = true := by decide
def e1211585119202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211585119202 : Closed e1211585119202 ∧ code e1211585119202 = 5609631630306 := by decide
theorem cert_e1211585119202 : check e1211585119202 [[],[],[],[]] .sourceHead = true := by decide
def e1211585119214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211585119214 : Closed e1211585119214 ∧ code e1211585119214 = 5609631630318 := by decide
theorem cert_e1211585119214 : check e1211585119214 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211585121134 : Closed e1211585121134 ∧ code e1211585121134 = 5609631632238 := by decide
theorem cert_e1211585121134 : check e1211585121134 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211585121142 : Closed e1211585121142 ∧ code e1211585121142 = 5609631632246 := by decide
theorem cert_e1211585121142 : check e1211585121142 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211585121198 : Closed e1211585121198 ∧ code e1211585121198 = 5609631632302 := by decide
theorem cert_e1211585121198 : check e1211585121198 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211585121210 : Closed e1211585121210 ∧ code e1211585121210 = 5609631632314 := by decide
theorem cert_e1211585121210 : check e1211585121210 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211585121238 : Closed e1211585121238 ∧ code e1211585121238 = 5609631632342 := by decide
theorem cert_e1211585121238 : check e1211585121238 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211585121242 : Closed e1211585121242 ∧ code e1211585121242 = 5609631632346 := by decide
theorem cert_e1211585121242 : check e1211585121242 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585121518 : Closed e1211585121518 ∧ code e1211585121518 = 5609631632622 := by decide
theorem cert_e1211585121518 : check e1211585121518 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585121526 : Closed e1211585121526 ∧ code e1211585121526 = 5609631632630 := by decide
theorem cert_e1211585121526 : check e1211585121526 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211585121902 : Closed e1211585121902 ∧ code e1211585121902 = 5609631633006 := by decide
theorem cert_e1211585121902 : check e1211585121902 [[],[],[],[]] .sourceHead = true := by decide
def e1211585121914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211585121914 : Closed e1211585121914 ∧ code e1211585121914 = 5609631633018 := by decide
theorem cert_e1211585121914 : check e1211585121914 [[],[],[],[]] .sourceHead = true := by decide
def e1211585122054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211585122054 : Closed e1211585122054 ∧ code e1211585122054 = 5609631633158 := by decide
theorem cert_e1211585122054 : check e1211585122054 [[],[],[],[]] .sourceHead = true := by decide
def e1211585122078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211585122078 : Closed e1211585122078 ∧ code e1211585122078 = 5609631633182 := by decide
theorem cert_e1211585122078 : check e1211585122078 [[],[],[],[]] .sourceHead = true := by decide
def e1211585122102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585122102 : Closed e1211585122102 ∧ code e1211585122102 = 5609631633206 := by decide
theorem cert_e1211585122102 : check e1211585122102 [[],[],[],[]] .sourceHead = true := by decide
def e1211585122106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585122106 : Closed e1211585122106 ∧ code e1211585122106 = 5609631633210 := by decide
theorem cert_e1211585122106 : check e1211585122106 [[],[],[],[]] .sourceHead = true := by decide
def e1211585126462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211585126462 : Closed e1211585126462 ∧ code e1211585126462 = 5609631637566 := by decide
theorem cert_e1211585126462 : check e1211585126462 [[],[],[],[]] .sourceHead = true := by decide
def e1211585126882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211585126882 : Closed e1211585126882 ∧ code e1211585126882 = 5609631637986 := by decide
theorem cert_e1211585126882 : check e1211585126882 [[],[],[],[]] .sourceHead = true := by decide
def e1211585126894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211585126894 : Closed e1211585126894 ∧ code e1211585126894 = 5609631637998 := by decide
theorem cert_e1211585126894 : check e1211585126894 [[],[],[],[]] .sourceHead = true := by decide
def e1211585127862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211585127862 : Closed e1211585127862 ∧ code e1211585127862 = 5609631638966 := by decide
theorem cert_e1211585127862 : check e1211585127862 [[],[],[],[]] .sourceHead = true := by decide
def e1211585127894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211585127894 : Closed e1211585127894 ∧ code e1211585127894 = 5609631638998 := by decide
theorem cert_e1211585127894 : check e1211585127894 [[],[],[],[]] .sourceHead = true := by decide
def e1211585127898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211585127898 : Closed e1211585127898 ∧ code e1211585127898 = 5609631639002 := by decide
theorem cert_e1211585127898 : check e1211585127898 [[],[],[],[]] .sourceHead = true := by decide
def e1211585128054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211585128054 : Closed e1211585128054 ∧ code e1211585128054 = 5609631639158 := by decide
theorem cert_e1211585128054 : check e1211585128054 [[],[],[],[]] .sourceHead = true := by decide
def e1211585128198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211585128198 : Closed e1211585128198 ∧ code e1211585128198 = 5609631639302 := by decide
theorem cert_e1211585128198 : check e1211585128198 [[],[],[],[]] .sourceHead = true := by decide
def e1211585128222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211585128222 : Closed e1211585128222 ∧ code e1211585128222 = 5609631639326 := by decide
theorem cert_e1211585128222 : check e1211585128222 [[],[],[],[]] .sourceHead = true := by decide
def e1211585128246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585128246 : Closed e1211585128246 ∧ code e1211585128246 = 5609631639350 := by decide
theorem cert_e1211585128246 : check e1211585128246 [[],[],[],[]] .sourceHead = true := by decide
def e1211585128250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585128250 : Closed e1211585128250 ∧ code e1211585128250 = 5609631639354 := by decide
theorem cert_e1211585128250 : check e1211585128250 [[],[],[],[]] .sourceHead = true := by decide
def e1211585128334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211585128334 : Closed e1211585128334 ∧ code e1211585128334 = 5609631639438 := by decide
theorem cert_e1211585128334 : check e1211585128334 [[],[],[],[]] .sourceHead = true := by decide
def e1211585277406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211585277406 : Closed e1211585277406 ∧ code e1211585277406 = 5609631788510 := by decide
private def t_e1211585277406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem cert_e1211585277406 : ¬ IsSelfInterpreter e1211585277406 :=
  wSource (t := t_e1211585277406) (replay_sound (ps := []) (t := e1211585277406) (by decide)) (by decide)
def e1211585277422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211585277422 : Closed e1211585277422 ∧ code e1211585277422 = 5609631788526 := by decide
private def t_e1211585277422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem cert_e1211585277422 : ¬ IsSelfInterpreter e1211585277422 :=
  wSource (t := t_e1211585277422) (replay_sound (ps := []) (t := e1211585277422) (by decide)) (by decide)
def e1211585277662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211585277662 : Closed e1211585277662 ∧ code e1211585277662 = 5609631788766 := by decide
theorem cert_e1211585277662 : check e1211585277662 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e1211585277686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211585277686 : Closed e1211585277686 ∧ code e1211585277686 = 5609631788790 := by decide
theorem cert_e1211585277686 : check e1211585277686 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e1211585277790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211585277790 : Closed e1211585277790 ∧ code e1211585277790 = 5609631788894 := by decide
private def t_e1211585277790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem cert_e1211585277790 : ¬ IsSelfInterpreter e1211585277790 :=
  wSource (t := t_e1211585277790) (replay_sound (ps := []) (t := e1211585277790) (by decide)) (by decide)
def e1211585277818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211585277818 : Closed e1211585277818 ∧ code e1211585277818 = 5609631788922 := by decide
private def t_e1211585277818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem cert_e1211585277818 : ¬ IsSelfInterpreter e1211585277818 :=
  wSource (t := t_e1211585277818) (replay_sound (ps := []) (t := e1211585277818) (by decide)) (by decide)
def e1211585277870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211585277870 : Closed e1211585277870 ∧ code e1211585277870 = 5609631788974 := by decide
private def t_e1211585277870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem cert_e1211585277870 : ¬ IsSelfInterpreter e1211585277870 :=
  wSource (t := t_e1211585277870) (replay_sound (ps := []) (t := e1211585277870) (by decide)) (by decide)
def e1211585277878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211585277878 : Closed e1211585277878 ∧ code e1211585277878 = 5609631788982 := by decide
theorem cert_e1211585277878 : check e1211585277878 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e1211585277882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211585277882 : Closed e1211585277882 ∧ code e1211585277882 = 5609631788986 := by decide
private def t_e1211585277882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem cert_e1211585277882 : ¬ IsSelfInterpreter e1211585277882 :=
  wSource (t := t_e1211585277882) (replay_sound (ps := []) (t := e1211585277882) (by decide)) (by decide)
def e1211585278942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211585278942 : Closed e1211585278942 ∧ code e1211585278942 = 5609631790046 := by decide
private def t_e1211585278942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem cert_e1211585278942 : ¬ IsSelfInterpreter e1211585278942 :=
  wSource (t := t_e1211585278942) (replay_sound (ps := []) (t := e1211585278942) (by decide)) (by decide)
def e1211585278958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211585278958 : Closed e1211585278958 ∧ code e1211585278958 = 5609631790062 := by decide
private def t_e1211585278958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem cert_e1211585278958 : ¬ IsSelfInterpreter e1211585278958 :=
  wSource (t := t_e1211585278958) (replay_sound (ps := []) (t := e1211585278958) (by decide)) (by decide)
def e1211585280478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211585280478 : Closed e1211585280478 ∧ code e1211585280478 = 5609631791582 := by decide
theorem cert_e1211585280478 : check e1211585280478 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e1211585280502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211585280502 : Closed e1211585280502 ∧ code e1211585280502 = 5609631791606 := by decide
theorem cert_e1211585280502 : check e1211585280502 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e1211585281246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211585281246 : Closed e1211585281246 ∧ code e1211585281246 = 5609631792350 := by decide
private def t_e1211585281246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem cert_e1211585281246 : ¬ IsSelfInterpreter e1211585281246 :=
  wSource (t := t_e1211585281246) (replay_sound (ps := []) (t := e1211585281246) (by decide)) (by decide)
def e1211585281274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211585281274 : Closed e1211585281274 ∧ code e1211585281274 = 5609631792378 := by decide
private def t_e1211585281274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem cert_e1211585281274 : ¬ IsSelfInterpreter e1211585281274 :=
  wSource (t := t_e1211585281274) (replay_sound (ps := []) (t := e1211585281274) (by decide)) (by decide)
def e1211585281646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211585281646 : Closed e1211585281646 ∧ code e1211585281646 = 5609631792750 := by decide
private def t_e1211585281646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211585281646 : ¬ IsSelfInterpreter e1211585281646 :=
  wSource (t := t_e1211585281646) (replay_sound (ps := []) (t := e1211585281646) (by decide)) (by decide)
def e1211585281654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211585281654 : Closed e1211585281654 ∧ code e1211585281654 = 5609631792758 := by decide
theorem cert_e1211585281654 : check e1211585281654 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e1211585281658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211585281658 : Closed e1211585281658 ∧ code e1211585281658 = 5609631792762 := by decide
private def t_e1211585281658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211585281658 : ¬ IsSelfInterpreter e1211585281658 :=
  wSource (t := t_e1211585281658) (replay_sound (ps := []) (t := e1211585281658) (by decide)) (by decide)
def e1211585310062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211585310062 : Closed e1211585310062 ∧ code e1211585310062 = 5609631821166 := by decide
theorem cert_e1211585310062 : check e1211585310062 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585310070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211585310070 : Closed e1211585310070 ∧ code e1211585310070 = 5609631821174 := by decide
theorem cert_e1211585310070 : check e1211585310070 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585310126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211585310126 : Closed e1211585310126 ∧ code e1211585310126 = 5609631821230 := by decide
theorem cert_e1211585310126 : check e1211585310126 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585310138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211585310138 : Closed e1211585310138 ∧ code e1211585310138 = 5609631821242 := by decide
theorem cert_e1211585310138 : check e1211585310138 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585310166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211585310166 : Closed e1211585310166 ∧ code e1211585310166 = 5609631821270 := by decide
theorem cert_e1211585310166 : check e1211585310166 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585310170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211585310170 : Closed e1211585310170 ∧ code e1211585310170 = 5609631821274 := by decide
theorem cert_e1211585310170 : check e1211585310170 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585310382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211585310382 : Closed e1211585310382 ∧ code e1211585310382 = 5609631821486 := by decide
theorem cert_e1211585310382 : check e1211585310382 [[],[],[],[],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585310394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211585310394 : Closed e1211585310394 ∧ code e1211585310394 = 5609631821498 := by decide
theorem cert_e1211585310394 : check e1211585310394 [[],[],[],[],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585310442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211585310442 : Closed e1211585310442 ∧ code e1211585310442 = 5609631821546 := by decide
private def t_e1211585310442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem cert_e1211585310442 : ¬ IsSelfInterpreter e1211585310442 :=
  wSource (t := t_e1211585310442) (replay_sound (ps := []) (t := e1211585310442) (by decide)) (by decide)
def e1211585310550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211585310550 : Closed e1211585310550 ∧ code e1211585310550 = 5609631821654 := by decide
theorem cert_e1211585310550 : check e1211585310550 [[],[],[],[],[.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211585310554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211585310554 : Closed e1211585310554 ∧ code e1211585310554 = 5609631821658 := by decide
theorem cert_e1211585310554 : check e1211585310554 [[],[],[],[],[.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211585310570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211585310570 : Closed e1211585310570 ∧ code e1211585310570 = 5609631821674 := by decide
private def t_e1211585310570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem cert_e1211585310570 : ¬ IsSelfInterpreter e1211585310570 :=
  wSource (t := t_e1211585310570) (replay_sound (ps := []) (t := e1211585310570) (by decide)) (by decide)
def e1211585310830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211585310830 : Closed e1211585310830 ∧ code e1211585310830 = 5609631821934 := by decide
theorem cert_e1211585310830 : check e1211585310830 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211585311006 : Closed e1211585311006 ∧ code e1211585311006 = 5609631822110 := by decide
theorem cert_e1211585311006 : check e1211585311006 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211585311202 : Closed e1211585311202 ∧ code e1211585311202 = 5609631822306 := by decide
theorem cert_e1211585311202 : check e1211585311202 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211585311214 : Closed e1211585311214 ∧ code e1211585311214 = 5609631822318 := by decide
theorem cert_e1211585311214 : check e1211585311214 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211585311598 : Closed e1211585311598 ∧ code e1211585311598 = 5609631822702 := by decide
theorem cert_e1211585311598 : check e1211585311598 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211585311606 : Closed e1211585311606 ∧ code e1211585311606 = 5609631822710 := by decide
theorem cert_e1211585311606 : check e1211585311606 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211585311662 : Closed e1211585311662 ∧ code e1211585311662 = 5609631822766 := by decide
theorem cert_e1211585311662 : check e1211585311662 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211585311674 : Closed e1211585311674 ∧ code e1211585311674 = 5609631822778 := by decide
theorem cert_e1211585311674 : check e1211585311674 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211585311702 : Closed e1211585311702 ∧ code e1211585311702 = 5609631822806 := by decide
theorem cert_e1211585311702 : check e1211585311702 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211585311706 : Closed e1211585311706 ∧ code e1211585311706 = 5609631822810 := by decide
theorem cert_e1211585311706 : check e1211585311706 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211585311982 : Closed e1211585311982 ∧ code e1211585311982 = 5609631823086 := by decide
theorem cert_e1211585311982 : check e1211585311982 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585311990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211585311990 : Closed e1211585311990 ∧ code e1211585311990 = 5609631823094 := by decide
theorem cert_e1211585311990 : check e1211585311990 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585312366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211585312366 : Closed e1211585312366 ∧ code e1211585312366 = 5609631823470 := by decide
theorem cert_e1211585312366 : check e1211585312366 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585312378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211585312378 : Closed e1211585312378 ∧ code e1211585312378 = 5609631823482 := by decide
theorem cert_e1211585312378 : check e1211585312378 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585312518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211585312518 : Closed e1211585312518 ∧ code e1211585312518 = 5609631823622 := by decide
theorem cert_e1211585312518 : check e1211585312518 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585312542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211585312542 : Closed e1211585312542 ∧ code e1211585312542 = 5609631823646 := by decide
theorem cert_e1211585312542 : check e1211585312542 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585312566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211585312566 : Closed e1211585312566 ∧ code e1211585312566 = 5609631823670 := by decide
theorem cert_e1211585312566 : check e1211585312566 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585312570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211585312570 : Closed e1211585312570 ∧ code e1211585312570 = 5609631823674 := by decide
theorem cert_e1211585312570 : check e1211585312570 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211585313198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211585313198 : Closed e1211585313198 ∧ code e1211585313198 = 5609631824302 := by decide
theorem cert_e1211585313198 : check e1211585313198 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585313210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211585313210 : Closed e1211585313210 ∧ code e1211585313210 = 5609631824314 := by decide
theorem cert_e1211585313210 : check e1211585313210 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585313258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211585313258 : Closed e1211585313258 ∧ code e1211585313258 = 5609631824362 := by decide
theorem cert_e1211585313258 : check e1211585313258 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585313390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211585313390 : Closed e1211585313390 ∧ code e1211585313390 = 5609631824494 := by decide
theorem cert_e1211585313390 : checkPay e1211585313390 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left]] 0 [] = true := by decide
def e1211585313402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211585313402 : Closed e1211585313402 ∧ code e1211585313402 = 5609631824506 := by decide
theorem cert_e1211585313402 : checkPay e1211585313402 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left]] 0 [[.left,.right],[.right],[.right,.under,.left],[.right,.under,.right,.left,.left],[.right,.under,.right,.right]] = true := by decide
def e1211585313690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211585313690 : Closed e1211585313690 ∧ code e1211585313690 = 5609631824794 := by decide
private def t_e1211585313690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211585313690 : ¬ IsSelfInterpreter e1211585313690 :=
  wSource (t := t_e1211585313690) (replay_sound (ps := []) (t := e1211585313690) (by decide)) (by decide)
def e1211585313818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211585313818 : Closed e1211585313818 ∧ code e1211585313818 = 5609631824922 := by decide
theorem cert_e1211585313818 : check e1211585313818 [[],[],[],[],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211585313862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211585313862 : Closed e1211585313862 ∧ code e1211585313862 = 5609631824966 := by decide
theorem cert_e1211585313862 : check e1211585313862 [[],[],[],[],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211585313890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211585313890 : Closed e1211585313890 ∧ code e1211585313890 = 5609631824994 := by decide
theorem cert_e1211585313890 : check e1211585313890 [[],[],[],[],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211585313902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211585313902 : Closed e1211585313902 ∧ code e1211585313902 = 5609631825006 := by decide
theorem cert_e1211585313902 : checkPay e1211585313902 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e1211585313914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211585313914 : Closed e1211585313914 ∧ code e1211585313914 = 5609631825018 := by decide
theorem cert_e1211585313914 : checkPay e1211585313914 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e1211585314006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211585314006 : Closed e1211585314006 ∧ code e1211585314006 = 5609631825110 := by decide
theorem cert_e1211585314006 : check e1211585314006 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585314010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211585314010 : Closed e1211585314010 ∧ code e1211585314010 = 5609631825114 := by decide
theorem cert_e1211585314010 : check e1211585314010 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585314026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211585314026 : Closed e1211585314026 ∧ code e1211585314026 = 5609631825130 := by decide
theorem cert_e1211585314026 : check e1211585314026 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585314054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211585314054 : Closed e1211585314054 ∧ code e1211585314054 = 5609631825158 := by decide
theorem cert_e1211585314054 : check e1211585314054 [[],[],[],[],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211585314078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211585314078 : Closed e1211585314078 ∧ code e1211585314078 = 5609631825182 := by decide
theorem cert_e1211585314078 : check e1211585314078 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585314102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211585314102 : Closed e1211585314102 ∧ code e1211585314102 = 5609631825206 := by decide
theorem cert_e1211585314102 : check e1211585314102 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585314106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211585314106 : Closed e1211585314106 ∧ code e1211585314106 = 5609631825210 := by decide
theorem cert_e1211585314106 : check e1211585314106 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585314202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211585314202 : Closed e1211585314202 ∧ code e1211585314202 = 5609631825306 := by decide
private def t_e1211585314202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211585314202 : ¬ IsSelfInterpreter e1211585314202 :=
  wSource (t := t_e1211585314202) (replay_sound (ps := []) (t := e1211585314202) (by decide)) (by decide)
def e1211585314246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211585314246 : Closed e1211585314246 ∧ code e1211585314246 = 5609631825350 := by decide
private def t_e1211585314246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e1211585314246 : ¬ IsSelfInterpreter e1211585314246 :=
  wSource (t := t_e1211585314246) (replay_sound (ps := []) (t := e1211585314246) (by decide)) (by decide)
def e1211585314942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211585314942 : Closed e1211585314942 ∧ code e1211585314942 = 5609631826046 := by decide
theorem cert_e1211585314942 : checkPay e1211585314942 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211585315806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211585315806 : Closed e1211585315806 ∧ code e1211585315806 = 5609631826910 := by decide
def e1211585315810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211585315810 : Closed e1211585315810 ∧ code e1211585315810 = 5609631826914 := by decide
theorem cert_e1211585315810 : checkPay e1211585315810 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under],[.under],[.under,.under,.under,.right,.right,.under]] = true := by decide
def e1211585315822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211585315822 : Closed e1211585315822 ∧ code e1211585315822 = 5609631826926 := by decide
def e1211585317742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211585317742 : Closed e1211585317742 ∧ code e1211585317742 = 5609631828846 := by decide
theorem cert_e1211585317742 : checkPay e1211585317742 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211585317750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211585317750 : Closed e1211585317750 ∧ code e1211585317750 = 5609631828854 := by decide
theorem cert_e1211585317750 : checkPay e1211585317750 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211585317806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211585317806 : Closed e1211585317806 ∧ code e1211585317806 = 5609631828910 := by decide
theorem cert_e1211585317806 : checkPay e1211585317806 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.left],[],[.right]] = true := by decide
def e1211585317818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211585317818 : Closed e1211585317818 ∧ code e1211585317818 = 5609631828922 := by decide
def e1211585317846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211585317846 : Closed e1211585317846 ∧ code e1211585317846 = 5609631828950 := by decide
theorem cert_e1211585317846 : checkPay e1211585317846 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.left],[.right,.under,.under,.right,.right,.left],[.right,.under,.under,.right,.right],[.right,.under,.under,.right,.right,.right,.right,.left]] = true := by decide
def e1211585317850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211585317850 : Closed e1211585317850 ∧ code e1211585317850 = 5609631828954 := by decide
def e1211585318126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585318126 : Closed e1211585318126 ∧ code e1211585318126 = 5609631829230 := by decide
def e1211585318134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585318134 : Closed e1211585318134 ∧ code e1211585318134 = 5609631829238 := by decide
def e1211585318510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211585318510 : Closed e1211585318510 ∧ code e1211585318510 = 5609631829614 := by decide
theorem cert_e1211585318510 : checkPay e1211585318510 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[]] = true := by decide
def e1211585318522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211585318522 : Closed e1211585318522 ∧ code e1211585318522 = 5609631829626 := by decide
theorem cert_e1211585318522 : checkPay e1211585318522 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[.under,.left],[.under,.right,.right,.left],[.under,.right,.right,.right],[.under,.right,.right,.right,.under,.right,.right,.right]] = true := by decide
def e1211585318662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211585318662 : Closed e1211585318662 ∧ code e1211585318662 = 5609631829766 := by decide
theorem cert_e1211585318662 : checkPay e1211585318662 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[],[.under,.under,.under,.right,.right]] = true := by decide
def e1211585318686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211585318686 : Closed e1211585318686 ∧ code e1211585318686 = 5609631829790 := by decide
theorem cert_e1211585318686 : checkPay e1211585318686 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[]] = true := by decide
def e1211585318710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585318710 : Closed e1211585318710 ∧ code e1211585318710 = 5609631829814 := by decide
theorem cert_e1211585318710 : checkPay e1211585318710 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[.left,.right,.under,.under,.right,.right],[.left,.right,.under,.under,.right,.right,.under,.right,.right],[.right,.under,.under,.right,.right,.left,.right,.under,.under,.right,.right],[.right,.under,.under,.right,.right,.left,.right,.under,.under,.right,.right,.under,.right,.right]] = true := by decide
def e1211585318714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585318714 : Closed e1211585318714 ∧ code e1211585318714 = 5609631829818 := by decide
def e1211585323486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211585323486 : Closed e1211585323486 ∧ code e1211585323486 = 5609631834590 := by decide
theorem cert_e1211585323486 : check e1211585323486 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e1211585323510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211585323510 : Closed e1211585323510 ∧ code e1211585323510 = 5609631834614 := by decide
theorem cert_e1211585323510 : check e1211585323510 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e1211585324462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211585324462 : Closed e1211585324462 ∧ code e1211585324462 = 5609631835566 := by decide
theorem cert_e1211585324462 : check e1211585324462 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211585324474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211585324474 : Closed e1211585324474 ∧ code e1211585324474 = 5609631835578 := by decide
theorem cert_e1211585324474 : check e1211585324474 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211585324522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211585324522 : Closed e1211585324522 ∧ code e1211585324522 = 5609631835626 := by decide
theorem cert_e1211585324522 : check e1211585324522 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585324654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211585324654 : Closed e1211585324654 ∧ code e1211585324654 = 5609631835758 := by decide
theorem cert_e1211585324654 : checkPay e1211585324654 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] 0 [] = true := by decide
def e1211585324666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211585324666 : Closed e1211585324666 ∧ code e1211585324666 = 5609631835770 := by decide
theorem cert_e1211585324666 : checkPay e1211585324666 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] 0 [[]] = true := by decide
def e1211585324954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211585324954 : Closed e1211585324954 ∧ code e1211585324954 = 5609631836058 := by decide
theorem cert_e1211585324954 : check e1211585324954 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585327134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211585327134 : Closed e1211585327134 ∧ code e1211585327134 = 5609631838238 := by decide
theorem cert_e1211585327134 : check e1211585327134 [[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1211585327330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211585327330 : Closed e1211585327330 ∧ code e1211585327330 = 5609631838434 := by decide
theorem cert_e1211585327330 : check e1211585327330 [[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1211585327342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211585327342 : Closed e1211585327342 ∧ code e1211585327342 = 5609631838446 := by decide
theorem cert_e1211585327342 : checkPay e1211585327342 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left]] 0 [[.under,.under,.right],[.under,.under,.right,.under]] = true := by decide
def e1211585327350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211585327350 : Closed e1211585327350 ∧ code e1211585327350 = 5609631838454 := by decide
theorem cert_e1211585327350 : check e1211585327350 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211585327830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211585327830 : Closed e1211585327830 ∧ code e1211585327830 = 5609631838934 := by decide
theorem cert_e1211585327830 : check e1211585327830 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585327834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211585327834 : Closed e1211585327834 ∧ code e1211585327834 = 5609631838938 := by decide
theorem cert_e1211585327834 : check e1211585327834 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585327850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211585327850 : Closed e1211585327850 ∧ code e1211585327850 = 5609631838954 := by decide
theorem cert_e1211585327850 : check e1211585327850 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211585327878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211585327878 : Closed e1211585327878 ∧ code e1211585327878 = 5609631838982 := by decide
theorem cert_e1211585327878 : check e1211585327878 [[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1211585327902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211585327902 : Closed e1211585327902 ∧ code e1211585327902 = 5609631839006 := by decide
theorem cert_e1211585327902 : check e1211585327902 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585327926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211585327926 : Closed e1211585327926 ∧ code e1211585327926 = 5609631839030 := by decide
theorem cert_e1211585327926 : check e1211585327926 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585327930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211585327930 : Closed e1211585327930 ∧ code e1211585327930 = 5609631839034 := by decide
theorem cert_e1211585327930 : check e1211585327930 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1211585328026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211585328026 : Closed e1211585328026 ∧ code e1211585328026 = 5609631839130 := by decide
theorem cert_e1211585328026 : check e1211585328026 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
end Blc.Floor42
