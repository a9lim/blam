import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1203530494678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1203530494678 : Closed e1203530494678 ∧ code e1203530494678 = 5601577005782 := by decide
theorem cert_e1203530494678 : check e1203530494678 [[],[]] .three = true := by decide
def e1203530494682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1203530494682 : Closed e1203530494682 ∧ code e1203530494682 = 5601577005786 := by decide
theorem cert_e1203530494682 : check e1203530494682 [[],[]] .three = true := by decide
def e1203530494698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1203530494698 : Closed e1203530494698 ∧ code e1203530494698 = 5601577005802 := by decide
theorem cert_e1203530494698 : check e1203530494698 [[],[]] .three = true := by decide
def e1203530494774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203530494774 : Closed e1203530494774 ∧ code e1203530494774 = 5601577005878 := by decide
theorem cert_e1203530494774 : check e1203530494774 [[],[]] .three = true := by decide
def e1203530494778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203530494778 : Closed e1203530494778 ∧ code e1203530494778 = 5601577005882 := by decide
theorem cert_e1203530494778 : check e1203530494778 [[],[]] .three = true := by decide
def e1203530494874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1203530494874 : Closed e1203530494874 ∧ code e1203530494874 = 5601577005978 := by decide
theorem cert_e1203530494874 : check e1203530494874 [[],[]] .three = true := by decide
def e1203530720110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1203530720110 : Closed e1203530720110 ∧ code e1203530720110 = 5601577231214 := by decide
theorem cert_e1203530720110 : check e1203530720110 [[],[]] .chain = true := by decide
def e1203530720118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1203530720118 : Closed e1203530720118 ∧ code e1203530720118 = 5601577231222 := by decide
theorem cert_e1203530720118 : check e1203530720118 [[],[]] .chain = true := by decide
def e1203530720174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1203530720174 : Closed e1203530720174 ∧ code e1203530720174 = 5601577231278 := by decide
theorem cert_e1203530720174 : check e1203530720174 [[],[]] .chain = true := by decide
def e1203530720186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1203530720186 : Closed e1203530720186 ∧ code e1203530720186 = 5601577231290 := by decide
theorem cert_e1203530720186 : check e1203530720186 [[],[]] .chain = true := by decide
def e1203530720214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1203530720214 : Closed e1203530720214 ∧ code e1203530720214 = 5601577231318 := by decide
theorem cert_e1203530720214 : check e1203530720214 [[],[]] .chain = true := by decide
def e1203530720218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1203530720218 : Closed e1203530720218 ∧ code e1203530720218 = 5601577231322 := by decide
theorem cert_e1203530720218 : check e1203530720218 [[],[]] .chain = true := by decide
def e1203530721518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1203530721518 : Closed e1203530721518 ∧ code e1203530721518 = 5601577232622 := by decide
theorem cert_e1203530721518 : check e1203530721518 [[],[]] .chain = true := by decide
def e1203530721526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1203530721526 : Closed e1203530721526 ∧ code e1203530721526 = 5601577232630 := by decide
theorem cert_e1203530721526 : check e1203530721526 [[],[]] .chain = true := by decide
def e1203530722078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1203530722078 : Closed e1203530722078 ∧ code e1203530722078 = 5601577233182 := by decide
theorem cert_e1203530722078 : check e1203530722078 [[],[]] .chain = true := by decide
def e1203530722190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1203530722190 : Closed e1203530722190 ∧ code e1203530722190 = 5601577233294 := by decide
theorem cert_e1203530722190 : check e1203530722190 [[],[]] .chain = true := by decide
def e1203530722414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1203530722414 : Closed e1203530722414 ∧ code e1203530722414 = 5601577233518 := by decide
theorem cert_e1203530722414 : check e1203530722414 [[],[]] .chain = true := by decide
def e1203530722426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1203530722426 : Closed e1203530722426 ∧ code e1203530722426 = 5601577233530 := by decide
theorem cert_e1203530722426 : check e1203530722426 [[],[]] .chain = true := by decide
def e1203530722590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1203530722590 : Closed e1203530722590 ∧ code e1203530722590 = 5601577233694 := by decide
theorem cert_e1203530722590 : check e1203530722590 [[],[]] .chain = true := by decide
def e1203530722758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1203530722758 : Closed e1203530722758 ∧ code e1203530722758 = 5601577233862 := by decide
theorem cert_e1203530722758 : check e1203530722758 [[],[]] .chain = true := by decide
def e1203530722870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1203530722870 : Closed e1203530722870 ∧ code e1203530722870 = 5601577233974 := by decide
theorem cert_e1203530722870 : check e1203530722870 [[],[]] .chain = true := by decide
def e1203530722874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1203530722874 : Closed e1203530722874 ∧ code e1203530722874 = 5601577233978 := by decide
theorem cert_e1203530722874 : check e1203530722874 [[],[]] .chain = true := by decide
def e1203530722958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1203530722958 : Closed e1203530722958 ∧ code e1203530722958 = 5601577234062 := by decide
theorem cert_e1203530722958 : check e1203530722958 [[],[]] .chain = true := by decide
def e1203530723014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1203530723014 : Closed e1203530723014 ∧ code e1203530723014 = 5601577234118 := by decide
theorem cert_e1203530723014 : check e1203530723014 [[],[]] .chain = true := by decide
def e1203530723758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1203530723758 : Closed e1203530723758 ∧ code e1203530723758 = 5601577234862 := by decide
theorem cert_e1203530723758 : check e1203530723758 [[],[]] .chain = true := by decide
def e1203530723770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1203530723770 : Closed e1203530723770 ∧ code e1203530723770 = 5601577234874 := by decide
theorem cert_e1203530723770 : check e1203530723770 [[],[]] .chain = true := by decide
def e1203530723818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1203530723818 : Closed e1203530723818 ∧ code e1203530723818 = 5601577234922 := by decide
theorem cert_e1203530723818 : check e1203530723818 [[],[]] .chain = true := by decide
def e1203530724462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1203530724462 : Closed e1203530724462 ∧ code e1203530724462 = 5601577235566 := by decide
theorem cert_e1203530724462 : check e1203530724462 [[],[]] .chain = true := by decide
def e1203530724474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1203530724474 : Closed e1203530724474 ∧ code e1203530724474 = 5601577235578 := by decide
theorem cert_e1203530724474 : check e1203530724474 [[],[]] .chain = true := by decide
def e1203530724638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1203530724638 : Closed e1203530724638 ∧ code e1203530724638 = 5601577235742 := by decide
theorem cert_e1203530724638 : check e1203530724638 [[],[]] .chain = true := by decide
def e1203530724806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1203530724806 : Closed e1203530724806 ∧ code e1203530724806 = 5601577235910 := by decide
theorem cert_e1203530724806 : check e1203530724806 [[],[]] .chain = true := by decide
def e1203530725146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1203530725146 : Closed e1203530725146 ∧ code e1203530725146 = 5601577236250 := by decide
theorem cert_e1203530725146 : check e1203530725146 [[],[]] .chain = true := by decide
def e1203530725190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1203530725190 : Closed e1203530725190 ∧ code e1203530725190 = 5601577236294 := by decide
theorem cert_e1203530725190 : check e1203530725190 [[],[]] .chain = true := by decide
def e1203530725590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1203530725590 : Closed e1203530725590 ∧ code e1203530725590 = 5601577236694 := by decide
theorem cert_e1203530725590 : check e1203530725590 [[],[]] .chain = true := by decide
def e1203530725594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1203530725594 : Closed e1203530725594 ∧ code e1203530725594 = 5601577236698 := by decide
theorem cert_e1203530725594 : check e1203530725594 [[],[]] .chain = true := by decide
def e1203530725610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1203530725610 : Closed e1203530725610 ∧ code e1203530725610 = 5601577236714 := by decide
theorem cert_e1203530725610 : check e1203530725610 [[],[]] .chain = true := by decide
def e1203530725942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1203530725942 : Closed e1203530725942 ∧ code e1203530725942 = 5601577237046 := by decide
theorem cert_e1203530725942 : check e1203530725942 [[],[]] .chain = true := by decide
def e1203530725946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1203530725946 : Closed e1203530725946 ∧ code e1203530725946 = 5601577237050 := by decide
theorem cert_e1203530725946 : check e1203530725946 [[],[]] .chain = true := by decide
def e1203530726030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1203530726030 : Closed e1203530726030 ∧ code e1203530726030 = 5601577237134 := by decide
theorem cert_e1203530726030 : check e1203530726030 [[],[]] .chain = true := by decide
def e1203530726086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1203530726086 : Closed e1203530726086 ∧ code e1203530726086 = 5601577237190 := by decide
theorem cert_e1203530726086 : check e1203530726086 [[],[]] .chain = true := by decide
def e1203530726170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1203530726170 : Closed e1203530726170 ∧ code e1203530726170 = 5601577237274 := by decide
theorem cert_e1203530726170 : check e1203530726170 [[],[]] .chain = true := by decide
def e1203530726214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1203530726214 : Closed e1203530726214 ∧ code e1203530726214 = 5601577237318 := by decide
theorem cert_e1203530726214 : check e1203530726214 [[],[]] .chain = true := by decide
def e1203530730734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1203530730734 : Closed e1203530730734 ∧ code e1203530730734 = 5601577241838 := by decide
theorem cert_e1203530730734 : check e1203530730734 [[],[]] .chain = true := by decide
def e1203530730742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1203530730742 : Closed e1203530730742 ∧ code e1203530730742 = 5601577241846 := by decide
theorem cert_e1203530730742 : check e1203530730742 [[],[]] .chain = true := by decide
def e1203530731118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1203530731118 : Closed e1203530731118 ∧ code e1203530731118 = 5601577242222 := by decide
theorem cert_e1203530731118 : check e1203530731118 [[],[]] .chain = true := by decide
def e1203530731130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1203530731130 : Closed e1203530731130 ∧ code e1203530731130 = 5601577242234 := by decide
theorem cert_e1203530731130 : check e1203530731130 [[],[]] .chain = true := by decide
def e1203530731318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1203530731318 : Closed e1203530731318 ∧ code e1203530731318 = 5601577242422 := by decide
theorem cert_e1203530731318 : check e1203530731318 [[],[]] .chain = true := by decide
def e1203530731322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1203530731322 : Closed e1203530731322 ∧ code e1203530731322 = 5601577242426 := by decide
theorem cert_e1203530731322 : check e1203530731322 [[],[]] .chain = true := by decide
def e1203530733806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1203530733806 : Closed e1203530733806 ∧ code e1203530733806 = 5601577244910 := by decide
theorem cert_e1203530733806 : check e1203530733806 [[],[]] .chain = true := by decide
def e1203530733814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1203530733814 : Closed e1203530733814 ∧ code e1203530733814 = 5601577244918 := by decide
theorem cert_e1203530733814 : check e1203530733814 [[],[]] .chain = true := by decide
def e1203530734366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1203530734366 : Closed e1203530734366 ∧ code e1203530734366 = 5601577245470 := by decide
theorem cert_e1203530734366 : check e1203530734366 [[],[]] .chain = true := by decide
def e1203530734478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1203530734478 : Closed e1203530734478 ∧ code e1203530734478 = 5601577245582 := by decide
theorem cert_e1203530734478 : check e1203530734478 [[],[]] .chain = true := by decide
def e1203530734702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1203530734702 : Closed e1203530734702 ∧ code e1203530734702 = 5601577245806 := by decide
theorem cert_e1203530734702 : check e1203530734702 [[],[]] .chain = true := by decide
def e1203530734714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1203530734714 : Closed e1203530734714 ∧ code e1203530734714 = 5601577245818 := by decide
theorem cert_e1203530734714 : check e1203530734714 [[],[]] .chain = true := by decide
def e1203530734878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1203530734878 : Closed e1203530734878 ∧ code e1203530734878 = 5601577245982 := by decide
theorem cert_e1203530734878 : check e1203530734878 [[],[]] .chain = true := by decide
def e1203530735046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1203530735046 : Closed e1203530735046 ∧ code e1203530735046 = 5601577246150 := by decide
theorem cert_e1203530735046 : check e1203530735046 [[],[]] .chain = true := by decide
def e1203530735158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1203530735158 : Closed e1203530735158 ∧ code e1203530735158 = 5601577246262 := by decide
theorem cert_e1203530735158 : check e1203530735158 [[],[]] .chain = true := by decide
def e1203530735162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1203530735162 : Closed e1203530735162 ∧ code e1203530735162 = 5601577246266 := by decide
theorem cert_e1203530735162 : check e1203530735162 [[],[]] .chain = true := by decide
def e1203530735246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1203530735246 : Closed e1203530735246 ∧ code e1203530735246 = 5601577246350 := by decide
theorem cert_e1203530735246 : check e1203530735246 [[],[]] .chain = true := by decide
def e1203530735302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1203530735302 : Closed e1203530735302 ∧ code e1203530735302 = 5601577246406 := by decide
theorem cert_e1203530735302 : check e1203530735302 [[],[]] .chain = true := by decide
def e1203530737438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1203530737438 : Closed e1203530737438 ∧ code e1203530737438 = 5601577248542 := by decide
theorem cert_e1203530737438 : check e1203530737438 [[],[]] .chain = true := by decide
def e1203530737550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1203530737550 : Closed e1203530737550 ∧ code e1203530737550 = 5601577248654 := by decide
theorem cert_e1203530737550 : check e1203530737550 [[],[]] .chain = true := by decide
def e1203530740510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1203530740510 : Closed e1203530740510 ∧ code e1203530740510 = 5601577251614 := by decide
theorem cert_e1203530740510 : check e1203530740510 [[],[]] .chain = true := by decide
def e1203530740678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1203530740678 : Closed e1203530740678 ∧ code e1203530740678 = 5601577251782 := by decide
theorem cert_e1203530740678 : check e1203530740678 [[],[]] .chain = true := by decide
def e1203530742158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1203530742158 : Closed e1203530742158 ∧ code e1203530742158 = 5601577253262 := by decide
theorem cert_e1203530742158 : check e1203530742158 [[],[]] .chain = true := by decide
def e1203530742214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1203530742214 : Closed e1203530742214 ∧ code e1203530742214 = 5601577253318 := by decide
theorem cert_e1203530742214 : check e1203530742214 [[],[]] .chain = true := by decide
def e1203530745454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1203530745454 : Closed e1203530745454 ∧ code e1203530745454 = 5601577256558 := by decide
theorem cert_e1203530745454 : check e1203530745454 [[],[]] .chain = true := by decide
def e1203530745466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1203530745466 : Closed e1203530745466 ∧ code e1203530745466 = 5601577256570 := by decide
theorem cert_e1203530745466 : check e1203530745466 [[],[]] .chain = true := by decide
def e1203530745754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1203530745754 : Closed e1203530745754 ∧ code e1203530745754 = 5601577256858 := by decide
theorem cert_e1203530745754 : check e1203530745754 [[],[]] .chain = true := by decide
def e1203530746990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1203530746990 : Closed e1203530746990 ∧ code e1203530746990 = 5601577258094 := by decide
theorem cert_e1203530746990 : check e1203530746990 [[],[]] .chain = true := by decide
def e1203530747002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1203530747002 : Closed e1203530747002 ∧ code e1203530747002 = 5601577258106 := by decide
theorem cert_e1203530747002 : check e1203530747002 [[],[]] .chain = true := by decide
def e1203530747166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1203530747166 : Closed e1203530747166 ∧ code e1203530747166 = 5601577258270 := by decide
theorem cert_e1203530747166 : check e1203530747166 [[],[]] .chain = true := by decide
def e1203530747334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1203530747334 : Closed e1203530747334 ∧ code e1203530747334 = 5601577258438 := by decide
theorem cert_e1203530747334 : check e1203530747334 [[],[]] .chain = true := by decide
def e1203530747674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1203530747674 : Closed e1203530747674 ∧ code e1203530747674 = 5601577258778 := by decide
theorem cert_e1203530747674 : check e1203530747674 [[],[]] .chain = true := by decide
def e1203530747718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1203530747718 : Closed e1203530747718 ∧ code e1203530747718 = 5601577258822 := by decide
theorem cert_e1203530747718 : check e1203530747718 [[],[]] .chain = true := by decide
def e1203530748702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1203530748702 : Closed e1203530748702 ∧ code e1203530748702 = 5601577259806 := by decide
theorem cert_e1203530748702 : check e1203530748702 [[],[]] .chain = true := by decide
def e1203530748870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1203530748870 : Closed e1203530748870 ∧ code e1203530748870 = 5601577259974 := by decide
theorem cert_e1203530748870 : check e1203530748870 [[],[]] .chain = true := by decide
def e1203530751174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203530751174 : Closed e1203530751174 ∧ code e1203530751174 = 5601577262278 := by decide
theorem cert_e1203530751174 : check e1203530751174 [[],[]] .chain = true := by decide
def e1203530752822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1203530752822 : Closed e1203530752822 ∧ code e1203530752822 = 5601577263926 := by decide
theorem cert_e1203530752822 : check e1203530752822 [[],[]] .chain = true := by decide
def e1203530752826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1203530752826 : Closed e1203530752826 ∧ code e1203530752826 = 5601577263930 := by decide
theorem cert_e1203530752826 : check e1203530752826 [[],[]] .chain = true := by decide
def e1203530752922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1203530752922 : Closed e1203530752922 ∧ code e1203530752922 = 5601577264026 := by decide
theorem cert_e1203530752922 : check e1203530752922 [[],[]] .chain = true := by decide
def e1203530753590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1203530753590 : Closed e1203530753590 ∧ code e1203530753590 = 5601577264694 := by decide
theorem cert_e1203530753590 : check e1203530753590 [[],[]] .chain = true := by decide
def e1203530753594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1203530753594 : Closed e1203530753594 ∧ code e1203530753594 = 5601577264698 := by decide
theorem cert_e1203530753594 : check e1203530753594 [[],[]] .chain = true := by decide
def e1203530753678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1203530753678 : Closed e1203530753678 ∧ code e1203530753678 = 5601577264782 := by decide
theorem cert_e1203530753678 : check e1203530753678 [[],[]] .chain = true := by decide
def e1203530753734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1203530753734 : Closed e1203530753734 ∧ code e1203530753734 = 5601577264838 := by decide
theorem cert_e1203530753734 : check e1203530753734 [[],[]] .chain = true := by decide
def e1203530753818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1203530753818 : Closed e1203530753818 ∧ code e1203530753818 = 5601577264922 := by decide
theorem cert_e1203530753818 : check e1203530753818 [[],[]] .chain = true := by decide
def e1203530753862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1203530753862 : Closed e1203530753862 ∧ code e1203530753862 = 5601577264966 := by decide
theorem cert_e1203530753862 : check e1203530753862 [[],[]] .chain = true := by decide
def e1203530754446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1203530754446 : Closed e1203530754446 ∧ code e1203530754446 = 5601577265550 := by decide
theorem cert_e1203530754446 : check e1203530754446 [[],[]] .chain = true := by decide
def e1203530754502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1203530754502 : Closed e1203530754502 ∧ code e1203530754502 = 5601577265606 := by decide
theorem cert_e1203530754502 : check e1203530754502 [[],[]] .chain = true := by decide
def e1203530755270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203530755270 : Closed e1203530755270 ∧ code e1203530755270 = 5601577266374 := by decide
theorem cert_e1203530755270 : check e1203530755270 [[],[]] .chain = true := by decide
def e1203530766046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1203530766046 : Closed e1203530766046 ∧ code e1203530766046 = 5601577277150 := by decide
theorem cert_e1203530766046 : check e1203530766046 [[],[]] .chain = true := by decide
def e1203530766070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1203530766070 : Closed e1203530766070 ∧ code e1203530766070 = 5601577277174 := by decide
theorem cert_e1203530766070 : check e1203530766070 [[],[]] .chain = true := by decide
def e1203530766174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1203530766174 : Closed e1203530766174 ∧ code e1203530766174 = 5601577277278 := by decide
theorem cert_e1203530766174 : check e1203530766174 [[],[]] .chain = true := by decide
def e1203530766202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1203530766202 : Closed e1203530766202 ∧ code e1203530766202 = 5601577277306 := by decide
theorem cert_e1203530766202 : check e1203530766202 [[],[]] .chain = true := by decide
def e1203530766294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1203530766294 : Closed e1203530766294 ∧ code e1203530766294 = 5601577277398 := by decide
theorem cert_e1203530766294 : check e1203530766294 [[],[]] .chain = true := by decide
def e1203530766298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1203530766298 : Closed e1203530766298 ∧ code e1203530766298 = 5601577277402 := by decide
theorem cert_e1203530766298 : check e1203530766298 [[],[]] .chain = true := by decide
def e1203530766814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1203530766814 : Closed e1203530766814 ∧ code e1203530766814 = 5601577277918 := by decide
theorem cert_e1203530766814 : check e1203530766814 [[],[]] .chain = true := by decide
def e1203530766838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1203530766838 : Closed e1203530766838 ∧ code e1203530766838 = 5601577277942 := by decide
theorem cert_e1203530766838 : check e1203530766838 [[],[]] .chain = true := by decide
def e1203530767582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1203530767582 : Closed e1203530767582 ∧ code e1203530767582 = 5601577278686 := by decide
theorem cert_e1203530767582 : check e1203530767582 [[],[]] .chain = true := by decide
def e1203530767610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1203530767610 : Closed e1203530767610 ∧ code e1203530767610 = 5601577278714 := by decide
theorem cert_e1203530767610 : check e1203530767610 [[],[]] .chain = true := by decide
def e1203530768182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203530768182 : Closed e1203530768182 ∧ code e1203530768182 = 5601577279286 := by decide
theorem cert_e1203530768182 : check e1203530768182 [[],[]] .chain = true := by decide
def e1203530768186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203530768186 : Closed e1203530768186 ∧ code e1203530768186 = 5601577279290 := by decide
theorem cert_e1203530768186 : check e1203530768186 [[],[]] .chain = true := by decide
def e1203530782958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1203530782958 : Closed e1203530782958 ∧ code e1203530782958 = 5601577294062 := by decide
theorem cert_e1203530782958 : check e1203530782958 [[],[]] .chain = true := by decide
def e1203530782966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1203530782966 : Closed e1203530782966 ∧ code e1203530782966 = 5601577294070 := by decide
theorem cert_e1203530782966 : check e1203530782966 [[],[]] .chain = true := by decide
def e1203530783518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1203530783518 : Closed e1203530783518 ∧ code e1203530783518 = 5601577294622 := by decide
theorem cert_e1203530783518 : check e1203530783518 [[],[]] .chain = true := by decide
def e1203530783630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1203530783630 : Closed e1203530783630 ∧ code e1203530783630 = 5601577294734 := by decide
theorem cert_e1203530783630 : check e1203530783630 [[],[]] .chain = true := by decide
def e1203530783854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1203530783854 : Closed e1203530783854 ∧ code e1203530783854 = 5601577294958 := by decide
theorem cert_e1203530783854 : check e1203530783854 [[],[]] .chain = true := by decide
def e1203530783866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1203530783866 : Closed e1203530783866 ∧ code e1203530783866 = 5601577294970 := by decide
theorem cert_e1203530783866 : check e1203530783866 [[],[]] .chain = true := by decide
def e1203530784030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1203530784030 : Closed e1203530784030 ∧ code e1203530784030 = 5601577295134 := by decide
theorem cert_e1203530784030 : check e1203530784030 [[],[]] .chain = true := by decide
def e1203530784198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1203530784198 : Closed e1203530784198 ∧ code e1203530784198 = 5601577295302 := by decide
theorem cert_e1203530784198 : check e1203530784198 [[],[]] .chain = true := by decide
def e1203530784310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1203530784310 : Closed e1203530784310 ∧ code e1203530784310 = 5601577295414 := by decide
theorem cert_e1203530784310 : check e1203530784310 [[],[]] .chain = true := by decide
def e1203530784314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1203530784314 : Closed e1203530784314 ∧ code e1203530784314 = 5601577295418 := by decide
theorem cert_e1203530784314 : check e1203530784314 [[],[]] .chain = true := by decide
def e1203530784398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1203530784398 : Closed e1203530784398 ∧ code e1203530784398 = 5601577295502 := by decide
theorem cert_e1203530784398 : check e1203530784398 [[],[]] .chain = true := by decide
def e1203530784454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1203530784454 : Closed e1203530784454 ∧ code e1203530784454 = 5601577295558 := by decide
theorem cert_e1203530784454 : check e1203530784454 [[],[]] .chain = true := by decide
def e1203530786590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1203530786590 : Closed e1203530786590 ∧ code e1203530786590 = 5601577297694 := by decide
theorem cert_e1203530786590 : check e1203530786590 [[],[]] .chain = true := by decide
def e1203530786702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1203530786702 : Closed e1203530786702 ∧ code e1203530786702 = 5601577297806 := by decide
theorem cert_e1203530786702 : check e1203530786702 [[],[]] .chain = true := by decide
def e1203530789662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1203530789662 : Closed e1203530789662 ∧ code e1203530789662 = 5601577300766 := by decide
theorem cert_e1203530789662 : check e1203530789662 [[],[]] .chain = true := by decide
def e1203530789830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1203530789830 : Closed e1203530789830 ∧ code e1203530789830 = 5601577300934 := by decide
theorem cert_e1203530789830 : check e1203530789830 [[],[]] .chain = true := by decide
def e1203530791310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1203530791310 : Closed e1203530791310 ∧ code e1203530791310 = 5601577302414 := by decide
theorem cert_e1203530791310 : check e1203530791310 [[],[]] .chain = true := by decide
def e1203530791366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1203530791366 : Closed e1203530791366 ∧ code e1203530791366 = 5601577302470 := by decide
theorem cert_e1203530791366 : check e1203530791366 [[],[]] .chain = true := by decide
def e1203530828654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1203530828654 : Closed e1203530828654 ∧ code e1203530828654 = 5601577339758 := by decide
theorem cert_e1203530828654 : check e1203530828654 [[],[]] .smaller = true := by decide
def e1203530828662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1203530828662 : Closed e1203530828662 ∧ code e1203530828662 = 5601577339766 := by decide
theorem cert_e1203530828662 : check e1203530828662 [[],[]] .smaller = true := by decide
def e1203530828718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1203530828718 : Closed e1203530828718 ∧ code e1203530828718 = 5601577339822 := by decide
theorem cert_e1203530828718 : check e1203530828718 [[],[]] .smaller = true := by decide
def e1203530828730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1203530828730 : Closed e1203530828730 ∧ code e1203530828730 = 5601577339834 := by decide
theorem cert_e1203530828730 : check e1203530828730 [[],[]] .smaller = true := by decide
def e1203530828758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1203530828758 : Closed e1203530828758 ∧ code e1203530828758 = 5601577339862 := by decide
theorem cert_e1203530828758 : check e1203530828758 [[],[]] .smaller = true := by decide
def e1203530828762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1203530828762 : Closed e1203530828762 ∧ code e1203530828762 = 5601577339866 := by decide
theorem cert_e1203530828762 : check e1203530828762 [[],[]] .smaller = true := by decide
def e1203530829038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1203530829038 : Closed e1203530829038 ∧ code e1203530829038 = 5601577340142 := by decide
theorem cert_e1203530829038 : check e1203530829038 [[],[]] .smaller = true := by decide
def e1203530829046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1203530829046 : Closed e1203530829046 ∧ code e1203530829046 = 5601577340150 := by decide
theorem cert_e1203530829046 : check e1203530829046 [[],[]] .smaller = true := by decide
def e1203530829422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1203530829422 : Closed e1203530829422 ∧ code e1203530829422 = 5601577340526 := by decide
theorem cert_e1203530829422 : check e1203530829422 [[],[]] .smaller = true := by decide
def e1203530829434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1203530829434 : Closed e1203530829434 ∧ code e1203530829434 = 5601577340538 := by decide
theorem cert_e1203530829434 : check e1203530829434 [[],[]] .smaller = true := by decide
def e1203530829622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203530829622 : Closed e1203530829622 ∧ code e1203530829622 = 5601577340726 := by decide
theorem cert_e1203530829622 : check e1203530829622 [[],[]] .smaller = true := by decide
def e1203530829626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203530829626 : Closed e1203530829626 ∧ code e1203530829626 = 5601577340730 := by decide
theorem cert_e1203530829626 : check e1203530829626 [[],[]] .smaller = true := by decide
def e1203530837102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1203530837102 : Closed e1203530837102 ∧ code e1203530837102 = 5601577348206 := by decide
theorem cert_e1203530837102 : check e1203530837102 [[],[]] .chain = true := by decide
def e1203530837114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1203530837114 : Closed e1203530837114 ∧ code e1203530837114 = 5601577348218 := by decide
theorem cert_e1203530837114 : check e1203530837114 [[],[]] .chain = true := by decide
def e1203530837278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1203530837278 : Closed e1203530837278 ∧ code e1203530837278 = 5601577348382 := by decide
theorem cert_e1203530837278 : check e1203530837278 [[],[]] .chain = true := by decide
def e1203530837446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1203530837446 : Closed e1203530837446 ∧ code e1203530837446 = 5601577348550 := by decide
theorem cert_e1203530837446 : check e1203530837446 [[],[]] .chain = true := by decide
def e1203530837786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1203530837786 : Closed e1203530837786 ∧ code e1203530837786 = 5601577348890 := by decide
theorem cert_e1203530837786 : check e1203530837786 [[],[]] .chain = true := by decide
def e1203530837830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1203530837830 : Closed e1203530837830 ∧ code e1203530837830 = 5601577348934 := by decide
theorem cert_e1203530837830 : check e1203530837830 [[],[]] .chain = true := by decide
def e1203530838814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1203530838814 : Closed e1203530838814 ∧ code e1203530838814 = 5601577349918 := by decide
theorem cert_e1203530838814 : check e1203530838814 [[],[]] .chain = true := by decide
def e1203530838982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1203530838982 : Closed e1203530838982 ∧ code e1203530838982 = 5601577350086 := by decide
theorem cert_e1203530838982 : check e1203530838982 [[],[]] .chain = true := by decide
def e1203530841286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1203530841286 : Closed e1203530841286 ∧ code e1203530841286 = 5601577352390 := by decide
theorem cert_e1203530841286 : check e1203530841286 [[],[]] .chain = true := by decide
def e1203530864182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1203530864182 : Closed e1203530864182 ∧ code e1203530864182 = 5601577375286 := by decide
theorem cert_e1203530864182 : check e1203530864182 [[],[]] .chain = true := by decide
def e1203530864186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1203530864186 : Closed e1203530864186 ∧ code e1203530864186 = 5601577375290 := by decide
theorem cert_e1203530864186 : check e1203530864186 [[],[]] .chain = true := by decide
def e1203530864270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1203530864270 : Closed e1203530864270 ∧ code e1203530864270 = 5601577375374 := by decide
theorem cert_e1203530864270 : check e1203530864270 [[],[]] .chain = true := by decide
def e1203530864326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1203530864326 : Closed e1203530864326 ∧ code e1203530864326 = 5601577375430 := by decide
theorem cert_e1203530864326 : check e1203530864326 [[],[]] .chain = true := by decide
def e1203530864410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1203530864410 : Closed e1203530864410 ∧ code e1203530864410 = 5601577375514 := by decide
theorem cert_e1203530864410 : check e1203530864410 [[],[]] .chain = true := by decide
def e1203530864454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1203530864454 : Closed e1203530864454 ∧ code e1203530864454 = 5601577375558 := by decide
theorem cert_e1203530864454 : check e1203530864454 [[],[]] .chain = true := by decide
def e1203530865038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1203530865038 : Closed e1203530865038 ∧ code e1203530865038 = 5601577376142 := by decide
theorem cert_e1203530865038 : check e1203530865038 [[],[]] .chain = true := by decide
def e1203530865094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1203530865094 : Closed e1203530865094 ∧ code e1203530865094 = 5601577376198 := by decide
theorem cert_e1203530865094 : check e1203530865094 [[],[]] .chain = true := by decide
def e1203530865862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1203530865862 : Closed e1203530865862 ∧ code e1203530865862 = 5601577376966 := by decide
theorem cert_e1203530865862 : check e1203530865862 [[],[]] .chain = true := by decide
def e1203531962606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1203531962606 : Closed e1203531962606 ∧ code e1203531962606 = 5601578473710 := by decide
theorem cert_e1203531962606 : check e1203531962606 [[],[]] .chain = true := by decide
def e1203531962614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1203531962614 : Closed e1203531962614 ∧ code e1203531962614 = 5601578473718 := by decide
theorem cert_e1203531962614 : check e1203531962614 [[],[]] .chain = true := by decide
def e1203531963166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1203531963166 : Closed e1203531963166 ∧ code e1203531963166 = 5601578474270 := by decide
theorem cert_e1203531963166 : check e1203531963166 [[],[]] .chain = true := by decide
def e1203531963278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1203531963278 : Closed e1203531963278 ∧ code e1203531963278 = 5601578474382 := by decide
theorem cert_e1203531963278 : check e1203531963278 [[],[]] .chain = true := by decide
def e1203531963502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1203531963502 : Closed e1203531963502 ∧ code e1203531963502 = 5601578474606 := by decide
theorem cert_e1203531963502 : check e1203531963502 [[],[]] .chain = true := by decide
def e1203531963514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1203531963514 : Closed e1203531963514 ∧ code e1203531963514 = 5601578474618 := by decide
theorem cert_e1203531963514 : check e1203531963514 [[],[]] .chain = true := by decide
def e1203531963678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1203531963678 : Closed e1203531963678 ∧ code e1203531963678 = 5601578474782 := by decide
theorem cert_e1203531963678 : check e1203531963678 [[],[]] .chain = true := by decide
def e1203531963846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1203531963846 : Closed e1203531963846 ∧ code e1203531963846 = 5601578474950 := by decide
theorem cert_e1203531963846 : check e1203531963846 [[],[]] .chain = true := by decide
def e1203531963958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1203531963958 : Closed e1203531963958 ∧ code e1203531963958 = 5601578475062 := by decide
theorem cert_e1203531963958 : check e1203531963958 [[],[]] .chain = true := by decide
def e1203531963962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1203531963962 : Closed e1203531963962 ∧ code e1203531963962 = 5601578475066 := by decide
theorem cert_e1203531963962 : check e1203531963962 [[],[]] .chain = true := by decide
end Blc.Floor42
