import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131188538330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1131188538330 : Closed e1131188538330 ∧ code e1131188538330 = 5529235049434 := by decide
theorem cert_e1131188538330 : check e1131188538330 [[],[.under]] .three = true := by decide
def e1131188538606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1131188538606 : Closed e1131188538606 ∧ code e1131188538606 = 5529235049710 := by decide
theorem cert_e1131188538606 : check e1131188538606 [[],[.under]] .three = true := by decide
def e1131188538614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1131188538614 : Closed e1131188538614 ∧ code e1131188538614 = 5529235049718 := by decide
theorem cert_e1131188538614 : check e1131188538614 [[],[.under]] .three = true := by decide
def e1131188538990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1131188538990 : Closed e1131188538990 ∧ code e1131188538990 = 5529235050094 := by decide
theorem cert_e1131188538990 : check e1131188538990 [[],[.under]] .three = true := by decide
def e1131188539002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1131188539002 : Closed e1131188539002 ∧ code e1131188539002 = 5529235050106 := by decide
theorem cert_e1131188539002 : check e1131188539002 [[],[.under]] .three = true := by decide
def e1131188539166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1131188539166 : Closed e1131188539166 ∧ code e1131188539166 = 5529235050270 := by decide
theorem cert_e1131188539166 : check e1131188539166 [[],[.under]] .three = true := by decide
def e1131188539190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188539190 : Closed e1131188539190 ∧ code e1131188539190 = 5529235050294 := by decide
theorem cert_e1131188539190 : check e1131188539190 [[],[.under]] .three = true := by decide
def e1131188539194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188539194 : Closed e1131188539194 ∧ code e1131188539194 = 5529235050298 := by decide
theorem cert_e1131188539194 : check e1131188539194 [[],[.under]] .three = true := by decide
def e1131188543966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1131188543966 : Closed e1131188543966 ∧ code e1131188543966 = 5529235055070 := by decide
theorem cert_e1131188543966 : check e1131188543966 [[],[.under]] .three = true := by decide
def e1131188543990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1131188543990 : Closed e1131188543990 ∧ code e1131188543990 = 5529235055094 := by decide
theorem cert_e1131188543990 : check e1131188543990 [[],[.under]] .three = true := by decide
def e1131188544942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1131188544942 : Closed e1131188544942 ∧ code e1131188544942 = 5529235056046 := by decide
theorem cert_e1131188544942 : check e1131188544942 [[],[.under]] .three = true := by decide
def e1131188544954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1131188544954 : Closed e1131188544954 ∧ code e1131188544954 = 5529235056058 := by decide
theorem cert_e1131188544954 : check e1131188544954 [[],[.under]] .three = true := by decide
def e1131188545002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1131188545002 : Closed e1131188545002 ∧ code e1131188545002 = 5529235056106 := by decide
theorem cert_e1131188545002 : check e1131188545002 [[],[.under]] .three = true := by decide
def e1131188545134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1131188545134 : Closed e1131188545134 ∧ code e1131188545134 = 5529235056238 := by decide
theorem cert_e1131188545134 : check e1131188545134 [[],[.under]] .three = true := by decide
def e1131188545146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1131188545146 : Closed e1131188545146 ∧ code e1131188545146 = 5529235056250 := by decide
theorem cert_e1131188545146 : check e1131188545146 [[],[.under]] .three = true := by decide
def e1131188545434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1131188545434 : Closed e1131188545434 ∧ code e1131188545434 = 5529235056538 := by decide
theorem cert_e1131188545434 : check e1131188545434 [[],[.under]] .three = true := by decide
def e1131188547822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1131188547822 : Closed e1131188547822 ∧ code e1131188547822 = 5529235058926 := by decide
theorem cert_e1131188547822 : check e1131188547822 [[],[.under]] .three = true := by decide
def e1131188547830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1131188547830 : Closed e1131188547830 ∧ code e1131188547830 = 5529235058934 := by decide
theorem cert_e1131188547830 : check e1131188547830 [[],[.under]] .three = true := by decide
def e1131188548310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1131188548310 : Closed e1131188548310 ∧ code e1131188548310 = 5529235059414 := by decide
theorem cert_e1131188548310 : check e1131188548310 [[],[.under]] .three = true := by decide
def e1131188548314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1131188548314 : Closed e1131188548314 ∧ code e1131188548314 = 5529235059418 := by decide
theorem cert_e1131188548314 : check e1131188548314 [[],[.under]] .three = true := by decide
def e1131188548330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1131188548330 : Closed e1131188548330 ∧ code e1131188548330 = 5529235059434 := by decide
theorem cert_e1131188548330 : check e1131188548330 [[],[.under]] .three = true := by decide
def e1131188548382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1131188548382 : Closed e1131188548382 ∧ code e1131188548382 = 5529235059486 := by decide
theorem cert_e1131188548382 : check e1131188548382 [[],[.under]] .three = true := by decide
def e1131188548406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188548406 : Closed e1131188548406 ∧ code e1131188548406 = 5529235059510 := by decide
theorem cert_e1131188548406 : check e1131188548406 [[],[.under]] .three = true := by decide
def e1131188548410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188548410 : Closed e1131188548410 ∧ code e1131188548410 = 5529235059514 := by decide
theorem cert_e1131188548410 : check e1131188548410 [[],[.under]] .three = true := by decide
def e1131188548506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1131188548506 : Closed e1131188548506 ∧ code e1131188548506 = 5529235059610 := by decide
theorem cert_e1131188548506 : check e1131188548506 [[],[.under]] .three = true := by decide
def e1131188548550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1131188548550 : Closed e1131188548550 ∧ code e1131188548550 = 5529235059654 := by decide
theorem cert_e1131188548550 : check e1131188548550 [[],[.under]] .three = true := by decide
def e1131188553590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1131188553590 : Closed e1131188553590 ∧ code e1131188553590 = 5529235064694 := by decide
theorem cert_e1131188553590 : check e1131188553590 [[],[.under]] .three = true := by decide
def e1131188553654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1131188553654 : Closed e1131188553654 ∧ code e1131188553654 = 5529235064758 := by decide
theorem cert_e1131188553654 : check e1131188553654 [[],[.under]] .three = true := by decide
def e1131188553658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1131188553658 : Closed e1131188553658 ∧ code e1131188553658 = 5529235064762 := by decide
theorem cert_e1131188553658 : check e1131188553658 [[],[.under]] .three = true := by decide
def e1131188554990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188554990 : Closed e1131188554990 ∧ code e1131188554990 = 5529235066094 := by decide
theorem cert_e1131188554990 : check e1131188554990 [[],[.under]] .three = true := by decide
def e1131188554998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188554998 : Closed e1131188554998 ∧ code e1131188554998 = 5529235066102 := by decide
theorem cert_e1131188554998 : check e1131188554998 [[],[.under]] .three = true := by decide
def e1131188555374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188555374 : Closed e1131188555374 ∧ code e1131188555374 = 5529235066478 := by decide
theorem cert_e1131188555374 : check e1131188555374 [[],[.under]] .three = true := by decide
def e1131188555386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188555386 : Closed e1131188555386 ∧ code e1131188555386 = 5529235066490 := by decide
theorem cert_e1131188555386 : check e1131188555386 [[],[.under]] .three = true := by decide
def e1131188555574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188555574 : Closed e1131188555574 ∧ code e1131188555574 = 5529235066678 := by decide
theorem cert_e1131188555574 : check e1131188555574 [[],[.under]] .three = true := by decide
def e1131188555578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188555578 : Closed e1131188555578 ∧ code e1131188555578 = 5529235066682 := by decide
theorem cert_e1131188555578 : check e1131188555578 [[],[.under]] .three = true := by decide
def e1131188557494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1131188557494 : Closed e1131188557494 ∧ code e1131188557494 = 5529235068598 := by decide
theorem cert_e1131188557494 : check e1131188557494 [[],[.under]] .three = true := by decide
def e1131188557526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1131188557526 : Closed e1131188557526 ∧ code e1131188557526 = 5529235068630 := by decide
theorem cert_e1131188557526 : check e1131188557526 [[],[.under]] .three = true := by decide
def e1131188557530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1131188557530 : Closed e1131188557530 ∧ code e1131188557530 = 5529235068634 := by decide
theorem cert_e1131188557530 : check e1131188557530 [[],[.under]] .three = true := by decide
def e1131188557654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1131188557654 : Closed e1131188557654 ∧ code e1131188557654 = 5529235068758 := by decide
theorem cert_e1131188557654 : check e1131188557654 [[],[.under]] .three = true := by decide
def e1131188557658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1131188557658 : Closed e1131188557658 ∧ code e1131188557658 = 5529235068762 := by decide
theorem cert_e1131188557658 : check e1131188557658 [[],[.under]] .three = true := by decide
def e1131188557674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1131188557674 : Closed e1131188557674 ∧ code e1131188557674 = 5529235068778 := by decide
theorem cert_e1131188557674 : check e1131188557674 [[],[.under]] .three = true := by decide
def e1131188558062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1131188558062 : Closed e1131188558062 ∧ code e1131188558062 = 5529235069166 := by decide
theorem cert_e1131188558062 : check e1131188558062 [[],[.under]] .three = true := by decide
def e1131188558070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1131188558070 : Closed e1131188558070 ∧ code e1131188558070 = 5529235069174 := by decide
theorem cert_e1131188558070 : check e1131188558070 [[],[.under]] .three = true := by decide
def e1131188558262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1131188558262 : Closed e1131188558262 ∧ code e1131188558262 = 5529235069366 := by decide
theorem cert_e1131188558262 : check e1131188558262 [[],[.under]] .three = true := by decide
def e1131188558294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1131188558294 : Closed e1131188558294 ∧ code e1131188558294 = 5529235069398 := by decide
theorem cert_e1131188558294 : check e1131188558294 [[],[.under]] .three = true := by decide
def e1131188558298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1131188558298 : Closed e1131188558298 ∧ code e1131188558298 = 5529235069402 := by decide
theorem cert_e1131188558298 : check e1131188558298 [[],[.under]] .three = true := by decide
def e1131188558454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1131188558454 : Closed e1131188558454 ∧ code e1131188558454 = 5529235069558 := by decide
theorem cert_e1131188558454 : check e1131188558454 [[],[.under]] .three = true := by decide
def e1131188558622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1131188558622 : Closed e1131188558622 ∧ code e1131188558622 = 5529235069726 := by decide
theorem cert_e1131188558622 : check e1131188558622 [[],[.under]] .three = true := by decide
def e1131188558646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188558646 : Closed e1131188558646 ∧ code e1131188558646 = 5529235069750 := by decide
theorem cert_e1131188558646 : check e1131188558646 [[],[.under]] .three = true := by decide
def e1131188558650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188558650 : Closed e1131188558650 ∧ code e1131188558650 = 5529235069754 := by decide
theorem cert_e1131188558650 : check e1131188558650 [[],[.under]] .three = true := by decide
def e1131188558734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1131188558734 : Closed e1131188558734 ∧ code e1131188558734 = 5529235069838 := by decide
theorem cert_e1131188558734 : check e1131188558734 [[],[.under]] .three = true := by decide
def e1131188558958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1131188558958 : Closed e1131188558958 ∧ code e1131188558958 = 5529235070062 := by decide
theorem cert_e1131188558958 : check e1131188558958 [[],[.under]] .three = true := by decide
def e1131188558970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1131188558970 : Closed e1131188558970 ∧ code e1131188558970 = 5529235070074 := by decide
theorem cert_e1131188558970 : check e1131188558970 [[],[.under]] .three = true := by decide
def e1131188559062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1131188559062 : Closed e1131188559062 ∧ code e1131188559062 = 5529235070166 := by decide
theorem cert_e1131188559062 : check e1131188559062 [[],[.under]] .three = true := by decide
def e1131188559066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1131188559066 : Closed e1131188559066 ∧ code e1131188559066 = 5529235070170 := by decide
theorem cert_e1131188559066 : check e1131188559066 [[],[.under]] .three = true := by decide
def e1131188559082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1131188559082 : Closed e1131188559082 ∧ code e1131188559082 = 5529235070186 := by decide
theorem cert_e1131188559082 : check e1131188559082 [[],[.under]] .three = true := by decide
def e1131188559134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1131188559134 : Closed e1131188559134 ∧ code e1131188559134 = 5529235070238 := by decide
theorem cert_e1131188559134 : check e1131188559134 [[],[.under]] .three = true := by decide
def e1131188559158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188559158 : Closed e1131188559158 ∧ code e1131188559158 = 5529235070262 := by decide
theorem cert_e1131188559158 : check e1131188559158 [[],[.under]] .three = true := by decide
def e1131188559162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188559162 : Closed e1131188559162 ∧ code e1131188559162 = 5529235070266 := by decide
theorem cert_e1131188559162 : check e1131188559162 [[],[.under]] .three = true := by decide
def e1131188559258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1131188559258 : Closed e1131188559258 ∧ code e1131188559258 = 5529235070362 := by decide
theorem cert_e1131188559258 : check e1131188559258 [[],[.under]] .three = true := by decide
def e1131188559302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1131188559302 : Closed e1131188559302 ∧ code e1131188559302 = 5529235070406 := by decide
theorem cert_e1131188559302 : check e1131188559302 [[],[.under]] .three = true := by decide
def e1131188559414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1131188559414 : Closed e1131188559414 ∧ code e1131188559414 = 5529235070518 := by decide
theorem cert_e1131188559414 : check e1131188559414 [[],[.under]] .three = true := by decide
def e1131188559418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1131188559418 : Closed e1131188559418 ∧ code e1131188559418 = 5529235070522 := by decide
theorem cert_e1131188559418 : check e1131188559418 [[],[.under]] .three = true := by decide
def e1131188559502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1131188559502 : Closed e1131188559502 ∧ code e1131188559502 = 5529235070606 := by decide
theorem cert_e1131188559502 : check e1131188559502 [[],[.under]] .three = true := by decide
def e1131188559558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1131188559558 : Closed e1131188559558 ∧ code e1131188559558 = 5529235070662 := by decide
theorem cert_e1131188559558 : check e1131188559558 [[],[.under]] .three = true := by decide
def e1131188560366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1131188560366 : Closed e1131188560366 ∧ code e1131188560366 = 5529235071470 := by decide
theorem cert_e1131188560366 : check e1131188560366 [[],[.under]] .three = true := by decide
def e1131188561334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1131188561334 : Closed e1131188561334 ∧ code e1131188561334 = 5529235072438 := by decide
theorem cert_e1131188561334 : check e1131188561334 [[],[.under]] .three = true := by decide
def e1131188561366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1131188561366 : Closed e1131188561366 ∧ code e1131188561366 = 5529235072470 := by decide
theorem cert_e1131188561366 : check e1131188561366 [[],[.under]] .three = true := by decide
def e1131188561370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1131188561370 : Closed e1131188561370 ∧ code e1131188561370 = 5529235072474 := by decide
theorem cert_e1131188561370 : check e1131188561370 [[],[.under]] .three = true := by decide
def e1131188561526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1131188561526 : Closed e1131188561526 ∧ code e1131188561526 = 5529235072630 := by decide
theorem cert_e1131188561526 : check e1131188561526 [[],[.under]] .three = true := by decide
def e1131188561694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1131188561694 : Closed e1131188561694 ∧ code e1131188561694 = 5529235072798 := by decide
theorem cert_e1131188561694 : check e1131188561694 [[],[.under]] .three = true := by decide
def e1131188561718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188561718 : Closed e1131188561718 ∧ code e1131188561718 = 5529235072822 := by decide
theorem cert_e1131188561718 : check e1131188561718 [[],[.under]] .three = true := by decide
def e1131188561722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188561722 : Closed e1131188561722 ∧ code e1131188561722 = 5529235072826 := by decide
theorem cert_e1131188561722 : check e1131188561722 [[],[.under]] .three = true := by decide
def e1131188561806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1131188561806 : Closed e1131188561806 ∧ code e1131188561806 = 5529235072910 := by decide
theorem cert_e1131188561806 : check e1131188561806 [[],[.under]] .three = true := by decide
def e1131188564206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1131188564206 : Closed e1131188564206 ∧ code e1131188564206 = 5529235075310 := by decide
theorem cert_e1131188564206 : check e1131188564206 [[],[.under]] .three = true := by decide
def e1131188564214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1131188564214 : Closed e1131188564214 ∧ code e1131188564214 = 5529235075318 := by decide
theorem cert_e1131188564214 : check e1131188564214 [[],[.under]] .three = true := by decide
def e1131188564694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1131188564694 : Closed e1131188564694 ∧ code e1131188564694 = 5529235075798 := by decide
theorem cert_e1131188564694 : check e1131188564694 [[],[.under]] .three = true := by decide
def e1131188564698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1131188564698 : Closed e1131188564698 ∧ code e1131188564698 = 5529235075802 := by decide
theorem cert_e1131188564698 : check e1131188564698 [[],[.under]] .three = true := by decide
def e1131188564714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1131188564714 : Closed e1131188564714 ∧ code e1131188564714 = 5529235075818 := by decide
theorem cert_e1131188564714 : check e1131188564714 [[],[.under]] .three = true := by decide
def e1131188564766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1131188564766 : Closed e1131188564766 ∧ code e1131188564766 = 5529235075870 := by decide
theorem cert_e1131188564766 : check e1131188564766 [[],[.under]] .three = true := by decide
def e1131188564790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188564790 : Closed e1131188564790 ∧ code e1131188564790 = 5529235075894 := by decide
theorem cert_e1131188564790 : check e1131188564790 [[],[.under]] .three = true := by decide
def e1131188564794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188564794 : Closed e1131188564794 ∧ code e1131188564794 = 5529235075898 := by decide
theorem cert_e1131188564794 : check e1131188564794 [[],[.under]] .three = true := by decide
def e1131188564890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1131188564890 : Closed e1131188564890 ∧ code e1131188564890 = 5529235075994 := by decide
theorem cert_e1131188564890 : check e1131188564890 [[],[.under]] .three = true := by decide
def e1131188564934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1131188564934 : Closed e1131188564934 ∧ code e1131188564934 = 5529235076038 := by decide
theorem cert_e1131188564934 : check e1131188564934 [[],[.under]] .three = true := by decide
def e1131188566414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1131188566414 : Closed e1131188566414 ∧ code e1131188566414 = 5529235077518 := by decide
private def t_e1131188566414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e1131188566414 : ¬ IsSelfInterpreter e1131188566414 :=
  wSource (t := t_e1131188566414) (replay_sound (ps := []) (t := e1131188566414) (by decide)) (by decide)
def e1131188566470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1131188566470 : Closed e1131188566470 ∧ code e1131188566470 = 5529235077574 := by decide
private def t_e1131188566470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e1131188566470 : ¬ IsSelfInterpreter e1131188566470 :=
  wSource (t := t_e1131188566470) (replay_sound (ps := []) (t := e1131188566470) (by decide)) (by decide)
def e1131188607214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1131188607214 : Closed e1131188607214 ∧ code e1131188607214 = 5529235118318 := by decide
theorem cert_e1131188607214 : check e1131188607214 [[],[.under]] .smaller = true := by decide
def e1131188607222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1131188607222 : Closed e1131188607222 ∧ code e1131188607222 = 5529235118326 := by decide
theorem cert_e1131188607222 : check e1131188607222 [[],[.under]] .smaller = true := by decide
def e1131188607774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1131188607774 : Closed e1131188607774 ∧ code e1131188607774 = 5529235118878 := by decide
theorem cert_e1131188607774 : check e1131188607774 [[],[.under]] .smaller = true := by decide
def e1131188607886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1131188607886 : Closed e1131188607886 ∧ code e1131188607886 = 5529235118990 := by decide
theorem cert_e1131188607886 : check e1131188607886 [[],[.under]] .smaller = true := by decide
def e1131188608110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1131188608110 : Closed e1131188608110 ∧ code e1131188608110 = 5529235119214 := by decide
theorem cert_e1131188608110 : check e1131188608110 [[],[.under]] .smaller = true := by decide
def e1131188608122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1131188608122 : Closed e1131188608122 ∧ code e1131188608122 = 5529235119226 := by decide
theorem cert_e1131188608122 : check e1131188608122 [[],[.under]] .smaller = true := by decide
def e1131188608286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1131188608286 : Closed e1131188608286 ∧ code e1131188608286 = 5529235119390 := by decide
theorem cert_e1131188608286 : check e1131188608286 [[],[.under]] .smaller = true := by decide
def e1131188608454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1131188608454 : Closed e1131188608454 ∧ code e1131188608454 = 5529235119558 := by decide
theorem cert_e1131188608454 : check e1131188608454 [[],[.under]] .smaller = true := by decide
def e1131188608478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1131188608478 : Closed e1131188608478 ∧ code e1131188608478 = 5529235119582 := by decide
theorem cert_e1131188608478 : check e1131188608478 [[],[.under]] .three = true := by decide
def e1131188608494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1131188608494 : Closed e1131188608494 ∧ code e1131188608494 = 5529235119598 := by decide
theorem cert_e1131188608494 : check e1131188608494 [[],[.under]] .three = true := by decide
def e1131188608566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1131188608566 : Closed e1131188608566 ∧ code e1131188608566 = 5529235119670 := by decide
theorem cert_e1131188608566 : check e1131188608566 [[],[.under]] .smaller = true := by decide
def e1131188608570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1131188608570 : Closed e1131188608570 ∧ code e1131188608570 = 5529235119674 := by decide
theorem cert_e1131188608570 : check e1131188608570 [[],[.under]] .smaller = true := by decide
def e1131188608654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1131188608654 : Closed e1131188608654 ∧ code e1131188608654 = 5529235119758 := by decide
theorem cert_e1131188608654 : check e1131188608654 [[],[.under]] .smaller = true := by decide
def e1131188608710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1131188608710 : Closed e1131188608710 ∧ code e1131188608710 = 5529235119814 := by decide
theorem cert_e1131188608710 : check e1131188608710 [[],[.under]] .smaller = true := by decide
def e1131188608734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1131188608734 : Closed e1131188608734 ∧ code e1131188608734 = 5529235119838 := by decide
theorem cert_e1131188608734 : check e1131188608734 [[],[.under]] .three = true := by decide
def e1131188608758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1131188608758 : Closed e1131188608758 ∧ code e1131188608758 = 5529235119862 := by decide
theorem cert_e1131188608758 : check e1131188608758 [[],[.under]] .three = true := by decide
def e1131188608878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1131188608878 : Closed e1131188608878 ∧ code e1131188608878 = 5529235119982 := by decide
theorem cert_e1131188608878 : check e1131188608878 [[],[.under]] .three = true := by decide
def e1131188608886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1131188608886 : Closed e1131188608886 ∧ code e1131188608886 = 5529235119990 := by decide
theorem cert_e1131188608886 : check e1131188608886 [[],[.under]] .three = true := by decide
def e1131188610846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1131188610846 : Closed e1131188610846 ∧ code e1131188610846 = 5529235121950 := by decide
theorem cert_e1131188610846 : check e1131188610846 [[],[.under]] .smaller = true := by decide
def e1131188610958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1131188610958 : Closed e1131188610958 ∧ code e1131188610958 = 5529235122062 := by decide
theorem cert_e1131188610958 : check e1131188610958 [[],[.under]] .smaller = true := by decide
def e1131188613918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1131188613918 : Closed e1131188613918 ∧ code e1131188613918 = 5529235125022 := by decide
theorem cert_e1131188613918 : check e1131188613918 [[],[.under]] .smaller = true := by decide
def e1131188614086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1131188614086 : Closed e1131188614086 ∧ code e1131188614086 = 5529235125190 := by decide
theorem cert_e1131188614086 : check e1131188614086 [[],[.under]] .smaller = true := by decide
def e1131188614110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1131188614110 : Closed e1131188614110 ∧ code e1131188614110 = 5529235125214 := by decide
theorem cert_e1131188614110 : check e1131188614110 [[],[.under]] .three = true := by decide
def e1131188614126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1131188614126 : Closed e1131188614126 ∧ code e1131188614126 = 5529235125230 := by decide
theorem cert_e1131188614126 : check e1131188614126 [[],[.under]] .three = true := by decide
def e1131188615566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1131188615566 : Closed e1131188615566 ∧ code e1131188615566 = 5529235126670 := by decide
theorem cert_e1131188615566 : check e1131188615566 [[],[.under]] .smaller = true := by decide
def e1131188615622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1131188615622 : Closed e1131188615622 ∧ code e1131188615622 = 5529235126726 := by decide
theorem cert_e1131188615622 : check e1131188615622 [[],[.under]] .smaller = true := by decide
def e1131188615646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1131188615646 : Closed e1131188615646 ∧ code e1131188615646 = 5529235126750 := by decide
theorem cert_e1131188615646 : check e1131188615646 [[],[.under]] .three = true := by decide
def e1131188615670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1131188615670 : Closed e1131188615670 ∧ code e1131188615670 = 5529235126774 := by decide
theorem cert_e1131188615670 : check e1131188615670 [[],[.under]] .three = true := by decide
def e1131188616430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1131188616430 : Closed e1131188616430 ∧ code e1131188616430 = 5529235127534 := by decide
theorem cert_e1131188616430 : check e1131188616430 [[],[.under]] .three = true := by decide
def e1131188616438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1131188616438 : Closed e1131188616438 ∧ code e1131188616438 = 5529235127542 := by decide
theorem cert_e1131188616438 : check e1131188616438 [[],[.under]] .three = true := by decide
def e1131188673390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1131188673390 : Closed e1131188673390 ∧ code e1131188673390 = 5529235184494 := by decide
theorem cert_e1131188673390 : check e1131188673390 [[],[.under]] .three = true := by decide
def e1131188673398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1131188673398 : Closed e1131188673398 ∧ code e1131188673398 = 5529235184502 := by decide
theorem cert_e1131188673398 : check e1131188673398 [[],[.under]] .three = true := by decide
def e1131188673462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1131188673462 : Closed e1131188673462 ∧ code e1131188673462 = 5529235184566 := by decide
theorem cert_e1131188673462 : check e1131188673462 [[],[.under]] .three = true := by decide
def e1131188673902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1131188673902 : Closed e1131188673902 ∧ code e1131188673902 = 5529235185006 := by decide
theorem cert_e1131188673902 : check e1131188673902 [[],[.under]] .three = true := by decide
def e1131188673910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1131188673910 : Closed e1131188673910 ∧ code e1131188673910 = 5529235185014 := by decide
theorem cert_e1131188673910 : check e1131188673910 [[],[.under]] .three = true := by decide
def e1131188673966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1131188673966 : Closed e1131188673966 ∧ code e1131188673966 = 5529235185070 := by decide
theorem cert_e1131188673966 : check e1131188673966 [[],[.under]] .three = true := by decide
def e1131188673978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1131188673978 : Closed e1131188673978 ∧ code e1131188673978 = 5529235185082 := by decide
theorem cert_e1131188673978 : check e1131188673978 [[],[.under]] .three = true := by decide
def e1131188674006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1131188674006 : Closed e1131188674006 ∧ code e1131188674006 = 5529235185110 := by decide
theorem cert_e1131188674006 : check e1131188674006 [[],[.under]] .three = true := by decide
def e1131188674010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1131188674010 : Closed e1131188674010 ∧ code e1131188674010 = 5529235185114 := by decide
theorem cert_e1131188674010 : check e1131188674010 [[],[.under]] .three = true := by decide
def e1131188674230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1131188674230 : Closed e1131188674230 ∧ code e1131188674230 = 5529235185334 := by decide
theorem cert_e1131188674230 : check e1131188674230 [[],[.under]] .three = true := by decide
def e1131188674262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1131188674262 : Closed e1131188674262 ∧ code e1131188674262 = 5529235185366 := by decide
theorem cert_e1131188674262 : check e1131188674262 [[],[.under]] .three = true := by decide
def e1131188674266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1131188674266 : Closed e1131188674266 ∧ code e1131188674266 = 5529235185370 := by decide
theorem cert_e1131188674266 : check e1131188674266 [[],[.under]] .three = true := by decide
def e1131188676462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1131188676462 : Closed e1131188676462 ∧ code e1131188676462 = 5529235187566 := by decide
theorem cert_e1131188676462 : check e1131188676462 [[],[.under]] .three = true := by decide
def e1131188676470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1131188676470 : Closed e1131188676470 ∧ code e1131188676470 = 5529235187574 := by decide
theorem cert_e1131188676470 : check e1131188676470 [[],[.under]] .three = true := by decide
def e1131188676534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1131188676534 : Closed e1131188676534 ∧ code e1131188676534 = 5529235187638 := by decide
theorem cert_e1131188676534 : check e1131188676534 [[],[.under]] .three = true := by decide
def e1131188677870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131188677870 : Closed e1131188677870 ∧ code e1131188677870 = 5529235188974 := by decide
theorem cert_e1131188677870 : check e1131188677870 [[],[.under]] .three = true := by decide
def e1131188677878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131188677878 : Closed e1131188677878 ∧ code e1131188677878 = 5529235188982 := by decide
theorem cert_e1131188677878 : check e1131188677878 [[],[.under]] .three = true := by decide
def e1131188678262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131188678262 : Closed e1131188678262 ∧ code e1131188678262 = 5529235189366 := by decide
theorem cert_e1131188678262 : check e1131188678262 [[],[.under]] .three = true := by decide
def e1131188679150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1131188679150 : Closed e1131188679150 ∧ code e1131188679150 = 5529235190254 := by decide
theorem cert_e1131188679150 : check e1131188679150 [[],[.under]] .three = true := by decide
def e1131188679534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1131188679534 : Closed e1131188679534 ∧ code e1131188679534 = 5529235190638 := by decide
theorem cert_e1131188679534 : check e1131188679534 [[],[.under]] .three = true := by decide
def e1131188679542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1131188679542 : Closed e1131188679542 ∧ code e1131188679542 = 5529235190646 := by decide
theorem cert_e1131188679542 : check e1131188679542 [[],[.under]] .three = true := by decide
def e1131188679598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1131188679598 : Closed e1131188679598 ∧ code e1131188679598 = 5529235190702 := by decide
theorem cert_e1131188679598 : check e1131188679598 [[],[.under]] .three = true := by decide
def e1131188679610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1131188679610 : Closed e1131188679610 ∧ code e1131188679610 = 5529235190714 := by decide
theorem cert_e1131188679610 : check e1131188679610 [[],[.under]] .three = true := by decide
def e1131188679638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1131188679638 : Closed e1131188679638 ∧ code e1131188679638 = 5529235190742 := by decide
theorem cert_e1131188679638 : check e1131188679638 [[],[.under]] .three = true := by decide
def e1131188679642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1131188679642 : Closed e1131188679642 ∧ code e1131188679642 = 5529235190746 := by decide
theorem cert_e1131188679642 : check e1131188679642 [[],[.under]] .three = true := by decide
def e1131188679918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1131188679918 : Closed e1131188679918 ∧ code e1131188679918 = 5529235191022 := by decide
theorem cert_e1131188679918 : check e1131188679918 [[],[.under]] .three = true := by decide
def e1131188679926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1131188679926 : Closed e1131188679926 ∧ code e1131188679926 = 5529235191030 := by decide
theorem cert_e1131188679926 : check e1131188679926 [[],[.under]] .three = true := by decide
def e1131188680302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1131188680302 : Closed e1131188680302 ∧ code e1131188680302 = 5529235191406 := by decide
theorem cert_e1131188680302 : check e1131188680302 [[],[.under]] .three = true := by decide
def e1131188680314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1131188680314 : Closed e1131188680314 ∧ code e1131188680314 = 5529235191418 := by decide
theorem cert_e1131188680314 : check e1131188680314 [[],[.under]] .three = true := by decide
def e1131188680478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1131188680478 : Closed e1131188680478 ∧ code e1131188680478 = 5529235191582 := by decide
theorem cert_e1131188680478 : check e1131188680478 [[],[.under]] .three = true := by decide
def e1131188680502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188680502 : Closed e1131188680502 ∧ code e1131188680502 = 5529235191606 := by decide
theorem cert_e1131188680502 : check e1131188680502 [[],[.under]] .three = true := by decide
def e1131188680506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188680506 : Closed e1131188680506 ∧ code e1131188680506 = 5529235191610 := by decide
theorem cert_e1131188680506 : check e1131188680506 [[],[.under]] .three = true := by decide
def e1131188680942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1131188680942 : Closed e1131188680942 ∧ code e1131188680942 = 5529235192046 := by decide
theorem cert_e1131188680942 : check e1131188680942 [[],[.under]] .three = true := by decide
def e1131188680950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1131188680950 : Closed e1131188680950 ∧ code e1131188680950 = 5529235192054 := by decide
theorem cert_e1131188680950 : check e1131188680950 [[],[.under]] .three = true := by decide
def e1131188681142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1131188681142 : Closed e1131188681142 ∧ code e1131188681142 = 5529235192246 := by decide
theorem cert_e1131188681142 : check e1131188681142 [[],[.under]] .three = true := by decide
def e1131188681174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1131188681174 : Closed e1131188681174 ∧ code e1131188681174 = 5529235192278 := by decide
theorem cert_e1131188681174 : check e1131188681174 [[],[.under]] .three = true := by decide
def e1131188681178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1131188681178 : Closed e1131188681178 ∧ code e1131188681178 = 5529235192282 := by decide
theorem cert_e1131188681178 : check e1131188681178 [[],[.under]] .three = true := by decide
def e1131188681334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1131188681334 : Closed e1131188681334 ∧ code e1131188681334 = 5529235192438 := by decide
theorem cert_e1131188681334 : check e1131188681334 [[],[.under]] .three = true := by decide
def e1131188681502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1131188681502 : Closed e1131188681502 ∧ code e1131188681502 = 5529235192606 := by decide
theorem cert_e1131188681502 : check e1131188681502 [[],[.under]] .three = true := by decide
def e1131188681526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188681526 : Closed e1131188681526 ∧ code e1131188681526 = 5529235192630 := by decide
theorem cert_e1131188681526 : check e1131188681526 [[],[.under]] .three = true := by decide
def e1131188681530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188681530 : Closed e1131188681530 ∧ code e1131188681530 = 5529235192634 := by decide
theorem cert_e1131188681530 : check e1131188681530 [[],[.under]] .three = true := by decide
def e1131188681614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1131188681614 : Closed e1131188681614 ∧ code e1131188681614 = 5529235192718 := by decide
theorem cert_e1131188681614 : check e1131188681614 [[],[.under]] .three = true := by decide
def e1131188688750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1131188688750 : Closed e1131188688750 ∧ code e1131188688750 = 5529235199854 := by decide
theorem cert_e1131188688750 : check e1131188688750 [[],[.under]] .three = true := by decide
def e1131188688758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1131188688758 : Closed e1131188688758 ∧ code e1131188688758 = 5529235199862 := by decide
theorem cert_e1131188688758 : check e1131188688758 [[],[.under]] .three = true := by decide
end Blc.Floor42
