import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182337142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211182337142 : Closed e1211182337142 ∧ code e1211182337142 = 5609228848246 := by decide
theorem cert_e1211182337142 : check e1211182337142 [[],[]] .smaller = true := by decide
def e1211182337146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211182337146 : Closed e1211182337146 ∧ code e1211182337146 = 5609228848250 := by decide
theorem cert_e1211182337146 : check e1211182337146 [[],[]] .smaller = true := by decide
def e1211182337238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e1211182337238 : Closed e1211182337238 ∧ code e1211182337238 = 5609228848342 := by decide
theorem cert_e1211182337238 : check e1211182337238 [[],[]] .smaller = true := by decide
def e1211182337242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e1211182337242 : Closed e1211182337242 ∧ code e1211182337242 = 5609228848346 := by decide
theorem cert_e1211182337242 : check e1211182337242 [[],[]] .smaller = true := by decide
def e1211182337258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e1211182337258 : Closed e1211182337258 ∧ code e1211182337258 = 5609228848362 := by decide
theorem cert_e1211182337258 : check e1211182337258 [[],[]] .smaller = true := by decide
def e1211182337310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211182337310 : Closed e1211182337310 ∧ code e1211182337310 = 5609228848414 := by decide
theorem cert_e1211182337310 : check e1211182337310 [[],[]] .smaller = true := by decide
def e1211182337334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182337334 : Closed e1211182337334 ∧ code e1211182337334 = 5609228848438 := by decide
theorem cert_e1211182337334 : check e1211182337334 [[],[]] .smaller = true := by decide
def e1211182337338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182337338 : Closed e1211182337338 ∧ code e1211182337338 = 5609228848442 := by decide
theorem cert_e1211182337338 : check e1211182337338 [[],[]] .smaller = true := by decide
def e1211182337422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211182337422 : Closed e1211182337422 ∧ code e1211182337422 = 5609228848526 := by decide
theorem cert_e1211182337422 : check e1211182337422 [[],[]] .smaller = true := by decide
def e1211182337434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182337434 : Closed e1211182337434 ∧ code e1211182337434 = 5609228848538 := by decide
theorem cert_e1211182337434 : check e1211182337434 [[],[]] .smaller = true := by decide
def e1211182337478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211182337478 : Closed e1211182337478 ∧ code e1211182337478 = 5609228848582 := by decide
theorem cert_e1211182337478 : check e1211182337478 [[],[]] .smaller = true := by decide
def e1211182337502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211182337502 : Closed e1211182337502 ∧ code e1211182337502 = 5609228848606 := by decide
theorem cert_e1211182337502 : check e1211182337502 [[],[]] .smaller = true := by decide
def e1211182337518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211182337518 : Closed e1211182337518 ∧ code e1211182337518 = 5609228848622 := by decide
theorem cert_e1211182337518 : check e1211182337518 [[],[]] .smaller = true := by decide
def e1211182337590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211182337590 : Closed e1211182337590 ∧ code e1211182337590 = 5609228848694 := by decide
theorem cert_e1211182337590 : check e1211182337590 [[],[]] .smaller = true := by decide
def e1211182337594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211182337594 : Closed e1211182337594 ∧ code e1211182337594 = 5609228848698 := by decide
theorem cert_e1211182337594 : check e1211182337594 [[],[]] .smaller = true := by decide
def e1211182337642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e1211182337642 : Closed e1211182337642 ∧ code e1211182337642 = 5609228848746 := by decide
theorem cert_e1211182337642 : check e1211182337642 [[],[]] .smaller = true := by decide
def e1211182337678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211182337678 : Closed e1211182337678 ∧ code e1211182337678 = 5609228848782 := by decide
theorem cert_e1211182337678 : check e1211182337678 [[],[]] .smaller = true := by decide
def e1211182337690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182337690 : Closed e1211182337690 ∧ code e1211182337690 = 5609228848794 := by decide
theorem cert_e1211182337690 : check e1211182337690 [[],[]] .smaller = true := by decide
def e1211182337734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211182337734 : Closed e1211182337734 ∧ code e1211182337734 = 5609228848838 := by decide
theorem cert_e1211182337734 : check e1211182337734 [[],[]] .smaller = true := by decide
def e1211182337774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e1211182337774 : Closed e1211182337774 ∧ code e1211182337774 = 5609228848878 := by decide
theorem cert_e1211182337774 : check e1211182337774 [[],[]] .smaller = true := by decide
def e1211182337818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211182337818 : Closed e1211182337818 ∧ code e1211182337818 = 5609228848922 := by decide
theorem cert_e1211182337818 : check e1211182337818 [[],[]] .smaller = true := by decide
def e1211182337862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211182337862 : Closed e1211182337862 ∧ code e1211182337862 = 5609228848966 := by decide
theorem cert_e1211182337862 : check e1211182337862 [[],[]] .smaller = true := by decide
def e1211182337886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211182337886 : Closed e1211182337886 ∧ code e1211182337886 = 5609228848990 := by decide
theorem cert_e1211182337886 : check e1211182337886 [[],[]] .smaller = true := by decide
def e1211182337902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e1211182337902 : Closed e1211182337902 ∧ code e1211182337902 = 5609228849006 := by decide
theorem cert_e1211182337902 : check e1211182337902 [[],[]] .smaller = true := by decide
def e1211182337910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e1211182337910 : Closed e1211182337910 ∧ code e1211182337910 = 5609228849014 := by decide
theorem cert_e1211182337910 : check e1211182337910 [[],[]] .smaller = true := by decide
def e1211182337914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211182337914 : Closed e1211182337914 ∧ code e1211182337914 = 5609228849018 := by decide
theorem cert_e1211182337914 : check e1211182337914 [[],[]] .smaller = true := by decide
def e1211182337966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211182337966 : Closed e1211182337966 ∧ code e1211182337966 = 5609228849070 := by decide
theorem cert_e1211182337966 : check e1211182337966 [[],[]] .smaller = true := by decide
def e1211182337978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211182337978 : Closed e1211182337978 ∧ code e1211182337978 = 5609228849082 := by decide
theorem cert_e1211182337978 : check e1211182337978 [[],[]] .smaller = true := by decide
def e1211182338286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182338286 : Closed e1211182338286 ∧ code e1211182338286 = 5609228849390 := by decide
theorem cert_e1211182338286 : check e1211182338286 [[],[]] .smaller = true := by decide
def e1211182338294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182338294 : Closed e1211182338294 ∧ code e1211182338294 = 5609228849398 := by decide
theorem cert_e1211182338294 : check e1211182338294 [[],[]] .smaller = true := by decide
def e1211182338774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211182338774 : Closed e1211182338774 ∧ code e1211182338774 = 5609228849878 := by decide
theorem cert_e1211182338774 : check e1211182338774 [[],[]] .smaller = true := by decide
def e1211182338778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211182338778 : Closed e1211182338778 ∧ code e1211182338778 = 5609228849882 := by decide
theorem cert_e1211182338778 : check e1211182338778 [[],[]] .smaller = true := by decide
def e1211182338794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211182338794 : Closed e1211182338794 ∧ code e1211182338794 = 5609228849898 := by decide
theorem cert_e1211182338794 : check e1211182338794 [[],[]] .smaller = true := by decide
def e1211182338846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211182338846 : Closed e1211182338846 ∧ code e1211182338846 = 5609228849950 := by decide
theorem cert_e1211182338846 : check e1211182338846 [[],[]] .smaller = true := by decide
def e1211182338870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182338870 : Closed e1211182338870 ∧ code e1211182338870 = 5609228849974 := by decide
theorem cert_e1211182338870 : check e1211182338870 [[],[]] .smaller = true := by decide
def e1211182338874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182338874 : Closed e1211182338874 ∧ code e1211182338874 = 5609228849978 := by decide
theorem cert_e1211182338874 : check e1211182338874 [[],[]] .smaller = true := by decide
def e1211182338958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211182338958 : Closed e1211182338958 ∧ code e1211182338958 = 5609228850062 := by decide
theorem cert_e1211182338958 : check e1211182338958 [[],[]] .smaller = true := by decide
def e1211182338970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182338970 : Closed e1211182338970 ∧ code e1211182338970 = 5609228850074 := by decide
theorem cert_e1211182338970 : check e1211182338970 [[],[]] .smaller = true := by decide
def e1211182339014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211182339014 : Closed e1211182339014 ∧ code e1211182339014 = 5609228850118 := by decide
theorem cert_e1211182339014 : check e1211182339014 [[],[]] .smaller = true := by decide
def e1211182339038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211182339038 : Closed e1211182339038 ∧ code e1211182339038 = 5609228850142 := by decide
theorem cert_e1211182339038 : check e1211182339038 [[],[]] .smaller = true := by decide
def e1211182339054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211182339054 : Closed e1211182339054 ∧ code e1211182339054 = 5609228850158 := by decide
theorem cert_e1211182339054 : check e1211182339054 [[],[]] .smaller = true := by decide
def e1211182340214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182340214 : Closed e1211182340214 ∧ code e1211182340214 = 5609228851318 := by decide
theorem cert_e1211182340214 : check e1211182340214 [[],[]] .smaller = true := by decide
def e1211182340458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211182340458 : Closed e1211182340458 ∧ code e1211182340458 = 5609228851562 := by decide
theorem cert_e1211182340458 : check e1211182340458 [[],[]] .smaller = true := by decide
def e1211182340494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211182340494 : Closed e1211182340494 ∧ code e1211182340494 = 5609228851598 := by decide
theorem cert_e1211182340494 : check e1211182340494 [[],[]] .smaller = true := by decide
def e1211182340506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182340506 : Closed e1211182340506 ∧ code e1211182340506 = 5609228851610 := by decide
theorem cert_e1211182340506 : check e1211182340506 [[],[]] .smaller = true := by decide
def e1211182340550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211182340550 : Closed e1211182340550 ∧ code e1211182340550 = 5609228851654 := by decide
theorem cert_e1211182340550 : check e1211182340550 [[],[]] .smaller = true := by decide
def e1211182340590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211182340590 : Closed e1211182340590 ∧ code e1211182340590 = 5609228851694 := by decide
theorem cert_e1211182340590 : check e1211182340590 [[],[]] .smaller = true := by decide
def e1211182341318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211182341318 : Closed e1211182341318 ∧ code e1211182341318 = 5609228852422 := by decide
theorem cert_e1211182341318 : check e1211182341318 [[],[]] .smaller = true := by decide
def e1211182341342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182341342 : Closed e1211182341342 ∧ code e1211182341342 = 5609228852446 := by decide
theorem cert_e1211182341342 : check e1211182341342 [[],[]] .smaller = true := by decide
def e1211182341358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182341358 : Closed e1211182341358 ∧ code e1211182341358 = 5609228852462 := by decide
theorem cert_e1211182341358 : check e1211182341358 [[],[]] .smaller = true := by decide
def e1211182341366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182341366 : Closed e1211182341366 ∧ code e1211182341366 = 5609228852470 := by decide
theorem cert_e1211182341366 : check e1211182341366 [[],[]] .smaller = true := by decide
def e1211182341370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182341370 : Closed e1211182341370 ∧ code e1211182341370 = 5609228852474 := by decide
theorem cert_e1211182341370 : check e1211182341370 [[],[]] .smaller = true := by decide
def e1211182341742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182341742 : Closed e1211182341742 ∧ code e1211182341742 = 5609228852846 := by decide
theorem cert_e1211182341742 : check e1211182341742 [[],[]] .smaller = true := by decide
def e1211182341754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182341754 : Closed e1211182341754 ∧ code e1211182341754 = 5609228852858 := by decide
theorem cert_e1211182341754 : check e1211182341754 [[],[]] .smaller = true := by decide
def e1211182342966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182342966 : Closed e1211182342966 ∧ code e1211182342966 = 5609228854070 := by decide
theorem cert_e1211182342966 : check e1211182342966 [[],[]] .three = true := by decide
def e1211182342970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182342970 : Closed e1211182342970 ∧ code e1211182342970 = 5609228854074 := by decide
theorem cert_e1211182342970 : check e1211182342970 [[],[]] .three = true := by decide
def e1211182343066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182343066 : Closed e1211182343066 ∧ code e1211182343066 = 5609228854170 := by decide
theorem cert_e1211182343066 : check e1211182343066 [[],[]] .three = true := by decide
def e1211182343734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211182343734 : Closed e1211182343734 ∧ code e1211182343734 = 5609228854838 := by decide
theorem cert_e1211182343734 : check e1211182343734 [[],[]] .three = true := by decide
def e1211182343738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211182343738 : Closed e1211182343738 ∧ code e1211182343738 = 5609228854842 := by decide
theorem cert_e1211182343738 : check e1211182343738 [[],[]] .three = true := by decide
def e1211182343822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211182343822 : Closed e1211182343822 ∧ code e1211182343822 = 5609228854926 := by decide
theorem cert_e1211182343822 : check e1211182343822 [[],[]] .three = true := by decide
def e1211182343878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211182343878 : Closed e1211182343878 ∧ code e1211182343878 = 5609228854982 := by decide
theorem cert_e1211182343878 : check e1211182343878 [[],[]] .three = true := by decide
def e1211182343918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e1211182343918 : Closed e1211182343918 ∧ code e1211182343918 = 5609228855022 := by decide
theorem cert_e1211182343918 : check e1211182343918 [[],[]] .three = true := by decide
def e1211182343962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211182343962 : Closed e1211182343962 ∧ code e1211182343962 = 5609228855066 := by decide
theorem cert_e1211182343962 : check e1211182343962 [[],[]] .three = true := by decide
def e1211182344006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211182344006 : Closed e1211182344006 ∧ code e1211182344006 = 5609228855110 := by decide
theorem cert_e1211182344006 : check e1211182344006 [[],[]] .three = true := by decide
def e1211182344046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211182344046 : Closed e1211182344046 ∧ code e1211182344046 = 5609228855150 := by decide
theorem cert_e1211182344046 : check e1211182344046 [[],[]] .three = true := by decide
def e1211182344054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211182344054 : Closed e1211182344054 ∧ code e1211182344054 = 5609228855158 := by decide
theorem cert_e1211182344054 : check e1211182344054 [[],[]] .three = true := by decide
def e1211182344110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e1211182344110 : Closed e1211182344110 ∧ code e1211182344110 = 5609228855214 := by decide
theorem cert_e1211182344110 : check e1211182344110 [[],[]] .three = true := by decide
def e1211182344118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211182344118 : Closed e1211182344118 ∧ code e1211182344118 = 5609228855222 := by decide
theorem cert_e1211182344118 : check e1211182344118 [[],[]] .three = true := by decide
def e1211182344122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e1211182344122 : Closed e1211182344122 ∧ code e1211182344122 = 5609228855226 := by decide
theorem cert_e1211182344122 : check e1211182344122 [[],[]] .three = true := by decide
def e1211182344590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211182344590 : Closed e1211182344590 ∧ code e1211182344590 = 5609228855694 := by decide
theorem cert_e1211182344590 : check e1211182344590 [[],[]] .three = true := by decide
def e1211182344646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211182344646 : Closed e1211182344646 ∧ code e1211182344646 = 5609228855750 := by decide
theorem cert_e1211182344646 : check e1211182344646 [[],[]] .three = true := by decide
def e1211182344686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211182344686 : Closed e1211182344686 ∧ code e1211182344686 = 5609228855790 := by decide
theorem cert_e1211182344686 : check e1211182344686 [[],[]] .three = true := by decide
def e1211182345414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211182345414 : Closed e1211182345414 ∧ code e1211182345414 = 5609228856518 := by decide
theorem cert_e1211182345414 : check e1211182345414 [[],[]] .three = true := by decide
def e1211182345454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182345454 : Closed e1211182345454 ∧ code e1211182345454 = 5609228856558 := by decide
theorem cert_e1211182345454 : check e1211182345454 [[],[]] .three = true := by decide
def e1211182345462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182345462 : Closed e1211182345462 ∧ code e1211182345462 = 5609228856566 := by decide
theorem cert_e1211182345462 : check e1211182345462 [[],[]] .three = true := by decide
def e1211182345838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182345838 : Closed e1211182345838 ∧ code e1211182345838 = 5609228856942 := by decide
theorem cert_e1211182345838 : check e1211182345838 [[],[]] .three = true := by decide
def e1211182345846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182345846 : Closed e1211182345846 ∧ code e1211182345846 = 5609228856950 := by decide
theorem cert_e1211182345846 : check e1211182345846 [[],[]] .three = true := by decide
def e1211182345850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182345850 : Closed e1211182345850 ∧ code e1211182345850 = 5609228856954 := by decide
theorem cert_e1211182345850 : check e1211182345850 [[],[]] .three = true := by decide
def e1211182373102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))))
theorem wire_e1211182373102 : Closed e1211182373102 ∧ code e1211182373102 = 5609228884206 := by decide
theorem cert_e1211182373102 : check e1211182373102 [[],[]] .smaller = true := by decide
def e1211182373110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))))
theorem wire_e1211182373110 : Closed e1211182373110 ∧ code e1211182373110 = 5609228884214 := by decide
theorem cert_e1211182373110 : check e1211182373110 [[],[]] .smaller = true := by decide
def e1211182373662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))))
theorem wire_e1211182373662 : Closed e1211182373662 ∧ code e1211182373662 = 5609228884766 := by decide
theorem cert_e1211182373662 : check e1211182373662 [[],[]] .smaller = true := by decide
def e1211182373758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 5))))))))))
theorem wire_e1211182373758 : Closed e1211182373758 ∧ code e1211182373758 = 5609228884862 := by decide
theorem cert_e1211182373758 : check e1211182373758 [[],[]] .three = true := by decide
def e1211182373774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))))
theorem wire_e1211182373774 : Closed e1211182373774 ∧ code e1211182373774 = 5609228884878 := by decide
theorem cert_e1211182373774 : check e1211182373774 [[],[]] .smaller = true := by decide
def e1211182373878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 5)) (.var 1))))))))))
theorem wire_e1211182373878 : Closed e1211182373878 ∧ code e1211182373878 = 5609228884982 := by decide
theorem cert_e1211182373878 : check e1211182373878 [[],[]] .three = true := by decide
def e1211182373998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))))
theorem wire_e1211182373998 : Closed e1211182373998 ∧ code e1211182373998 = 5609228885102 := by decide
theorem cert_e1211182373998 : check e1211182373998 [[],[]] .smaller = true := by decide
def e1211182374010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))))
theorem wire_e1211182374010 : Closed e1211182374010 ∧ code e1211182374010 = 5609228885114 := by decide
theorem cert_e1211182374010 : check e1211182374010 [[],[]] .smaller = true := by decide
def e1211182374174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))))
theorem wire_e1211182374174 : Closed e1211182374174 ∧ code e1211182374174 = 5609228885278 := by decide
theorem cert_e1211182374174 : check e1211182374174 [[],[]] .smaller = true := by decide
def e1211182374270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 5))))))))))
theorem wire_e1211182374270 : Closed e1211182374270 ∧ code e1211182374270 = 5609228885374 := by decide
theorem cert_e1211182374270 : check e1211182374270 [[],[]] .three = true := by decide
def e1211182374342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))))
theorem wire_e1211182374342 : Closed e1211182374342 ∧ code e1211182374342 = 5609228885446 := by decide
theorem cert_e1211182374342 : check e1211182374342 [[],[]] .smaller = true := by decide
def e1211182374366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))))
theorem wire_e1211182374366 : Closed e1211182374366 ∧ code e1211182374366 = 5609228885470 := by decide
theorem cert_e1211182374366 : check e1211182374366 [[],[]] .smaller = true := by decide
def e1211182374382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))))
theorem wire_e1211182374382 : Closed e1211182374382 ∧ code e1211182374382 = 5609228885486 := by decide
theorem cert_e1211182374382 : check e1211182374382 [[],[]] .smaller = true := by decide
def e1211182374394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 5)) (.var 0))))))))))
theorem wire_e1211182374394 : Closed e1211182374394 ∧ code e1211182374394 = 5609228885498 := by decide
theorem cert_e1211182374394 : check e1211182374394 [[],[]] .three = true := by decide
def e1211182374454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e1211182374454 : Closed e1211182374454 ∧ code e1211182374454 = 5609228885558 := by decide
theorem cert_e1211182374454 : check e1211182374454 [[],[]] .smaller = true := by decide
def e1211182374458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e1211182374458 : Closed e1211182374458 ∧ code e1211182374458 = 5609228885562 := by decide
theorem cert_e1211182374458 : check e1211182374458 [[],[]] .smaller = true := by decide
def e1211182374542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e1211182374542 : Closed e1211182374542 ∧ code e1211182374542 = 5609228885646 := by decide
theorem cert_e1211182374542 : check e1211182374542 [[],[]] .smaller = true := by decide
def e1211182374598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e1211182374598 : Closed e1211182374598 ∧ code e1211182374598 = 5609228885702 := by decide
theorem cert_e1211182374598 : check e1211182374598 [[],[]] .smaller = true := by decide
def e1211182374622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))))
theorem wire_e1211182374622 : Closed e1211182374622 ∧ code e1211182374622 = 5609228885726 := by decide
theorem cert_e1211182374622 : check e1211182374622 [[],[]] .smaller = true := by decide
def e1211182374646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))))
theorem wire_e1211182374646 : Closed e1211182374646 ∧ code e1211182374646 = 5609228885750 := by decide
theorem cert_e1211182374646 : check e1211182374646 [[],[]] .smaller = true := by decide
def e1211182374766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))))
theorem wire_e1211182374766 : Closed e1211182374766 ∧ code e1211182374766 = 5609228885870 := by decide
theorem cert_e1211182374766 : check e1211182374766 [[],[]] .smaller = true := by decide
def e1211182374774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))))
theorem wire_e1211182374774 : Closed e1211182374774 ∧ code e1211182374774 = 5609228885878 := by decide
theorem cert_e1211182374774 : check e1211182374774 [[],[]] .smaller = true := by decide
def e1211182374870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 5) (.var 0)) (.var 1))))))))))
theorem wire_e1211182374870 : Closed e1211182374870 ∧ code e1211182374870 = 5609228885974 := by decide
theorem cert_e1211182374870 : check e1211182374870 [[],[]] .three = true := by decide
def e1211182374874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 5) (.var 1)) (.var 0))))))))))
theorem wire_e1211182374874 : Closed e1211182374874 ∧ code e1211182374874 = 5609228885978 := by decide
theorem cert_e1211182374874 : check e1211182374874 [[],[]] .three = true := by decide
def e1211182376734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))))
theorem wire_e1211182376734 : Closed e1211182376734 ∧ code e1211182376734 = 5609228887838 := by decide
theorem cert_e1211182376734 : check e1211182376734 [[],[]] .smaller = true := by decide
def e1211182376830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 5)))))))))))
theorem wire_e1211182376830 : Closed e1211182376830 ∧ code e1211182376830 = 5609228887934 := by decide
theorem cert_e1211182376830 : check e1211182376830 [[],[]] .three = true := by decide
def e1211182376846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))))
theorem wire_e1211182376846 : Closed e1211182376846 ∧ code e1211182376846 = 5609228887950 := by decide
theorem cert_e1211182376846 : check e1211182376846 [[],[]] .smaller = true := by decide
def e1211182376950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 5) (.var 1)))))))))))
theorem wire_e1211182376950 : Closed e1211182376950 ∧ code e1211182376950 = 5609228888054 := by decide
theorem cert_e1211182376950 : check e1211182376950 [[],[]] .three = true := by decide
def e1211182379806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))
theorem wire_e1211182379806 : Closed e1211182379806 ∧ code e1211182379806 = 5609228890910 := by decide
theorem cert_e1211182379806 : check e1211182379806 [[],[]] .smaller = true := by decide
def e1211182379902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 5)))))))))))
theorem wire_e1211182379902 : Closed e1211182379902 ∧ code e1211182379902 = 5609228891006 := by decide
theorem cert_e1211182379902 : check e1211182379902 [[],[]] .three = true := by decide
def e1211182379974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))))
theorem wire_e1211182379974 : Closed e1211182379974 ∧ code e1211182379974 = 5609228891078 := by decide
theorem cert_e1211182379974 : check e1211182379974 [[],[]] .smaller = true := by decide
def e1211182379998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211182379998 : Closed e1211182379998 ∧ code e1211182379998 = 5609228891102 := by decide
theorem cert_e1211182379998 : check e1211182379998 [[],[]] .smaller = true := by decide
def e1211182380014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211182380014 : Closed e1211182380014 ∧ code e1211182380014 = 5609228891118 := by decide
theorem cert_e1211182380014 : check e1211182380014 [[],[]] .smaller = true := by decide
def e1211182380026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 5) (.var 0)))))))))))
theorem wire_e1211182380026 : Closed e1211182380026 ∧ code e1211182380026 = 5609228891130 := by decide
theorem cert_e1211182380026 : check e1211182380026 [[],[]] .three = true := by decide
def e1211182381454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e1211182381454 : Closed e1211182381454 ∧ code e1211182381454 = 5609228892558 := by decide
theorem cert_e1211182381454 : check e1211182381454 [[],[]] .smaller = true := by decide
def e1211182381510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e1211182381510 : Closed e1211182381510 ∧ code e1211182381510 = 5609228892614 := by decide
theorem cert_e1211182381510 : check e1211182381510 [[],[]] .smaller = true := by decide
def e1211182381534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211182381534 : Closed e1211182381534 ∧ code e1211182381534 = 5609228892638 := by decide
theorem cert_e1211182381534 : check e1211182381534 [[],[]] .smaller = true := by decide
def e1211182381558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211182381558 : Closed e1211182381558 ∧ code e1211182381558 = 5609228892662 := by decide
theorem cert_e1211182381558 : check e1211182381558 [[],[]] .smaller = true := by decide
def e1211182382318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182382318 : Closed e1211182382318 ∧ code e1211182382318 = 5609228893422 := by decide
theorem cert_e1211182382318 : check e1211182382318 [[],[]] .smaller = true := by decide
def e1211182382326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182382326 : Closed e1211182382326 ∧ code e1211182382326 = 5609228893430 := by decide
theorem cert_e1211182382326 : check e1211182382326 [[],[]] .smaller = true := by decide
def e1211182382902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 5) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182382902 : Closed e1211182382902 ∧ code e1211182382902 = 5609228894006 := by decide
theorem cert_e1211182382902 : check e1211182382902 [[],[]] .three = true := by decide
def e1211182382906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 5) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182382906 : Closed e1211182382906 ∧ code e1211182382906 = 5609228894010 := by decide
theorem cert_e1211182382906 : check e1211182382906 [[],[]] .three = true := by decide
def e1211182439134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e1211182439134 : Closed e1211182439134 ∧ code e1211182439134 = 5609228950238 := by decide
theorem cert_e1211182439134 : check e1211182439134 [[],[]] .smaller = true := by decide
def e1211182439158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e1211182439158 : Closed e1211182439158 ∧ code e1211182439158 = 5609228950262 := by decide
theorem cert_e1211182439158 : check e1211182439158 [[],[]] .smaller = true := by decide
def e1211182439262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e1211182439262 : Closed e1211182439262 ∧ code e1211182439262 = 5609228950366 := by decide
theorem cert_e1211182439262 : check e1211182439262 [[],[]] .smaller = true := by decide
def e1211182439278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e1211182439278 : Closed e1211182439278 ∧ code e1211182439278 = 5609228950382 := by decide
theorem cert_e1211182439278 : check e1211182439278 [[],[]] .smaller = true := by decide
def e1211182439286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e1211182439286 : Closed e1211182439286 ∧ code e1211182439286 = 5609228950390 := by decide
theorem cert_e1211182439286 : check e1211182439286 [[],[]] .smaller = true := by decide
def e1211182439290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e1211182439290 : Closed e1211182439290 ∧ code e1211182439290 = 5609228950394 := by decide
theorem cert_e1211182439290 : check e1211182439290 [[],[]] .smaller = true := by decide
def e1211182439350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e1211182439350 : Closed e1211182439350 ∧ code e1211182439350 = 5609228950454 := by decide
theorem cert_e1211182439350 : check e1211182439350 [[],[]] .smaller = true := by decide
def e1211182439382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182439382 : Closed e1211182439382 ∧ code e1211182439382 = 5609228950486 := by decide
theorem cert_e1211182439382 : check e1211182439382 [[],[]] .smaller = true := by decide
def e1211182439386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182439386 : Closed e1211182439386 ∧ code e1211182439386 = 5609228950490 := by decide
theorem cert_e1211182439386 : check e1211182439386 [[],[]] .smaller = true := by decide
def e1211182439774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e1211182439774 : Closed e1211182439774 ∧ code e1211182439774 = 5609228950878 := by decide
theorem cert_e1211182439774 : check e1211182439774 [[],[]] .smaller = true := by decide
def e1211182439790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211182439790 : Closed e1211182439790 ∧ code e1211182439790 = 5609228950894 := by decide
theorem cert_e1211182439790 : check e1211182439790 [[],[]] .smaller = true := by decide
def e1211182439798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211182439798 : Closed e1211182439798 ∧ code e1211182439798 = 5609228950902 := by decide
theorem cert_e1211182439798 : check e1211182439798 [[],[]] .smaller = true := by decide
def e1211182439802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e1211182439802 : Closed e1211182439802 ∧ code e1211182439802 = 5609228950906 := by decide
theorem cert_e1211182439802 : check e1211182439802 [[],[]] .smaller = true := by decide
def e1211182439854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211182439854 : Closed e1211182439854 ∧ code e1211182439854 = 5609228950958 := by decide
theorem cert_e1211182439854 : check e1211182439854 [[],[]] .smaller = true := by decide
def e1211182439866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211182439866 : Closed e1211182439866 ∧ code e1211182439866 = 5609228950970 := by decide
theorem cert_e1211182439866 : check e1211182439866 [[],[]] .smaller = true := by decide
def e1211182439894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182439894 : Closed e1211182439894 ∧ code e1211182439894 = 5609228950998 := by decide
theorem cert_e1211182439894 : check e1211182439894 [[],[]] .smaller = true := by decide
def e1211182439898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182439898 : Closed e1211182439898 ∧ code e1211182439898 = 5609228951002 := by decide
theorem cert_e1211182439898 : check e1211182439898 [[],[]] .smaller = true := by decide
def e1211182439914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182439914 : Closed e1211182439914 ∧ code e1211182439914 = 5609228951018 := by decide
theorem cert_e1211182439914 : check e1211182439914 [[],[]] .smaller = true := by decide
def e1211182440118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211182440118 : Closed e1211182440118 ∧ code e1211182440118 = 5609228951222 := by decide
theorem cert_e1211182440118 : check e1211182440118 [[],[]] .smaller = true := by decide
def e1211182440150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182440150 : Closed e1211182440150 ∧ code e1211182440150 = 5609228951254 := by decide
theorem cert_e1211182440150 : check e1211182440150 [[],[]] .smaller = true := by decide
def e1211182440154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182440154 : Closed e1211182440154 ∧ code e1211182440154 = 5609228951258 := by decide
theorem cert_e1211182440154 : check e1211182440154 [[],[]] .smaller = true := by decide
def e1211182440278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182440278 : Closed e1211182440278 ∧ code e1211182440278 = 5609228951382 := by decide
theorem cert_e1211182440278 : check e1211182440278 [[],[]] .smaller = true := by decide
def e1211182440282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182440282 : Closed e1211182440282 ∧ code e1211182440282 = 5609228951386 := by decide
theorem cert_e1211182440282 : check e1211182440282 [[],[]] .smaller = true := by decide
def e1211182440298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182440298 : Closed e1211182440298 ∧ code e1211182440298 = 5609228951402 := by decide
theorem cert_e1211182440298 : check e1211182440298 [[],[]] .smaller = true := by decide
def e1211182441406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 4)))))))))
theorem wire_e1211182441406 : Closed e1211182441406 ∧ code e1211182441406 = 5609228952510 := by decide
theorem cert_e1211182441406 : check e1211182441406 [[],[]] .three = true := by decide
def e1211182441438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 3)))))))))
theorem wire_e1211182441438 : Closed e1211182441438 ∧ code e1211182441438 = 5609228952542 := by decide
theorem cert_e1211182441438 : check e1211182441438 [[],[]] .smaller = true := by decide
def e1211182441454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 2)))))))))
theorem wire_e1211182441454 : Closed e1211182441454 ∧ code e1211182441454 = 5609228952558 := by decide
theorem cert_e1211182441454 : check e1211182441454 [[],[]] .smaller = true := by decide
def e1211182441462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 5))) (.var 1)))))))))
theorem wire_e1211182441462 : Closed e1211182441462 ∧ code e1211182441462 = 5609228952566 := by decide
theorem cert_e1211182441462 : check e1211182441462 [[],[]] .three = true := by decide
def e1211182442206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e1211182442206 : Closed e1211182442206 ∧ code e1211182442206 = 5609228953310 := by decide
theorem cert_e1211182442206 : check e1211182442206 [[],[]] .smaller = true := by decide
def e1211182442230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e1211182442230 : Closed e1211182442230 ∧ code e1211182442230 = 5609228953334 := by decide
theorem cert_e1211182442230 : check e1211182442230 [[],[]] .smaller = true := by decide
def e1211182442334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e1211182442334 : Closed e1211182442334 ∧ code e1211182442334 = 5609228953438 := by decide
theorem cert_e1211182442334 : check e1211182442334 [[],[]] .smaller = true := by decide
def e1211182442350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e1211182442350 : Closed e1211182442350 ∧ code e1211182442350 = 5609228953454 := by decide
theorem cert_e1211182442350 : check e1211182442350 [[],[]] .smaller = true := by decide
def e1211182442358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e1211182442358 : Closed e1211182442358 ∧ code e1211182442358 = 5609228953462 := by decide
theorem cert_e1211182442358 : check e1211182442358 [[],[]] .smaller = true := by decide
def e1211182442362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e1211182442362 : Closed e1211182442362 ∧ code e1211182442362 = 5609228953466 := by decide
theorem cert_e1211182442362 : check e1211182442362 [[],[]] .smaller = true := by decide
def e1211182442422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e1211182442422 : Closed e1211182442422 ∧ code e1211182442422 = 5609228953526 := by decide
theorem cert_e1211182442422 : check e1211182442422 [[],[]] .smaller = true := by decide
def e1211182442454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e1211182442454 : Closed e1211182442454 ∧ code e1211182442454 = 5609228953558 := by decide
theorem cert_e1211182442454 : check e1211182442454 [[],[]] .smaller = true := by decide
def e1211182442458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e1211182442458 : Closed e1211182442458 ∧ code e1211182442458 = 5609228953562 := by decide
theorem cert_e1211182442458 : check e1211182442458 [[],[]] .smaller = true := by decide
def e1211182442974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211182442974 : Closed e1211182442974 ∧ code e1211182442974 = 5609228954078 := by decide
theorem cert_e1211182442974 : check e1211182442974 [[],[]] .smaller = true := by decide
def e1211182442998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211182442998 : Closed e1211182442998 ∧ code e1211182442998 = 5609228954102 := by decide
theorem cert_e1211182442998 : check e1211182442998 [[],[]] .smaller = true := by decide
def e1211182443646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 5))))))))))
theorem wire_e1211182443646 : Closed e1211182443646 ∧ code e1211182443646 = 5609228954750 := by decide
theorem cert_e1211182443646 : check e1211182443646 [[],[]] .three = true := by decide
end Blc.Floor42
