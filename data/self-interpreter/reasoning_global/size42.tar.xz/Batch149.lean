import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186467806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186467806 : Closed e1211186467806 ∧ code e1211186467806 = 5609232978910 := by decide
theorem cert_e1211186467806 : check e1211186467806 [[],[]] .three = true := by decide
def e1211186467810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211186467810 : Closed e1211186467810 ∧ code e1211186467810 = 5609232978914 := by decide
theorem cert_e1211186467810 : check e1211186467810 [[],[]] .three = true := by decide
def e1211186467822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186467822 : Closed e1211186467822 ∧ code e1211186467822 = 5609232978926 := by decide
theorem cert_e1211186467822 : check e1211186467822 [[],[]] .three = true := by decide
def e1211186468926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e1211186468926 : Closed e1211186468926 ∧ code e1211186468926 = 5609232980030 := by decide
theorem cert_e1211186468926 : check e1211186468926 [[],[]] .smaller = true := by decide
def e1211186469342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186469342 : Closed e1211186469342 ∧ code e1211186469342 = 5609232980446 := by decide
theorem cert_e1211186469342 : check e1211186469342 [[],[]] .three = true := by decide
def e1211186469346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211186469346 : Closed e1211186469346 ∧ code e1211186469346 = 5609232980450 := by decide
theorem cert_e1211186469346 : check e1211186469346 [[],[]] .smaller = true := by decide
def e1211186469358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186469358 : Closed e1211186469358 ∧ code e1211186469358 = 5609232980462 := by decide
theorem cert_e1211186469358 : check e1211186469358 [[],[]] .smaller = true := by decide
def e1211186469366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186469366 : Closed e1211186469366 ∧ code e1211186469366 = 5609232980470 := by decide
theorem cert_e1211186469366 : check e1211186469366 [[],[]] .three = true := by decide
def e1211186469918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186469918 : Closed e1211186469918 ∧ code e1211186469918 = 5609232981022 := by decide
theorem cert_e1211186469918 : check e1211186469918 [[],[]] .smaller = true := by decide
def e1211186469942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186469942 : Closed e1211186469942 ∧ code e1211186469942 = 5609232981046 := by decide
theorem cert_e1211186469942 : check e1211186469942 [[],[]] .smaller = true := by decide
def e1211186469946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186469946 : Closed e1211186469946 ∧ code e1211186469946 = 5609232981050 := by decide
theorem cert_e1211186469946 : check e1211186469946 [[],[]] .smaller = true := by decide
def e1211186470086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186470086 : Closed e1211186470086 ∧ code e1211186470086 = 5609232981190 := by decide
theorem cert_e1211186470086 : check e1211186470086 [[],[]] .smaller = true := by decide
def e1211186470110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186470110 : Closed e1211186470110 ∧ code e1211186470110 = 5609232981214 := by decide
theorem cert_e1211186470110 : check e1211186470110 [[],[]] .three = true := by decide
def e1211186470114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186470114 : Closed e1211186470114 ∧ code e1211186470114 = 5609232981218 := by decide
theorem cert_e1211186470114 : check e1211186470114 [[],[]] .smaller = true := by decide
def e1211186470126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186470126 : Closed e1211186470126 ∧ code e1211186470126 = 5609232981230 := by decide
theorem cert_e1211186470126 : check e1211186470126 [[],[]] .smaller = true := by decide
def e1211186470134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186470134 : Closed e1211186470134 ∧ code e1211186470134 = 5609232981238 := by decide
theorem cert_e1211186470134 : check e1211186470134 [[],[]] .smaller = true := by decide
def e1211186470138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186470138 : Closed e1211186470138 ∧ code e1211186470138 = 5609232981242 := by decide
theorem cert_e1211186470138 : check e1211186470138 [[],[]] .three = true := by decide
def e1211186470414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186470414 : Closed e1211186470414 ∧ code e1211186470414 = 5609232981518 := by decide
theorem cert_e1211186470414 : check e1211186470414 [[],[]] .three = true := by decide
def e1211186470426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186470426 : Closed e1211186470426 ∧ code e1211186470426 = 5609232981530 := by decide
theorem cert_e1211186470426 : check e1211186470426 [[],[]] .three = true := by decide
def e1211186470462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 4))))))))
theorem wire_e1211186470462 : Closed e1211186470462 ∧ code e1211186470462 = 5609232981566 := by decide
theorem cert_e1211186470462 : check e1211186470462 [[],[]] .three = true := by decide
def e1211186470498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186470498 : Closed e1211186470498 ∧ code e1211186470498 = 5609232981602 := by decide
theorem cert_e1211186470498 : check e1211186470498 [[],[]] .three = true := by decide
def e1211186470510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186470510 : Closed e1211186470510 ∧ code e1211186470510 = 5609232981614 := by decide
theorem cert_e1211186470510 : check e1211186470510 [[],[]] .three = true := by decide
def e1211186470518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186470518 : Closed e1211186470518 ∧ code e1211186470518 = 5609232981622 := by decide
theorem cert_e1211186470518 : check e1211186470518 [[],[]] .three = true := by decide
def e1211186470522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186470522 : Closed e1211186470522 ∧ code e1211186470522 = 5609232981626 := by decide
theorem cert_e1211186470522 : check e1211186470522 [[],[]] .three = true := by decide
def e1211186471158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211186471158 : Closed e1211186471158 ∧ code e1211186471158 = 5609232982262 := by decide
theorem cert_e1211186471158 : check e1211186471158 [[],[]] .smaller = true := by decide
def e1211186471350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211186471350 : Closed e1211186471350 ∧ code e1211186471350 = 5609232982454 := by decide
theorem cert_e1211186471350 : check e1211186471350 [[],[]] .smaller = true := by decide
def e1211186471354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211186471354 : Closed e1211186471354 ∧ code e1211186471354 = 5609232982458 := by decide
theorem cert_e1211186471354 : check e1211186471354 [[],[]] .smaller = true := by decide
def e1211186471382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211186471382 : Closed e1211186471382 ∧ code e1211186471382 = 5609232982486 := by decide
theorem cert_e1211186471382 : check e1211186471382 [[],[]] .smaller = true := by decide
def e1211186471402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211186471402 : Closed e1211186471402 ∧ code e1211186471402 = 5609232982506 := by decide
theorem cert_e1211186471402 : check e1211186471402 [[],[]] .smaller = true := by decide
def e1211186471542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186471542 : Closed e1211186471542 ∧ code e1211186471542 = 5609232982646 := by decide
theorem cert_e1211186471542 : check e1211186471542 [[],[]] .smaller = true := by decide
def e1211186471734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186471734 : Closed e1211186471734 ∧ code e1211186471734 = 5609232982838 := by decide
theorem cert_e1211186471734 : check e1211186471734 [[],[]] .smaller = true := by decide
def e1211186471738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186471738 : Closed e1211186471738 ∧ code e1211186471738 = 5609232982842 := by decide
theorem cert_e1211186471738 : check e1211186471738 [[],[]] .smaller = true := by decide
def e1211186471822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211186471822 : Closed e1211186471822 ∧ code e1211186471822 = 5609232982926 := by decide
theorem cert_e1211186471822 : check e1211186471822 [[],[]] .smaller = true := by decide
def e1211186471834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186471834 : Closed e1211186471834 ∧ code e1211186471834 = 5609232982938 := by decide
theorem cert_e1211186471834 : check e1211186471834 [[],[]] .smaller = true := by decide
def e1211186471902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e1211186471902 : Closed e1211186471902 ∧ code e1211186471902 = 5609232983006 := by decide
theorem cert_e1211186471902 : check e1211186471902 [[],[]] .three = true := by decide
def e1211186471918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e1211186471918 : Closed e1211186471918 ∧ code e1211186471918 = 5609232983022 := by decide
theorem cert_e1211186471918 : check e1211186471918 [[],[]] .three = true := by decide
def e1211186472502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211186472502 : Closed e1211186472502 ∧ code e1211186472502 = 5609232983606 := by decide
theorem cert_e1211186472502 : check e1211186472502 [[],[]] .smaller = true := by decide
def e1211186472506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186472506 : Closed e1211186472506 ∧ code e1211186472506 = 5609232983610 := by decide
theorem cert_e1211186472506 : check e1211186472506 [[],[]] .smaller = true := by decide
def e1211186472590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211186472590 : Closed e1211186472590 ∧ code e1211186472590 = 5609232983694 := by decide
theorem cert_e1211186472590 : check e1211186472590 [[],[]] .smaller = true := by decide
def e1211186472646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186472646 : Closed e1211186472646 ∧ code e1211186472646 = 5609232983750 := by decide
theorem cert_e1211186472646 : check e1211186472646 [[],[]] .smaller = true := by decide
def e1211186472670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1211186472670 : Closed e1211186472670 ∧ code e1211186472670 = 5609232983774 := by decide
theorem cert_e1211186472670 : check e1211186472670 [[],[]] .three = true := by decide
def e1211186472694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1211186472694 : Closed e1211186472694 ∧ code e1211186472694 = 5609232983798 := by decide
theorem cert_e1211186472694 : check e1211186472694 [[],[]] .three = true := by decide
def e1211186472726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186472726 : Closed e1211186472726 ∧ code e1211186472726 = 5609232983830 := by decide
theorem cert_e1211186472726 : check e1211186472726 [[],[]] .smaller = true := by decide
def e1211186472730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186472730 : Closed e1211186472730 ∧ code e1211186472730 = 5609232983834 := by decide
theorem cert_e1211186472730 : check e1211186472730 [[],[]] .smaller = true := by decide
def e1211186472774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186472774 : Closed e1211186472774 ∧ code e1211186472774 = 5609232983878 := by decide
theorem cert_e1211186472774 : check e1211186472774 [[],[]] .smaller = true := by decide
def e1211186472798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1211186472798 : Closed e1211186472798 ∧ code e1211186472798 = 5609232983902 := by decide
theorem cert_e1211186472798 : check e1211186472798 [[],[]] .three = true := by decide
def e1211186472802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186472802 : Closed e1211186472802 ∧ code e1211186472802 = 5609232983906 := by decide
theorem cert_e1211186472802 : check e1211186472802 [[],[]] .smaller = true := by decide
def e1211186472814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211186472814 : Closed e1211186472814 ∧ code e1211186472814 = 5609232983918 := by decide
theorem cert_e1211186472814 : check e1211186472814 [[],[]] .smaller = true := by decide
def e1211186472822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211186472822 : Closed e1211186472822 ∧ code e1211186472822 = 5609232983926 := by decide
theorem cert_e1211186472822 : check e1211186472822 [[],[]] .smaller = true := by decide
def e1211186472826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1211186472826 : Closed e1211186472826 ∧ code e1211186472826 = 5609232983930 := by decide
theorem cert_e1211186472826 : check e1211186472826 [[],[]] .three = true := by decide
def e1211186472886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211186472886 : Closed e1211186472886 ∧ code e1211186472886 = 5609232983990 := by decide
theorem cert_e1211186472886 : check e1211186472886 [[],[]] .smaller = true := by decide
def e1211186472918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1211186472918 : Closed e1211186472918 ∧ code e1211186472918 = 5609232984022 := by decide
theorem cert_e1211186472918 : check e1211186472918 [[],[]] .three = true := by decide
def e1211186472922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1211186472922 : Closed e1211186472922 ∧ code e1211186472922 = 5609232984026 := by decide
theorem cert_e1211186472922 : check e1211186472922 [[],[]] .three = true := by decide
def e1211186473070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186473070 : Closed e1211186473070 ∧ code e1211186473070 = 5609232984174 := by decide
theorem cert_e1211186473070 : check e1211186473070 [[],[]] .smaller = true := by decide
def e1211186473082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186473082 : Closed e1211186473082 ∧ code e1211186473082 = 5609232984186 := by decide
theorem cert_e1211186473082 : check e1211186473082 [[],[]] .smaller = true := by decide
def e1211186473358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186473358 : Closed e1211186473358 ∧ code e1211186473358 = 5609232984462 := by decide
theorem cert_e1211186473358 : check e1211186473358 [[],[]] .smaller = true := by decide
def e1211186473414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186473414 : Closed e1211186473414 ∧ code e1211186473414 = 5609232984518 := by decide
theorem cert_e1211186473414 : check e1211186473414 [[],[]] .smaller = true := by decide
def e1211186473438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186473438 : Closed e1211186473438 ∧ code e1211186473438 = 5609232984542 := by decide
theorem cert_e1211186473438 : check e1211186473438 [[],[]] .three = true := by decide
def e1211186473462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186473462 : Closed e1211186473462 ∧ code e1211186473462 = 5609232984566 := by decide
theorem cert_e1211186473462 : check e1211186473462 [[],[]] .three = true := by decide
def e1211186474014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186474014 : Closed e1211186474014 ∧ code e1211186474014 = 5609232985118 := by decide
theorem cert_e1211186474014 : check e1211186474014 [[],[]] .smaller = true := by decide
def e1211186474038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186474038 : Closed e1211186474038 ∧ code e1211186474038 = 5609232985142 := by decide
theorem cert_e1211186474038 : check e1211186474038 [[],[]] .smaller = true := by decide
def e1211186474042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186474042 : Closed e1211186474042 ∧ code e1211186474042 = 5609232985146 := by decide
theorem cert_e1211186474042 : check e1211186474042 [[],[]] .smaller = true := by decide
def e1211186474182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186474182 : Closed e1211186474182 ∧ code e1211186474182 = 5609232985286 := by decide
theorem cert_e1211186474182 : check e1211186474182 [[],[]] .smaller = true := by decide
def e1211186474206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186474206 : Closed e1211186474206 ∧ code e1211186474206 = 5609232985310 := by decide
theorem cert_e1211186474206 : check e1211186474206 [[],[]] .three = true := by decide
def e1211186474210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186474210 : Closed e1211186474210 ∧ code e1211186474210 = 5609232985314 := by decide
theorem cert_e1211186474210 : check e1211186474210 [[],[]] .smaller = true := by decide
def e1211186474222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186474222 : Closed e1211186474222 ∧ code e1211186474222 = 5609232985326 := by decide
theorem cert_e1211186474222 : check e1211186474222 [[],[]] .smaller = true := by decide
def e1211186474230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186474230 : Closed e1211186474230 ∧ code e1211186474230 = 5609232985334 := by decide
theorem cert_e1211186474230 : check e1211186474230 [[],[]] .smaller = true := by decide
def e1211186474234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186474234 : Closed e1211186474234 ∧ code e1211186474234 = 5609232985338 := by decide
theorem cert_e1211186474234 : check e1211186474234 [[],[]] .three = true := by decide
def e1211186474558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e1211186474558 : Closed e1211186474558 ∧ code e1211186474558 = 5609232985662 := by decide
theorem cert_e1211186474558 : check e1211186474558 [[],[]] .three = true := by decide
def e1211186474614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186474614 : Closed e1211186474614 ∧ code e1211186474614 = 5609232985718 := by decide
theorem cert_e1211186474614 : check e1211186474614 [[],[]] .smaller = true := by decide
def e1211186474782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e1211186474782 : Closed e1211186474782 ∧ code e1211186474782 = 5609232985886 := by decide
theorem cert_e1211186474782 : check e1211186474782 [[],[]] .three = true := by decide
def e1211186474806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186474806 : Closed e1211186474806 ∧ code e1211186474806 = 5609232985910 := by decide
theorem cert_e1211186474806 : check e1211186474806 [[],[]] .three = true := by decide
def e1211186474810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186474810 : Closed e1211186474810 ∧ code e1211186474810 = 5609232985914 := by decide
theorem cert_e1211186474810 : check e1211186474810 [[],[]] .three = true := by decide
def e1211186475126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211186475126 : Closed e1211186475126 ∧ code e1211186475126 = 5609232986230 := by decide
theorem cert_e1211186475126 : check e1211186475126 [[],[]] .three = true := by decide
def e1211186475130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186475130 : Closed e1211186475130 ∧ code e1211186475130 = 5609232986234 := by decide
theorem cert_e1211186475130 : check e1211186475130 [[],[]] .three = true := by decide
def e1211186475222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211186475222 : Closed e1211186475222 ∧ code e1211186475222 = 5609232986326 := by decide
theorem cert_e1211186475222 : check e1211186475222 [[],[]] .three = true := by decide
def e1211186475318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186475318 : Closed e1211186475318 ∧ code e1211186475318 = 5609232986422 := by decide
theorem cert_e1211186475318 : check e1211186475318 [[],[]] .three = true := by decide
def e1211186475322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186475322 : Closed e1211186475322 ∧ code e1211186475322 = 5609232986426 := by decide
theorem cert_e1211186475322 : check e1211186475322 [[],[]] .three = true := by decide
def e1211186475406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211186475406 : Closed e1211186475406 ∧ code e1211186475406 = 5609232986510 := by decide
theorem cert_e1211186475406 : check e1211186475406 [[],[]] .three = true := by decide
def e1211186475462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186475462 : Closed e1211186475462 ∧ code e1211186475462 = 5609232986566 := by decide
theorem cert_e1211186475462 : check e1211186475462 [[],[]] .three = true := by decide
def e1211186475486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e1211186475486 : Closed e1211186475486 ∧ code e1211186475486 = 5609232986590 := by decide
theorem cert_e1211186475486 : check e1211186475486 [[],[]] .three = true := by decide
def e1211186475502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211186475502 : Closed e1211186475502 ∧ code e1211186475502 = 5609232986606 := by decide
theorem cert_e1211186475502 : check e1211186475502 [[],[]] .three = true := by decide
def e1211186475510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e1211186475510 : Closed e1211186475510 ∧ code e1211186475510 = 5609232986614 := by decide
theorem cert_e1211186475510 : check e1211186475510 [[],[]] .three = true := by decide
def e1211186475798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186475798 : Closed e1211186475798 ∧ code e1211186475798 = 5609232986902 := by decide
theorem cert_e1211186475798 : check e1211186475798 [[],[]] .three = true := by decide
def e1211186475874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186475874 : Closed e1211186475874 ∧ code e1211186475874 = 5609232986978 := by decide
theorem cert_e1211186475874 : check e1211186475874 [[],[]] .three = true := by decide
def e1211186475886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211186475886 : Closed e1211186475886 ∧ code e1211186475886 = 5609232986990 := by decide
theorem cert_e1211186475886 : check e1211186475886 [[],[]] .three = true := by decide
def e1211186475894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211186475894 : Closed e1211186475894 ∧ code e1211186475894 = 5609232986998 := by decide
theorem cert_e1211186475894 : check e1211186475894 [[],[]] .three = true := by decide
def e1211186475914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186475914 : Closed e1211186475914 ∧ code e1211186475914 = 5609232987018 := by decide
theorem cert_e1211186475914 : check e1211186475914 [[],[]] .three = true := by decide
def e1211186475938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186475938 : Closed e1211186475938 ∧ code e1211186475938 = 5609232987042 := by decide
theorem cert_e1211186475938 : check e1211186475938 [[],[]] .three = true := by decide
def e1211186475950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211186475950 : Closed e1211186475950 ∧ code e1211186475950 = 5609232987054 := by decide
theorem cert_e1211186475950 : check e1211186475950 [[],[]] .three = true := by decide
def e1211186475958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e1211186475958 : Closed e1211186475958 ∧ code e1211186475958 = 5609232987062 := by decide
theorem cert_e1211186475958 : check e1211186475958 [[],[]] .three = true := by decide
def e1211186475962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211186475962 : Closed e1211186475962 ∧ code e1211186475962 = 5609232987066 := by decide
theorem cert_e1211186475962 : check e1211186475962 [[],[]] .three = true := by decide
def e1211186475990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211186475990 : Closed e1211186475990 ∧ code e1211186475990 = 5609232987094 := by decide
theorem cert_e1211186475990 : check e1211186475990 [[],[]] .three = true := by decide
def e1211186475994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211186475994 : Closed e1211186475994 ∧ code e1211186475994 = 5609232987098 := by decide
theorem cert_e1211186475994 : check e1211186475994 [[],[]] .three = true := by decide
def e1211186476062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186476062 : Closed e1211186476062 ∧ code e1211186476062 = 5609232987166 := by decide
theorem cert_e1211186476062 : check e1211186476062 [[],[]] .three = true := by decide
def e1211186476258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186476258 : Closed e1211186476258 ∧ code e1211186476258 = 5609232987362 := by decide
theorem cert_e1211186476258 : check e1211186476258 [[],[]] .three = true := by decide
def e1211186476270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186476270 : Closed e1211186476270 ∧ code e1211186476270 = 5609232987374 := by decide
theorem cert_e1211186476270 : check e1211186476270 [[],[]] .three = true := by decide
def e1211186476278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186476278 : Closed e1211186476278 ∧ code e1211186476278 = 5609232987382 := by decide
theorem cert_e1211186476278 : check e1211186476278 [[],[]] .three = true := by decide
def e1211186476558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186476558 : Closed e1211186476558 ∧ code e1211186476558 = 5609232987662 := by decide
theorem cert_e1211186476558 : check e1211186476558 [[],[]] .three = true := by decide
def e1211186476570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186476570 : Closed e1211186476570 ∧ code e1211186476570 = 5609232987674 := by decide
theorem cert_e1211186476570 : check e1211186476570 [[],[]] .three = true := by decide
def e1211186476606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e1211186476606 : Closed e1211186476606 ∧ code e1211186476606 = 5609232987710 := by decide
theorem cert_e1211186476606 : check e1211186476606 [[],[]] .three = true := by decide
def e1211186476642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186476642 : Closed e1211186476642 ∧ code e1211186476642 = 5609232987746 := by decide
theorem cert_e1211186476642 : check e1211186476642 [[],[]] .three = true := by decide
def e1211186476654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186476654 : Closed e1211186476654 ∧ code e1211186476654 = 5609232987758 := by decide
theorem cert_e1211186476654 : check e1211186476654 [[],[]] .three = true := by decide
def e1211186476662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186476662 : Closed e1211186476662 ∧ code e1211186476662 = 5609232987766 := by decide
theorem cert_e1211186476662 : check e1211186476662 [[],[]] .three = true := by decide
def e1211186476666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186476666 : Closed e1211186476666 ∧ code e1211186476666 = 5609232987770 := by decide
theorem cert_e1211186476666 : check e1211186476666 [[],[]] .three = true := by decide
def e1211186476830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211186476830 : Closed e1211186476830 ∧ code e1211186476830 = 5609232987934 := by decide
theorem cert_e1211186476830 : check e1211186476830 [[],[]] .three = true := by decide
def e1211186476854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186476854 : Closed e1211186476854 ∧ code e1211186476854 = 5609232987958 := by decide
theorem cert_e1211186476854 : check e1211186476854 [[],[]] .three = true := by decide
def e1211186476858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186476858 : Closed e1211186476858 ∧ code e1211186476858 = 5609232987962 := by decide
theorem cert_e1211186476858 : check e1211186476858 [[],[]] .three = true := by decide
def e1211186476942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e1211186476942 : Closed e1211186476942 ∧ code e1211186476942 = 5609232988046 := by decide
theorem cert_e1211186476942 : check e1211186476942 [[],[]] .three = true := by decide
def e1211186480990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 3)))))))
theorem wire_e1211186480990 : Closed e1211186480990 ∧ code e1211186480990 = 5609232992094 := by decide
theorem cert_e1211186480990 : check e1211186480990 [[],[]] .three = true := by decide
def e1211186481006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186481006 : Closed e1211186481006 ∧ code e1211186481006 = 5609232992110 := by decide
theorem cert_e1211186481006 : check e1211186481006 [[],[]] .smaller = true := by decide
def e1211186481014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186481014 : Closed e1211186481014 ∧ code e1211186481014 = 5609232992118 := by decide
theorem cert_e1211186481014 : check e1211186481014 [[],[]] .smaller = true := by decide
def e1211186481018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 3)) (.var 0)))))))
theorem wire_e1211186481018 : Closed e1211186481018 ∧ code e1211186481018 = 5609232992122 := by decide
theorem cert_e1211186481018 : check e1211186481018 [[],[]] .three = true := by decide
def e1211186481070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186481070 : Closed e1211186481070 ∧ code e1211186481070 = 5609232992174 := by decide
theorem cert_e1211186481070 : check e1211186481070 [[],[]] .smaller = true := by decide
def e1211186481082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186481082 : Closed e1211186481082 ∧ code e1211186481082 = 5609232992186 := by decide
theorem cert_e1211186481082 : check e1211186481082 [[],[]] .smaller = true := by decide
def e1211186481110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186481110 : Closed e1211186481110 ∧ code e1211186481110 = 5609232992214 := by decide
theorem cert_e1211186481110 : check e1211186481110 [[],[]] .smaller = true := by decide
def e1211186481114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186481114 : Closed e1211186481114 ∧ code e1211186481114 = 5609232992218 := by decide
theorem cert_e1211186481114 : check e1211186481114 [[],[]] .smaller = true := by decide
def e1211186481130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186481130 : Closed e1211186481130 ∧ code e1211186481130 = 5609232992234 := by decide
theorem cert_e1211186481130 : check e1211186481130 [[],[]] .three = true := by decide
def e1211186482526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e1211186482526 : Closed e1211186482526 ∧ code e1211186482526 = 5609232993630 := by decide
theorem cert_e1211186482526 : check e1211186482526 [[],[]] .three = true := by decide
def e1211186482554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e1211186482554 : Closed e1211186482554 ∧ code e1211186482554 = 5609232993658 := by decide
theorem cert_e1211186482554 : check e1211186482554 [[],[]] .three = true := by decide
def e1211186482606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186482606 : Closed e1211186482606 ∧ code e1211186482606 = 5609232993710 := by decide
theorem cert_e1211186482606 : check e1211186482606 [[],[]] .smaller = true := by decide
def e1211186482618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186482618 : Closed e1211186482618 ∧ code e1211186482618 = 5609232993722 := by decide
theorem cert_e1211186482618 : check e1211186482618 [[],[]] .smaller = true := by decide
def e1211186482666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186482666 : Closed e1211186482666 ∧ code e1211186482666 = 5609232993770 := by decide
theorem cert_e1211186482666 : check e1211186482666 [[],[]] .smaller = true := by decide
def e1211186482862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186482862 : Closed e1211186482862 ∧ code e1211186482862 = 5609232993966 := by decide
theorem cert_e1211186482862 : check e1211186482862 [[],[]] .smaller = true := by decide
def e1211186482874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186482874 : Closed e1211186482874 ∧ code e1211186482874 = 5609232993978 := by decide
theorem cert_e1211186482874 : check e1211186482874 [[],[]] .smaller = true := by decide
def e1211186483114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186483114 : Closed e1211186483114 ∧ code e1211186483114 = 5609232994218 := by decide
theorem cert_e1211186483114 : check e1211186483114 [[],[]] .smaller = true := by decide
def e1211186484062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1211186484062 : Closed e1211186484062 ∧ code e1211186484062 = 5609232995166 := by decide
theorem cert_e1211186484062 : check e1211186484062 [[],[]] .three = true := by decide
def e1211186484078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211186484078 : Closed e1211186484078 ∧ code e1211186484078 = 5609232995182 := by decide
theorem cert_e1211186484078 : check e1211186484078 [[],[]] .smaller = true := by decide
def e1211186484086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211186484086 : Closed e1211186484086 ∧ code e1211186484086 = 5609232995190 := by decide
theorem cert_e1211186484086 : check e1211186484086 [[],[]] .smaller = true := by decide
def e1211186484090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1211186484090 : Closed e1211186484090 ∧ code e1211186484090 = 5609232995194 := by decide
theorem cert_e1211186484090 : check e1211186484090 [[],[]] .three = true := by decide
def e1211186484142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211186484142 : Closed e1211186484142 ∧ code e1211186484142 = 5609232995246 := by decide
theorem cert_e1211186484142 : check e1211186484142 [[],[]] .smaller = true := by decide
def e1211186484154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211186484154 : Closed e1211186484154 ∧ code e1211186484154 = 5609232995258 := by decide
theorem cert_e1211186484154 : check e1211186484154 [[],[]] .smaller = true := by decide
def e1211186484182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211186484182 : Closed e1211186484182 ∧ code e1211186484182 = 5609232995286 := by decide
theorem cert_e1211186484182 : check e1211186484182 [[],[]] .smaller = true := by decide
def e1211186484186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211186484186 : Closed e1211186484186 ∧ code e1211186484186 = 5609232995290 := by decide
theorem cert_e1211186484186 : check e1211186484186 [[],[]] .smaller = true := by decide
def e1211186484202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1211186484202 : Closed e1211186484202 ∧ code e1211186484202 = 5609232995306 := by decide
theorem cert_e1211186484202 : check e1211186484202 [[],[]] .three = true := by decide
def e1211186484446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186484446 : Closed e1211186484446 ∧ code e1211186484446 = 5609232995550 := by decide
theorem cert_e1211186484446 : check e1211186484446 [[],[]] .three = true := by decide
def e1211186484462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186484462 : Closed e1211186484462 ∧ code e1211186484462 = 5609232995566 := by decide
theorem cert_e1211186484462 : check e1211186484462 [[],[]] .smaller = true := by decide
def e1211186484470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186484470 : Closed e1211186484470 ∧ code e1211186484470 = 5609232995574 := by decide
theorem cert_e1211186484470 : check e1211186484470 [[],[]] .smaller = true := by decide
def e1211186484474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186484474 : Closed e1211186484474 ∧ code e1211186484474 = 5609232995578 := by decide
theorem cert_e1211186484474 : check e1211186484474 [[],[]] .three = true := by decide
def e1211186484846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186484846 : Closed e1211186484846 ∧ code e1211186484846 = 5609232995950 := by decide
theorem cert_e1211186484846 : check e1211186484846 [[],[]] .smaller = true := by decide
def e1211186484858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186484858 : Closed e1211186484858 ∧ code e1211186484858 = 5609232995962 := by decide
theorem cert_e1211186484858 : check e1211186484858 [[],[]] .smaller = true := by decide
def e1211186485046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186485046 : Closed e1211186485046 ∧ code e1211186485046 = 5609232996150 := by decide
theorem cert_e1211186485046 : check e1211186485046 [[],[]] .smaller = true := by decide
def e1211186485050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186485050 : Closed e1211186485050 ∧ code e1211186485050 = 5609232996154 := by decide
theorem cert_e1211186485050 : check e1211186485050 [[],[]] .smaller = true := by decide
def e1211186485146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186485146 : Closed e1211186485146 ∧ code e1211186485146 = 5609232996250 := by decide
theorem cert_e1211186485146 : check e1211186485146 [[],[]] .three = true := by decide
def e1211186485470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1211186485470 : Closed e1211186485470 ∧ code e1211186485470 = 5609232996574 := by decide
theorem cert_e1211186485470 : check e1211186485470 [[],[]] .three = true := by decide
def e1211186485486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211186485486 : Closed e1211186485486 ∧ code e1211186485486 = 5609232996590 := by decide
theorem cert_e1211186485486 : check e1211186485486 [[],[]] .smaller = true := by decide
def e1211186485494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211186485494 : Closed e1211186485494 ∧ code e1211186485494 = 5609232996598 := by decide
theorem cert_e1211186485494 : check e1211186485494 [[],[]] .smaller = true := by decide
def e1211186485498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1211186485498 : Closed e1211186485498 ∧ code e1211186485498 = 5609232996602 := by decide
theorem cert_e1211186485498 : check e1211186485498 [[],[]] .three = true := by decide
def e1211186485678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211186485678 : Closed e1211186485678 ∧ code e1211186485678 = 5609232996782 := by decide
theorem cert_e1211186485678 : check e1211186485678 [[],[]] .smaller = true := by decide
def e1211186485690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211186485690 : Closed e1211186485690 ∧ code e1211186485690 = 5609232996794 := by decide
theorem cert_e1211186485690 : check e1211186485690 [[],[]] .smaller = true := by decide
def e1211186485738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211186485738 : Closed e1211186485738 ∧ code e1211186485738 = 5609232996842 := by decide
theorem cert_e1211186485738 : check e1211186485738 [[],[]] .smaller = true := by decide
def e1211186485822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1211186485822 : Closed e1211186485822 ∧ code e1211186485822 = 5609232996926 := by decide
theorem cert_e1211186485822 : check e1211186485822 [[],[]] .three = true := by decide
def e1211186485870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186485870 : Closed e1211186485870 ∧ code e1211186485870 = 5609232996974 := by decide
theorem cert_e1211186485870 : check e1211186485870 [[],[]] .smaller = true := by decide
def e1211186485882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186485882 : Closed e1211186485882 ∧ code e1211186485882 = 5609232996986 := by decide
theorem cert_e1211186485882 : check e1211186485882 [[],[]] .smaller = true := by decide
def e1211186486046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211186486046 : Closed e1211186486046 ∧ code e1211186486046 = 5609232997150 := by decide
theorem cert_e1211186486046 : check e1211186486046 [[],[]] .smaller = true := by decide
def e1211186486158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211186486158 : Closed e1211186486158 ∧ code e1211186486158 = 5609232997262 := by decide
theorem cert_e1211186486158 : check e1211186486158 [[],[]] .smaller = true := by decide
def e1211186486170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186486170 : Closed e1211186486170 ∧ code e1211186486170 = 5609232997274 := by decide
theorem cert_e1211186486170 : check e1211186486170 [[],[]] .smaller = true := by decide
def e1211186486214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1211186486214 : Closed e1211186486214 ∧ code e1211186486214 = 5609232997318 := by decide
theorem cert_e1211186486214 : check e1211186486214 [[],[]] .three = true := by decide
def e1211186486238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 3)))))))
theorem wire_e1211186486238 : Closed e1211186486238 ∧ code e1211186486238 = 5609232997342 := by decide
theorem cert_e1211186486238 : check e1211186486238 [[],[]] .three = true := by decide
def e1211186486382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186486382 : Closed e1211186486382 ∧ code e1211186486382 = 5609232997486 := by decide
theorem cert_e1211186486382 : check e1211186486382 [[],[]] .smaller = true := by decide
end Blc.Floor42
