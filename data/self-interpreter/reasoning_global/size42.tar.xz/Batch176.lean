import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203202170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203202170 : Closed e1211203202170 ∧ code e1211203202170 = 5609249713274 := by decide
theorem cert_e1211203202170 : check e1211203202170 [[],[]] .chain = true := by decide
def e1211203202334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203202334 : Closed e1211203202334 ∧ code e1211203202334 = 5609249713438 := by decide
theorem cert_e1211203202334 : check e1211203202334 [[],[]] .chain = true := by decide
def e1211203202502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203202502 : Closed e1211203202502 ∧ code e1211203202502 = 5609249713606 := by decide
theorem cert_e1211203202502 : check e1211203202502 [[],[]] .chain = true := by decide
def e1211203202614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203202614 : Closed e1211203202614 ∧ code e1211203202614 = 5609249713718 := by decide
theorem cert_e1211203202614 : check e1211203202614 [[],[]] .chain = true := by decide
def e1211203202618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203202618 : Closed e1211203202618 ∧ code e1211203202618 = 5609249713722 := by decide
theorem cert_e1211203202618 : check e1211203202618 [[],[]] .chain = true := by decide
def e1211203202702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203202702 : Closed e1211203202702 ∧ code e1211203202702 = 5609249713806 := by decide
theorem cert_e1211203202702 : check e1211203202702 [[],[]] .chain = true := by decide
def e1211203202758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203202758 : Closed e1211203202758 ∧ code e1211203202758 = 5609249713862 := by decide
theorem cert_e1211203202758 : check e1211203202758 [[],[]] .chain = true := by decide
def e1211203203438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203203438 : Closed e1211203203438 ∧ code e1211203203438 = 5609249714542 := by decide
theorem cert_e1211203203438 : check e1211203203438 [[],[]] .chain = true := by decide
def e1211203203446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203203446 : Closed e1211203203446 ∧ code e1211203203446 = 5609249714550 := by decide
theorem cert_e1211203203446 : check e1211203203446 [[],[]] .chain = true := by decide
def e1211203204654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203204654 : Closed e1211203204654 ∧ code e1211203204654 = 5609249715758 := by decide
theorem cert_e1211203204654 : check e1211203204654 [[],[]] .chain = true := by decide
def e1211203204834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203204834 : Closed e1211203204834 ∧ code e1211203204834 = 5609249715938 := by decide
theorem cert_e1211203204834 : check e1211203204834 [[],[]] .chain = true := by decide
def e1211203204846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1211203204846 : Closed e1211203204846 ∧ code e1211203204846 = 5609249715950 := by decide
theorem cert_e1211203204846 : check e1211203204846 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203204886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203204886 : Closed e1211203204886 ∧ code e1211203204886 = 5609249715990 := by decide
theorem cert_e1211203204886 : check e1211203204886 [[],[]] .chain = true := by decide
def e1211203204962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203204962 : Closed e1211203204962 ∧ code e1211203204962 = 5609249716066 := by decide
theorem cert_e1211203204962 : check e1211203204962 [[],[]] .chain = true := by decide
def e1211203204974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1211203204974 : Closed e1211203204974 ∧ code e1211203204974 = 5609249716078 := by decide
theorem cert_e1211203204974 : check e1211203204974 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203204982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1211203204982 : Closed e1211203204982 ∧ code e1211203204982 = 5609249716086 := by decide
theorem cert_e1211203204982 : check e1211203204982 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203205294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203205294 : Closed e1211203205294 ∧ code e1211203205294 = 5609249716398 := by decide
theorem cert_e1211203205294 : check e1211203205294 [[],[]] .chain = true := by decide
def e1211203205306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203205306 : Closed e1211203205306 ∧ code e1211203205306 = 5609249716410 := by decide
theorem cert_e1211203205306 : check e1211203205306 [[],[]] .chain = true := by decide
def e1211203205678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203205678 : Closed e1211203205678 ∧ code e1211203205678 = 5609249716782 := by decide
theorem cert_e1211203205678 : check e1211203205678 [[],[]] .chain = true := by decide
def e1211203205858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203205858 : Closed e1211203205858 ∧ code e1211203205858 = 5609249716962 := by decide
theorem cert_e1211203205858 : check e1211203205858 [[],[]] .chain = true := by decide
def e1211203205870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1211203205870 : Closed e1211203205870 ∧ code e1211203205870 = 5609249716974 := by decide
theorem cert_e1211203205870 : check e1211203205870 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203205998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1211203205998 : Closed e1211203205998 ∧ code e1211203205998 = 5609249717102 := by decide
theorem cert_e1211203205998 : check e1211203205998 [[],[]] .chain = true := by decide
def e1211203206006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1211203206006 : Closed e1211203206006 ∧ code e1211203206006 = 5609249717110 := by decide
theorem cert_e1211203206006 : check e1211203206006 [[],[]] .chain = true := by decide
def e1211203206026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203206026 : Closed e1211203206026 ∧ code e1211203206026 = 5609249717130 := by decide
theorem cert_e1211203206026 : check e1211203206026 [[],[]] .chain = true := by decide
def e1211203206050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203206050 : Closed e1211203206050 ∧ code e1211203206050 = 5609249717154 := by decide
theorem cert_e1211203206050 : check e1211203206050 [[],[]] .chain = true := by decide
def e1211203206062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1211203206062 : Closed e1211203206062 ∧ code e1211203206062 = 5609249717166 := by decide
theorem cert_e1211203206062 : check e1211203206062 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203206070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1211203206070 : Closed e1211203206070 ∧ code e1211203206070 = 5609249717174 := by decide
theorem cert_e1211203206070 : check e1211203206070 [[],[]] .chain = true := by decide
def e1211203206074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1211203206074 : Closed e1211203206074 ∧ code e1211203206074 = 5609249717178 := by decide
theorem cert_e1211203206074 : check e1211203206074 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203206230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203206230 : Closed e1211203206230 ∧ code e1211203206230 = 5609249717334 := by decide
theorem cert_e1211203206230 : check e1211203206230 [[],[]] .chain = true := by decide
def e1211203206234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203206234 : Closed e1211203206234 ∧ code e1211203206234 = 5609249717338 := by decide
theorem cert_e1211203206234 : check e1211203206234 [[],[]] .chain = true := by decide
def e1211203206422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203206422 : Closed e1211203206422 ∧ code e1211203206422 = 5609249717526 := by decide
theorem cert_e1211203206422 : check e1211203206422 [[],[]] .chain = true := by decide
def e1211203206498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203206498 : Closed e1211203206498 ∧ code e1211203206498 = 5609249717602 := by decide
theorem cert_e1211203206498 : check e1211203206498 [[],[]] .chain = true := by decide
def e1211203206510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203206510 : Closed e1211203206510 ∧ code e1211203206510 = 5609249717614 := by decide
theorem cert_e1211203206510 : check e1211203206510 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203206518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203206518 : Closed e1211203206518 ∧ code e1211203206518 = 5609249717622 := by decide
theorem cert_e1211203206518 : check e1211203206518 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203206538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203206538 : Closed e1211203206538 ∧ code e1211203206538 = 5609249717642 := by decide
theorem cert_e1211203206538 : check e1211203206538 [[],[]] .chain = true := by decide
def e1211203206562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203206562 : Closed e1211203206562 ∧ code e1211203206562 = 5609249717666 := by decide
theorem cert_e1211203206562 : check e1211203206562 [[],[]] .chain = true := by decide
def e1211203206574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203206574 : Closed e1211203206574 ∧ code e1211203206574 = 5609249717678 := by decide
theorem cert_e1211203206574 : check e1211203206574 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203206582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e1211203206582 : Closed e1211203206582 ∧ code e1211203206582 = 5609249717686 := by decide
theorem cert_e1211203206582 : check e1211203206582 [[],[]] .chain = true := by decide
def e1211203206586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203206586 : Closed e1211203206586 ∧ code e1211203206586 = 5609249717690 := by decide
theorem cert_e1211203206586 : check e1211203206586 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203206614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203206614 : Closed e1211203206614 ∧ code e1211203206614 = 5609249717718 := by decide
theorem cert_e1211203206614 : checkPay e1211203206614 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211203206618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203206618 : Closed e1211203206618 ∧ code e1211203206618 = 5609249717722 := by decide
theorem cert_e1211203206618 : check e1211203206618 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203218286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1211203218286 : Closed e1211203218286 ∧ code e1211203218286 = 5609249729390 := by decide
theorem cert_e1211203218286 : check e1211203218286 [[],[]] .chain = true := by decide
def e1211203218294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1211203218294 : Closed e1211203218294 ∧ code e1211203218294 = 5609249729398 := by decide
theorem cert_e1211203218294 : check e1211203218294 [[],[]] .chain = true := by decide
def e1211203218358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1211203218358 : Closed e1211203218358 ∧ code e1211203218358 = 5609249729462 := by decide
theorem cert_e1211203218358 : check e1211203218358 [[],[]] .chain = true := by decide
def e1211203218798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203218798 : Closed e1211203218798 ∧ code e1211203218798 = 5609249729902 := by decide
theorem cert_e1211203218798 : check e1211203218798 [[],[]] .chain = true := by decide
def e1211203218806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203218806 : Closed e1211203218806 ∧ code e1211203218806 = 5609249729910 := by decide
theorem cert_e1211203218806 : check e1211203218806 [[],[]] .chain = true := by decide
def e1211203218862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203218862 : Closed e1211203218862 ∧ code e1211203218862 = 5609249729966 := by decide
theorem cert_e1211203218862 : check e1211203218862 [[],[]] .chain = true := by decide
def e1211203218874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203218874 : Closed e1211203218874 ∧ code e1211203218874 = 5609249729978 := by decide
theorem cert_e1211203218874 : check e1211203218874 [[],[]] .chain = true := by decide
def e1211203218902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203218902 : Closed e1211203218902 ∧ code e1211203218902 = 5609249730006 := by decide
theorem cert_e1211203218902 : check e1211203218902 [[],[]] .chain = true := by decide
def e1211203218906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203218906 : Closed e1211203218906 ∧ code e1211203218906 = 5609249730010 := by decide
theorem cert_e1211203218906 : check e1211203218906 [[],[]] .chain = true := by decide
def e1211203219126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203219126 : Closed e1211203219126 ∧ code e1211203219126 = 5609249730230 := by decide
theorem cert_e1211203219126 : check e1211203219126 [[],[]] .chain = true := by decide
def e1211203219158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203219158 : Closed e1211203219158 ∧ code e1211203219158 = 5609249730262 := by decide
theorem cert_e1211203219158 : check e1211203219158 [[],[]] .chain = true := by decide
def e1211203219162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203219162 : Closed e1211203219162 ∧ code e1211203219162 = 5609249730266 := by decide
theorem cert_e1211203219162 : check e1211203219162 [[],[]] .chain = true := by decide
def e1211203220846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203220846 : Closed e1211203220846 ∧ code e1211203220846 = 5609249731950 := by decide
theorem cert_e1211203220846 : check e1211203220846 [[],[]] .chain = true := by decide
def e1211203220854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203220854 : Closed e1211203220854 ∧ code e1211203220854 = 5609249731958 := by decide
theorem cert_e1211203220854 : check e1211203220854 [[],[]] .chain = true := by decide
def e1211203220910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203220910 : Closed e1211203220910 ∧ code e1211203220910 = 5609249732014 := by decide
theorem cert_e1211203220910 : check e1211203220910 [[],[]] .chain = true := by decide
def e1211203220922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203220922 : Closed e1211203220922 ∧ code e1211203220922 = 5609249732026 := by decide
theorem cert_e1211203220922 : check e1211203220922 [[],[]] .chain = true := by decide
def e1211203220950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203220950 : Closed e1211203220950 ∧ code e1211203220950 = 5609249732054 := by decide
theorem cert_e1211203220950 : check e1211203220950 [[],[]] .chain = true := by decide
def e1211203220954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203220954 : Closed e1211203220954 ∧ code e1211203220954 = 5609249732058 := by decide
theorem cert_e1211203220954 : check e1211203220954 [[],[]] .chain = true := by decide
def e1211203221166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203221166 : Closed e1211203221166 ∧ code e1211203221166 = 5609249732270 := by decide
theorem cert_e1211203221166 : check e1211203221166 [[],[]] .chain = true := by decide
def e1211203221178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203221178 : Closed e1211203221178 ∧ code e1211203221178 = 5609249732282 := by decide
theorem cert_e1211203221178 : check e1211203221178 [[],[]] .chain = true := by decide
def e1211203221226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203221226 : Closed e1211203221226 ∧ code e1211203221226 = 5609249732330 := by decide
theorem cert_e1211203221226 : check e1211203221226 [[],[]] .chain = true := by decide
def e1211203221334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203221334 : Closed e1211203221334 ∧ code e1211203221334 = 5609249732438 := by decide
theorem cert_e1211203221334 : check e1211203221334 [[],[]] .chain = true := by decide
def e1211203221338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203221338 : Closed e1211203221338 ∧ code e1211203221338 = 5609249732442 := by decide
theorem cert_e1211203221338 : check e1211203221338 [[],[]] .chain = true := by decide
def e1211203221354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203221354 : Closed e1211203221354 ∧ code e1211203221354 = 5609249732458 := by decide
theorem cert_e1211203221354 : check e1211203221354 [[],[]] .chain = true := by decide
def e1211203222198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203222198 : Closed e1211203222198 ∧ code e1211203222198 = 5609249733302 := by decide
theorem cert_e1211203222198 : check e1211203222198 [[],[]] .chain = true := by decide
def e1211203222230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203222230 : Closed e1211203222230 ∧ code e1211203222230 = 5609249733334 := by decide
theorem cert_e1211203222230 : check e1211203222230 [[],[]] .chain = true := by decide
def e1211203222234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203222234 : Closed e1211203222234 ∧ code e1211203222234 = 5609249733338 := by decide
theorem cert_e1211203222234 : check e1211203222234 [[],[]] .chain = true := by decide
def e1211203222358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203222358 : Closed e1211203222358 ∧ code e1211203222358 = 5609249733462 := by decide
theorem cert_e1211203222358 : check e1211203222358 [[],[]] .chain = true := by decide
def e1211203222362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203222362 : Closed e1211203222362 ∧ code e1211203222362 = 5609249733466 := by decide
theorem cert_e1211203222362 : check e1211203222362 [[],[]] .chain = true := by decide
def e1211203222378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203222378 : Closed e1211203222378 ∧ code e1211203222378 = 5609249733482 := by decide
theorem cert_e1211203222378 : check e1211203222378 [[],[]] .chain = true := by decide
def e1211203224430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203224430 : Closed e1211203224430 ∧ code e1211203224430 = 5609249735534 := by decide
theorem cert_e1211203224430 : check e1211203224430 [[],[]] .chain = true := by decide
def e1211203224438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203224438 : Closed e1211203224438 ∧ code e1211203224438 = 5609249735542 := by decide
theorem cert_e1211203224438 : check e1211203224438 [[],[]] .chain = true := by decide
def e1211203225838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203225838 : Closed e1211203225838 ∧ code e1211203225838 = 5609249736942 := by decide
theorem cert_e1211203225838 : check e1211203225838 [[],[]] .chain = true := by decide
def e1211203225846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203225846 : Closed e1211203225846 ∧ code e1211203225846 = 5609249736950 := by decide
theorem cert_e1211203225846 : check e1211203225846 [[],[]] .chain = true := by decide
def e1211203226398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203226398 : Closed e1211203226398 ∧ code e1211203226398 = 5609249737502 := by decide
theorem cert_e1211203226398 : check e1211203226398 [[],[]] .chain = true := by decide
def e1211203226510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203226510 : Closed e1211203226510 ∧ code e1211203226510 = 5609249737614 := by decide
theorem cert_e1211203226510 : check e1211203226510 [[],[]] .chain = true := by decide
def e1211203227182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203227182 : Closed e1211203227182 ∧ code e1211203227182 = 5609249738286 := by decide
theorem cert_e1211203227182 : check e1211203227182 [[],[]] .chain = true := by decide
def e1211203227362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203227362 : Closed e1211203227362 ∧ code e1211203227362 = 5609249738466 := by decide
theorem cert_e1211203227362 : check e1211203227362 [[],[]] .chain = true := by decide
def e1211203227374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e1211203227374 : Closed e1211203227374 ∧ code e1211203227374 = 5609249738478 := by decide
theorem cert_e1211203227374 : check e1211203227374 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203227414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203227414 : Closed e1211203227414 ∧ code e1211203227414 = 5609249738518 := by decide
theorem cert_e1211203227414 : check e1211203227414 [[],[]] .chain = true := by decide
def e1211203227490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203227490 : Closed e1211203227490 ∧ code e1211203227490 = 5609249738594 := by decide
theorem cert_e1211203227490 : check e1211203227490 [[],[]] .chain = true := by decide
def e1211203227502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e1211203227502 : Closed e1211203227502 ∧ code e1211203227502 = 5609249738606 := by decide
theorem cert_e1211203227502 : check e1211203227502 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203227510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e1211203227510 : Closed e1211203227510 ∧ code e1211203227510 = 5609249738614 := by decide
theorem cert_e1211203227510 : check e1211203227510 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203230574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1211203230574 : Closed e1211203230574 ∧ code e1211203230574 = 5609249741678 := by decide
theorem cert_e1211203230574 : check e1211203230574 [[],[]] .chain = true := by decide
def e1211203230582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1211203230582 : Closed e1211203230582 ∧ code e1211203230582 = 5609249741686 := by decide
theorem cert_e1211203230582 : check e1211203230582 [[],[]] .chain = true := by decide
def e1211203230646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1211203230646 : Closed e1211203230646 ∧ code e1211203230646 = 5609249741750 := by decide
theorem cert_e1211203230646 : check e1211203230646 [[],[]] .chain = true := by decide
def e1211203231086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203231086 : Closed e1211203231086 ∧ code e1211203231086 = 5609249742190 := by decide
theorem cert_e1211203231086 : check e1211203231086 [[],[]] .chain = true := by decide
def e1211203231094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203231094 : Closed e1211203231094 ∧ code e1211203231094 = 5609249742198 := by decide
theorem cert_e1211203231094 : check e1211203231094 [[],[]] .chain = true := by decide
def e1211203231150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203231150 : Closed e1211203231150 ∧ code e1211203231150 = 5609249742254 := by decide
theorem cert_e1211203231150 : check e1211203231150 [[],[]] .chain = true := by decide
def e1211203231162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203231162 : Closed e1211203231162 ∧ code e1211203231162 = 5609249742266 := by decide
theorem cert_e1211203231162 : check e1211203231162 [[],[]] .chain = true := by decide
def e1211203231190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203231190 : Closed e1211203231190 ∧ code e1211203231190 = 5609249742294 := by decide
theorem cert_e1211203231190 : check e1211203231190 [[],[]] .chain = true := by decide
def e1211203231194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203231194 : Closed e1211203231194 ∧ code e1211203231194 = 5609249742298 := by decide
theorem cert_e1211203231194 : check e1211203231194 [[],[]] .chain = true := by decide
def e1211203231414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1211203231414 : Closed e1211203231414 ∧ code e1211203231414 = 5609249742518 := by decide
theorem cert_e1211203231414 : check e1211203231414 [[],[]] .chain = true := by decide
def e1211203231446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203231446 : Closed e1211203231446 ∧ code e1211203231446 = 5609249742550 := by decide
theorem cert_e1211203231446 : check e1211203231446 [[],[]] .chain = true := by decide
def e1211203231450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203231450 : Closed e1211203231450 ∧ code e1211203231450 = 5609249742554 := by decide
theorem cert_e1211203231450 : check e1211203231450 [[],[]] .chain = true := by decide
def e1211203233646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1211203233646 : Closed e1211203233646 ∧ code e1211203233646 = 5609249744750 := by decide
theorem cert_e1211203233646 : check e1211203233646 [[],[]] .chain = true := by decide
def e1211203233654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1211203233654 : Closed e1211203233654 ∧ code e1211203233654 = 5609249744758 := by decide
theorem cert_e1211203233654 : check e1211203233654 [[],[]] .chain = true := by decide
def e1211203233718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1211203233718 : Closed e1211203233718 ∧ code e1211203233718 = 5609249744822 := by decide
theorem cert_e1211203233718 : check e1211203233718 [[],[]] .chain = true := by decide
def e1211203235054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203235054 : Closed e1211203235054 ∧ code e1211203235054 = 5609249746158 := by decide
theorem cert_e1211203235054 : check e1211203235054 [[],[]] .chain = true := by decide
def e1211203235062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203235062 : Closed e1211203235062 ∧ code e1211203235062 = 5609249746166 := by decide
theorem cert_e1211203235062 : check e1211203235062 [[],[]] .chain = true := by decide
def e1211203235446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203235446 : Closed e1211203235446 ∧ code e1211203235446 = 5609249746550 := by decide
theorem cert_e1211203235446 : check e1211203235446 [[],[]] .chain = true := by decide
def e1211203235950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203235950 : Closed e1211203235950 ∧ code e1211203235950 = 5609249747054 := by decide
theorem cert_e1211203235950 : check e1211203235950 [[],[]] .chain = true := by decide
def e1211203236126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203236126 : Closed e1211203236126 ∧ code e1211203236126 = 5609249747230 := by decide
theorem cert_e1211203236126 : check e1211203236126 [[],[]] .chain = true := by decide
def e1211203236322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e1211203236322 : Closed e1211203236322 ∧ code e1211203236322 = 5609249747426 := by decide
theorem cert_e1211203236322 : check e1211203236322 [[],[]] .chain = true := by decide
def e1211203236334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1211203236334 : Closed e1211203236334 ∧ code e1211203236334 = 5609249747438 := by decide
theorem cert_e1211203236334 : check e1211203236334 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203236718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203236718 : Closed e1211203236718 ∧ code e1211203236718 = 5609249747822 := by decide
theorem cert_e1211203236718 : check e1211203236718 [[],[]] .chain = true := by decide
def e1211203236726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203236726 : Closed e1211203236726 ∧ code e1211203236726 = 5609249747830 := by decide
theorem cert_e1211203236726 : check e1211203236726 [[],[]] .chain = true := by decide
def e1211203236782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203236782 : Closed e1211203236782 ∧ code e1211203236782 = 5609249747886 := by decide
theorem cert_e1211203236782 : check e1211203236782 [[],[]] .chain = true := by decide
def e1211203236794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203236794 : Closed e1211203236794 ∧ code e1211203236794 = 5609249747898 := by decide
theorem cert_e1211203236794 : check e1211203236794 [[],[]] .chain = true := by decide
def e1211203236822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203236822 : Closed e1211203236822 ∧ code e1211203236822 = 5609249747926 := by decide
theorem cert_e1211203236822 : check e1211203236822 [[],[]] .chain = true := by decide
def e1211203236826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203236826 : Closed e1211203236826 ∧ code e1211203236826 = 5609249747930 := by decide
theorem cert_e1211203236826 : check e1211203236826 [[],[]] .chain = true := by decide
def e1211203237102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203237102 : Closed e1211203237102 ∧ code e1211203237102 = 5609249748206 := by decide
theorem cert_e1211203237102 : check e1211203237102 [[],[]] .chain = true := by decide
def e1211203237110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203237110 : Closed e1211203237110 ∧ code e1211203237110 = 5609249748214 := by decide
theorem cert_e1211203237110 : check e1211203237110 [[],[]] .chain = true := by decide
def e1211203237486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203237486 : Closed e1211203237486 ∧ code e1211203237486 = 5609249748590 := by decide
theorem cert_e1211203237486 : check e1211203237486 [[],[]] .chain = true := by decide
def e1211203237498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203237498 : Closed e1211203237498 ∧ code e1211203237498 = 5609249748602 := by decide
theorem cert_e1211203237498 : check e1211203237498 [[],[]] .chain = true := by decide
def e1211203237638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203237638 : Closed e1211203237638 ∧ code e1211203237638 = 5609249748742 := by decide
theorem cert_e1211203237638 : check e1211203237638 [[],[]] .chain = true := by decide
def e1211203237662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1211203237662 : Closed e1211203237662 ∧ code e1211203237662 = 5609249748766 := by decide
theorem cert_e1211203237662 : check e1211203237662 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203237686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203237686 : Closed e1211203237686 ∧ code e1211203237686 = 5609249748790 := by decide
theorem cert_e1211203237686 : check e1211203237686 [[],[]] .chain = true := by decide
def e1211203237690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203237690 : Closed e1211203237690 ∧ code e1211203237690 = 5609249748794 := by decide
theorem cert_e1211203237690 : check e1211203237690 [[],[]] .chain = true := by decide
def e1211203237942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203237942 : Closed e1211203237942 ∧ code e1211203237942 = 5609249749046 := by decide
theorem cert_e1211203237942 : check e1211203237942 [[],[]] .chain = true := by decide
def e1211203238030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203238030 : Closed e1211203238030 ∧ code e1211203238030 = 5609249749134 := by decide
theorem cert_e1211203238030 : check e1211203238030 [[],[]] .chain = true := by decide
def e1211203238114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203238114 : Closed e1211203238114 ∧ code e1211203238114 = 5609249749218 := by decide
theorem cert_e1211203238114 : check e1211203238114 [[],[]] .chain = true := by decide
def e1211203238126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203238126 : Closed e1211203238126 ∧ code e1211203238126 = 5609249749230 := by decide
theorem cert_e1211203238126 : checkPay e1211203238126 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] 0 [] = true := by decide
def e1211203238134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203238134 : Closed e1211203238134 ∧ code e1211203238134 = 5609249749238 := by decide
theorem cert_e1211203238134 : check e1211203238134 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203238326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203238326 : Closed e1211203238326 ∧ code e1211203238326 = 5609249749430 := by decide
theorem cert_e1211203238326 : check e1211203238326 [[],[]] .chain = true := by decide
def e1211203238358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203238358 : Closed e1211203238358 ∧ code e1211203238358 = 5609249749462 := by decide
theorem cert_e1211203238358 : check e1211203238358 [[],[]] .chain = true := by decide
def e1211203238362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203238362 : Closed e1211203238362 ∧ code e1211203238362 = 5609249749466 := by decide
theorem cert_e1211203238362 : check e1211203238362 [[],[]] .chain = true := by decide
def e1211203238518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203238518 : Closed e1211203238518 ∧ code e1211203238518 = 5609249749622 := by decide
theorem cert_e1211203238518 : check e1211203238518 [[],[]] .chain = true := by decide
def e1211203238662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203238662 : Closed e1211203238662 ∧ code e1211203238662 = 5609249749766 := by decide
theorem cert_e1211203238662 : check e1211203238662 [[],[]] .chain = true := by decide
def e1211203238686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203238686 : Closed e1211203238686 ∧ code e1211203238686 = 5609249749790 := by decide
theorem cert_e1211203238686 : check e1211203238686 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203238710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203238710 : Closed e1211203238710 ∧ code e1211203238710 = 5609249749814 := by decide
theorem cert_e1211203238710 : check e1211203238710 [[],[]] .chain = true := by decide
def e1211203238714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203238714 : Closed e1211203238714 ∧ code e1211203238714 = 5609249749818 := by decide
theorem cert_e1211203238714 : check e1211203238714 [[],[]] .chain = true := by decide
def e1211203238798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203238798 : Closed e1211203238798 ∧ code e1211203238798 = 5609249749902 := by decide
theorem cert_e1211203238798 : check e1211203238798 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203240302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203240302 : Closed e1211203240302 ∧ code e1211203240302 = 5609249751406 := by decide
theorem cert_e1211203240302 : check e1211203240302 [[],[]] .chain = true := by decide
def e1211203240310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203240310 : Closed e1211203240310 ∧ code e1211203240310 = 5609249751414 := by decide
theorem cert_e1211203240310 : check e1211203240310 [[],[]] .chain = true := by decide
def e1211203240366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203240366 : Closed e1211203240366 ∧ code e1211203240366 = 5609249751470 := by decide
theorem cert_e1211203240366 : check e1211203240366 [[],[]] .chain = true := by decide
def e1211203240378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203240378 : Closed e1211203240378 ∧ code e1211203240378 = 5609249751482 := by decide
theorem cert_e1211203240378 : check e1211203240378 [[],[]] .chain = true := by decide
def e1211203241070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203241070 : Closed e1211203241070 ∧ code e1211203241070 = 5609249752174 := by decide
theorem cert_e1211203241070 : check e1211203241070 [[],[]] .chain = true := by decide
def e1211203241082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203241082 : Closed e1211203241082 ∧ code e1211203241082 = 5609249752186 := by decide
theorem cert_e1211203241082 : check e1211203241082 [[],[]] .chain = true := by decide
def e1211203241246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203241246 : Closed e1211203241246 ∧ code e1211203241246 = 5609249752350 := by decide
theorem cert_e1211203241246 : check e1211203241246 [[],[]] .chain = true := by decide
def e1211203241414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203241414 : Closed e1211203241414 ∧ code e1211203241414 = 5609249752518 := by decide
theorem cert_e1211203241414 : check e1211203241414 [[],[]] .chain = true := by decide
def e1211203241518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203241518 : Closed e1211203241518 ∧ code e1211203241518 = 5609249752622 := by decide
theorem cert_e1211203241518 : check e1211203241518 [[],[]] .chain = true := by decide
def e1211203241698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203241698 : Closed e1211203241698 ∧ code e1211203241698 = 5609249752802 := by decide
theorem cert_e1211203241698 : check e1211203241698 [[],[]] .chain = true := by decide
def e1211203241710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e1211203241710 : Closed e1211203241710 ∧ code e1211203241710 = 5609249752814 := by decide
theorem cert_e1211203241710 : check e1211203241710 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203241838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e1211203241838 : Closed e1211203241838 ∧ code e1211203241838 = 5609249752942 := by decide
theorem cert_e1211203241838 : check e1211203241838 [[],[]] .chain = true := by decide
def e1211203241846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e1211203241846 : Closed e1211203241846 ∧ code e1211203241846 = 5609249752950 := by decide
theorem cert_e1211203241846 : check e1211203241846 [[],[]] .chain = true := by decide
def e1211203241866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203241866 : Closed e1211203241866 ∧ code e1211203241866 = 5609249752970 := by decide
theorem cert_e1211203241866 : check e1211203241866 [[],[]] .chain = true := by decide
def e1211203241890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203241890 : Closed e1211203241890 ∧ code e1211203241890 = 5609249752994 := by decide
theorem cert_e1211203241890 : check e1211203241890 [[],[]] .chain = true := by decide
def e1211203241902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e1211203241902 : Closed e1211203241902 ∧ code e1211203241902 = 5609249753006 := by decide
theorem cert_e1211203241902 : check e1211203241902 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203241910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e1211203241910 : Closed e1211203241910 ∧ code e1211203241910 = 5609249753014 := by decide
theorem cert_e1211203241910 : check e1211203241910 [[],[]] .chain = true := by decide
def e1211203241914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e1211203241914 : Closed e1211203241914 ∧ code e1211203241914 = 5609249753018 := by decide
theorem cert_e1211203241914 : check e1211203241914 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203243374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203243374 : Closed e1211203243374 ∧ code e1211203243374 = 5609249754478 := by decide
theorem cert_e1211203243374 : check e1211203243374 [[],[]] .chain = true := by decide
def e1211203243382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203243382 : Closed e1211203243382 ∧ code e1211203243382 = 5609249754486 := by decide
theorem cert_e1211203243382 : check e1211203243382 [[],[]] .chain = true := by decide
def e1211203243438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203243438 : Closed e1211203243438 ∧ code e1211203243438 = 5609249754542 := by decide
theorem cert_e1211203243438 : check e1211203243438 [[],[]] .chain = true := by decide
def e1211203243450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203243450 : Closed e1211203243450 ∧ code e1211203243450 = 5609249754554 := by decide
theorem cert_e1211203243450 : check e1211203243450 [[],[]] .chain = true := by decide
def e1211203243478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203243478 : Closed e1211203243478 ∧ code e1211203243478 = 5609249754582 := by decide
theorem cert_e1211203243478 : check e1211203243478 [[],[]] .chain = true := by decide
def e1211203243482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203243482 : Closed e1211203243482 ∧ code e1211203243482 = 5609249754586 := by decide
theorem cert_e1211203243482 : check e1211203243482 [[],[]] .chain = true := by decide
def e1211203243694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203243694 : Closed e1211203243694 ∧ code e1211203243694 = 5609249754798 := by decide
theorem cert_e1211203243694 : check e1211203243694 [[],[]] .chain = true := by decide
def e1211203243706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203243706 : Closed e1211203243706 ∧ code e1211203243706 = 5609249754810 := by decide
theorem cert_e1211203243706 : check e1211203243706 [[],[]] .chain = true := by decide
end Blc.Floor42
