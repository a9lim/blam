import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186665974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186665974 : Closed e1211186665974 ∧ code e1211186665974 = 5609233177078 := by decide
theorem cert_e1211186665974 : check e1211186665974 [[],[]] .three = true := by decide
def e1211186666526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186666526 : Closed e1211186666526 ∧ code e1211186666526 = 5609233177630 := by decide
theorem cert_e1211186666526 : check e1211186666526 [[],[]] .smaller = true := by decide
def e1211186666550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186666550 : Closed e1211186666550 ∧ code e1211186666550 = 5609233177654 := by decide
theorem cert_e1211186666550 : check e1211186666550 [[],[]] .smaller = true := by decide
def e1211186666554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186666554 : Closed e1211186666554 ∧ code e1211186666554 = 5609233177658 := by decide
theorem cert_e1211186666554 : check e1211186666554 [[],[]] .smaller = true := by decide
def e1211186666694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186666694 : Closed e1211186666694 ∧ code e1211186666694 = 5609233177798 := by decide
theorem cert_e1211186666694 : check e1211186666694 [[],[]] .smaller = true := by decide
def e1211186666718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186666718 : Closed e1211186666718 ∧ code e1211186666718 = 5609233177822 := by decide
theorem cert_e1211186666718 : check e1211186666718 [[],[]] .three = true := by decide
def e1211186666722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186666722 : Closed e1211186666722 ∧ code e1211186666722 = 5609233177826 := by decide
theorem cert_e1211186666722 : check e1211186666722 [[],[]] .smaller = true := by decide
def e1211186666734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186666734 : Closed e1211186666734 ∧ code e1211186666734 = 5609233177838 := by decide
theorem cert_e1211186666734 : check e1211186666734 [[],[]] .smaller = true := by decide
def e1211186666742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186666742 : Closed e1211186666742 ∧ code e1211186666742 = 5609233177846 := by decide
theorem cert_e1211186666742 : check e1211186666742 [[],[]] .smaller = true := by decide
def e1211186666746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186666746 : Closed e1211186666746 ∧ code e1211186666746 = 5609233177850 := by decide
theorem cert_e1211186666746 : check e1211186666746 [[],[]] .three = true := by decide
def e1211186667022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186667022 : Closed e1211186667022 ∧ code e1211186667022 = 5609233178126 := by decide
theorem cert_e1211186667022 : check e1211186667022 [[],[]] .three = true := by decide
def e1211186667034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186667034 : Closed e1211186667034 ∧ code e1211186667034 = 5609233178138 := by decide
theorem cert_e1211186667034 : check e1211186667034 [[],[]] .three = true := by decide
def e1211186667070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 4))))))))
theorem wire_e1211186667070 : Closed e1211186667070 ∧ code e1211186667070 = 5609233178174 := by decide
theorem cert_e1211186667070 : check e1211186667070 [[],[]] .three = true := by decide
def e1211186667106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186667106 : Closed e1211186667106 ∧ code e1211186667106 = 5609233178210 := by decide
theorem cert_e1211186667106 : check e1211186667106 [[],[]] .three = true := by decide
def e1211186667118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186667118 : Closed e1211186667118 ∧ code e1211186667118 = 5609233178222 := by decide
theorem cert_e1211186667118 : check e1211186667118 [[],[]] .three = true := by decide
def e1211186667126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186667126 : Closed e1211186667126 ∧ code e1211186667126 = 5609233178230 := by decide
theorem cert_e1211186667126 : check e1211186667126 [[],[]] .three = true := by decide
def e1211186667130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186667130 : Closed e1211186667130 ∧ code e1211186667130 = 5609233178234 := by decide
theorem cert_e1211186667130 : check e1211186667130 [[],[]] .three = true := by decide
def e1211186667766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211186667766 : Closed e1211186667766 ∧ code e1211186667766 = 5609233178870 := by decide
theorem cert_e1211186667766 : check e1211186667766 [[],[]] .smaller = true := by decide
def e1211186667958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e1211186667958 : Closed e1211186667958 ∧ code e1211186667958 = 5609233179062 := by decide
theorem cert_e1211186667958 : check e1211186667958 [[],[]] .smaller = true := by decide
def e1211186667962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e1211186667962 : Closed e1211186667962 ∧ code e1211186667962 = 5609233179066 := by decide
theorem cert_e1211186667962 : check e1211186667962 [[],[]] .smaller = true := by decide
def e1211186667990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e1211186667990 : Closed e1211186667990 ∧ code e1211186667990 = 5609233179094 := by decide
theorem cert_e1211186667990 : check e1211186667990 [[],[]] .smaller = true := by decide
def e1211186668010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e1211186668010 : Closed e1211186668010 ∧ code e1211186668010 = 5609233179114 := by decide
theorem cert_e1211186668010 : check e1211186668010 [[],[]] .smaller = true := by decide
def e1211186668150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186668150 : Closed e1211186668150 ∧ code e1211186668150 = 5609233179254 := by decide
theorem cert_e1211186668150 : check e1211186668150 [[],[]] .smaller = true := by decide
def e1211186668342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186668342 : Closed e1211186668342 ∧ code e1211186668342 = 5609233179446 := by decide
theorem cert_e1211186668342 : check e1211186668342 [[],[]] .smaller = true := by decide
def e1211186668346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186668346 : Closed e1211186668346 ∧ code e1211186668346 = 5609233179450 := by decide
theorem cert_e1211186668346 : check e1211186668346 [[],[]] .smaller = true := by decide
def e1211186668430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211186668430 : Closed e1211186668430 ∧ code e1211186668430 = 5609233179534 := by decide
theorem cert_e1211186668430 : check e1211186668430 [[],[]] .smaller = true := by decide
def e1211186668442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186668442 : Closed e1211186668442 ∧ code e1211186668442 = 5609233179546 := by decide
theorem cert_e1211186668442 : check e1211186668442 [[],[]] .smaller = true := by decide
def e1211186668510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e1211186668510 : Closed e1211186668510 ∧ code e1211186668510 = 5609233179614 := by decide
theorem cert_e1211186668510 : check e1211186668510 [[],[]] .three = true := by decide
def e1211186668526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e1211186668526 : Closed e1211186668526 ∧ code e1211186668526 = 5609233179630 := by decide
theorem cert_e1211186668526 : check e1211186668526 [[],[]] .three = true := by decide
def e1211186669110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211186669110 : Closed e1211186669110 ∧ code e1211186669110 = 5609233180214 := by decide
theorem cert_e1211186669110 : check e1211186669110 [[],[]] .smaller = true := by decide
def e1211186669114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211186669114 : Closed e1211186669114 ∧ code e1211186669114 = 5609233180218 := by decide
theorem cert_e1211186669114 : check e1211186669114 [[],[]] .smaller = true := by decide
def e1211186669198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211186669198 : Closed e1211186669198 ∧ code e1211186669198 = 5609233180302 := by decide
theorem cert_e1211186669198 : check e1211186669198 [[],[]] .smaller = true := by decide
def e1211186669254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211186669254 : Closed e1211186669254 ∧ code e1211186669254 = 5609233180358 := by decide
theorem cert_e1211186669254 : check e1211186669254 [[],[]] .smaller = true := by decide
def e1211186669278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e1211186669278 : Closed e1211186669278 ∧ code e1211186669278 = 5609233180382 := by decide
theorem cert_e1211186669278 : check e1211186669278 [[],[]] .three = true := by decide
def e1211186669302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e1211186669302 : Closed e1211186669302 ∧ code e1211186669302 = 5609233180406 := by decide
theorem cert_e1211186669302 : check e1211186669302 [[],[]] .three = true := by decide
def e1211186669334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186669334 : Closed e1211186669334 ∧ code e1211186669334 = 5609233180438 := by decide
theorem cert_e1211186669334 : check e1211186669334 [[],[]] .smaller = true := by decide
def e1211186669338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211186669338 : Closed e1211186669338 ∧ code e1211186669338 = 5609233180442 := by decide
theorem cert_e1211186669338 : check e1211186669338 [[],[]] .smaller = true := by decide
def e1211186669382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211186669382 : Closed e1211186669382 ∧ code e1211186669382 = 5609233180486 := by decide
theorem cert_e1211186669382 : check e1211186669382 [[],[]] .smaller = true := by decide
def e1211186669406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e1211186669406 : Closed e1211186669406 ∧ code e1211186669406 = 5609233180510 := by decide
theorem cert_e1211186669406 : check e1211186669406 [[],[]] .three = true := by decide
def e1211186669410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186669410 : Closed e1211186669410 ∧ code e1211186669410 = 5609233180514 := by decide
theorem cert_e1211186669410 : check e1211186669410 [[],[]] .smaller = true := by decide
def e1211186669422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211186669422 : Closed e1211186669422 ∧ code e1211186669422 = 5609233180526 := by decide
theorem cert_e1211186669422 : check e1211186669422 [[],[]] .smaller = true := by decide
def e1211186669430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211186669430 : Closed e1211186669430 ∧ code e1211186669430 = 5609233180534 := by decide
theorem cert_e1211186669430 : check e1211186669430 [[],[]] .smaller = true := by decide
def e1211186669434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e1211186669434 : Closed e1211186669434 ∧ code e1211186669434 = 5609233180538 := by decide
theorem cert_e1211186669434 : check e1211186669434 [[],[]] .three = true := by decide
def e1211186669494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211186669494 : Closed e1211186669494 ∧ code e1211186669494 = 5609233180598 := by decide
theorem cert_e1211186669494 : check e1211186669494 [[],[]] .smaller = true := by decide
def e1211186669526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e1211186669526 : Closed e1211186669526 ∧ code e1211186669526 = 5609233180630 := by decide
theorem cert_e1211186669526 : check e1211186669526 [[],[]] .three = true := by decide
def e1211186669530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e1211186669530 : Closed e1211186669530 ∧ code e1211186669530 = 5609233180634 := by decide
theorem cert_e1211186669530 : check e1211186669530 [[],[]] .three = true := by decide
def e1211186669678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186669678 : Closed e1211186669678 ∧ code e1211186669678 = 5609233180782 := by decide
theorem cert_e1211186669678 : check e1211186669678 [[],[]] .smaller = true := by decide
def e1211186669690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186669690 : Closed e1211186669690 ∧ code e1211186669690 = 5609233180794 := by decide
theorem cert_e1211186669690 : check e1211186669690 [[],[]] .smaller = true := by decide
def e1211186669966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186669966 : Closed e1211186669966 ∧ code e1211186669966 = 5609233181070 := by decide
theorem cert_e1211186669966 : check e1211186669966 [[],[]] .smaller = true := by decide
def e1211186670022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186670022 : Closed e1211186670022 ∧ code e1211186670022 = 5609233181126 := by decide
theorem cert_e1211186670022 : check e1211186670022 [[],[]] .smaller = true := by decide
def e1211186670046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186670046 : Closed e1211186670046 ∧ code e1211186670046 = 5609233181150 := by decide
theorem cert_e1211186670046 : check e1211186670046 [[],[]] .three = true := by decide
def e1211186670070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186670070 : Closed e1211186670070 ∧ code e1211186670070 = 5609233181174 := by decide
theorem cert_e1211186670070 : check e1211186670070 [[],[]] .three = true := by decide
def e1211186670622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186670622 : Closed e1211186670622 ∧ code e1211186670622 = 5609233181726 := by decide
theorem cert_e1211186670622 : check e1211186670622 [[],[]] .smaller = true := by decide
def e1211186670646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186670646 : Closed e1211186670646 ∧ code e1211186670646 = 5609233181750 := by decide
theorem cert_e1211186670646 : check e1211186670646 [[],[]] .smaller = true := by decide
def e1211186670650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186670650 : Closed e1211186670650 ∧ code e1211186670650 = 5609233181754 := by decide
theorem cert_e1211186670650 : check e1211186670650 [[],[]] .smaller = true := by decide
def e1211186670790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186670790 : Closed e1211186670790 ∧ code e1211186670790 = 5609233181894 := by decide
theorem cert_e1211186670790 : check e1211186670790 [[],[]] .smaller = true := by decide
def e1211186670814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186670814 : Closed e1211186670814 ∧ code e1211186670814 = 5609233181918 := by decide
theorem cert_e1211186670814 : check e1211186670814 [[],[]] .three = true := by decide
def e1211186670818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186670818 : Closed e1211186670818 ∧ code e1211186670818 = 5609233181922 := by decide
theorem cert_e1211186670818 : check e1211186670818 [[],[]] .smaller = true := by decide
def e1211186670830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186670830 : Closed e1211186670830 ∧ code e1211186670830 = 5609233181934 := by decide
theorem cert_e1211186670830 : check e1211186670830 [[],[]] .smaller = true := by decide
def e1211186670838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186670838 : Closed e1211186670838 ∧ code e1211186670838 = 5609233181942 := by decide
theorem cert_e1211186670838 : check e1211186670838 [[],[]] .smaller = true := by decide
def e1211186670842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186670842 : Closed e1211186670842 ∧ code e1211186670842 = 5609233181946 := by decide
theorem cert_e1211186670842 : check e1211186670842 [[],[]] .three = true := by decide
def e1211186671166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 4))))))))
theorem wire_e1211186671166 : Closed e1211186671166 ∧ code e1211186671166 = 5609233182270 := by decide
theorem cert_e1211186671166 : check e1211186671166 [[],[]] .three = true := by decide
def e1211186671222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186671222 : Closed e1211186671222 ∧ code e1211186671222 = 5609233182326 := by decide
theorem cert_e1211186671222 : check e1211186671222 [[],[]] .smaller = true := by decide
def e1211186671390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 3))))))))
theorem wire_e1211186671390 : Closed e1211186671390 ∧ code e1211186671390 = 5609233182494 := by decide
theorem cert_e1211186671390 : check e1211186671390 [[],[]] .three = true := by decide
def e1211186671414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186671414 : Closed e1211186671414 ∧ code e1211186671414 = 5609233182518 := by decide
theorem cert_e1211186671414 : check e1211186671414 [[],[]] .three = true := by decide
def e1211186671418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186671418 : Closed e1211186671418 ∧ code e1211186671418 = 5609233182522 := by decide
theorem cert_e1211186671418 : check e1211186671418 [[],[]] .three = true := by decide
def e1211186671734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e1211186671734 : Closed e1211186671734 ∧ code e1211186671734 = 5609233182838 := by decide
theorem cert_e1211186671734 : check e1211186671734 [[],[]] .three = true := by decide
def e1211186671738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186671738 : Closed e1211186671738 ∧ code e1211186671738 = 5609233182842 := by decide
theorem cert_e1211186671738 : check e1211186671738 [[],[]] .three = true := by decide
def e1211186671830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e1211186671830 : Closed e1211186671830 ∧ code e1211186671830 = 5609233182934 := by decide
theorem cert_e1211186671830 : check e1211186671830 [[],[]] .three = true := by decide
def e1211186671926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186671926 : Closed e1211186671926 ∧ code e1211186671926 = 5609233183030 := by decide
theorem cert_e1211186671926 : check e1211186671926 [[],[]] .three = true := by decide
def e1211186671930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186671930 : Closed e1211186671930 ∧ code e1211186671930 = 5609233183034 := by decide
theorem cert_e1211186671930 : check e1211186671930 [[],[]] .three = true := by decide
def e1211186672014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e1211186672014 : Closed e1211186672014 ∧ code e1211186672014 = 5609233183118 := by decide
theorem cert_e1211186672014 : check e1211186672014 [[],[]] .three = true := by decide
def e1211186672070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186672070 : Closed e1211186672070 ∧ code e1211186672070 = 5609233183174 := by decide
theorem cert_e1211186672070 : check e1211186672070 [[],[]] .three = true := by decide
def e1211186672094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1211186672094 : Closed e1211186672094 ∧ code e1211186672094 = 5609233183198 := by decide
theorem cert_e1211186672094 : check e1211186672094 [[],[]] .three = true := by decide
def e1211186672110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211186672110 : Closed e1211186672110 ∧ code e1211186672110 = 5609233183214 := by decide
theorem cert_e1211186672110 : check e1211186672110 [[],[]] .three = true := by decide
def e1211186672118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1211186672118 : Closed e1211186672118 ∧ code e1211186672118 = 5609233183222 := by decide
theorem cert_e1211186672118 : check e1211186672118 [[],[]] .three = true := by decide
def e1211186672406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186672406 : Closed e1211186672406 ∧ code e1211186672406 = 5609233183510 := by decide
theorem cert_e1211186672406 : check e1211186672406 [[],[]] .three = true := by decide
def e1211186672482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186672482 : Closed e1211186672482 ∧ code e1211186672482 = 5609233183586 := by decide
theorem cert_e1211186672482 : check e1211186672482 [[],[]] .three = true := by decide
def e1211186672494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211186672494 : Closed e1211186672494 ∧ code e1211186672494 = 5609233183598 := by decide
theorem cert_e1211186672494 : check e1211186672494 [[],[]] .three = true := by decide
def e1211186672502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211186672502 : Closed e1211186672502 ∧ code e1211186672502 = 5609233183606 := by decide
theorem cert_e1211186672502 : check e1211186672502 [[],[]] .three = true := by decide
def e1211186672522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186672522 : Closed e1211186672522 ∧ code e1211186672522 = 5609233183626 := by decide
theorem cert_e1211186672522 : check e1211186672522 [[],[]] .three = true := by decide
def e1211186672546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186672546 : Closed e1211186672546 ∧ code e1211186672546 = 5609233183650 := by decide
theorem cert_e1211186672546 : check e1211186672546 [[],[]] .three = true := by decide
def e1211186672558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211186672558 : Closed e1211186672558 ∧ code e1211186672558 = 5609233183662 := by decide
theorem cert_e1211186672558 : check e1211186672558 [[],[]] .three = true := by decide
def e1211186672566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e1211186672566 : Closed e1211186672566 ∧ code e1211186672566 = 5609233183670 := by decide
theorem cert_e1211186672566 : check e1211186672566 [[],[]] .three = true := by decide
def e1211186672570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211186672570 : Closed e1211186672570 ∧ code e1211186672570 = 5609233183674 := by decide
theorem cert_e1211186672570 : check e1211186672570 [[],[]] .three = true := by decide
def e1211186672598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211186672598 : Closed e1211186672598 ∧ code e1211186672598 = 5609233183702 := by decide
theorem cert_e1211186672598 : check e1211186672598 [[],[]] .three = true := by decide
def e1211186672602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211186672602 : Closed e1211186672602 ∧ code e1211186672602 = 5609233183706 := by decide
theorem cert_e1211186672602 : check e1211186672602 [[],[]] .three = true := by decide
def e1211186672670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186672670 : Closed e1211186672670 ∧ code e1211186672670 = 5609233183774 := by decide
theorem cert_e1211186672670 : check e1211186672670 [[],[]] .three = true := by decide
def e1211186672866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186672866 : Closed e1211186672866 ∧ code e1211186672866 = 5609233183970 := by decide
theorem cert_e1211186672866 : check e1211186672866 [[],[]] .three = true := by decide
def e1211186672878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186672878 : Closed e1211186672878 ∧ code e1211186672878 = 5609233183982 := by decide
theorem cert_e1211186672878 : check e1211186672878 [[],[]] .three = true := by decide
def e1211186672886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186672886 : Closed e1211186672886 ∧ code e1211186672886 = 5609233183990 := by decide
theorem cert_e1211186672886 : check e1211186672886 [[],[]] .three = true := by decide
def e1211186673166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186673166 : Closed e1211186673166 ∧ code e1211186673166 = 5609233184270 := by decide
theorem cert_e1211186673166 : check e1211186673166 [[],[]] .three = true := by decide
def e1211186673178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186673178 : Closed e1211186673178 ∧ code e1211186673178 = 5609233184282 := by decide
theorem cert_e1211186673178 : check e1211186673178 [[],[]] .three = true := by decide
def e1211186673214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 4))))))))
theorem wire_e1211186673214 : Closed e1211186673214 ∧ code e1211186673214 = 5609233184318 := by decide
theorem cert_e1211186673214 : check e1211186673214 [[],[]] .three = true := by decide
def e1211186673250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186673250 : Closed e1211186673250 ∧ code e1211186673250 = 5609233184354 := by decide
theorem cert_e1211186673250 : check e1211186673250 [[],[]] .three = true := by decide
def e1211186673262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186673262 : Closed e1211186673262 ∧ code e1211186673262 = 5609233184366 := by decide
theorem cert_e1211186673262 : check e1211186673262 [[],[]] .three = true := by decide
def e1211186673270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186673270 : Closed e1211186673270 ∧ code e1211186673270 = 5609233184374 := by decide
theorem cert_e1211186673270 : check e1211186673270 [[],[]] .three = true := by decide
def e1211186673274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186673274 : Closed e1211186673274 ∧ code e1211186673274 = 5609233184378 := by decide
theorem cert_e1211186673274 : check e1211186673274 [[],[]] .three = true := by decide
def e1211186673438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211186673438 : Closed e1211186673438 ∧ code e1211186673438 = 5609233184542 := by decide
theorem cert_e1211186673438 : check e1211186673438 [[],[]] .three = true := by decide
def e1211186673462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186673462 : Closed e1211186673462 ∧ code e1211186673462 = 5609233184566 := by decide
theorem cert_e1211186673462 : check e1211186673462 [[],[]] .three = true := by decide
def e1211186673466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186673466 : Closed e1211186673466 ∧ code e1211186673466 = 5609233184570 := by decide
theorem cert_e1211186673466 : check e1211186673466 [[],[]] .three = true := by decide
def e1211186673550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.lam (.var 2))))))))
theorem wire_e1211186673550 : Closed e1211186673550 ∧ code e1211186673550 = 5609233184654 := by decide
theorem cert_e1211186673550 : check e1211186673550 [[],[]] .three = true := by decide
def e1211186681566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211186681566 : Closed e1211186681566 ∧ code e1211186681566 = 5609233192670 := by decide
theorem cert_e1211186681566 : check e1211186681566 [[],[]] .smaller = true := by decide
def e1211186681590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211186681590 : Closed e1211186681590 ∧ code e1211186681590 = 5609233192694 := by decide
theorem cert_e1211186681590 : check e1211186681590 [[],[]] .smaller = true := by decide
def e1211186681694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211186681694 : Closed e1211186681694 ∧ code e1211186681694 = 5609233192798 := by decide
theorem cert_e1211186681694 : check e1211186681694 [[],[]] .smaller = true := by decide
def e1211186681722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211186681722 : Closed e1211186681722 ∧ code e1211186681722 = 5609233192826 := by decide
theorem cert_e1211186681722 : check e1211186681722 [[],[]] .smaller = true := by decide
def e1211186681814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211186681814 : Closed e1211186681814 ∧ code e1211186681814 = 5609233192918 := by decide
theorem cert_e1211186681814 : check e1211186681814 [[],[]] .smaller = true := by decide
def e1211186681818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211186681818 : Closed e1211186681818 ∧ code e1211186681818 = 5609233192922 := by decide
theorem cert_e1211186681818 : check e1211186681818 [[],[]] .smaller = true := by decide
def e1211186682334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211186682334 : Closed e1211186682334 ∧ code e1211186682334 = 5609233193438 := by decide
theorem cert_e1211186682334 : check e1211186682334 [[],[]] .smaller = true := by decide
def e1211186682358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211186682358 : Closed e1211186682358 ∧ code e1211186682358 = 5609233193462 := by decide
theorem cert_e1211186682358 : check e1211186682358 [[],[]] .smaller = true := by decide
def e1211186683102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211186683102 : Closed e1211186683102 ∧ code e1211186683102 = 5609233194206 := by decide
theorem cert_e1211186683102 : check e1211186683102 [[],[]] .smaller = true := by decide
def e1211186683130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211186683130 : Closed e1211186683130 ∧ code e1211186683130 = 5609233194234 := by decide
theorem cert_e1211186683130 : check e1211186683130 [[],[]] .smaller = true := by decide
def e1211186683454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211186683454 : Closed e1211186683454 ∧ code e1211186683454 = 5609233194558 := by decide
theorem cert_e1211186683454 : check e1211186683454 [[],[]] .smaller = true := by decide
def e1211186683678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211186683678 : Closed e1211186683678 ∧ code e1211186683678 = 5609233194782 := by decide
theorem cert_e1211186683678 : check e1211186683678 [[],[]] .smaller = true := by decide
def e1211186683702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186683702 : Closed e1211186683702 ∧ code e1211186683702 = 5609233194806 := by decide
theorem cert_e1211186683702 : check e1211186683702 [[],[]] .smaller = true := by decide
def e1211186683706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186683706 : Closed e1211186683706 ∧ code e1211186683706 = 5609233194810 := by decide
theorem cert_e1211186683706 : check e1211186683706 [[],[]] .smaller = true := by decide
def e1211186698478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211186698478 : Closed e1211186698478 ∧ code e1211186698478 = 5609233209582 := by decide
theorem cert_e1211186698478 : check e1211186698478 [[],[]] .smaller = true := by decide
def e1211186698486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211186698486 : Closed e1211186698486 ∧ code e1211186698486 = 5609233209590 := by decide
theorem cert_e1211186698486 : check e1211186698486 [[],[]] .smaller = true := by decide
def e1211186699038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211186699038 : Closed e1211186699038 ∧ code e1211186699038 = 5609233210142 := by decide
theorem cert_e1211186699038 : check e1211186699038 [[],[]] .smaller = true := by decide
def e1211186699150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211186699150 : Closed e1211186699150 ∧ code e1211186699150 = 5609233210254 := by decide
theorem cert_e1211186699150 : check e1211186699150 [[],[]] .smaller = true := by decide
def e1211186699358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211186699358 : Closed e1211186699358 ∧ code e1211186699358 = 5609233210462 := by decide
theorem cert_e1211186699358 : check e1211186699358 [[],[]] .three = true := by decide
def e1211186699374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211186699374 : Closed e1211186699374 ∧ code e1211186699374 = 5609233210478 := by decide
theorem cert_e1211186699374 : check e1211186699374 [[],[]] .smaller = true := by decide
def e1211186699386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211186699386 : Closed e1211186699386 ∧ code e1211186699386 = 5609233210490 := by decide
theorem cert_e1211186699386 : check e1211186699386 [[],[]] .smaller = true := by decide
def e1211186699550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211186699550 : Closed e1211186699550 ∧ code e1211186699550 = 5609233210654 := by decide
theorem cert_e1211186699550 : check e1211186699550 [[],[]] .smaller = true := by decide
def e1211186699718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211186699718 : Closed e1211186699718 ∧ code e1211186699718 = 5609233210822 := by decide
theorem cert_e1211186699718 : check e1211186699718 [[],[]] .smaller = true := by decide
def e1211186699742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1211186699742 : Closed e1211186699742 ∧ code e1211186699742 = 5609233210846 := by decide
theorem cert_e1211186699742 : check e1211186699742 [[],[]] .three = true := by decide
def e1211186699746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211186699746 : Closed e1211186699746 ∧ code e1211186699746 = 5609233210850 := by decide
theorem cert_e1211186699746 : check e1211186699746 [[],[]] .three = true := by decide
def e1211186699758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1211186699758 : Closed e1211186699758 ∧ code e1211186699758 = 5609233210862 := by decide
theorem cert_e1211186699758 : check e1211186699758 [[],[]] .three = true := by decide
def e1211186699830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211186699830 : Closed e1211186699830 ∧ code e1211186699830 = 5609233210934 := by decide
theorem cert_e1211186699830 : check e1211186699830 [[],[]] .smaller = true := by decide
def e1211186699834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211186699834 : Closed e1211186699834 ∧ code e1211186699834 = 5609233210938 := by decide
theorem cert_e1211186699834 : check e1211186699834 [[],[]] .smaller = true := by decide
def e1211186699918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211186699918 : Closed e1211186699918 ∧ code e1211186699918 = 5609233211022 := by decide
theorem cert_e1211186699918 : check e1211186699918 [[],[]] .smaller = true := by decide
def e1211186699974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211186699974 : Closed e1211186699974 ∧ code e1211186699974 = 5609233211078 := by decide
theorem cert_e1211186699974 : check e1211186699974 [[],[]] .smaller = true := by decide
def e1211186699998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1211186699998 : Closed e1211186699998 ∧ code e1211186699998 = 5609233211102 := by decide
theorem cert_e1211186699998 : check e1211186699998 [[],[]] .three = true := by decide
def e1211186700022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1211186700022 : Closed e1211186700022 ∧ code e1211186700022 = 5609233211126 := by decide
theorem cert_e1211186700022 : check e1211186700022 [[],[]] .three = true := by decide
def e1211186700054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186700054 : Closed e1211186700054 ∧ code e1211186700054 = 5609233211158 := by decide
theorem cert_e1211186700054 : check e1211186700054 [[],[]] .three = true := by decide
def e1211186700130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186700130 : Closed e1211186700130 ∧ code e1211186700130 = 5609233211234 := by decide
theorem cert_e1211186700130 : check e1211186700130 [[],[]] .three = true := by decide
def e1211186700142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1211186700142 : Closed e1211186700142 ∧ code e1211186700142 = 5609233211246 := by decide
theorem cert_e1211186700142 : check e1211186700142 [[],[]] .three = true := by decide
def e1211186700150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1211186700150 : Closed e1211186700150 ∧ code e1211186700150 = 5609233211254 := by decide
theorem cert_e1211186700150 : check e1211186700150 [[],[]] .three = true := by decide
def e1211186702110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211186702110 : Closed e1211186702110 ∧ code e1211186702110 = 5609233213214 := by decide
theorem cert_e1211186702110 : check e1211186702110 [[],[]] .smaller = true := by decide
def e1211186702222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211186702222 : Closed e1211186702222 ∧ code e1211186702222 = 5609233213326 := by decide
theorem cert_e1211186702222 : check e1211186702222 [[],[]] .smaller = true := by decide
def e1211186704510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 5))))))))))
theorem wire_e1211186704510 : Closed e1211186704510 ∧ code e1211186704510 = 5609233215614 := by decide
theorem cert_e1211186704510 : check e1211186704510 [[],[]] .three = true := by decide
def e1211186704606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211186704606 : Closed e1211186704606 ∧ code e1211186704606 = 5609233215710 := by decide
theorem cert_e1211186704606 : check e1211186704606 [[],[]] .smaller = true := by decide
def e1211186704634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211186704634 : Closed e1211186704634 ∧ code e1211186704634 = 5609233215738 := by decide
theorem cert_e1211186704634 : check e1211186704634 [[],[]] .smaller = true := by decide
def e1211186705182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211186705182 : Closed e1211186705182 ∧ code e1211186705182 = 5609233216286 := by decide
theorem cert_e1211186705182 : check e1211186705182 [[],[]] .smaller = true := by decide
def e1211186705350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211186705350 : Closed e1211186705350 ∧ code e1211186705350 = 5609233216454 := by decide
theorem cert_e1211186705350 : check e1211186705350 [[],[]] .smaller = true := by decide
def e1211186705374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211186705374 : Closed e1211186705374 ∧ code e1211186705374 = 5609233216478 := by decide
theorem cert_e1211186705374 : check e1211186705374 [[],[]] .three = true := by decide
def e1211186705378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211186705378 : Closed e1211186705378 ∧ code e1211186705378 = 5609233216482 := by decide
theorem cert_e1211186705378 : check e1211186705378 [[],[]] .three = true := by decide
def e1211186705390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211186705390 : Closed e1211186705390 ∧ code e1211186705390 = 5609233216494 := by decide
theorem cert_e1211186705390 : check e1211186705390 [[],[]] .three = true := by decide
def e1211186706542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186706542 : Closed e1211186706542 ∧ code e1211186706542 = 5609233217646 := by decide
theorem cert_e1211186706542 : check e1211186706542 [[],[]] .smaller = true := by decide
def e1211186706554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186706554 : Closed e1211186706554 ∧ code e1211186706554 = 5609233217658 := by decide
theorem cert_e1211186706554 : check e1211186706554 [[],[]] .smaller = true := by decide
def e1211186706830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211186706830 : Closed e1211186706830 ∧ code e1211186706830 = 5609233217934 := by decide
theorem cert_e1211186706830 : check e1211186706830 [[],[]] .smaller = true := by decide
def e1211186706886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211186706886 : Closed e1211186706886 ∧ code e1211186706886 = 5609233217990 := by decide
theorem cert_e1211186706886 : check e1211186706886 [[],[]] .smaller = true := by decide
def e1211186706910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186706910 : Closed e1211186706910 ∧ code e1211186706910 = 5609233218014 := by decide
theorem cert_e1211186706910 : check e1211186706910 [[],[]] .three = true := by decide
def e1211186706934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186706934 : Closed e1211186706934 ∧ code e1211186706934 = 5609233218038 := by decide
theorem cert_e1211186706934 : check e1211186706934 [[],[]] .three = true := by decide
def e1211186707486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186707486 : Closed e1211186707486 ∧ code e1211186707486 = 5609233218590 := by decide
theorem cert_e1211186707486 : check e1211186707486 [[],[]] .three = true := by decide
def e1211186707682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186707682 : Closed e1211186707682 ∧ code e1211186707682 = 5609233218786 := by decide
theorem cert_e1211186707682 : check e1211186707682 [[],[]] .three = true := by decide
def e1211186707694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186707694 : Closed e1211186707694 ∧ code e1211186707694 = 5609233218798 := by decide
theorem cert_e1211186707694 : check e1211186707694 [[],[]] .three = true := by decide
def e1211186707702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186707702 : Closed e1211186707702 ∧ code e1211186707702 = 5609233218806 := by decide
theorem cert_e1211186707702 : check e1211186707702 [[],[]] .three = true := by decide
def e1211186744158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211186744158 : Closed e1211186744158 ∧ code e1211186744158 = 5609233255262 := by decide
theorem cert_e1211186744158 : check e1211186744158 [[],[]] .smaller = true := by decide
def e1211186744174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211186744174 : Closed e1211186744174 ∧ code e1211186744174 = 5609233255278 := by decide
theorem cert_e1211186744174 : check e1211186744174 [[],[]] .smaller = true := by decide
end Blc.Floor42
