import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211187022778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211187022778 : Closed e1211187022778 ∧ code e1211187022778 = 5609233533882 := by decide
theorem cert_e1211187022778 : check e1211187022778 [[],[]] .three = true := by decide
def e1211187022806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211187022806 : Closed e1211187022806 ∧ code e1211187022806 = 5609233533910 := by decide
theorem cert_e1211187022806 : check e1211187022806 [[],[]] .three = true := by decide
def e1211187022810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211187022810 : Closed e1211187022810 ∧ code e1211187022810 = 5609233533914 := by decide
theorem cert_e1211187022810 : check e1211187022810 [[],[]] .three = true := by decide
def e1211187022878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1211187022878 : Closed e1211187022878 ∧ code e1211187022878 = 5609233533982 := by decide
theorem cert_e1211187022878 : check e1211187022878 [[],[]] .three = true := by decide
def e1211187023074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211187023074 : Closed e1211187023074 ∧ code e1211187023074 = 5609233534178 := by decide
theorem cert_e1211187023074 : check e1211187023074 [[],[]] .three = true := by decide
def e1211187023086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211187023086 : Closed e1211187023086 ∧ code e1211187023086 = 5609233534190 := by decide
theorem cert_e1211187023086 : check e1211187023086 [[],[]] .three = true := by decide
def e1211187023094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211187023094 : Closed e1211187023094 ∧ code e1211187023094 = 5609233534198 := by decide
theorem cert_e1211187023094 : check e1211187023094 [[],[]] .three = true := by decide
def e1211187023374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1211187023374 : Closed e1211187023374 ∧ code e1211187023374 = 5609233534478 := by decide
theorem cert_e1211187023374 : check e1211187023374 [[],[]] .three = true := by decide
def e1211187023386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211187023386 : Closed e1211187023386 ∧ code e1211187023386 = 5609233534490 := by decide
theorem cert_e1211187023386 : check e1211187023386 [[],[]] .three = true := by decide
def e1211187023422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211187023422 : Closed e1211187023422 ∧ code e1211187023422 = 5609233534526 := by decide
theorem cert_e1211187023422 : check e1211187023422 [[],[]] .three = true := by decide
def e1211187023458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211187023458 : Closed e1211187023458 ∧ code e1211187023458 = 5609233534562 := by decide
theorem cert_e1211187023458 : check e1211187023458 [[],[]] .three = true := by decide
def e1211187023470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211187023470 : Closed e1211187023470 ∧ code e1211187023470 = 5609233534574 := by decide
theorem cert_e1211187023470 : check e1211187023470 [[],[]] .three = true := by decide
def e1211187023478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211187023478 : Closed e1211187023478 ∧ code e1211187023478 = 5609233534582 := by decide
theorem cert_e1211187023478 : check e1211187023478 [[],[]] .three = true := by decide
def e1211187023482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211187023482 : Closed e1211187023482 ∧ code e1211187023482 = 5609233534586 := by decide
theorem cert_e1211187023482 : check e1211187023482 [[],[]] .three = true := by decide
def e1211187023646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211187023646 : Closed e1211187023646 ∧ code e1211187023646 = 5609233534750 := by decide
theorem cert_e1211187023646 : check e1211187023646 [[],[]] .three = true := by decide
def e1211187023670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187023670 : Closed e1211187023670 ∧ code e1211187023670 = 5609233534774 := by decide
theorem cert_e1211187023670 : check e1211187023670 [[],[]] .three = true := by decide
def e1211187023674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187023674 : Closed e1211187023674 ∧ code e1211187023674 = 5609233534778 := by decide
theorem cert_e1211187023674 : check e1211187023674 [[],[]] .three = true := by decide
def e1211187023758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211187023758 : Closed e1211187023758 ∧ code e1211187023758 = 5609233534862 := by decide
theorem cert_e1211187023758 : check e1211187023758 [[],[]] .three = true := by decide
def e1211187029386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211187029386 : Closed e1211187029386 ∧ code e1211187029386 = 5609233540490 := by decide
theorem cert_e1211187029386 : check e1211187029386 [[],[]] .three = true := by decide
def e1211187029410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211187029410 : Closed e1211187029410 ∧ code e1211187029410 = 5609233540514 := by decide
theorem cert_e1211187029410 : check e1211187029410 [[],[]] .three = true := by decide
def e1211187029422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211187029422 : Closed e1211187029422 ∧ code e1211187029422 = 5609233540526 := by decide
theorem cert_e1211187029422 : check e1211187029422 [[],[]] .three = true := by decide
def e1211187029430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211187029430 : Closed e1211187029430 ∧ code e1211187029430 = 5609233540534 := by decide
theorem cert_e1211187029430 : check e1211187029430 [[],[]] .three = true := by decide
def e1211187029434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211187029434 : Closed e1211187029434 ∧ code e1211187029434 = 5609233540538 := by decide
theorem cert_e1211187029434 : check e1211187029434 [[],[]] .three = true := by decide
def e1211187029462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211187029462 : Closed e1211187029462 ∧ code e1211187029462 = 5609233540566 := by decide
theorem cert_e1211187029462 : check e1211187029462 [[],[]] .three = true := by decide
def e1211187029466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211187029466 : Closed e1211187029466 ∧ code e1211187029466 = 5609233540570 := by decide
theorem cert_e1211187029466 : check e1211187029466 [[],[]] .three = true := by decide
def e1211187029482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211187029482 : Closed e1211187029482 ∧ code e1211187029482 = 5609233540586 := by decide
theorem cert_e1211187029482 : check e1211187029482 [[],[]] .three = true := by decide
def e1211187029518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e1211187029518 : Closed e1211187029518 ∧ code e1211187029518 = 5609233540622 := by decide
theorem cert_e1211187029518 : check e1211187029518 [[],[]] .three = true := by decide
def e1211187029530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211187029530 : Closed e1211187029530 ∧ code e1211187029530 = 5609233540634 := by decide
theorem cert_e1211187029530 : check e1211187029530 [[],[]] .three = true := by decide
def e1211187029566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1211187029566 : Closed e1211187029566 ∧ code e1211187029566 = 5609233540670 := by decide
theorem cert_e1211187029566 : check e1211187029566 [[],[]] .three = true := by decide
def e1211187029602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211187029602 : Closed e1211187029602 ∧ code e1211187029602 = 5609233540706 := by decide
theorem cert_e1211187029602 : check e1211187029602 [[],[]] .three = true := by decide
def e1211187029614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211187029614 : Closed e1211187029614 ∧ code e1211187029614 = 5609233540718 := by decide
theorem cert_e1211187029614 : check e1211187029614 [[],[]] .three = true := by decide
def e1211187029622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211187029622 : Closed e1211187029622 ∧ code e1211187029622 = 5609233540726 := by decide
theorem cert_e1211187029622 : check e1211187029622 [[],[]] .three = true := by decide
def e1211187029626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211187029626 : Closed e1211187029626 ∧ code e1211187029626 = 5609233540730 := by decide
theorem cert_e1211187029626 : check e1211187029626 [[],[]] .three = true := by decide
def e1211187029790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211187029790 : Closed e1211187029790 ∧ code e1211187029790 = 5609233540894 := by decide
theorem cert_e1211187029790 : check e1211187029790 [[],[]] .three = true := by decide
def e1211187029814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187029814 : Closed e1211187029814 ∧ code e1211187029814 = 5609233540918 := by decide
theorem cert_e1211187029814 : check e1211187029814 [[],[]] .three = true := by decide
def e1211187029818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187029818 : Closed e1211187029818 ∧ code e1211187029818 = 5609233540922 := by decide
theorem cert_e1211187029818 : check e1211187029818 [[],[]] .three = true := by decide
def e1211187029902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211187029902 : Closed e1211187029902 ∧ code e1211187029902 = 5609233541006 := by decide
theorem cert_e1211187029902 : check e1211187029902 [[],[]] .three = true := by decide
def e1211187029914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187029914 : Closed e1211187029914 ∧ code e1211187029914 = 5609233541018 := by decide
theorem cert_e1211187029914 : check e1211187029914 [[],[]] .three = true := by decide
def e1211187029958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1211187029958 : Closed e1211187029958 ∧ code e1211187029958 = 5609233541062 := by decide
theorem cert_e1211187029958 : check e1211187029958 [[],[]] .three = true := by decide
def e1211187032790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211187032790 : Closed e1211187032790 ∧ code e1211187032790 = 5609233543894 := by decide
theorem cert_e1211187032790 : check e1211187032790 [[],[]] .three = true := by decide
def e1211187032794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211187032794 : Closed e1211187032794 ∧ code e1211187032794 = 5609233543898 := by decide
theorem cert_e1211187032794 : check e1211187032794 [[],[]] .three = true := by decide
def e1211187032810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211187032810 : Closed e1211187032810 ∧ code e1211187032810 = 5609233543914 := by decide
theorem cert_e1211187032810 : check e1211187032810 [[],[]] .three = true := by decide
def e1211187032862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211187032862 : Closed e1211187032862 ∧ code e1211187032862 = 5609233543966 := by decide
theorem cert_e1211187032862 : check e1211187032862 [[],[]] .three = true := by decide
def e1211187032886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211187032886 : Closed e1211187032886 ∧ code e1211187032886 = 5609233543990 := by decide
theorem cert_e1211187032886 : check e1211187032886 [[],[]] .three = true := by decide
def e1211187032890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211187032890 : Closed e1211187032890 ∧ code e1211187032890 = 5609233543994 := by decide
theorem cert_e1211187032890 : check e1211187032890 [[],[]] .three = true := by decide
def e1211187032974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211187032974 : Closed e1211187032974 ∧ code e1211187032974 = 5609233544078 := by decide
theorem cert_e1211187032974 : check e1211187032974 [[],[]] .three = true := by decide
def e1211187032986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211187032986 : Closed e1211187032986 ∧ code e1211187032986 = 5609233544090 := by decide
theorem cert_e1211187032986 : check e1211187032986 [[],[]] .three = true := by decide
def e1211187033030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211187033030 : Closed e1211187033030 ∧ code e1211187033030 = 5609233544134 := by decide
theorem cert_e1211187033030 : check e1211187033030 [[],[]] .three = true := by decide
def e1211187034510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211187034510 : Closed e1211187034510 ∧ code e1211187034510 = 5609233545614 := by decide
private def t_e1211187034510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e1211187034510 : ¬ IsSelfInterpreter e1211187034510 :=
  wSource (t := t_e1211187034510) (replay_sound (ps := []) (t := e1211187034510) (by decide)) (by decide)
def e1211187034566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211187034566 : Closed e1211187034566 ∧ code e1211187034566 = 5609233545670 := by decide
private def t_e1211187034566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e1211187034566 : ¬ IsSelfInterpreter e1211187034566 :=
  wSource (t := t_e1211187034566) (replay_sound (ps := []) (t := e1211187034566) (by decide)) (by decide)
def e1211187074782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))))
theorem wire_e1211187074782 : Closed e1211187074782 ∧ code e1211187074782 = 5609233585886 := by decide
theorem cert_e1211187074782 : check e1211187074782 [[],[]] .smaller = true := by decide
def e1211187074806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))))
theorem wire_e1211187074806 : Closed e1211187074806 ∧ code e1211187074806 = 5609233585910 := by decide
theorem cert_e1211187074806 : check e1211187074806 [[],[]] .smaller = true := by decide
def e1211187074910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))))
theorem wire_e1211187074910 : Closed e1211187074910 ∧ code e1211187074910 = 5609233586014 := by decide
theorem cert_e1211187074910 : check e1211187074910 [[],[]] .smaller = true := by decide
def e1211187074938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))))
theorem wire_e1211187074938 : Closed e1211187074938 ∧ code e1211187074938 = 5609233586042 := by decide
theorem cert_e1211187074938 : check e1211187074938 [[],[]] .smaller = true := by decide
def e1211187075030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))))
theorem wire_e1211187075030 : Closed e1211187075030 ∧ code e1211187075030 = 5609233586134 := by decide
theorem cert_e1211187075030 : check e1211187075030 [[],[]] .smaller = true := by decide
def e1211187075034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))))
theorem wire_e1211187075034 : Closed e1211187075034 ∧ code e1211187075034 = 5609233586138 := by decide
theorem cert_e1211187075034 : check e1211187075034 [[],[]] .smaller = true := by decide
def e1211187075550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))))
theorem wire_e1211187075550 : Closed e1211187075550 ∧ code e1211187075550 = 5609233586654 := by decide
theorem cert_e1211187075550 : check e1211187075550 [[],[]] .smaller = true := by decide
def e1211187075574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))))
theorem wire_e1211187075574 : Closed e1211187075574 ∧ code e1211187075574 = 5609233586678 := by decide
theorem cert_e1211187075574 : check e1211187075574 [[],[]] .smaller = true := by decide
def e1211187076318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))))
theorem wire_e1211187076318 : Closed e1211187076318 ∧ code e1211187076318 = 5609233587422 := by decide
theorem cert_e1211187076318 : check e1211187076318 [[],[]] .smaller = true := by decide
def e1211187076346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))))
theorem wire_e1211187076346 : Closed e1211187076346 ∧ code e1211187076346 = 5609233587450 := by decide
theorem cert_e1211187076346 : check e1211187076346 [[],[]] .smaller = true := by decide
def e1211187076918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211187076918 : Closed e1211187076918 ∧ code e1211187076918 = 5609233588022 := by decide
theorem cert_e1211187076918 : check e1211187076918 [[],[]] .smaller = true := by decide
def e1211187076922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211187076922 : Closed e1211187076922 ∧ code e1211187076922 = 5609233588026 := by decide
theorem cert_e1211187076922 : check e1211187076922 [[],[]] .smaller = true := by decide
def e1211187091694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))))
theorem wire_e1211187091694 : Closed e1211187091694 ∧ code e1211187091694 = 5609233602798 := by decide
theorem cert_e1211187091694 : check e1211187091694 [[],[]] .smaller = true := by decide
def e1211187091702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))))
theorem wire_e1211187091702 : Closed e1211187091702 ∧ code e1211187091702 = 5609233602806 := by decide
theorem cert_e1211187091702 : check e1211187091702 [[],[]] .smaller = true := by decide
def e1211187092254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))))
theorem wire_e1211187092254 : Closed e1211187092254 ∧ code e1211187092254 = 5609233603358 := by decide
theorem cert_e1211187092254 : check e1211187092254 [[],[]] .smaller = true := by decide
def e1211187092366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))))
theorem wire_e1211187092366 : Closed e1211187092366 ∧ code e1211187092366 = 5609233603470 := by decide
theorem cert_e1211187092366 : check e1211187092366 [[],[]] .smaller = true := by decide
def e1211187092414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4))))))))))
theorem wire_e1211187092414 : Closed e1211187092414 ∧ code e1211187092414 = 5609233603518 := by decide
theorem cert_e1211187092414 : check e1211187092414 [[],[]] .smaller = true := by decide
def e1211187092462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2))))))))))
theorem wire_e1211187092462 : Closed e1211187092462 ∧ code e1211187092462 = 5609233603566 := by decide
theorem cert_e1211187092462 : check e1211187092462 [[],[]] .smaller = true := by decide
def e1211187092590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))))
theorem wire_e1211187092590 : Closed e1211187092590 ∧ code e1211187092590 = 5609233603694 := by decide
theorem cert_e1211187092590 : check e1211187092590 [[],[]] .smaller = true := by decide
def e1211187092602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))))
theorem wire_e1211187092602 : Closed e1211187092602 ∧ code e1211187092602 = 5609233603706 := by decide
theorem cert_e1211187092602 : check e1211187092602 [[],[]] .smaller = true := by decide
def e1211187092766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))))
theorem wire_e1211187092766 : Closed e1211187092766 ∧ code e1211187092766 = 5609233603870 := by decide
theorem cert_e1211187092766 : check e1211187092766 [[],[]] .smaller = true := by decide
def e1211187092934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))))
theorem wire_e1211187092934 : Closed e1211187092934 ∧ code e1211187092934 = 5609233604038 := by decide
theorem cert_e1211187092934 : check e1211187092934 [[],[]] .smaller = true := by decide
def e1211187092958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))))
theorem wire_e1211187092958 : Closed e1211187092958 ∧ code e1211187092958 = 5609233604062 := by decide
theorem cert_e1211187092958 : check e1211187092958 [[],[]] .smaller = true := by decide
def e1211187092974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))))
theorem wire_e1211187092974 : Closed e1211187092974 ∧ code e1211187092974 = 5609233604078 := by decide
theorem cert_e1211187092974 : check e1211187092974 [[],[]] .smaller = true := by decide
def e1211187093046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e1211187093046 : Closed e1211187093046 ∧ code e1211187093046 = 5609233604150 := by decide
theorem cert_e1211187093046 : check e1211187093046 [[],[]] .smaller = true := by decide
def e1211187093050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e1211187093050 : Closed e1211187093050 ∧ code e1211187093050 = 5609233604154 := by decide
theorem cert_e1211187093050 : check e1211187093050 [[],[]] .smaller = true := by decide
def e1211187093134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e1211187093134 : Closed e1211187093134 ∧ code e1211187093134 = 5609233604238 := by decide
theorem cert_e1211187093134 : check e1211187093134 [[],[]] .smaller = true := by decide
def e1211187093182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4))))))))))
theorem wire_e1211187093182 : Closed e1211187093182 ∧ code e1211187093182 = 5609233604286 := by decide
theorem cert_e1211187093182 : check e1211187093182 [[],[]] .smaller = true := by decide
def e1211187093190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e1211187093190 : Closed e1211187093190 ∧ code e1211187093190 = 5609233604294 := by decide
theorem cert_e1211187093190 : check e1211187093190 [[],[]] .smaller = true := by decide
def e1211187093214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))))
theorem wire_e1211187093214 : Closed e1211187093214 ∧ code e1211187093214 = 5609233604318 := by decide
theorem cert_e1211187093214 : check e1211187093214 [[],[]] .smaller = true := by decide
def e1211187093238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))))
theorem wire_e1211187093238 : Closed e1211187093238 ∧ code e1211187093238 = 5609233604342 := by decide
theorem cert_e1211187093238 : check e1211187093238 [[],[]] .smaller = true := by decide
def e1211187093242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0))))))))))
theorem wire_e1211187093242 : Closed e1211187093242 ∧ code e1211187093242 = 5609233604346 := by decide
theorem cert_e1211187093242 : check e1211187093242 [[],[]] .smaller = true := by decide
def e1211187093358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))))
theorem wire_e1211187093358 : Closed e1211187093358 ∧ code e1211187093358 = 5609233604462 := by decide
theorem cert_e1211187093358 : check e1211187093358 [[],[]] .smaller = true := by decide
def e1211187093366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))))
theorem wire_e1211187093366 : Closed e1211187093366 ∧ code e1211187093366 = 5609233604470 := by decide
theorem cert_e1211187093366 : check e1211187093366 [[],[]] .smaller = true := by decide
def e1211187093422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2))))))))))
theorem wire_e1211187093422 : Closed e1211187093422 ∧ code e1211187093422 = 5609233604526 := by decide
theorem cert_e1211187093422 : check e1211187093422 [[],[]] .smaller = true := by decide
def e1211187093434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0))))))))))
theorem wire_e1211187093434 : Closed e1211187093434 ∧ code e1211187093434 = 5609233604538 := by decide
theorem cert_e1211187093434 : check e1211187093434 [[],[]] .smaller = true := by decide
def e1211187095326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))))
theorem wire_e1211187095326 : Closed e1211187095326 ∧ code e1211187095326 = 5609233606430 := by decide
theorem cert_e1211187095326 : check e1211187095326 [[],[]] .smaller = true := by decide
def e1211187095438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))))
theorem wire_e1211187095438 : Closed e1211187095438 ∧ code e1211187095438 = 5609233606542 := by decide
theorem cert_e1211187095438 : check e1211187095438 [[],[]] .smaller = true := by decide
def e1211187095486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4)))))))))))
theorem wire_e1211187095486 : Closed e1211187095486 ∧ code e1211187095486 = 5609233606590 := by decide
theorem cert_e1211187095486 : check e1211187095486 [[],[]] .smaller = true := by decide
def e1211187095534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2)))))))))))
theorem wire_e1211187095534 : Closed e1211187095534 ∧ code e1211187095534 = 5609233606638 := by decide
theorem cert_e1211187095534 : check e1211187095534 [[],[]] .smaller = true := by decide
def e1211187098398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))
theorem wire_e1211187098398 : Closed e1211187098398 ∧ code e1211187098398 = 5609233609502 := by decide
theorem cert_e1211187098398 : check e1211187098398 [[],[]] .smaller = true := by decide
def e1211187098566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))))
theorem wire_e1211187098566 : Closed e1211187098566 ∧ code e1211187098566 = 5609233609670 := by decide
theorem cert_e1211187098566 : check e1211187098566 [[],[]] .smaller = true := by decide
def e1211187098590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211187098590 : Closed e1211187098590 ∧ code e1211187098590 = 5609233609694 := by decide
theorem cert_e1211187098590 : check e1211187098590 [[],[]] .smaller = true := by decide
def e1211187098606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211187098606 : Closed e1211187098606 ∧ code e1211187098606 = 5609233609710 := by decide
theorem cert_e1211187098606 : check e1211187098606 [[],[]] .smaller = true := by decide
def e1211187100046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e1211187100046 : Closed e1211187100046 ∧ code e1211187100046 = 5609233611150 := by decide
theorem cert_e1211187100046 : check e1211187100046 [[],[]] .smaller = true := by decide
def e1211187100094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4)))))))))))
theorem wire_e1211187100094 : Closed e1211187100094 ∧ code e1211187100094 = 5609233611198 := by decide
theorem cert_e1211187100094 : check e1211187100094 [[],[]] .smaller = true := by decide
def e1211187100102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e1211187100102 : Closed e1211187100102 ∧ code e1211187100102 = 5609233611206 := by decide
theorem cert_e1211187100102 : check e1211187100102 [[],[]] .smaller = true := by decide
def e1211187100126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211187100126 : Closed e1211187100126 ∧ code e1211187100126 = 5609233611230 := by decide
theorem cert_e1211187100126 : check e1211187100126 [[],[]] .smaller = true := by decide
def e1211187100150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211187100150 : Closed e1211187100150 ∧ code e1211187100150 = 5609233611254 := by decide
theorem cert_e1211187100150 : check e1211187100150 [[],[]] .smaller = true := by decide
def e1211187100154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0)))))))))))
theorem wire_e1211187100154 : Closed e1211187100154 ∧ code e1211187100154 = 5609233611258 := by decide
theorem cert_e1211187100154 : check e1211187100154 [[],[]] .smaller = true := by decide
def e1211187100910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211187100910 : Closed e1211187100910 ∧ code e1211187100910 = 5609233612014 := by decide
theorem cert_e1211187100910 : check e1211187100910 [[],[]] .smaller = true := by decide
def e1211187100918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211187100918 : Closed e1211187100918 ∧ code e1211187100918 = 5609233612022 := by decide
theorem cert_e1211187100918 : check e1211187100918 [[],[]] .smaller = true := by decide
def e1211187101294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211187101294 : Closed e1211187101294 ∧ code e1211187101294 = 5609233612398 := by decide
theorem cert_e1211187101294 : check e1211187101294 [[],[]] .smaller = true := by decide
def e1211187101306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211187101306 : Closed e1211187101306 ∧ code e1211187101306 = 5609233612410 := by decide
theorem cert_e1211187101306 : check e1211187101306 [[],[]] .smaller = true := by decide
def e1211187157726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e1211187157726 : Closed e1211187157726 ∧ code e1211187157726 = 5609233668830 := by decide
theorem cert_e1211187157726 : check e1211187157726 [[],[]] .smaller = true := by decide
def e1211187157750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e1211187157750 : Closed e1211187157750 ∧ code e1211187157750 = 5609233668854 := by decide
theorem cert_e1211187157750 : check e1211187157750 [[],[]] .smaller = true := by decide
def e1211187157854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e1211187157854 : Closed e1211187157854 ∧ code e1211187157854 = 5609233668958 := by decide
theorem cert_e1211187157854 : check e1211187157854 [[],[]] .smaller = true := by decide
def e1211187157870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e1211187157870 : Closed e1211187157870 ∧ code e1211187157870 = 5609233668974 := by decide
theorem cert_e1211187157870 : check e1211187157870 [[],[]] .smaller = true := by decide
def e1211187157878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e1211187157878 : Closed e1211187157878 ∧ code e1211187157878 = 5609233668982 := by decide
theorem cert_e1211187157878 : check e1211187157878 [[],[]] .smaller = true := by decide
def e1211187157882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e1211187157882 : Closed e1211187157882 ∧ code e1211187157882 = 5609233668986 := by decide
theorem cert_e1211187157882 : check e1211187157882 [[],[]] .smaller = true := by decide
def e1211187157942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e1211187157942 : Closed e1211187157942 ∧ code e1211187157942 = 5609233669046 := by decide
theorem cert_e1211187157942 : check e1211187157942 [[],[]] .smaller = true := by decide
def e1211187157974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e1211187157974 : Closed e1211187157974 ∧ code e1211187157974 = 5609233669078 := by decide
theorem cert_e1211187157974 : check e1211187157974 [[],[]] .smaller = true := by decide
def e1211187157978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e1211187157978 : Closed e1211187157978 ∧ code e1211187157978 = 5609233669082 := by decide
theorem cert_e1211187157978 : check e1211187157978 [[],[]] .smaller = true := by decide
def e1211187158366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e1211187158366 : Closed e1211187158366 ∧ code e1211187158366 = 5609233669470 := by decide
theorem cert_e1211187158366 : check e1211187158366 [[],[]] .smaller = true := by decide
def e1211187158382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211187158382 : Closed e1211187158382 ∧ code e1211187158382 = 5609233669486 := by decide
theorem cert_e1211187158382 : check e1211187158382 [[],[]] .smaller = true := by decide
def e1211187158390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211187158390 : Closed e1211187158390 ∧ code e1211187158390 = 5609233669494 := by decide
theorem cert_e1211187158390 : check e1211187158390 [[],[]] .smaller = true := by decide
def e1211187158394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e1211187158394 : Closed e1211187158394 ∧ code e1211187158394 = 5609233669498 := by decide
theorem cert_e1211187158394 : check e1211187158394 [[],[]] .smaller = true := by decide
def e1211187158446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211187158446 : Closed e1211187158446 ∧ code e1211187158446 = 5609233669550 := by decide
theorem cert_e1211187158446 : check e1211187158446 [[],[]] .smaller = true := by decide
def e1211187158458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211187158458 : Closed e1211187158458 ∧ code e1211187158458 = 5609233669562 := by decide
theorem cert_e1211187158458 : check e1211187158458 [[],[]] .smaller = true := by decide
def e1211187158486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211187158486 : Closed e1211187158486 ∧ code e1211187158486 = 5609233669590 := by decide
theorem cert_e1211187158486 : check e1211187158486 [[],[]] .smaller = true := by decide
def e1211187158490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211187158490 : Closed e1211187158490 ∧ code e1211187158490 = 5609233669594 := by decide
theorem cert_e1211187158490 : check e1211187158490 [[],[]] .smaller = true := by decide
def e1211187158506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e1211187158506 : Closed e1211187158506 ∧ code e1211187158506 = 5609233669610 := by decide
theorem cert_e1211187158506 : check e1211187158506 [[],[]] .smaller = true := by decide
def e1211187158710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211187158710 : Closed e1211187158710 ∧ code e1211187158710 = 5609233669814 := by decide
theorem cert_e1211187158710 : check e1211187158710 [[],[]] .smaller = true := by decide
def e1211187158742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211187158742 : Closed e1211187158742 ∧ code e1211187158742 = 5609233669846 := by decide
theorem cert_e1211187158742 : check e1211187158742 [[],[]] .smaller = true := by decide
def e1211187158746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211187158746 : Closed e1211187158746 ∧ code e1211187158746 = 5609233669850 := by decide
theorem cert_e1211187158746 : check e1211187158746 [[],[]] .smaller = true := by decide
def e1211187158870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211187158870 : Closed e1211187158870 ∧ code e1211187158870 = 5609233669974 := by decide
theorem cert_e1211187158870 : check e1211187158870 [[],[]] .smaller = true := by decide
def e1211187158874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211187158874 : Closed e1211187158874 ∧ code e1211187158874 = 5609233669978 := by decide
theorem cert_e1211187158874 : check e1211187158874 [[],[]] .smaller = true := by decide
def e1211187158890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211187158890 : Closed e1211187158890 ∧ code e1211187158890 = 5609233669994 := by decide
theorem cert_e1211187158890 : check e1211187158890 [[],[]] .smaller = true := by decide
def e1211187159998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 4)))))))))
theorem wire_e1211187159998 : Closed e1211187159998 ∧ code e1211187159998 = 5609233671102 := by decide
theorem cert_e1211187159998 : check e1211187159998 [[],[]] .three = true := by decide
def e1211187160054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 5))) (.var 1)))))))))
theorem wire_e1211187160054 : Closed e1211187160054 ∧ code e1211187160054 = 5609233671158 := by decide
theorem cert_e1211187160054 : check e1211187160054 [[],[]] .three = true := by decide
def e1211187160798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e1211187160798 : Closed e1211187160798 ∧ code e1211187160798 = 5609233671902 := by decide
theorem cert_e1211187160798 : check e1211187160798 [[],[]] .smaller = true := by decide
def e1211187160822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e1211187160822 : Closed e1211187160822 ∧ code e1211187160822 = 5609233671926 := by decide
theorem cert_e1211187160822 : check e1211187160822 [[],[]] .smaller = true := by decide
def e1211187160926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e1211187160926 : Closed e1211187160926 ∧ code e1211187160926 = 5609233672030 := by decide
theorem cert_e1211187160926 : check e1211187160926 [[],[]] .smaller = true := by decide
def e1211187160942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e1211187160942 : Closed e1211187160942 ∧ code e1211187160942 = 5609233672046 := by decide
theorem cert_e1211187160942 : check e1211187160942 [[],[]] .smaller = true := by decide
def e1211187160950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e1211187160950 : Closed e1211187160950 ∧ code e1211187160950 = 5609233672054 := by decide
theorem cert_e1211187160950 : check e1211187160950 [[],[]] .smaller = true := by decide
def e1211187160954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e1211187160954 : Closed e1211187160954 ∧ code e1211187160954 = 5609233672058 := by decide
theorem cert_e1211187160954 : check e1211187160954 [[],[]] .smaller = true := by decide
def e1211187161014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e1211187161014 : Closed e1211187161014 ∧ code e1211187161014 = 5609233672118 := by decide
theorem cert_e1211187161014 : check e1211187161014 [[],[]] .smaller = true := by decide
def e1211187161046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e1211187161046 : Closed e1211187161046 ∧ code e1211187161046 = 5609233672150 := by decide
theorem cert_e1211187161046 : check e1211187161046 [[],[]] .smaller = true := by decide
def e1211187161050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e1211187161050 : Closed e1211187161050 ∧ code e1211187161050 = 5609233672154 := by decide
theorem cert_e1211187161050 : check e1211187161050 [[],[]] .smaller = true := by decide
def e1211187161566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211187161566 : Closed e1211187161566 ∧ code e1211187161566 = 5609233672670 := by decide
theorem cert_e1211187161566 : check e1211187161566 [[],[]] .smaller = true := by decide
def e1211187161590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211187161590 : Closed e1211187161590 ∧ code e1211187161590 = 5609233672694 := by decide
theorem cert_e1211187161590 : check e1211187161590 [[],[]] .smaller = true := by decide
def e1211187162238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 5))))))))))
theorem wire_e1211187162238 : Closed e1211187162238 ∧ code e1211187162238 = 5609233673342 := by decide
theorem cert_e1211187162238 : check e1211187162238 [[],[]] .three = true := by decide
def e1211187162334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211187162334 : Closed e1211187162334 ∧ code e1211187162334 = 5609233673438 := by decide
theorem cert_e1211187162334 : check e1211187162334 [[],[]] .smaller = true := by decide
def e1211187162350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211187162350 : Closed e1211187162350 ∧ code e1211187162350 = 5609233673454 := by decide
theorem cert_e1211187162350 : check e1211187162350 [[],[]] .smaller = true := by decide
def e1211187162358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211187162358 : Closed e1211187162358 ∧ code e1211187162358 = 5609233673462 := by decide
theorem cert_e1211187162358 : check e1211187162358 [[],[]] .smaller = true := by decide
def e1211187162362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211187162362 : Closed e1211187162362 ∧ code e1211187162362 = 5609233673466 := by decide
theorem cert_e1211187162362 : check e1211187162362 [[],[]] .smaller = true := by decide
def e1211187162742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211187162742 : Closed e1211187162742 ∧ code e1211187162742 = 5609233673846 := by decide
theorem cert_e1211187162742 : check e1211187162742 [[],[]] .smaller = true := by decide
def e1211187162934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211187162934 : Closed e1211187162934 ∧ code e1211187162934 = 5609233674038 := by decide
theorem cert_e1211187162934 : check e1211187162934 [[],[]] .smaller = true := by decide
def e1211187162938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211187162938 : Closed e1211187162938 ∧ code e1211187162938 = 5609233674042 := by decide
theorem cert_e1211187162938 : check e1211187162938 [[],[]] .smaller = true := by decide
def e1211187163022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.lam (.var 2))))))))))
theorem wire_e1211187163022 : Closed e1211187163022 ∧ code e1211187163022 = 5609233674126 := by decide
theorem cert_e1211187163022 : check e1211187163022 [[],[]] .three = true := by decide
def e1211187163582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e1211187163582 : Closed e1211187163582 ∧ code e1211187163582 = 5609233674686 := by decide
theorem cert_e1211187163582 : check e1211187163582 [[],[]] .three = true := by decide
def e1211187163642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e1211187163642 : Closed e1211187163642 ∧ code e1211187163642 = 5609233674746 := by decide
theorem cert_e1211187163642 : check e1211187163642 [[],[]] .three = true := by decide
def e1211187163998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e1211187163998 : Closed e1211187163998 ∧ code e1211187163998 = 5609233675102 := by decide
theorem cert_e1211187163998 : check e1211187163998 [[],[]] .smaller = true := by decide
def e1211187164014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211187164014 : Closed e1211187164014 ∧ code e1211187164014 = 5609233675118 := by decide
theorem cert_e1211187164014 : check e1211187164014 [[],[]] .smaller = true := by decide
def e1211187164022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211187164022 : Closed e1211187164022 ∧ code e1211187164022 = 5609233675126 := by decide
theorem cert_e1211187164022 : check e1211187164022 [[],[]] .smaller = true := by decide
def e1211187164026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e1211187164026 : Closed e1211187164026 ∧ code e1211187164026 = 5609233675130 := by decide
theorem cert_e1211187164026 : check e1211187164026 [[],[]] .smaller = true := by decide
def e1211187164078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211187164078 : Closed e1211187164078 ∧ code e1211187164078 = 5609233675182 := by decide
theorem cert_e1211187164078 : check e1211187164078 [[],[]] .smaller = true := by decide
def e1211187164090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211187164090 : Closed e1211187164090 ∧ code e1211187164090 = 5609233675194 := by decide
theorem cert_e1211187164090 : check e1211187164090 [[],[]] .smaller = true := by decide
def e1211187164118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211187164118 : Closed e1211187164118 ∧ code e1211187164118 = 5609233675222 := by decide
theorem cert_e1211187164118 : check e1211187164118 [[],[]] .smaller = true := by decide
def e1211187164122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211187164122 : Closed e1211187164122 ∧ code e1211187164122 = 5609233675226 := by decide
theorem cert_e1211187164122 : check e1211187164122 [[],[]] .smaller = true := by decide
end Blc.Floor42
