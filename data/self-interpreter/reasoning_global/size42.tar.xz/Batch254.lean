import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211550374362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))) (.var 0))))
theorem wire_e1211550374362 : Closed e1211550374362 ∧ code e1211550374362 = 5609596885466 := by decide
def e1211550374662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550374662 : Closed e1211550374662 ∧ code e1211550374662 = 5609596885766 := by decide
theorem cert_e1211550374662 : check e1211550374662 [[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left]] .chain = true := by decide
def e1211550375010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.lam (.var 0)))))
theorem wire_e1211550375010 : Closed e1211550375010 ∧ code e1211550375010 = 5609596886114 := by decide
theorem cert_e1211550375010 : check e1211550375010 [[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left]] .chain = true := by decide
def e1211550375130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e1211550375130 : Closed e1211550375130 ∧ code e1211550375130 = 5609596886234 := by decide
def e1211550375146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e1211550375146 : Closed e1211550375146 ∧ code e1211550375146 = 5609596886250 := by decide
def e1211550375174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550375174 : Closed e1211550375174 ∧ code e1211550375174 = 5609596886278 := by decide
theorem cert_e1211550375174 : check e1211550375174 [[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211550665582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211550665582 : Closed e1211550665582 ∧ code e1211550665582 = 5609597176686 := by decide
theorem cert_e1211550665582 : check e1211550665582 [[],[],[.left]] .chain = true := by decide
def e1211550665590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211550665590 : Closed e1211550665590 ∧ code e1211550665590 = 5609597176694 := by decide
theorem cert_e1211550665590 : check e1211550665590 [[],[],[.left]] .chain = true := by decide
def e1211550665646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211550665646 : Closed e1211550665646 ∧ code e1211550665646 = 5609597176750 := by decide
theorem cert_e1211550665646 : check e1211550665646 [[],[],[.left]] .chain = true := by decide
def e1211550665658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211550665658 : Closed e1211550665658 ∧ code e1211550665658 = 5609597176762 := by decide
theorem cert_e1211550665658 : check e1211550665658 [[],[],[.left]] .chain = true := by decide
def e1211550665686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211550665686 : Closed e1211550665686 ∧ code e1211550665686 = 5609597176790 := by decide
theorem cert_e1211550665686 : check e1211550665686 [[],[],[.left]] .chain = true := by decide
def e1211550665690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211550665690 : Closed e1211550665690 ∧ code e1211550665690 = 5609597176794 := by decide
theorem cert_e1211550665690 : check e1211550665690 [[],[],[.left]] .chain = true := by decide
def e1211550665966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211550665966 : Closed e1211550665966 ∧ code e1211550665966 = 5609597177070 := by decide
theorem cert_e1211550665966 : check e1211550665966 [[],[],[.left]] .chain = true := by decide
def e1211550665974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211550665974 : Closed e1211550665974 ∧ code e1211550665974 = 5609597177078 := by decide
theorem cert_e1211550665974 : check e1211550665974 [[],[],[.left]] .chain = true := by decide
def e1211550666350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211550666350 : Closed e1211550666350 ∧ code e1211550666350 = 5609597177454 := by decide
theorem cert_e1211550666350 : check e1211550666350 [[],[],[.left]] .chain = true := by decide
def e1211550666362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211550666362 : Closed e1211550666362 ∧ code e1211550666362 = 5609597177466 := by decide
theorem cert_e1211550666362 : check e1211550666362 [[],[],[.left]] .chain = true := by decide
def e1211550666550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211550666550 : Closed e1211550666550 ∧ code e1211550666550 = 5609597177654 := by decide
theorem cert_e1211550666550 : check e1211550666550 [[],[],[.left]] .chain = true := by decide
def e1211550666554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211550666554 : Closed e1211550666554 ∧ code e1211550666554 = 5609597177658 := by decide
theorem cert_e1211550666554 : check e1211550666554 [[],[],[.left]] .chain = true := by decide
def e1211551722938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e1211551722938 : Closed e1211551722938 ∧ code e1211551722938 = 5609598234042 := by decide
private def t_e1211551722938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem cert_e1211551722938 : ¬ IsSelfInterpreter e1211551722938 :=
  wSource (t := t_e1211551722938) (replay_sound (ps := []) (t := e1211551722938) (by decide)) (by decide)
def e1211551722970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e1211551722970 : Closed e1211551722970 ∧ code e1211551722970 = 5609598234074 := by decide
private def t_e1211551722970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem cert_e1211551722970 : ¬ IsSelfInterpreter e1211551722970 :=
  wSource (t := t_e1211551722970) (replay_sound (ps := []) (t := e1211551722970) (by decide)) (by decide)
def e1211551723194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e1211551723194 : Closed e1211551723194 ∧ code e1211551723194 = 5609598234298 := by decide
private def t_e1211551723194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem cert_e1211551723194 : ¬ IsSelfInterpreter e1211551723194 :=
  wSource (t := t_e1211551723194) (replay_sound (ps := []) (t := e1211551723194) (by decide)) (by decide)
def e1211551723242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e1211551723242 : Closed e1211551723242 ∧ code e1211551723242 = 5609598234346 := by decide
private def t_e1211551723242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem cert_e1211551723242 : ¬ IsSelfInterpreter e1211551723242 :=
  wSource (t := t_e1211551723242) (replay_sound (ps := []) (t := e1211551723242) (by decide)) (by decide)
def e1211551723354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e1211551723354 : Closed e1211551723354 ∧ code e1211551723354 = 5609598234458 := by decide
private def t_e1211551723354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem cert_e1211551723354 : ¬ IsSelfInterpreter e1211551723354 :=
  wSource (t := t_e1211551723354) (replay_sound (ps := []) (t := e1211551723354) (by decide)) (by decide)
def e1211551723370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e1211551723370 : Closed e1211551723370 ∧ code e1211551723370 = 5609598234474 := by decide
private def t_e1211551723370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem cert_e1211551723370 : ¬ IsSelfInterpreter e1211551723370 :=
  wSource (t := t_e1211551723370) (replay_sound (ps := []) (t := e1211551723370) (by decide)) (by decide)
def e1211551724474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e1211551724474 : Closed e1211551724474 ∧ code e1211551724474 = 5609598235578 := by decide
private def t_e1211551724474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem cert_e1211551724474 : ¬ IsSelfInterpreter e1211551724474 :=
  wSource (t := t_e1211551724474) (replay_sound (ps := []) (t := e1211551724474) (by decide)) (by decide)
def e1211551724506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e1211551724506 : Closed e1211551724506 ∧ code e1211551724506 = 5609598235610 := by decide
private def t_e1211551724506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem cert_e1211551724506 : ¬ IsSelfInterpreter e1211551724506 :=
  wSource (t := t_e1211551724506) (replay_sound (ps := []) (t := e1211551724506) (by decide)) (by decide)
def e1211551726010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e1211551726010 : Closed e1211551726010 ∧ code e1211551726010 = 5609598237114 := by decide
private def t_e1211551726010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem cert_e1211551726010 : ¬ IsSelfInterpreter e1211551726010 :=
  wSource (t := t_e1211551726010) (replay_sound (ps := []) (t := e1211551726010) (by decide)) (by decide)
def e1211551726058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e1211551726058 : Closed e1211551726058 ∧ code e1211551726058 = 5609598237162 := by decide
private def t_e1211551726058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem cert_e1211551726058 : ¬ IsSelfInterpreter e1211551726058 :=
  wSource (t := t_e1211551726058) (replay_sound (ps := []) (t := e1211551726058) (by decide)) (by decide)
def e1211551726810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e1211551726810 : Closed e1211551726810 ∧ code e1211551726810 = 5609598237914 := by decide
private def t_e1211551726810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem cert_e1211551726810 : ¬ IsSelfInterpreter e1211551726810 :=
  wSource (t := t_e1211551726810) (replay_sound (ps := []) (t := e1211551726810) (by decide)) (by decide)
def e1211551726826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e1211551726826 : Closed e1211551726826 ∧ code e1211551726826 = 5609598237930 := by decide
private def t_e1211551726826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem cert_e1211551726826 : ¬ IsSelfInterpreter e1211551726826 :=
  wSource (t := t_e1211551726826) (replay_sound (ps := []) (t := e1211551726826) (by decide)) (by decide)
def e1211551979230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211551979230 : Closed e1211551979230 ∧ code e1211551979230 = 5609598490334 := by decide
theorem cert_e1211551979230 : check e1211551979230 [[],[],[.left]] .chain = true := by decide
def e1211551979254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211551979254 : Closed e1211551979254 ∧ code e1211551979254 = 5609598490358 := by decide
theorem cert_e1211551979254 : check e1211551979254 [[],[],[.left]] .chain = true := by decide
def e1211551979358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211551979358 : Closed e1211551979358 ∧ code e1211551979358 = 5609598490462 := by decide
theorem cert_e1211551979358 : check e1211551979358 [[],[],[.left]] .chain = true := by decide
def e1211551979386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211551979386 : Closed e1211551979386 ∧ code e1211551979386 = 5609598490490 := by decide
theorem cert_e1211551979386 : check e1211551979386 [[],[],[.left]] .chain = true := by decide
def e1211551979478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211551979478 : Closed e1211551979478 ∧ code e1211551979478 = 5609598490582 := by decide
theorem cert_e1211551979478 : check e1211551979478 [[],[],[.left]] .chain = true := by decide
def e1211551979482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211551979482 : Closed e1211551979482 ∧ code e1211551979482 = 5609598490586 := by decide
theorem cert_e1211551979482 : check e1211551979482 [[],[],[.left]] .chain = true := by decide
def e1211551979998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211551979998 : Closed e1211551979998 ∧ code e1211551979998 = 5609598491102 := by decide
theorem cert_e1211551979998 : check e1211551979998 [[],[],[.left]] .chain = true := by decide
def e1211551980022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211551980022 : Closed e1211551980022 ∧ code e1211551980022 = 5609598491126 := by decide
theorem cert_e1211551980022 : check e1211551980022 [[],[],[.left]] .chain = true := by decide
def e1211551980766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211551980766 : Closed e1211551980766 ∧ code e1211551980766 = 5609598491870 := by decide
theorem cert_e1211551980766 : check e1211551980766 [[],[],[.left]] .chain = true := by decide
def e1211551980794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211551980794 : Closed e1211551980794 ∧ code e1211551980794 = 5609598491898 := by decide
theorem cert_e1211551980794 : check e1211551980794 [[],[],[.left]] .chain = true := by decide
def e1211551981366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211551981366 : Closed e1211551981366 ∧ code e1211551981366 = 5609598492470 := by decide
theorem cert_e1211551981366 : check e1211551981366 [[],[],[.left]] .chain = true := by decide
def e1211551981370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211551981370 : Closed e1211551981370 ∧ code e1211551981370 = 5609598492474 := by decide
theorem cert_e1211551981370 : check e1211551981370 [[],[],[.left]] .chain = true := by decide
def e1211551996142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211551996142 : Closed e1211551996142 ∧ code e1211551996142 = 5609598507246 := by decide
theorem cert_e1211551996142 : check e1211551996142 [[],[],[.left]] .chain = true := by decide
def e1211551996150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211551996150 : Closed e1211551996150 ∧ code e1211551996150 = 5609598507254 := by decide
theorem cert_e1211551996150 : check e1211551996150 [[],[],[.left]] .chain = true := by decide
def e1211551996702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211551996702 : Closed e1211551996702 ∧ code e1211551996702 = 5609598507806 := by decide
theorem cert_e1211551996702 : check e1211551996702 [[],[],[.left]] .chain = true := by decide
def e1211551996814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211551996814 : Closed e1211551996814 ∧ code e1211551996814 = 5609598507918 := by decide
theorem cert_e1211551996814 : check e1211551996814 [[],[],[.left]] .chain = true := by decide
def e1211551997038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211551997038 : Closed e1211551997038 ∧ code e1211551997038 = 5609598508142 := by decide
theorem cert_e1211551997038 : check e1211551997038 [[],[],[.left]] .chain = true := by decide
def e1211551997050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211551997050 : Closed e1211551997050 ∧ code e1211551997050 = 5609598508154 := by decide
theorem cert_e1211551997050 : check e1211551997050 [[],[],[.left]] .chain = true := by decide
def e1211551997214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211551997214 : Closed e1211551997214 ∧ code e1211551997214 = 5609598508318 := by decide
theorem cert_e1211551997214 : check e1211551997214 [[],[],[.left]] .chain = true := by decide
def e1211551997382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211551997382 : Closed e1211551997382 ∧ code e1211551997382 = 5609598508486 := by decide
theorem cert_e1211551997382 : check e1211551997382 [[],[],[.left]] .chain = true := by decide
def e1211551997494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211551997494 : Closed e1211551997494 ∧ code e1211551997494 = 5609598508598 := by decide
theorem cert_e1211551997494 : check e1211551997494 [[],[],[.left]] .chain = true := by decide
def e1211551997498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211551997498 : Closed e1211551997498 ∧ code e1211551997498 = 5609598508602 := by decide
theorem cert_e1211551997498 : check e1211551997498 [[],[],[.left]] .chain = true := by decide
def e1211551997582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211551997582 : Closed e1211551997582 ∧ code e1211551997582 = 5609598508686 := by decide
theorem cert_e1211551997582 : check e1211551997582 [[],[],[.left]] .chain = true := by decide
def e1211551997638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211551997638 : Closed e1211551997638 ∧ code e1211551997638 = 5609598508742 := by decide
theorem cert_e1211551997638 : check e1211551997638 [[],[],[.left]] .chain = true := by decide
def e1211551999774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211551999774 : Closed e1211551999774 ∧ code e1211551999774 = 5609598510878 := by decide
theorem cert_e1211551999774 : check e1211551999774 [[],[],[.left]] .chain = true := by decide
def e1211551999886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211551999886 : Closed e1211551999886 ∧ code e1211551999886 = 5609598510990 := by decide
theorem cert_e1211551999886 : check e1211551999886 [[],[],[.left]] .chain = true := by decide
def e1211552002846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211552002846 : Closed e1211552002846 ∧ code e1211552002846 = 5609598513950 := by decide
theorem cert_e1211552002846 : check e1211552002846 [[],[],[.left]] .chain = true := by decide
def e1211552003014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211552003014 : Closed e1211552003014 ∧ code e1211552003014 = 5609598514118 := by decide
theorem cert_e1211552003014 : check e1211552003014 [[],[],[.left]] .chain = true := by decide
def e1211552004494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211552004494 : Closed e1211552004494 ∧ code e1211552004494 = 5609598515598 := by decide
theorem cert_e1211552004494 : check e1211552004494 [[],[],[.left]] .chain = true := by decide
def e1211552004550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211552004550 : Closed e1211552004550 ∧ code e1211552004550 = 5609598515654 := by decide
theorem cert_e1211552004550 : check e1211552004550 [[],[],[.left]] .chain = true := by decide
def e1211553024878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211553024878 : Closed e1211553024878 ∧ code e1211553024878 = 5609599535982 := by decide
theorem cert_e1211553024878 : check e1211553024878 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553024886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211553024886 : Closed e1211553024886 ∧ code e1211553024886 = 5609599535990 := by decide
theorem cert_e1211553024886 : check e1211553024886 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553024942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211553024942 : Closed e1211553024942 ∧ code e1211553024942 = 5609599536046 := by decide
theorem cert_e1211553024942 : check e1211553024942 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553024954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211553024954 : Closed e1211553024954 ∧ code e1211553024954 = 5609599536058 := by decide
theorem cert_e1211553024954 : check e1211553024954 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553024982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211553024982 : Closed e1211553024982 ∧ code e1211553024982 = 5609599536086 := by decide
theorem cert_e1211553024982 : check e1211553024982 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553024986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211553024986 : Closed e1211553024986 ∧ code e1211553024986 = 5609599536090 := by decide
theorem cert_e1211553024986 : check e1211553024986 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553025262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211553025262 : Closed e1211553025262 ∧ code e1211553025262 = 5609599536366 := by decide
theorem cert_e1211553025262 : check e1211553025262 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553025270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211553025270 : Closed e1211553025270 ∧ code e1211553025270 = 5609599536374 := by decide
theorem cert_e1211553025270 : check e1211553025270 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553025646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211553025646 : Closed e1211553025646 ∧ code e1211553025646 = 5609599536750 := by decide
theorem cert_e1211553025646 : check e1211553025646 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553025658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211553025658 : Closed e1211553025658 ∧ code e1211553025658 = 5609599536762 := by decide
theorem cert_e1211553025658 : check e1211553025658 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553025846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211553025846 : Closed e1211553025846 ∧ code e1211553025846 = 5609599536950 := by decide
theorem cert_e1211553025846 : check e1211553025846 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211553025850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211553025850 : Closed e1211553025850 ∧ code e1211553025850 = 5609599536954 := by decide
theorem cert_e1211553025850 : check e1211553025850 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211558270686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211558270686 : Closed e1211558270686 ∧ code e1211558270686 = 5609604781790 := by decide
private def t_e1211558270686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem cert_e1211558270686 : ¬ IsSelfInterpreter e1211558270686 :=
  wSource (t := t_e1211558270686) (replay_sound (ps := []) (t := e1211558270686) (by decide)) (by decide)
def e1211558270710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211558270710 : Closed e1211558270710 ∧ code e1211558270710 = 5609604781814 := by decide
private def t_e1211558270710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem cert_e1211558270710 : ¬ IsSelfInterpreter e1211558270710 :=
  wSource (t := t_e1211558270710) (replay_sound (ps := []) (t := e1211558270710) (by decide)) (by decide)
def e1211558270814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211558270814 : Closed e1211558270814 ∧ code e1211558270814 = 5609604781918 := by decide
private def t_e1211558270814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem cert_e1211558270814 : ¬ IsSelfInterpreter e1211558270814 :=
  wSource (t := t_e1211558270814) (replay_sound (ps := []) (t := e1211558270814) (by decide)) (by decide)
def e1211558270842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211558270842 : Closed e1211558270842 ∧ code e1211558270842 = 5609604781946 := by decide
private def t_e1211558270842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem cert_e1211558270842 : ¬ IsSelfInterpreter e1211558270842 :=
  wSource (t := t_e1211558270842) (replay_sound (ps := []) (t := e1211558270842) (by decide)) (by decide)
def e1211558270934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211558270934 : Closed e1211558270934 ∧ code e1211558270934 = 5609604782038 := by decide
private def t_e1211558270934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem cert_e1211558270934 : ¬ IsSelfInterpreter e1211558270934 :=
  wSource (t := t_e1211558270934) (replay_sound (ps := []) (t := e1211558270934) (by decide)) (by decide)
def e1211558270938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211558270938 : Closed e1211558270938 ∧ code e1211558270938 = 5609604782042 := by decide
private def t_e1211558270938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem cert_e1211558270938 : ¬ IsSelfInterpreter e1211558270938 :=
  wSource (t := t_e1211558270938) (replay_sound (ps := []) (t := e1211558270938) (by decide)) (by decide)
def e1211558271454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211558271454 : Closed e1211558271454 ∧ code e1211558271454 = 5609604782558 := by decide
private def t_e1211558271454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem cert_e1211558271454 : ¬ IsSelfInterpreter e1211558271454 :=
  wSource (t := t_e1211558271454) (replay_sound (ps := []) (t := e1211558271454) (by decide)) (by decide)
def e1211558271478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211558271478 : Closed e1211558271478 ∧ code e1211558271478 = 5609604782582 := by decide
private def t_e1211558271478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem cert_e1211558271478 : ¬ IsSelfInterpreter e1211558271478 :=
  wSource (t := t_e1211558271478) (replay_sound (ps := []) (t := e1211558271478) (by decide)) (by decide)
def e1211558272222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211558272222 : Closed e1211558272222 ∧ code e1211558272222 = 5609604783326 := by decide
private def t_e1211558272222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem cert_e1211558272222 : ¬ IsSelfInterpreter e1211558272222 :=
  wSource (t := t_e1211558272222) (replay_sound (ps := []) (t := e1211558272222) (by decide)) (by decide)
def e1211558272250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211558272250 : Closed e1211558272250 ∧ code e1211558272250 = 5609604783354 := by decide
private def t_e1211558272250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem cert_e1211558272250 : ¬ IsSelfInterpreter e1211558272250 :=
  wSource (t := t_e1211558272250) (replay_sound (ps := []) (t := e1211558272250) (by decide)) (by decide)
def e1211558272822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211558272822 : Closed e1211558272822 ∧ code e1211558272822 = 5609604783926 := by decide
private def t_e1211558272822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211558272822 : ¬ IsSelfInterpreter e1211558272822 :=
  wSource (t := t_e1211558272822) (replay_sound (ps := []) (t := e1211558272822) (by decide)) (by decide)
def e1211558272826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211558272826 : Closed e1211558272826 ∧ code e1211558272826 = 5609604783930 := by decide
private def t_e1211558272826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211558272826 : ¬ IsSelfInterpreter e1211558272826 :=
  wSource (t := t_e1211558272826) (replay_sound (ps := []) (t := e1211558272826) (by decide)) (by decide)
def e1211558287598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211558287598 : Closed e1211558287598 ∧ code e1211558287598 = 5609604798702 := by decide
private def t_e1211558287598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem cert_e1211558287598 : ¬ IsSelfInterpreter e1211558287598 :=
  wSource (t := t_e1211558287598) (replay_sound (ps := []) (t := e1211558287598) (by decide)) (by decide)
def e1211558287606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211558287606 : Closed e1211558287606 ∧ code e1211558287606 = 5609604798710 := by decide
private def t_e1211558287606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem cert_e1211558287606 : ¬ IsSelfInterpreter e1211558287606 :=
  wSource (t := t_e1211558287606) (replay_sound (ps := []) (t := e1211558287606) (by decide)) (by decide)
def e1211558288158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211558288158 : Closed e1211558288158 ∧ code e1211558288158 = 5609604799262 := by decide
private def t_e1211558288158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem cert_e1211558288158 : ¬ IsSelfInterpreter e1211558288158 :=
  wSource (t := t_e1211558288158) (replay_sound (ps := []) (t := e1211558288158) (by decide)) (by decide)
def e1211558288270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211558288270 : Closed e1211558288270 ∧ code e1211558288270 = 5609604799374 := by decide
private def t_e1211558288270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem cert_e1211558288270 : ¬ IsSelfInterpreter e1211558288270 :=
  wSource (t := t_e1211558288270) (replay_sound (ps := []) (t := e1211558288270) (by decide)) (by decide)
def e1211558288494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211558288494 : Closed e1211558288494 ∧ code e1211558288494 = 5609604799598 := by decide
private def t_e1211558288494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem cert_e1211558288494 : ¬ IsSelfInterpreter e1211558288494 :=
  wSource (t := t_e1211558288494) (replay_sound (ps := []) (t := e1211558288494) (by decide)) (by decide)
def e1211558288506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211558288506 : Closed e1211558288506 ∧ code e1211558288506 = 5609604799610 := by decide
private def t_e1211558288506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem cert_e1211558288506 : ¬ IsSelfInterpreter e1211558288506 :=
  wSource (t := t_e1211558288506) (replay_sound (ps := []) (t := e1211558288506) (by decide)) (by decide)
def e1211558288670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211558288670 : Closed e1211558288670 ∧ code e1211558288670 = 5609604799774 := by decide
private def t_e1211558288670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem cert_e1211558288670 : ¬ IsSelfInterpreter e1211558288670 :=
  wSource (t := t_e1211558288670) (replay_sound (ps := []) (t := e1211558288670) (by decide)) (by decide)
def e1211558288838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211558288838 : Closed e1211558288838 ∧ code e1211558288838 = 5609604799942 := by decide
private def t_e1211558288838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e1211558288838 : ¬ IsSelfInterpreter e1211558288838 :=
  wSource (t := t_e1211558288838) (replay_sound (ps := []) (t := e1211558288838) (by decide)) (by decide)
def e1211558288862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1211558288862 : Closed e1211558288862 ∧ code e1211558288862 = 5609604799966 := by decide
private def t_e1211558288862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem cert_e1211558288862 : ¬ IsSelfInterpreter e1211558288862 :=
  wSource (t := t_e1211558288862) (replay_sound (ps := []) (t := e1211558288862) (by decide)) (by decide)
def e1211558288878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1211558288878 : Closed e1211558288878 ∧ code e1211558288878 = 5609604799982 := by decide
private def t_e1211558288878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem cert_e1211558288878 : ¬ IsSelfInterpreter e1211558288878 :=
  wSource (t := t_e1211558288878) (replay_sound (ps := []) (t := e1211558288878) (by decide)) (by decide)
def e1211558288950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211558288950 : Closed e1211558288950 ∧ code e1211558288950 = 5609604800054 := by decide
private def t_e1211558288950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem cert_e1211558288950 : ¬ IsSelfInterpreter e1211558288950 :=
  wSource (t := t_e1211558288950) (replay_sound (ps := []) (t := e1211558288950) (by decide)) (by decide)
def e1211558288954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211558288954 : Closed e1211558288954 ∧ code e1211558288954 = 5609604800058 := by decide
private def t_e1211558288954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem cert_e1211558288954 : ¬ IsSelfInterpreter e1211558288954 :=
  wSource (t := t_e1211558288954) (replay_sound (ps := []) (t := e1211558288954) (by decide)) (by decide)
def e1211558289038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211558289038 : Closed e1211558289038 ∧ code e1211558289038 = 5609604800142 := by decide
private def t_e1211558289038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e1211558289038 : ¬ IsSelfInterpreter e1211558289038 :=
  wSource (t := t_e1211558289038) (replay_sound (ps := []) (t := e1211558289038) (by decide)) (by decide)
def e1211558289094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211558289094 : Closed e1211558289094 ∧ code e1211558289094 = 5609604800198 := by decide
private def t_e1211558289094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e1211558289094 : ¬ IsSelfInterpreter e1211558289094 :=
  wSource (t := t_e1211558289094) (replay_sound (ps := []) (t := e1211558289094) (by decide)) (by decide)
def e1211558289118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1211558289118 : Closed e1211558289118 ∧ code e1211558289118 = 5609604800222 := by decide
private def t_e1211558289118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem cert_e1211558289118 : ¬ IsSelfInterpreter e1211558289118 :=
  wSource (t := t_e1211558289118) (replay_sound (ps := []) (t := e1211558289118) (by decide)) (by decide)
def e1211558289142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1211558289142 : Closed e1211558289142 ∧ code e1211558289142 = 5609604800246 := by decide
private def t_e1211558289142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem cert_e1211558289142 : ¬ IsSelfInterpreter e1211558289142 :=
  wSource (t := t_e1211558289142) (replay_sound (ps := []) (t := e1211558289142) (by decide)) (by decide)
def e1211558289262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1211558289262 : Closed e1211558289262 ∧ code e1211558289262 = 5609604800366 := by decide
private def t_e1211558289262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem cert_e1211558289262 : ¬ IsSelfInterpreter e1211558289262 :=
  wSource (t := t_e1211558289262) (replay_sound (ps := []) (t := e1211558289262) (by decide)) (by decide)
def e1211558289270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1211558289270 : Closed e1211558289270 ∧ code e1211558289270 = 5609604800374 := by decide
private def t_e1211558289270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem cert_e1211558289270 : ¬ IsSelfInterpreter e1211558289270 :=
  wSource (t := t_e1211558289270) (replay_sound (ps := []) (t := e1211558289270) (by decide)) (by decide)
def e1211558291230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211558291230 : Closed e1211558291230 ∧ code e1211558291230 = 5609604802334 := by decide
private def t_e1211558291230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem cert_e1211558291230 : ¬ IsSelfInterpreter e1211558291230 :=
  wSource (t := t_e1211558291230) (replay_sound (ps := []) (t := e1211558291230) (by decide)) (by decide)
def e1211558291342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211558291342 : Closed e1211558291342 ∧ code e1211558291342 = 5609604802446 := by decide
private def t_e1211558291342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem cert_e1211558291342 : ¬ IsSelfInterpreter e1211558291342 :=
  wSource (t := t_e1211558291342) (replay_sound (ps := []) (t := e1211558291342) (by decide)) (by decide)
def e1211558294302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211558294302 : Closed e1211558294302 ∧ code e1211558294302 = 5609604805406 := by decide
private def t_e1211558294302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem cert_e1211558294302 : ¬ IsSelfInterpreter e1211558294302 :=
  wSource (t := t_e1211558294302) (replay_sound (ps := []) (t := e1211558294302) (by decide)) (by decide)
def e1211558294470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211558294470 : Closed e1211558294470 ∧ code e1211558294470 = 5609604805574 := by decide
private def t_e1211558294470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem cert_e1211558294470 : ¬ IsSelfInterpreter e1211558294470 :=
  wSource (t := t_e1211558294470) (replay_sound (ps := []) (t := e1211558294470) (by decide)) (by decide)
def e1211558294494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211558294494 : Closed e1211558294494 ∧ code e1211558294494 = 5609604805598 := by decide
private def t_e1211558294494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem cert_e1211558294494 : ¬ IsSelfInterpreter e1211558294494 :=
  wSource (t := t_e1211558294494) (replay_sound (ps := []) (t := e1211558294494) (by decide)) (by decide)
def e1211558294510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211558294510 : Closed e1211558294510 ∧ code e1211558294510 = 5609604805614 := by decide
private def t_e1211558294510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem cert_e1211558294510 : ¬ IsSelfInterpreter e1211558294510 :=
  wSource (t := t_e1211558294510) (replay_sound (ps := []) (t := e1211558294510) (by decide)) (by decide)
def e1211558295950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211558295950 : Closed e1211558295950 ∧ code e1211558295950 = 5609604807054 := by decide
private def t_e1211558295950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem cert_e1211558295950 : ¬ IsSelfInterpreter e1211558295950 :=
  wSource (t := t_e1211558295950) (replay_sound (ps := []) (t := e1211558295950) (by decide)) (by decide)
def e1211558296006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211558296006 : Closed e1211558296006 ∧ code e1211558296006 = 5609604807110 := by decide
private def t_e1211558296006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem cert_e1211558296006 : ¬ IsSelfInterpreter e1211558296006 :=
  wSource (t := t_e1211558296006) (replay_sound (ps := []) (t := e1211558296006) (by decide)) (by decide)
def e1211558296030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211558296030 : Closed e1211558296030 ∧ code e1211558296030 = 5609604807134 := by decide
private def t_e1211558296030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem cert_e1211558296030 : ¬ IsSelfInterpreter e1211558296030 :=
  wSource (t := t_e1211558296030) (replay_sound (ps := []) (t := e1211558296030) (by decide)) (by decide)
def e1211558296054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211558296054 : Closed e1211558296054 ∧ code e1211558296054 = 5609604807158 := by decide
private def t_e1211558296054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem cert_e1211558296054 : ¬ IsSelfInterpreter e1211558296054 :=
  wSource (t := t_e1211558296054) (replay_sound (ps := []) (t := e1211558296054) (by decide)) (by decide)
def e1211558296814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211558296814 : Closed e1211558296814 ∧ code e1211558296814 = 5609604807918 := by decide
private def t_e1211558296814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211558296814 : ¬ IsSelfInterpreter e1211558296814 :=
  wSource (t := t_e1211558296814) (replay_sound (ps := []) (t := e1211558296814) (by decide)) (by decide)
def e1211558296822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211558296822 : Closed e1211558296822 ∧ code e1211558296822 = 5609604807926 := by decide
private def t_e1211558296822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211558296822 : ¬ IsSelfInterpreter e1211558296822 :=
  wSource (t := t_e1211558296822) (replay_sound (ps := []) (t := e1211558296822) (by decide)) (by decide)
def e1211558353774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211558353774 : Closed e1211558353774 ∧ code e1211558353774 = 5609604864878 := by decide
private def t_e1211558353774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem cert_e1211558353774 : ¬ IsSelfInterpreter e1211558353774 :=
  wSource (t := t_e1211558353774) (replay_sound (ps := []) (t := e1211558353774) (by decide)) (by decide)
def e1211558353782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211558353782 : Closed e1211558353782 ∧ code e1211558353782 = 5609604864886 := by decide
private def t_e1211558353782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem cert_e1211558353782 : ¬ IsSelfInterpreter e1211558353782 :=
  wSource (t := t_e1211558353782) (replay_sound (ps := []) (t := e1211558353782) (by decide)) (by decide)
def e1211558353846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211558353846 : Closed e1211558353846 ∧ code e1211558353846 = 5609604864950 := by decide
private def t_e1211558353846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem cert_e1211558353846 : ¬ IsSelfInterpreter e1211558353846 :=
  wSource (t := t_e1211558353846) (replay_sound (ps := []) (t := e1211558353846) (by decide)) (by decide)
def e1211558354286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211558354286 : Closed e1211558354286 ∧ code e1211558354286 = 5609604865390 := by decide
private def t_e1211558354286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e1211558354286 : ¬ IsSelfInterpreter e1211558354286 :=
  wSource (t := t_e1211558354286) (replay_sound (ps := []) (t := e1211558354286) (by decide)) (by decide)
def e1211558354294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211558354294 : Closed e1211558354294 ∧ code e1211558354294 = 5609604865398 := by decide
private def t_e1211558354294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e1211558354294 : ¬ IsSelfInterpreter e1211558354294 :=
  wSource (t := t_e1211558354294) (replay_sound (ps := []) (t := e1211558354294) (by decide)) (by decide)
def e1211558354350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211558354350 : Closed e1211558354350 ∧ code e1211558354350 = 5609604865454 := by decide
private def t_e1211558354350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e1211558354350 : ¬ IsSelfInterpreter e1211558354350 :=
  wSource (t := t_e1211558354350) (replay_sound (ps := []) (t := e1211558354350) (by decide)) (by decide)
def e1211558354362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211558354362 : Closed e1211558354362 ∧ code e1211558354362 = 5609604865466 := by decide
private def t_e1211558354362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e1211558354362 : ¬ IsSelfInterpreter e1211558354362 :=
  wSource (t := t_e1211558354362) (replay_sound (ps := []) (t := e1211558354362) (by decide)) (by decide)
def e1211558354390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211558354390 : Closed e1211558354390 ∧ code e1211558354390 = 5609604865494 := by decide
private def t_e1211558354390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1211558354390 : ¬ IsSelfInterpreter e1211558354390 :=
  wSource (t := t_e1211558354390) (replay_sound (ps := []) (t := e1211558354390) (by decide)) (by decide)
def e1211558354394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211558354394 : Closed e1211558354394 ∧ code e1211558354394 = 5609604865498 := by decide
private def t_e1211558354394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1211558354394 : ¬ IsSelfInterpreter e1211558354394 :=
  wSource (t := t_e1211558354394) (replay_sound (ps := []) (t := e1211558354394) (by decide)) (by decide)
def e1211558354614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211558354614 : Closed e1211558354614 ∧ code e1211558354614 = 5609604865718 := by decide
private def t_e1211558354614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem cert_e1211558354614 : ¬ IsSelfInterpreter e1211558354614 :=
  wSource (t := t_e1211558354614) (replay_sound (ps := []) (t := e1211558354614) (by decide)) (by decide)
def e1211558354646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211558354646 : Closed e1211558354646 ∧ code e1211558354646 = 5609604865750 := by decide
private def t_e1211558354646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem cert_e1211558354646 : ¬ IsSelfInterpreter e1211558354646 :=
  wSource (t := t_e1211558354646) (replay_sound (ps := []) (t := e1211558354646) (by decide)) (by decide)
def e1211558354650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211558354650 : Closed e1211558354650 ∧ code e1211558354650 = 5609604865754 := by decide
private def t_e1211558354650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem cert_e1211558354650 : ¬ IsSelfInterpreter e1211558354650 :=
  wSource (t := t_e1211558354650) (replay_sound (ps := []) (t := e1211558354650) (by decide)) (by decide)
def e1211558356846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211558356846 : Closed e1211558356846 ∧ code e1211558356846 = 5609604867950 := by decide
private def t_e1211558356846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem cert_e1211558356846 : ¬ IsSelfInterpreter e1211558356846 :=
  wSource (t := t_e1211558356846) (replay_sound (ps := []) (t := e1211558356846) (by decide)) (by decide)
def e1211558356854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211558356854 : Closed e1211558356854 ∧ code e1211558356854 = 5609604867958 := by decide
private def t_e1211558356854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem cert_e1211558356854 : ¬ IsSelfInterpreter e1211558356854 :=
  wSource (t := t_e1211558356854) (replay_sound (ps := []) (t := e1211558356854) (by decide)) (by decide)
def e1211558356918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211558356918 : Closed e1211558356918 ∧ code e1211558356918 = 5609604868022 := by decide
private def t_e1211558356918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem cert_e1211558356918 : ¬ IsSelfInterpreter e1211558356918 :=
  wSource (t := t_e1211558356918) (replay_sound (ps := []) (t := e1211558356918) (by decide)) (by decide)
def e1211558358254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211558358254 : Closed e1211558358254 ∧ code e1211558358254 = 5609604869358 := by decide
private def t_e1211558358254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem cert_e1211558358254 : ¬ IsSelfInterpreter e1211558358254 :=
  wSource (t := t_e1211558358254) (replay_sound (ps := []) (t := e1211558358254) (by decide)) (by decide)
def e1211558358262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211558358262 : Closed e1211558358262 ∧ code e1211558358262 = 5609604869366 := by decide
private def t_e1211558358262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem cert_e1211558358262 : ¬ IsSelfInterpreter e1211558358262 :=
  wSource (t := t_e1211558358262) (replay_sound (ps := []) (t := e1211558358262) (by decide)) (by decide)
def e1211558358646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211558358646 : Closed e1211558358646 ∧ code e1211558358646 = 5609604869750 := by decide
private def t_e1211558358646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem cert_e1211558358646 : ¬ IsSelfInterpreter e1211558358646 :=
  wSource (t := t_e1211558358646) (replay_sound (ps := []) (t := e1211558358646) (by decide)) (by decide)
def e1211558359918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211558359918 : Closed e1211558359918 ∧ code e1211558359918 = 5609604871022 := by decide
private def t_e1211558359918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem cert_e1211558359918 : ¬ IsSelfInterpreter e1211558359918 :=
  wSource (t := t_e1211558359918) (replay_sound (ps := []) (t := e1211558359918) (by decide)) (by decide)
def e1211558359926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211558359926 : Closed e1211558359926 ∧ code e1211558359926 = 5609604871030 := by decide
private def t_e1211558359926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e1211558359926 : ¬ IsSelfInterpreter e1211558359926 :=
  wSource (t := t_e1211558359926) (replay_sound (ps := []) (t := e1211558359926) (by decide)) (by decide)
def e1211558359982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211558359982 : Closed e1211558359982 ∧ code e1211558359982 = 5609604871086 := by decide
private def t_e1211558359982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem cert_e1211558359982 : ¬ IsSelfInterpreter e1211558359982 :=
  wSource (t := t_e1211558359982) (replay_sound (ps := []) (t := e1211558359982) (by decide)) (by decide)
def e1211558359994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211558359994 : Closed e1211558359994 ∧ code e1211558359994 = 5609604871098 := by decide
private def t_e1211558359994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e1211558359994 : ¬ IsSelfInterpreter e1211558359994 :=
  wSource (t := t_e1211558359994) (replay_sound (ps := []) (t := e1211558359994) (by decide)) (by decide)
def e1211558360022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211558360022 : Closed e1211558360022 ∧ code e1211558360022 = 5609604871126 := by decide
private def t_e1211558360022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e1211558360022 : ¬ IsSelfInterpreter e1211558360022 :=
  wSource (t := t_e1211558360022) (replay_sound (ps := []) (t := e1211558360022) (by decide)) (by decide)
def e1211558360026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211558360026 : Closed e1211558360026 ∧ code e1211558360026 = 5609604871130 := by decide
private def t_e1211558360026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e1211558360026 : ¬ IsSelfInterpreter e1211558360026 :=
  wSource (t := t_e1211558360026) (replay_sound (ps := []) (t := e1211558360026) (by decide)) (by decide)
def e1211558360302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211558360302 : Closed e1211558360302 ∧ code e1211558360302 = 5609604871406 := by decide
private def t_e1211558360302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e1211558360302 : ¬ IsSelfInterpreter e1211558360302 :=
  wSource (t := t_e1211558360302) (replay_sound (ps := []) (t := e1211558360302) (by decide)) (by decide)
def e1211558360310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211558360310 : Closed e1211558360310 ∧ code e1211558360310 = 5609604871414 := by decide
private def t_e1211558360310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e1211558360310 : ¬ IsSelfInterpreter e1211558360310 :=
  wSource (t := t_e1211558360310) (replay_sound (ps := []) (t := e1211558360310) (by decide)) (by decide)
def e1211558360686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211558360686 : Closed e1211558360686 ∧ code e1211558360686 = 5609604871790 := by decide
private def t_e1211558360686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e1211558360686 : ¬ IsSelfInterpreter e1211558360686 :=
  wSource (t := t_e1211558360686) (replay_sound (ps := []) (t := e1211558360686) (by decide)) (by decide)
def e1211558360698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211558360698 : Closed e1211558360698 ∧ code e1211558360698 = 5609604871802 := by decide
private def t_e1211558360698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e1211558360698 : ¬ IsSelfInterpreter e1211558360698 :=
  wSource (t := t_e1211558360698) (replay_sound (ps := []) (t := e1211558360698) (by decide)) (by decide)
def e1211558360886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211558360886 : Closed e1211558360886 ∧ code e1211558360886 = 5609604871990 := by decide
private def t_e1211558360886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211558360886 : ¬ IsSelfInterpreter e1211558360886 :=
  wSource (t := t_e1211558360886) (replay_sound (ps := []) (t := e1211558360886) (by decide)) (by decide)
def e1211558360890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211558360890 : Closed e1211558360890 ∧ code e1211558360890 = 5609604871994 := by decide
private def t_e1211558360890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211558360890 : ¬ IsSelfInterpreter e1211558360890 :=
  wSource (t := t_e1211558360890) (replay_sound (ps := []) (t := e1211558360890) (by decide)) (by decide)
def e1211558361526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211558361526 : Closed e1211558361526 ∧ code e1211558361526 = 5609604872630 := by decide
private def t_e1211558361526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem cert_e1211558361526 : ¬ IsSelfInterpreter e1211558361526 :=
  wSource (t := t_e1211558361526) (replay_sound (ps := []) (t := e1211558361526) (by decide)) (by decide)
def e1211558361558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211558361558 : Closed e1211558361558 ∧ code e1211558361558 = 5609604872662 := by decide
private def t_e1211558361558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem cert_e1211558361558 : ¬ IsSelfInterpreter e1211558361558 :=
  wSource (t := t_e1211558361558) (replay_sound (ps := []) (t := e1211558361558) (by decide)) (by decide)
def e1211558361562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211558361562 : Closed e1211558361562 ∧ code e1211558361562 = 5609604872666 := by decide
private def t_e1211558361562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem cert_e1211558361562 : ¬ IsSelfInterpreter e1211558361562 :=
  wSource (t := t_e1211558361562) (replay_sound (ps := []) (t := e1211558361562) (by decide)) (by decide)
def e1211558361718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211558361718 : Closed e1211558361718 ∧ code e1211558361718 = 5609604872822 := by decide
private def t_e1211558361718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem cert_e1211558361718 : ¬ IsSelfInterpreter e1211558361718 :=
  wSource (t := t_e1211558361718) (replay_sound (ps := []) (t := e1211558361718) (by decide)) (by decide)
def e1211558361910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211558361910 : Closed e1211558361910 ∧ code e1211558361910 = 5609604873014 := by decide
private def t_e1211558361910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211558361910 : ¬ IsSelfInterpreter e1211558361910 :=
  wSource (t := t_e1211558361910) (replay_sound (ps := []) (t := e1211558361910) (by decide)) (by decide)
def e1211558361914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211558361914 : Closed e1211558361914 ∧ code e1211558361914 = 5609604873018 := by decide
private def t_e1211558361914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211558361914 : ¬ IsSelfInterpreter e1211558361914 :=
  wSource (t := t_e1211558361914) (replay_sound (ps := []) (t := e1211558361914) (by decide)) (by decide)
def e1211558369134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211558369134 : Closed e1211558369134 ∧ code e1211558369134 = 5609604880238 := by decide
private def t_e1211558369134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem cert_e1211558369134 : ¬ IsSelfInterpreter e1211558369134 :=
  wSource (t := t_e1211558369134) (replay_sound (ps := []) (t := e1211558369134) (by decide)) (by decide)
def e1211558369142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211558369142 : Closed e1211558369142 ∧ code e1211558369142 = 5609604880246 := by decide
private def t_e1211558369142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem cert_e1211558369142 : ¬ IsSelfInterpreter e1211558369142 :=
  wSource (t := t_e1211558369142) (replay_sound (ps := []) (t := e1211558369142) (by decide)) (by decide)
def e1211558369206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211558369206 : Closed e1211558369206 ∧ code e1211558369206 = 5609604880310 := by decide
private def t_e1211558369206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem cert_e1211558369206 : ¬ IsSelfInterpreter e1211558369206 :=
  wSource (t := t_e1211558369206) (replay_sound (ps := []) (t := e1211558369206) (by decide)) (by decide)
def e1211558370542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211558370542 : Closed e1211558370542 ∧ code e1211558370542 = 5609604881646 := by decide
private def t_e1211558370542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211558370542 : ¬ IsSelfInterpreter e1211558370542 :=
  wSource (t := t_e1211558370542) (replay_sound (ps := []) (t := e1211558370542) (by decide)) (by decide)
def e1211558370550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211558370550 : Closed e1211558370550 ∧ code e1211558370550 = 5609604881654 := by decide
private def t_e1211558370550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211558370550 : ¬ IsSelfInterpreter e1211558370550 :=
  wSource (t := t_e1211558370550) (replay_sound (ps := []) (t := e1211558370550) (by decide)) (by decide)
def e1211558370934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211558370934 : Closed e1211558370934 ∧ code e1211558370934 = 5609604882038 := by decide
private def t_e1211558370934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem cert_e1211558370934 : ¬ IsSelfInterpreter e1211558370934 :=
  wSource (t := t_e1211558370934) (replay_sound (ps := []) (t := e1211558370934) (by decide)) (by decide)
def e1211558382446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211558382446 : Closed e1211558382446 ∧ code e1211558382446 = 5609604893550 := by decide
private def t_e1211558382446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1211558382446 : ¬ IsSelfInterpreter e1211558382446 :=
  wSource (t := t_e1211558382446) (replay_sound (ps := []) (t := e1211558382446) (by decide)) (by decide)
def e1211558382454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211558382454 : Closed e1211558382454 ∧ code e1211558382454 = 5609604893558 := by decide
private def t_e1211558382454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1211558382454 : ¬ IsSelfInterpreter e1211558382454 :=
  wSource (t := t_e1211558382454) (replay_sound (ps := []) (t := e1211558382454) (by decide)) (by decide)
def e1211558382510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211558382510 : Closed e1211558382510 ∧ code e1211558382510 = 5609604893614 := by decide
private def t_e1211558382510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1211558382510 : ¬ IsSelfInterpreter e1211558382510 :=
  wSource (t := t_e1211558382510) (replay_sound (ps := []) (t := e1211558382510) (by decide)) (by decide)
def e1211558382522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211558382522 : Closed e1211558382522 ∧ code e1211558382522 = 5609604893626 := by decide
private def t_e1211558382522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1211558382522 : ¬ IsSelfInterpreter e1211558382522 :=
  wSource (t := t_e1211558382522) (replay_sound (ps := []) (t := e1211558382522) (by decide)) (by decide)
end Blc.Floor42
