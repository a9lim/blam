import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205959920558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205959920558 : Closed e1205959920558 ∧ code e1205959920558 = 5604006431662 := by decide
theorem cert_e1205959920558 : check e1205959920558 [[],[.left]] .chain = true := by decide
def e1205959920570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205959920570 : Closed e1205959920570 ∧ code e1205959920570 = 5604006431674 := by decide
theorem cert_e1205959920570 : check e1205959920570 [[],[.left]] .chain = true := by decide
def e1205959920598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205959920598 : Closed e1205959920598 ∧ code e1205959920598 = 5604006431702 := by decide
theorem cert_e1205959920598 : check e1205959920598 [[],[.left]] .chain = true := by decide
def e1205959920602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205959920602 : Closed e1205959920602 ∧ code e1205959920602 = 5604006431706 := by decide
theorem cert_e1205959920602 : check e1205959920602 [[],[.left]] .chain = true := by decide
def e1205959920878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205959920878 : Closed e1205959920878 ∧ code e1205959920878 = 5604006431982 := by decide
theorem cert_e1205959920878 : check e1205959920878 [[],[.left]] .chain = true := by decide
def e1205959920886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205959920886 : Closed e1205959920886 ∧ code e1205959920886 = 5604006431990 := by decide
theorem cert_e1205959920886 : check e1205959920886 [[],[.left]] .chain = true := by decide
def e1205959921262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205959921262 : Closed e1205959921262 ∧ code e1205959921262 = 5604006432366 := by decide
theorem cert_e1205959921262 : check e1205959921262 [[],[.left]] .chain = true := by decide
def e1205959921274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205959921274 : Closed e1205959921274 ∧ code e1205959921274 = 5604006432378 := by decide
theorem cert_e1205959921274 : check e1205959921274 [[],[.left]] .chain = true := by decide
def e1205959921462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205959921462 : Closed e1205959921462 ∧ code e1205959921462 = 5604006432566 := by decide
theorem cert_e1205959921462 : check e1205959921462 [[],[.left]] .chain = true := by decide
def e1205959921466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205959921466 : Closed e1205959921466 ∧ code e1205959921466 = 5604006432570 := by decide
theorem cert_e1205959921466 : check e1205959921466 [[],[.left]] .chain = true := by decide
def e1208664284014 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1208664284014 : Closed e1208664284014 ∧ code e1208664284014 = 5606710795118 := by decide
theorem cert_e1208664284014 : check e1208664284014 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1208664284022 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1208664284022 : Closed e1208664284022 ∧ code e1208664284022 = 5606710795126 := by decide
theorem cert_e1208664284022 : check e1208664284022 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1208664284086 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1208664284086 : Closed e1208664284086 ∧ code e1208664284086 = 5606710795190 := by decide
theorem cert_e1208664284086 : check e1208664284086 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1208664284526 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1208664284526 : Closed e1208664284526 ∧ code e1208664284526 = 5606710795630 := by decide
theorem cert_e1208664284526 : check e1208664284526 [[],[]] .sourceHead = true := by decide
def e1208664284534 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1208664284534 : Closed e1208664284534 ∧ code e1208664284534 = 5606710795638 := by decide
theorem cert_e1208664284534 : check e1208664284534 [[],[]] .sourceHead = true := by decide
def e1208664284590 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1208664284590 : Closed e1208664284590 ∧ code e1208664284590 = 5606710795694 := by decide
theorem cert_e1208664284590 : check e1208664284590 [[],[]] .sourceHead = true := by decide
def e1208664284602 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1208664284602 : Closed e1208664284602 ∧ code e1208664284602 = 5606710795706 := by decide
theorem cert_e1208664284602 : check e1208664284602 [[],[]] .sourceHead = true := by decide
def e1208664284630 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1208664284630 : Closed e1208664284630 ∧ code e1208664284630 = 5606710795734 := by decide
theorem cert_e1208664284630 : check e1208664284630 [[],[]] .sourceHead = true := by decide
def e1208664284634 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1208664284634 : Closed e1208664284634 ∧ code e1208664284634 = 5606710795738 := by decide
theorem cert_e1208664284634 : check e1208664284634 [[],[]] .sourceHead = true := by decide
def e1208664284854 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1208664284854 : Closed e1208664284854 ∧ code e1208664284854 = 5606710795958 := by decide
theorem cert_e1208664284854 : check e1208664284854 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1208664284886 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1208664284886 : Closed e1208664284886 ∧ code e1208664284886 = 5606710795990 := by decide
theorem cert_e1208664284886 : check e1208664284886 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1208664284890 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1208664284890 : Closed e1208664284890 ∧ code e1208664284890 = 5606710795994 := by decide
def e1208664287086 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1208664287086 : Closed e1208664287086 ∧ code e1208664287086 = 5606710798190 := by decide
theorem cert_e1208664287086 : check e1208664287086 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1208664287094 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1208664287094 : Closed e1208664287094 ∧ code e1208664287094 = 5606710798198 := by decide
theorem cert_e1208664287094 : check e1208664287094 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1208664287158 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1208664287158 : Closed e1208664287158 ∧ code e1208664287158 = 5606710798262 := by decide
theorem cert_e1208664287158 : check e1208664287158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1208664288494 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1208664288494 : Closed e1208664288494 ∧ code e1208664288494 = 5606710799598 := by decide
theorem cert_e1208664288494 : check e1208664288494 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1208664288502 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1208664288502 : Closed e1208664288502 ∧ code e1208664288502 = 5606710799606 := by decide
theorem cert_e1208664288502 : check e1208664288502 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1208664288886 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1208664288886 : Closed e1208664288886 ∧ code e1208664288886 = 5606710799990 := by decide
theorem cert_e1208664288886 : check e1208664288886 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1208664290158 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1208664290158 : Closed e1208664290158 ∧ code e1208664290158 = 5606710801262 := by decide
theorem cert_e1208664290158 : checkPay e1208664290158 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1208664290166 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1208664290166 : Closed e1208664290166 ∧ code e1208664290166 = 5606710801270 := by decide
theorem cert_e1208664290166 : checkPay e1208664290166 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1208664290222 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1208664290222 : Closed e1208664290222 ∧ code e1208664290222 = 5606710801326 := by decide
theorem cert_e1208664290222 : checkPay e1208664290222 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1208664290234 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1208664290234 : Closed e1208664290234 ∧ code e1208664290234 = 5606710801338 := by decide
theorem cert_e1208664290234 : checkPay e1208664290234 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left],[.right,.under],[.right,.under,.under,.left,.right,.right]] = true := by decide
def e1208664290262 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1208664290262 : Closed e1208664290262 ∧ code e1208664290262 = 5606710801366 := by decide
theorem cert_e1208664290262 : checkPay e1208664290262 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1208664290266 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1208664290266 : Closed e1208664290266 ∧ code e1208664290266 = 5606710801370 := by decide
theorem cert_e1208664290266 : checkPay e1208664290266 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[],[.under,.left,.right,.left],[.under,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e1208664290542 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1208664290542 : Closed e1208664290542 ∧ code e1208664290542 = 5606710801646 := by decide
theorem cert_e1208664290542 : checkPay e1208664290542 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1208664290550 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1208664290550 : Closed e1208664290550 ∧ code e1208664290550 = 5606710801654 := by decide
theorem cert_e1208664290550 : checkPay e1208664290550 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1208664290926 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1208664290926 : Closed e1208664290926 ∧ code e1208664290926 = 5606710802030 := by decide
theorem cert_e1208664290926 : checkPay e1208664290926 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1208664290938 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1208664290938 : Closed e1208664290938 ∧ code e1208664290938 = 5606710802042 := by decide
theorem cert_e1208664290938 : checkPay e1208664290938 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1208664291126 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1208664291126 : Closed e1208664291126 ∧ code e1208664291126 = 5606710802230 := by decide
theorem cert_e1208664291126 : checkPay e1208664291126 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e1208664291130 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1208664291130 : Closed e1208664291130 ∧ code e1208664291130 = 5606710802234 := by decide
theorem cert_e1208664291130 : checkPay e1208664291130 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.under,.left,.left],[.under,.under,.under,.left],[.under,.under,.under],[.under,.under,.under,.left,.right,.left],[.under,.under,.under,.left,.right],[.under,.under,.under,.right,.right,.left],[.under,.under,.under,.right,.right],[.under,.under,.under,.right,.right,.under,.left,.right,.left],[.under,.under,.under,.right,.right,.under,.left,.right]] = true := by decide
def e1208664291766 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1208664291766 : Closed e1208664291766 ∧ code e1208664291766 = 5606710802870 := by decide
theorem cert_e1208664291766 : check e1208664291766 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1208664291798 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1208664291798 : Closed e1208664291798 ∧ code e1208664291798 = 5606710802902 := by decide
theorem cert_e1208664291798 : check e1208664291798 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1208664291802 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1208664291802 : Closed e1208664291802 ∧ code e1208664291802 = 5606710802906 := by decide
theorem cert_e1208664291802 : check e1208664291802 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1208664291958 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1208664291958 : Closed e1208664291958 ∧ code e1208664291958 = 5606710803062 := by decide
theorem cert_e1208664291958 : check e1208664291958 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1208664292150 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1208664292150 : Closed e1208664292150 ∧ code e1208664292150 = 5606710803254 := by decide
theorem cert_e1208664292150 : check e1208664292150 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1208664292154 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1208664292154 : Closed e1208664292154 ∧ code e1208664292154 = 5606710803258 := by decide
theorem cert_e1208664292154 : check e1208664292154 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1208664299374 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1208664299374 : Closed e1208664299374 ∧ code e1208664299374 = 5606710810478 := by decide
theorem cert_e1208664299374 : check e1208664299374 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1208664299382 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1208664299382 : Closed e1208664299382 ∧ code e1208664299382 = 5606710810486 := by decide
theorem cert_e1208664299382 : check e1208664299382 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1208664299446 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1208664299446 : Closed e1208664299446 ∧ code e1208664299446 = 5606710810550 := by decide
theorem cert_e1208664299446 : check e1208664299446 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1208664300782 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1208664300782 : Closed e1208664300782 ∧ code e1208664300782 = 5606710811886 := by decide
theorem cert_e1208664300782 : check e1208664300782 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1208664300790 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1208664300790 : Closed e1208664300790 ∧ code e1208664300790 = 5606710811894 := by decide
theorem cert_e1208664300790 : check e1208664300790 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1208664301174 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1208664301174 : Closed e1208664301174 ∧ code e1208664301174 = 5606710812278 := by decide
theorem cert_e1208664301174 : check e1208664301174 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1208664312686 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1208664312686 : Closed e1208664312686 ∧ code e1208664312686 = 5606710823790 := by decide
theorem cert_e1208664312686 : check e1208664312686 [[],[]] .sourceHead = true := by decide
def e1208664312694 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1208664312694 : Closed e1208664312694 ∧ code e1208664312694 = 5606710823798 := by decide
theorem cert_e1208664312694 : check e1208664312694 [[],[]] .sourceHead = true := by decide
def e1208664312750 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1208664312750 : Closed e1208664312750 ∧ code e1208664312750 = 5606710823854 := by decide
theorem cert_e1208664312750 : check e1208664312750 [[],[]] .sourceHead = true := by decide
def e1208664312762 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1208664312762 : Closed e1208664312762 ∧ code e1208664312762 = 5606710823866 := by decide
theorem cert_e1208664312762 : check e1208664312762 [[],[]] .sourceHead = true := by decide
def e1208664312790 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1208664312790 : Closed e1208664312790 ∧ code e1208664312790 = 5606710823894 := by decide
theorem cert_e1208664312790 : check e1208664312790 [[],[]] .sourceHead = true := by decide
def e1208664312794 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1208664312794 : Closed e1208664312794 ∧ code e1208664312794 = 5606710823898 := by decide
theorem cert_e1208664312794 : check e1208664312794 [[],[]] .sourceHead = true := by decide
def e1208664313070 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1208664313070 : Closed e1208664313070 ∧ code e1208664313070 = 5606710824174 := by decide
theorem cert_e1208664313070 : check e1208664313070 [[],[]] .sourceHead = true := by decide
def e1208664313078 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1208664313078 : Closed e1208664313078 ∧ code e1208664313078 = 5606710824182 := by decide
theorem cert_e1208664313078 : check e1208664313078 [[],[]] .sourceHead = true := by decide
def e1208664313454 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1208664313454 : Closed e1208664313454 ∧ code e1208664313454 = 5606710824558 := by decide
theorem cert_e1208664313454 : check e1208664313454 [[],[]] .sourceHead = true := by decide
def e1208664313466 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1208664313466 : Closed e1208664313466 ∧ code e1208664313466 = 5606710824570 := by decide
theorem cert_e1208664313466 : check e1208664313466 [[],[]] .sourceHead = true := by decide
def e1208664313654 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1208664313654 : Closed e1208664313654 ∧ code e1208664313654 = 5606710824758 := by decide
theorem cert_e1208664313654 : check e1208664313654 [[],[]] .sourceHead = true := by decide
def e1208664313658 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1208664313658 : Closed e1208664313658 ∧ code e1208664313658 = 5606710824762 := by decide
theorem cert_e1208664313658 : check e1208664313658 [[],[]] .sourceHead = true := by decide
def e1208664319414 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1208664319414 : Closed e1208664319414 ∧ code e1208664319414 = 5606710830518 := by decide
theorem cert_e1208664319414 : check e1208664319414 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1208664319446 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1208664319446 : Closed e1208664319446 ∧ code e1208664319446 = 5606710830550 := by decide
theorem cert_e1208664319446 : check e1208664319446 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1208664319450 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1208664319450 : Closed e1208664319450 ∧ code e1208664319450 = 5606710830554 := by decide
theorem cert_e1208664319450 : check e1208664319450 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1208664319606 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1208664319606 : Closed e1208664319606 ∧ code e1208664319606 = 5606710830710 := by decide
theorem cert_e1208664319606 : check e1208664319606 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1208664319798 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1208664319798 : Closed e1208664319798 ∧ code e1208664319798 = 5606710830902 := by decide
theorem cert_e1208664319798 : check e1208664319798 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1208664319802 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1208664319802 : Closed e1208664319802 ∧ code e1208664319802 = 5606710830906 := by decide
theorem cert_e1208664319802 : check e1208664319802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1208664656750 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1208664656750 : Closed e1208664656750 ∧ code e1208664656750 = 5606711167854 := by decide
theorem cert_e1208664656750 : check e1208664656750 [[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1208664656758 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1208664656758 : Closed e1208664656758 ∧ code e1208664656758 = 5606711167862 := by decide
private def t_e1208664656758 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1208664656758 : ¬ IsSelfInterpreter e1208664656758 :=
  wSource (t := t_e1208664656758) (replay_sound (ps := []) (t := e1208664656758) (by decide)) (by decide)
def e1208664656814 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1208664656814 : Closed e1208664656814 ∧ code e1208664656814 = 5606711167918 := by decide
theorem cert_e1208664656814 : check e1208664656814 [[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e1208664656826 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1208664656826 : Closed e1208664656826 ∧ code e1208664656826 = 5606711167930 := by decide
theorem cert_e1208664656826 : check e1208664656826 [[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1208664656854 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1208664656854 : Closed e1208664656854 ∧ code e1208664656854 = 5606711167958 := by decide
private def t_e1208664656854 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1208664656854 : ¬ IsSelfInterpreter e1208664656854 :=
  wSource (t := t_e1208664656854) (replay_sound (ps := []) (t := e1208664656854) (by decide)) (by decide)
def e1208664656858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1208664656858 : Closed e1208664656858 ∧ code e1208664656858 = 5606711167962 := by decide
def e1208664657134 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1208664657134 : Closed e1208664657134 ∧ code e1208664657134 = 5606711168238 := by decide
theorem cert_e1208664657134 : check e1208664657134 [[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1208664657142 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1208664657142 : Closed e1208664657142 ∧ code e1208664657142 = 5606711168246 := by decide
def e1208664657518 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1208664657518 : Closed e1208664657518 ∧ code e1208664657518 = 5606711168622 := by decide
def e1208664657530 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1208664657530 : Closed e1208664657530 ∧ code e1208664657530 = 5606711168634 := by decide
theorem cert_e1208664657530 : check e1208664657530 [[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1208664657718 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1208664657718 : Closed e1208664657718 ∧ code e1208664657718 = 5606711168822 := by decide
def e1208664657722 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1208664657722 : Closed e1208664657722 ∧ code e1208664657722 = 5606711168826 := by decide
def e1209034792474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034792474 : Closed e1209034792474 ∧ code e1209034792474 = 5607081303578 := by decide
theorem cert_e1209034792474 : check e1209034792474 [[],[],[.left]] .chain = true := by decide
def e1209034798618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034798618 : Closed e1209034798618 ∧ code e1209034798618 = 5607081309722 := by decide
theorem cert_e1209034798618 : check e1209034798618 [[],[],[.left]] .chain = true := by decide
def e1209034825242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034825242 : Closed e1209034825242 ∧ code e1209034825242 = 5607081336346 := by decide
theorem cert_e1209034825242 : check e1209034825242 [[],[],[.left]] .chain = true := by decide
def e1209034832410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034832410 : Closed e1209034832410 ∧ code e1209034832410 = 5607081343514 := by decide
theorem cert_e1209034832410 : check e1209034832410 [[],[],[.left]] .chain = true := by decide
def e1209034855962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034855962 : Closed e1209034855962 ∧ code e1209034855962 = 5607081367066 := by decide
theorem cert_e1209034855962 : check e1209034855962 [[],[],[.left]] .chain = true := by decide
def e1209034856986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034856986 : Closed e1209034856986 ∧ code e1209034856986 = 5607081368090 := by decide
theorem cert_e1209034856986 : check e1209034856986 [[],[],[.left]] .chain = true := by decide
def e1209034989082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034989082 : Closed e1209034989082 ∧ code e1209034989082 = 5607081500186 := by decide
theorem cert_e1209034989082 : check e1209034989082 [[],[],[.left]] .chain = true := by decide
def e1209034995226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209034995226 : Closed e1209034995226 ∧ code e1209034995226 = 5607081506330 := by decide
theorem cert_e1209034995226 : check e1209034995226 [[],[],[.left]] .chain = true := by decide
def e1209035185690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209035185690 : Closed e1209035185690 ∧ code e1209035185690 = 5607081696794 := by decide
theorem cert_e1209035185690 : check e1209035185690 [[],[],[.left]] .chain = true := by decide
def e1209035192858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209035192858 : Closed e1209035192858 ∧ code e1209035192858 = 5607081703962 := by decide
theorem cert_e1209035192858 : check e1209035192858 [[],[],[.left]] .chain = true := by decide
def e1209035339290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209035339290 : Closed e1209035339290 ∧ code e1209035339290 = 5607081850394 := by decide
theorem cert_e1209035339290 : check e1209035339290 [[],[],[.left]] .chain = true := by decide
def e1209035340314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209035340314 : Closed e1209035340314 ∧ code e1209035340314 = 5607081851418 := by decide
theorem cert_e1209035340314 : check e1209035340314 [[],[],[.left]] .chain = true := by decide
def e1209039121946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039121946 : Closed e1209039121946 ∧ code e1209039121946 = 5607085633050 := by decide
theorem cert_e1209039121946 : check e1209039121946 [[],[],[.left]] .chain = true := by decide
def e1209039123994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039123994 : Closed e1209039123994 ∧ code e1209039123994 = 5607085635098 := by decide
theorem cert_e1209039123994 : check e1209039123994 [[],[],[.left]] .chain = true := by decide
def e1209039265306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039265306 : Closed e1209039265306 ∧ code e1209039265306 = 5607085776410 := by decide
theorem cert_e1209039265306 : check e1209039265306 [[],[],[.left]] .chain = true := by decide
def e1209039286470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209039286470 : Closed e1209039286470 ∧ code e1209039286470 = 5607085797574 := by decide
theorem cert_e1209039286470 : check e1209039286470 [[],[],[.left]] .chain = true := by decide
def e1209039288346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209039288346 : Closed e1209039288346 ∧ code e1209039288346 = 5607085799450 := by decide
theorem cert_e1209039288346 : check e1209039288346 [[]] .width = true := by decide
def e1209039293978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039293978 : Closed e1209039293978 ∧ code e1209039293978 = 5607085805082 := by decide
theorem cert_e1209039293978 : check e1209039293978 [[],[],[.left]] .chain = true := by decide
def e1209039302854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209039302854 : Closed e1209039302854 ∧ code e1209039302854 = 5607085813958 := by decide
theorem cert_e1209039302854 : check e1209039302854 [[],[],[.left]] .chain = true := by decide
def e1209039312922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209039312922 : Closed e1209039312922 ∧ code e1209039312922 = 5607085824026 := by decide
theorem cert_e1209039312922 : check e1209039312922 [[]] .width = true := by decide
def e1209039351322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039351322 : Closed e1209039351322 ∧ code e1209039351322 = 5607085862426 := by decide
theorem cert_e1209039351322 : check e1209039351322 [[],[],[.left]] .chain = true := by decide
def e1209039354394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039354394 : Closed e1209039354394 ∧ code e1209039354394 = 5607085865498 := by decide
theorem cert_e1209039354394 : check e1209039354394 [[],[],[.left]] .chain = true := by decide
def e1209039396378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039396378 : Closed e1209039396378 ∧ code e1209039396378 = 5607085907482 := by decide
theorem cert_e1209039396378 : check e1209039396378 [[],[],[.left]] .chain = true := by decide
def e1209039417542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209039417542 : Closed e1209039417542 ∧ code e1209039417542 = 5607085928646 := by decide
theorem cert_e1209039417542 : check e1209039417542 [[],[],[.left]] .chain = true := by decide
def e1209039419418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209039419418 : Closed e1209039419418 ∧ code e1209039419418 = 5607085930522 := by decide
theorem cert_e1209039419418 : check e1209039419418 [[]] .width = true := by decide
def e1209039439386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039439386 : Closed e1209039439386 ∧ code e1209039439386 = 5607085950490 := by decide
theorem cert_e1209039439386 : check e1209039439386 [[],[],[.left]] .chain = true := by decide
def e1209039442118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209039442118 : Closed e1209039442118 ∧ code e1209039442118 = 5607085953222 := by decide
theorem cert_e1209039442118 : check e1209039442118 [[],[],[.left]] .chain = true := by decide
def e1209039445530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039445530 : Closed e1209039445530 ∧ code e1209039445530 = 5607085956634 := by decide
theorem cert_e1209039445530 : check e1209039445530 [[]] .width = true := by decide
def e1209039448090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209039448090 : Closed e1209039448090 ∧ code e1209039448090 = 5607085959194 := by decide
theorem cert_e1209039448090 : check e1209039448090 [[]] .width = true := by decide
def e1209039449626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039449626 : Closed e1209039449626 ∧ code e1209039449626 = 5607085960730 := by decide
theorem cert_e1209039449626 : check e1209039449626 [[]] .width = true := by decide
def e1209039468058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039468058 : Closed e1209039468058 ∧ code e1209039468058 = 5607085979162 := by decide
theorem cert_e1209039468058 : check e1209039468058 [[],[],[.left]] .chain = true := by decide
def e1209039469082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039469082 : Closed e1209039469082 ∧ code e1209039469082 = 5607085980186 := by decide
theorem cert_e1209039469082 : check e1209039469082 [[],[],[.left]] .chain = true := by decide
def e1209039490586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039490586 : Closed e1209039490586 ∧ code e1209039490586 = 5607086001690 := by decide
theorem cert_e1209039490586 : check e1209039490586 [[],[],[.left]] .chain = true := by decide
def e1209039499462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209039499462 : Closed e1209039499462 ∧ code e1209039499462 = 5607086010566 := by decide
theorem cert_e1209039499462 : check e1209039499462 [[],[],[.left]] .chain = true := by decide
def e1209039504922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039504922 : Closed e1209039504922 ∧ code e1209039504922 = 5607086016026 := by decide
theorem cert_e1209039504922 : check e1209039504922 [[],[],[.left]] .chain = true := by decide
def e1209039507654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209039507654 : Closed e1209039507654 ∧ code e1209039507654 = 5607086018758 := by decide
theorem cert_e1209039507654 : check e1209039507654 [[],[],[.left]] .chain = true := by decide
def e1209039511066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039511066 : Closed e1209039511066 ∧ code e1209039511066 = 5607086022170 := by decide
theorem cert_e1209039511066 : check e1209039511066 [[]] .width = true := by decide
def e1209039517210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039517210 : Closed e1209039517210 ∧ code e1209039517210 = 5607086028314 := by decide
private def t_e1209039517210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209039517210 : ¬ IsSelfInterpreter e1209039517210 :=
  wSource (t := t_e1209039517210) (replay_sound (ps := []) (t := e1209039517210) (by decide)) (by decide)
def e1209039542298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209039542298 : Closed e1209039542298 ∧ code e1209039542298 = 5607086053402 := by decide
theorem cert_e1209039542298 : check e1209039542298 [[]] .width = true := by decide
def e1209039546394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209039546394 : Closed e1209039546394 ∧ code e1209039546394 = 5607086057498 := by decide
theorem cert_e1209039546394 : check e1209039546394 [[]] .width = true := by decide
def e1209039547930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039547930 : Closed e1209039547930 ∧ code e1209039547930 = 5607086059034 := by decide
theorem cert_e1209039547930 : check e1209039547930 [[]] .width = true := by decide
def e1209039549978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209039549978 : Closed e1209039549978 ∧ code e1209039549978 = 5607086061082 := by decide
private def t_e1209039549978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209039549978 : ¬ IsSelfInterpreter e1209039549978 :=
  wSource (t := t_e1209039549978) (replay_sound (ps := []) (t := e1209039549978) (by decide)) (by decide)
def e1209040051738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209040051738 : Closed e1209040051738 ∧ code e1209040051738 = 5607086562842 := by decide
theorem cert_e1209040051738 : check e1209040051738 [[],[],[.left]] .chain = true := by decide
def e1209040072902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209040072902 : Closed e1209040072902 ∧ code e1209040072902 = 5607086584006 := by decide
theorem cert_e1209040072902 : check e1209040072902 [[],[],[.left]] .chain = true := by decide
def e1209040074778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209040074778 : Closed e1209040074778 ∧ code e1209040074778 = 5607086585882 := by decide
theorem cert_e1209040074778 : check e1209040074778 [[]] .width = true := by decide
def e1209040080410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209040080410 : Closed e1209040080410 ∧ code e1209040080410 = 5607086591514 := by decide
theorem cert_e1209040080410 : check e1209040080410 [[],[],[.left]] .chain = true := by decide
def e1209040089286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209040089286 : Closed e1209040089286 ∧ code e1209040089286 = 5607086600390 := by decide
theorem cert_e1209040089286 : check e1209040089286 [[],[],[.left]] .chain = true := by decide
def e1209040099354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209040099354 : Closed e1209040099354 ∧ code e1209040099354 = 5607086610458 := by decide
theorem cert_e1209040099354 : check e1209040099354 [[]] .width = true := by decide
def e1209040838170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209040838170 : Closed e1209040838170 ∧ code e1209040838170 = 5607087349274 := by decide
theorem cert_e1209040838170 : check e1209040838170 [[],[],[.left]] .chain = true := by decide
def e1209040859334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209040859334 : Closed e1209040859334 ∧ code e1209040859334 = 5607087370438 := by decide
theorem cert_e1209040859334 : check e1209040859334 [[],[],[.left]] .chain = true := by decide
def e1209040861210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209040861210 : Closed e1209040861210 ∧ code e1209040861210 = 5607087372314 := by decide
theorem cert_e1209040861210 : check e1209040861210 [[]] .width = true := by decide
def e1209040881178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209040881178 : Closed e1209040881178 ∧ code e1209040881178 = 5607087392282 := by decide
theorem cert_e1209040881178 : check e1209040881178 [[],[],[.left]] .chain = true := by decide
def e1209040883910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209040883910 : Closed e1209040883910 ∧ code e1209040883910 = 5607087395014 := by decide
theorem cert_e1209040883910 : check e1209040883910 [[],[],[.left]] .chain = true := by decide
def e1209040887322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209040887322 : Closed e1209040887322 ∧ code e1209040887322 = 5607087398426 := by decide
theorem cert_e1209040887322 : check e1209040887322 [[]] .width = true := by decide
def e1209040889882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209040889882 : Closed e1209040889882 ∧ code e1209040889882 = 5607087400986 := by decide
theorem cert_e1209040889882 : check e1209040889882 [[]] .width = true := by decide
def e1209040891418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209040891418 : Closed e1209040891418 ∧ code e1209040891418 = 5607087402522 := by decide
theorem cert_e1209040891418 : check e1209040891418 [[]] .width = true := by decide
def e1209041260058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209041260058 : Closed e1209041260058 ∧ code e1209041260058 = 5607087771162 := by decide
theorem cert_e1209041260058 : check e1209041260058 [[],[],[.left]] .chain = true := by decide
def e1209041268934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209041268934 : Closed e1209041268934 ∧ code e1209041268934 = 5607087780038 := by decide
theorem cert_e1209041268934 : check e1209041268934 [[],[],[.left]] .chain = true := by decide
def e1209041274394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209041274394 : Closed e1209041274394 ∧ code e1209041274394 = 5607087785498 := by decide
theorem cert_e1209041274394 : check e1209041274394 [[],[],[.left]] .chain = true := by decide
def e1209041277126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1209041277126 : Closed e1209041277126 ∧ code e1209041277126 = 5607087788230 := by decide
theorem cert_e1209041277126 : check e1209041277126 [[],[],[.left]] .chain = true := by decide
def e1209041280538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209041280538 : Closed e1209041280538 ∧ code e1209041280538 = 5607087791642 := by decide
theorem cert_e1209041280538 : check e1209041280538 [[]] .width = true := by decide
def e1209041286682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209041286682 : Closed e1209041286682 ∧ code e1209041286682 = 5607087797786 := by decide
theorem cert_e1209041286682 : check e1209041286682 [[]] .width = true := by decide
def e1209041475610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209041475610 : Closed e1209041475610 ∧ code e1209041475610 = 5607087986714 := by decide
theorem cert_e1209041475610 : check e1209041475610 [[]] .width = true := by decide
def e1209041479706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209041479706 : Closed e1209041479706 ∧ code e1209041479706 = 5607087990810 := by decide
theorem cert_e1209041479706 : check e1209041479706 [[]] .width = true := by decide
def e1209041481242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209041481242 : Closed e1209041481242 ∧ code e1209041481242 = 5607087992346 := by decide
theorem cert_e1209041481242 : check e1209041481242 [[]] .width = true := by decide
def e1209041483290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209041483290 : Closed e1209041483290 ∧ code e1209041483290 = 5607087994394 := by decide
theorem cert_e1209041483290 : check e1209041483290 [[]] .width = true := by decide
def e1209056063002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056063002 : Closed e1209056063002 ∧ code e1209056063002 = 5607102574106 := by decide
theorem cert_e1209056063002 : check e1209056063002 [[]] .width = true := by decide
def e1209056065050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056065050 : Closed e1209056065050 ∧ code e1209056065050 = 5607102576154 := by decide
theorem cert_e1209056065050 : check e1209056065050 [[]] .width = true := by decide
def e1209056081434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056081434 : Closed e1209056081434 ∧ code e1209056081434 = 5607102592538 := by decide
theorem cert_e1209056081434 : check e1209056081434 [[]] .width = true := by decide
def e1209056194074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056194074 : Closed e1209056194074 ∧ code e1209056194074 = 5607102705178 := by decide
theorem cert_e1209056194074 : check e1209056194074 [[]] .width = true := by decide
def e1209056196122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056196122 : Closed e1209056196122 ∧ code e1209056196122 = 5607102707226 := by decide
theorem cert_e1209056196122 : check e1209056196122 [[]] .width = true := by decide
def e1209056210458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056210458 : Closed e1209056210458 ∧ code e1209056210458 = 5607102721562 := by decide
private def t_e1209056210458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209056210458 : ¬ IsSelfInterpreter e1209056210458 :=
  wSource (t := t_e1209056210458) (replay_sound (ps := []) (t := e1209056210458) (by decide)) (by decide)
def e1209056213530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056213530 : Closed e1209056213530 ∧ code e1209056213530 = 5607102724634 := by decide
private def t_e1209056213530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209056213530 : ¬ IsSelfInterpreter e1209056213530 :=
  wSource (t := t_e1209056213530) (replay_sound (ps := []) (t := e1209056213530) (by decide)) (by decide)
def e1209056220698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056220698 : Closed e1209056220698 ∧ code e1209056220698 = 5607102731802 := by decide
private def t_e1209056220698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209056220698 : ¬ IsSelfInterpreter e1209056220698 :=
  wSource (t := t_e1209056220698) (replay_sound (ps := []) (t := e1209056220698) (by decide)) (by decide)
def e1209056221722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056221722 : Closed e1209056221722 ∧ code e1209056221722 = 5607102732826 := by decide
private def t_e1209056221722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209056221722 : ¬ IsSelfInterpreter e1209056221722 :=
  wSource (t := t_e1209056221722) (replay_sound (ps := []) (t := e1209056221722) (by decide)) (by decide)
def e1209056278042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056278042 : Closed e1209056278042 ∧ code e1209056278042 = 5607102789146 := by decide
theorem cert_e1209056278042 : check e1209056278042 [[]] .width = true := by decide
def e1209056286234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056286234 : Closed e1209056286234 ∧ code e1209056286234 = 5607102797338 := by decide
private def t_e1209056286234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209056286234 : ¬ IsSelfInterpreter e1209056286234 :=
  wSource (t := t_e1209056286234) (replay_sound (ps := []) (t := e1209056286234) (by decide)) (by decide)
def e1209056287258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056287258 : Closed e1209056287258 ∧ code e1209056287258 = 5607102798362 := by decide
private def t_e1209056287258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209056287258 : ¬ IsSelfInterpreter e1209056287258 :=
  wSource (t := t_e1209056287258) (replay_sound (ps := []) (t := e1209056287258) (by decide)) (by decide)
end Blc.Floor42
