import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186502894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186502894 : Closed e1211186502894 ∧ code e1211186502894 = 5609233013998 := by decide
theorem cert_e1211186502894 : check e1211186502894 [[],[]] .smaller = true := by decide
def e1211186502902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186502902 : Closed e1211186502902 ∧ code e1211186502902 = 5609233014006 := by decide
theorem cert_e1211186502902 : check e1211186502902 [[],[]] .smaller = true := by decide
def e1211186502906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186502906 : Closed e1211186502906 ∧ code e1211186502906 = 5609233014010 := by decide
theorem cert_e1211186502906 : check e1211186502906 [[],[]] .three = true := by decide
def e1211186503182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186503182 : Closed e1211186503182 ∧ code e1211186503182 = 5609233014286 := by decide
theorem cert_e1211186503182 : check e1211186503182 [[],[]] .three = true := by decide
def e1211186503194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186503194 : Closed e1211186503194 ∧ code e1211186503194 = 5609233014298 := by decide
theorem cert_e1211186503194 : check e1211186503194 [[],[]] .three = true := by decide
def e1211186503230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 4))))))))
theorem wire_e1211186503230 : Closed e1211186503230 ∧ code e1211186503230 = 5609233014334 := by decide
theorem cert_e1211186503230 : check e1211186503230 [[],[]] .three = true := by decide
def e1211186503266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186503266 : Closed e1211186503266 ∧ code e1211186503266 = 5609233014370 := by decide
theorem cert_e1211186503266 : check e1211186503266 [[],[]] .three = true := by decide
def e1211186503278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186503278 : Closed e1211186503278 ∧ code e1211186503278 = 5609233014382 := by decide
theorem cert_e1211186503278 : check e1211186503278 [[],[]] .three = true := by decide
def e1211186503286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186503286 : Closed e1211186503286 ∧ code e1211186503286 = 5609233014390 := by decide
theorem cert_e1211186503286 : check e1211186503286 [[],[]] .three = true := by decide
def e1211186503290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186503290 : Closed e1211186503290 ∧ code e1211186503290 = 5609233014394 := by decide
theorem cert_e1211186503290 : check e1211186503290 [[],[]] .three = true := by decide
def e1211186503918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211186503918 : Closed e1211186503918 ∧ code e1211186503918 = 5609233015022 := by decide
theorem cert_e1211186503918 : check e1211186503918 [[],[]] .smaller = true := by decide
def e1211186503930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1211186503930 : Closed e1211186503930 ∧ code e1211186503930 = 5609233015034 := by decide
theorem cert_e1211186503930 : check e1211186503930 [[],[]] .smaller = true := by decide
def e1211186504302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186504302 : Closed e1211186504302 ∧ code e1211186504302 = 5609233015406 := by decide
theorem cert_e1211186504302 : check e1211186504302 [[],[]] .smaller = true := by decide
def e1211186504314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186504314 : Closed e1211186504314 ∧ code e1211186504314 = 5609233015418 := by decide
theorem cert_e1211186504314 : check e1211186504314 [[],[]] .smaller = true := by decide
def e1211186504478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211186504478 : Closed e1211186504478 ∧ code e1211186504478 = 5609233015582 := by decide
theorem cert_e1211186504478 : check e1211186504478 [[],[]] .smaller = true := by decide
def e1211186504646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e1211186504646 : Closed e1211186504646 ∧ code e1211186504646 = 5609233015750 := by decide
theorem cert_e1211186504646 : check e1211186504646 [[],[]] .smaller = true := by decide
def e1211186504670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e1211186504670 : Closed e1211186504670 ∧ code e1211186504670 = 5609233015774 := by decide
theorem cert_e1211186504670 : check e1211186504670 [[],[]] .three = true := by decide
def e1211186504686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e1211186504686 : Closed e1211186504686 ∧ code e1211186504686 = 5609233015790 := by decide
theorem cert_e1211186504686 : check e1211186504686 [[],[]] .three = true := by decide
def e1211186505262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211186505262 : Closed e1211186505262 ∧ code e1211186505262 = 5609233016366 := by decide
theorem cert_e1211186505262 : check e1211186505262 [[],[]] .smaller = true := by decide
def e1211186505438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1211186505438 : Closed e1211186505438 ∧ code e1211186505438 = 5609233016542 := by decide
theorem cert_e1211186505438 : check e1211186505438 [[],[]] .three = true := by decide
def e1211186505442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211186505442 : Closed e1211186505442 ∧ code e1211186505442 = 5609233016546 := by decide
theorem cert_e1211186505442 : check e1211186505442 [[],[]] .smaller = true := by decide
def e1211186505454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e1211186505454 : Closed e1211186505454 ∧ code e1211186505454 = 5609233016558 := by decide
theorem cert_e1211186505454 : check e1211186505454 [[],[]] .smaller = true := by decide
def e1211186505462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1211186505462 : Closed e1211186505462 ∧ code e1211186505462 = 5609233016566 := by decide
theorem cert_e1211186505462 : check e1211186505462 [[],[]] .three = true := by decide
def e1211186505566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1211186505566 : Closed e1211186505566 ∧ code e1211186505566 = 5609233016670 := by decide
theorem cert_e1211186505566 : check e1211186505566 [[],[]] .three = true := by decide
def e1211186505594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1211186505594 : Closed e1211186505594 ∧ code e1211186505594 = 5609233016698 := by decide
theorem cert_e1211186505594 : check e1211186505594 [[],[]] .three = true := by decide
def e1211186505610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186505610 : Closed e1211186505610 ∧ code e1211186505610 = 5609233016714 := by decide
theorem cert_e1211186505610 : check e1211186505610 [[],[]] .smaller = true := by decide
def e1211186505634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186505634 : Closed e1211186505634 ∧ code e1211186505634 = 5609233016738 := by decide
theorem cert_e1211186505634 : check e1211186505634 [[],[]] .smaller = true := by decide
def e1211186505646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e1211186505646 : Closed e1211186505646 ∧ code e1211186505646 = 5609233016750 := by decide
theorem cert_e1211186505646 : check e1211186505646 [[],[]] .smaller = true := by decide
def e1211186505658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e1211186505658 : Closed e1211186505658 ∧ code e1211186505658 = 5609233016762 := by decide
theorem cert_e1211186505658 : check e1211186505658 [[],[]] .smaller = true := by decide
def e1211186505686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1211186505686 : Closed e1211186505686 ∧ code e1211186505686 = 5609233016790 := by decide
theorem cert_e1211186505686 : check e1211186505686 [[],[]] .three = true := by decide
def e1211186505690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1211186505690 : Closed e1211186505690 ∧ code e1211186505690 = 5609233016794 := by decide
theorem cert_e1211186505690 : check e1211186505690 [[],[]] .three = true := by decide
def e1211186505790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e1211186505790 : Closed e1211186505790 ∧ code e1211186505790 = 5609233016894 := by decide
theorem cert_e1211186505790 : check e1211186505790 [[],[]] .smaller = true := by decide
def e1211186506206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186506206 : Closed e1211186506206 ∧ code e1211186506206 = 5609233017310 := by decide
theorem cert_e1211186506206 : check e1211186506206 [[],[]] .three = true := by decide
def e1211186506210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211186506210 : Closed e1211186506210 ∧ code e1211186506210 = 5609233017314 := by decide
theorem cert_e1211186506210 : check e1211186506210 [[],[]] .smaller = true := by decide
def e1211186506222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186506222 : Closed e1211186506222 ∧ code e1211186506222 = 5609233017326 := by decide
theorem cert_e1211186506222 : check e1211186506222 [[],[]] .smaller = true := by decide
def e1211186506230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186506230 : Closed e1211186506230 ∧ code e1211186506230 = 5609233017334 := by decide
theorem cert_e1211186506230 : check e1211186506230 [[],[]] .three = true := by decide
def e1211186506974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186506974 : Closed e1211186506974 ∧ code e1211186506974 = 5609233018078 := by decide
theorem cert_e1211186506974 : check e1211186506974 [[],[]] .three = true := by decide
def e1211186507002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186507002 : Closed e1211186507002 ∧ code e1211186507002 = 5609233018106 := by decide
theorem cert_e1211186507002 : check e1211186507002 [[],[]] .three = true := by decide
def e1211186507278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186507278 : Closed e1211186507278 ∧ code e1211186507278 = 5609233018382 := by decide
theorem cert_e1211186507278 : check e1211186507278 [[],[]] .smaller = true := by decide
def e1211186507326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e1211186507326 : Closed e1211186507326 ∧ code e1211186507326 = 5609233018430 := by decide
theorem cert_e1211186507326 : check e1211186507326 [[],[]] .three = true := by decide
def e1211186507362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186507362 : Closed e1211186507362 ∧ code e1211186507362 = 5609233018466 := by decide
theorem cert_e1211186507362 : check e1211186507362 [[],[]] .smaller = true := by decide
def e1211186507374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186507374 : Closed e1211186507374 ∧ code e1211186507374 = 5609233018478 := by decide
theorem cert_e1211186507374 : check e1211186507374 [[],[]] .smaller = true := by decide
def e1211186507386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186507386 : Closed e1211186507386 ∧ code e1211186507386 = 5609233018490 := by decide
theorem cert_e1211186507386 : check e1211186507386 [[],[]] .smaller = true := by decide
def e1211186507550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e1211186507550 : Closed e1211186507550 ∧ code e1211186507550 = 5609233018654 := by decide
theorem cert_e1211186507550 : check e1211186507550 [[],[]] .three = true := by decide
def e1211186507574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186507574 : Closed e1211186507574 ∧ code e1211186507574 = 5609233018678 := by decide
theorem cert_e1211186507574 : check e1211186507574 [[],[]] .three = true := by decide
def e1211186507578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186507578 : Closed e1211186507578 ∧ code e1211186507578 = 5609233018682 := by decide
theorem cert_e1211186507578 : check e1211186507578 [[],[]] .three = true := by decide
def e1211186507894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211186507894 : Closed e1211186507894 ∧ code e1211186507894 = 5609233018998 := by decide
theorem cert_e1211186507894 : check e1211186507894 [[],[]] .smaller = true := by decide
def e1211186507898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186507898 : Closed e1211186507898 ∧ code e1211186507898 = 5609233019002 := by decide
theorem cert_e1211186507898 : check e1211186507898 [[],[]] .smaller = true := by decide
def e1211186507994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211186507994 : Closed e1211186507994 ∧ code e1211186507994 = 5609233019098 := by decide
theorem cert_e1211186507994 : check e1211186507994 [[],[]] .smaller = true := by decide
def e1211186508010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211186508010 : Closed e1211186508010 ∧ code e1211186508010 = 5609233019114 := by decide
theorem cert_e1211186508010 : check e1211186508010 [[],[]] .smaller = true := by decide
def e1211186508086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186508086 : Closed e1211186508086 ∧ code e1211186508086 = 5609233019190 := by decide
theorem cert_e1211186508086 : check e1211186508086 [[],[]] .smaller = true := by decide
def e1211186508090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186508090 : Closed e1211186508090 ∧ code e1211186508090 = 5609233019194 := by decide
theorem cert_e1211186508090 : check e1211186508090 [[],[]] .smaller = true := by decide
def e1211186508174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211186508174 : Closed e1211186508174 ∧ code e1211186508174 = 5609233019278 := by decide
theorem cert_e1211186508174 : check e1211186508174 [[],[]] .smaller = true := by decide
def e1211186508186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186508186 : Closed e1211186508186 ∧ code e1211186508186 = 5609233019290 := by decide
theorem cert_e1211186508186 : check e1211186508186 [[],[]] .smaller = true := by decide
def e1211186508230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186508230 : Closed e1211186508230 ∧ code e1211186508230 = 5609233019334 := by decide
theorem cert_e1211186508230 : check e1211186508230 [[],[]] .smaller = true := by decide
def e1211186508254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e1211186508254 : Closed e1211186508254 ∧ code e1211186508254 = 5609233019358 := by decide
theorem cert_e1211186508254 : check e1211186508254 [[],[]] .three = true := by decide
def e1211186508278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e1211186508278 : Closed e1211186508278 ∧ code e1211186508278 = 5609233019382 := by decide
theorem cert_e1211186508278 : check e1211186508278 [[],[]] .three = true := by decide
def e1211186508566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186508566 : Closed e1211186508566 ∧ code e1211186508566 = 5609233019670 := by decide
theorem cert_e1211186508566 : check e1211186508566 [[],[]] .smaller = true := by decide
def e1211186508570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186508570 : Closed e1211186508570 ∧ code e1211186508570 = 5609233019674 := by decide
theorem cert_e1211186508570 : check e1211186508570 [[],[]] .smaller = true := by decide
def e1211186508614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186508614 : Closed e1211186508614 ∧ code e1211186508614 = 5609233019718 := by decide
theorem cert_e1211186508614 : check e1211186508614 [[],[]] .smaller = true := by decide
def e1211186508638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1211186508638 : Closed e1211186508638 ∧ code e1211186508638 = 5609233019742 := by decide
theorem cert_e1211186508638 : check e1211186508638 [[],[]] .three = true := by decide
def e1211186508642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186508642 : Closed e1211186508642 ∧ code e1211186508642 = 5609233019746 := by decide
theorem cert_e1211186508642 : check e1211186508642 [[],[]] .smaller = true := by decide
def e1211186508654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211186508654 : Closed e1211186508654 ∧ code e1211186508654 = 5609233019758 := by decide
theorem cert_e1211186508654 : check e1211186508654 [[],[]] .smaller = true := by decide
def e1211186508662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211186508662 : Closed e1211186508662 ∧ code e1211186508662 = 5609233019766 := by decide
theorem cert_e1211186508662 : check e1211186508662 [[],[]] .smaller = true := by decide
def e1211186508666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1211186508666 : Closed e1211186508666 ∧ code e1211186508666 = 5609233019770 := by decide
theorem cert_e1211186508666 : check e1211186508666 [[],[]] .three = true := by decide
def e1211186508682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186508682 : Closed e1211186508682 ∧ code e1211186508682 = 5609233019786 := by decide
theorem cert_e1211186508682 : check e1211186508682 [[],[]] .smaller = true := by decide
def e1211186508706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186508706 : Closed e1211186508706 ∧ code e1211186508706 = 5609233019810 := by decide
theorem cert_e1211186508706 : check e1211186508706 [[],[]] .smaller = true := by decide
def e1211186508718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211186508718 : Closed e1211186508718 ∧ code e1211186508718 = 5609233019822 := by decide
theorem cert_e1211186508718 : check e1211186508718 [[],[]] .smaller = true := by decide
def e1211186508730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211186508730 : Closed e1211186508730 ∧ code e1211186508730 = 5609233019834 := by decide
theorem cert_e1211186508730 : check e1211186508730 [[],[]] .smaller = true := by decide
def e1211186508758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211186508758 : Closed e1211186508758 ∧ code e1211186508758 = 5609233019862 := by decide
theorem cert_e1211186508758 : check e1211186508758 [[],[]] .smaller = true := by decide
def e1211186508762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211186508762 : Closed e1211186508762 ∧ code e1211186508762 = 5609233019866 := by decide
theorem cert_e1211186508762 : check e1211186508762 [[],[]] .smaller = true := by decide
def e1211186508778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1211186508778 : Closed e1211186508778 ∧ code e1211186508778 = 5609233019882 := by decide
theorem cert_e1211186508778 : check e1211186508778 [[],[]] .three = true := by decide
def e1211186508830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186508830 : Closed e1211186508830 ∧ code e1211186508830 = 5609233019934 := by decide
theorem cert_e1211186508830 : check e1211186508830 [[],[]] .smaller = true := by decide
def e1211186508854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186508854 : Closed e1211186508854 ∧ code e1211186508854 = 5609233019958 := by decide
theorem cert_e1211186508854 : check e1211186508854 [[],[]] .smaller = true := by decide
def e1211186508858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186508858 : Closed e1211186508858 ∧ code e1211186508858 = 5609233019962 := by decide
theorem cert_e1211186508858 : check e1211186508858 [[],[]] .smaller = true := by decide
def e1211186508998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186508998 : Closed e1211186508998 ∧ code e1211186508998 = 5609233020102 := by decide
theorem cert_e1211186508998 : check e1211186508998 [[],[]] .smaller = true := by decide
def e1211186509022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186509022 : Closed e1211186509022 ∧ code e1211186509022 = 5609233020126 := by decide
theorem cert_e1211186509022 : check e1211186509022 [[],[]] .three = true := by decide
def e1211186509026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186509026 : Closed e1211186509026 ∧ code e1211186509026 = 5609233020130 := by decide
theorem cert_e1211186509026 : check e1211186509026 [[],[]] .smaller = true := by decide
def e1211186509038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186509038 : Closed e1211186509038 ∧ code e1211186509038 = 5609233020142 := by decide
theorem cert_e1211186509038 : check e1211186509038 [[],[]] .smaller = true := by decide
def e1211186509046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186509046 : Closed e1211186509046 ∧ code e1211186509046 = 5609233020150 := by decide
theorem cert_e1211186509046 : check e1211186509046 [[],[]] .smaller = true := by decide
def e1211186509050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186509050 : Closed e1211186509050 ∧ code e1211186509050 = 5609233020154 := by decide
theorem cert_e1211186509050 : check e1211186509050 [[],[]] .three = true := by decide
def e1211186509326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186509326 : Closed e1211186509326 ∧ code e1211186509326 = 5609233020430 := by decide
theorem cert_e1211186509326 : check e1211186509326 [[],[]] .smaller = true := by decide
def e1211186509374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e1211186509374 : Closed e1211186509374 ∧ code e1211186509374 = 5609233020478 := by decide
theorem cert_e1211186509374 : check e1211186509374 [[],[]] .three = true := by decide
def e1211186509410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186509410 : Closed e1211186509410 ∧ code e1211186509410 = 5609233020514 := by decide
theorem cert_e1211186509410 : check e1211186509410 [[],[]] .smaller = true := by decide
def e1211186509422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186509422 : Closed e1211186509422 ∧ code e1211186509422 = 5609233020526 := by decide
theorem cert_e1211186509422 : check e1211186509422 [[],[]] .smaller = true := by decide
def e1211186509434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186509434 : Closed e1211186509434 ∧ code e1211186509434 = 5609233020538 := by decide
theorem cert_e1211186509434 : check e1211186509434 [[],[]] .smaller = true := by decide
def e1211186509622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186509622 : Closed e1211186509622 ∧ code e1211186509622 = 5609233020726 := by decide
theorem cert_e1211186509622 : check e1211186509622 [[],[]] .smaller = true := by decide
def e1211186509626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186509626 : Closed e1211186509626 ∧ code e1211186509626 = 5609233020730 := by decide
theorem cert_e1211186509626 : check e1211186509626 [[],[]] .smaller = true := by decide
def e1211186509710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e1211186509710 : Closed e1211186509710 ∧ code e1211186509710 = 5609233020814 := by decide
theorem cert_e1211186509710 : check e1211186509710 [[],[]] .three = true := by decide
def e1211186509722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186509722 : Closed e1211186509722 ∧ code e1211186509722 = 5609233020826 := by decide
theorem cert_e1211186509722 : check e1211186509722 [[],[]] .three = true := by decide
def e1211186509882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211186509882 : Closed e1211186509882 ∧ code e1211186509882 = 5609233020986 := by decide
theorem cert_e1211186509882 : check e1211186509882 [[],[]] .three = true := by decide
def e1211186509930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211186509930 : Closed e1211186509930 ∧ code e1211186509930 = 5609233021034 := by decide
theorem cert_e1211186509930 : check e1211186509930 [[],[]] .three = true := by decide
def e1211186509978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186509978 : Closed e1211186509978 ∧ code e1211186509978 = 5609233021082 := by decide
theorem cert_e1211186509978 : check e1211186509978 [[],[]] .three = true := by decide
def e1211186510022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211186510022 : Closed e1211186510022 ∧ code e1211186510022 = 5609233021126 := by decide
theorem cert_e1211186510022 : check e1211186510022 [[],[]] .three = true := by decide
def e1211186510046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1211186510046 : Closed e1211186510046 ∧ code e1211186510046 = 5609233021150 := by decide
theorem cert_e1211186510046 : check e1211186510046 [[],[]] .three = true := by decide
def e1211186510062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211186510062 : Closed e1211186510062 ∧ code e1211186510062 = 5609233021166 := by decide
theorem cert_e1211186510062 : check e1211186510062 [[],[]] .three = true := by decide
def e1211186510070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211186510070 : Closed e1211186510070 ∧ code e1211186510070 = 5609233021174 := by decide
theorem cert_e1211186510070 : check e1211186510070 [[],[]] .three = true := by decide
def e1211186510074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1211186510074 : Closed e1211186510074 ∧ code e1211186510074 = 5609233021178 := by decide
theorem cert_e1211186510074 : check e1211186510074 [[],[]] .three = true := by decide
def e1211186510218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186510218 : Closed e1211186510218 ∧ code e1211186510218 = 5609233021322 := by decide
theorem cert_e1211186510218 : check e1211186510218 [[],[]] .three = true := by decide
def e1211186510242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186510242 : Closed e1211186510242 ∧ code e1211186510242 = 5609233021346 := by decide
theorem cert_e1211186510242 : check e1211186510242 [[],[]] .three = true := by decide
def e1211186510254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211186510254 : Closed e1211186510254 ∧ code e1211186510254 = 5609233021358 := by decide
theorem cert_e1211186510254 : check e1211186510254 [[],[]] .three = true := by decide
def e1211186510262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211186510262 : Closed e1211186510262 ∧ code e1211186510262 = 5609233021366 := by decide
theorem cert_e1211186510262 : check e1211186510262 [[],[]] .three = true := by decide
def e1211186510266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211186510266 : Closed e1211186510266 ∧ code e1211186510266 = 5609233021370 := by decide
theorem cert_e1211186510266 : check e1211186510266 [[],[]] .three = true := by decide
def e1211186510294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211186510294 : Closed e1211186510294 ∧ code e1211186510294 = 5609233021398 := by decide
theorem cert_e1211186510294 : check e1211186510294 [[],[]] .three = true := by decide
def e1211186510298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211186510298 : Closed e1211186510298 ∧ code e1211186510298 = 5609233021402 := by decide
theorem cert_e1211186510298 : check e1211186510298 [[],[]] .three = true := by decide
def e1211186510314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211186510314 : Closed e1211186510314 ∧ code e1211186510314 = 5609233021418 := by decide
theorem cert_e1211186510314 : check e1211186510314 [[],[]] .three = true := by decide
def e1211186510350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186510350 : Closed e1211186510350 ∧ code e1211186510350 = 5609233021454 := by decide
theorem cert_e1211186510350 : check e1211186510350 [[],[]] .three = true := by decide
def e1211186510362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186510362 : Closed e1211186510362 ∧ code e1211186510362 = 5609233021466 := by decide
theorem cert_e1211186510362 : check e1211186510362 [[],[]] .three = true := by decide
def e1211186510398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1211186510398 : Closed e1211186510398 ∧ code e1211186510398 = 5609233021502 := by decide
theorem cert_e1211186510398 : check e1211186510398 [[],[]] .three = true := by decide
def e1211186510434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186510434 : Closed e1211186510434 ∧ code e1211186510434 = 5609233021538 := by decide
theorem cert_e1211186510434 : check e1211186510434 [[],[]] .three = true := by decide
def e1211186510446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186510446 : Closed e1211186510446 ∧ code e1211186510446 = 5609233021550 := by decide
theorem cert_e1211186510446 : check e1211186510446 [[],[]] .three = true := by decide
def e1211186510454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186510454 : Closed e1211186510454 ∧ code e1211186510454 = 5609233021558 := by decide
theorem cert_e1211186510454 : check e1211186510454 [[],[]] .three = true := by decide
def e1211186510458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186510458 : Closed e1211186510458 ∧ code e1211186510458 = 5609233021562 := by decide
theorem cert_e1211186510458 : check e1211186510458 [[],[]] .three = true := by decide
def e1211186510622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211186510622 : Closed e1211186510622 ∧ code e1211186510622 = 5609233021726 := by decide
theorem cert_e1211186510622 : check e1211186510622 [[],[]] .three = true := by decide
def e1211186510646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186510646 : Closed e1211186510646 ∧ code e1211186510646 = 5609233021750 := by decide
theorem cert_e1211186510646 : check e1211186510646 [[],[]] .three = true := by decide
def e1211186510650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186510650 : Closed e1211186510650 ∧ code e1211186510650 = 5609233021754 := by decide
theorem cert_e1211186510650 : check e1211186510650 [[],[]] .three = true := by decide
def e1211186510734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211186510734 : Closed e1211186510734 ∧ code e1211186510734 = 5609233021838 := by decide
theorem cert_e1211186510734 : check e1211186510734 [[],[]] .three = true := by decide
def e1211186510746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186510746 : Closed e1211186510746 ∧ code e1211186510746 = 5609233021850 := by decide
theorem cert_e1211186510746 : check e1211186510746 [[],[]] .three = true := by decide
def e1211186510790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1211186510790 : Closed e1211186510790 ∧ code e1211186510790 = 5609233021894 := by decide
theorem cert_e1211186510790 : check e1211186510790 [[],[]] .three = true := by decide
def e1211186512822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 1)))))))
theorem wire_e1211186512822 : Closed e1211186512822 ∧ code e1211186512822 = 5609233023926 := by decide
theorem cert_e1211186512822 : check e1211186512822 [[],[]] .smaller = true := by decide
def e1211186512854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186512854 : Closed e1211186512854 ∧ code e1211186512854 = 5609233023958 := by decide
theorem cert_e1211186512854 : check e1211186512854 [[],[]] .smaller = true := by decide
def e1211186512858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186512858 : Closed e1211186512858 ∧ code e1211186512858 = 5609233023962 := by decide
theorem cert_e1211186512858 : check e1211186512858 [[],[]] .smaller = true := by decide
def e1211186513622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186513622 : Closed e1211186513622 ∧ code e1211186513622 = 5609233024726 := by decide
theorem cert_e1211186513622 : check e1211186513622 [[],[]] .smaller = true := by decide
def e1211186513626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186513626 : Closed e1211186513626 ∧ code e1211186513626 = 5609233024730 := by decide
theorem cert_e1211186513626 : check e1211186513626 [[],[]] .smaller = true := by decide
def e1211186513642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186513642 : Closed e1211186513642 ∧ code e1211186513642 = 5609233024746 := by decide
theorem cert_e1211186513642 : check e1211186513642 [[],[]] .smaller = true := by decide
def e1211186513750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186513750 : Closed e1211186513750 ∧ code e1211186513750 = 5609233024854 := by decide
theorem cert_e1211186513750 : check e1211186513750 [[],[]] .smaller = true := by decide
def e1211186513754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186513754 : Closed e1211186513754 ∧ code e1211186513754 = 5609233024858 := by decide
theorem cert_e1211186513754 : check e1211186513754 [[],[]] .smaller = true := by decide
def e1211186513834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186513834 : Closed e1211186513834 ∧ code e1211186513834 = 5609233024938 := by decide
theorem cert_e1211186513834 : check e1211186513834 [[],[]] .smaller = true := by decide
def e1211186514358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211186514358 : Closed e1211186514358 ∧ code e1211186514358 = 5609233025462 := by decide
theorem cert_e1211186514358 : check e1211186514358 [[],[]] .smaller = true := by decide
def e1211186514390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211186514390 : Closed e1211186514390 ∧ code e1211186514390 = 5609233025494 := by decide
theorem cert_e1211186514390 : check e1211186514390 [[],[]] .smaller = true := by decide
def e1211186514394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211186514394 : Closed e1211186514394 ∧ code e1211186514394 = 5609233025498 := by decide
theorem cert_e1211186514394 : check e1211186514394 [[],[]] .smaller = true := by decide
def e1211186514550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186514550 : Closed e1211186514550 ∧ code e1211186514550 = 5609233025654 := by decide
theorem cert_e1211186514550 : check e1211186514550 [[],[]] .smaller = true := by decide
def e1211186514742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186514742 : Closed e1211186514742 ∧ code e1211186514742 = 5609233025846 := by decide
theorem cert_e1211186514742 : check e1211186514742 [[],[]] .smaller = true := by decide
def e1211186514746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186514746 : Closed e1211186514746 ∧ code e1211186514746 = 5609233025850 := by decide
theorem cert_e1211186514746 : check e1211186514746 [[],[]] .smaller = true := by decide
def e1211186515062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211186515062 : Closed e1211186515062 ∧ code e1211186515062 = 5609233026166 := by decide
theorem cert_e1211186515062 : check e1211186515062 [[],[]] .smaller = true := by decide
def e1211186515158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211186515158 : Closed e1211186515158 ∧ code e1211186515158 = 5609233026262 := by decide
theorem cert_e1211186515158 : check e1211186515158 [[],[]] .smaller = true := by decide
def e1211186515162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211186515162 : Closed e1211186515162 ∧ code e1211186515162 = 5609233026266 := by decide
theorem cert_e1211186515162 : check e1211186515162 [[],[]] .smaller = true := by decide
def e1211186515178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211186515178 : Closed e1211186515178 ∧ code e1211186515178 = 5609233026282 := by decide
theorem cert_e1211186515178 : check e1211186515178 [[],[]] .smaller = true := by decide
def e1211186515254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186515254 : Closed e1211186515254 ∧ code e1211186515254 = 5609233026358 := by decide
theorem cert_e1211186515254 : check e1211186515254 [[],[]] .smaller = true := by decide
def e1211186515258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186515258 : Closed e1211186515258 ∧ code e1211186515258 = 5609233026362 := by decide
theorem cert_e1211186515258 : check e1211186515258 [[],[]] .smaller = true := by decide
def e1211186515342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211186515342 : Closed e1211186515342 ∧ code e1211186515342 = 5609233026446 := by decide
theorem cert_e1211186515342 : check e1211186515342 [[],[]] .smaller = true := by decide
def e1211186515354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186515354 : Closed e1211186515354 ∧ code e1211186515354 = 5609233026458 := by decide
theorem cert_e1211186515354 : check e1211186515354 [[],[]] .smaller = true := by decide
def e1211186515422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e1211186515422 : Closed e1211186515422 ∧ code e1211186515422 = 5609233026526 := by decide
theorem cert_e1211186515422 : check e1211186515422 [[],[]] .three = true := by decide
def e1211186515438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e1211186515438 : Closed e1211186515438 ∧ code e1211186515438 = 5609233026542 := by decide
theorem cert_e1211186515438 : check e1211186515438 [[],[]] .three = true := by decide
def e1211186515510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186515510 : Closed e1211186515510 ∧ code e1211186515510 = 5609233026614 := by decide
theorem cert_e1211186515510 : check e1211186515510 [[],[]] .smaller = true := by decide
def e1211186515514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186515514 : Closed e1211186515514 ∧ code e1211186515514 = 5609233026618 := by decide
theorem cert_e1211186515514 : check e1211186515514 [[],[]] .smaller = true := by decide
def e1211186515562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211186515562 : Closed e1211186515562 ∧ code e1211186515562 = 5609233026666 := by decide
theorem cert_e1211186515562 : check e1211186515562 [[],[]] .smaller = true := by decide
def e1211186515598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186515598 : Closed e1211186515598 ∧ code e1211186515598 = 5609233026702 := by decide
theorem cert_e1211186515598 : check e1211186515598 [[],[]] .smaller = true := by decide
def e1211186515610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186515610 : Closed e1211186515610 ∧ code e1211186515610 = 5609233026714 := by decide
theorem cert_e1211186515610 : check e1211186515610 [[],[]] .smaller = true := by decide
def e1211186515654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186515654 : Closed e1211186515654 ∧ code e1211186515654 = 5609233026758 := by decide
theorem cert_e1211186515654 : check e1211186515654 [[],[]] .smaller = true := by decide
def e1211186515678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e1211186515678 : Closed e1211186515678 ∧ code e1211186515678 = 5609233026782 := by decide
theorem cert_e1211186515678 : check e1211186515678 [[],[]] .three = true := by decide
def e1211186515702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e1211186515702 : Closed e1211186515702 ∧ code e1211186515702 = 5609233026806 := by decide
theorem cert_e1211186515702 : check e1211186515702 [[],[]] .three = true := by decide
def e1211186515806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 3)))))))
theorem wire_e1211186515806 : Closed e1211186515806 ∧ code e1211186515806 = 5609233026910 := by decide
theorem cert_e1211186515806 : check e1211186515806 [[],[]] .three = true := by decide
def e1211186515834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 3)) (.var 0)))))))
theorem wire_e1211186515834 : Closed e1211186515834 ∧ code e1211186515834 = 5609233026938 := by decide
theorem cert_e1211186515834 : check e1211186515834 [[],[]] .three = true := by decide
def e1211186515886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 0)) (.var 2)))))))
theorem wire_e1211186515886 : Closed e1211186515886 ∧ code e1211186515886 = 5609233026990 := by decide
theorem cert_e1211186515886 : check e1211186515886 [[],[]] .three = true := by decide
def e1211186515894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 1)) (.var 1)))))))
theorem wire_e1211186515894 : Closed e1211186515894 ∧ code e1211186515894 = 5609233026998 := by decide
theorem cert_e1211186515894 : check e1211186515894 [[],[]] .three = true := by decide
def e1211186515898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 2)) (.var 0)))))))
theorem wire_e1211186515898 : Closed e1211186515898 ∧ code e1211186515898 = 5609233027002 := by decide
theorem cert_e1211186515898 : check e1211186515898 [[],[]] .three = true := by decide
def e1211186518198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e1211186518198 : Closed e1211186518198 ∧ code e1211186518198 = 5609233029302 := by decide
theorem cert_e1211186518198 : check e1211186518198 [[],[]] .smaller = true := by decide
def e1211186518230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186518230 : Closed e1211186518230 ∧ code e1211186518230 = 5609233029334 := by decide
theorem cert_e1211186518230 : check e1211186518230 [[],[]] .smaller = true := by decide
def e1211186518234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186518234 : Closed e1211186518234 ∧ code e1211186518234 = 5609233029338 := by decide
theorem cert_e1211186518234 : check e1211186518234 [[],[]] .smaller = true := by decide
end Blc.Floor42
