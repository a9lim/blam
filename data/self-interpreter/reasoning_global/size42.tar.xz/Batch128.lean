import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209571679866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571679866 : Closed e1209571679866 ∧ code e1209571679866 = 5607618190970 := by decide
theorem cert_e1209571679866 : checkPay e1209571679866 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.under,.under,.right]] = true := by decide
def e1209571683694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1209571683694 : Closed e1209571683694 ∧ code e1209571683694 = 5607618194798 := by decide
theorem cert_e1209571683694 : checkPay e1209571683694 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1209571683702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1209571683702 : Closed e1209571683702 ∧ code e1209571683702 = 5607618194806 := by decide
theorem cert_e1209571683702 : checkPay e1209571683702 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1209571683758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1209571683758 : Closed e1209571683758 ∧ code e1209571683758 = 5607618194862 := by decide
theorem cert_e1209571683758 : checkPay e1209571683758 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e1209571683770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1209571683770 : Closed e1209571683770 ∧ code e1209571683770 = 5607618194874 := by decide
theorem cert_e1209571683770 : checkPay e1209571683770 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.right]] = true := by decide
def e1209571683798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1209571683798 : Closed e1209571683798 ∧ code e1209571683798 = 5607618194902 := by decide
theorem cert_e1209571683798 : checkPay e1209571683798 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1209571683802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1209571683802 : Closed e1209571683802 ∧ code e1209571683802 = 5607618194906 := by decide
theorem cert_e1209571683802 : checkPay e1209571683802 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1209571684014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1209571684014 : Closed e1209571684014 ∧ code e1209571684014 = 5607618195118 := by decide
theorem cert_e1209571684014 : checkPay e1209571684014 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571684026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1209571684026 : Closed e1209571684026 ∧ code e1209571684026 = 5607618195130 := by decide
theorem cert_e1209571684026 : checkPay e1209571684026 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e1209571684074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1209571684074 : Closed e1209571684074 ∧ code e1209571684074 = 5607618195178 := by decide
theorem cert_e1209571684074 : checkPay e1209571684074 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.right]] = true := by decide
def e1209571684182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1209571684182 : Closed e1209571684182 ∧ code e1209571684182 = 5607618195286 := by decide
theorem cert_e1209571684182 : checkPay e1209571684182 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1209571684186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1209571684186 : Closed e1209571684186 ∧ code e1209571684186 = 5607618195290 := by decide
theorem cert_e1209571684186 : checkPay e1209571684186 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] = true := by decide
def e1209571684202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1209571684202 : Closed e1209571684202 ∧ code e1209571684202 = 5607618195306 := by decide
theorem cert_e1209571684202 : checkPay e1209571684202 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right,.left],[.left,.right],[.left,.right,.under,.left]] = true := by decide
def e1209571684846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1209571684846 : Closed e1209571684846 ∧ code e1209571684846 = 5607618195950 := by decide
theorem cert_e1209571684846 : checkPay e1209571684846 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e1209571685230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1209571685230 : Closed e1209571685230 ∧ code e1209571685230 = 5607618196334 := by decide
theorem cert_e1209571685230 : checkPay e1209571685230 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left]] = true := by decide
def e1209571685238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1209571685238 : Closed e1209571685238 ∧ code e1209571685238 = 5607618196342 := by decide
theorem cert_e1209571685238 : checkPay e1209571685238 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] = true := by decide
def e1209571685294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1209571685294 : Closed e1209571685294 ∧ code e1209571685294 = 5607618196398 := by decide
theorem cert_e1209571685294 : checkPay e1209571685294 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571685306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1209571685306 : Closed e1209571685306 ∧ code e1209571685306 = 5607618196410 := by decide
theorem cert_e1209571685306 : checkPay e1209571685306 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.right]] = true := by decide
def e1209571685334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1209571685334 : Closed e1209571685334 ∧ code e1209571685334 = 5607618196438 := by decide
theorem cert_e1209571685334 : checkPay e1209571685334 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1209571685338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1209571685338 : Closed e1209571685338 ∧ code e1209571685338 = 5607618196442 := by decide
theorem cert_e1209571685338 : checkPay e1209571685338 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.right],[.left,.left,.right,.under]] = true := by decide
def e1209571685614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571685614 : Closed e1209571685614 ∧ code e1209571685614 = 5607618196718 := by decide
theorem cert_e1209571685614 : checkPay e1209571685614 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1209571685622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571685622 : Closed e1209571685622 ∧ code e1209571685622 = 5607618196726 := by decide
theorem cert_e1209571685622 : checkPay e1209571685622 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1209571685998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571685998 : Closed e1209571685998 ∧ code e1209571685998 = 5607618197102 := by decide
theorem cert_e1209571685998 : checkPay e1209571685998 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571686010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571686010 : Closed e1209571686010 ∧ code e1209571686010 = 5607618197114 := by decide
theorem cert_e1209571686010 : checkPay e1209571686010 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571686174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1209571686174 : Closed e1209571686174 ∧ code e1209571686174 = 5607618197278 := by decide
theorem cert_e1209571686174 : checkPay e1209571686174 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e1209571686198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571686198 : Closed e1209571686198 ∧ code e1209571686198 = 5607618197302 := by decide
theorem cert_e1209571686198 : checkPay e1209571686198 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e1209571686202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571686202 : Closed e1209571686202 ∧ code e1209571686202 = 5607618197306 := by decide
theorem cert_e1209571686202 : checkPay e1209571686202 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left],[.under,.right]] = true := by decide
def e1209571686830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1209571686830 : Closed e1209571686830 ∧ code e1209571686830 = 5607618197934 := by decide
theorem cert_e1209571686830 : checkPay e1209571686830 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left],[.right,.left,.left],[.right,.left],[.right]] = true := by decide
def e1209571686842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1209571686842 : Closed e1209571686842 ∧ code e1209571686842 = 5607618197946 := by decide
theorem cert_e1209571686842 : checkPay e1209571686842 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left,.left],[.right,.left],[.right],[.right,.left],[.right],[.right],[.right,.under],[.right,.under,.left],[.right,.under],[.right,.under,.under,.left],[.right,.under,.under,.left,.left,.left]] = true := by decide
def e1209571686890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1209571686890 : Closed e1209571686890 ∧ code e1209571686890 = 5607618197994 := by decide
theorem cert_e1209571686890 : checkPay e1209571686890 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left,.left,.left],[.right,.under,.left,.left,.left,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left]] = true := by decide
def e1209571687022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571687022 : Closed e1209571687022 ∧ code e1209571687022 = 5607618198126 := by decide
theorem cert_e1209571687022 : checkPay e1209571687022 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571687034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571687034 : Closed e1209571687034 ∧ code e1209571687034 = 5607618198138 := by decide
theorem cert_e1209571687034 : checkPay e1209571687034 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571687322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1209571687322 : Closed e1209571687322 ∧ code e1209571687322 = 5607618198426 := by decide
theorem cert_e1209571687322 : checkPay e1209571687322 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e1209571687534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1209571687534 : Closed e1209571687534 ∧ code e1209571687534 = 5607618198638 := by decide
theorem cert_e1209571687534 : checkPay e1209571687534 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] = true := by decide
def e1209571687546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1209571687546 : Closed e1209571687546 ∧ code e1209571687546 = 5607618198650 := by decide
theorem cert_e1209571687546 : checkPay e1209571687546 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.under,.left,.right]] = true := by decide
def e1209571687638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1209571687638 : Closed e1209571687638 ∧ code e1209571687638 = 5607618198742 := by decide
theorem cert_e1209571687638 : checkPay e1209571687638 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1209571687642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1209571687642 : Closed e1209571687642 ∧ code e1209571687642 = 5607618198746 := by decide
theorem cert_e1209571687642 : checkPay e1209571687642 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.right],[.under,.left,.right,.under,.under,.left,.right,.left,.right]] = true := by decide
def e1209571687658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1209571687658 : Closed e1209571687658 ∧ code e1209571687658 = 5607618198762 := by decide
theorem cert_e1209571687658 : checkPay e1209571687658 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e1209571687710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1209571687710 : Closed e1209571687710 ∧ code e1209571687710 = 5607618198814 := by decide
theorem cert_e1209571687710 : checkPay e1209571687710 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e1209571687734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571687734 : Closed e1209571687734 ∧ code e1209571687734 = 5607618198838 := by decide
theorem cert_e1209571687734 : checkPay e1209571687734 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e1209571687738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571687738 : Closed e1209571687738 ∧ code e1209571687738 = 5607618198842 := by decide
theorem cert_e1209571687738 : checkPay e1209571687738 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.right]] = true := by decide
def e1209571687834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1209571687834 : Closed e1209571687834 ∧ code e1209571687834 = 5607618198938 := by decide
theorem cert_e1209571687834 : checkPay e1209571687834 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e1209571687878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1209571687878 : Closed e1209571687878 ∧ code e1209571687878 = 5607618198982 := by decide
theorem cert_e1209571687878 : checkPay e1209571687878 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1209571689438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1209571689438 : Closed e1209571689438 ∧ code e1209571689438 = 5607618200542 := by decide
theorem cert_e1209571689438 : checkPay e1209571689438 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571689454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1209571689454 : Closed e1209571689454 ∧ code e1209571689454 = 5607618200558 := by decide
theorem cert_e1209571689454 : checkPay e1209571689454 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209571691374 : Closed e1209571691374 ∧ code e1209571691374 = 5607618202478 := by decide
theorem cert_e1209571691374 : checkPay e1209571691374 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209571691382 : Closed e1209571691382 ∧ code e1209571691382 = 5607618202486 := by decide
theorem cert_e1209571691382 : checkPay e1209571691382 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209571691438 : Closed e1209571691438 ∧ code e1209571691438 = 5607618202542 := by decide
theorem cert_e1209571691438 : checkPay e1209571691438 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209571691450 : Closed e1209571691450 ∧ code e1209571691450 = 5607618202554 := by decide
theorem cert_e1209571691450 : checkPay e1209571691450 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209571691478 : Closed e1209571691478 ∧ code e1209571691478 = 5607618202582 := by decide
theorem cert_e1209571691478 : checkPay e1209571691478 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209571691482 : Closed e1209571691482 ∧ code e1209571691482 = 5607618202586 := by decide
theorem cert_e1209571691482 : checkPay e1209571691482 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209571691758 : Closed e1209571691758 ∧ code e1209571691758 = 5607618202862 := by decide
theorem cert_e1209571691758 : checkPay e1209571691758 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571691766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209571691766 : Closed e1209571691766 ∧ code e1209571691766 = 5607618202870 := by decide
theorem cert_e1209571691766 : checkPay e1209571691766 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571692142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209571692142 : Closed e1209571692142 ∧ code e1209571692142 = 5607618203246 := by decide
theorem cert_e1209571692142 : checkPay e1209571692142 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571692154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209571692154 : Closed e1209571692154 ∧ code e1209571692154 = 5607618203258 := by decide
theorem cert_e1209571692154 : checkPay e1209571692154 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571692318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1209571692318 : Closed e1209571692318 ∧ code e1209571692318 = 5607618203422 := by decide
theorem cert_e1209571692318 : checkPay e1209571692318 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571692342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571692342 : Closed e1209571692342 ∧ code e1209571692342 = 5607618203446 := by decide
theorem cert_e1209571692342 : checkPay e1209571692342 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571692346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571692346 : Closed e1209571692346 ∧ code e1209571692346 = 5607618203450 := by decide
theorem cert_e1209571692346 : checkPay e1209571692346 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571697118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1209571697118 : Closed e1209571697118 ∧ code e1209571697118 = 5607618208222 := by decide
theorem cert_e1209571697118 : checkPay e1209571697118 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571697142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1209571697142 : Closed e1209571697142 ∧ code e1209571697142 = 5607618208246 := by decide
theorem cert_e1209571697142 : checkPay e1209571697142 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571698094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1209571698094 : Closed e1209571698094 ∧ code e1209571698094 = 5607618209198 := by decide
theorem cert_e1209571698094 : checkPay e1209571698094 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571698106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1209571698106 : Closed e1209571698106 ∧ code e1209571698106 = 5607618209210 := by decide
theorem cert_e1209571698106 : checkPay e1209571698106 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571698154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1209571698154 : Closed e1209571698154 ∧ code e1209571698154 = 5607618209258 := by decide
theorem cert_e1209571698154 : checkPay e1209571698154 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571698286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1209571698286 : Closed e1209571698286 ∧ code e1209571698286 = 5607618209390 := by decide
theorem cert_e1209571698286 : checkPay e1209571698286 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571698298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1209571698298 : Closed e1209571698298 ∧ code e1209571698298 = 5607618209402 := by decide
theorem cert_e1209571698298 : checkPay e1209571698298 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571698586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1209571698586 : Closed e1209571698586 ∧ code e1209571698586 = 5607618209690 := by decide
theorem cert_e1209571698586 : checkPay e1209571698586 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571700974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1209571700974 : Closed e1209571700974 ∧ code e1209571700974 = 5607618212078 := by decide
theorem cert_e1209571700974 : checkPay e1209571700974 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571700982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1209571700982 : Closed e1209571700982 ∧ code e1209571700982 = 5607618212086 := by decide
theorem cert_e1209571700982 : checkPay e1209571700982 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1209571701462 : Closed e1209571701462 ∧ code e1209571701462 = 5607618212566 := by decide
theorem cert_e1209571701462 : checkPay e1209571701462 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1209571701466 : Closed e1209571701466 ∧ code e1209571701466 = 5607618212570 := by decide
theorem cert_e1209571701466 : checkPay e1209571701466 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1209571701482 : Closed e1209571701482 ∧ code e1209571701482 = 5607618212586 := by decide
theorem cert_e1209571701482 : checkPay e1209571701482 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1209571701534 : Closed e1209571701534 ∧ code e1209571701534 = 5607618212638 := by decide
theorem cert_e1209571701534 : checkPay e1209571701534 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571701558 : Closed e1209571701558 ∧ code e1209571701558 = 5607618212662 := by decide
theorem cert_e1209571701558 : checkPay e1209571701558 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571701562 : Closed e1209571701562 ∧ code e1209571701562 = 5607618212666 := by decide
theorem cert_e1209571701562 : checkPay e1209571701562 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1209571701658 : Closed e1209571701658 ∧ code e1209571701658 = 5607618212762 := by decide
theorem cert_e1209571701658 : checkPay e1209571701658 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571701702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1209571701702 : Closed e1209571701702 ∧ code e1209571701702 = 5607618212806 := by decide
theorem cert_e1209571701702 : checkPay e1209571701702 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right],[.under,.under,.right,.under,.under,.right]] = true := by decide
def e1209571706742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1209571706742 : Closed e1209571706742 ∧ code e1209571706742 = 5607618217846 := by decide
theorem cert_e1209571706742 : check e1209571706742 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571706806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1209571706806 : Closed e1209571706806 ∧ code e1209571706806 = 5607618217910 := by decide
theorem cert_e1209571706806 : check e1209571706806 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571706810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1209571706810 : Closed e1209571706810 ∧ code e1209571706810 = 5607618217914 := by decide
theorem cert_e1209571706810 : check e1209571706810 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571708142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571708142 : Closed e1209571708142 ∧ code e1209571708142 = 5607618219246 := by decide
theorem cert_e1209571708142 : check e1209571708142 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571708150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571708150 : Closed e1209571708150 ∧ code e1209571708150 = 5607618219254 := by decide
theorem cert_e1209571708150 : check e1209571708150 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571708526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571708526 : Closed e1209571708526 ∧ code e1209571708526 = 5607618219630 := by decide
theorem cert_e1209571708526 : check e1209571708526 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571708538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571708538 : Closed e1209571708538 ∧ code e1209571708538 = 5607618219642 := by decide
theorem cert_e1209571708538 : check e1209571708538 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571708726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571708726 : Closed e1209571708726 ∧ code e1209571708726 = 5607618219830 := by decide
theorem cert_e1209571708726 : check e1209571708726 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571708730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571708730 : Closed e1209571708730 ∧ code e1209571708730 = 5607618219834 := by decide
theorem cert_e1209571708730 : check e1209571708730 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571710646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1209571710646 : Closed e1209571710646 ∧ code e1209571710646 = 5607618221750 := by decide
theorem cert_e1209571710646 : check e1209571710646 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571710678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1209571710678 : Closed e1209571710678 ∧ code e1209571710678 = 5607618221782 := by decide
theorem cert_e1209571710678 : check e1209571710678 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571710682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1209571710682 : Closed e1209571710682 ∧ code e1209571710682 = 5607618221786 := by decide
theorem cert_e1209571710682 : check e1209571710682 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571710806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1209571710806 : Closed e1209571710806 ∧ code e1209571710806 = 5607618221910 := by decide
theorem cert_e1209571710806 : check e1209571710806 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571710810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1209571710810 : Closed e1209571710810 ∧ code e1209571710810 = 5607618221914 := by decide
theorem cert_e1209571710810 : check e1209571710810 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571710826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1209571710826 : Closed e1209571710826 ∧ code e1209571710826 = 5607618221930 := by decide
theorem cert_e1209571710826 : check e1209571710826 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1209571711214 : Closed e1209571711214 ∧ code e1209571711214 = 5607618222318 := by decide
theorem cert_e1209571711214 : check e1209571711214 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571711222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1209571711222 : Closed e1209571711222 ∧ code e1209571711222 = 5607618222326 := by decide
theorem cert_e1209571711222 : check e1209571711222 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571711414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1209571711414 : Closed e1209571711414 ∧ code e1209571711414 = 5607618222518 := by decide
theorem cert_e1209571711414 : check e1209571711414 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1209571711446 : Closed e1209571711446 ∧ code e1209571711446 = 5607618222550 := by decide
theorem cert_e1209571711446 : check e1209571711446 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1209571711450 : Closed e1209571711450 ∧ code e1209571711450 = 5607618222554 := by decide
theorem cert_e1209571711450 : check e1209571711450 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1209571711606 : Closed e1209571711606 ∧ code e1209571711606 = 5607618222710 := by decide
theorem cert_e1209571711606 : check e1209571711606 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1209571711774 : Closed e1209571711774 ∧ code e1209571711774 = 5607618222878 := by decide
theorem cert_e1209571711774 : check e1209571711774 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571711798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571711798 : Closed e1209571711798 ∧ code e1209571711798 = 5607618222902 := by decide
theorem cert_e1209571711798 : check e1209571711798 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571711802 : Closed e1209571711802 ∧ code e1209571711802 = 5607618222906 := by decide
theorem cert_e1209571711802 : check e1209571711802 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571711886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1209571711886 : Closed e1209571711886 ∧ code e1209571711886 = 5607618222990 := by decide
theorem cert_e1209571711886 : check e1209571711886 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1209571712110 : Closed e1209571712110 ∧ code e1209571712110 = 5607618223214 := by decide
theorem cert_e1209571712110 : check e1209571712110 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1209571712122 : Closed e1209571712122 ∧ code e1209571712122 = 5607618223226 := by decide
theorem cert_e1209571712122 : check e1209571712122 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1209571712214 : Closed e1209571712214 ∧ code e1209571712214 = 5607618223318 := by decide
theorem cert_e1209571712214 : check e1209571712214 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571712218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1209571712218 : Closed e1209571712218 ∧ code e1209571712218 = 5607618223322 := by decide
theorem cert_e1209571712218 : check e1209571712218 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571712234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1209571712234 : Closed e1209571712234 ∧ code e1209571712234 = 5607618223338 := by decide
theorem cert_e1209571712234 : check e1209571712234 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571712286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1209571712286 : Closed e1209571712286 ∧ code e1209571712286 = 5607618223390 := by decide
theorem cert_e1209571712286 : check e1209571712286 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571712310 : Closed e1209571712310 ∧ code e1209571712310 = 5607618223414 := by decide
theorem cert_e1209571712310 : check e1209571712310 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571712314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571712314 : Closed e1209571712314 ∧ code e1209571712314 = 5607618223418 := by decide
theorem cert_e1209571712314 : check e1209571712314 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571712410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1209571712410 : Closed e1209571712410 ∧ code e1209571712410 = 5607618223514 := by decide
theorem cert_e1209571712410 : check e1209571712410 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571712454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1209571712454 : Closed e1209571712454 ∧ code e1209571712454 = 5607618223558 := by decide
theorem cert_e1209571712454 : check e1209571712454 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1209571712566 : Closed e1209571712566 ∧ code e1209571712566 = 5607618223670 := by decide
theorem cert_e1209571712566 : check e1209571712566 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1209571712570 : Closed e1209571712570 ∧ code e1209571712570 = 5607618223674 := by decide
theorem cert_e1209571712570 : check e1209571712570 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1209571712654 : Closed e1209571712654 ∧ code e1209571712654 = 5607618223758 := by decide
theorem cert_e1209571712654 : check e1209571712654 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571712710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1209571712710 : Closed e1209571712710 ∧ code e1209571712710 = 5607618223814 := by decide
theorem cert_e1209571712710 : check e1209571712710 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571713518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1209571713518 : Closed e1209571713518 ∧ code e1209571713518 = 5607618224622 := by decide
theorem cert_e1209571713518 : check e1209571713518 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1209571714486 : Closed e1209571714486 ∧ code e1209571714486 = 5607618225590 := by decide
theorem cert_e1209571714486 : check e1209571714486 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1209571714518 : Closed e1209571714518 ∧ code e1209571714518 = 5607618225622 := by decide
theorem cert_e1209571714518 : check e1209571714518 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1209571714522 : Closed e1209571714522 ∧ code e1209571714522 = 5607618225626 := by decide
theorem cert_e1209571714522 : check e1209571714522 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1209571714678 : Closed e1209571714678 ∧ code e1209571714678 = 5607618225782 := by decide
theorem cert_e1209571714678 : check e1209571714678 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1209571714846 : Closed e1209571714846 ∧ code e1209571714846 = 5607618225950 := by decide
theorem cert_e1209571714846 : check e1209571714846 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571714870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571714870 : Closed e1209571714870 ∧ code e1209571714870 = 5607618225974 := by decide
theorem cert_e1209571714870 : check e1209571714870 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571714874 : Closed e1209571714874 ∧ code e1209571714874 = 5607618225978 := by decide
theorem cert_e1209571714874 : check e1209571714874 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571714958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1209571714958 : Closed e1209571714958 ∧ code e1209571714958 = 5607618226062 := by decide
theorem cert_e1209571714958 : check e1209571714958 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571717358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1209571717358 : Closed e1209571717358 ∧ code e1209571717358 = 5607618228462 := by decide
theorem cert_e1209571717358 : check e1209571717358 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571717366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1209571717366 : Closed e1209571717366 ∧ code e1209571717366 = 5607618228470 := by decide
theorem cert_e1209571717366 : check e1209571717366 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571717846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1209571717846 : Closed e1209571717846 ∧ code e1209571717846 = 5607618228950 := by decide
theorem cert_e1209571717846 : check e1209571717846 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571717850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1209571717850 : Closed e1209571717850 ∧ code e1209571717850 = 5607618228954 := by decide
theorem cert_e1209571717850 : check e1209571717850 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571717866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1209571717866 : Closed e1209571717866 ∧ code e1209571717866 = 5607618228970 := by decide
theorem cert_e1209571717866 : check e1209571717866 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571717918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1209571717918 : Closed e1209571717918 ∧ code e1209571717918 = 5607618229022 := by decide
theorem cert_e1209571717918 : check e1209571717918 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571717942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571717942 : Closed e1209571717942 ∧ code e1209571717942 = 5607618229046 := by decide
theorem cert_e1209571717942 : check e1209571717942 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571717946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571717946 : Closed e1209571717946 ∧ code e1209571717946 = 5607618229050 := by decide
theorem cert_e1209571717946 : check e1209571717946 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571718042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1209571718042 : Closed e1209571718042 ∧ code e1209571718042 = 5607618229146 := by decide
theorem cert_e1209571718042 : check e1209571718042 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1209571718086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1209571718086 : Closed e1209571718086 ∧ code e1209571718086 = 5607618229190 := by decide
theorem cert_e1209571718086 : check e1209571718086 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571719566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1209571719566 : Closed e1209571719566 ∧ code e1209571719566 = 5607618230670 := by decide
private def t_e1209571719566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e1209571719566 : ¬ IsSelfInterpreter e1209571719566 :=
  wSource (t := t_e1209571719566) (replay_sound (ps := []) (t := e1209571719566) (by decide)) (by decide)
def e1209571719622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1209571719622 : Closed e1209571719622 ∧ code e1209571719622 = 5607618230726 := by decide
private def t_e1209571719622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e1209571719622 : ¬ IsSelfInterpreter e1209571719622 :=
  wSource (t := t_e1209571719622) (replay_sound (ps := []) (t := e1209571719622) (by decide)) (by decide)
def e1209571760366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1209571760366 : Closed e1209571760366 ∧ code e1209571760366 = 5607618271470 := by decide
theorem cert_e1209571760366 : check e1209571760366 [[],[]] .smaller = true := by decide
def e1209571760374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1209571760374 : Closed e1209571760374 ∧ code e1209571760374 = 5607618271478 := by decide
theorem cert_e1209571760374 : check e1209571760374 [[],[]] .smaller = true := by decide
def e1209571760926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1209571760926 : Closed e1209571760926 ∧ code e1209571760926 = 5607618272030 := by decide
theorem cert_e1209571760926 : check e1209571760926 [[],[]] .smaller = true := by decide
def e1209571761038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1209571761038 : Closed e1209571761038 ∧ code e1209571761038 = 5607618272142 := by decide
theorem cert_e1209571761038 : check e1209571761038 [[],[]] .smaller = true := by decide
def e1209571761262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1209571761262 : Closed e1209571761262 ∧ code e1209571761262 = 5607618272366 := by decide
theorem cert_e1209571761262 : check e1209571761262 [[],[]] .smaller = true := by decide
def e1209571761274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1209571761274 : Closed e1209571761274 ∧ code e1209571761274 = 5607618272378 := by decide
theorem cert_e1209571761274 : check e1209571761274 [[],[]] .smaller = true := by decide
def e1209571761438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1209571761438 : Closed e1209571761438 ∧ code e1209571761438 = 5607618272542 := by decide
theorem cert_e1209571761438 : check e1209571761438 [[],[]] .smaller = true := by decide
def e1209571761606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1209571761606 : Closed e1209571761606 ∧ code e1209571761606 = 5607618272710 := by decide
theorem cert_e1209571761606 : check e1209571761606 [[],[]] .smaller = true := by decide
def e1209571761630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1209571761630 : Closed e1209571761630 ∧ code e1209571761630 = 5607618272734 := by decide
theorem cert_e1209571761630 : check e1209571761630 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1209571761646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1209571761646 : Closed e1209571761646 ∧ code e1209571761646 = 5607618272750 := by decide
theorem cert_e1209571761646 : check e1209571761646 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571761718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1209571761718 : Closed e1209571761718 ∧ code e1209571761718 = 5607618272822 := by decide
theorem cert_e1209571761718 : check e1209571761718 [[],[]] .smaller = true := by decide
def e1209571761722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1209571761722 : Closed e1209571761722 ∧ code e1209571761722 = 5607618272826 := by decide
theorem cert_e1209571761722 : check e1209571761722 [[],[]] .smaller = true := by decide
def e1209571761806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1209571761806 : Closed e1209571761806 ∧ code e1209571761806 = 5607618272910 := by decide
theorem cert_e1209571761806 : check e1209571761806 [[],[]] .smaller = true := by decide
def e1209571761862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1209571761862 : Closed e1209571761862 ∧ code e1209571761862 = 5607618272966 := by decide
theorem cert_e1209571761862 : check e1209571761862 [[],[]] .smaller = true := by decide
def e1209571761886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1209571761886 : Closed e1209571761886 ∧ code e1209571761886 = 5607618272990 := by decide
theorem cert_e1209571761886 : check e1209571761886 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1209571761910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1209571761910 : Closed e1209571761910 ∧ code e1209571761910 = 5607618273014 := by decide
theorem cert_e1209571761910 : check e1209571761910 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1209571762030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1209571762030 : Closed e1209571762030 ∧ code e1209571762030 = 5607618273134 := by decide
theorem cert_e1209571762030 : checkPay e1209571762030 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left]] 0 [[.under,.left],[.under]] = true := by decide
def e1209571762038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1209571762038 : Closed e1209571762038 ∧ code e1209571762038 = 5607618273142 := by decide
theorem cert_e1209571762038 : check e1209571762038 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1209571763998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1209571763998 : Closed e1209571763998 ∧ code e1209571763998 = 5607618275102 := by decide
theorem cert_e1209571763998 : check e1209571763998 [[],[]] .smaller = true := by decide
def e1209571764110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1209571764110 : Closed e1209571764110 ∧ code e1209571764110 = 5607618275214 := by decide
theorem cert_e1209571764110 : check e1209571764110 [[],[]] .smaller = true := by decide
def e1209571767070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1209571767070 : Closed e1209571767070 ∧ code e1209571767070 = 5607618278174 := by decide
theorem cert_e1209571767070 : check e1209571767070 [[],[]] .smaller = true := by decide
def e1209571767238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1209571767238 : Closed e1209571767238 ∧ code e1209571767238 = 5607618278342 := by decide
theorem cert_e1209571767238 : check e1209571767238 [[],[]] .smaller = true := by decide
def e1209571767262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1209571767262 : Closed e1209571767262 ∧ code e1209571767262 = 5607618278366 := by decide
theorem cert_e1209571767262 : check e1209571767262 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left]] .identityHead = true := by decide
def e1209571767278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1209571767278 : Closed e1209571767278 ∧ code e1209571767278 = 5607618278382 := by decide
theorem cert_e1209571767278 : check e1209571767278 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under]] .identityHead = true := by decide
end Blc.Floor42
