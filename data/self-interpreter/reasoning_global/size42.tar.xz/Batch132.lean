import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209577704302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209577704302 : Closed e1209577704302 ∧ code e1209577704302 = 5607624215406 := by decide
theorem cert_e1209577704302 : check e1209577704302 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209577704310 : Closed e1209577704310 ∧ code e1209577704310 = 5607624215414 := by decide
theorem cert_e1209577704310 : check e1209577704310 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209577704366 : Closed e1209577704366 ∧ code e1209577704366 = 5607624215470 := by decide
theorem cert_e1209577704366 : check e1209577704366 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209577704378 : Closed e1209577704378 ∧ code e1209577704378 = 5607624215482 := by decide
theorem cert_e1209577704378 : check e1209577704378 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209577704406 : Closed e1209577704406 ∧ code e1209577704406 = 5607624215510 := by decide
theorem cert_e1209577704406 : check e1209577704406 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209577704410 : Closed e1209577704410 ∧ code e1209577704410 = 5607624215514 := by decide
theorem cert_e1209577704410 : check e1209577704410 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209577704686 : Closed e1209577704686 ∧ code e1209577704686 = 5607624215790 := by decide
theorem cert_e1209577704686 : check e1209577704686 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577704694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209577704694 : Closed e1209577704694 ∧ code e1209577704694 = 5607624215798 := by decide
theorem cert_e1209577704694 : check e1209577704694 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577705070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209577705070 : Closed e1209577705070 ∧ code e1209577705070 = 5607624216174 := by decide
theorem cert_e1209577705070 : check e1209577705070 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577705082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209577705082 : Closed e1209577705082 ∧ code e1209577705082 = 5607624216186 := by decide
theorem cert_e1209577705082 : check e1209577705082 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577705270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209577705270 : Closed e1209577705270 ∧ code e1209577705270 = 5607624216374 := by decide
theorem cert_e1209577705270 : check e1209577705270 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209577705274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209577705274 : Closed e1209577705274 ∧ code e1209577705274 = 5607624216378 := by decide
theorem cert_e1209577705274 : check e1209577705274 [[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e1209595354590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1209595354590 : Closed e1209595354590 ∧ code e1209595354590 = 5607641865694 := by decide
theorem cert_e1209595354590 : check e1209595354590 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209595354606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1209595354606 : Closed e1209595354606 ∧ code e1209595354606 = 5607641865710 := by decide
theorem cert_e1209595354606 : check e1209595354606 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209595354846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1209595354846 : Closed e1209595354846 ∧ code e1209595354846 = 5607641865950 := by decide
theorem cert_e1209595354846 : check e1209595354846 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209595354870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1209595354870 : Closed e1209595354870 ∧ code e1209595354870 = 5607641865974 := by decide
private def t_e1209595354870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem cert_e1209595354870 : ¬ IsSelfInterpreter e1209595354870 :=
  wSource (t := t_e1209595354870) (replay_sound (ps := []) (t := e1209595354870) (by decide)) (by decide)
def e1209595354990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1209595354990 : Closed e1209595354990 ∧ code e1209595354990 = 5607641866094 := by decide
theorem cert_e1209595354990 : check e1209595354990 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209595354998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1209595354998 : Closed e1209595354998 ∧ code e1209595354998 = 5607641866102 := by decide
private def t_e1209595354998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem cert_e1209595354998 : ¬ IsSelfInterpreter e1209595354998 :=
  wSource (t := t_e1209595354998) (replay_sound (ps := []) (t := e1209595354998) (by decide)) (by decide)
def e1209595360222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1209595360222 : Closed e1209595360222 ∧ code e1209595360222 = 5607641871326 := by decide
theorem cert_e1209595360222 : check e1209595360222 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e1209595360238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1209595360238 : Closed e1209595360238 ∧ code e1209595360238 = 5607641871342 := by decide
theorem cert_e1209595360238 : check e1209595360238 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e1209595361758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209595361758 : Closed e1209595361758 ∧ code e1209595361758 = 5607641872862 := by decide
theorem cert_e1209595361758 : check e1209595361758 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e1209595361782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209595361782 : Closed e1209595361782 ∧ code e1209595361782 = 5607641872886 := by decide
theorem cert_e1209595361782 : check e1209595361782 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e1209595362542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209595362542 : Closed e1209595362542 ∧ code e1209595362542 = 5607641873646 := by decide
theorem cert_e1209595362542 : check e1209595362542 [[],[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209595362550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209595362550 : Closed e1209595362550 ∧ code e1209595362550 = 5607641873654 := by decide
theorem cert_e1209595362550 : check e1209595362550 [[],[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1209595419502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1209595419502 : Closed e1209595419502 ∧ code e1209595419502 = 5607641930606 := by decide
def e1209595419510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1209595419510 : Closed e1209595419510 ∧ code e1209595419510 = 5607641930614 := by decide
def e1209595419574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1209595419574 : Closed e1209595419574 ∧ code e1209595419574 = 5607641930678 := by decide
def e1209595420014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209595420014 : Closed e1209595420014 ∧ code e1209595420014 = 5607641931118 := by decide
def e1209595420022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209595420022 : Closed e1209595420022 ∧ code e1209595420022 = 5607641931126 := by decide
def e1209595420078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209595420078 : Closed e1209595420078 ∧ code e1209595420078 = 5607641931182 := by decide
private def t_e1209595420078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e1209595420078 : ¬ IsSelfInterpreter e1209595420078 :=
  wSource (t := t_e1209595420078) (replay_sound (ps := []) (t := e1209595420078) (by decide)) (by decide)
def e1209595420090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209595420090 : Closed e1209595420090 ∧ code e1209595420090 = 5607641931194 := by decide
private def t_e1209595420090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e1209595420090 : ¬ IsSelfInterpreter e1209595420090 :=
  wSource (t := t_e1209595420090) (replay_sound (ps := []) (t := e1209595420090) (by decide)) (by decide)
def e1209595420118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209595420118 : Closed e1209595420118 ∧ code e1209595420118 = 5607641931222 := by decide
private def t_e1209595420118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1209595420118 : ¬ IsSelfInterpreter e1209595420118 :=
  wSource (t := t_e1209595420118) (replay_sound (ps := []) (t := e1209595420118) (by decide)) (by decide)
def e1209595420122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209595420122 : Closed e1209595420122 ∧ code e1209595420122 = 5607641931226 := by decide
private def t_e1209595420122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1209595420122 : ¬ IsSelfInterpreter e1209595420122 :=
  wSource (t := t_e1209595420122) (replay_sound (ps := []) (t := e1209595420122) (by decide)) (by decide)
def e1209595420342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1209595420342 : Closed e1209595420342 ∧ code e1209595420342 = 5607641931446 := by decide
def e1209595420374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1209595420374 : Closed e1209595420374 ∧ code e1209595420374 = 5607641931478 := by decide
private def t_e1209595420374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem cert_e1209595420374 : ¬ IsSelfInterpreter e1209595420374 :=
  wSource (t := t_e1209595420374) (replay_sound (ps := []) (t := e1209595420374) (by decide)) (by decide)
def e1209595420378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1209595420378 : Closed e1209595420378 ∧ code e1209595420378 = 5607641931482 := by decide
private def t_e1209595420378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem cert_e1209595420378 : ¬ IsSelfInterpreter e1209595420378 :=
  wSource (t := t_e1209595420378) (replay_sound (ps := []) (t := e1209595420378) (by decide)) (by decide)
def e1209595422574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1209595422574 : Closed e1209595422574 ∧ code e1209595422574 = 5607641933678 := by decide
def e1209595422582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1209595422582 : Closed e1209595422582 ∧ code e1209595422582 = 5607641933686 := by decide
def e1209595422646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1209595422646 : Closed e1209595422646 ∧ code e1209595422646 = 5607641933750 := by decide
def e1209595423982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209595423982 : Closed e1209595423982 ∧ code e1209595423982 = 5607641935086 := by decide
def e1209595423990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209595423990 : Closed e1209595423990 ∧ code e1209595423990 = 5607641935094 := by decide
def e1209595424374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209595424374 : Closed e1209595424374 ∧ code e1209595424374 = 5607641935478 := by decide
def e1209595425646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209595425646 : Closed e1209595425646 ∧ code e1209595425646 = 5607641936750 := by decide
def e1209595425654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209595425654 : Closed e1209595425654 ∧ code e1209595425654 = 5607641936758 := by decide
def e1209595425710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209595425710 : Closed e1209595425710 ∧ code e1209595425710 = 5607641936814 := by decide
def e1209595425722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209595425722 : Closed e1209595425722 ∧ code e1209595425722 = 5607641936826 := by decide
private def t_e1209595425722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e1209595425722 : ¬ IsSelfInterpreter e1209595425722 :=
  wSource (t := t_e1209595425722) (replay_sound (ps := []) (t := e1209595425722) (by decide)) (by decide)
def e1209595425750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209595425750 : Closed e1209595425750 ∧ code e1209595425750 = 5607641936854 := by decide
def e1209595425754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209595425754 : Closed e1209595425754 ∧ code e1209595425754 = 5607641936858 := by decide
private def t_e1209595425754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e1209595425754 : ¬ IsSelfInterpreter e1209595425754 :=
  wSource (t := t_e1209595425754) (replay_sound (ps := []) (t := e1209595425754) (by decide)) (by decide)
def e1209595426030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209595426030 : Closed e1209595426030 ∧ code e1209595426030 = 5607641937134 := by decide
def e1209595426038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209595426038 : Closed e1209595426038 ∧ code e1209595426038 = 5607641937142 := by decide
def e1209595426414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209595426414 : Closed e1209595426414 ∧ code e1209595426414 = 5607641937518 := by decide
private def t_e1209595426414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e1209595426414 : ¬ IsSelfInterpreter e1209595426414 :=
  wSource (t := t_e1209595426414) (replay_sound (ps := []) (t := e1209595426414) (by decide)) (by decide)
def e1209595426426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209595426426 : Closed e1209595426426 ∧ code e1209595426426 = 5607641937530 := by decide
private def t_e1209595426426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e1209595426426 : ¬ IsSelfInterpreter e1209595426426 :=
  wSource (t := t_e1209595426426) (replay_sound (ps := []) (t := e1209595426426) (by decide)) (by decide)
def e1209595426614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209595426614 : Closed e1209595426614 ∧ code e1209595426614 = 5607641937718 := by decide
private def t_e1209595426614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1209595426614 : ¬ IsSelfInterpreter e1209595426614 :=
  wSource (t := t_e1209595426614) (replay_sound (ps := []) (t := e1209595426614) (by decide)) (by decide)
def e1209595426618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209595426618 : Closed e1209595426618 ∧ code e1209595426618 = 5607641937722 := by decide
private def t_e1209595426618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1209595426618 : ¬ IsSelfInterpreter e1209595426618 :=
  wSource (t := t_e1209595426618) (replay_sound (ps := []) (t := e1209595426618) (by decide)) (by decide)
def e1209595427254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1209595427254 : Closed e1209595427254 ∧ code e1209595427254 = 5607641938358 := by decide
def e1209595427286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1209595427286 : Closed e1209595427286 ∧ code e1209595427286 = 5607641938390 := by decide
def e1209595427290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1209595427290 : Closed e1209595427290 ∧ code e1209595427290 = 5607641938394 := by decide
private def t_e1209595427290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem cert_e1209595427290 : ¬ IsSelfInterpreter e1209595427290 :=
  wSource (t := t_e1209595427290) (replay_sound (ps := []) (t := e1209595427290) (by decide)) (by decide)
def e1209595427446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209595427446 : Closed e1209595427446 ∧ code e1209595427446 = 5607641938550 := by decide
def e1209595427638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209595427638 : Closed e1209595427638 ∧ code e1209595427638 = 5607641938742 := by decide
private def t_e1209595427638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem cert_e1209595427638 : ¬ IsSelfInterpreter e1209595427638 :=
  wSource (t := t_e1209595427638) (replay_sound (ps := []) (t := e1209595427638) (by decide)) (by decide)
def e1209595427642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209595427642 : Closed e1209595427642 ∧ code e1209595427642 = 5607641938746 := by decide
private def t_e1209595427642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem cert_e1209595427642 : ¬ IsSelfInterpreter e1209595427642 :=
  wSource (t := t_e1209595427642) (replay_sound (ps := []) (t := e1209595427642) (by decide)) (by decide)
def e1209595434862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1209595434862 : Closed e1209595434862 ∧ code e1209595434862 = 5607641945966 := by decide
theorem cert_e1209595434862 : check e1209595434862 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1209595434870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1209595434870 : Closed e1209595434870 ∧ code e1209595434870 = 5607641945974 := by decide
theorem cert_e1209595434870 : check e1209595434870 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1209595434934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1209595434934 : Closed e1209595434934 ∧ code e1209595434934 = 5607641946038 := by decide
theorem cert_e1209595434934 : check e1209595434934 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1209595436270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209595436270 : Closed e1209595436270 ∧ code e1209595436270 = 5607641947374 := by decide
theorem cert_e1209595436270 : check e1209595436270 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1209595436278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209595436278 : Closed e1209595436278 ∧ code e1209595436278 = 5607641947382 := by decide
theorem cert_e1209595436278 : check e1209595436278 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1209595436662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209595436662 : Closed e1209595436662 ∧ code e1209595436662 = 5607641947766 := by decide
theorem cert_e1209595436662 : check e1209595436662 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1209595448174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209595448174 : Closed e1209595448174 ∧ code e1209595448174 = 5607641959278 := by decide
def e1209595448182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209595448182 : Closed e1209595448182 ∧ code e1209595448182 = 5607641959286 := by decide
def e1209595448238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209595448238 : Closed e1209595448238 ∧ code e1209595448238 = 5607641959342 := by decide
def e1209595448250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209595448250 : Closed e1209595448250 ∧ code e1209595448250 = 5607641959354 := by decide
private def t_e1209595448250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1209595448250 : ¬ IsSelfInterpreter e1209595448250 :=
  wSource (t := t_e1209595448250) (replay_sound (ps := []) (t := e1209595448250) (by decide)) (by decide)
def e1209595448278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209595448278 : Closed e1209595448278 ∧ code e1209595448278 = 5607641959382 := by decide
def e1209595448282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209595448282 : Closed e1209595448282 ∧ code e1209595448282 = 5607641959386 := by decide
private def t_e1209595448282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1209595448282 : ¬ IsSelfInterpreter e1209595448282 :=
  wSource (t := t_e1209595448282) (replay_sound (ps := []) (t := e1209595448282) (by decide)) (by decide)
def e1209595448558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209595448558 : Closed e1209595448558 ∧ code e1209595448558 = 5607641959662 := by decide
def e1209595448566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209595448566 : Closed e1209595448566 ∧ code e1209595448566 = 5607641959670 := by decide
def e1209595448942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209595448942 : Closed e1209595448942 ∧ code e1209595448942 = 5607641960046 := by decide
def e1209595448954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209595448954 : Closed e1209595448954 ∧ code e1209595448954 = 5607641960058 := by decide
def e1209595449142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209595449142 : Closed e1209595449142 ∧ code e1209595449142 = 5607641960246 := by decide
def e1209595449146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209595449146 : Closed e1209595449146 ∧ code e1209595449146 = 5607641960250 := by decide
def e1209595454902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1209595454902 : Closed e1209595454902 ∧ code e1209595454902 = 5607641966006 := by decide
def e1209595454934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1209595454934 : Closed e1209595454934 ∧ code e1209595454934 = 5607641966038 := by decide
def e1209595454938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1209595454938 : Closed e1209595454938 ∧ code e1209595454938 = 5607641966042 := by decide
private def t_e1209595454938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem cert_e1209595454938 : ¬ IsSelfInterpreter e1209595454938 :=
  wSource (t := t_e1209595454938) (replay_sound (ps := []) (t := e1209595454938) (by decide)) (by decide)
def e1209595455094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209595455094 : Closed e1209595455094 ∧ code e1209595455094 = 5607641966198 := by decide
def e1209595455286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209595455286 : Closed e1209595455286 ∧ code e1209595455286 = 5607641966390 := by decide
def e1209595455290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209595455290 : Closed e1209595455290 ∧ code e1209595455290 = 5607641966394 := by decide
def e1209595792238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209595792238 : Closed e1209595792238 ∧ code e1209595792238 = 5607642303342 := by decide
private def t_e1209595792238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1209595792238 : ¬ IsSelfInterpreter e1209595792238 :=
  wSource (t := t_e1209595792238) (replay_sound (ps := []) (t := e1209595792238) (by decide)) (by decide)
def e1209595792246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209595792246 : Closed e1209595792246 ∧ code e1209595792246 = 5607642303350 := by decide
private def t_e1209595792246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1209595792246 : ¬ IsSelfInterpreter e1209595792246 :=
  wSource (t := t_e1209595792246) (replay_sound (ps := []) (t := e1209595792246) (by decide)) (by decide)
def e1209595792302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209595792302 : Closed e1209595792302 ∧ code e1209595792302 = 5607642303406 := by decide
private def t_e1209595792302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1209595792302 : ¬ IsSelfInterpreter e1209595792302 :=
  wSource (t := t_e1209595792302) (replay_sound (ps := []) (t := e1209595792302) (by decide)) (by decide)
def e1209595792314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209595792314 : Closed e1209595792314 ∧ code e1209595792314 = 5607642303418 := by decide
private def t_e1209595792314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1209595792314 : ¬ IsSelfInterpreter e1209595792314 :=
  wSource (t := t_e1209595792314) (replay_sound (ps := []) (t := e1209595792314) (by decide)) (by decide)
def e1209595792342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209595792342 : Closed e1209595792342 ∧ code e1209595792342 = 5607642303446 := by decide
private def t_e1209595792342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1209595792342 : ¬ IsSelfInterpreter e1209595792342 :=
  wSource (t := t_e1209595792342) (replay_sound (ps := []) (t := e1209595792342) (by decide)) (by decide)
def e1209595792346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209595792346 : Closed e1209595792346 ∧ code e1209595792346 = 5607642303450 := by decide
private def t_e1209595792346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1209595792346 : ¬ IsSelfInterpreter e1209595792346 :=
  wSource (t := t_e1209595792346) (replay_sound (ps := []) (t := e1209595792346) (by decide)) (by decide)
def e1209595792622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209595792622 : Closed e1209595792622 ∧ code e1209595792622 = 5607642303726 := by decide
private def t_e1209595792622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1209595792622 : ¬ IsSelfInterpreter e1209595792622 :=
  wSource (t := t_e1209595792622) (replay_sound (ps := []) (t := e1209595792622) (by decide)) (by decide)
def e1209595792630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209595792630 : Closed e1209595792630 ∧ code e1209595792630 = 5607642303734 := by decide
private def t_e1209595792630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1209595792630 : ¬ IsSelfInterpreter e1209595792630 :=
  wSource (t := t_e1209595792630) (replay_sound (ps := []) (t := e1209595792630) (by decide)) (by decide)
def e1209595793006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209595793006 : Closed e1209595793006 ∧ code e1209595793006 = 5607642304110 := by decide
private def t_e1209595793006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1209595793006 : ¬ IsSelfInterpreter e1209595793006 :=
  wSource (t := t_e1209595793006) (replay_sound (ps := []) (t := e1209595793006) (by decide)) (by decide)
def e1209595793018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209595793018 : Closed e1209595793018 ∧ code e1209595793018 = 5607642304122 := by decide
private def t_e1209595793018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1209595793018 : ¬ IsSelfInterpreter e1209595793018 :=
  wSource (t := t_e1209595793018) (replay_sound (ps := []) (t := e1209595793018) (by decide)) (by decide)
def e1209595793206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209595793206 : Closed e1209595793206 ∧ code e1209595793206 = 5607642304310 := by decide
private def t_e1209595793206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1209595793206 : ¬ IsSelfInterpreter e1209595793206 :=
  wSource (t := t_e1209595793206) (replay_sound (ps := []) (t := e1209595793206) (by decide)) (by decide)
def e1209595793210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209595793210 : Closed e1209595793210 ∧ code e1209595793210 = 5607642304314 := by decide
private def t_e1209595793210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1209595793210 : ¬ IsSelfInterpreter e1209595793210 :=
  wSource (t := t_e1209595793210) (replay_sound (ps := []) (t := e1209595793210) (by decide)) (by decide)
def e1211180866270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))))
theorem wire_e1211180866270 : Closed e1211180866270 ∧ code e1211180866270 = 5609227377374 := by decide
theorem cert_e1211180866270 : check e1211180866270 [[],[]] .smaller = true := by decide
def e1211180866294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))))
theorem wire_e1211180866294 : Closed e1211180866294 ∧ code e1211180866294 = 5609227377398 := by decide
theorem cert_e1211180866294 : check e1211180866294 [[],[]] .smaller = true := by decide
def e1211180866398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))))
theorem wire_e1211180866398 : Closed e1211180866398 ∧ code e1211180866398 = 5609227377502 := by decide
theorem cert_e1211180866398 : check e1211180866398 [[],[]] .smaller = true := by decide
def e1211180866414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))))
theorem wire_e1211180866414 : Closed e1211180866414 ∧ code e1211180866414 = 5609227377518 := by decide
theorem cert_e1211180866414 : check e1211180866414 [[],[]] .smaller = true := by decide
def e1211180866422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))))
theorem wire_e1211180866422 : Closed e1211180866422 ∧ code e1211180866422 = 5609227377526 := by decide
theorem cert_e1211180866422 : check e1211180866422 [[],[]] .smaller = true := by decide
def e1211180866426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))))
theorem wire_e1211180866426 : Closed e1211180866426 ∧ code e1211180866426 = 5609227377530 := by decide
theorem cert_e1211180866426 : check e1211180866426 [[],[]] .smaller = true := by decide
def e1211180866486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))))
theorem wire_e1211180866486 : Closed e1211180866486 ∧ code e1211180866486 = 5609227377590 := by decide
theorem cert_e1211180866486 : check e1211180866486 [[],[]] .smaller = true := by decide
def e1211180866518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))))
theorem wire_e1211180866518 : Closed e1211180866518 ∧ code e1211180866518 = 5609227377622 := by decide
theorem cert_e1211180866518 : check e1211180866518 [[],[]] .smaller = true := by decide
def e1211180866522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))))
theorem wire_e1211180866522 : Closed e1211180866522 ∧ code e1211180866522 = 5609227377626 := by decide
theorem cert_e1211180866522 : check e1211180866522 [[],[]] .smaller = true := by decide
def e1211180866910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))))
theorem wire_e1211180866910 : Closed e1211180866910 ∧ code e1211180866910 = 5609227378014 := by decide
theorem cert_e1211180866910 : check e1211180866910 [[],[]] .smaller = true := by decide
def e1211180866926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e1211180866926 : Closed e1211180866926 ∧ code e1211180866926 = 5609227378030 := by decide
theorem cert_e1211180866926 : check e1211180866926 [[],[]] .smaller = true := by decide
def e1211180866934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e1211180866934 : Closed e1211180866934 ∧ code e1211180866934 = 5609227378038 := by decide
theorem cert_e1211180866934 : check e1211180866934 [[],[]] .smaller = true := by decide
def e1211180866938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))))
theorem wire_e1211180866938 : Closed e1211180866938 ∧ code e1211180866938 = 5609227378042 := by decide
theorem cert_e1211180866938 : check e1211180866938 [[],[]] .smaller = true := by decide
def e1211180866990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e1211180866990 : Closed e1211180866990 ∧ code e1211180866990 = 5609227378094 := by decide
theorem cert_e1211180866990 : check e1211180866990 [[],[]] .smaller = true := by decide
def e1211180867002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e1211180867002 : Closed e1211180867002 ∧ code e1211180867002 = 5609227378106 := by decide
theorem cert_e1211180867002 : check e1211180867002 [[],[]] .smaller = true := by decide
def e1211180867030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e1211180867030 : Closed e1211180867030 ∧ code e1211180867030 = 5609227378134 := by decide
theorem cert_e1211180867030 : check e1211180867030 [[],[]] .smaller = true := by decide
def e1211180867034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e1211180867034 : Closed e1211180867034 ∧ code e1211180867034 = 5609227378138 := by decide
theorem cert_e1211180867034 : check e1211180867034 [[],[]] .smaller = true := by decide
def e1211180867050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))))
theorem wire_e1211180867050 : Closed e1211180867050 ∧ code e1211180867050 = 5609227378154 := by decide
theorem cert_e1211180867050 : check e1211180867050 [[],[]] .smaller = true := by decide
def e1211180867254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))))
theorem wire_e1211180867254 : Closed e1211180867254 ∧ code e1211180867254 = 5609227378358 := by decide
theorem cert_e1211180867254 : check e1211180867254 [[],[]] .smaller = true := by decide
def e1211180867286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))))
theorem wire_e1211180867286 : Closed e1211180867286 ∧ code e1211180867286 = 5609227378390 := by decide
theorem cert_e1211180867286 : check e1211180867286 [[],[]] .smaller = true := by decide
def e1211180867290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))))
theorem wire_e1211180867290 : Closed e1211180867290 ∧ code e1211180867290 = 5609227378394 := by decide
theorem cert_e1211180867290 : check e1211180867290 [[],[]] .smaller = true := by decide
def e1211180867414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e1211180867414 : Closed e1211180867414 ∧ code e1211180867414 = 5609227378518 := by decide
theorem cert_e1211180867414 : check e1211180867414 [[],[]] .smaller = true := by decide
def e1211180867418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e1211180867418 : Closed e1211180867418 ∧ code e1211180867418 = 5609227378522 := by decide
theorem cert_e1211180867418 : check e1211180867418 [[],[]] .smaller = true := by decide
def e1211180867434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e1211180867434 : Closed e1211180867434 ∧ code e1211180867434 = 5609227378538 := by decide
theorem cert_e1211180867434 : check e1211180867434 [[],[]] .smaller = true := by decide
def e1211180869342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))))
theorem wire_e1211180869342 : Closed e1211180869342 ∧ code e1211180869342 = 5609227380446 := by decide
theorem cert_e1211180869342 : check e1211180869342 [[],[]] .smaller = true := by decide
def e1211180869366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))))
theorem wire_e1211180869366 : Closed e1211180869366 ∧ code e1211180869366 = 5609227380470 := by decide
theorem cert_e1211180869366 : check e1211180869366 [[],[]] .smaller = true := by decide
def e1211180869470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))))
theorem wire_e1211180869470 : Closed e1211180869470 ∧ code e1211180869470 = 5609227380574 := by decide
theorem cert_e1211180869470 : check e1211180869470 [[],[]] .smaller = true := by decide
def e1211180869486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))))
theorem wire_e1211180869486 : Closed e1211180869486 ∧ code e1211180869486 = 5609227380590 := by decide
theorem cert_e1211180869486 : check e1211180869486 [[],[]] .smaller = true := by decide
def e1211180869494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))))
theorem wire_e1211180869494 : Closed e1211180869494 ∧ code e1211180869494 = 5609227380598 := by decide
theorem cert_e1211180869494 : check e1211180869494 [[],[]] .smaller = true := by decide
def e1211180869498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))))
theorem wire_e1211180869498 : Closed e1211180869498 ∧ code e1211180869498 = 5609227380602 := by decide
theorem cert_e1211180869498 : check e1211180869498 [[],[]] .smaller = true := by decide
def e1211180869558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))))
theorem wire_e1211180869558 : Closed e1211180869558 ∧ code e1211180869558 = 5609227380662 := by decide
theorem cert_e1211180869558 : check e1211180869558 [[],[]] .smaller = true := by decide
def e1211180869590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))))
theorem wire_e1211180869590 : Closed e1211180869590 ∧ code e1211180869590 = 5609227380694 := by decide
theorem cert_e1211180869590 : check e1211180869590 [[],[]] .smaller = true := by decide
def e1211180869594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))))
theorem wire_e1211180869594 : Closed e1211180869594 ∧ code e1211180869594 = 5609227380698 := by decide
theorem cert_e1211180869594 : check e1211180869594 [[],[]] .smaller = true := by decide
def e1211180870110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211180870110 : Closed e1211180870110 ∧ code e1211180870110 = 5609227381214 := by decide
theorem cert_e1211180870110 : check e1211180870110 [[],[]] .smaller = true := by decide
def e1211180870134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211180870134 : Closed e1211180870134 ∧ code e1211180870134 = 5609227381238 := by decide
theorem cert_e1211180870134 : check e1211180870134 [[],[]] .smaller = true := by decide
def e1211180870878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211180870878 : Closed e1211180870878 ∧ code e1211180870878 = 5609227381982 := by decide
theorem cert_e1211180870878 : check e1211180870878 [[],[]] .smaller = true := by decide
def e1211180870894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211180870894 : Closed e1211180870894 ∧ code e1211180870894 = 5609227381998 := by decide
theorem cert_e1211180870894 : check e1211180870894 [[],[]] .smaller = true := by decide
def e1211180870902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211180870902 : Closed e1211180870902 ∧ code e1211180870902 = 5609227382006 := by decide
theorem cert_e1211180870902 : check e1211180870902 [[],[]] .smaller = true := by decide
def e1211180870906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211180870906 : Closed e1211180870906 ∧ code e1211180870906 = 5609227382010 := by decide
theorem cert_e1211180870906 : check e1211180870906 [[],[]] .smaller = true := by decide
def e1211180871286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211180871286 : Closed e1211180871286 ∧ code e1211180871286 = 5609227382390 := by decide
theorem cert_e1211180871286 : check e1211180871286 [[],[]] .smaller = true := by decide
def e1211180871478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211180871478 : Closed e1211180871478 ∧ code e1211180871478 = 5609227382582 := by decide
theorem cert_e1211180871478 : check e1211180871478 [[],[]] .smaller = true := by decide
def e1211180871482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211180871482 : Closed e1211180871482 ∧ code e1211180871482 = 5609227382586 := by decide
theorem cert_e1211180871482 : check e1211180871482 [[],[]] .smaller = true := by decide
def e1211180872542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))))
theorem wire_e1211180872542 : Closed e1211180872542 ∧ code e1211180872542 = 5609227383646 := by decide
theorem cert_e1211180872542 : check e1211180872542 [[],[]] .smaller = true := by decide
def e1211180872558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e1211180872558 : Closed e1211180872558 ∧ code e1211180872558 = 5609227383662 := by decide
theorem cert_e1211180872558 : check e1211180872558 [[],[]] .smaller = true := by decide
def e1211180872566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e1211180872566 : Closed e1211180872566 ∧ code e1211180872566 = 5609227383670 := by decide
theorem cert_e1211180872566 : check e1211180872566 [[],[]] .smaller = true := by decide
def e1211180872570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))))
theorem wire_e1211180872570 : Closed e1211180872570 ∧ code e1211180872570 = 5609227383674 := by decide
theorem cert_e1211180872570 : check e1211180872570 [[],[]] .smaller = true := by decide
def e1211180872622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e1211180872622 : Closed e1211180872622 ∧ code e1211180872622 = 5609227383726 := by decide
theorem cert_e1211180872622 : check e1211180872622 [[],[]] .smaller = true := by decide
def e1211180872634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e1211180872634 : Closed e1211180872634 ∧ code e1211180872634 = 5609227383738 := by decide
theorem cert_e1211180872634 : check e1211180872634 [[],[]] .smaller = true := by decide
def e1211180872662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e1211180872662 : Closed e1211180872662 ∧ code e1211180872662 = 5609227383766 := by decide
theorem cert_e1211180872662 : check e1211180872662 [[],[]] .smaller = true := by decide
def e1211180872666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e1211180872666 : Closed e1211180872666 ∧ code e1211180872666 = 5609227383770 := by decide
theorem cert_e1211180872666 : check e1211180872666 [[],[]] .smaller = true := by decide
def e1211180872682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))))
theorem wire_e1211180872682 : Closed e1211180872682 ∧ code e1211180872682 = 5609227383786 := by decide
theorem cert_e1211180872682 : check e1211180872682 [[],[]] .smaller = true := by decide
def e1211180872926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211180872926 : Closed e1211180872926 ∧ code e1211180872926 = 5609227384030 := by decide
theorem cert_e1211180872926 : check e1211180872926 [[],[]] .smaller = true := by decide
def e1211180872942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211180872942 : Closed e1211180872942 ∧ code e1211180872942 = 5609227384046 := by decide
theorem cert_e1211180872942 : check e1211180872942 [[],[]] .smaller = true := by decide
def e1211180872950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211180872950 : Closed e1211180872950 ∧ code e1211180872950 = 5609227384054 := by decide
theorem cert_e1211180872950 : check e1211180872950 [[],[]] .smaller = true := by decide
def e1211180872954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211180872954 : Closed e1211180872954 ∧ code e1211180872954 = 5609227384058 := by decide
theorem cert_e1211180872954 : check e1211180872954 [[],[]] .smaller = true := by decide
def e1211180873326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211180873326 : Closed e1211180873326 ∧ code e1211180873326 = 5609227384430 := by decide
theorem cert_e1211180873326 : check e1211180873326 [[],[]] .smaller = true := by decide
def e1211180873338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211180873338 : Closed e1211180873338 ∧ code e1211180873338 = 5609227384442 := by decide
theorem cert_e1211180873338 : check e1211180873338 [[],[]] .smaller = true := by decide
def e1211180873526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211180873526 : Closed e1211180873526 ∧ code e1211180873526 = 5609227384630 := by decide
theorem cert_e1211180873526 : check e1211180873526 [[],[]] .smaller = true := by decide
def e1211180873530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211180873530 : Closed e1211180873530 ∧ code e1211180873530 = 5609227384634 := by decide
theorem cert_e1211180873530 : check e1211180873530 [[],[]] .smaller = true := by decide
def e1211180873626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211180873626 : Closed e1211180873626 ∧ code e1211180873626 = 5609227384730 := by decide
theorem cert_e1211180873626 : check e1211180873626 [[],[]] .smaller = true := by decide
def e1211180874166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))))
theorem wire_e1211180874166 : Closed e1211180874166 ∧ code e1211180874166 = 5609227385270 := by decide
theorem cert_e1211180874166 : check e1211180874166 [[],[]] .smaller = true := by decide
def e1211180874198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))))
theorem wire_e1211180874198 : Closed e1211180874198 ∧ code e1211180874198 = 5609227385302 := by decide
theorem cert_e1211180874198 : check e1211180874198 [[],[]] .smaller = true := by decide
def e1211180874202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))))
theorem wire_e1211180874202 : Closed e1211180874202 ∧ code e1211180874202 = 5609227385306 := by decide
theorem cert_e1211180874202 : check e1211180874202 [[],[]] .smaller = true := by decide
def e1211180874358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211180874358 : Closed e1211180874358 ∧ code e1211180874358 = 5609227385462 := by decide
theorem cert_e1211180874358 : check e1211180874358 [[],[]] .smaller = true := by decide
end Blc.Floor42
