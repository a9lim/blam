import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205143670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211205143670 : Closed e1211205143670 ∧ code e1211205143670 = 5609251654774 := by decide
theorem cert_e1211205143670 : check e1211205143670 [[],[]] .chain = true := by decide
def e1211205143674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211205143674 : Closed e1211205143674 ∧ code e1211205143674 = 5609251654778 := by decide
theorem cert_e1211205143674 : checkPay e1211205143674 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.right,.under],[.under,.under,.left,.right,.under,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.under],[.under,.under,.left,.right,.under,.left,.left,.right,.under,.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.right]] = true := by decide
def e1211205143766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1211205143766 : Closed e1211205143766 ∧ code e1211205143766 = 5609251654870 := by decide
theorem cert_e1211205143766 : check e1211205143766 [[],[]] .chain = true := by decide
def e1211205143770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211205143770 : Closed e1211205143770 ∧ code e1211205143770 = 5609251654874 := by decide
theorem cert_e1211205143770 : check e1211205143770 [[],[]] .chain = true := by decide
def e1211205143786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211205143786 : Closed e1211205143786 ∧ code e1211205143786 = 5609251654890 := by decide
theorem cert_e1211205143786 : check e1211205143786 [[],[]] .chain = true := by decide
def e1211205143814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205143814 : Closed e1211205143814 ∧ code e1211205143814 = 5609251654918 := by decide
theorem cert_e1211205143814 : check e1211205143814 [[],[]] .chain = true := by decide
def e1211205143838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211205143838 : Closed e1211205143838 ∧ code e1211205143838 = 5609251654942 := by decide
theorem cert_e1211205143838 : checkPay e1211205143838 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.right,.under],[.under,.under,.right,.under,.left],[.under,.under,.right,.under,.left,.left],[.under,.under,.right,.under,.left],[.under,.under,.right,.under]] = true := by decide
def e1211205143862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205143862 : Closed e1211205143862 ∧ code e1211205143862 = 5609251654966 := by decide
theorem cert_e1211205143862 : check e1211205143862 [[],[]] .chain = true := by decide
def e1211205143866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205143866 : Closed e1211205143866 ∧ code e1211205143866 = 5609251654970 := by decide
theorem cert_e1211205143866 : check e1211205143866 [[],[]] .chain = true := by decide
def e1211205143938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205143938 : Closed e1211205143938 ∧ code e1211205143938 = 5609251655042 := by decide
theorem cert_e1211205143938 : check e1211205143938 [[],[]] .chain = true := by decide
def e1211205143950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211205143950 : Closed e1211205143950 ∧ code e1211205143950 = 5609251655054 := by decide
theorem cert_e1211205143950 : check e1211205143950 [[],[]] .chain = true := by decide
def e1211205143962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205143962 : Closed e1211205143962 ∧ code e1211205143962 = 5609251655066 := by decide
theorem cert_e1211205143962 : check e1211205143962 [[],[]] .chain = true := by decide
def e1211205144006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211205144006 : Closed e1211205144006 ∧ code e1211205144006 = 5609251655110 := by decide
theorem cert_e1211205144006 : checkPay e1211205144006 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.right,.under,.right],[.under,.under,.left,.right,.right,.under,.right,.left],[.under,.under,.left,.right,.right,.under,.right],[.under,.under,.left,.right,.right,.under,.right,.under,.left],[.under,.under,.left,.right,.right,.under,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.right,.under,.right,.under,.left,.left]] = true := by decide
def e1211205144074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205144074 : Closed e1211205144074 ∧ code e1211205144074 = 5609251655178 := by decide
theorem cert_e1211205144074 : check e1211205144074 [[],[]] .chain = true := by decide
def e1211205144118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211205144118 : Closed e1211205144118 ∧ code e1211205144118 = 5609251655222 := by decide
theorem cert_e1211205144118 : check e1211205144118 [[],[]] .chain = true := by decide
def e1211205144122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211205144122 : Closed e1211205144122 ∧ code e1211205144122 = 5609251655226 := by decide
theorem cert_e1211205144122 : check e1211205144122 [[],[]] .chain = true := by decide
def e1211205144170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e1211205144170 : Closed e1211205144170 ∧ code e1211205144170 = 5609251655274 := by decide
theorem cert_e1211205144170 : check e1211205144170 [[],[]] .chain = true := by decide
def e1211205144194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205144194 : Closed e1211205144194 ∧ code e1211205144194 = 5609251655298 := by decide
theorem cert_e1211205144194 : check e1211205144194 [[],[]] .chain = true := by decide
def e1211205144206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211205144206 : Closed e1211205144206 ∧ code e1211205144206 = 5609251655310 := by decide
theorem cert_e1211205144206 : check e1211205144206 [[],[]] .chain = true := by decide
def e1211205144218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205144218 : Closed e1211205144218 ∧ code e1211205144218 = 5609251655322 := by decide
theorem cert_e1211205144218 : check e1211205144218 [[],[]] .chain = true := by decide
def e1211205144262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211205144262 : Closed e1211205144262 ∧ code e1211205144262 = 5609251655366 := by decide
theorem cert_e1211205144262 : check e1211205144262 [[],[]] .chain = true := by decide
def e1211205144346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205144346 : Closed e1211205144346 ∧ code e1211205144346 = 5609251655450 := by decide
theorem cert_e1211205144346 : checkPay e1211205144346 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left,.right]] = true := by decide
def e1211205144390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205144390 : Closed e1211205144390 ∧ code e1211205144390 = 5609251655494 := by decide
theorem cert_e1211205144390 : checkPay e1211205144390 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.right,.under],[.under,.under,.left,.right,.under,.left,.right,.under,.left,.left]] = true := by decide
def e1211205144606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211205144606 : Closed e1211205144606 ∧ code e1211205144606 = 5609251655710 := by decide
theorem cert_e1211205144606 : check e1211205144606 [[],[]] .chain = true := by decide
def e1211205144774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205144774 : Closed e1211205144774 ∧ code e1211205144774 = 5609251655878 := by decide
theorem cert_e1211205144774 : checkPay e1211205144774 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211205144798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211205144798 : Closed e1211205144798 ∧ code e1211205144798 = 5609251655902 := by decide
theorem cert_e1211205144798 : checkPay e1211205144798 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211205144802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211205144802 : Closed e1211205144802 ∧ code e1211205144802 = 5609251655906 := by decide
theorem cert_e1211205144802 : check e1211205144802 [[],[]] .chain = true := by decide
def e1211205144814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211205144814 : Closed e1211205144814 ∧ code e1211205144814 = 5609251655918 := by decide
theorem cert_e1211205144814 : check e1211205144814 [[],[]] .chain = true := by decide
def e1211205144822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211205144822 : Closed e1211205144822 ∧ code e1211205144822 = 5609251655926 := by decide
theorem cert_e1211205144822 : check e1211205144822 [[],[]] .chain = true := by decide
def e1211205144826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211205144826 : Closed e1211205144826 ∧ code e1211205144826 = 5609251655930 := by decide
theorem cert_e1211205144826 : checkPay e1211205144826 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right,.under]] = true := by decide
def e1211205145302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211205145302 : Closed e1211205145302 ∧ code e1211205145302 = 5609251656406 := by decide
theorem cert_e1211205145302 : check e1211205145302 [[],[]] .chain = true := by decide
def e1211205145306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211205145306 : Closed e1211205145306 ∧ code e1211205145306 = 5609251656410 := by decide
theorem cert_e1211205145306 : check e1211205145306 [[],[]] .chain = true := by decide
def e1211205145322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211205145322 : Closed e1211205145322 ∧ code e1211205145322 = 5609251656426 := by decide
theorem cert_e1211205145322 : check e1211205145322 [[],[]] .chain = true := by decide
def e1211205145350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205145350 : Closed e1211205145350 ∧ code e1211205145350 = 5609251656454 := by decide
theorem cert_e1211205145350 : check e1211205145350 [[],[]] .chain = true := by decide
def e1211205145374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211205145374 : Closed e1211205145374 ∧ code e1211205145374 = 5609251656478 := by decide
theorem cert_e1211205145374 : checkPay e1211205145374 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211205145398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205145398 : Closed e1211205145398 ∧ code e1211205145398 = 5609251656502 := by decide
theorem cert_e1211205145398 : check e1211205145398 [[],[]] .chain = true := by decide
def e1211205145402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205145402 : Closed e1211205145402 ∧ code e1211205145402 = 5609251656506 := by decide
theorem cert_e1211205145402 : check e1211205145402 [[],[]] .chain = true := by decide
def e1211205145474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205145474 : Closed e1211205145474 ∧ code e1211205145474 = 5609251656578 := by decide
theorem cert_e1211205145474 : check e1211205145474 [[],[]] .chain = true := by decide
def e1211205145486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211205145486 : Closed e1211205145486 ∧ code e1211205145486 = 5609251656590 := by decide
theorem cert_e1211205145486 : check e1211205145486 [[],[]] .chain = true := by decide
def e1211205145498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205145498 : Closed e1211205145498 ∧ code e1211205145498 = 5609251656602 := by decide
theorem cert_e1211205145498 : check e1211205145498 [[],[]] .chain = true := by decide
def e1211205145542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211205145542 : Closed e1211205145542 ∧ code e1211205145542 = 5609251656646 := by decide
theorem cert_e1211205145542 : checkPay e1211205145542 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.left]] = true := by decide
def e1211205146742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e1211205146742 : Closed e1211205146742 ∧ code e1211205146742 = 5609251657846 := by decide
theorem cert_e1211205146742 : check e1211205146742 [[],[]] .chain = true := by decide
def e1211205146986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e1211205146986 : Closed e1211205146986 ∧ code e1211205146986 = 5609251658090 := by decide
theorem cert_e1211205146986 : check e1211205146986 [[],[]] .chain = true := by decide
def e1211205147010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205147010 : Closed e1211205147010 ∧ code e1211205147010 = 5609251658114 := by decide
theorem cert_e1211205147010 : check e1211205147010 [[],[]] .chain = true := by decide
def e1211205147022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205147022 : Closed e1211205147022 ∧ code e1211205147022 = 5609251658126 := by decide
theorem cert_e1211205147022 : check e1211205147022 [[],[]] .chain = true := by decide
def e1211205147034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205147034 : Closed e1211205147034 ∧ code e1211205147034 = 5609251658138 := by decide
theorem cert_e1211205147034 : check e1211205147034 [[],[]] .chain = true := by decide
def e1211205147078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205147078 : Closed e1211205147078 ∧ code e1211205147078 = 5609251658182 := by decide
theorem cert_e1211205147078 : check e1211205147078 [[],[]] .chain = true := by decide
def e1211205147702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e1211205147702 : Closed e1211205147702 ∧ code e1211205147702 = 5609251658806 := by decide
theorem cert_e1211205147702 : checkPay e1211205147702 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211205147706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e1211205147706 : Closed e1211205147706 ∧ code e1211205147706 = 5609251658810 := by decide
theorem cert_e1211205147706 : checkPay e1211205147706 [[.left,.left],[.left,.left],[.left],[]] 1 [[.under]] = true := by decide
def e1211205147846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211205147846 : Closed e1211205147846 ∧ code e1211205147846 = 5609251658950 := by decide
theorem cert_e1211205147846 : checkPay e1211205147846 [[.left,.left],[.left,.left],[.left],[]] 1 [[],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1211205159790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211205159790 : Closed e1211205159790 ∧ code e1211205159790 = 5609251670894 := by decide
theorem cert_e1211205159790 : check e1211205159790 [[],[]] .smaller = true := by decide
def e1211205159798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211205159798 : Closed e1211205159798 ∧ code e1211205159798 = 5609251670902 := by decide
theorem cert_e1211205159798 : check e1211205159798 [[],[]] .smaller = true := by decide
def e1211205159854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211205159854 : Closed e1211205159854 ∧ code e1211205159854 = 5609251670958 := by decide
theorem cert_e1211205159854 : check e1211205159854 [[],[]] .smaller = true := by decide
def e1211205159866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211205159866 : Closed e1211205159866 ∧ code e1211205159866 = 5609251670970 := by decide
theorem cert_e1211205159866 : check e1211205159866 [[],[]] .smaller = true := by decide
def e1211205159894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211205159894 : Closed e1211205159894 ∧ code e1211205159894 = 5609251670998 := by decide
theorem cert_e1211205159894 : check e1211205159894 [[],[]] .smaller = true := by decide
def e1211205159898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211205159898 : Closed e1211205159898 ∧ code e1211205159898 = 5609251671002 := by decide
theorem cert_e1211205159898 : check e1211205159898 [[],[]] .smaller = true := by decide
def e1211205160174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211205160174 : Closed e1211205160174 ∧ code e1211205160174 = 5609251671278 := by decide
theorem cert_e1211205160174 : check e1211205160174 [[],[]] .smaller = true := by decide
def e1211205160182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211205160182 : Closed e1211205160182 ∧ code e1211205160182 = 5609251671286 := by decide
theorem cert_e1211205160182 : check e1211205160182 [[],[]] .smaller = true := by decide
def e1211205160558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211205160558 : Closed e1211205160558 ∧ code e1211205160558 = 5609251671662 := by decide
theorem cert_e1211205160558 : check e1211205160558 [[],[]] .smaller = true := by decide
def e1211205160570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211205160570 : Closed e1211205160570 ∧ code e1211205160570 = 5609251671674 := by decide
theorem cert_e1211205160570 : check e1211205160570 [[],[]] .smaller = true := by decide
def e1211205160758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211205160758 : Closed e1211205160758 ∧ code e1211205160758 = 5609251671862 := by decide
theorem cert_e1211205160758 : check e1211205160758 [[],[]] .smaller = true := by decide
def e1211205160762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211205160762 : Closed e1211205160762 ∧ code e1211205160762 = 5609251671866 := by decide
theorem cert_e1211205160762 : check e1211205160762 [[],[]] .smaller = true := by decide
def e1211205160894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e1211205160894 : Closed e1211205160894 ∧ code e1211205160894 = 5609251671998 := by decide
theorem cert_e1211205160894 : check e1211205160894 [[],[]] .chain = true := by decide
def e1211205160926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e1211205160926 : Closed e1211205160926 ∧ code e1211205160926 = 5609251672030 := by decide
theorem cert_e1211205160926 : check e1211205160926 [[],[]] .chain = true := by decide
def e1211205168606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1211205168606 : Closed e1211205168606 ∧ code e1211205168606 = 5609251679710 := by decide
theorem cert_e1211205168606 : check e1211205168606 [[],[]] .chain = true := by decide
def e1211205168622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1211205168622 : Closed e1211205168622 ∧ code e1211205168622 = 5609251679726 := by decide
theorem cert_e1211205168622 : check e1211205168622 [[],[]] .chain = true := by decide
def e1211205168862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1211205168862 : Closed e1211205168862 ∧ code e1211205168862 = 5609251679966 := by decide
theorem cert_e1211205168862 : check e1211205168862 [[],[]] .chain = true := by decide
def e1211205168886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1211205168886 : Closed e1211205168886 ∧ code e1211205168886 = 5609251679990 := by decide
theorem cert_e1211205168886 : check e1211205168886 [[],[]] .chain = true := by decide
def e1211205168990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1211205168990 : Closed e1211205168990 ∧ code e1211205168990 = 5609251680094 := by decide
theorem cert_e1211205168990 : check e1211205168990 [[],[]] .chain = true := by decide
def e1211205169018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1211205169018 : Closed e1211205169018 ∧ code e1211205169018 = 5609251680122 := by decide
theorem cert_e1211205169018 : check e1211205169018 [[],[]] .chain = true := by decide
def e1211205169070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1211205169070 : Closed e1211205169070 ∧ code e1211205169070 = 5609251680174 := by decide
theorem cert_e1211205169070 : check e1211205169070 [[],[]] .chain = true := by decide
def e1211205169078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1211205169078 : Closed e1211205169078 ∧ code e1211205169078 = 5609251680182 := by decide
theorem cert_e1211205169078 : check e1211205169078 [[],[]] .chain = true := by decide
def e1211205169082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1211205169082 : Closed e1211205169082 ∧ code e1211205169082 = 5609251680186 := by decide
theorem cert_e1211205169082 : check e1211205169082 [[],[]] .chain = true := by decide
def e1211205170142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211205170142 : Closed e1211205170142 ∧ code e1211205170142 = 5609251681246 := by decide
theorem cert_e1211205170142 : check e1211205170142 [[],[]] .chain = true := by decide
def e1211205170158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211205170158 : Closed e1211205170158 ∧ code e1211205170158 = 5609251681262 := by decide
theorem cert_e1211205170158 : check e1211205170158 [[],[]] .chain = true := by decide
def e1211205171678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211205171678 : Closed e1211205171678 ∧ code e1211205171678 = 5609251682782 := by decide
theorem cert_e1211205171678 : check e1211205171678 [[],[]] .chain = true := by decide
def e1211205171702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211205171702 : Closed e1211205171702 ∧ code e1211205171702 = 5609251682806 := by decide
theorem cert_e1211205171702 : check e1211205171702 [[],[]] .chain = true := by decide
def e1211205172446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205172446 : Closed e1211205172446 ∧ code e1211205172446 = 5609251683550 := by decide
theorem cert_e1211205172446 : check e1211205172446 [[],[]] .chain = true := by decide
def e1211205172474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205172474 : Closed e1211205172474 ∧ code e1211205172474 = 5609251683578 := by decide
theorem cert_e1211205172474 : check e1211205172474 [[],[]] .chain = true := by decide
def e1211205172762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211205172762 : Closed e1211205172762 ∧ code e1211205172762 = 5609251683866 := by decide
theorem cert_e1211205172762 : checkPay e1211205172762 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205172798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 4)))))))))
theorem wire_e1211205172798 : Closed e1211205172798 ∧ code e1211205172798 = 5609251683902 := by decide
theorem cert_e1211205172798 : checkPay e1211205172798 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205172846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205172846 : Closed e1211205172846 ∧ code e1211205172846 = 5609251683950 := by decide
theorem cert_e1211205172846 : check e1211205172846 [[],[]] .chain = true := by decide
def e1211205172854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205172854 : Closed e1211205172854 ∧ code e1211205172854 = 5609251683958 := by decide
theorem cert_e1211205172854 : check e1211205172854 [[],[]] .chain = true := by decide
def e1211205172858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205172858 : Closed e1211205172858 ∧ code e1211205172858 = 5609251683962 := by decide
theorem cert_e1211205172858 : check e1211205172858 [[],[]] .chain = true := by decide
def e1211205201262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211205201262 : Closed e1211205201262 ∧ code e1211205201262 = 5609251712366 := by decide
theorem cert_e1211205201262 : check e1211205201262 [[],[]] .chain = true := by decide
def e1211205201270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211205201270 : Closed e1211205201270 ∧ code e1211205201270 = 5609251712374 := by decide
theorem cert_e1211205201270 : check e1211205201270 [[],[]] .chain = true := by decide
def e1211205201326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211205201326 : Closed e1211205201326 ∧ code e1211205201326 = 5609251712430 := by decide
theorem cert_e1211205201326 : check e1211205201326 [[],[]] .chain = true := by decide
def e1211205201338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211205201338 : Closed e1211205201338 ∧ code e1211205201338 = 5609251712442 := by decide
theorem cert_e1211205201338 : check e1211205201338 [[],[]] .chain = true := by decide
def e1211205201366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211205201366 : Closed e1211205201366 ∧ code e1211205201366 = 5609251712470 := by decide
theorem cert_e1211205201366 : check e1211205201366 [[],[]] .chain = true := by decide
def e1211205201370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211205201370 : Closed e1211205201370 ∧ code e1211205201370 = 5609251712474 := by decide
theorem cert_e1211205201370 : check e1211205201370 [[],[]] .chain = true := by decide
def e1211205201582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211205201582 : Closed e1211205201582 ∧ code e1211205201582 = 5609251712686 := by decide
theorem cert_e1211205201582 : check e1211205201582 [[],[]] .chain = true := by decide
def e1211205201594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211205201594 : Closed e1211205201594 ∧ code e1211205201594 = 5609251712698 := by decide
theorem cert_e1211205201594 : check e1211205201594 [[],[]] .chain = true := by decide
def e1211205201642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211205201642 : Closed e1211205201642 ∧ code e1211205201642 = 5609251712746 := by decide
theorem cert_e1211205201642 : check e1211205201642 [[],[]] .chain = true := by decide
def e1211205201750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211205201750 : Closed e1211205201750 ∧ code e1211205201750 = 5609251712854 := by decide
theorem cert_e1211205201750 : check e1211205201750 [[],[]] .chain = true := by decide
def e1211205201754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211205201754 : Closed e1211205201754 ∧ code e1211205201754 = 5609251712858 := by decide
theorem cert_e1211205201754 : check e1211205201754 [[],[]] .chain = true := by decide
def e1211205201770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211205201770 : Closed e1211205201770 ∧ code e1211205201770 = 5609251712874 := by decide
theorem cert_e1211205201770 : check e1211205201770 [[],[]] .chain = true := by decide
def e1211205202030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211205202030 : Closed e1211205202030 ∧ code e1211205202030 = 5609251713134 := by decide
theorem cert_e1211205202030 : check e1211205202030 [[],[]] .chain = true := by decide
def e1211205202206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211205202206 : Closed e1211205202206 ∧ code e1211205202206 = 5609251713310 := by decide
theorem cert_e1211205202206 : check e1211205202206 [[],[]] .chain = true := by decide
def e1211205202402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211205202402 : Closed e1211205202402 ∧ code e1211205202402 = 5609251713506 := by decide
theorem cert_e1211205202402 : check e1211205202402 [[],[]] .chain = true := by decide
def e1211205202414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211205202414 : Closed e1211205202414 ∧ code e1211205202414 = 5609251713518 := by decide
theorem cert_e1211205202414 : checkPay e1211205202414 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205202798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211205202798 : Closed e1211205202798 ∧ code e1211205202798 = 5609251713902 := by decide
theorem cert_e1211205202798 : check e1211205202798 [[],[]] .chain = true := by decide
def e1211205202806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211205202806 : Closed e1211205202806 ∧ code e1211205202806 = 5609251713910 := by decide
theorem cert_e1211205202806 : check e1211205202806 [[],[]] .chain = true := by decide
def e1211205202862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211205202862 : Closed e1211205202862 ∧ code e1211205202862 = 5609251713966 := by decide
theorem cert_e1211205202862 : check e1211205202862 [[],[]] .chain = true := by decide
def e1211205202874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211205202874 : Closed e1211205202874 ∧ code e1211205202874 = 5609251713978 := by decide
theorem cert_e1211205202874 : check e1211205202874 [[],[]] .chain = true := by decide
def e1211205202902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211205202902 : Closed e1211205202902 ∧ code e1211205202902 = 5609251714006 := by decide
theorem cert_e1211205202902 : check e1211205202902 [[],[]] .chain = true := by decide
def e1211205202906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211205202906 : Closed e1211205202906 ∧ code e1211205202906 = 5609251714010 := by decide
theorem cert_e1211205202906 : check e1211205202906 [[],[]] .chain = true := by decide
def e1211205203182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211205203182 : Closed e1211205203182 ∧ code e1211205203182 = 5609251714286 := by decide
theorem cert_e1211205203182 : check e1211205203182 [[],[]] .chain = true := by decide
def e1211205203190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211205203190 : Closed e1211205203190 ∧ code e1211205203190 = 5609251714294 := by decide
theorem cert_e1211205203190 : check e1211205203190 [[],[]] .chain = true := by decide
def e1211205203566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205203566 : Closed e1211205203566 ∧ code e1211205203566 = 5609251714670 := by decide
theorem cert_e1211205203566 : check e1211205203566 [[],[]] .chain = true := by decide
def e1211205203578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205203578 : Closed e1211205203578 ∧ code e1211205203578 = 5609251714682 := by decide
theorem cert_e1211205203578 : check e1211205203578 [[],[]] .chain = true := by decide
def e1211205203718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205203718 : Closed e1211205203718 ∧ code e1211205203718 = 5609251714822 := by decide
theorem cert_e1211205203718 : check e1211205203718 [[],[]] .chain = true := by decide
def e1211205203742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211205203742 : Closed e1211205203742 ∧ code e1211205203742 = 5609251714846 := by decide
theorem cert_e1211205203742 : checkPay e1211205203742 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205203766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205203766 : Closed e1211205203766 ∧ code e1211205203766 = 5609251714870 := by decide
theorem cert_e1211205203766 : check e1211205203766 [[],[]] .chain = true := by decide
def e1211205203770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205203770 : Closed e1211205203770 ∧ code e1211205203770 = 5609251714874 := by decide
theorem cert_e1211205203770 : check e1211205203770 [[],[]] .chain = true := by decide
def e1211205204014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211205204014 : Closed e1211205204014 ∧ code e1211205204014 = 5609251715118 := by decide
theorem cert_e1211205204014 : check e1211205204014 [[],[]] .chain = true := by decide
def e1211205204206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211205204206 : Closed e1211205204206 ∧ code e1211205204206 = 5609251715310 := by decide
theorem cert_e1211205204206 : check e1211205204206 [[],[]] .chain = true := by decide
def e1211205204214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211205204214 : Closed e1211205204214 ∧ code e1211205204214 = 5609251715318 := by decide
theorem cert_e1211205204214 : check e1211205204214 [[],[]] .chain = true := by decide
def e1211205204398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211205204398 : Closed e1211205204398 ∧ code e1211205204398 = 5609251715502 := by decide
theorem cert_e1211205204398 : check e1211205204398 [[],[]] .chain = true := by decide
def e1211205204410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211205204410 : Closed e1211205204410 ∧ code e1211205204410 = 5609251715514 := by decide
theorem cert_e1211205204410 : check e1211205204410 [[],[]] .chain = true := by decide
def e1211205204458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211205204458 : Closed e1211205204458 ∧ code e1211205204458 = 5609251715562 := by decide
theorem cert_e1211205204458 : check e1211205204458 [[],[]] .chain = true := by decide
def e1211205204590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205204590 : Closed e1211205204590 ∧ code e1211205204590 = 5609251715694 := by decide
theorem cert_e1211205204590 : check e1211205204590 [[],[]] .chain = true := by decide
def e1211205204602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205204602 : Closed e1211205204602 ∧ code e1211205204602 = 5609251715706 := by decide
theorem cert_e1211205204602 : check e1211205204602 [[],[]] .chain = true := by decide
def e1211205204766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211205204766 : Closed e1211205204766 ∧ code e1211205204766 = 5609251715870 := by decide
theorem cert_e1211205204766 : check e1211205204766 [[],[]] .chain = true := by decide
def e1211205204866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205204866 : Closed e1211205204866 ∧ code e1211205204866 = 5609251715970 := by decide
theorem cert_e1211205204866 : check e1211205204866 [[],[]] .chain = true := by decide
def e1211205204878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211205204878 : Closed e1211205204878 ∧ code e1211205204878 = 5609251715982 := by decide
theorem cert_e1211205204878 : check e1211205204878 [[],[]] .chain = true := by decide
def e1211205204890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205204890 : Closed e1211205204890 ∧ code e1211205204890 = 5609251715994 := by decide
theorem cert_e1211205204890 : check e1211205204890 [[],[]] .chain = true := by decide
def e1211205205014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211205205014 : Closed e1211205205014 ∧ code e1211205205014 = 5609251716118 := by decide
theorem cert_e1211205205014 : check e1211205205014 [[],[]] .chain = true := by decide
def e1211205205018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211205205018 : Closed e1211205205018 ∧ code e1211205205018 = 5609251716122 := by decide
theorem cert_e1211205205018 : check e1211205205018 [[],[]] .chain = true := by decide
def e1211205205062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211205205062 : Closed e1211205205062 ∧ code e1211205205062 = 5609251716166 := by decide
theorem cert_e1211205205062 : check e1211205205062 [[],[]] .chain = true := by decide
def e1211205205090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211205205090 : Closed e1211205205090 ∧ code e1211205205090 = 5609251716194 := by decide
theorem cert_e1211205205090 : check e1211205205090 [[],[]] .chain = true := by decide
def e1211205205102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211205205102 : Closed e1211205205102 ∧ code e1211205205102 = 5609251716206 := by decide
theorem cert_e1211205205102 : checkPay e1211205205102 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205205110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211205205110 : Closed e1211205205110 ∧ code e1211205205110 = 5609251716214 := by decide
theorem cert_e1211205205110 : check e1211205205110 [[],[]] .chain = true := by decide
def e1211205205114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211205205114 : Closed e1211205205114 ∧ code e1211205205114 = 5609251716218 := by decide
theorem cert_e1211205205114 : checkPay e1211205205114 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205205206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211205205206 : Closed e1211205205206 ∧ code e1211205205206 = 5609251716310 := by decide
theorem cert_e1211205205206 : check e1211205205206 [[],[]] .chain = true := by decide
def e1211205205210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211205205210 : Closed e1211205205210 ∧ code e1211205205210 = 5609251716314 := by decide
theorem cert_e1211205205210 : check e1211205205210 [[],[]] .chain = true := by decide
def e1211205205226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211205205226 : Closed e1211205205226 ∧ code e1211205205226 = 5609251716330 := by decide
theorem cert_e1211205205226 : check e1211205205226 [[],[]] .chain = true := by decide
def e1211205205254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205205254 : Closed e1211205205254 ∧ code e1211205205254 = 5609251716358 := by decide
theorem cert_e1211205205254 : check e1211205205254 [[],[]] .chain = true := by decide
def e1211205205278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211205205278 : Closed e1211205205278 ∧ code e1211205205278 = 5609251716382 := by decide
theorem cert_e1211205205278 : checkPay e1211205205278 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205205302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205205302 : Closed e1211205205302 ∧ code e1211205205302 = 5609251716406 := by decide
theorem cert_e1211205205302 : check e1211205205302 [[],[]] .chain = true := by decide
def e1211205205306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205205306 : Closed e1211205205306 ∧ code e1211205205306 = 5609251716410 := by decide
theorem cert_e1211205205306 : check e1211205205306 [[],[]] .chain = true := by decide
def e1211205205378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205205378 : Closed e1211205205378 ∧ code e1211205205378 = 5609251716482 := by decide
theorem cert_e1211205205378 : check e1211205205378 [[],[]] .chain = true := by decide
def e1211205205390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211205205390 : Closed e1211205205390 ∧ code e1211205205390 = 5609251716494 := by decide
theorem cert_e1211205205390 : check e1211205205390 [[],[]] .chain = true := by decide
def e1211205205402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205205402 : Closed e1211205205402 ∧ code e1211205205402 = 5609251716506 := by decide
theorem cert_e1211205205402 : check e1211205205402 [[],[]] .chain = true := by decide
def e1211205205446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211205205446 : Closed e1211205205446 ∧ code e1211205205446 = 5609251716550 := by decide
theorem cert_e1211205205446 : checkPay e1211205205446 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205206142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211205206142 : Closed e1211205206142 ∧ code e1211205206142 = 5609251717246 := by decide
theorem cert_e1211205206142 : check e1211205206142 [[],[]] .chain = true := by decide
def e1211205207006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211205207006 : Closed e1211205207006 ∧ code e1211205207006 = 5609251718110 := by decide
theorem cert_e1211205207006 : check e1211205207006 [[],[]] .chain = true := by decide
def e1211205207010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211205207010 : Closed e1211205207010 ∧ code e1211205207010 = 5609251718114 := by decide
theorem cert_e1211205207010 : check e1211205207010 [[],[]] .chain = true := by decide
def e1211205207022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211205207022 : Closed e1211205207022 ∧ code e1211205207022 = 5609251718126 := by decide
theorem cert_e1211205207022 : check e1211205207022 [[],[]] .chain = true := by decide
def e1211205208942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211205208942 : Closed e1211205208942 ∧ code e1211205208942 = 5609251720046 := by decide
theorem cert_e1211205208942 : check e1211205208942 [[],[]] .chain = true := by decide
def e1211205208950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211205208950 : Closed e1211205208950 ∧ code e1211205208950 = 5609251720054 := by decide
theorem cert_e1211205208950 : check e1211205208950 [[],[]] .chain = true := by decide
def e1211205209006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211205209006 : Closed e1211205209006 ∧ code e1211205209006 = 5609251720110 := by decide
theorem cert_e1211205209006 : check e1211205209006 [[],[]] .chain = true := by decide
def e1211205209018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211205209018 : Closed e1211205209018 ∧ code e1211205209018 = 5609251720122 := by decide
theorem cert_e1211205209018 : check e1211205209018 [[],[]] .chain = true := by decide
def e1211205209046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211205209046 : Closed e1211205209046 ∧ code e1211205209046 = 5609251720150 := by decide
theorem cert_e1211205209046 : check e1211205209046 [[],[]] .chain = true := by decide
def e1211205209050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211205209050 : Closed e1211205209050 ∧ code e1211205209050 = 5609251720154 := by decide
theorem cert_e1211205209050 : check e1211205209050 [[],[]] .chain = true := by decide
def e1211205209326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205209326 : Closed e1211205209326 ∧ code e1211205209326 = 5609251720430 := by decide
theorem cert_e1211205209326 : check e1211205209326 [[],[]] .chain = true := by decide
def e1211205209334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205209334 : Closed e1211205209334 ∧ code e1211205209334 = 5609251720438 := by decide
theorem cert_e1211205209334 : check e1211205209334 [[],[]] .chain = true := by decide
def e1211205209710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205209710 : Closed e1211205209710 ∧ code e1211205209710 = 5609251720814 := by decide
theorem cert_e1211205209710 : check e1211205209710 [[],[]] .chain = true := by decide
def e1211205209722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205209722 : Closed e1211205209722 ∧ code e1211205209722 = 5609251720826 := by decide
theorem cert_e1211205209722 : check e1211205209722 [[],[]] .chain = true := by decide
def e1211205209862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211205209862 : Closed e1211205209862 ∧ code e1211205209862 = 5609251720966 := by decide
theorem cert_e1211205209862 : check e1211205209862 [[],[]] .chain = true := by decide
def e1211205209886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211205209886 : Closed e1211205209886 ∧ code e1211205209886 = 5609251720990 := by decide
theorem cert_e1211205209886 : checkPay e1211205209886 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
end Blc.Floor42
