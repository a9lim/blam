import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188133086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211188133086 : Closed e1211188133086 ∧ code e1211188133086 = 5609234644190 := by decide
theorem cert_e1211188133086 : check e1211188133086 [[],[]] .smaller = true := by decide
def e1211188133114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211188133114 : Closed e1211188133114 ∧ code e1211188133114 = 5609234644218 := by decide
theorem cert_e1211188133114 : check e1211188133114 [[],[]] .smaller = true := by decide
def e1211188133486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211188133486 : Closed e1211188133486 ∧ code e1211188133486 = 5609234644590 := by decide
theorem cert_e1211188133486 : check e1211188133486 [[],[]] .smaller = true := by decide
def e1211188133498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211188133498 : Closed e1211188133498 ∧ code e1211188133498 = 5609234644602 := by decide
theorem cert_e1211188133498 : check e1211188133498 [[],[]] .smaller = true := by decide
def e1211188161902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211188161902 : Closed e1211188161902 ∧ code e1211188161902 = 5609234673006 := by decide
theorem cert_e1211188161902 : check e1211188161902 [[],[]] .smaller = true := by decide
def e1211188161910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211188161910 : Closed e1211188161910 ∧ code e1211188161910 = 5609234673014 := by decide
theorem cert_e1211188161910 : check e1211188161910 [[],[]] .smaller = true := by decide
def e1211188161966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211188161966 : Closed e1211188161966 ∧ code e1211188161966 = 5609234673070 := by decide
theorem cert_e1211188161966 : check e1211188161966 [[],[]] .smaller = true := by decide
def e1211188161978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211188161978 : Closed e1211188161978 ∧ code e1211188161978 = 5609234673082 := by decide
theorem cert_e1211188161978 : check e1211188161978 [[],[]] .smaller = true := by decide
def e1211188162006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211188162006 : Closed e1211188162006 ∧ code e1211188162006 = 5609234673110 := by decide
theorem cert_e1211188162006 : check e1211188162006 [[],[]] .smaller = true := by decide
def e1211188162010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211188162010 : Closed e1211188162010 ∧ code e1211188162010 = 5609234673114 := by decide
theorem cert_e1211188162010 : check e1211188162010 [[],[]] .smaller = true := by decide
def e1211188162222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e1211188162222 : Closed e1211188162222 ∧ code e1211188162222 = 5609234673326 := by decide
theorem cert_e1211188162222 : check e1211188162222 [[],[]] .smaller = true := by decide
def e1211188162234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e1211188162234 : Closed e1211188162234 ∧ code e1211188162234 = 5609234673338 := by decide
theorem cert_e1211188162234 : check e1211188162234 [[],[]] .smaller = true := by decide
def e1211188162282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e1211188162282 : Closed e1211188162282 ∧ code e1211188162282 = 5609234673386 := by decide
theorem cert_e1211188162282 : check e1211188162282 [[],[]] .smaller = true := by decide
def e1211188162390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211188162390 : Closed e1211188162390 ∧ code e1211188162390 = 5609234673494 := by decide
theorem cert_e1211188162390 : check e1211188162390 [[],[]] .smaller = true := by decide
def e1211188162394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211188162394 : Closed e1211188162394 ∧ code e1211188162394 = 5609234673498 := by decide
theorem cert_e1211188162394 : check e1211188162394 [[],[]] .smaller = true := by decide
def e1211188162410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211188162410 : Closed e1211188162410 ∧ code e1211188162410 = 5609234673514 := by decide
theorem cert_e1211188162410 : check e1211188162410 [[],[]] .smaller = true := by decide
def e1211188163438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211188163438 : Closed e1211188163438 ∧ code e1211188163438 = 5609234674542 := by decide
theorem cert_e1211188163438 : check e1211188163438 [[],[]] .smaller = true := by decide
def e1211188163446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211188163446 : Closed e1211188163446 ∧ code e1211188163446 = 5609234674550 := by decide
theorem cert_e1211188163446 : check e1211188163446 [[],[]] .smaller = true := by decide
def e1211188163502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211188163502 : Closed e1211188163502 ∧ code e1211188163502 = 5609234674606 := by decide
theorem cert_e1211188163502 : check e1211188163502 [[],[]] .smaller = true := by decide
def e1211188163514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211188163514 : Closed e1211188163514 ∧ code e1211188163514 = 5609234674618 := by decide
theorem cert_e1211188163514 : check e1211188163514 [[],[]] .smaller = true := by decide
def e1211188163542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211188163542 : Closed e1211188163542 ∧ code e1211188163542 = 5609234674646 := by decide
theorem cert_e1211188163542 : check e1211188163542 [[],[]] .smaller = true := by decide
def e1211188163546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211188163546 : Closed e1211188163546 ∧ code e1211188163546 = 5609234674650 := by decide
theorem cert_e1211188163546 : check e1211188163546 [[],[]] .smaller = true := by decide
def e1211188163822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188163822 : Closed e1211188163822 ∧ code e1211188163822 = 5609234674926 := by decide
theorem cert_e1211188163822 : check e1211188163822 [[],[]] .smaller = true := by decide
def e1211188163830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188163830 : Closed e1211188163830 ∧ code e1211188163830 = 5609234674934 := by decide
theorem cert_e1211188163830 : check e1211188163830 [[],[]] .smaller = true := by decide
def e1211188164206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188164206 : Closed e1211188164206 ∧ code e1211188164206 = 5609234675310 := by decide
theorem cert_e1211188164206 : check e1211188164206 [[],[]] .smaller = true := by decide
def e1211188164218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188164218 : Closed e1211188164218 ∧ code e1211188164218 = 5609234675322 := by decide
theorem cert_e1211188164218 : check e1211188164218 [[],[]] .smaller = true := by decide
def e1211188164406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188164406 : Closed e1211188164406 ∧ code e1211188164406 = 5609234675510 := by decide
theorem cert_e1211188164406 : check e1211188164406 [[],[]] .smaller = true := by decide
def e1211188164410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188164410 : Closed e1211188164410 ∧ code e1211188164410 = 5609234675514 := by decide
theorem cert_e1211188164410 : check e1211188164410 [[],[]] .smaller = true := by decide
def e1211188165038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e1211188165038 : Closed e1211188165038 ∧ code e1211188165038 = 5609234676142 := by decide
theorem cert_e1211188165038 : check e1211188165038 [[],[]] .smaller = true := by decide
def e1211188165050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e1211188165050 : Closed e1211188165050 ∧ code e1211188165050 = 5609234676154 := by decide
theorem cert_e1211188165050 : check e1211188165050 [[],[]] .smaller = true := by decide
def e1211188165098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e1211188165098 : Closed e1211188165098 ∧ code e1211188165098 = 5609234676202 := by decide
theorem cert_e1211188165098 : check e1211188165098 [[],[]] .smaller = true := by decide
def e1211188165230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188165230 : Closed e1211188165230 ∧ code e1211188165230 = 5609234676334 := by decide
theorem cert_e1211188165230 : check e1211188165230 [[],[]] .smaller = true := by decide
def e1211188165242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188165242 : Closed e1211188165242 ∧ code e1211188165242 = 5609234676346 := by decide
theorem cert_e1211188165242 : check e1211188165242 [[],[]] .smaller = true := by decide
def e1211188165530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188165530 : Closed e1211188165530 ∧ code e1211188165530 = 5609234676634 := by decide
theorem cert_e1211188165530 : check e1211188165530 [[],[]] .smaller = true := by decide
def e1211188165566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e1211188165566 : Closed e1211188165566 ∧ code e1211188165566 = 5609234676670 := by decide
theorem cert_e1211188165566 : check e1211188165566 [[],[]] .three = true := by decide
def e1211188165598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 3)))))))))
theorem wire_e1211188165598 : Closed e1211188165598 ∧ code e1211188165598 = 5609234676702 := by decide
theorem cert_e1211188165598 : check e1211188165598 [[],[]] .smaller = true := by decide
def e1211188165614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e1211188165614 : Closed e1211188165614 ∧ code e1211188165614 = 5609234676718 := by decide
theorem cert_e1211188165614 : check e1211188165614 [[],[]] .three = true := by decide
def e1211188165846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211188165846 : Closed e1211188165846 ∧ code e1211188165846 = 5609234676950 := by decide
theorem cert_e1211188165846 : check e1211188165846 [[],[]] .smaller = true := by decide
def e1211188165850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211188165850 : Closed e1211188165850 ∧ code e1211188165850 = 5609234676954 := by decide
theorem cert_e1211188165850 : check e1211188165850 [[],[]] .smaller = true := by decide
def e1211188165866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211188165866 : Closed e1211188165866 ∧ code e1211188165866 = 5609234676970 := by decide
theorem cert_e1211188165866 : check e1211188165866 [[],[]] .smaller = true := by decide
def e1211188165942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188165942 : Closed e1211188165942 ∧ code e1211188165942 = 5609234677046 := by decide
theorem cert_e1211188165942 : check e1211188165942 [[],[]] .smaller = true := by decide
def e1211188165946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188165946 : Closed e1211188165946 ∧ code e1211188165946 = 5609234677050 := by decide
theorem cert_e1211188165946 : check e1211188165946 [[],[]] .smaller = true := by decide
def e1211188166042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188166042 : Closed e1211188166042 ∧ code e1211188166042 = 5609234677146 := by decide
theorem cert_e1211188166042 : check e1211188166042 [[],[]] .smaller = true := by decide
def e1211188166078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e1211188166078 : Closed e1211188166078 ∧ code e1211188166078 = 5609234677182 := by decide
theorem cert_e1211188166078 : check e1211188166078 [[],[]] .three = true := by decide
def e1211188166134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e1211188166134 : Closed e1211188166134 ∧ code e1211188166134 = 5609234677238 := by decide
theorem cert_e1211188166134 : check e1211188166134 [[],[]] .three = true := by decide
def e1211188166366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 3)))))))))
theorem wire_e1211188166366 : Closed e1211188166366 ∧ code e1211188166366 = 5609234677470 := by decide
theorem cert_e1211188166366 : check e1211188166366 [[],[]] .smaller = true := by decide
def e1211188166390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 3)) (.var 1)))))))))
theorem wire_e1211188166390 : Closed e1211188166390 ∧ code e1211188166390 = 5609234677494 := by decide
theorem cert_e1211188166390 : check e1211188166390 [[],[]] .smaller = true := by decide
def e1211188166510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e1211188166510 : Closed e1211188166510 ∧ code e1211188166510 = 5609234677614 := by decide
theorem cert_e1211188166510 : check e1211188166510 [[],[]] .three = true := by decide
def e1211188166518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e1211188166518 : Closed e1211188166518 ∧ code e1211188166518 = 5609234677622 := by decide
theorem cert_e1211188166518 : check e1211188166518 [[],[]] .three = true := by decide
def e1211188167646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211188167646 : Closed e1211188167646 ∧ code e1211188167646 = 5609234678750 := by decide
theorem cert_e1211188167646 : check e1211188167646 [[],[]] .smaller = true := by decide
def e1211188167662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211188167662 : Closed e1211188167662 ∧ code e1211188167662 = 5609234678766 := by decide
theorem cert_e1211188167662 : check e1211188167662 [[],[]] .smaller = true := by decide
def e1211188169582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211188169582 : Closed e1211188169582 ∧ code e1211188169582 = 5609234680686 := by decide
theorem cert_e1211188169582 : check e1211188169582 [[],[]] .smaller = true := by decide
def e1211188169590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211188169590 : Closed e1211188169590 ∧ code e1211188169590 = 5609234680694 := by decide
theorem cert_e1211188169590 : check e1211188169590 [[],[]] .smaller = true := by decide
def e1211188169646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211188169646 : Closed e1211188169646 ∧ code e1211188169646 = 5609234680750 := by decide
theorem cert_e1211188169646 : check e1211188169646 [[],[]] .smaller = true := by decide
def e1211188169658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211188169658 : Closed e1211188169658 ∧ code e1211188169658 = 5609234680762 := by decide
theorem cert_e1211188169658 : check e1211188169658 [[],[]] .smaller = true := by decide
def e1211188169686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211188169686 : Closed e1211188169686 ∧ code e1211188169686 = 5609234680790 := by decide
theorem cert_e1211188169686 : check e1211188169686 [[],[]] .smaller = true := by decide
def e1211188169690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211188169690 : Closed e1211188169690 ∧ code e1211188169690 = 5609234680794 := by decide
theorem cert_e1211188169690 : check e1211188169690 [[],[]] .smaller = true := by decide
def e1211188169966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211188169966 : Closed e1211188169966 ∧ code e1211188169966 = 5609234681070 := by decide
theorem cert_e1211188169966 : check e1211188169966 [[],[]] .smaller = true := by decide
def e1211188169974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211188169974 : Closed e1211188169974 ∧ code e1211188169974 = 5609234681078 := by decide
theorem cert_e1211188169974 : check e1211188169974 [[],[]] .smaller = true := by decide
def e1211188170350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211188170350 : Closed e1211188170350 ∧ code e1211188170350 = 5609234681454 := by decide
theorem cert_e1211188170350 : check e1211188170350 [[],[]] .smaller = true := by decide
def e1211188170362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211188170362 : Closed e1211188170362 ∧ code e1211188170362 = 5609234681466 := by decide
theorem cert_e1211188170362 : check e1211188170362 [[],[]] .smaller = true := by decide
def e1211188170550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188170550 : Closed e1211188170550 ∧ code e1211188170550 = 5609234681654 := by decide
theorem cert_e1211188170550 : check e1211188170550 [[],[]] .smaller = true := by decide
def e1211188170554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188170554 : Closed e1211188170554 ∧ code e1211188170554 = 5609234681658 := by decide
theorem cert_e1211188170554 : check e1211188170554 [[],[]] .smaller = true := by decide
def e1211188175326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211188175326 : Closed e1211188175326 ∧ code e1211188175326 = 5609234686430 := by decide
theorem cert_e1211188175326 : check e1211188175326 [[],[]] .smaller = true := by decide
def e1211188175350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211188175350 : Closed e1211188175350 ∧ code e1211188175350 = 5609234686454 := by decide
theorem cert_e1211188175350 : check e1211188175350 [[],[]] .smaller = true := by decide
def e1211188176302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211188176302 : Closed e1211188176302 ∧ code e1211188176302 = 5609234687406 := by decide
theorem cert_e1211188176302 : check e1211188176302 [[],[]] .smaller = true := by decide
def e1211188176314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211188176314 : Closed e1211188176314 ∧ code e1211188176314 = 5609234687418 := by decide
theorem cert_e1211188176314 : check e1211188176314 [[],[]] .smaller = true := by decide
def e1211188176362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211188176362 : Closed e1211188176362 ∧ code e1211188176362 = 5609234687466 := by decide
theorem cert_e1211188176362 : check e1211188176362 [[],[]] .smaller = true := by decide
def e1211188176494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211188176494 : Closed e1211188176494 ∧ code e1211188176494 = 5609234687598 := by decide
theorem cert_e1211188176494 : check e1211188176494 [[],[]] .smaller = true := by decide
def e1211188176506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211188176506 : Closed e1211188176506 ∧ code e1211188176506 = 5609234687610 := by decide
theorem cert_e1211188176506 : check e1211188176506 [[],[]] .smaller = true := by decide
def e1211188176794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188176794 : Closed e1211188176794 ∧ code e1211188176794 = 5609234687898 := by decide
theorem cert_e1211188176794 : check e1211188176794 [[],[]] .smaller = true := by decide
def e1211188176830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211188176830 : Closed e1211188176830 ∧ code e1211188176830 = 5609234687934 := by decide
theorem cert_e1211188176830 : check e1211188176830 [[],[]] .three = true := by decide
def e1211188176862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 3))))))))))
theorem wire_e1211188176862 : Closed e1211188176862 ∧ code e1211188176862 = 5609234687966 := by decide
theorem cert_e1211188176862 : check e1211188176862 [[],[]] .smaller = true := by decide
def e1211188176878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211188176878 : Closed e1211188176878 ∧ code e1211188176878 = 5609234687982 := by decide
theorem cert_e1211188176878 : check e1211188176878 [[],[]] .three = true := by decide
def e1211188179182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211188179182 : Closed e1211188179182 ∧ code e1211188179182 = 5609234690286 := by decide
theorem cert_e1211188179182 : check e1211188179182 [[],[]] .smaller = true := by decide
def e1211188179190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211188179190 : Closed e1211188179190 ∧ code e1211188179190 = 5609234690294 := by decide
theorem cert_e1211188179190 : check e1211188179190 [[],[]] .smaller = true := by decide
def e1211188179670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211188179670 : Closed e1211188179670 ∧ code e1211188179670 = 5609234690774 := by decide
theorem cert_e1211188179670 : check e1211188179670 [[],[]] .smaller = true := by decide
def e1211188179674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211188179674 : Closed e1211188179674 ∧ code e1211188179674 = 5609234690778 := by decide
theorem cert_e1211188179674 : check e1211188179674 [[],[]] .smaller = true := by decide
def e1211188179690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211188179690 : Closed e1211188179690 ∧ code e1211188179690 = 5609234690794 := by decide
theorem cert_e1211188179690 : check e1211188179690 [[],[]] .smaller = true := by decide
def e1211188179766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211188179766 : Closed e1211188179766 ∧ code e1211188179766 = 5609234690870 := by decide
theorem cert_e1211188179766 : check e1211188179766 [[],[]] .smaller = true := by decide
def e1211188179770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211188179770 : Closed e1211188179770 ∧ code e1211188179770 = 5609234690874 := by decide
theorem cert_e1211188179770 : check e1211188179770 [[],[]] .smaller = true := by decide
def e1211188179866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188179866 : Closed e1211188179866 ∧ code e1211188179866 = 5609234690970 := by decide
theorem cert_e1211188179866 : check e1211188179866 [[],[]] .smaller = true := by decide
def e1211188179902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211188179902 : Closed e1211188179902 ∧ code e1211188179902 = 5609234691006 := by decide
theorem cert_e1211188179902 : check e1211188179902 [[],[]] .three = true := by decide
def e1211188179958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211188179958 : Closed e1211188179958 ∧ code e1211188179958 = 5609234691062 := by decide
theorem cert_e1211188179958 : check e1211188179958 [[],[]] .three = true := by decide
def e1211188181470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211188181470 : Closed e1211188181470 ∧ code e1211188181470 = 5609234692574 := by decide
theorem cert_e1211188181470 : check e1211188181470 [[],[]] .smaller = true := by decide
def e1211188181494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211188181494 : Closed e1211188181494 ∧ code e1211188181494 = 5609234692598 := by decide
theorem cert_e1211188181494 : check e1211188181494 [[],[]] .smaller = true := by decide
def e1211188182254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188182254 : Closed e1211188182254 ∧ code e1211188182254 = 5609234693358 := by decide
theorem cert_e1211188182254 : check e1211188182254 [[],[]] .three = true := by decide
def e1211188182262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188182262 : Closed e1211188182262 ∧ code e1211188182262 = 5609234693366 := by decide
theorem cert_e1211188182262 : check e1211188182262 [[],[]] .three = true := by decide
def e1211188262110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188262110 : Closed e1211188262110 ∧ code e1211188262110 = 5609234773214 := by decide
theorem cert_e1211188262110 : check e1211188262110 [[],[]] .three = true := by decide
def e1211188262138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188262138 : Closed e1211188262138 ∧ code e1211188262138 = 5609234773242 := by decide
theorem cert_e1211188262138 : check e1211188262138 [[],[]] .three = true := by decide
def e1211188293982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e1211188293982 : Closed e1211188293982 ∧ code e1211188293982 = 5609234805086 := by decide
theorem cert_e1211188293982 : check e1211188293982 [[],[]] .three = true := by decide
def e1211188293998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e1211188293998 : Closed e1211188293998 ∧ code e1211188293998 = 5609234805102 := by decide
theorem cert_e1211188293998 : check e1211188293998 [[],[]] .smaller = true := by decide
def e1211188294006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e1211188294006 : Closed e1211188294006 ∧ code e1211188294006 = 5609234805110 := by decide
theorem cert_e1211188294006 : check e1211188294006 [[],[]] .smaller = true := by decide
def e1211188294010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e1211188294010 : Closed e1211188294010 ∧ code e1211188294010 = 5609234805114 := by decide
theorem cert_e1211188294010 : check e1211188294010 [[],[]] .three = true := by decide
def e1211188294062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211188294062 : Closed e1211188294062 ∧ code e1211188294062 = 5609234805166 := by decide
theorem cert_e1211188294062 : check e1211188294062 [[],[]] .smaller = true := by decide
def e1211188294074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211188294074 : Closed e1211188294074 ∧ code e1211188294074 = 5609234805178 := by decide
theorem cert_e1211188294074 : check e1211188294074 [[],[]] .smaller = true := by decide
def e1211188294122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211188294122 : Closed e1211188294122 ∧ code e1211188294122 = 5609234805226 := by decide
theorem cert_e1211188294122 : check e1211188294122 [[],[]] .smaller = true := by decide
def e1211188294750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211188294750 : Closed e1211188294750 ∧ code e1211188294750 = 5609234805854 := by decide
theorem cert_e1211188294750 : check e1211188294750 [[],[]] .three = true := by decide
def e1211188294766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211188294766 : Closed e1211188294766 ∧ code e1211188294766 = 5609234805870 := by decide
theorem cert_e1211188294766 : check e1211188294766 [[],[]] .smaller = true := by decide
def e1211188294778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211188294778 : Closed e1211188294778 ∧ code e1211188294778 = 5609234805882 := by decide
theorem cert_e1211188294778 : check e1211188294778 [[],[]] .smaller = true := by decide
def e1211188294942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211188294942 : Closed e1211188294942 ∧ code e1211188294942 = 5609234806046 := by decide
theorem cert_e1211188294942 : check e1211188294942 [[],[]] .smaller = true := by decide
def e1211188295110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211188295110 : Closed e1211188295110 ∧ code e1211188295110 = 5609234806214 := by decide
theorem cert_e1211188295110 : check e1211188295110 [[],[]] .smaller = true := by decide
def e1211188295134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211188295134 : Closed e1211188295134 ∧ code e1211188295134 = 5609234806238 := by decide
theorem cert_e1211188295134 : check e1211188295134 [[],[]] .three = true := by decide
def e1211188295138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211188295138 : Closed e1211188295138 ∧ code e1211188295138 = 5609234806242 := by decide
theorem cert_e1211188295138 : check e1211188295138 [[],[]] .three = true := by decide
def e1211188295150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211188295150 : Closed e1211188295150 ∧ code e1211188295150 = 5609234806254 := by decide
theorem cert_e1211188295150 : check e1211188295150 [[],[]] .three = true := by decide
def e1211188295214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211188295214 : Closed e1211188295214 ∧ code e1211188295214 = 5609234806318 := by decide
theorem cert_e1211188295214 : check e1211188295214 [[],[]] .smaller = true := by decide
def e1211188295390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e1211188295390 : Closed e1211188295390 ∧ code e1211188295390 = 5609234806494 := by decide
theorem cert_e1211188295390 : check e1211188295390 [[],[]] .three = true := by decide
def e1211188295394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211188295394 : Closed e1211188295394 ∧ code e1211188295394 = 5609234806498 := by decide
theorem cert_e1211188295394 : check e1211188295394 [[],[]] .smaller = true := by decide
def e1211188295406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e1211188295406 : Closed e1211188295406 ∧ code e1211188295406 = 5609234806510 := by decide
theorem cert_e1211188295406 : check e1211188295406 [[],[]] .smaller = true := by decide
def e1211188295414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e1211188295414 : Closed e1211188295414 ∧ code e1211188295414 = 5609234806518 := by decide
theorem cert_e1211188295414 : check e1211188295414 [[],[]] .three = true := by decide
def e1211188295446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211188295446 : Closed e1211188295446 ∧ code e1211188295446 = 5609234806550 := by decide
theorem cert_e1211188295446 : check e1211188295446 [[],[]] .smaller = true := by decide
def e1211188295450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211188295450 : Closed e1211188295450 ∧ code e1211188295450 = 5609234806554 := by decide
theorem cert_e1211188295450 : check e1211188295450 [[],[]] .smaller = true := by decide
def e1211188295494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211188295494 : Closed e1211188295494 ∧ code e1211188295494 = 5609234806598 := by decide
theorem cert_e1211188295494 : check e1211188295494 [[],[]] .smaller = true := by decide
def e1211188295518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211188295518 : Closed e1211188295518 ∧ code e1211188295518 = 5609234806622 := by decide
theorem cert_e1211188295518 : check e1211188295518 [[],[]] .three = true := by decide
def e1211188295522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211188295522 : Closed e1211188295522 ∧ code e1211188295522 = 5609234806626 := by decide
theorem cert_e1211188295522 : check e1211188295522 [[],[]] .smaller = true := by decide
def e1211188295534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e1211188295534 : Closed e1211188295534 ∧ code e1211188295534 = 5609234806638 := by decide
theorem cert_e1211188295534 : check e1211188295534 [[],[]] .smaller = true := by decide
def e1211188295542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e1211188295542 : Closed e1211188295542 ∧ code e1211188295542 = 5609234806646 := by decide
theorem cert_e1211188295542 : check e1211188295542 [[],[]] .smaller = true := by decide
def e1211188295546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211188295546 : Closed e1211188295546 ∧ code e1211188295546 = 5609234806650 := by decide
theorem cert_e1211188295546 : check e1211188295546 [[],[]] .three = true := by decide
def e1211188295562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188295562 : Closed e1211188295562 ∧ code e1211188295562 = 5609234806666 := by decide
theorem cert_e1211188295562 : check e1211188295562 [[],[]] .three = true := by decide
def e1211188295586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188295586 : Closed e1211188295586 ∧ code e1211188295586 = 5609234806690 := by decide
theorem cert_e1211188295586 : check e1211188295586 [[],[]] .three = true := by decide
def e1211188295598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211188295598 : Closed e1211188295598 ∧ code e1211188295598 = 5609234806702 := by decide
theorem cert_e1211188295598 : check e1211188295598 [[],[]] .three = true := by decide
def e1211188295606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e1211188295606 : Closed e1211188295606 ∧ code e1211188295606 = 5609234806710 := by decide
theorem cert_e1211188295606 : check e1211188295606 [[],[]] .three = true := by decide
def e1211188295610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211188295610 : Closed e1211188295610 ∧ code e1211188295610 = 5609234806714 := by decide
theorem cert_e1211188295610 : check e1211188295610 [[],[]] .three = true := by decide
def e1211188295854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e1211188295854 : Closed e1211188295854 ∧ code e1211188295854 = 5609234806958 := by decide
theorem cert_e1211188295854 : check e1211188295854 [[],[]] .smaller = true := by decide
def e1211188295866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e1211188295866 : Closed e1211188295866 ∧ code e1211188295866 = 5609234806970 := by decide
theorem cert_e1211188295866 : check e1211188295866 [[],[]] .smaller = true := by decide
def e1211188296238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211188296238 : Closed e1211188296238 ∧ code e1211188296238 = 5609234807342 := by decide
theorem cert_e1211188296238 : check e1211188296238 [[],[]] .smaller = true := by decide
def e1211188296414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211188296414 : Closed e1211188296414 ∧ code e1211188296414 = 5609234807518 := by decide
theorem cert_e1211188296414 : check e1211188296414 [[],[]] .three = true := by decide
def e1211188296418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211188296418 : Closed e1211188296418 ∧ code e1211188296418 = 5609234807522 := by decide
theorem cert_e1211188296418 : check e1211188296418 [[],[]] .smaller = true := by decide
def e1211188296430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e1211188296430 : Closed e1211188296430 ∧ code e1211188296430 = 5609234807534 := by decide
theorem cert_e1211188296430 : check e1211188296430 [[],[]] .smaller = true := by decide
def e1211188296438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211188296438 : Closed e1211188296438 ∧ code e1211188296438 = 5609234807542 := by decide
theorem cert_e1211188296438 : check e1211188296438 [[],[]] .three = true := by decide
def e1211188296542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211188296542 : Closed e1211188296542 ∧ code e1211188296542 = 5609234807646 := by decide
theorem cert_e1211188296542 : check e1211188296542 [[],[]] .three = true := by decide
def e1211188296570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211188296570 : Closed e1211188296570 ∧ code e1211188296570 = 5609234807674 := by decide
theorem cert_e1211188296570 : check e1211188296570 [[],[]] .three = true := by decide
def e1211188296586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188296586 : Closed e1211188296586 ∧ code e1211188296586 = 5609234807690 := by decide
theorem cert_e1211188296586 : check e1211188296586 [[],[]] .smaller = true := by decide
def e1211188296610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188296610 : Closed e1211188296610 ∧ code e1211188296610 = 5609234807714 := by decide
theorem cert_e1211188296610 : check e1211188296610 [[],[]] .smaller = true := by decide
def e1211188296622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e1211188296622 : Closed e1211188296622 ∧ code e1211188296622 = 5609234807726 := by decide
theorem cert_e1211188296622 : check e1211188296622 [[],[]] .smaller = true := by decide
def e1211188296634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e1211188296634 : Closed e1211188296634 ∧ code e1211188296634 = 5609234807738 := by decide
theorem cert_e1211188296634 : check e1211188296634 [[],[]] .smaller = true := by decide
def e1211188296662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211188296662 : Closed e1211188296662 ∧ code e1211188296662 = 5609234807766 := by decide
theorem cert_e1211188296662 : check e1211188296662 [[],[]] .three = true := by decide
def e1211188296666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211188296666 : Closed e1211188296666 ∧ code e1211188296666 = 5609234807770 := by decide
theorem cert_e1211188296666 : check e1211188296666 [[],[]] .three = true := by decide
def e1211188296790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211188296790 : Closed e1211188296790 ∧ code e1211188296790 = 5609234807894 := by decide
theorem cert_e1211188296790 : check e1211188296790 [[],[]] .smaller = true := by decide
def e1211188296794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211188296794 : Closed e1211188296794 ∧ code e1211188296794 = 5609234807898 := by decide
theorem cert_e1211188296794 : check e1211188296794 [[],[]] .smaller = true := by decide
def e1211188296810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e1211188296810 : Closed e1211188296810 ∧ code e1211188296810 = 5609234807914 := by decide
theorem cert_e1211188296810 : check e1211188296810 [[],[]] .smaller = true := by decide
def e1211188296982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211188296982 : Closed e1211188296982 ∧ code e1211188296982 = 5609234808086 := by decide
theorem cert_e1211188296982 : check e1211188296982 [[],[]] .smaller = true := by decide
def e1211188296986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211188296986 : Closed e1211188296986 ∧ code e1211188296986 = 5609234808090 := by decide
theorem cert_e1211188296986 : check e1211188296986 [[],[]] .smaller = true := by decide
def e1211188297030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211188297030 : Closed e1211188297030 ∧ code e1211188297030 = 5609234808134 := by decide
theorem cert_e1211188297030 : check e1211188297030 [[],[]] .smaller = true := by decide
def e1211188297054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211188297054 : Closed e1211188297054 ∧ code e1211188297054 = 5609234808158 := by decide
theorem cert_e1211188297054 : check e1211188297054 [[],[]] .three = true := by decide
def e1211188297058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211188297058 : Closed e1211188297058 ∧ code e1211188297058 = 5609234808162 := by decide
theorem cert_e1211188297058 : check e1211188297058 [[],[]] .smaller = true := by decide
def e1211188297070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211188297070 : Closed e1211188297070 ∧ code e1211188297070 = 5609234808174 := by decide
theorem cert_e1211188297070 : check e1211188297070 [[],[]] .smaller = true := by decide
def e1211188297078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211188297078 : Closed e1211188297078 ∧ code e1211188297078 = 5609234808182 := by decide
theorem cert_e1211188297078 : check e1211188297078 [[],[]] .smaller = true := by decide
def e1211188297082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211188297082 : Closed e1211188297082 ∧ code e1211188297082 = 5609234808186 := by decide
theorem cert_e1211188297082 : check e1211188297082 [[],[]] .three = true := by decide
def e1211188297098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188297098 : Closed e1211188297098 ∧ code e1211188297098 = 5609234808202 := by decide
theorem cert_e1211188297098 : check e1211188297098 [[],[]] .smaller = true := by decide
def e1211188297122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188297122 : Closed e1211188297122 ∧ code e1211188297122 = 5609234808226 := by decide
theorem cert_e1211188297122 : check e1211188297122 [[],[]] .smaller = true := by decide
def e1211188297134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211188297134 : Closed e1211188297134 ∧ code e1211188297134 = 5609234808238 := by decide
theorem cert_e1211188297134 : check e1211188297134 [[],[]] .smaller = true := by decide
def e1211188297146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211188297146 : Closed e1211188297146 ∧ code e1211188297146 = 5609234808250 := by decide
theorem cert_e1211188297146 : check e1211188297146 [[],[]] .smaller = true := by decide
def e1211188297174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211188297174 : Closed e1211188297174 ∧ code e1211188297174 = 5609234808278 := by decide
theorem cert_e1211188297174 : check e1211188297174 [[],[]] .smaller = true := by decide
def e1211188297178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211188297178 : Closed e1211188297178 ∧ code e1211188297178 = 5609234808282 := by decide
theorem cert_e1211188297178 : check e1211188297178 [[],[]] .smaller = true := by decide
def e1211188297194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211188297194 : Closed e1211188297194 ∧ code e1211188297194 = 5609234808298 := by decide
theorem cert_e1211188297194 : check e1211188297194 [[],[]] .three = true := by decide
def e1211188297258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e1211188297258 : Closed e1211188297258 ∧ code e1211188297258 = 5609234808362 := by decide
theorem cert_e1211188297258 : check e1211188297258 [[],[]] .three = true := by decide
def e1211188297354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188297354 : Closed e1211188297354 ∧ code e1211188297354 = 5609234808458 := by decide
theorem cert_e1211188297354 : check e1211188297354 [[],[]] .three = true := by decide
def e1211188297378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188297378 : Closed e1211188297378 ∧ code e1211188297378 = 5609234808482 := by decide
theorem cert_e1211188297378 : check e1211188297378 [[],[]] .three = true := by decide
def e1211188297390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211188297390 : Closed e1211188297390 ∧ code e1211188297390 = 5609234808494 := by decide
theorem cert_e1211188297390 : check e1211188297390 [[],[]] .three = true := by decide
end Blc.Floor42
