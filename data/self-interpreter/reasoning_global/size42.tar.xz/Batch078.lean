import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196686783406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1196686783406 : Closed e1196686783406 ∧ code e1196686783406 = 5594733294510 := by decide
theorem cert_e1196686783406 : check e1196686783406 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686783418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1196686783418 : Closed e1196686783418 ∧ code e1196686783418 = 5594733294522 := by decide
theorem cert_e1196686783418 : checkPay e1196686783418 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.right,.right]] = true := by decide
def e1196686783446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1196686783446 : Closed e1196686783446 ∧ code e1196686783446 = 5594733294550 := by decide
theorem cert_e1196686783446 : check e1196686783446 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686783450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1196686783450 : Closed e1196686783450 ∧ code e1196686783450 = 5594733294554 := by decide
theorem cert_e1196686783450 : checkPay e1196686783450 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left,.right],[.left,.left,.left,.right,.under,.under,.left,.right,.right]] = true := by decide
def e1196686783726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686783726 : Closed e1196686783726 ∧ code e1196686783726 = 5594733294830 := by decide
theorem cert_e1196686783726 : check e1196686783726 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1196686783734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686783734 : Closed e1196686783734 ∧ code e1196686783734 = 5594733294838 := by decide
theorem cert_e1196686783734 : check e1196686783734 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1196686784110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686784110 : Closed e1196686784110 ∧ code e1196686784110 = 5594733295214 := by decide
theorem cert_e1196686784110 : check e1196686784110 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686784122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686784122 : Closed e1196686784122 ∧ code e1196686784122 = 5594733295226 := by decide
theorem cert_e1196686784122 : check e1196686784122 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1196686784286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1196686784286 : Closed e1196686784286 ∧ code e1196686784286 = 5594733295390 := by decide
theorem cert_e1196686784286 : check e1196686784286 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686784310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686784310 : Closed e1196686784310 ∧ code e1196686784310 = 5594733295414 := by decide
theorem cert_e1196686784310 : check e1196686784310 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686784314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686784314 : Closed e1196686784314 ∧ code e1196686784314 = 5594733295418 := by decide
theorem cert_e1196686784314 : check e1196686784314 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1196686784942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1196686784942 : Closed e1196686784942 ∧ code e1196686784942 = 5594733296046 := by decide
theorem cert_e1196686784942 : check e1196686784942 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686784954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1196686784954 : Closed e1196686784954 ∧ code e1196686784954 = 5594733296058 := by decide
theorem cert_e1196686784954 : checkPay e1196686784954 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left,.left],[.right,.left],[.right],[.right,.left],[.right],[.right],[.right,.under]] = true := by decide
def e1196686785002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1196686785002 : Closed e1196686785002 ∧ code e1196686785002 = 5594733296106 := by decide
theorem cert_e1196686785002 : checkPay e1196686785002 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left,.left,.left,.left],[.right,.under,.left,.left,.left,.left,.left],[.right,.under,.left,.left,.left,.left]] = true := by decide
def e1196686785134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686785134 : Closed e1196686785134 ∧ code e1196686785134 = 5594733296238 := by decide
theorem cert_e1196686785134 : check e1196686785134 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686785146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686785146 : Closed e1196686785146 ∧ code e1196686785146 = 5594733296250 := by decide
def e1196686785434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1196686785434 : Closed e1196686785434 ∧ code e1196686785434 = 5594733296538 := by decide
theorem cert_e1196686785434 : check e1196686785434 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686785646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1196686785646 : Closed e1196686785646 ∧ code e1196686785646 = 5594733296750 := by decide
theorem cert_e1196686785646 : check e1196686785646 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686785658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1196686785658 : Closed e1196686785658 ∧ code e1196686785658 = 5594733296762 := by decide
theorem cert_e1196686785658 : checkPay e1196686785658 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.right]] = true := by decide
def e1196686785750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1196686785750 : Closed e1196686785750 ∧ code e1196686785750 = 5594733296854 := by decide
theorem cert_e1196686785750 : check e1196686785750 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686785754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1196686785754 : Closed e1196686785754 ∧ code e1196686785754 = 5594733296858 := by decide
theorem cert_e1196686785754 : checkPay e1196686785754 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.right,.right,.right]] = true := by decide
def e1196686785770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1196686785770 : Closed e1196686785770 ∧ code e1196686785770 = 5594733296874 := by decide
theorem cert_e1196686785770 : checkPay e1196686785770 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right,.left],[.under,.left,.right]] = true := by decide
def e1196686785822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1196686785822 : Closed e1196686785822 ∧ code e1196686785822 = 5594733296926 := by decide
theorem cert_e1196686785822 : check e1196686785822 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686785846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686785846 : Closed e1196686785846 ∧ code e1196686785846 = 5594733296950 := by decide
theorem cert_e1196686785846 : check e1196686785846 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686785850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686785850 : Closed e1196686785850 ∧ code e1196686785850 = 5594733296954 := by decide
theorem cert_e1196686785850 : check e1196686785850 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1196686785946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1196686785946 : Closed e1196686785946 ∧ code e1196686785946 = 5594733297050 := by decide
theorem cert_e1196686785946 : check e1196686785946 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686785990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1196686785990 : Closed e1196686785990 ∧ code e1196686785990 = 5594733297094 := by decide
theorem cert_e1196686785990 : check e1196686785990 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .smaller = true := by decide
def e1196686787550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1196686787550 : Closed e1196686787550 ∧ code e1196686787550 = 5594733298654 := by decide
theorem cert_e1196686787550 : check e1196686787550 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686787566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1196686787566 : Closed e1196686787566 ∧ code e1196686787566 = 5594733298670 := by decide
theorem cert_e1196686787566 : check e1196686787566 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686789486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196686789486 : Closed e1196686789486 ∧ code e1196686789486 = 5594733300590 := by decide
theorem cert_e1196686789486 : check e1196686789486 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686789494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196686789494 : Closed e1196686789494 ∧ code e1196686789494 = 5594733300598 := by decide
theorem cert_e1196686789494 : check e1196686789494 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686789550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196686789550 : Closed e1196686789550 ∧ code e1196686789550 = 5594733300654 := by decide
theorem cert_e1196686789550 : check e1196686789550 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686789562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196686789562 : Closed e1196686789562 ∧ code e1196686789562 = 5594733300666 := by decide
theorem cert_e1196686789562 : check e1196686789562 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686789590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196686789590 : Closed e1196686789590 ∧ code e1196686789590 = 5594733300694 := by decide
theorem cert_e1196686789590 : check e1196686789590 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1196686789594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196686789594 : Closed e1196686789594 ∧ code e1196686789594 = 5594733300698 := by decide
theorem cert_e1196686789594 : check e1196686789594 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686789870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196686789870 : Closed e1196686789870 ∧ code e1196686789870 = 5594733300974 := by decide
theorem cert_e1196686789870 : check e1196686789870 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686789878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196686789878 : Closed e1196686789878 ∧ code e1196686789878 = 5594733300982 := by decide
theorem cert_e1196686789878 : check e1196686789878 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686790254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196686790254 : Closed e1196686790254 ∧ code e1196686790254 = 5594733301358 := by decide
theorem cert_e1196686790254 : check e1196686790254 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1196686790266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196686790266 : Closed e1196686790266 ∧ code e1196686790266 = 5594733301370 := by decide
theorem cert_e1196686790266 : check e1196686790266 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1196686790430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1196686790430 : Closed e1196686790430 ∧ code e1196686790430 = 5594733301534 := by decide
theorem cert_e1196686790430 : check e1196686790430 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1196686790454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686790454 : Closed e1196686790454 ∧ code e1196686790454 = 5594733301558 := by decide
theorem cert_e1196686790454 : check e1196686790454 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1196686790458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686790458 : Closed e1196686790458 ∧ code e1196686790458 = 5594733301562 := by decide
theorem cert_e1196686790458 : check e1196686790458 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1196686795230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1196686795230 : Closed e1196686795230 ∧ code e1196686795230 = 5594733306334 := by decide
theorem cert_e1196686795230 : checkPay e1196686795230 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1196686795254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1196686795254 : Closed e1196686795254 ∧ code e1196686795254 = 5594733306358 := by decide
theorem cert_e1196686795254 : check e1196686795254 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686796206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1196686796206 : Closed e1196686796206 ∧ code e1196686796206 = 5594733307310 := by decide
theorem cert_e1196686796206 : check e1196686796206 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686796218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1196686796218 : Closed e1196686796218 ∧ code e1196686796218 = 5594733307322 := by decide
theorem cert_e1196686796218 : check e1196686796218 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686796266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1196686796266 : Closed e1196686796266 ∧ code e1196686796266 = 5594733307370 := by decide
theorem cert_e1196686796266 : check e1196686796266 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686796398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1196686796398 : Closed e1196686796398 ∧ code e1196686796398 = 5594733307502 := by decide
theorem cert_e1196686796398 : check e1196686796398 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686796410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1196686796410 : Closed e1196686796410 ∧ code e1196686796410 = 5594733307514 := by decide
theorem cert_e1196686796410 : check e1196686796410 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686796698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1196686796698 : Closed e1196686796698 ∧ code e1196686796698 = 5594733307802 := by decide
def e1196686799086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1196686799086 : Closed e1196686799086 ∧ code e1196686799086 = 5594733310190 := by decide
theorem cert_e1196686799086 : checkPay e1196686799086 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1196686799094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1196686799094 : Closed e1196686799094 ∧ code e1196686799094 = 5594733310198 := by decide
theorem cert_e1196686799094 : check e1196686799094 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686799574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1196686799574 : Closed e1196686799574 ∧ code e1196686799574 = 5594733310678 := by decide
theorem cert_e1196686799574 : check e1196686799574 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686799578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1196686799578 : Closed e1196686799578 ∧ code e1196686799578 = 5594733310682 := by decide
theorem cert_e1196686799578 : check e1196686799578 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686799594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1196686799594 : Closed e1196686799594 ∧ code e1196686799594 = 5594733310698 := by decide
theorem cert_e1196686799594 : check e1196686799594 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686799646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1196686799646 : Closed e1196686799646 ∧ code e1196686799646 = 5594733310750 := by decide
theorem cert_e1196686799646 : check e1196686799646 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686799670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686799670 : Closed e1196686799670 ∧ code e1196686799670 = 5594733310774 := by decide
theorem cert_e1196686799670 : check e1196686799670 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686799674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686799674 : Closed e1196686799674 ∧ code e1196686799674 = 5594733310778 := by decide
theorem cert_e1196686799674 : check e1196686799674 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686799770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1196686799770 : Closed e1196686799770 ∧ code e1196686799770 = 5594733310874 := by decide
theorem cert_e1196686799770 : check e1196686799770 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686799814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1196686799814 : Closed e1196686799814 ∧ code e1196686799814 = 5594733310918 := by decide
theorem cert_e1196686799814 : check e1196686799814 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1196686804854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1196686804854 : Closed e1196686804854 ∧ code e1196686804854 = 5594733315958 := by decide
theorem cert_e1196686804854 : checkPay e1196686804854 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e1196686804918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1196686804918 : Closed e1196686804918 ∧ code e1196686804918 = 5594733316022 := by decide
theorem cert_e1196686804918 : check e1196686804918 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686804922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1196686804922 : Closed e1196686804922 ∧ code e1196686804922 = 5594733316026 := by decide
theorem cert_e1196686804922 : check e1196686804922 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1196686806254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686806254 : Closed e1196686806254 ∧ code e1196686806254 = 5594733317358 := by decide
theorem cert_e1196686806254 : check e1196686806254 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686806262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686806262 : Closed e1196686806262 ∧ code e1196686806262 = 5594733317366 := by decide
theorem cert_e1196686806262 : check e1196686806262 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686806638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686806638 : Closed e1196686806638 ∧ code e1196686806638 = 5594733317742 := by decide
theorem cert_e1196686806638 : check e1196686806638 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686806650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686806650 : Closed e1196686806650 ∧ code e1196686806650 = 5594733317754 := by decide
theorem cert_e1196686806650 : check e1196686806650 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686806838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686806838 : Closed e1196686806838 ∧ code e1196686806838 = 5594733317942 := by decide
theorem cert_e1196686806838 : check e1196686806838 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686806842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686806842 : Closed e1196686806842 ∧ code e1196686806842 = 5594733317946 := by decide
theorem cert_e1196686806842 : check e1196686806842 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686808758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1196686808758 : Closed e1196686808758 ∧ code e1196686808758 = 5594733319862 := by decide
theorem cert_e1196686808758 : check e1196686808758 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686808790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1196686808790 : Closed e1196686808790 ∧ code e1196686808790 = 5594733319894 := by decide
theorem cert_e1196686808790 : check e1196686808790 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686808794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1196686808794 : Closed e1196686808794 ∧ code e1196686808794 = 5594733319898 := by decide
theorem cert_e1196686808794 : check e1196686808794 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686808918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1196686808918 : Closed e1196686808918 ∧ code e1196686808918 = 5594733320022 := by decide
theorem cert_e1196686808918 : check e1196686808918 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686808922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1196686808922 : Closed e1196686808922 ∧ code e1196686808922 = 5594733320026 := by decide
theorem cert_e1196686808922 : check e1196686808922 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1196686808938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1196686808938 : Closed e1196686808938 ∧ code e1196686808938 = 5594733320042 := by decide
theorem cert_e1196686808938 : check e1196686808938 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1196686809326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1196686809326 : Closed e1196686809326 ∧ code e1196686809326 = 5594733320430 := by decide
theorem cert_e1196686809326 : check e1196686809326 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1196686809334 : Closed e1196686809334 ∧ code e1196686809334 = 5594733320438 := by decide
theorem cert_e1196686809334 : check e1196686809334 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1196686809526 : Closed e1196686809526 ∧ code e1196686809526 = 5594733320630 := by decide
theorem cert_e1196686809526 : check e1196686809526 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1196686809558 : Closed e1196686809558 ∧ code e1196686809558 = 5594733320662 := by decide
theorem cert_e1196686809558 : check e1196686809558 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1196686809562 : Closed e1196686809562 ∧ code e1196686809562 = 5594733320666 := by decide
theorem cert_e1196686809562 : check e1196686809562 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1196686809718 : Closed e1196686809718 ∧ code e1196686809718 = 5594733320822 := by decide
theorem cert_e1196686809718 : check e1196686809718 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1196686809886 : Closed e1196686809886 ∧ code e1196686809886 = 5594733320990 := by decide
theorem cert_e1196686809886 : check e1196686809886 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686809910 : Closed e1196686809910 ∧ code e1196686809910 = 5594733321014 := by decide
theorem cert_e1196686809910 : check e1196686809910 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686809914 : Closed e1196686809914 ∧ code e1196686809914 = 5594733321018 := by decide
theorem cert_e1196686809914 : check e1196686809914 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686809998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1196686809998 : Closed e1196686809998 ∧ code e1196686809998 = 5594733321102 := by decide
theorem cert_e1196686809998 : check e1196686809998 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686810222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1196686810222 : Closed e1196686810222 ∧ code e1196686810222 = 5594733321326 := by decide
theorem cert_e1196686810222 : check e1196686810222 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1196686810234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1196686810234 : Closed e1196686810234 ∧ code e1196686810234 = 5594733321338 := by decide
theorem cert_e1196686810234 : check e1196686810234 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1196686810326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1196686810326 : Closed e1196686810326 ∧ code e1196686810326 = 5594733321430 := by decide
theorem cert_e1196686810326 : check e1196686810326 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1196686810330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1196686810330 : Closed e1196686810330 ∧ code e1196686810330 = 5594733321434 := by decide
theorem cert_e1196686810330 : check e1196686810330 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1196686810346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1196686810346 : Closed e1196686810346 ∧ code e1196686810346 = 5594733321450 := by decide
theorem cert_e1196686810346 : check e1196686810346 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1196686810398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1196686810398 : Closed e1196686810398 ∧ code e1196686810398 = 5594733321502 := by decide
theorem cert_e1196686810398 : checkPay e1196686810398 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.under,.left,.right],[.under,.under,.under,.left,.right,.under]] = true := by decide
def e1196686810422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686810422 : Closed e1196686810422 ∧ code e1196686810422 = 5594733321526 := by decide
theorem cert_e1196686810422 : checkPay e1196686810422 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e1196686810426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686810426 : Closed e1196686810426 ∧ code e1196686810426 = 5594733321530 := by decide
theorem cert_e1196686810426 : checkPay e1196686810426 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right],[.left,.right,.left,.left,.left],[.left,.right,.left,.left],[.left,.right,.left],[.left,.right,.left,.left,.right],[.left,.right,.left,.left,.right,.left],[.left,.right,.left,.left,.right],[.left,.right,.left,.right],[.left,.right,.left,.right,.left],[.left,.right,.left,.right],[.right],[.right,.left,.left,.left],[.right,.left,.left],[.right,.left],[.right,.left,.left,.right],[.right,.left,.left,.right,.left],[.right,.left,.left,.right],[.right,.left,.right],[.right,.left,.right,.left],[.right,.left,.right]] = true := by decide
def e1196686810522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1196686810522 : Closed e1196686810522 ∧ code e1196686810522 = 5594733321626 := by decide
theorem cert_e1196686810522 : check e1196686810522 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1196686810566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1196686810566 : Closed e1196686810566 ∧ code e1196686810566 = 5594733321670 := by decide
theorem cert_e1196686810566 : check e1196686810566 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686810678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1196686810678 : Closed e1196686810678 ∧ code e1196686810678 = 5594733321782 := by decide
theorem cert_e1196686810678 : check e1196686810678 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1196686810682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1196686810682 : Closed e1196686810682 ∧ code e1196686810682 = 5594733321786 := by decide
theorem cert_e1196686810682 : check e1196686810682 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e1196686810766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1196686810766 : Closed e1196686810766 ∧ code e1196686810766 = 5594733321870 := by decide
theorem cert_e1196686810766 : checkPay e1196686810766 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686810822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1196686810822 : Closed e1196686810822 ∧ code e1196686810822 = 5594733321926 := by decide
theorem cert_e1196686810822 : check e1196686810822 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686811630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1196686811630 : Closed e1196686811630 ∧ code e1196686811630 = 5594733322734 := by decide
theorem cert_e1196686811630 : checkPay e1196686811630 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1196686812598 : Closed e1196686812598 ∧ code e1196686812598 = 5594733323702 := by decide
theorem cert_e1196686812598 : checkPay e1196686812598 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1196686812630 : Closed e1196686812630 ∧ code e1196686812630 = 5594733323734 := by decide
theorem cert_e1196686812630 : checkPay e1196686812630 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1196686812634 : Closed e1196686812634 ∧ code e1196686812634 = 5594733323738 := by decide
theorem cert_e1196686812634 : checkPay e1196686812634 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1196686812790 : Closed e1196686812790 ∧ code e1196686812790 = 5594733323894 := by decide
theorem cert_e1196686812790 : checkPay e1196686812790 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1196686812958 : Closed e1196686812958 ∧ code e1196686812958 = 5594733324062 := by decide
theorem cert_e1196686812958 : checkPay e1196686812958 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686812982 : Closed e1196686812982 ∧ code e1196686812982 = 5594733324086 := by decide
theorem cert_e1196686812982 : checkPay e1196686812982 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686812986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686812986 : Closed e1196686812986 ∧ code e1196686812986 = 5594733324090 := by decide
theorem cert_e1196686812986 : checkPay e1196686812986 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686813070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1196686813070 : Closed e1196686813070 ∧ code e1196686813070 = 5594733324174 := by decide
theorem cert_e1196686813070 : checkPay e1196686813070 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196686815470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1196686815470 : Closed e1196686815470 ∧ code e1196686815470 = 5594733326574 := by decide
theorem cert_e1196686815470 : check e1196686815470 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686815478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1196686815478 : Closed e1196686815478 ∧ code e1196686815478 = 5594733326582 := by decide
theorem cert_e1196686815478 : check e1196686815478 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686815958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1196686815958 : Closed e1196686815958 ∧ code e1196686815958 = 5594733327062 := by decide
theorem cert_e1196686815958 : check e1196686815958 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686815962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1196686815962 : Closed e1196686815962 ∧ code e1196686815962 = 5594733327066 := by decide
theorem cert_e1196686815962 : check e1196686815962 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686815978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1196686815978 : Closed e1196686815978 ∧ code e1196686815978 = 5594733327082 := by decide
theorem cert_e1196686815978 : check e1196686815978 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686816030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1196686816030 : Closed e1196686816030 ∧ code e1196686816030 = 5594733327134 := by decide
theorem cert_e1196686816030 : check e1196686816030 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686816054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686816054 : Closed e1196686816054 ∧ code e1196686816054 = 5594733327158 := by decide
theorem cert_e1196686816054 : check e1196686816054 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686816058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686816058 : Closed e1196686816058 ∧ code e1196686816058 = 5594733327162 := by decide
theorem cert_e1196686816058 : check e1196686816058 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686816154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1196686816154 : Closed e1196686816154 ∧ code e1196686816154 = 5594733327258 := by decide
theorem cert_e1196686816154 : check e1196686816154 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686816198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1196686816198 : Closed e1196686816198 ∧ code e1196686816198 = 5594733327302 := by decide
theorem cert_e1196686816198 : check e1196686816198 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686817678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1196686817678 : Closed e1196686817678 ∧ code e1196686817678 = 5594733328782 := by decide
private def t_e1196686817678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e1196686817678 : ¬ IsSelfInterpreter e1196686817678 :=
  wSource (t := t_e1196686817678) (replay_sound (ps := []) (t := e1196686817678) (by decide)) (by decide)
def e1196686817734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1196686817734 : Closed e1196686817734 ∧ code e1196686817734 = 5594733328838 := by decide
private def t_e1196686817734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e1196686817734 : ¬ IsSelfInterpreter e1196686817734 :=
  wSource (t := t_e1196686817734) (replay_sound (ps := []) (t := e1196686817734) (by decide)) (by decide)
def e1196686858478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1196686858478 : Closed e1196686858478 ∧ code e1196686858478 = 5594733369582 := by decide
theorem cert_e1196686858478 : check e1196686858478 [[],[.left],[]] .chain = true := by decide
def e1196686858486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1196686858486 : Closed e1196686858486 ∧ code e1196686858486 = 5594733369590 := by decide
theorem cert_e1196686858486 : check e1196686858486 [[],[.left],[]] .chain = true := by decide
def e1196686859038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1196686859038 : Closed e1196686859038 ∧ code e1196686859038 = 5594733370142 := by decide
theorem cert_e1196686859038 : check e1196686859038 [[],[.left],[]] .chain = true := by decide
def e1196686859150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1196686859150 : Closed e1196686859150 ∧ code e1196686859150 = 5594733370254 := by decide
theorem cert_e1196686859150 : check e1196686859150 [[],[.left],[]] .chain = true := by decide
def e1196686859374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1196686859374 : Closed e1196686859374 ∧ code e1196686859374 = 5594733370478 := by decide
theorem cert_e1196686859374 : check e1196686859374 [[],[.left],[]] .chain = true := by decide
def e1196686859386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1196686859386 : Closed e1196686859386 ∧ code e1196686859386 = 5594733370490 := by decide
theorem cert_e1196686859386 : check e1196686859386 [[],[.left],[]] .chain = true := by decide
def e1196686859550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1196686859550 : Closed e1196686859550 ∧ code e1196686859550 = 5594733370654 := by decide
theorem cert_e1196686859550 : check e1196686859550 [[],[.left],[]] .chain = true := by decide
def e1196686859718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1196686859718 : Closed e1196686859718 ∧ code e1196686859718 = 5594733370822 := by decide
theorem cert_e1196686859718 : check e1196686859718 [[],[.left],[]] .chain = true := by decide
def e1196686859742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e1196686859742 : Closed e1196686859742 ∧ code e1196686859742 = 5594733370846 := by decide
theorem cert_e1196686859742 : check e1196686859742 [[],[.left],[]] .sourceHead = true := by decide
def e1196686859758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e1196686859758 : Closed e1196686859758 ∧ code e1196686859758 = 5594733370862 := by decide
theorem cert_e1196686859758 : check e1196686859758 [[],[.left],[]] .sourceHead = true := by decide
def e1196686859830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1196686859830 : Closed e1196686859830 ∧ code e1196686859830 = 5594733370934 := by decide
theorem cert_e1196686859830 : check e1196686859830 [[],[.left],[]] .chain = true := by decide
def e1196686859834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1196686859834 : Closed e1196686859834 ∧ code e1196686859834 = 5594733370938 := by decide
theorem cert_e1196686859834 : check e1196686859834 [[],[.left],[]] .chain = true := by decide
def e1196686859918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1196686859918 : Closed e1196686859918 ∧ code e1196686859918 = 5594733371022 := by decide
theorem cert_e1196686859918 : check e1196686859918 [[],[.left],[]] .chain = true := by decide
def e1196686859974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1196686859974 : Closed e1196686859974 ∧ code e1196686859974 = 5594733371078 := by decide
theorem cert_e1196686859974 : check e1196686859974 [[],[.left],[]] .chain = true := by decide
def e1196686859998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e1196686859998 : Closed e1196686859998 ∧ code e1196686859998 = 5594733371102 := by decide
theorem cert_e1196686859998 : check e1196686859998 [[],[.left],[]] .sourceHead = true := by decide
def e1196686860022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e1196686860022 : Closed e1196686860022 ∧ code e1196686860022 = 5594733371126 := by decide
theorem cert_e1196686860022 : check e1196686860022 [[],[.left],[]] .sourceHead = true := by decide
def e1196686860142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1196686860142 : Closed e1196686860142 ∧ code e1196686860142 = 5594733371246 := by decide
theorem cert_e1196686860142 : check e1196686860142 [[],[.left],[]] .sourceHead = true := by decide
def e1196686860150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1196686860150 : Closed e1196686860150 ∧ code e1196686860150 = 5594733371254 := by decide
theorem cert_e1196686860150 : check e1196686860150 [[],[.left],[]] .sourceHead = true := by decide
def e1196686862110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1196686862110 : Closed e1196686862110 ∧ code e1196686862110 = 5594733373214 := by decide
theorem cert_e1196686862110 : check e1196686862110 [[],[.left],[]] .chain = true := by decide
def e1196686862222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1196686862222 : Closed e1196686862222 ∧ code e1196686862222 = 5594733373326 := by decide
theorem cert_e1196686862222 : check e1196686862222 [[],[.left],[]] .chain = true := by decide
def e1196686865182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1196686865182 : Closed e1196686865182 ∧ code e1196686865182 = 5594733376286 := by decide
theorem cert_e1196686865182 : check e1196686865182 [[],[.left],[]] .chain = true := by decide
def e1196686865350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1196686865350 : Closed e1196686865350 ∧ code e1196686865350 = 5594733376454 := by decide
theorem cert_e1196686865350 : check e1196686865350 [[],[.left],[]] .chain = true := by decide
def e1196686865374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1196686865374 : Closed e1196686865374 ∧ code e1196686865374 = 5594733376478 := by decide
theorem cert_e1196686865374 : check e1196686865374 [[],[.left],[]] .sourceHead = true := by decide
def e1196686865390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1196686865390 : Closed e1196686865390 ∧ code e1196686865390 = 5594733376494 := by decide
theorem cert_e1196686865390 : check e1196686865390 [[],[.left],[]] .sourceHead = true := by decide
def e1196686866830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1196686866830 : Closed e1196686866830 ∧ code e1196686866830 = 5594733377934 := by decide
theorem cert_e1196686866830 : check e1196686866830 [[],[.left],[]] .chain = true := by decide
def e1196686866886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1196686866886 : Closed e1196686866886 ∧ code e1196686866886 = 5594733377990 := by decide
theorem cert_e1196686866886 : check e1196686866886 [[],[.left],[]] .chain = true := by decide
def e1196686866910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196686866910 : Closed e1196686866910 ∧ code e1196686866910 = 5594733378014 := by decide
theorem cert_e1196686866910 : check e1196686866910 [[],[.left],[]] .sourceHead = true := by decide
def e1196686866934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196686866934 : Closed e1196686866934 ∧ code e1196686866934 = 5594733378038 := by decide
theorem cert_e1196686866934 : check e1196686866934 [[],[.left],[]] .sourceHead = true := by decide
def e1196686867694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196686867694 : Closed e1196686867694 ∧ code e1196686867694 = 5594733378798 := by decide
theorem cert_e1196686867694 : check e1196686867694 [[],[.left],[]] .sourceHead = true := by decide
def e1196686867702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196686867702 : Closed e1196686867702 ∧ code e1196686867702 = 5594733378806 := by decide
theorem cert_e1196686867702 : check e1196686867702 [[],[.left],[]] .sourceHead = true := by decide
def e1196686924654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1196686924654 : Closed e1196686924654 ∧ code e1196686924654 = 5594733435758 := by decide
theorem cert_e1196686924654 : check e1196686924654 [[],[.left],[]] .sourceHead = true := by decide
def e1196686924662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1196686924662 : Closed e1196686924662 ∧ code e1196686924662 = 5594733435766 := by decide
theorem cert_e1196686924662 : check e1196686924662 [[],[.left],[]] .sourceHead = true := by decide
def e1196686924726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1196686924726 : Closed e1196686924726 ∧ code e1196686924726 = 5594733435830 := by decide
theorem cert_e1196686924726 : check e1196686924726 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196686925166 : Closed e1196686925166 ∧ code e1196686925166 = 5594733436270 := by decide
theorem cert_e1196686925166 : check e1196686925166 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196686925174 : Closed e1196686925174 ∧ code e1196686925174 = 5594733436278 := by decide
theorem cert_e1196686925174 : check e1196686925174 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196686925230 : Closed e1196686925230 ∧ code e1196686925230 = 5594733436334 := by decide
theorem cert_e1196686925230 : check e1196686925230 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196686925242 : Closed e1196686925242 ∧ code e1196686925242 = 5594733436346 := by decide
theorem cert_e1196686925242 : check e1196686925242 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196686925270 : Closed e1196686925270 ∧ code e1196686925270 = 5594733436374 := by decide
theorem cert_e1196686925270 : check e1196686925270 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196686925274 : Closed e1196686925274 ∧ code e1196686925274 = 5594733436378 := by decide
theorem cert_e1196686925274 : check e1196686925274 [[],[.left],[]] .sourceHead = true := by decide
def e1196686925494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1196686925494 : Closed e1196686925494 ∧ code e1196686925494 = 5594733436598 := by decide
theorem cert_e1196686925494 : check e1196686925494 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor42
