import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186856878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e1211186856878 : Closed e1211186856878 ∧ code e1211186856878 = 5609233367982 := by decide
theorem cert_e1211186856878 : check e1211186856878 [[],[]] .smaller = true := by decide
def e1211186856938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e1211186856938 : Closed e1211186856938 ∧ code e1211186856938 = 5609233368042 := by decide
theorem cert_e1211186856938 : check e1211186856938 [[],[]] .smaller = true := by decide
def e1211186857182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186857182 : Closed e1211186857182 ∧ code e1211186857182 = 5609233368286 := by decide
theorem cert_e1211186857182 : check e1211186857182 [[],[]] .three = true := by decide
def e1211186857198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186857198 : Closed e1211186857198 ∧ code e1211186857198 = 5609233368302 := by decide
theorem cert_e1211186857198 : check e1211186857198 [[],[]] .smaller = true := by decide
def e1211186857206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186857206 : Closed e1211186857206 ∧ code e1211186857206 = 5609233368310 := by decide
theorem cert_e1211186857206 : check e1211186857206 [[],[]] .smaller = true := by decide
def e1211186857210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186857210 : Closed e1211186857210 ∧ code e1211186857210 = 5609233368314 := by decide
theorem cert_e1211186857210 : check e1211186857210 [[],[]] .three = true := by decide
def e1211186857534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 4))))))))
theorem wire_e1211186857534 : Closed e1211186857534 ∧ code e1211186857534 = 5609233368638 := by decide
theorem cert_e1211186857534 : check e1211186857534 [[],[]] .three = true := by decide
def e1211186857582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186857582 : Closed e1211186857582 ∧ code e1211186857582 = 5609233368686 := by decide
theorem cert_e1211186857582 : check e1211186857582 [[],[]] .smaller = true := by decide
def e1211186857594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186857594 : Closed e1211186857594 ∧ code e1211186857594 = 5609233368698 := by decide
theorem cert_e1211186857594 : check e1211186857594 [[],[]] .smaller = true := by decide
def e1211186857758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211186857758 : Closed e1211186857758 ∧ code e1211186857758 = 5609233368862 := by decide
theorem cert_e1211186857758 : check e1211186857758 [[],[]] .smaller = true := by decide
def e1211186857870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2))))))))
theorem wire_e1211186857870 : Closed e1211186857870 ∧ code e1211186857870 = 5609233368974 := by decide
theorem cert_e1211186857870 : check e1211186857870 [[],[]] .smaller = true := by decide
def e1211186857882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186857882 : Closed e1211186857882 ∧ code e1211186857882 = 5609233368986 := by decide
theorem cert_e1211186857882 : check e1211186857882 [[],[]] .smaller = true := by decide
def e1211186857926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e1211186857926 : Closed e1211186857926 ∧ code e1211186857926 = 5609233369030 := by decide
theorem cert_e1211186857926 : check e1211186857926 [[],[]] .three = true := by decide
def e1211186857950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 3)))))))
theorem wire_e1211186857950 : Closed e1211186857950 ∧ code e1211186857950 = 5609233369054 := by decide
theorem cert_e1211186857950 : check e1211186857950 [[],[]] .three = true := by decide
def e1211186859102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e1211186859102 : Closed e1211186859102 ∧ code e1211186859102 = 5609233370206 := by decide
theorem cert_e1211186859102 : check e1211186859102 [[],[]] .three = true := by decide
def e1211186859118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211186859118 : Closed e1211186859118 ∧ code e1211186859118 = 5609233370222 := by decide
theorem cert_e1211186859118 : check e1211186859118 [[],[]] .smaller = true := by decide
def e1211186859130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186859130 : Closed e1211186859130 ∧ code e1211186859130 = 5609233370234 := by decide
theorem cert_e1211186859130 : check e1211186859130 [[],[]] .smaller = true := by decide
def e1211186859294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211186859294 : Closed e1211186859294 ∧ code e1211186859294 = 5609233370398 := by decide
theorem cert_e1211186859294 : check e1211186859294 [[],[]] .smaller = true := by decide
def e1211186859462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186859462 : Closed e1211186859462 ∧ code e1211186859462 = 5609233370566 := by decide
theorem cert_e1211186859462 : check e1211186859462 [[],[]] .smaller = true := by decide
def e1211186859486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e1211186859486 : Closed e1211186859486 ∧ code e1211186859486 = 5609233370590 := by decide
theorem cert_e1211186859486 : check e1211186859486 [[],[]] .three = true := by decide
def e1211186859490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211186859490 : Closed e1211186859490 ∧ code e1211186859490 = 5609233370594 := by decide
theorem cert_e1211186859490 : check e1211186859490 [[],[]] .three = true := by decide
def e1211186859502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e1211186859502 : Closed e1211186859502 ∧ code e1211186859502 = 5609233370606 := by decide
theorem cert_e1211186859502 : check e1211186859502 [[],[]] .three = true := by decide
def e1211186859566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211186859566 : Closed e1211186859566 ∧ code e1211186859566 = 5609233370670 := by decide
theorem cert_e1211186859566 : check e1211186859566 [[],[]] .smaller = true := by decide
def e1211186859742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e1211186859742 : Closed e1211186859742 ∧ code e1211186859742 = 5609233370846 := by decide
theorem cert_e1211186859742 : check e1211186859742 [[],[]] .three = true := by decide
def e1211186859746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211186859746 : Closed e1211186859746 ∧ code e1211186859746 = 5609233370850 := by decide
theorem cert_e1211186859746 : check e1211186859746 [[],[]] .smaller = true := by decide
def e1211186859758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211186859758 : Closed e1211186859758 ∧ code e1211186859758 = 5609233370862 := by decide
theorem cert_e1211186859758 : check e1211186859758 [[],[]] .smaller = true := by decide
def e1211186859766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211186859766 : Closed e1211186859766 ∧ code e1211186859766 = 5609233370870 := by decide
theorem cert_e1211186859766 : check e1211186859766 [[],[]] .three = true := by decide
def e1211186859798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186859798 : Closed e1211186859798 ∧ code e1211186859798 = 5609233370902 := by decide
theorem cert_e1211186859798 : check e1211186859798 [[],[]] .smaller = true := by decide
def e1211186859802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211186859802 : Closed e1211186859802 ∧ code e1211186859802 = 5609233370906 := by decide
theorem cert_e1211186859802 : check e1211186859802 [[],[]] .smaller = true := by decide
def e1211186859846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211186859846 : Closed e1211186859846 ∧ code e1211186859846 = 5609233370950 := by decide
theorem cert_e1211186859846 : check e1211186859846 [[],[]] .smaller = true := by decide
def e1211186859870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e1211186859870 : Closed e1211186859870 ∧ code e1211186859870 = 5609233370974 := by decide
theorem cert_e1211186859870 : check e1211186859870 [[],[]] .three = true := by decide
def e1211186859874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186859874 : Closed e1211186859874 ∧ code e1211186859874 = 5609233370978 := by decide
theorem cert_e1211186859874 : check e1211186859874 [[],[]] .smaller = true := by decide
def e1211186859886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211186859886 : Closed e1211186859886 ∧ code e1211186859886 = 5609233370990 := by decide
theorem cert_e1211186859886 : check e1211186859886 [[],[]] .smaller = true := by decide
def e1211186859894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1)))))))
theorem wire_e1211186859894 : Closed e1211186859894 ∧ code e1211186859894 = 5609233370998 := by decide
theorem cert_e1211186859894 : check e1211186859894 [[],[]] .smaller = true := by decide
def e1211186859898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211186859898 : Closed e1211186859898 ∧ code e1211186859898 = 5609233371002 := by decide
theorem cert_e1211186859898 : check e1211186859898 [[],[]] .three = true := by decide
def e1211186859914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186859914 : Closed e1211186859914 ∧ code e1211186859914 = 5609233371018 := by decide
theorem cert_e1211186859914 : check e1211186859914 [[],[]] .three = true := by decide
def e1211186859938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186859938 : Closed e1211186859938 ∧ code e1211186859938 = 5609233371042 := by decide
theorem cert_e1211186859938 : check e1211186859938 [[],[]] .three = true := by decide
def e1211186859950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e1211186859950 : Closed e1211186859950 ∧ code e1211186859950 = 5609233371054 := by decide
theorem cert_e1211186859950 : check e1211186859950 [[],[]] .three = true := by decide
def e1211186859958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211186859958 : Closed e1211186859958 ∧ code e1211186859958 = 5609233371062 := by decide
theorem cert_e1211186859958 : check e1211186859958 [[],[]] .three = true := by decide
def e1211186859962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211186859962 : Closed e1211186859962 ∧ code e1211186859962 = 5609233371066 := by decide
theorem cert_e1211186859962 : check e1211186859962 [[],[]] .three = true := by decide
def e1211186860158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 5)))))))))
theorem wire_e1211186860158 : Closed e1211186860158 ∧ code e1211186860158 = 5609233371262 := by decide
theorem cert_e1211186860158 : check e1211186860158 [[],[]] .three = true := by decide
def e1211186860254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186860254 : Closed e1211186860254 ∧ code e1211186860254 = 5609233371358 := by decide
theorem cert_e1211186860254 : check e1211186860254 [[],[]] .smaller = true := by decide
def e1211186860282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186860282 : Closed e1211186860282 ∧ code e1211186860282 = 5609233371386 := by decide
theorem cert_e1211186860282 : check e1211186860282 [[],[]] .smaller = true := by decide
def e1211186860830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186860830 : Closed e1211186860830 ∧ code e1211186860830 = 5609233371934 := by decide
theorem cert_e1211186860830 : check e1211186860830 [[],[]] .smaller = true := by decide
def e1211186860998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186860998 : Closed e1211186860998 ∧ code e1211186860998 = 5609233372102 := by decide
theorem cert_e1211186860998 : check e1211186860998 [[],[]] .smaller = true := by decide
def e1211186861022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186861022 : Closed e1211186861022 ∧ code e1211186861022 = 5609233372126 := by decide
theorem cert_e1211186861022 : check e1211186861022 [[],[]] .three = true := by decide
def e1211186861026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211186861026 : Closed e1211186861026 ∧ code e1211186861026 = 5609233372130 := by decide
theorem cert_e1211186861026 : check e1211186861026 [[],[]] .three = true := by decide
def e1211186861038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186861038 : Closed e1211186861038 ∧ code e1211186861038 = 5609233372142 := by decide
theorem cert_e1211186861038 : check e1211186861038 [[],[]] .three = true := by decide
def e1211186862142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211186862142 : Closed e1211186862142 ∧ code e1211186862142 = 5609233373246 := by decide
theorem cert_e1211186862142 : check e1211186862142 [[],[]] .smaller = true := by decide
def e1211186862558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186862558 : Closed e1211186862558 ∧ code e1211186862558 = 5609233373662 := by decide
theorem cert_e1211186862558 : check e1211186862558 [[],[]] .three = true := by decide
def e1211186862562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211186862562 : Closed e1211186862562 ∧ code e1211186862562 = 5609233373666 := by decide
theorem cert_e1211186862562 : check e1211186862562 [[],[]] .smaller = true := by decide
def e1211186862574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186862574 : Closed e1211186862574 ∧ code e1211186862574 = 5609233373678 := by decide
theorem cert_e1211186862574 : check e1211186862574 [[],[]] .smaller = true := by decide
def e1211186862582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186862582 : Closed e1211186862582 ∧ code e1211186862582 = 5609233373686 := by decide
theorem cert_e1211186862582 : check e1211186862582 [[],[]] .three = true := by decide
def e1211186863134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186863134 : Closed e1211186863134 ∧ code e1211186863134 = 5609233374238 := by decide
theorem cert_e1211186863134 : check e1211186863134 [[],[]] .smaller = true := by decide
def e1211186863158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186863158 : Closed e1211186863158 ∧ code e1211186863158 = 5609233374262 := by decide
theorem cert_e1211186863158 : check e1211186863158 [[],[]] .smaller = true := by decide
def e1211186863162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186863162 : Closed e1211186863162 ∧ code e1211186863162 = 5609233374266 := by decide
theorem cert_e1211186863162 : check e1211186863162 [[],[]] .smaller = true := by decide
def e1211186863302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186863302 : Closed e1211186863302 ∧ code e1211186863302 = 5609233374406 := by decide
theorem cert_e1211186863302 : check e1211186863302 [[],[]] .smaller = true := by decide
def e1211186863326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186863326 : Closed e1211186863326 ∧ code e1211186863326 = 5609233374430 := by decide
theorem cert_e1211186863326 : check e1211186863326 [[],[]] .three = true := by decide
def e1211186863330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186863330 : Closed e1211186863330 ∧ code e1211186863330 = 5609233374434 := by decide
theorem cert_e1211186863330 : check e1211186863330 [[],[]] .smaller = true := by decide
def e1211186863342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186863342 : Closed e1211186863342 ∧ code e1211186863342 = 5609233374446 := by decide
theorem cert_e1211186863342 : check e1211186863342 [[],[]] .smaller = true := by decide
def e1211186863350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186863350 : Closed e1211186863350 ∧ code e1211186863350 = 5609233374454 := by decide
theorem cert_e1211186863350 : check e1211186863350 [[],[]] .smaller = true := by decide
def e1211186863354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186863354 : Closed e1211186863354 ∧ code e1211186863354 = 5609233374458 := by decide
theorem cert_e1211186863354 : check e1211186863354 [[],[]] .three = true := by decide
def e1211186863630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186863630 : Closed e1211186863630 ∧ code e1211186863630 = 5609233374734 := by decide
theorem cert_e1211186863630 : check e1211186863630 [[],[]] .three = true := by decide
def e1211186863642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186863642 : Closed e1211186863642 ∧ code e1211186863642 = 5609233374746 := by decide
theorem cert_e1211186863642 : check e1211186863642 [[],[]] .three = true := by decide
def e1211186863678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 4))))))))
theorem wire_e1211186863678 : Closed e1211186863678 ∧ code e1211186863678 = 5609233374782 := by decide
theorem cert_e1211186863678 : check e1211186863678 [[],[]] .three = true := by decide
def e1211186863714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186863714 : Closed e1211186863714 ∧ code e1211186863714 = 5609233374818 := by decide
theorem cert_e1211186863714 : check e1211186863714 [[],[]] .three = true := by decide
def e1211186863726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186863726 : Closed e1211186863726 ∧ code e1211186863726 = 5609233374830 := by decide
theorem cert_e1211186863726 : check e1211186863726 [[],[]] .three = true := by decide
def e1211186863734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186863734 : Closed e1211186863734 ∧ code e1211186863734 = 5609233374838 := by decide
theorem cert_e1211186863734 : check e1211186863734 [[],[]] .three = true := by decide
def e1211186863738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186863738 : Closed e1211186863738 ∧ code e1211186863738 = 5609233374842 := by decide
theorem cert_e1211186863738 : check e1211186863738 [[],[]] .three = true := by decide
def e1211186864366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e1211186864366 : Closed e1211186864366 ∧ code e1211186864366 = 5609233375470 := by decide
theorem cert_e1211186864366 : check e1211186864366 [[],[]] .smaller = true := by decide
def e1211186864378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211186864378 : Closed e1211186864378 ∧ code e1211186864378 = 5609233375482 := by decide
theorem cert_e1211186864378 : check e1211186864378 [[],[]] .smaller = true := by decide
def e1211186864750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186864750 : Closed e1211186864750 ∧ code e1211186864750 = 5609233375854 := by decide
theorem cert_e1211186864750 : check e1211186864750 [[],[]] .smaller = true := by decide
def e1211186864762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186864762 : Closed e1211186864762 ∧ code e1211186864762 = 5609233375866 := by decide
theorem cert_e1211186864762 : check e1211186864762 [[],[]] .smaller = true := by decide
def e1211186864926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e1211186864926 : Closed e1211186864926 ∧ code e1211186864926 = 5609233376030 := by decide
theorem cert_e1211186864926 : check e1211186864926 [[],[]] .smaller = true := by decide
def e1211186865094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211186865094 : Closed e1211186865094 ∧ code e1211186865094 = 5609233376198 := by decide
theorem cert_e1211186865094 : check e1211186865094 [[],[]] .smaller = true := by decide
def e1211186865118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e1211186865118 : Closed e1211186865118 ∧ code e1211186865118 = 5609233376222 := by decide
theorem cert_e1211186865118 : check e1211186865118 [[],[]] .three = true := by decide
def e1211186865134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e1211186865134 : Closed e1211186865134 ∧ code e1211186865134 = 5609233376238 := by decide
theorem cert_e1211186865134 : check e1211186865134 [[],[]] .three = true := by decide
def e1211186865710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211186865710 : Closed e1211186865710 ∧ code e1211186865710 = 5609233376814 := by decide
theorem cert_e1211186865710 : check e1211186865710 [[],[]] .smaller = true := by decide
def e1211186865886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e1211186865886 : Closed e1211186865886 ∧ code e1211186865886 = 5609233376990 := by decide
theorem cert_e1211186865886 : check e1211186865886 [[],[]] .three = true := by decide
def e1211186865890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211186865890 : Closed e1211186865890 ∧ code e1211186865890 = 5609233376994 := by decide
theorem cert_e1211186865890 : check e1211186865890 [[],[]] .smaller = true := by decide
def e1211186865902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e1211186865902 : Closed e1211186865902 ∧ code e1211186865902 = 5609233377006 := by decide
theorem cert_e1211186865902 : check e1211186865902 [[],[]] .smaller = true := by decide
def e1211186865910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e1211186865910 : Closed e1211186865910 ∧ code e1211186865910 = 5609233377014 := by decide
theorem cert_e1211186865910 : check e1211186865910 [[],[]] .three = true := by decide
def e1211186866014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e1211186866014 : Closed e1211186866014 ∧ code e1211186866014 = 5609233377118 := by decide
theorem cert_e1211186866014 : check e1211186866014 [[],[]] .three = true := by decide
def e1211186866042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e1211186866042 : Closed e1211186866042 ∧ code e1211186866042 = 5609233377146 := by decide
theorem cert_e1211186866042 : check e1211186866042 [[],[]] .three = true := by decide
def e1211186866058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186866058 : Closed e1211186866058 ∧ code e1211186866058 = 5609233377162 := by decide
theorem cert_e1211186866058 : check e1211186866058 [[],[]] .smaller = true := by decide
def e1211186866082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186866082 : Closed e1211186866082 ∧ code e1211186866082 = 5609233377186 := by decide
theorem cert_e1211186866082 : check e1211186866082 [[],[]] .smaller = true := by decide
def e1211186866094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e1211186866094 : Closed e1211186866094 ∧ code e1211186866094 = 5609233377198 := by decide
theorem cert_e1211186866094 : check e1211186866094 [[],[]] .smaller = true := by decide
def e1211186866106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e1211186866106 : Closed e1211186866106 ∧ code e1211186866106 = 5609233377210 := by decide
theorem cert_e1211186866106 : check e1211186866106 [[],[]] .smaller = true := by decide
def e1211186866134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e1211186866134 : Closed e1211186866134 ∧ code e1211186866134 = 5609233377238 := by decide
theorem cert_e1211186866134 : check e1211186866134 [[],[]] .three = true := by decide
def e1211186866138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e1211186866138 : Closed e1211186866138 ∧ code e1211186866138 = 5609233377242 := by decide
theorem cert_e1211186866138 : check e1211186866138 [[],[]] .three = true := by decide
def e1211186866238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211186866238 : Closed e1211186866238 ∧ code e1211186866238 = 5609233377342 := by decide
theorem cert_e1211186866238 : check e1211186866238 [[],[]] .smaller = true := by decide
def e1211186866654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186866654 : Closed e1211186866654 ∧ code e1211186866654 = 5609233377758 := by decide
theorem cert_e1211186866654 : check e1211186866654 [[],[]] .three = true := by decide
def e1211186866658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211186866658 : Closed e1211186866658 ∧ code e1211186866658 = 5609233377762 := by decide
theorem cert_e1211186866658 : check e1211186866658 [[],[]] .smaller = true := by decide
def e1211186866670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186866670 : Closed e1211186866670 ∧ code e1211186866670 = 5609233377774 := by decide
theorem cert_e1211186866670 : check e1211186866670 [[],[]] .smaller = true := by decide
def e1211186866678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186866678 : Closed e1211186866678 ∧ code e1211186866678 = 5609233377782 := by decide
theorem cert_e1211186866678 : check e1211186866678 [[],[]] .three = true := by decide
def e1211186867422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186867422 : Closed e1211186867422 ∧ code e1211186867422 = 5609233378526 := by decide
theorem cert_e1211186867422 : check e1211186867422 [[],[]] .three = true := by decide
def e1211186867450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186867450 : Closed e1211186867450 ∧ code e1211186867450 = 5609233378554 := by decide
theorem cert_e1211186867450 : check e1211186867450 [[],[]] .three = true := by decide
def e1211186867726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186867726 : Closed e1211186867726 ∧ code e1211186867726 = 5609233378830 := by decide
theorem cert_e1211186867726 : check e1211186867726 [[],[]] .smaller = true := by decide
def e1211186867774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 4))))))))
theorem wire_e1211186867774 : Closed e1211186867774 ∧ code e1211186867774 = 5609233378878 := by decide
theorem cert_e1211186867774 : check e1211186867774 [[],[]] .three = true := by decide
def e1211186867810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186867810 : Closed e1211186867810 ∧ code e1211186867810 = 5609233378914 := by decide
theorem cert_e1211186867810 : check e1211186867810 [[],[]] .smaller = true := by decide
def e1211186867822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186867822 : Closed e1211186867822 ∧ code e1211186867822 = 5609233378926 := by decide
theorem cert_e1211186867822 : check e1211186867822 [[],[]] .smaller = true := by decide
def e1211186867834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186867834 : Closed e1211186867834 ∧ code e1211186867834 = 5609233378938 := by decide
theorem cert_e1211186867834 : check e1211186867834 [[],[]] .smaller = true := by decide
def e1211186867998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.var 3))))))))
theorem wire_e1211186867998 : Closed e1211186867998 ∧ code e1211186867998 = 5609233379102 := by decide
theorem cert_e1211186867998 : check e1211186867998 [[],[]] .three = true := by decide
def e1211186868022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186868022 : Closed e1211186868022 ∧ code e1211186868022 = 5609233379126 := by decide
theorem cert_e1211186868022 : check e1211186868022 [[],[]] .three = true := by decide
def e1211186868026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186868026 : Closed e1211186868026 ∧ code e1211186868026 = 5609233379130 := by decide
theorem cert_e1211186868026 : check e1211186868026 [[],[]] .three = true := by decide
def e1211186868342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e1211186868342 : Closed e1211186868342 ∧ code e1211186868342 = 5609233379446 := by decide
theorem cert_e1211186868342 : check e1211186868342 [[],[]] .smaller = true := by decide
def e1211186868346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211186868346 : Closed e1211186868346 ∧ code e1211186868346 = 5609233379450 := by decide
theorem cert_e1211186868346 : check e1211186868346 [[],[]] .smaller = true := by decide
def e1211186868442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e1211186868442 : Closed e1211186868442 ∧ code e1211186868442 = 5609233379546 := by decide
theorem cert_e1211186868442 : check e1211186868442 [[],[]] .smaller = true := by decide
def e1211186868458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e1211186868458 : Closed e1211186868458 ∧ code e1211186868458 = 5609233379562 := by decide
theorem cert_e1211186868458 : check e1211186868458 [[],[]] .smaller = true := by decide
def e1211186868534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186868534 : Closed e1211186868534 ∧ code e1211186868534 = 5609233379638 := by decide
theorem cert_e1211186868534 : check e1211186868534 [[],[]] .smaller = true := by decide
def e1211186868538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186868538 : Closed e1211186868538 ∧ code e1211186868538 = 5609233379642 := by decide
theorem cert_e1211186868538 : check e1211186868538 [[],[]] .smaller = true := by decide
def e1211186868622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e1211186868622 : Closed e1211186868622 ∧ code e1211186868622 = 5609233379726 := by decide
theorem cert_e1211186868622 : check e1211186868622 [[],[]] .smaller = true := by decide
def e1211186868634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186868634 : Closed e1211186868634 ∧ code e1211186868634 = 5609233379738 := by decide
theorem cert_e1211186868634 : check e1211186868634 [[],[]] .smaller = true := by decide
def e1211186868678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211186868678 : Closed e1211186868678 ∧ code e1211186868678 = 5609233379782 := by decide
theorem cert_e1211186868678 : check e1211186868678 [[],[]] .smaller = true := by decide
def e1211186868702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1211186868702 : Closed e1211186868702 ∧ code e1211186868702 = 5609233379806 := by decide
theorem cert_e1211186868702 : check e1211186868702 [[],[]] .three = true := by decide
def e1211186868726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1211186868726 : Closed e1211186868726 ∧ code e1211186868726 = 5609233379830 := by decide
theorem cert_e1211186868726 : check e1211186868726 [[],[]] .three = true := by decide
def e1211186869014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211186869014 : Closed e1211186869014 ∧ code e1211186869014 = 5609233380118 := by decide
theorem cert_e1211186869014 : check e1211186869014 [[],[]] .smaller = true := by decide
def e1211186869018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211186869018 : Closed e1211186869018 ∧ code e1211186869018 = 5609233380122 := by decide
theorem cert_e1211186869018 : check e1211186869018 [[],[]] .smaller = true := by decide
def e1211186869062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211186869062 : Closed e1211186869062 ∧ code e1211186869062 = 5609233380166 := by decide
theorem cert_e1211186869062 : check e1211186869062 [[],[]] .smaller = true := by decide
def e1211186869086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e1211186869086 : Closed e1211186869086 ∧ code e1211186869086 = 5609233380190 := by decide
theorem cert_e1211186869086 : check e1211186869086 [[],[]] .three = true := by decide
def e1211186869090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211186869090 : Closed e1211186869090 ∧ code e1211186869090 = 5609233380194 := by decide
theorem cert_e1211186869090 : check e1211186869090 [[],[]] .smaller = true := by decide
def e1211186869102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211186869102 : Closed e1211186869102 ∧ code e1211186869102 = 5609233380206 := by decide
theorem cert_e1211186869102 : check e1211186869102 [[],[]] .smaller = true := by decide
def e1211186869110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211186869110 : Closed e1211186869110 ∧ code e1211186869110 = 5609233380214 := by decide
theorem cert_e1211186869110 : check e1211186869110 [[],[]] .smaller = true := by decide
def e1211186869114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e1211186869114 : Closed e1211186869114 ∧ code e1211186869114 = 5609233380218 := by decide
theorem cert_e1211186869114 : check e1211186869114 [[],[]] .three = true := by decide
def e1211186869130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186869130 : Closed e1211186869130 ∧ code e1211186869130 = 5609233380234 := by decide
theorem cert_e1211186869130 : check e1211186869130 [[],[]] .smaller = true := by decide
def e1211186869154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186869154 : Closed e1211186869154 ∧ code e1211186869154 = 5609233380258 := by decide
theorem cert_e1211186869154 : check e1211186869154 [[],[]] .smaller = true := by decide
def e1211186869166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211186869166 : Closed e1211186869166 ∧ code e1211186869166 = 5609233380270 := by decide
theorem cert_e1211186869166 : check e1211186869166 [[],[]] .smaller = true := by decide
def e1211186869178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211186869178 : Closed e1211186869178 ∧ code e1211186869178 = 5609233380282 := by decide
theorem cert_e1211186869178 : check e1211186869178 [[],[]] .smaller = true := by decide
def e1211186869206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211186869206 : Closed e1211186869206 ∧ code e1211186869206 = 5609233380310 := by decide
theorem cert_e1211186869206 : check e1211186869206 [[],[]] .smaller = true := by decide
def e1211186869210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211186869210 : Closed e1211186869210 ∧ code e1211186869210 = 5609233380314 := by decide
theorem cert_e1211186869210 : check e1211186869210 [[],[]] .smaller = true := by decide
def e1211186869226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e1211186869226 : Closed e1211186869226 ∧ code e1211186869226 = 5609233380330 := by decide
theorem cert_e1211186869226 : check e1211186869226 [[],[]] .three = true := by decide
def e1211186869278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186869278 : Closed e1211186869278 ∧ code e1211186869278 = 5609233380382 := by decide
theorem cert_e1211186869278 : check e1211186869278 [[],[]] .smaller = true := by decide
def e1211186869302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186869302 : Closed e1211186869302 ∧ code e1211186869302 = 5609233380406 := by decide
theorem cert_e1211186869302 : check e1211186869302 [[],[]] .smaller = true := by decide
def e1211186869306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186869306 : Closed e1211186869306 ∧ code e1211186869306 = 5609233380410 := by decide
theorem cert_e1211186869306 : check e1211186869306 [[],[]] .smaller = true := by decide
def e1211186869446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186869446 : Closed e1211186869446 ∧ code e1211186869446 = 5609233380550 := by decide
theorem cert_e1211186869446 : check e1211186869446 [[],[]] .smaller = true := by decide
def e1211186869470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186869470 : Closed e1211186869470 ∧ code e1211186869470 = 5609233380574 := by decide
theorem cert_e1211186869470 : check e1211186869470 [[],[]] .three = true := by decide
def e1211186869474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186869474 : Closed e1211186869474 ∧ code e1211186869474 = 5609233380578 := by decide
theorem cert_e1211186869474 : check e1211186869474 [[],[]] .smaller = true := by decide
def e1211186869486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186869486 : Closed e1211186869486 ∧ code e1211186869486 = 5609233380590 := by decide
theorem cert_e1211186869486 : check e1211186869486 [[],[]] .smaller = true := by decide
def e1211186869494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186869494 : Closed e1211186869494 ∧ code e1211186869494 = 5609233380598 := by decide
theorem cert_e1211186869494 : check e1211186869494 [[],[]] .smaller = true := by decide
def e1211186869498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186869498 : Closed e1211186869498 ∧ code e1211186869498 = 5609233380602 := by decide
theorem cert_e1211186869498 : check e1211186869498 [[],[]] .three = true := by decide
def e1211186869774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186869774 : Closed e1211186869774 ∧ code e1211186869774 = 5609233380878 := by decide
theorem cert_e1211186869774 : check e1211186869774 [[],[]] .smaller = true := by decide
def e1211186869822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 4))))))))
theorem wire_e1211186869822 : Closed e1211186869822 ∧ code e1211186869822 = 5609233380926 := by decide
theorem cert_e1211186869822 : check e1211186869822 [[],[]] .three = true := by decide
def e1211186869858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186869858 : Closed e1211186869858 ∧ code e1211186869858 = 5609233380962 := by decide
theorem cert_e1211186869858 : check e1211186869858 [[],[]] .smaller = true := by decide
def e1211186869870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186869870 : Closed e1211186869870 ∧ code e1211186869870 = 5609233380974 := by decide
theorem cert_e1211186869870 : check e1211186869870 [[],[]] .smaller = true := by decide
def e1211186869882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186869882 : Closed e1211186869882 ∧ code e1211186869882 = 5609233380986 := by decide
theorem cert_e1211186869882 : check e1211186869882 [[],[]] .smaller = true := by decide
def e1211186870070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186870070 : Closed e1211186870070 ∧ code e1211186870070 = 5609233381174 := by decide
theorem cert_e1211186870070 : check e1211186870070 [[],[]] .smaller = true := by decide
def e1211186870074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186870074 : Closed e1211186870074 ∧ code e1211186870074 = 5609233381178 := by decide
theorem cert_e1211186870074 : check e1211186870074 [[],[]] .smaller = true := by decide
def e1211186870158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.lam (.var 2))))))))
theorem wire_e1211186870158 : Closed e1211186870158 ∧ code e1211186870158 = 5609233381262 := by decide
theorem cert_e1211186870158 : check e1211186870158 [[],[]] .three = true := by decide
def e1211186870170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186870170 : Closed e1211186870170 ∧ code e1211186870170 = 5609233381274 := by decide
theorem cert_e1211186870170 : check e1211186870170 [[],[]] .three = true := by decide
def e1211186870330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211186870330 : Closed e1211186870330 ∧ code e1211186870330 = 5609233381434 := by decide
theorem cert_e1211186870330 : check e1211186870330 [[],[]] .three = true := by decide
def e1211186870378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e1211186870378 : Closed e1211186870378 ∧ code e1211186870378 = 5609233381482 := by decide
theorem cert_e1211186870378 : check e1211186870378 [[],[]] .three = true := by decide
def e1211186870426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186870426 : Closed e1211186870426 ∧ code e1211186870426 = 5609233381530 := by decide
theorem cert_e1211186870426 : check e1211186870426 [[],[]] .three = true := by decide
def e1211186870470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211186870470 : Closed e1211186870470 ∧ code e1211186870470 = 5609233381574 := by decide
theorem cert_e1211186870470 : check e1211186870470 [[],[]] .three = true := by decide
def e1211186870494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e1211186870494 : Closed e1211186870494 ∧ code e1211186870494 = 5609233381598 := by decide
theorem cert_e1211186870494 : check e1211186870494 [[],[]] .three = true := by decide
def e1211186870510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211186870510 : Closed e1211186870510 ∧ code e1211186870510 = 5609233381614 := by decide
theorem cert_e1211186870510 : check e1211186870510 [[],[]] .three = true := by decide
def e1211186870518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211186870518 : Closed e1211186870518 ∧ code e1211186870518 = 5609233381622 := by decide
theorem cert_e1211186870518 : check e1211186870518 [[],[]] .three = true := by decide
def e1211186870522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e1211186870522 : Closed e1211186870522 ∧ code e1211186870522 = 5609233381626 := by decide
theorem cert_e1211186870522 : check e1211186870522 [[],[]] .three = true := by decide
def e1211186870666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211186870666 : Closed e1211186870666 ∧ code e1211186870666 = 5609233381770 := by decide
theorem cert_e1211186870666 : check e1211186870666 [[],[]] .three = true := by decide
def e1211186870690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e1211186870690 : Closed e1211186870690 ∧ code e1211186870690 = 5609233381794 := by decide
theorem cert_e1211186870690 : check e1211186870690 [[],[]] .three = true := by decide
def e1211186870702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211186870702 : Closed e1211186870702 ∧ code e1211186870702 = 5609233381806 := by decide
theorem cert_e1211186870702 : check e1211186870702 [[],[]] .three = true := by decide
end Blc.Floor42
