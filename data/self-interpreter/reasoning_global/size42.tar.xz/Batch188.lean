import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203699098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203699098 : Closed e1211203699098 ∧ code e1211203699098 = 5609250210202 := by decide
theorem cert_e1211203699098 : check e1211203699098 [[],[]] .chain = true := by decide
def e1211203699142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211203699142 : Closed e1211203699142 ∧ code e1211203699142 = 5609250210246 := by decide
theorem cert_e1211203699142 : check e1211203699142 [[],[]] .chain = true := by decide
def e1211203699482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203699482 : Closed e1211203699482 ∧ code e1211203699482 = 5609250210586 := by decide
theorem cert_e1211203699482 : check e1211203699482 [[],[]] .sourceHead = true := by decide
def e1211203699526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203699526 : Closed e1211203699526 ∧ code e1211203699526 = 5609250210630 := by decide
theorem cert_e1211203699526 : check e1211203699526 [[],[]] .sourceHead = true := by decide
def e1211203699566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211203699566 : Closed e1211203699566 ∧ code e1211203699566 = 5609250210670 := by decide
theorem cert_e1211203699566 : check e1211203699566 [[],[]] .sourceHead = true := by decide
def e1211203699578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e1211203699578 : Closed e1211203699578 ∧ code e1211203699578 = 5609250210682 := by decide
theorem cert_e1211203699578 : check e1211203699578 [[],[]] .sourceHead = true := by decide
def e1211203699594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203699594 : Closed e1211203699594 ∧ code e1211203699594 = 5609250210698 := by decide
theorem cert_e1211203699594 : check e1211203699594 [[],[]] .chain = true := by decide
def e1211203699630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211203699630 : Closed e1211203699630 ∧ code e1211203699630 = 5609250210734 := by decide
theorem cert_e1211203699630 : check e1211203699630 [[],[]] .sourceHead = true := by decide
def e1211203699638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e1211203699638 : Closed e1211203699638 ∧ code e1211203699638 = 5609250210742 := by decide
theorem cert_e1211203699638 : check e1211203699638 [[],[]] .chain = true := by decide
def e1211203699642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211203699642 : Closed e1211203699642 ∧ code e1211203699642 = 5609250210746 := by decide
theorem cert_e1211203699642 : check e1211203699642 [[],[]] .chain = true := by decide
def e1211203699674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211203699674 : Closed e1211203699674 ∧ code e1211203699674 = 5609250210778 := by decide
theorem cert_e1211203699674 : check e1211203699674 [[],[]] .chain = true := by decide
def e1211203699690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e1211203699690 : Closed e1211203699690 ∧ code e1211203699690 = 5609250210794 := by decide
theorem cert_e1211203699690 : check e1211203699690 [[],[]] .sourceHead = true := by decide
def e1211203699910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203699910 : Closed e1211203699910 ∧ code e1211203699910 = 5609250211014 := by decide
theorem cert_e1211203699910 : check e1211203699910 [[],[]] .chain = true := by decide
def e1211203700238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e1211203700238 : Closed e1211203700238 ∧ code e1211203700238 = 5609250211342 := by decide
theorem cert_e1211203700238 : check e1211203700238 [[],[]] .chain = true := by decide
def e1211203700250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203700250 : Closed e1211203700250 ∧ code e1211203700250 = 5609250211354 := by decide
theorem cert_e1211203700250 : check e1211203700250 [[],[]] .sourceHead = true := by decide
def e1211203700322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203700322 : Closed e1211203700322 ∧ code e1211203700322 = 5609250211426 := by decide
theorem cert_e1211203700322 : check e1211203700322 [[],[]] .chain = true := by decide
def e1211203700334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203700334 : Closed e1211203700334 ∧ code e1211203700334 = 5609250211438 := by decide
theorem cert_e1211203700334 : check e1211203700334 [[],[]] .sourceHead = true := by decide
def e1211203700342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203700342 : Closed e1211203700342 ∧ code e1211203700342 = 5609250211446 := by decide
theorem cert_e1211203700342 : check e1211203700342 [[],[]] .chain = true := by decide
def e1211203700346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203700346 : Closed e1211203700346 ∧ code e1211203700346 = 5609250211450 := by decide
theorem cert_e1211203700346 : check e1211203700346 [[],[]] .sourceHead = true := by decide
def e1211203700534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203700534 : Closed e1211203700534 ∧ code e1211203700534 = 5609250211638 := by decide
theorem cert_e1211203700534 : check e1211203700534 [[],[]] .chain = true := by decide
def e1211203700538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203700538 : Closed e1211203700538 ∧ code e1211203700538 = 5609250211642 := by decide
theorem cert_e1211203700538 : check e1211203700538 [[],[]] .chain = true := by decide
def e1211203700634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203700634 : Closed e1211203700634 ∧ code e1211203700634 = 5609250211738 := by decide
theorem cert_e1211203700634 : check e1211203700634 [[],[]] .sourceHead = true := by decide
def e1211203701590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211203701590 : Closed e1211203701590 ∧ code e1211203701590 = 5609250212694 := by decide
theorem cert_e1211203701590 : check e1211203701590 [[],[]] .chain = true := by decide
def e1211203701594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211203701594 : Closed e1211203701594 ∧ code e1211203701594 = 5609250212698 := by decide
theorem cert_e1211203701594 : check e1211203701594 [[],[]] .chain = true := by decide
def e1211203701610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211203701610 : Closed e1211203701610 ∧ code e1211203701610 = 5609250212714 := by decide
theorem cert_e1211203701610 : check e1211203701610 [[],[]] .chain = true := by decide
def e1211203701674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e1211203701674 : Closed e1211203701674 ∧ code e1211203701674 = 5609250212778 := by decide
theorem cert_e1211203701674 : check e1211203701674 [[],[]] .chain = true := by decide
def e1211203701782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203701782 : Closed e1211203701782 ∧ code e1211203701782 = 5609250212886 := by decide
theorem cert_e1211203701782 : check e1211203701782 [[],[]] .chain = true := by decide
def e1211203701786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203701786 : Closed e1211203701786 ∧ code e1211203701786 = 5609250212890 := by decide
theorem cert_e1211203701786 : check e1211203701786 [[],[]] .chain = true := by decide
def e1211203701830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203701830 : Closed e1211203701830 ∧ code e1211203701830 = 5609250212934 := by decide
theorem cert_e1211203701830 : check e1211203701830 [[],[]] .chain = true := by decide
def e1211203701858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203701858 : Closed e1211203701858 ∧ code e1211203701858 = 5609250212962 := by decide
theorem cert_e1211203701858 : check e1211203701858 [[],[]] .chain = true := by decide
def e1211203701870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203701870 : Closed e1211203701870 ∧ code e1211203701870 = 5609250212974 := by decide
theorem cert_e1211203701870 : check e1211203701870 [[],[]] .sourceHead = true := by decide
def e1211203701878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203701878 : Closed e1211203701878 ∧ code e1211203701878 = 5609250212982 := by decide
theorem cert_e1211203701878 : check e1211203701878 [[],[]] .chain = true := by decide
def e1211203701882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203701882 : Closed e1211203701882 ∧ code e1211203701882 = 5609250212986 := by decide
theorem cert_e1211203701882 : check e1211203701882 [[],[]] .sourceHead = true := by decide
def e1211203701974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203701974 : Closed e1211203701974 ∧ code e1211203701974 = 5609250213078 := by decide
theorem cert_e1211203701974 : check e1211203701974 [[],[]] .chain = true := by decide
def e1211203701978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211203701978 : Closed e1211203701978 ∧ code e1211203701978 = 5609250213082 := by decide
theorem cert_e1211203701978 : check e1211203701978 [[],[]] .chain = true := by decide
def e1211203701994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211203701994 : Closed e1211203701994 ∧ code e1211203701994 = 5609250213098 := by decide
theorem cert_e1211203701994 : check e1211203701994 [[],[]] .chain = true := by decide
def e1211203702022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203702022 : Closed e1211203702022 ∧ code e1211203702022 = 5609250213126 := by decide
theorem cert_e1211203702022 : check e1211203702022 [[],[]] .chain = true := by decide
def e1211203702046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203702046 : Closed e1211203702046 ∧ code e1211203702046 = 5609250213150 := by decide
theorem cert_e1211203702046 : check e1211203702046 [[],[]] .sourceHead = true := by decide
def e1211203702070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203702070 : Closed e1211203702070 ∧ code e1211203702070 = 5609250213174 := by decide
theorem cert_e1211203702070 : check e1211203702070 [[],[]] .chain = true := by decide
def e1211203702074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203702074 : Closed e1211203702074 ∧ code e1211203702074 = 5609250213178 := by decide
theorem cert_e1211203702074 : check e1211203702074 [[],[]] .chain = true := by decide
def e1211203702146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203702146 : Closed e1211203702146 ∧ code e1211203702146 = 5609250213250 := by decide
theorem cert_e1211203702146 : check e1211203702146 [[],[]] .chain = true := by decide
def e1211203702158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203702158 : Closed e1211203702158 ∧ code e1211203702158 = 5609250213262 := by decide
theorem cert_e1211203702158 : check e1211203702158 [[],[]] .chain = true := by decide
def e1211203702170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203702170 : Closed e1211203702170 ∧ code e1211203702170 = 5609250213274 := by decide
theorem cert_e1211203702170 : check e1211203702170 [[],[]] .chain = true := by decide
def e1211203702214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203702214 : Closed e1211203702214 ∧ code e1211203702214 = 5609250213318 := by decide
theorem cert_e1211203702214 : check e1211203702214 [[],[]] .sourceHead = true := by decide
def e1211203702282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203702282 : Closed e1211203702282 ∧ code e1211203702282 = 5609250213386 := by decide
theorem cert_e1211203702282 : check e1211203702282 [[],[]] .chain = true := by decide
def e1211203702326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203702326 : Closed e1211203702326 ∧ code e1211203702326 = 5609250213430 := by decide
theorem cert_e1211203702326 : check e1211203702326 [[],[]] .chain = true := by decide
def e1211203702330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203702330 : Closed e1211203702330 ∧ code e1211203702330 = 5609250213434 := by decide
theorem cert_e1211203702330 : check e1211203702330 [[],[]] .chain = true := by decide
def e1211203702378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211203702378 : Closed e1211203702378 ∧ code e1211203702378 = 5609250213482 := by decide
theorem cert_e1211203702378 : check e1211203702378 [[],[]] .chain = true := by decide
def e1211203702402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203702402 : Closed e1211203702402 ∧ code e1211203702402 = 5609250213506 := by decide
theorem cert_e1211203702402 : check e1211203702402 [[],[]] .chain = true := by decide
def e1211203702414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203702414 : Closed e1211203702414 ∧ code e1211203702414 = 5609250213518 := by decide
theorem cert_e1211203702414 : check e1211203702414 [[],[]] .chain = true := by decide
def e1211203702426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203702426 : Closed e1211203702426 ∧ code e1211203702426 = 5609250213530 := by decide
theorem cert_e1211203702426 : check e1211203702426 [[],[]] .chain = true := by decide
def e1211203702470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203702470 : Closed e1211203702470 ∧ code e1211203702470 = 5609250213574 := by decide
theorem cert_e1211203702470 : check e1211203702470 [[],[]] .chain = true := by decide
def e1211203702554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203702554 : Closed e1211203702554 ∧ code e1211203702554 = 5609250213658 := by decide
theorem cert_e1211203702554 : check e1211203702554 [[],[]] .sourceHead = true := by decide
def e1211203702598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203702598 : Closed e1211203702598 ∧ code e1211203702598 = 5609250213702 := by decide
theorem cert_e1211203702598 : check e1211203702598 [[],[]] .sourceHead = true := by decide
def e1211203702814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211203702814 : Closed e1211203702814 ∧ code e1211203702814 = 5609250213918 := by decide
theorem cert_e1211203702814 : check e1211203702814 [[],[]] .chain = true := by decide
def e1211203702982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211203702982 : Closed e1211203702982 ∧ code e1211203702982 = 5609250214086 := by decide
theorem cert_e1211203702982 : check e1211203702982 [[],[]] .sourceHead = true := by decide
def e1211203703006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211203703006 : Closed e1211203703006 ∧ code e1211203703006 = 5609250214110 := by decide
theorem cert_e1211203703006 : check e1211203703006 [[],[]] .sourceHead = true := by decide
def e1211203703010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211203703010 : Closed e1211203703010 ∧ code e1211203703010 = 5609250214114 := by decide
theorem cert_e1211203703010 : check e1211203703010 [[],[]] .chain = true := by decide
def e1211203703022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211203703022 : Closed e1211203703022 ∧ code e1211203703022 = 5609250214126 := by decide
theorem cert_e1211203703022 : check e1211203703022 [[],[]] .chain = true := by decide
def e1211203703030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211203703030 : Closed e1211203703030 ∧ code e1211203703030 = 5609250214134 := by decide
theorem cert_e1211203703030 : check e1211203703030 [[],[]] .chain = true := by decide
def e1211203703034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211203703034 : Closed e1211203703034 ∧ code e1211203703034 = 5609250214138 := by decide
theorem cert_e1211203703034 : check e1211203703034 [[],[]] .sourceHead = true := by decide
def e1211203703510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211203703510 : Closed e1211203703510 ∧ code e1211203703510 = 5609250214614 := by decide
theorem cert_e1211203703510 : check e1211203703510 [[],[]] .chain = true := by decide
def e1211203703514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211203703514 : Closed e1211203703514 ∧ code e1211203703514 = 5609250214618 := by decide
theorem cert_e1211203703514 : check e1211203703514 [[],[]] .chain = true := by decide
def e1211203703530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211203703530 : Closed e1211203703530 ∧ code e1211203703530 = 5609250214634 := by decide
theorem cert_e1211203703530 : check e1211203703530 [[],[]] .chain = true := by decide
def e1211203703558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203703558 : Closed e1211203703558 ∧ code e1211203703558 = 5609250214662 := by decide
theorem cert_e1211203703558 : check e1211203703558 [[],[]] .chain = true := by decide
def e1211203703582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203703582 : Closed e1211203703582 ∧ code e1211203703582 = 5609250214686 := by decide
theorem cert_e1211203703582 : check e1211203703582 [[],[]] .sourceHead = true := by decide
def e1211203703606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203703606 : Closed e1211203703606 ∧ code e1211203703606 = 5609250214710 := by decide
theorem cert_e1211203703606 : check e1211203703606 [[],[]] .chain = true := by decide
def e1211203703610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203703610 : Closed e1211203703610 ∧ code e1211203703610 = 5609250214714 := by decide
theorem cert_e1211203703610 : check e1211203703610 [[],[]] .chain = true := by decide
def e1211203703682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203703682 : Closed e1211203703682 ∧ code e1211203703682 = 5609250214786 := by decide
theorem cert_e1211203703682 : check e1211203703682 [[],[]] .chain = true := by decide
def e1211203703694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211203703694 : Closed e1211203703694 ∧ code e1211203703694 = 5609250214798 := by decide
theorem cert_e1211203703694 : check e1211203703694 [[],[]] .chain = true := by decide
def e1211203703706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203703706 : Closed e1211203703706 ∧ code e1211203703706 = 5609250214810 := by decide
theorem cert_e1211203703706 : check e1211203703706 [[],[]] .chain = true := by decide
def e1211203703750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203703750 : Closed e1211203703750 ∧ code e1211203703750 = 5609250214854 := by decide
theorem cert_e1211203703750 : check e1211203703750 [[],[]] .sourceHead = true := by decide
def e1211203704950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e1211203704950 : Closed e1211203704950 ∧ code e1211203704950 = 5609250216054 := by decide
theorem cert_e1211203704950 : check e1211203704950 [[],[]] .chain = true := by decide
def e1211203705194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e1211203705194 : Closed e1211203705194 ∧ code e1211203705194 = 5609250216298 := by decide
theorem cert_e1211203705194 : check e1211203705194 [[],[]] .chain = true := by decide
def e1211203705218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203705218 : Closed e1211203705218 ∧ code e1211203705218 = 5609250216322 := by decide
theorem cert_e1211203705218 : check e1211203705218 [[],[]] .chain = true := by decide
def e1211203705230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203705230 : Closed e1211203705230 ∧ code e1211203705230 = 5609250216334 := by decide
theorem cert_e1211203705230 : check e1211203705230 [[],[]] .chain = true := by decide
def e1211203705242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203705242 : Closed e1211203705242 ∧ code e1211203705242 = 5609250216346 := by decide
theorem cert_e1211203705242 : check e1211203705242 [[],[]] .chain = true := by decide
def e1211203705286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203705286 : Closed e1211203705286 ∧ code e1211203705286 = 5609250216390 := by decide
theorem cert_e1211203705286 : check e1211203705286 [[],[]] .chain = true := by decide
def e1211203705910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e1211203705910 : Closed e1211203705910 ∧ code e1211203705910 = 5609250217014 := by decide
theorem cert_e1211203705910 : check e1211203705910 [[],[]] .sourceHead = true := by decide
def e1211203705914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e1211203705914 : Closed e1211203705914 ∧ code e1211203705914 = 5609250217018 := by decide
theorem cert_e1211203705914 : check e1211203705914 [[],[]] .sourceHead = true := by decide
def e1211203706054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203706054 : Closed e1211203706054 ∧ code e1211203706054 = 5609250217158 := by decide
theorem cert_e1211203706054 : check e1211203706054 [[],[]] .sourceHead = true := by decide
def e1211203716054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.var 1))))))
theorem wire_e1211203716054 : Closed e1211203716054 ∧ code e1211203716054 = 5609250227158 := by decide
theorem cert_e1211203716054 : check e1211203716054 [[],[]] .chain = true := by decide
def e1211203716058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 1)) (.var 0))))))
theorem wire_e1211203716058 : Closed e1211203716058 ∧ code e1211203716058 = 5609250227162 := by decide
theorem cert_e1211203716058 : check e1211203716058 [[],[]] .chain = true := by decide
def e1211203716074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.var 0)) (.var 0))))))
theorem wire_e1211203716074 : Closed e1211203716074 ∧ code e1211203716074 = 5609250227178 := by decide
theorem cert_e1211203716074 : check e1211203716074 [[],[]] .chain = true := by decide
def e1211203717558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203717558 : Closed e1211203717558 ∧ code e1211203717558 = 5609250228662 := by decide
theorem cert_e1211203717558 : check e1211203717558 [[],[]] .chain = true := by decide
def e1211203717590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203717590 : Closed e1211203717590 ∧ code e1211203717590 = 5609250228694 := by decide
theorem cert_e1211203717590 : check e1211203717590 [[],[]] .chain = true := by decide
def e1211203717594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203717594 : Closed e1211203717594 ∧ code e1211203717594 = 5609250228698 := by decide
theorem cert_e1211203717594 : check e1211203717594 [[],[]] .chain = true := by decide
def e1211203717750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203717750 : Closed e1211203717750 ∧ code e1211203717750 = 5609250228854 := by decide
theorem cert_e1211203717750 : check e1211203717750 [[],[]] .chain = true := by decide
def e1211203717942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203717942 : Closed e1211203717942 ∧ code e1211203717942 = 5609250229046 := by decide
theorem cert_e1211203717942 : check e1211203717942 [[],[]] .chain = true := by decide
def e1211203717946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203717946 : Closed e1211203717946 ∧ code e1211203717946 = 5609250229050 := by decide
theorem cert_e1211203717946 : check e1211203717946 [[],[]] .chain = true := by decide
def e1211203718358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203718358 : Closed e1211203718358 ∧ code e1211203718358 = 5609250229462 := by decide
theorem cert_e1211203718358 : check e1211203718358 [[],[]] .chain = true := by decide
def e1211203718362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203718362 : Closed e1211203718362 ∧ code e1211203718362 = 5609250229466 := by decide
theorem cert_e1211203718362 : check e1211203718362 [[],[]] .chain = true := by decide
def e1211203718378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203718378 : Closed e1211203718378 ∧ code e1211203718378 = 5609250229482 := by decide
theorem cert_e1211203718378 : check e1211203718378 [[],[]] .chain = true := by decide
def e1211203718454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203718454 : Closed e1211203718454 ∧ code e1211203718454 = 5609250229558 := by decide
theorem cert_e1211203718454 : check e1211203718454 [[],[]] .chain = true := by decide
def e1211203718458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203718458 : Closed e1211203718458 ∧ code e1211203718458 = 5609250229562 := by decide
theorem cert_e1211203718458 : check e1211203718458 [[],[]] .chain = true := by decide
def e1211203718554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203718554 : Closed e1211203718554 ∧ code e1211203718554 = 5609250229658 := by decide
theorem cert_e1211203718554 : check e1211203718554 [[],[]] .chain = true := by decide
def e1211203718710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203718710 : Closed e1211203718710 ∧ code e1211203718710 = 5609250229814 := by decide
theorem cert_e1211203718710 : check e1211203718710 [[],[]] .chain = true := by decide
def e1211203718714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203718714 : Closed e1211203718714 ∧ code e1211203718714 = 5609250229818 := by decide
theorem cert_e1211203718714 : check e1211203718714 [[],[]] .chain = true := by decide
def e1211203718798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203718798 : Closed e1211203718798 ∧ code e1211203718798 = 5609250229902 := by decide
theorem cert_e1211203718798 : check e1211203718798 [[],[]] .chain = true := by decide
def e1211203718854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203718854 : Closed e1211203718854 ∧ code e1211203718854 = 5609250229958 := by decide
theorem cert_e1211203718854 : check e1211203718854 [[],[]] .chain = true := by decide
def e1211203718938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203718938 : Closed e1211203718938 ∧ code e1211203718938 = 5609250230042 := by decide
theorem cert_e1211203718938 : check e1211203718938 [[],[]] .chain = true := by decide
def e1211203718982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203718982 : Closed e1211203718982 ∧ code e1211203718982 = 5609250230086 := by decide
theorem cert_e1211203718982 : check e1211203718982 [[],[]] .chain = true := by decide
def e1211203721430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e1211203721430 : Closed e1211203721430 ∧ code e1211203721430 = 5609250232534 := by decide
theorem cert_e1211203721430 : check e1211203721430 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203721434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e1211203721434 : Closed e1211203721434 ∧ code e1211203721434 = 5609250232538 := by decide
theorem cert_e1211203721434 : check e1211203721434 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203721782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203721782 : Closed e1211203721782 ∧ code e1211203721782 = 5609250232886 := by decide
private def t_e1211203721782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem cert_e1211203721782 : ¬ IsSelfInterpreter e1211203721782 :=
  wSource (t := t_e1211203721782) (replay_sound (ps := []) (t := e1211203721782) (by decide)) (by decide)
def e1211203721786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203721786 : Closed e1211203721786 ∧ code e1211203721786 = 5609250232890 := by decide
private def t_e1211203721786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem cert_e1211203721786 : ¬ IsSelfInterpreter e1211203721786 :=
  wSource (t := t_e1211203721786) (replay_sound (ps := []) (t := e1211203721786) (by decide)) (by decide)
def e1211203721870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203721870 : Closed e1211203721870 ∧ code e1211203721870 = 5609250232974 := by decide
private def t_e1211203721870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem cert_e1211203721870 : ¬ IsSelfInterpreter e1211203721870 :=
  wSource (t := t_e1211203721870) (replay_sound (ps := []) (t := e1211203721870) (by decide)) (by decide)
def e1211203721926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203721926 : Closed e1211203721926 ∧ code e1211203721926 = 5609250233030 := by decide
private def t_e1211203721926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem cert_e1211203721926 : ¬ IsSelfInterpreter e1211203721926 :=
  wSource (t := t_e1211203721926) (replay_sound (ps := []) (t := e1211203721926) (by decide)) (by decide)
def e1211203722094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203722094 : Closed e1211203722094 ∧ code e1211203722094 = 5609250233198 := by decide
theorem cert_e1211203722094 : check e1211203722094 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203722102 : Closed e1211203722102 ∧ code e1211203722102 = 5609250233206 := by decide
theorem cert_e1211203722102 : check e1211203722102 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1211203722158 : Closed e1211203722158 ∧ code e1211203722158 = 5609250233262 := by decide
theorem cert_e1211203722158 : check e1211203722158 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1211203722170 : Closed e1211203722170 ∧ code e1211203722170 = 5609250233274 := by decide
theorem cert_e1211203722170 : check e1211203722170 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e1211203722198 : Closed e1211203722198 ∧ code e1211203722198 = 5609250233302 := by decide
private def t_e1211203722198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1))))))
theorem cert_e1211203722198 : ¬ IsSelfInterpreter e1211203722198 :=
  wSource (t := t_e1211203722198) (replay_sound (ps := []) (t := e1211203722198) (by decide)) (by decide)
def e1211203722202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e1211203722202 : Closed e1211203722202 ∧ code e1211203722202 = 5609250233306 := by decide
private def t_e1211203722202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0))))))
theorem cert_e1211203722202 : ¬ IsSelfInterpreter e1211203722202 :=
  wSource (t := t_e1211203722202) (replay_sound (ps := []) (t := e1211203722202) (by decide)) (by decide)
def e1211203722326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e1211203722326 : Closed e1211203722326 ∧ code e1211203722326 = 5609250233430 := by decide
theorem cert_e1211203722326 : check e1211203722326 [[],[]] .chain = true := by decide
def e1211203722330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e1211203722330 : Closed e1211203722330 ∧ code e1211203722330 = 5609250233434 := by decide
theorem cert_e1211203722330 : check e1211203722330 [[],[]] .chain = true := by decide
def e1211203722606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203722606 : Closed e1211203722606 ∧ code e1211203722606 = 5609250233710 := by decide
theorem cert_e1211203722606 : check e1211203722606 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203722614 : Closed e1211203722614 ∧ code e1211203722614 = 5609250233718 := by decide
theorem cert_e1211203722614 : check e1211203722614 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e1211203722678 : Closed e1211203722678 ∧ code e1211203722678 = 5609250233782 := by decide
theorem cert_e1211203722678 : check e1211203722678 [[],[]] .chain = true := by decide
def e1211203722710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203722710 : Closed e1211203722710 ∧ code e1211203722710 = 5609250233814 := by decide
theorem cert_e1211203722710 : check e1211203722710 [[],[]] .chain = true := by decide
def e1211203722714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203722714 : Closed e1211203722714 ∧ code e1211203722714 = 5609250233818 := by decide
theorem cert_e1211203722714 : check e1211203722714 [[],[]] .chain = true := by decide
def e1211203722794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e1211203722794 : Closed e1211203722794 ∧ code e1211203722794 = 5609250233898 := by decide
theorem cert_e1211203722794 : check e1211203722794 [[],[]] .chain = true := by decide
def e1211203722926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1211203722926 : Closed e1211203722926 ∧ code e1211203722926 = 5609250234030 := by decide
theorem cert_e1211203722926 : check e1211203722926 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1211203722938 : Closed e1211203722938 ∧ code e1211203722938 = 5609250234042 := by decide
theorem cert_e1211203722938 : check e1211203722938 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203722966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203722966 : Closed e1211203722966 ∧ code e1211203722966 = 5609250234070 := by decide
theorem cert_e1211203722966 : check e1211203722966 [[],[]] .chain = true := by decide
def e1211203722970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203722970 : Closed e1211203722970 ∧ code e1211203722970 = 5609250234074 := by decide
theorem cert_e1211203722970 : check e1211203722970 [[],[]] .chain = true := by decide
def e1211203722986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e1211203722986 : Closed e1211203722986 ∧ code e1211203722986 = 5609250234090 := by decide
theorem cert_e1211203722986 : check e1211203722986 [[],[]] .chain = true := by decide
def e1211203723094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203723094 : Closed e1211203723094 ∧ code e1211203723094 = 5609250234198 := by decide
private def t_e1211203723094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1))))))
theorem cert_e1211203723094 : ¬ IsSelfInterpreter e1211203723094 :=
  wSource (t := t_e1211203723094) (replay_sound (ps := []) (t := e1211203723094) (by decide)) (by decide)
def e1211203723098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203723098 : Closed e1211203723098 ∧ code e1211203723098 = 5609250234202 := by decide
private def t_e1211203723098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0))))))
theorem cert_e1211203723098 : ¬ IsSelfInterpreter e1211203723098 :=
  wSource (t := t_e1211203723098) (replay_sound (ps := []) (t := e1211203723098) (by decide)) (by decide)
def e1211203724086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203724086 : Closed e1211203724086 ∧ code e1211203724086 = 5609250235190 := by decide
theorem cert_e1211203724086 : check e1211203724086 [[],[]] .chain = true := by decide
def e1211203724090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203724090 : Closed e1211203724090 ∧ code e1211203724090 = 5609250235194 := by decide
theorem cert_e1211203724090 : check e1211203724090 [[],[]] .chain = true := by decide
def e1211203724186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203724186 : Closed e1211203724186 ∧ code e1211203724186 = 5609250235290 := by decide
theorem cert_e1211203724186 : check e1211203724186 [[],[]] .chain = true := by decide
def e1211203724854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203724854 : Closed e1211203724854 ∧ code e1211203724854 = 5609250235958 := by decide
theorem cert_e1211203724854 : check e1211203724854 [[],[]] .chain = true := by decide
def e1211203724858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203724858 : Closed e1211203724858 ∧ code e1211203724858 = 5609250235962 := by decide
theorem cert_e1211203724858 : check e1211203724858 [[],[]] .chain = true := by decide
def e1211203724942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203724942 : Closed e1211203724942 ∧ code e1211203724942 = 5609250236046 := by decide
theorem cert_e1211203724942 : check e1211203724942 [[],[]] .chain = true := by decide
def e1211203724998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203724998 : Closed e1211203724998 ∧ code e1211203724998 = 5609250236102 := by decide
theorem cert_e1211203724998 : check e1211203724998 [[],[]] .chain = true := by decide
def e1211203725082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203725082 : Closed e1211203725082 ∧ code e1211203725082 = 5609250236186 := by decide
theorem cert_e1211203725082 : check e1211203725082 [[],[]] .chain = true := by decide
def e1211203725126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203725126 : Closed e1211203725126 ∧ code e1211203725126 = 5609250236230 := by decide
theorem cert_e1211203725126 : check e1211203725126 [[],[]] .chain = true := by decide
def e1211203725710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203725710 : Closed e1211203725710 ∧ code e1211203725710 = 5609250236814 := by decide
theorem cert_e1211203725710 : check e1211203725710 [[],[]] .chain = true := by decide
def e1211203725766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203725766 : Closed e1211203725766 ∧ code e1211203725766 = 5609250236870 := by decide
theorem cert_e1211203725766 : check e1211203725766 [[],[]] .chain = true := by decide
def e1211203726534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203726534 : Closed e1211203726534 ∧ code e1211203726534 = 5609250237638 := by decide
theorem cert_e1211203726534 : check e1211203726534 [[],[]] .chain = true := by decide
def e1211203727478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203727478 : Closed e1211203727478 ∧ code e1211203727478 = 5609250238582 := by decide
theorem cert_e1211203727478 : check e1211203727478 [[],[]] .chain = true := by decide
def e1211203727482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203727482 : Closed e1211203727482 ∧ code e1211203727482 = 5609250238586 := by decide
theorem cert_e1211203727482 : check e1211203727482 [[],[]] .chain = true := by decide
def e1211203727574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203727574 : Closed e1211203727574 ∧ code e1211203727574 = 5609250238678 := by decide
theorem cert_e1211203727574 : check e1211203727574 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203727670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203727670 : Closed e1211203727670 ∧ code e1211203727670 = 5609250238774 := by decide
theorem cert_e1211203727670 : check e1211203727670 [[],[]] .chain = true := by decide
def e1211203727674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203727674 : Closed e1211203727674 ∧ code e1211203727674 = 5609250238778 := by decide
theorem cert_e1211203727674 : check e1211203727674 [[],[]] .chain = true := by decide
def e1211203727758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203727758 : Closed e1211203727758 ∧ code e1211203727758 = 5609250238862 := by decide
theorem cert_e1211203727758 : check e1211203727758 [[],[]] .chain = true := by decide
def e1211203727814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203727814 : Closed e1211203727814 ∧ code e1211203727814 = 5609250238918 := by decide
theorem cert_e1211203727814 : check e1211203727814 [[],[]] .chain = true := by decide
def e1211203728150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203728150 : Closed e1211203728150 ∧ code e1211203728150 = 5609250239254 := by decide
theorem cert_e1211203728150 : check e1211203728150 [[],[]] .chain = true := by decide
def e1211203728226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203728226 : Closed e1211203728226 ∧ code e1211203728226 = 5609250239330 := by decide
theorem cert_e1211203728226 : check e1211203728226 [[],[]] .chain = true := by decide
def e1211203728238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203728238 : Closed e1211203728238 ∧ code e1211203728238 = 5609250239342 := by decide
theorem cert_e1211203728238 : check e1211203728238 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203728246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203728246 : Closed e1211203728246 ∧ code e1211203728246 = 5609250239350 := by decide
theorem cert_e1211203728246 : check e1211203728246 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203728266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203728266 : Closed e1211203728266 ∧ code e1211203728266 = 5609250239370 := by decide
theorem cert_e1211203728266 : check e1211203728266 [[],[]] .chain = true := by decide
def e1211203728290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211203728290 : Closed e1211203728290 ∧ code e1211203728290 = 5609250239394 := by decide
theorem cert_e1211203728290 : check e1211203728290 [[],[]] .chain = true := by decide
def e1211203728302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203728302 : Closed e1211203728302 ∧ code e1211203728302 = 5609250239406 := by decide
theorem cert_e1211203728302 : check e1211203728302 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203728310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e1211203728310 : Closed e1211203728310 ∧ code e1211203728310 = 5609250239414 := by decide
theorem cert_e1211203728310 : check e1211203728310 [[],[]] .chain = true := by decide
def e1211203728314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203728314 : Closed e1211203728314 ∧ code e1211203728314 = 5609250239418 := by decide
theorem cert_e1211203728314 : check e1211203728314 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203728342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203728342 : Closed e1211203728342 ∧ code e1211203728342 = 5609250239446 := by decide
theorem cert_e1211203728342 : check e1211203728342 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203728346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203728346 : Closed e1211203728346 ∧ code e1211203728346 = 5609250239450 := by decide
theorem cert_e1211203728346 : check e1211203728346 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203728414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e1211203728414 : Closed e1211203728414 ∧ code e1211203728414 = 5609250239518 := by decide
theorem cert_e1211203728414 : check e1211203728414 [[],[]] .chain = true := by decide
end Blc.Floor42
