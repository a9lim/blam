import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211207451886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207451886 : Closed e1211207451886 ∧ code e1211207451886 = 5609253962990 := by decide
theorem cert_e1211207451886 : check e1211207451886 [[],[]] .chain = true := by decide
def e1211207451894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207451894 : Closed e1211207451894 ∧ code e1211207451894 = 5609253962998 := by decide
theorem cert_e1211207451894 : check e1211207451894 [[],[]] .chain = true := by decide
def e1211207452270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207452270 : Closed e1211207452270 ∧ code e1211207452270 = 5609253963374 := by decide
theorem cert_e1211207452270 : check e1211207452270 [[],[]] .chain = true := by decide
def e1211207452282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207452282 : Closed e1211207452282 ∧ code e1211207452282 = 5609253963386 := by decide
theorem cert_e1211207452282 : check e1211207452282 [[],[]] .chain = true := by decide
def e1211207452446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211207452446 : Closed e1211207452446 ∧ code e1211207452446 = 5609253963550 := by decide
theorem cert_e1211207452446 : check e1211207452446 [[],[]] .chain = true := by decide
def e1211207452614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e1211207452614 : Closed e1211207452614 ∧ code e1211207452614 = 5609253963718 := by decide
theorem cert_e1211207452614 : check e1211207452614 [[],[]] .chain = true := by decide
def e1211207453806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211207453806 : Closed e1211207453806 ∧ code e1211207453806 = 5609253964910 := by decide
theorem cert_e1211207453806 : check e1211207453806 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207453982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211207453982 : Closed e1211207453982 ∧ code e1211207453982 = 5609253965086 := by decide
theorem cert_e1211207453982 : check e1211207453982 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207454190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e1211207454190 : Closed e1211207454190 ∧ code e1211207454190 = 5609253965294 := by decide
theorem cert_e1211207454190 : check e1211207454190 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207454254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211207454254 : Closed e1211207454254 ∧ code e1211207454254 = 5609253965358 := by decide
theorem cert_e1211207454254 : check e1211207454254 [[],[]] .chain = true := by decide
def e1211207454446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211207454446 : Closed e1211207454446 ∧ code e1211207454446 = 5609253965550 := by decide
theorem cert_e1211207454446 : check e1211207454446 [[],[]] .chain = true := by decide
def e1211207454454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211207454454 : Closed e1211207454454 ∧ code e1211207454454 = 5609253965558 := by decide
theorem cert_e1211207454454 : check e1211207454454 [[],[]] .chain = true := by decide
def e1211207454574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211207454574 : Closed e1211207454574 ∧ code e1211207454574 = 5609253965678 := by decide
theorem cert_e1211207454574 : check e1211207454574 [[],[]] .chain = true := by decide
def e1211207454586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211207454586 : Closed e1211207454586 ∧ code e1211207454586 = 5609253965690 := by decide
theorem cert_e1211207454586 : check e1211207454586 [[],[]] .chain = true := by decide
def e1211207454602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211207454602 : Closed e1211207454602 ∧ code e1211207454602 = 5609253965706 := by decide
theorem cert_e1211207454602 : check e1211207454602 [[],[]] .chain = true := by decide
def e1211207454638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e1211207454638 : Closed e1211207454638 ∧ code e1211207454638 = 5609253965742 := by decide
theorem cert_e1211207454638 : check e1211207454638 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207454646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211207454646 : Closed e1211207454646 ∧ code e1211207454646 = 5609253965750 := by decide
theorem cert_e1211207454646 : check e1211207454646 [[],[]] .chain = true := by decide
def e1211207454650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211207454650 : Closed e1211207454650 ∧ code e1211207454650 = 5609253965754 := by decide
theorem cert_e1211207454650 : check e1211207454650 [[],[]] .chain = true := by decide
def e1211207455518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211207455518 : Closed e1211207455518 ∧ code e1211207455518 = 5609253966622 := by decide
theorem cert_e1211207455518 : check e1211207455518 [[],[]] .chain = true := by decide
def e1211207455686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211207455686 : Closed e1211207455686 ∧ code e1211207455686 = 5609253966790 := by decide
theorem cert_e1211207455686 : check e1211207455686 [[],[]] .chain = true := by decide
def e1211207456830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211207456830 : Closed e1211207456830 ∧ code e1211207456830 = 5609253967934 := by decide
theorem cert_e1211207456830 : check e1211207456830 [[],[]] .chain = true := by decide
def e1211207457250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211207457250 : Closed e1211207457250 ∧ code e1211207457250 = 5609253968354 := by decide
theorem cert_e1211207457250 : check e1211207457250 [[],[]] .chain = true := by decide
def e1211207457262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211207457262 : Closed e1211207457262 ∧ code e1211207457262 = 5609253968366 := by decide
theorem cert_e1211207457262 : check e1211207457262 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207458030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207458030 : Closed e1211207458030 ∧ code e1211207458030 = 5609253969134 := by decide
theorem cert_e1211207458030 : check e1211207458030 [[],[]] .chain = true := by decide
def e1211207458038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207458038 : Closed e1211207458038 ∧ code e1211207458038 = 5609253969142 := by decide
theorem cert_e1211207458038 : check e1211207458038 [[],[]] .chain = true := by decide
def e1211207458318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211207458318 : Closed e1211207458318 ∧ code e1211207458318 = 5609253969422 := by decide
theorem cert_e1211207458318 : check e1211207458318 [[],[]] .chain = true := by decide
def e1211207458330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207458330 : Closed e1211207458330 ∧ code e1211207458330 = 5609253969434 := by decide
theorem cert_e1211207458330 : check e1211207458330 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207458402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211207458402 : Closed e1211207458402 ∧ code e1211207458402 = 5609253969506 := by decide
theorem cert_e1211207458402 : check e1211207458402 [[],[]] .chain = true := by decide
def e1211207458414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207458414 : Closed e1211207458414 ∧ code e1211207458414 = 5609253969518 := by decide
theorem cert_e1211207458414 : check e1211207458414 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207458422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207458422 : Closed e1211207458422 ∧ code e1211207458422 = 5609253969526 := by decide
theorem cert_e1211207458422 : check e1211207458422 [[],[]] .chain = true := by decide
def e1211207458426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207458426 : Closed e1211207458426 ∧ code e1211207458426 = 5609253969530 := by decide
theorem cert_e1211207458426 : check e1211207458426 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207462254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211207462254 : Closed e1211207462254 ∧ code e1211207462254 = 5609253973358 := by decide
theorem cert_e1211207462254 : check e1211207462254 [[],[]] .chain = true := by decide
def e1211207462262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211207462262 : Closed e1211207462262 ∧ code e1211207462262 = 5609253973366 := by decide
theorem cert_e1211207462262 : check e1211207462262 [[],[]] .chain = true := by decide
def e1211207462318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211207462318 : Closed e1211207462318 ∧ code e1211207462318 = 5609253973422 := by decide
theorem cert_e1211207462318 : check e1211207462318 [[],[]] .chain = true := by decide
def e1211207462330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211207462330 : Closed e1211207462330 ∧ code e1211207462330 = 5609253973434 := by decide
theorem cert_e1211207462330 : check e1211207462330 [[],[]] .chain = true := by decide
def e1211207462358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211207462358 : Closed e1211207462358 ∧ code e1211207462358 = 5609253973462 := by decide
theorem cert_e1211207462358 : check e1211207462358 [[],[]] .chain = true := by decide
def e1211207462362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211207462362 : Closed e1211207462362 ∧ code e1211207462362 = 5609253973466 := by decide
theorem cert_e1211207462362 : check e1211207462362 [[],[]] .chain = true := by decide
def e1211207462574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211207462574 : Closed e1211207462574 ∧ code e1211207462574 = 5609253973678 := by decide
theorem cert_e1211207462574 : check e1211207462574 [[],[]] .chain = true := by decide
def e1211207462586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211207462586 : Closed e1211207462586 ∧ code e1211207462586 = 5609253973690 := by decide
theorem cert_e1211207462586 : check e1211207462586 [[],[]] .chain = true := by decide
def e1211207462634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211207462634 : Closed e1211207462634 ∧ code e1211207462634 = 5609253973738 := by decide
theorem cert_e1211207462634 : check e1211207462634 [[],[]] .chain = true := by decide
def e1211207462742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211207462742 : Closed e1211207462742 ∧ code e1211207462742 = 5609253973846 := by decide
theorem cert_e1211207462742 : check e1211207462742 [[],[]] .chain = true := by decide
def e1211207462746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211207462746 : Closed e1211207462746 ∧ code e1211207462746 = 5609253973850 := by decide
theorem cert_e1211207462746 : check e1211207462746 [[],[]] .chain = true := by decide
def e1211207462762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211207462762 : Closed e1211207462762 ∧ code e1211207462762 = 5609253973866 := by decide
theorem cert_e1211207462762 : check e1211207462762 [[],[]] .chain = true := by decide
def e1211207463022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211207463022 : Closed e1211207463022 ∧ code e1211207463022 = 5609253974126 := by decide
theorem cert_e1211207463022 : check e1211207463022 [[],[]] .chain = true := by decide
def e1211207463198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211207463198 : Closed e1211207463198 ∧ code e1211207463198 = 5609253974302 := by decide
theorem cert_e1211207463198 : check e1211207463198 [[],[]] .chain = true := by decide
def e1211207463394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211207463394 : Closed e1211207463394 ∧ code e1211207463394 = 5609253974498 := by decide
theorem cert_e1211207463394 : check e1211207463394 [[],[]] .chain = true := by decide
def e1211207463406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211207463406 : Closed e1211207463406 ∧ code e1211207463406 = 5609253974510 := by decide
theorem cert_e1211207463406 : check e1211207463406 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207463790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211207463790 : Closed e1211207463790 ∧ code e1211207463790 = 5609253974894 := by decide
theorem cert_e1211207463790 : check e1211207463790 [[],[]] .chain = true := by decide
def e1211207463798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211207463798 : Closed e1211207463798 ∧ code e1211207463798 = 5609253974902 := by decide
theorem cert_e1211207463798 : check e1211207463798 [[],[]] .chain = true := by decide
def e1211207463854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211207463854 : Closed e1211207463854 ∧ code e1211207463854 = 5609253974958 := by decide
theorem cert_e1211207463854 : check e1211207463854 [[],[]] .chain = true := by decide
def e1211207463866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211207463866 : Closed e1211207463866 ∧ code e1211207463866 = 5609253974970 := by decide
theorem cert_e1211207463866 : check e1211207463866 [[],[]] .chain = true := by decide
def e1211207463894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211207463894 : Closed e1211207463894 ∧ code e1211207463894 = 5609253974998 := by decide
theorem cert_e1211207463894 : check e1211207463894 [[],[]] .chain = true := by decide
def e1211207463898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211207463898 : Closed e1211207463898 ∧ code e1211207463898 = 5609253975002 := by decide
theorem cert_e1211207463898 : check e1211207463898 [[],[]] .chain = true := by decide
def e1211207464174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207464174 : Closed e1211207464174 ∧ code e1211207464174 = 5609253975278 := by decide
theorem cert_e1211207464174 : check e1211207464174 [[],[]] .chain = true := by decide
def e1211207464182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207464182 : Closed e1211207464182 ∧ code e1211207464182 = 5609253975286 := by decide
theorem cert_e1211207464182 : check e1211207464182 [[],[]] .chain = true := by decide
def e1211207464558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207464558 : Closed e1211207464558 ∧ code e1211207464558 = 5609253975662 := by decide
theorem cert_e1211207464558 : check e1211207464558 [[],[]] .chain = true := by decide
def e1211207464570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207464570 : Closed e1211207464570 ∧ code e1211207464570 = 5609253975674 := by decide
theorem cert_e1211207464570 : check e1211207464570 [[],[]] .chain = true := by decide
def e1211207464710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207464710 : Closed e1211207464710 ∧ code e1211207464710 = 5609253975814 := by decide
theorem cert_e1211207464710 : check e1211207464710 [[],[]] .chain = true := by decide
def e1211207464734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211207464734 : Closed e1211207464734 ∧ code e1211207464734 = 5609253975838 := by decide
theorem cert_e1211207464734 : check e1211207464734 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207464758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207464758 : Closed e1211207464758 ∧ code e1211207464758 = 5609253975862 := by decide
theorem cert_e1211207464758 : check e1211207464758 [[],[]] .chain = true := by decide
def e1211207464762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207464762 : Closed e1211207464762 ∧ code e1211207464762 = 5609253975866 := by decide
theorem cert_e1211207464762 : check e1211207464762 [[],[]] .chain = true := by decide
def e1211207465006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211207465006 : Closed e1211207465006 ∧ code e1211207465006 = 5609253976110 := by decide
theorem cert_e1211207465006 : check e1211207465006 [[],[]] .chain = true := by decide
def e1211207465198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211207465198 : Closed e1211207465198 ∧ code e1211207465198 = 5609253976302 := by decide
theorem cert_e1211207465198 : check e1211207465198 [[],[]] .chain = true := by decide
def e1211207465206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211207465206 : Closed e1211207465206 ∧ code e1211207465206 = 5609253976310 := by decide
theorem cert_e1211207465206 : check e1211207465206 [[],[]] .chain = true := by decide
def e1211207465390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211207465390 : Closed e1211207465390 ∧ code e1211207465390 = 5609253976494 := by decide
theorem cert_e1211207465390 : check e1211207465390 [[],[]] .chain = true := by decide
def e1211207465402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211207465402 : Closed e1211207465402 ∧ code e1211207465402 = 5609253976506 := by decide
theorem cert_e1211207465402 : check e1211207465402 [[],[]] .chain = true := by decide
def e1211207465450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211207465450 : Closed e1211207465450 ∧ code e1211207465450 = 5609253976554 := by decide
theorem cert_e1211207465450 : check e1211207465450 [[],[]] .chain = true := by decide
def e1211207465582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207465582 : Closed e1211207465582 ∧ code e1211207465582 = 5609253976686 := by decide
theorem cert_e1211207465582 : check e1211207465582 [[],[]] .chain = true := by decide
def e1211207465594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207465594 : Closed e1211207465594 ∧ code e1211207465594 = 5609253976698 := by decide
theorem cert_e1211207465594 : check e1211207465594 [[],[]] .chain = true := by decide
def e1211207465758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211207465758 : Closed e1211207465758 ∧ code e1211207465758 = 5609253976862 := by decide
theorem cert_e1211207465758 : check e1211207465758 [[],[]] .chain = true := by decide
def e1211207465858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211207465858 : Closed e1211207465858 ∧ code e1211207465858 = 5609253976962 := by decide
theorem cert_e1211207465858 : check e1211207465858 [[],[]] .chain = true := by decide
def e1211207465870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211207465870 : Closed e1211207465870 ∧ code e1211207465870 = 5609253976974 := by decide
theorem cert_e1211207465870 : check e1211207465870 [[],[]] .chain = true := by decide
def e1211207465882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211207465882 : Closed e1211207465882 ∧ code e1211207465882 = 5609253976986 := by decide
theorem cert_e1211207465882 : check e1211207465882 [[],[]] .chain = true := by decide
def e1211207466006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211207466006 : Closed e1211207466006 ∧ code e1211207466006 = 5609253977110 := by decide
theorem cert_e1211207466006 : check e1211207466006 [[],[]] .chain = true := by decide
def e1211207466010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211207466010 : Closed e1211207466010 ∧ code e1211207466010 = 5609253977114 := by decide
theorem cert_e1211207466010 : check e1211207466010 [[],[]] .chain = true := by decide
def e1211207466054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211207466054 : Closed e1211207466054 ∧ code e1211207466054 = 5609253977158 := by decide
theorem cert_e1211207466054 : check e1211207466054 [[],[]] .chain = true := by decide
def e1211207466082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211207466082 : Closed e1211207466082 ∧ code e1211207466082 = 5609253977186 := by decide
theorem cert_e1211207466082 : check e1211207466082 [[],[]] .chain = true := by decide
def e1211207466094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211207466094 : Closed e1211207466094 ∧ code e1211207466094 = 5609253977198 := by decide
theorem cert_e1211207466094 : check e1211207466094 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207466102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211207466102 : Closed e1211207466102 ∧ code e1211207466102 = 5609253977206 := by decide
theorem cert_e1211207466102 : check e1211207466102 [[],[]] .chain = true := by decide
def e1211207466106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211207466106 : Closed e1211207466106 ∧ code e1211207466106 = 5609253977210 := by decide
theorem cert_e1211207466106 : check e1211207466106 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207466198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211207466198 : Closed e1211207466198 ∧ code e1211207466198 = 5609253977302 := by decide
theorem cert_e1211207466198 : check e1211207466198 [[],[]] .chain = true := by decide
def e1211207466202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211207466202 : Closed e1211207466202 ∧ code e1211207466202 = 5609253977306 := by decide
theorem cert_e1211207466202 : check e1211207466202 [[],[]] .chain = true := by decide
def e1211207466218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211207466218 : Closed e1211207466218 ∧ code e1211207466218 = 5609253977322 := by decide
theorem cert_e1211207466218 : check e1211207466218 [[],[]] .chain = true := by decide
def e1211207466246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207466246 : Closed e1211207466246 ∧ code e1211207466246 = 5609253977350 := by decide
theorem cert_e1211207466246 : check e1211207466246 [[],[]] .chain = true := by decide
def e1211207466270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211207466270 : Closed e1211207466270 ∧ code e1211207466270 = 5609253977374 := by decide
theorem cert_e1211207466270 : check e1211207466270 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207466294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207466294 : Closed e1211207466294 ∧ code e1211207466294 = 5609253977398 := by decide
theorem cert_e1211207466294 : check e1211207466294 [[],[]] .chain = true := by decide
def e1211207466298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207466298 : Closed e1211207466298 ∧ code e1211207466298 = 5609253977402 := by decide
theorem cert_e1211207466298 : check e1211207466298 [[],[]] .chain = true := by decide
def e1211207466370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211207466370 : Closed e1211207466370 ∧ code e1211207466370 = 5609253977474 := by decide
theorem cert_e1211207466370 : check e1211207466370 [[],[]] .chain = true := by decide
def e1211207466382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211207466382 : Closed e1211207466382 ∧ code e1211207466382 = 5609253977486 := by decide
theorem cert_e1211207466382 : check e1211207466382 [[],[]] .chain = true := by decide
def e1211207466394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211207466394 : Closed e1211207466394 ∧ code e1211207466394 = 5609253977498 := by decide
theorem cert_e1211207466394 : check e1211207466394 [[],[]] .chain = true := by decide
def e1211207466438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211207466438 : Closed e1211207466438 ∧ code e1211207466438 = 5609253977542 := by decide
theorem cert_e1211207466438 : check e1211207466438 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207467134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211207467134 : Closed e1211207467134 ∧ code e1211207467134 = 5609253978238 := by decide
theorem cert_e1211207467134 : check e1211207467134 [[],[]] .chain = true := by decide
def e1211207467998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211207467998 : Closed e1211207467998 ∧ code e1211207467998 = 5609253979102 := by decide
theorem cert_e1211207467998 : check e1211207467998 [[],[]] .chain = true := by decide
def e1211207468002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211207468002 : Closed e1211207468002 ∧ code e1211207468002 = 5609253979106 := by decide
theorem cert_e1211207468002 : check e1211207468002 [[],[]] .chain = true := by decide
def e1211207468014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211207468014 : Closed e1211207468014 ∧ code e1211207468014 = 5609253979118 := by decide
theorem cert_e1211207468014 : check e1211207468014 [[],[]] .chain = true := by decide
def e1211207469934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211207469934 : Closed e1211207469934 ∧ code e1211207469934 = 5609253981038 := by decide
theorem cert_e1211207469934 : check e1211207469934 [[],[]] .chain = true := by decide
def e1211207469942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211207469942 : Closed e1211207469942 ∧ code e1211207469942 = 5609253981046 := by decide
theorem cert_e1211207469942 : check e1211207469942 [[],[]] .chain = true := by decide
def e1211207469998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211207469998 : Closed e1211207469998 ∧ code e1211207469998 = 5609253981102 := by decide
theorem cert_e1211207469998 : check e1211207469998 [[],[]] .chain = true := by decide
def e1211207470010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211207470010 : Closed e1211207470010 ∧ code e1211207470010 = 5609253981114 := by decide
theorem cert_e1211207470010 : check e1211207470010 [[],[]] .chain = true := by decide
def e1211207470038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211207470038 : Closed e1211207470038 ∧ code e1211207470038 = 5609253981142 := by decide
theorem cert_e1211207470038 : check e1211207470038 [[],[]] .chain = true := by decide
def e1211207470042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211207470042 : Closed e1211207470042 ∧ code e1211207470042 = 5609253981146 := by decide
theorem cert_e1211207470042 : check e1211207470042 [[],[]] .chain = true := by decide
def e1211207470318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207470318 : Closed e1211207470318 ∧ code e1211207470318 = 5609253981422 := by decide
theorem cert_e1211207470318 : check e1211207470318 [[],[]] .chain = true := by decide
def e1211207470326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207470326 : Closed e1211207470326 ∧ code e1211207470326 = 5609253981430 := by decide
theorem cert_e1211207470326 : check e1211207470326 [[],[]] .chain = true := by decide
def e1211207470702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207470702 : Closed e1211207470702 ∧ code e1211207470702 = 5609253981806 := by decide
theorem cert_e1211207470702 : check e1211207470702 [[],[]] .chain = true := by decide
def e1211207470714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207470714 : Closed e1211207470714 ∧ code e1211207470714 = 5609253981818 := by decide
theorem cert_e1211207470714 : check e1211207470714 [[],[]] .chain = true := by decide
def e1211207470854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207470854 : Closed e1211207470854 ∧ code e1211207470854 = 5609253981958 := by decide
theorem cert_e1211207470854 : check e1211207470854 [[],[]] .chain = true := by decide
def e1211207470878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211207470878 : Closed e1211207470878 ∧ code e1211207470878 = 5609253981982 := by decide
theorem cert_e1211207470878 : check e1211207470878 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207470902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207470902 : Closed e1211207470902 ∧ code e1211207470902 = 5609253982006 := by decide
theorem cert_e1211207470902 : check e1211207470902 [[],[]] .chain = true := by decide
def e1211207470906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207470906 : Closed e1211207470906 ∧ code e1211207470906 = 5609253982010 := by decide
theorem cert_e1211207470906 : check e1211207470906 [[],[]] .chain = true := by decide
def e1211207475678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211207475678 : Closed e1211207475678 ∧ code e1211207475678 = 5609253986782 := by decide
theorem cert_e1211207475678 : check e1211207475678 [[],[]] .chain = true := by decide
def e1211207475702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211207475702 : Closed e1211207475702 ∧ code e1211207475702 = 5609253986806 := by decide
theorem cert_e1211207475702 : check e1211207475702 [[],[]] .chain = true := by decide
def e1211207476654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211207476654 : Closed e1211207476654 ∧ code e1211207476654 = 5609253987758 := by decide
theorem cert_e1211207476654 : check e1211207476654 [[],[]] .chain = true := by decide
def e1211207476666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211207476666 : Closed e1211207476666 ∧ code e1211207476666 = 5609253987770 := by decide
theorem cert_e1211207476666 : check e1211207476666 [[],[]] .chain = true := by decide
def e1211207476714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211207476714 : Closed e1211207476714 ∧ code e1211207476714 = 5609253987818 := by decide
theorem cert_e1211207476714 : check e1211207476714 [[],[]] .chain = true := by decide
def e1211207476846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211207476846 : Closed e1211207476846 ∧ code e1211207476846 = 5609253987950 := by decide
theorem cert_e1211207476846 : check e1211207476846 [[],[]] .chain = true := by decide
def e1211207476858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211207476858 : Closed e1211207476858 ∧ code e1211207476858 = 5609253987962 := by decide
theorem cert_e1211207476858 : check e1211207476858 [[],[]] .chain = true := by decide
def e1211207477022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211207477022 : Closed e1211207477022 ∧ code e1211207477022 = 5609253988126 := by decide
theorem cert_e1211207477022 : check e1211207477022 [[],[]] .chain = true := by decide
def e1211207477122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211207477122 : Closed e1211207477122 ∧ code e1211207477122 = 5609253988226 := by decide
theorem cert_e1211207477122 : check e1211207477122 [[],[]] .chain = true := by decide
def e1211207477134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211207477134 : Closed e1211207477134 ∧ code e1211207477134 = 5609253988238 := by decide
theorem cert_e1211207477134 : check e1211207477134 [[],[]] .chain = true := by decide
def e1211207477146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207477146 : Closed e1211207477146 ∧ code e1211207477146 = 5609253988250 := by decide
theorem cert_e1211207477146 : check e1211207477146 [[],[]] .chain = true := by decide
def e1211207479326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211207479326 : Closed e1211207479326 ∧ code e1211207479326 = 5609253990430 := by decide
theorem cert_e1211207479326 : check e1211207479326 [[],[]] .chain = true := by decide
def e1211207479494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211207479494 : Closed e1211207479494 ∧ code e1211207479494 = 5609253990598 := by decide
theorem cert_e1211207479494 : check e1211207479494 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207479518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211207479518 : Closed e1211207479518 ∧ code e1211207479518 = 5609253990622 := by decide
theorem cert_e1211207479518 : check e1211207479518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207479522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211207479522 : Closed e1211207479522 ∧ code e1211207479522 = 5609253990626 := by decide
theorem cert_e1211207479522 : check e1211207479522 [[],[]] .chain = true := by decide
def e1211207479534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211207479534 : Closed e1211207479534 ∧ code e1211207479534 = 5609253990638 := by decide
theorem cert_e1211207479534 : check e1211207479534 [[],[]] .chain = true := by decide
def e1211207479542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211207479542 : Closed e1211207479542 ∧ code e1211207479542 = 5609253990646 := by decide
theorem cert_e1211207479542 : check e1211207479542 [[],[]] .chain = true := by decide
def e1211207479546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211207479546 : Closed e1211207479546 ∧ code e1211207479546 = 5609253990650 := by decide
theorem cert_e1211207479546 : check e1211207479546 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207480022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211207480022 : Closed e1211207480022 ∧ code e1211207480022 = 5609253991126 := by decide
theorem cert_e1211207480022 : check e1211207480022 [[],[]] .chain = true := by decide
def e1211207480026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211207480026 : Closed e1211207480026 ∧ code e1211207480026 = 5609253991130 := by decide
theorem cert_e1211207480026 : check e1211207480026 [[],[]] .chain = true := by decide
def e1211207480042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211207480042 : Closed e1211207480042 ∧ code e1211207480042 = 5609253991146 := by decide
theorem cert_e1211207480042 : check e1211207480042 [[],[]] .chain = true := by decide
def e1211207480070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207480070 : Closed e1211207480070 ∧ code e1211207480070 = 5609253991174 := by decide
theorem cert_e1211207480070 : check e1211207480070 [[],[]] .chain = true := by decide
def e1211207480094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211207480094 : Closed e1211207480094 ∧ code e1211207480094 = 5609253991198 := by decide
theorem cert_e1211207480094 : check e1211207480094 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207480118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207480118 : Closed e1211207480118 ∧ code e1211207480118 = 5609253991222 := by decide
theorem cert_e1211207480118 : check e1211207480118 [[],[]] .chain = true := by decide
def e1211207480122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207480122 : Closed e1211207480122 ∧ code e1211207480122 = 5609253991226 := by decide
theorem cert_e1211207480122 : check e1211207480122 [[],[]] .chain = true := by decide
def e1211207480194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211207480194 : Closed e1211207480194 ∧ code e1211207480194 = 5609253991298 := by decide
theorem cert_e1211207480194 : check e1211207480194 [[],[]] .chain = true := by decide
def e1211207480206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211207480206 : Closed e1211207480206 ∧ code e1211207480206 = 5609253991310 := by decide
theorem cert_e1211207480206 : check e1211207480206 [[],[]] .chain = true := by decide
def e1211207480218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207480218 : Closed e1211207480218 ∧ code e1211207480218 = 5609253991322 := by decide
theorem cert_e1211207480218 : check e1211207480218 [[],[]] .chain = true := by decide
def e1211207480262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211207480262 : Closed e1211207480262 ∧ code e1211207480262 = 5609253991366 := by decide
theorem cert_e1211207480262 : check e1211207480262 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207483638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e1211207483638 : Closed e1211207483638 ∧ code e1211207483638 = 5609253994742 := by decide
theorem cert_e1211207483638 : check e1211207483638 [[],[]] .chain = true := by decide
def e1211207483642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211207483642 : Closed e1211207483642 ∧ code e1211207483642 = 5609253994746 := by decide
theorem cert_e1211207483642 : check e1211207483642 [[],[]] .chain = true := by decide
def e1211207484022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207484022 : Closed e1211207484022 ∧ code e1211207484022 = 5609253995126 := by decide
theorem cert_e1211207484022 : check e1211207484022 [[],[]] .chain = true := by decide
def e1211207484214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207484214 : Closed e1211207484214 ∧ code e1211207484214 = 5609253995318 := by decide
theorem cert_e1211207484214 : check e1211207484214 [[],[]] .chain = true := by decide
def e1211207484218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207484218 : Closed e1211207484218 ∧ code e1211207484218 = 5609253995322 := by decide
theorem cert_e1211207484218 : check e1211207484218 [[],[]] .chain = true := by decide
def e1211207484302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e1211207484302 : Closed e1211207484302 ∧ code e1211207484302 = 5609253995406 := by decide
theorem cert_e1211207484302 : check e1211207484302 [[],[]] .chain = true := by decide
def e1211207484358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211207484358 : Closed e1211207484358 ∧ code e1211207484358 = 5609253995462 := by decide
theorem cert_e1211207484358 : check e1211207484358 [[],[]] .chain = true := by decide
def e1211207484982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211207484982 : Closed e1211207484982 ∧ code e1211207484982 = 5609253996086 := by decide
theorem cert_e1211207484982 : check e1211207484982 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207485070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211207485070 : Closed e1211207485070 ∧ code e1211207485070 = 5609253996174 := by decide
private def t_e1211207485070 : Term := (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 4))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3))))))))
theorem cert_e1211207485070 : ¬ IsSelfInterpreter e1211207485070 :=
  wIdentity (t := t_e1211207485070) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left]]) (t := (inv e1211207485070)) (by decide)) (by decide)
def e1211207485166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e1211207485166 : Closed e1211207485166 ∧ code e1211207485166 = 5609253996270 := by decide
theorem cert_e1211207485166 : checkPay e1211207485166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left]] 0 [] = true := by decide
def e1211207485174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e1211207485174 : Closed e1211207485174 ∧ code e1211207485174 = 5609253996278 := by decide
theorem cert_e1211207485174 : check e1211207485174 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207485206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211207485206 : Closed e1211207485206 ∧ code e1211207485206 = 5609253996310 := by decide
theorem cert_e1211207485206 : check e1211207485206 [[],[]] .chain = true := by decide
def e1211207485302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211207485302 : Closed e1211207485302 ∧ code e1211207485302 = 5609253996406 := by decide
theorem cert_e1211207485302 : check e1211207485302 [[],[]] .chain = true := by decide
def e1211207485322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211207485322 : Closed e1211207485322 ∧ code e1211207485322 = 5609253996426 := by decide
theorem cert_e1211207485322 : check e1211207485322 [[],[]] .chain = true := by decide
def e1211207485358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e1211207485358 : Closed e1211207485358 ∧ code e1211207485358 = 5609253996462 := by decide
theorem cert_e1211207485358 : checkPay e1211207485358 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] 0 [[.under]] = true := by decide
def e1211207485366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211207485366 : Closed e1211207485366 ∧ code e1211207485366 = 5609253996470 := by decide
theorem cert_e1211207485366 : check e1211207485366 [[],[]] .chain = true := by decide
def e1211207485370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e1211207485370 : Closed e1211207485370 ∧ code e1211207485370 = 5609253996474 := by decide
theorem cert_e1211207485370 : check e1211207485370 [[],[]] .chain = true := by decide
def e1211207485398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e1211207485398 : Closed e1211207485398 ∧ code e1211207485398 = 5609253996502 := by decide
theorem cert_e1211207485398 : check e1211207485398 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1211207485838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211207485838 : Closed e1211207485838 ∧ code e1211207485838 = 5609253996942 := by decide
theorem cert_e1211207485838 : check e1211207485838 [[],[]] .chain = true := by decide
def e1211207485894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211207485894 : Closed e1211207485894 ∧ code e1211207485894 = 5609253996998 := by decide
theorem cert_e1211207485894 : check e1211207485894 [[],[]] .chain = true := by decide
def e1211207486494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211207486494 : Closed e1211207486494 ∧ code e1211207486494 = 5609253997598 := by decide
theorem cert_e1211207486494 : check e1211207486494 [[],[]] .chain = true := by decide
def e1211207486690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211207486690 : Closed e1211207486690 ∧ code e1211207486690 = 5609253997794 := by decide
theorem cert_e1211207486690 : check e1211207486690 [[],[]] .chain = true := by decide
end Blc.Floor42
