import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211278307246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1211278307246 : Closed e1211278307246 ∧ code e1211278307246 = 5609324818350 := by decide
theorem cert_e1211278307246 : check e1211278307246 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278307258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1211278307258 : Closed e1211278307258 ∧ code e1211278307258 = 5609324818362 := by decide
theorem cert_e1211278307258 : check e1211278307258 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278308318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211278308318 : Closed e1211278308318 ∧ code e1211278308318 = 5609324819422 := by decide
theorem cert_e1211278308318 : check e1211278308318 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278308334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211278308334 : Closed e1211278308334 ∧ code e1211278308334 = 5609324819438 := by decide
theorem cert_e1211278308334 : check e1211278308334 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278310622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211278310622 : Closed e1211278310622 ∧ code e1211278310622 = 5609324821726 := by decide
theorem cert_e1211278310622 : check e1211278310622 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278310650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211278310650 : Closed e1211278310650 ∧ code e1211278310650 = 5609324821754 := by decide
theorem cert_e1211278310650 : check e1211278310650 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278311022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211278311022 : Closed e1211278311022 ∧ code e1211278311022 = 5609324822126 := by decide
theorem cert_e1211278311022 : check e1211278311022 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278311034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211278311034 : Closed e1211278311034 ∧ code e1211278311034 = 5609324822138 := by decide
theorem cert_e1211278311034 : check e1211278311034 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211278339438 : Closed e1211278339438 ∧ code e1211278339438 = 5609324850542 := by decide
theorem cert_e1211278339438 : check e1211278339438 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211278339446 : Closed e1211278339446 ∧ code e1211278339446 = 5609324850550 := by decide
theorem cert_e1211278339446 : check e1211278339446 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211278339502 : Closed e1211278339502 ∧ code e1211278339502 = 5609324850606 := by decide
theorem cert_e1211278339502 : check e1211278339502 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211278339514 : Closed e1211278339514 ∧ code e1211278339514 = 5609324850618 := by decide
theorem cert_e1211278339514 : check e1211278339514 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211278339542 : Closed e1211278339542 ∧ code e1211278339542 = 5609324850646 := by decide
theorem cert_e1211278339542 : check e1211278339542 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211278339546 : Closed e1211278339546 ∧ code e1211278339546 = 5609324850650 := by decide
theorem cert_e1211278339546 : check e1211278339546 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211278339758 : Closed e1211278339758 ∧ code e1211278339758 = 5609324850862 := by decide
theorem cert_e1211278339758 : check e1211278339758 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211278339770 : Closed e1211278339770 ∧ code e1211278339770 = 5609324850874 := by decide
theorem cert_e1211278339770 : check e1211278339770 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211278339818 : Closed e1211278339818 ∧ code e1211278339818 = 5609324850922 := by decide
theorem cert_e1211278339818 : check e1211278339818 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211278339926 : Closed e1211278339926 ∧ code e1211278339926 = 5609324851030 := by decide
theorem cert_e1211278339926 : check e1211278339926 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211278339930 : Closed e1211278339930 ∧ code e1211278339930 = 5609324851034 := by decide
theorem cert_e1211278339930 : check e1211278339930 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278339946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211278339946 : Closed e1211278339946 ∧ code e1211278339946 = 5609324851050 := by decide
theorem cert_e1211278339946 : check e1211278339946 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278340974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211278340974 : Closed e1211278340974 ∧ code e1211278340974 = 5609324852078 := by decide
theorem cert_e1211278340974 : check e1211278340974 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278340982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211278340982 : Closed e1211278340982 ∧ code e1211278340982 = 5609324852086 := by decide
theorem cert_e1211278340982 : check e1211278340982 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211278341038 : Closed e1211278341038 ∧ code e1211278341038 = 5609324852142 := by decide
theorem cert_e1211278341038 : check e1211278341038 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211278341050 : Closed e1211278341050 ∧ code e1211278341050 = 5609324852154 := by decide
theorem cert_e1211278341050 : check e1211278341050 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211278341078 : Closed e1211278341078 ∧ code e1211278341078 = 5609324852182 := by decide
theorem cert_e1211278341078 : check e1211278341078 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211278341082 : Closed e1211278341082 ∧ code e1211278341082 = 5609324852186 := by decide
theorem cert_e1211278341082 : check e1211278341082 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211278341358 : Closed e1211278341358 ∧ code e1211278341358 = 5609324852462 := by decide
theorem cert_e1211278341358 : check e1211278341358 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211278341366 : Closed e1211278341366 ∧ code e1211278341366 = 5609324852470 := by decide
theorem cert_e1211278341366 : check e1211278341366 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211278341742 : Closed e1211278341742 ∧ code e1211278341742 = 5609324852846 := by decide
theorem cert_e1211278341742 : check e1211278341742 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211278341754 : Closed e1211278341754 ∧ code e1211278341754 = 5609324852858 := by decide
theorem cert_e1211278341754 : check e1211278341754 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211278341942 : Closed e1211278341942 ∧ code e1211278341942 = 5609324853046 := by decide
theorem cert_e1211278341942 : check e1211278341942 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278341946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211278341946 : Closed e1211278341946 ∧ code e1211278341946 = 5609324853050 := by decide
theorem cert_e1211278341946 : check e1211278341946 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278342574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211278342574 : Closed e1211278342574 ∧ code e1211278342574 = 5609324853678 := by decide
theorem cert_e1211278342574 : check e1211278342574 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278342586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211278342586 : Closed e1211278342586 ∧ code e1211278342586 = 5609324853690 := by decide
theorem cert_e1211278342586 : check e1211278342586 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278342634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211278342634 : Closed e1211278342634 ∧ code e1211278342634 = 5609324853738 := by decide
theorem cert_e1211278342634 : check e1211278342634 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278342766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211278342766 : Closed e1211278342766 ∧ code e1211278342766 = 5609324853870 := by decide
theorem cert_e1211278342766 : check e1211278342766 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278342778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211278342778 : Closed e1211278342778 ∧ code e1211278342778 = 5609324853882 := by decide
theorem cert_e1211278342778 : check e1211278342778 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211278343066 : Closed e1211278343066 ∧ code e1211278343066 = 5609324854170 := by decide
theorem cert_e1211278343066 : check e1211278343066 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211278343382 : Closed e1211278343382 ∧ code e1211278343382 = 5609324854486 := by decide
theorem cert_e1211278343382 : check e1211278343382 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211278343386 : Closed e1211278343386 ∧ code e1211278343386 = 5609324854490 := by decide
theorem cert_e1211278343386 : check e1211278343386 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211278343402 : Closed e1211278343402 ∧ code e1211278343402 = 5609324854506 := by decide
theorem cert_e1211278343402 : check e1211278343402 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211278343478 : Closed e1211278343478 ∧ code e1211278343478 = 5609324854582 := by decide
theorem cert_e1211278343478 : check e1211278343478 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211278343482 : Closed e1211278343482 ∧ code e1211278343482 = 5609324854586 := by decide
theorem cert_e1211278343482 : check e1211278343482 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278343578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211278343578 : Closed e1211278343578 ∧ code e1211278343578 = 5609324854682 := by decide
theorem cert_e1211278343578 : check e1211278343578 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278345182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211278345182 : Closed e1211278345182 ∧ code e1211278345182 = 5609324856286 := by decide
theorem cert_e1211278345182 : check e1211278345182 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278345198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211278345198 : Closed e1211278345198 ∧ code e1211278345198 = 5609324856302 := by decide
theorem cert_e1211278345198 : check e1211278345198 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211278347118 : Closed e1211278347118 ∧ code e1211278347118 = 5609324858222 := by decide
theorem cert_e1211278347118 : check e1211278347118 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211278347126 : Closed e1211278347126 ∧ code e1211278347126 = 5609324858230 := by decide
theorem cert_e1211278347126 : check e1211278347126 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211278347182 : Closed e1211278347182 ∧ code e1211278347182 = 5609324858286 := by decide
theorem cert_e1211278347182 : check e1211278347182 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211278347194 : Closed e1211278347194 ∧ code e1211278347194 = 5609324858298 := by decide
theorem cert_e1211278347194 : check e1211278347194 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211278347222 : Closed e1211278347222 ∧ code e1211278347222 = 5609324858326 := by decide
theorem cert_e1211278347222 : check e1211278347222 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211278347226 : Closed e1211278347226 ∧ code e1211278347226 = 5609324858330 := by decide
theorem cert_e1211278347226 : check e1211278347226 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211278347502 : Closed e1211278347502 ∧ code e1211278347502 = 5609324858606 := by decide
theorem cert_e1211278347502 : check e1211278347502 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211278347510 : Closed e1211278347510 ∧ code e1211278347510 = 5609324858614 := by decide
theorem cert_e1211278347510 : check e1211278347510 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211278347886 : Closed e1211278347886 ∧ code e1211278347886 = 5609324858990 := by decide
theorem cert_e1211278347886 : check e1211278347886 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278347898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211278347898 : Closed e1211278347898 ∧ code e1211278347898 = 5609324859002 := by decide
theorem cert_e1211278347898 : check e1211278347898 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278348086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211278348086 : Closed e1211278348086 ∧ code e1211278348086 = 5609324859190 := by decide
theorem cert_e1211278348086 : check e1211278348086 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278348090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211278348090 : Closed e1211278348090 ∧ code e1211278348090 = 5609324859194 := by decide
theorem cert_e1211278348090 : check e1211278348090 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278352862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211278352862 : Closed e1211278352862 ∧ code e1211278352862 = 5609324863966 := by decide
theorem cert_e1211278352862 : check e1211278352862 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278352886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211278352886 : Closed e1211278352886 ∧ code e1211278352886 = 5609324863990 := by decide
theorem cert_e1211278352886 : check e1211278352886 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278353838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211278353838 : Closed e1211278353838 ∧ code e1211278353838 = 5609324864942 := by decide
theorem cert_e1211278353838 : check e1211278353838 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278353850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211278353850 : Closed e1211278353850 ∧ code e1211278353850 = 5609324864954 := by decide
theorem cert_e1211278353850 : check e1211278353850 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278353898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211278353898 : Closed e1211278353898 ∧ code e1211278353898 = 5609324865002 := by decide
theorem cert_e1211278353898 : check e1211278353898 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278354030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211278354030 : Closed e1211278354030 ∧ code e1211278354030 = 5609324865134 := by decide
theorem cert_e1211278354030 : check e1211278354030 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278354042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211278354042 : Closed e1211278354042 ∧ code e1211278354042 = 5609324865146 := by decide
theorem cert_e1211278354042 : check e1211278354042 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278354330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211278354330 : Closed e1211278354330 ∧ code e1211278354330 = 5609324865434 := by decide
theorem cert_e1211278354330 : check e1211278354330 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278356718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211278356718 : Closed e1211278356718 ∧ code e1211278356718 = 5609324867822 := by decide
theorem cert_e1211278356718 : check e1211278356718 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278356726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211278356726 : Closed e1211278356726 ∧ code e1211278356726 = 5609324867830 := by decide
theorem cert_e1211278356726 : check e1211278356726 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278357206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211278357206 : Closed e1211278357206 ∧ code e1211278357206 = 5609324868310 := by decide
theorem cert_e1211278357206 : check e1211278357206 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278357210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211278357210 : Closed e1211278357210 ∧ code e1211278357210 = 5609324868314 := by decide
theorem cert_e1211278357210 : check e1211278357210 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278357226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211278357226 : Closed e1211278357226 ∧ code e1211278357226 = 5609324868330 := by decide
theorem cert_e1211278357226 : check e1211278357226 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278357302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211278357302 : Closed e1211278357302 ∧ code e1211278357302 = 5609324868406 := by decide
theorem cert_e1211278357302 : check e1211278357302 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278357306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211278357306 : Closed e1211278357306 ∧ code e1211278357306 = 5609324868410 := by decide
theorem cert_e1211278357306 : check e1211278357306 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278357402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211278357402 : Closed e1211278357402 ∧ code e1211278357402 = 5609324868506 := by decide
theorem cert_e1211278357402 : check e1211278357402 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211278494574 : Closed e1211278494574 ∧ code e1211278494574 = 5609325005678 := by decide
theorem cert_e1211278494574 : check e1211278494574 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211278494582 : Closed e1211278494582 ∧ code e1211278494582 = 5609325005686 := by decide
theorem cert_e1211278494582 : check e1211278494582 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211278494638 : Closed e1211278494638 ∧ code e1211278494638 = 5609325005742 := by decide
theorem cert_e1211278494638 : check e1211278494638 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211278494650 : Closed e1211278494650 ∧ code e1211278494650 = 5609325005754 := by decide
theorem cert_e1211278494650 : check e1211278494650 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211278494678 : Closed e1211278494678 ∧ code e1211278494678 = 5609325005782 := by decide
theorem cert_e1211278494678 : check e1211278494678 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211278494682 : Closed e1211278494682 ∧ code e1211278494682 = 5609325005786 := by decide
theorem cert_e1211278494682 : check e1211278494682 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211278494958 : Closed e1211278494958 ∧ code e1211278494958 = 5609325006062 := by decide
theorem cert_e1211278494958 : check e1211278494958 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278494966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211278494966 : Closed e1211278494966 ∧ code e1211278494966 = 5609325006070 := by decide
theorem cert_e1211278494966 : check e1211278494966 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278495342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211278495342 : Closed e1211278495342 ∧ code e1211278495342 = 5609325006446 := by decide
theorem cert_e1211278495342 : check e1211278495342 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278495354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211278495354 : Closed e1211278495354 ∧ code e1211278495354 = 5609325006458 := by decide
theorem cert_e1211278495354 : check e1211278495354 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278495542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211278495542 : Closed e1211278495542 ∧ code e1211278495542 = 5609325006646 := by decide
theorem cert_e1211278495542 : check e1211278495542 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278495546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211278495546 : Closed e1211278495546 ∧ code e1211278495546 = 5609325006650 := by decide
theorem cert_e1211278495546 : check e1211278495546 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278825182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211278825182 : Closed e1211278825182 ∧ code e1211278825182 = 5609325336286 := by decide
private def t_e1211278825182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem cert_e1211278825182 : ¬ IsSelfInterpreter e1211278825182 :=
  wSource (t := t_e1211278825182) (replay_sound (ps := []) (t := e1211278825182) (by decide)) (by decide)
def e1211278825206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211278825206 : Closed e1211278825206 ∧ code e1211278825206 = 5609325336310 := by decide
private def t_e1211278825206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem cert_e1211278825206 : ¬ IsSelfInterpreter e1211278825206 :=
  wSource (t := t_e1211278825206) (replay_sound (ps := []) (t := e1211278825206) (by decide)) (by decide)
def e1211278825310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211278825310 : Closed e1211278825310 ∧ code e1211278825310 = 5609325336414 := by decide
private def t_e1211278825310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem cert_e1211278825310 : ¬ IsSelfInterpreter e1211278825310 :=
  wSource (t := t_e1211278825310) (replay_sound (ps := []) (t := e1211278825310) (by decide)) (by decide)
def e1211278825338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211278825338 : Closed e1211278825338 ∧ code e1211278825338 = 5609325336442 := by decide
private def t_e1211278825338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e1211278825338 : ¬ IsSelfInterpreter e1211278825338 :=
  wSource (t := t_e1211278825338) (replay_sound (ps := []) (t := e1211278825338) (by decide)) (by decide)
def e1211278825430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211278825430 : Closed e1211278825430 ∧ code e1211278825430 = 5609325336534 := by decide
private def t_e1211278825430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem cert_e1211278825430 : ¬ IsSelfInterpreter e1211278825430 :=
  wSource (t := t_e1211278825430) (replay_sound (ps := []) (t := e1211278825430) (by decide)) (by decide)
def e1211278825434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211278825434 : Closed e1211278825434 ∧ code e1211278825434 = 5609325336538 := by decide
private def t_e1211278825434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e1211278825434 : ¬ IsSelfInterpreter e1211278825434 :=
  wSource (t := t_e1211278825434) (replay_sound (ps := []) (t := e1211278825434) (by decide)) (by decide)
def e1211278825950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211278825950 : Closed e1211278825950 ∧ code e1211278825950 = 5609325337054 := by decide
private def t_e1211278825950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem cert_e1211278825950 : ¬ IsSelfInterpreter e1211278825950 :=
  wSource (t := t_e1211278825950) (replay_sound (ps := []) (t := e1211278825950) (by decide)) (by decide)
def e1211278825974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211278825974 : Closed e1211278825974 ∧ code e1211278825974 = 5609325337078 := by decide
private def t_e1211278825974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem cert_e1211278825974 : ¬ IsSelfInterpreter e1211278825974 :=
  wSource (t := t_e1211278825974) (replay_sound (ps := []) (t := e1211278825974) (by decide)) (by decide)
def e1211278826718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211278826718 : Closed e1211278826718 ∧ code e1211278826718 = 5609325337822 := by decide
private def t_e1211278826718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem cert_e1211278826718 : ¬ IsSelfInterpreter e1211278826718 :=
  wSource (t := t_e1211278826718) (replay_sound (ps := []) (t := e1211278826718) (by decide)) (by decide)
def e1211278826746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211278826746 : Closed e1211278826746 ∧ code e1211278826746 = 5609325337850 := by decide
private def t_e1211278826746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem cert_e1211278826746 : ¬ IsSelfInterpreter e1211278826746 :=
  wSource (t := t_e1211278826746) (replay_sound (ps := []) (t := e1211278826746) (by decide)) (by decide)
def e1211278827318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211278827318 : Closed e1211278827318 ∧ code e1211278827318 = 5609325338422 := by decide
private def t_e1211278827318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211278827318 : ¬ IsSelfInterpreter e1211278827318 :=
  wSource (t := t_e1211278827318) (replay_sound (ps := []) (t := e1211278827318) (by decide)) (by decide)
def e1211278827322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211278827322 : Closed e1211278827322 ∧ code e1211278827322 = 5609325338426 := by decide
private def t_e1211278827322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211278827322 : ¬ IsSelfInterpreter e1211278827322 :=
  wSource (t := t_e1211278827322) (replay_sound (ps := []) (t := e1211278827322) (by decide)) (by decide)
def e1211278842094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211278842094 : Closed e1211278842094 ∧ code e1211278842094 = 5609325353198 := by decide
private def t_e1211278842094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem cert_e1211278842094 : ¬ IsSelfInterpreter e1211278842094 :=
  wSource (t := t_e1211278842094) (replay_sound (ps := []) (t := e1211278842094) (by decide)) (by decide)
def e1211278842102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211278842102 : Closed e1211278842102 ∧ code e1211278842102 = 5609325353206 := by decide
private def t_e1211278842102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem cert_e1211278842102 : ¬ IsSelfInterpreter e1211278842102 :=
  wSource (t := t_e1211278842102) (replay_sound (ps := []) (t := e1211278842102) (by decide)) (by decide)
def e1211278842654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211278842654 : Closed e1211278842654 ∧ code e1211278842654 = 5609325353758 := by decide
private def t_e1211278842654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem cert_e1211278842654 : ¬ IsSelfInterpreter e1211278842654 :=
  wSource (t := t_e1211278842654) (replay_sound (ps := []) (t := e1211278842654) (by decide)) (by decide)
def e1211278842766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211278842766 : Closed e1211278842766 ∧ code e1211278842766 = 5609325353870 := by decide
private def t_e1211278842766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e1211278842766 : ¬ IsSelfInterpreter e1211278842766 :=
  wSource (t := t_e1211278842766) (replay_sound (ps := []) (t := e1211278842766) (by decide)) (by decide)
def e1211278842990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211278842990 : Closed e1211278842990 ∧ code e1211278842990 = 5609325354094 := by decide
private def t_e1211278842990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem cert_e1211278842990 : ¬ IsSelfInterpreter e1211278842990 :=
  wSource (t := t_e1211278842990) (replay_sound (ps := []) (t := e1211278842990) (by decide)) (by decide)
def e1211278843002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211278843002 : Closed e1211278843002 ∧ code e1211278843002 = 5609325354106 := by decide
private def t_e1211278843002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem cert_e1211278843002 : ¬ IsSelfInterpreter e1211278843002 :=
  wSource (t := t_e1211278843002) (replay_sound (ps := []) (t := e1211278843002) (by decide)) (by decide)
def e1211278843166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211278843166 : Closed e1211278843166 ∧ code e1211278843166 = 5609325354270 := by decide
private def t_e1211278843166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem cert_e1211278843166 : ¬ IsSelfInterpreter e1211278843166 :=
  wSource (t := t_e1211278843166) (replay_sound (ps := []) (t := e1211278843166) (by decide)) (by decide)
def e1211278843334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211278843334 : Closed e1211278843334 ∧ code e1211278843334 = 5609325354438 := by decide
private def t_e1211278843334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e1211278843334 : ¬ IsSelfInterpreter e1211278843334 :=
  wSource (t := t_e1211278843334) (replay_sound (ps := []) (t := e1211278843334) (by decide)) (by decide)
def e1211278843446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211278843446 : Closed e1211278843446 ∧ code e1211278843446 = 5609325354550 := by decide
private def t_e1211278843446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem cert_e1211278843446 : ¬ IsSelfInterpreter e1211278843446 :=
  wSource (t := t_e1211278843446) (replay_sound (ps := []) (t := e1211278843446) (by decide)) (by decide)
def e1211278843450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211278843450 : Closed e1211278843450 ∧ code e1211278843450 = 5609325354554 := by decide
private def t_e1211278843450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem cert_e1211278843450 : ¬ IsSelfInterpreter e1211278843450 :=
  wSource (t := t_e1211278843450) (replay_sound (ps := []) (t := e1211278843450) (by decide)) (by decide)
def e1211278843534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211278843534 : Closed e1211278843534 ∧ code e1211278843534 = 5609325354638 := by decide
private def t_e1211278843534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e1211278843534 : ¬ IsSelfInterpreter e1211278843534 :=
  wSource (t := t_e1211278843534) (replay_sound (ps := []) (t := e1211278843534) (by decide)) (by decide)
def e1211278843590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211278843590 : Closed e1211278843590 ∧ code e1211278843590 = 5609325354694 := by decide
private def t_e1211278843590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e1211278843590 : ¬ IsSelfInterpreter e1211278843590 :=
  wSource (t := t_e1211278843590) (replay_sound (ps := []) (t := e1211278843590) (by decide)) (by decide)
def e1211278845726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211278845726 : Closed e1211278845726 ∧ code e1211278845726 = 5609325356830 := by decide
private def t_e1211278845726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem cert_e1211278845726 : ¬ IsSelfInterpreter e1211278845726 :=
  wSource (t := t_e1211278845726) (replay_sound (ps := []) (t := e1211278845726) (by decide)) (by decide)
def e1211278845838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211278845838 : Closed e1211278845838 ∧ code e1211278845838 = 5609325356942 := by decide
private def t_e1211278845838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem cert_e1211278845838 : ¬ IsSelfInterpreter e1211278845838 :=
  wSource (t := t_e1211278845838) (replay_sound (ps := []) (t := e1211278845838) (by decide)) (by decide)
def e1211278848798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211278848798 : Closed e1211278848798 ∧ code e1211278848798 = 5609325359902 := by decide
private def t_e1211278848798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem cert_e1211278848798 : ¬ IsSelfInterpreter e1211278848798 :=
  wSource (t := t_e1211278848798) (replay_sound (ps := []) (t := e1211278848798) (by decide)) (by decide)
def e1211278848966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211278848966 : Closed e1211278848966 ∧ code e1211278848966 = 5609325360070 := by decide
private def t_e1211278848966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem cert_e1211278848966 : ¬ IsSelfInterpreter e1211278848966 :=
  wSource (t := t_e1211278848966) (replay_sound (ps := []) (t := e1211278848966) (by decide)) (by decide)
def e1211278850446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211278850446 : Closed e1211278850446 ∧ code e1211278850446 = 5609325361550 := by decide
private def t_e1211278850446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e1211278850446 : ¬ IsSelfInterpreter e1211278850446 :=
  wSource (t := t_e1211278850446) (replay_sound (ps := []) (t := e1211278850446) (by decide)) (by decide)
def e1211278850502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211278850502 : Closed e1211278850502 ∧ code e1211278850502 = 5609325361606 := by decide
private def t_e1211278850502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e1211278850502 : ¬ IsSelfInterpreter e1211278850502 :=
  wSource (t := t_e1211278850502) (replay_sound (ps := []) (t := e1211278850502) (by decide)) (by decide)
def e1211281464254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4))))))))))
theorem wire_e1211281464254 : Closed e1211281464254 ∧ code e1211281464254 = 5609327975358 := by decide
theorem cert_e1211281464254 : check e1211281464254 [[],[]] .smaller = true := by decide
def e1211281464302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2))))))))))
theorem wire_e1211281464302 : Closed e1211281464302 ∧ code e1211281464302 = 5609327975406 := by decide
theorem cert_e1211281464302 : check e1211281464302 [[],[]] .smaller = true := by decide
def e1211281465022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4))))))))))
theorem wire_e1211281465022 : Closed e1211281465022 ∧ code e1211281465022 = 5609327976126 := by decide
theorem cert_e1211281465022 : check e1211281465022 [[],[]] .smaller = true := by decide
def e1211281465082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0))))))))))
theorem wire_e1211281465082 : Closed e1211281465082 ∧ code e1211281465082 = 5609327976186 := by decide
theorem cert_e1211281465082 : check e1211281465082 [[],[]] .smaller = true := by decide
def e1211281465262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2))))))))))
theorem wire_e1211281465262 : Closed e1211281465262 ∧ code e1211281465262 = 5609327976366 := by decide
theorem cert_e1211281465262 : check e1211281465262 [[],[]] .smaller = true := by decide
def e1211281465274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0))))))))))
theorem wire_e1211281465274 : Closed e1211281465274 ∧ code e1211281465274 = 5609327976378 := by decide
theorem cert_e1211281465274 : check e1211281465274 [[],[]] .smaller = true := by decide
def e1211281467326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4)))))))))))
theorem wire_e1211281467326 : Closed e1211281467326 ∧ code e1211281467326 = 5609327978430 := by decide
theorem cert_e1211281467326 : check e1211281467326 [[],[]] .smaller = true := by decide
def e1211281467374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2)))))))))))
theorem wire_e1211281467374 : Closed e1211281467374 ∧ code e1211281467374 = 5609327978478 := by decide
theorem cert_e1211281467374 : check e1211281467374 [[],[]] .smaller = true := by decide
def e1211281471934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4)))))))))))
theorem wire_e1211281471934 : Closed e1211281471934 ∧ code e1211281471934 = 5609327983038 := by decide
theorem cert_e1211281471934 : check e1211281471934 [[],[]] .smaller = true := by decide
def e1211281471994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0)))))))))))
theorem wire_e1211281471994 : Closed e1211281471994 ∧ code e1211281471994 = 5609327983098 := by decide
theorem cert_e1211281471994 : check e1211281471994 [[],[]] .smaller = true := by decide
def e1211281473134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211281473134 : Closed e1211281473134 ∧ code e1211281473134 = 5609327984238 := by decide
theorem cert_e1211281473134 : check e1211281473134 [[],[]] .smaller = true := by decide
def e1211281473146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211281473146 : Closed e1211281473146 ∧ code e1211281473146 = 5609327984250 := by decide
theorem cert_e1211281473146 : check e1211281473146 [[],[]] .smaller = true := by decide
def e1211281529566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e1211281529566 : Closed e1211281529566 ∧ code e1211281529566 = 5609328040670 := by decide
theorem cert_e1211281529566 : check e1211281529566 [[],[]] .smaller = true := by decide
def e1211281529590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e1211281529590 : Closed e1211281529590 ∧ code e1211281529590 = 5609328040694 := by decide
theorem cert_e1211281529590 : check e1211281529590 [[],[]] .smaller = true := by decide
def e1211281529694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e1211281529694 : Closed e1211281529694 ∧ code e1211281529694 = 5609328040798 := by decide
theorem cert_e1211281529694 : check e1211281529694 [[],[]] .smaller = true := by decide
def e1211281529710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e1211281529710 : Closed e1211281529710 ∧ code e1211281529710 = 5609328040814 := by decide
theorem cert_e1211281529710 : check e1211281529710 [[],[]] .smaller = true := by decide
def e1211281529718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e1211281529718 : Closed e1211281529718 ∧ code e1211281529718 = 5609328040822 := by decide
theorem cert_e1211281529718 : check e1211281529718 [[],[]] .smaller = true := by decide
def e1211281529722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e1211281529722 : Closed e1211281529722 ∧ code e1211281529722 = 5609328040826 := by decide
theorem cert_e1211281529722 : check e1211281529722 [[],[]] .smaller = true := by decide
def e1211281529782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e1211281529782 : Closed e1211281529782 ∧ code e1211281529782 = 5609328040886 := by decide
theorem cert_e1211281529782 : check e1211281529782 [[],[]] .smaller = true := by decide
def e1211281529814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e1211281529814 : Closed e1211281529814 ∧ code e1211281529814 = 5609328040918 := by decide
theorem cert_e1211281529814 : check e1211281529814 [[],[]] .smaller = true := by decide
def e1211281529818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e1211281529818 : Closed e1211281529818 ∧ code e1211281529818 = 5609328040922 := by decide
theorem cert_e1211281529818 : check e1211281529818 [[],[]] .smaller = true := by decide
def e1211281530206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e1211281530206 : Closed e1211281530206 ∧ code e1211281530206 = 5609328041310 := by decide
theorem cert_e1211281530206 : check e1211281530206 [[],[]] .smaller = true := by decide
def e1211281530222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211281530222 : Closed e1211281530222 ∧ code e1211281530222 = 5609328041326 := by decide
theorem cert_e1211281530222 : check e1211281530222 [[],[]] .smaller = true := by decide
def e1211281530230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211281530230 : Closed e1211281530230 ∧ code e1211281530230 = 5609328041334 := by decide
theorem cert_e1211281530230 : check e1211281530230 [[],[]] .smaller = true := by decide
def e1211281530234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e1211281530234 : Closed e1211281530234 ∧ code e1211281530234 = 5609328041338 := by decide
theorem cert_e1211281530234 : check e1211281530234 [[],[]] .smaller = true := by decide
def e1211281530286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211281530286 : Closed e1211281530286 ∧ code e1211281530286 = 5609328041390 := by decide
theorem cert_e1211281530286 : check e1211281530286 [[],[]] .smaller = true := by decide
def e1211281530298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211281530298 : Closed e1211281530298 ∧ code e1211281530298 = 5609328041402 := by decide
theorem cert_e1211281530298 : check e1211281530298 [[],[]] .smaller = true := by decide
def e1211281530326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211281530326 : Closed e1211281530326 ∧ code e1211281530326 = 5609328041430 := by decide
theorem cert_e1211281530326 : check e1211281530326 [[],[]] .smaller = true := by decide
def e1211281530330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211281530330 : Closed e1211281530330 ∧ code e1211281530330 = 5609328041434 := by decide
theorem cert_e1211281530330 : check e1211281530330 [[],[]] .smaller = true := by decide
def e1211281530346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e1211281530346 : Closed e1211281530346 ∧ code e1211281530346 = 5609328041450 := by decide
theorem cert_e1211281530346 : check e1211281530346 [[],[]] .smaller = true := by decide
def e1211281530550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211281530550 : Closed e1211281530550 ∧ code e1211281530550 = 5609328041654 := by decide
theorem cert_e1211281530550 : check e1211281530550 [[],[]] .smaller = true := by decide
def e1211281530582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211281530582 : Closed e1211281530582 ∧ code e1211281530582 = 5609328041686 := by decide
theorem cert_e1211281530582 : check e1211281530582 [[],[]] .smaller = true := by decide
def e1211281530586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211281530586 : Closed e1211281530586 ∧ code e1211281530586 = 5609328041690 := by decide
theorem cert_e1211281530586 : check e1211281530586 [[],[]] .smaller = true := by decide
def e1211281530710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211281530710 : Closed e1211281530710 ∧ code e1211281530710 = 5609328041814 := by decide
theorem cert_e1211281530710 : check e1211281530710 [[],[]] .smaller = true := by decide
def e1211281530714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211281530714 : Closed e1211281530714 ∧ code e1211281530714 = 5609328041818 := by decide
theorem cert_e1211281530714 : check e1211281530714 [[],[]] .smaller = true := by decide
def e1211281530730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211281530730 : Closed e1211281530730 ∧ code e1211281530730 = 5609328041834 := by decide
theorem cert_e1211281530730 : check e1211281530730 [[],[]] .smaller = true := by decide
def e1211281531870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3)))))))))
theorem wire_e1211281531870 : Closed e1211281531870 ∧ code e1211281531870 = 5609328042974 := by decide
theorem cert_e1211281531870 : check e1211281531870 [[],[]] .smaller = true := by decide
def e1211281531886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2)))))))))
theorem wire_e1211281531886 : Closed e1211281531886 ∧ code e1211281531886 = 5609328042990 := by decide
theorem cert_e1211281531886 : check e1211281531886 [[],[]] .smaller = true := by decide
def e1211281532638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e1211281532638 : Closed e1211281532638 ∧ code e1211281532638 = 5609328043742 := by decide
theorem cert_e1211281532638 : check e1211281532638 [[],[]] .smaller = true := by decide
def e1211281532662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e1211281532662 : Closed e1211281532662 ∧ code e1211281532662 = 5609328043766 := by decide
theorem cert_e1211281532662 : check e1211281532662 [[],[]] .smaller = true := by decide
def e1211281532766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e1211281532766 : Closed e1211281532766 ∧ code e1211281532766 = 5609328043870 := by decide
theorem cert_e1211281532766 : check e1211281532766 [[],[]] .smaller = true := by decide
def e1211281532782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e1211281532782 : Closed e1211281532782 ∧ code e1211281532782 = 5609328043886 := by decide
theorem cert_e1211281532782 : check e1211281532782 [[],[]] .smaller = true := by decide
def e1211281532790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e1211281532790 : Closed e1211281532790 ∧ code e1211281532790 = 5609328043894 := by decide
theorem cert_e1211281532790 : check e1211281532790 [[],[]] .smaller = true := by decide
def e1211281532794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e1211281532794 : Closed e1211281532794 ∧ code e1211281532794 = 5609328043898 := by decide
theorem cert_e1211281532794 : check e1211281532794 [[],[]] .smaller = true := by decide
end Blc.Floor42
