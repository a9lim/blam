import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186818746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e1211186818746 : Closed e1211186818746 ∧ code e1211186818746 = 5609233329850 := by decide
theorem cert_e1211186818746 : check e1211186818746 [[],[]] .smaller = true := by decide
def e1211186818794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186818794 : Closed e1211186818794 ∧ code e1211186818794 = 5609233329898 := by decide
theorem cert_e1211186818794 : check e1211186818794 [[],[]] .smaller = true := by decide
def e1211186818906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e1211186818906 : Closed e1211186818906 ∧ code e1211186818906 = 5609233330010 := by decide
theorem cert_e1211186818906 : check e1211186818906 [[],[]] .smaller = true := by decide
def e1211186818922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186818922 : Closed e1211186818922 ∧ code e1211186818922 = 5609233330026 := by decide
theorem cert_e1211186818922 : check e1211186818922 [[],[]] .smaller = true := by decide
def e1211186818986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186818986 : Closed e1211186818986 ∧ code e1211186818986 = 5609233330090 := by decide
theorem cert_e1211186818986 : check e1211186818986 [[],[]] .smaller = true := by decide
def e1211186819950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e1211186819950 : Closed e1211186819950 ∧ code e1211186819950 = 5609233331054 := by decide
theorem cert_e1211186819950 : check e1211186819950 [[],[]] .smaller = true := by decide
def e1211186819962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e1211186819962 : Closed e1211186819962 ∧ code e1211186819962 = 5609233331066 := by decide
theorem cert_e1211186819962 : check e1211186819962 [[],[]] .smaller = true := by decide
def e1211186820014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e1211186820014 : Closed e1211186820014 ∧ code e1211186820014 = 5609233331118 := by decide
theorem cert_e1211186820014 : check e1211186820014 [[],[]] .smaller = true := by decide
def e1211186820026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e1211186820026 : Closed e1211186820026 ∧ code e1211186820026 = 5609233331130 := by decide
theorem cert_e1211186820026 : check e1211186820026 [[],[]] .smaller = true := by decide
def e1211186820058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e1211186820058 : Closed e1211186820058 ∧ code e1211186820058 = 5609233331162 := by decide
theorem cert_e1211186820058 : check e1211186820058 [[],[]] .smaller = true := by decide
def e1211186820074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e1211186820074 : Closed e1211186820074 ∧ code e1211186820074 = 5609233331178 := by decide
theorem cert_e1211186820074 : check e1211186820074 [[],[]] .smaller = true := by decide
def e1211186820318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186820318 : Closed e1211186820318 ∧ code e1211186820318 = 5609233331422 := by decide
theorem cert_e1211186820318 : check e1211186820318 [[],[]] .three = true := by decide
def e1211186820346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186820346 : Closed e1211186820346 ∧ code e1211186820346 = 5609233331450 := by decide
theorem cert_e1211186820346 : check e1211186820346 [[],[]] .three = true := by decide
def e1211186820718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186820718 : Closed e1211186820718 ∧ code e1211186820718 = 5609233331822 := by decide
theorem cert_e1211186820718 : check e1211186820718 [[],[]] .smaller = true := by decide
def e1211186820730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186820730 : Closed e1211186820730 ∧ code e1211186820730 = 5609233331834 := by decide
theorem cert_e1211186820730 : check e1211186820730 [[],[]] .smaller = true := by decide
def e1211186821018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186821018 : Closed e1211186821018 ∧ code e1211186821018 = 5609233332122 := by decide
theorem cert_e1211186821018 : check e1211186821018 [[],[]] .smaller = true := by decide
def e1211186821358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e1211186821358 : Closed e1211186821358 ∧ code e1211186821358 = 5609233332462 := by decide
theorem cert_e1211186821358 : check e1211186821358 [[],[]] .smaller = true := by decide
def e1211186821370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 0)))))))
theorem wire_e1211186821370 : Closed e1211186821370 ∧ code e1211186821370 = 5609233332474 := by decide
theorem cert_e1211186821370 : check e1211186821370 [[],[]] .smaller = true := by decide
def e1211186821550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e1211186821550 : Closed e1211186821550 ∧ code e1211186821550 = 5609233332654 := by decide
theorem cert_e1211186821550 : check e1211186821550 [[],[]] .smaller = true := by decide
def e1211186821562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e1211186821562 : Closed e1211186821562 ∧ code e1211186821562 = 5609233332666 := by decide
theorem cert_e1211186821562 : check e1211186821562 [[],[]] .smaller = true := by decide
def e1211186821610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e1211186821610 : Closed e1211186821610 ∧ code e1211186821610 = 5609233332714 := by decide
theorem cert_e1211186821610 : check e1211186821610 [[],[]] .smaller = true := by decide
def e1211186821742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186821742 : Closed e1211186821742 ∧ code e1211186821742 = 5609233332846 := by decide
theorem cert_e1211186821742 : check e1211186821742 [[],[]] .smaller = true := by decide
def e1211186821754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186821754 : Closed e1211186821754 ∧ code e1211186821754 = 5609233332858 := by decide
theorem cert_e1211186821754 : check e1211186821754 [[],[]] .smaller = true := by decide
def e1211186821918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e1211186821918 : Closed e1211186821918 ∧ code e1211186821918 = 5609233333022 := by decide
theorem cert_e1211186821918 : check e1211186821918 [[],[]] .smaller = true := by decide
def e1211186822086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 1))))))))
theorem wire_e1211186822086 : Closed e1211186822086 ∧ code e1211186822086 = 5609233333190 := by decide
theorem cert_e1211186822086 : check e1211186822086 [[],[]] .smaller = true := by decide
def e1211186822362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e1211186822362 : Closed e1211186822362 ∧ code e1211186822362 = 5609233333466 := by decide
theorem cert_e1211186822362 : check e1211186822362 [[],[]] .smaller = true := by decide
def e1211186822378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e1211186822378 : Closed e1211186822378 ∧ code e1211186822378 = 5609233333482 := by decide
theorem cert_e1211186822378 : check e1211186822378 [[],[]] .smaller = true := by decide
def e1211186822714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e1211186822714 : Closed e1211186822714 ∧ code e1211186822714 = 5609233333818 := by decide
theorem cert_e1211186822714 : check e1211186822714 [[],[]] .smaller = true := by decide
def e1211186822762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e1211186822762 : Closed e1211186822762 ∧ code e1211186822762 = 5609233333866 := by decide
theorem cert_e1211186822762 : check e1211186822762 [[],[]] .smaller = true := by decide
def e1211186822810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186822810 : Closed e1211186822810 ∧ code e1211186822810 = 5609233333914 := by decide
theorem cert_e1211186822810 : check e1211186822810 [[],[]] .smaller = true := by decide
def e1211186822854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e1211186822854 : Closed e1211186822854 ∧ code e1211186822854 = 5609233333958 := by decide
theorem cert_e1211186822854 : check e1211186822854 [[],[]] .smaller = true := by decide
def e1211186826078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1211186826078 : Closed e1211186826078 ∧ code e1211186826078 = 5609233337182 := by decide
theorem cert_e1211186826078 : check e1211186826078 [[],[]] .three = true := by decide
def e1211186826094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211186826094 : Closed e1211186826094 ∧ code e1211186826094 = 5609233337198 := by decide
theorem cert_e1211186826094 : check e1211186826094 [[],[]] .smaller = true := by decide
def e1211186826102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211186826102 : Closed e1211186826102 ∧ code e1211186826102 = 5609233337206 := by decide
theorem cert_e1211186826102 : check e1211186826102 [[],[]] .smaller = true := by decide
def e1211186826106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1211186826106 : Closed e1211186826106 ∧ code e1211186826106 = 5609233337210 := by decide
theorem cert_e1211186826106 : check e1211186826106 [[],[]] .three = true := by decide
def e1211186826158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211186826158 : Closed e1211186826158 ∧ code e1211186826158 = 5609233337262 := by decide
theorem cert_e1211186826158 : check e1211186826158 [[],[]] .smaller = true := by decide
def e1211186826170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211186826170 : Closed e1211186826170 ∧ code e1211186826170 = 5609233337274 := by decide
theorem cert_e1211186826170 : check e1211186826170 [[],[]] .smaller = true := by decide
def e1211186826198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211186826198 : Closed e1211186826198 ∧ code e1211186826198 = 5609233337302 := by decide
theorem cert_e1211186826198 : check e1211186826198 [[],[]] .smaller = true := by decide
def e1211186826202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211186826202 : Closed e1211186826202 ∧ code e1211186826202 = 5609233337306 := by decide
theorem cert_e1211186826202 : check e1211186826202 [[],[]] .smaller = true := by decide
def e1211186826218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1211186826218 : Closed e1211186826218 ∧ code e1211186826218 = 5609233337322 := by decide
theorem cert_e1211186826218 : check e1211186826218 [[],[]] .three = true := by decide
def e1211186826462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186826462 : Closed e1211186826462 ∧ code e1211186826462 = 5609233337566 := by decide
theorem cert_e1211186826462 : check e1211186826462 [[],[]] .three = true := by decide
def e1211186826478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186826478 : Closed e1211186826478 ∧ code e1211186826478 = 5609233337582 := by decide
theorem cert_e1211186826478 : check e1211186826478 [[],[]] .smaller = true := by decide
def e1211186826486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186826486 : Closed e1211186826486 ∧ code e1211186826486 = 5609233337590 := by decide
theorem cert_e1211186826486 : check e1211186826486 [[],[]] .smaller = true := by decide
def e1211186826490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186826490 : Closed e1211186826490 ∧ code e1211186826490 = 5609233337594 := by decide
theorem cert_e1211186826490 : check e1211186826490 [[],[]] .three = true := by decide
def e1211186826862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186826862 : Closed e1211186826862 ∧ code e1211186826862 = 5609233337966 := by decide
theorem cert_e1211186826862 : check e1211186826862 [[],[]] .smaller = true := by decide
def e1211186826874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186826874 : Closed e1211186826874 ∧ code e1211186826874 = 5609233337978 := by decide
theorem cert_e1211186826874 : check e1211186826874 [[],[]] .smaller = true := by decide
def e1211186827062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186827062 : Closed e1211186827062 ∧ code e1211186827062 = 5609233338166 := by decide
theorem cert_e1211186827062 : check e1211186827062 [[],[]] .smaller = true := by decide
def e1211186827066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186827066 : Closed e1211186827066 ∧ code e1211186827066 = 5609233338170 := by decide
theorem cert_e1211186827066 : check e1211186827066 [[],[]] .smaller = true := by decide
def e1211186827162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186827162 : Closed e1211186827162 ∧ code e1211186827162 = 5609233338266 := by decide
theorem cert_e1211186827162 : check e1211186827162 [[],[]] .three = true := by decide
def e1211186831838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186831838 : Closed e1211186831838 ∧ code e1211186831838 = 5609233342942 := by decide
theorem cert_e1211186831838 : check e1211186831838 [[],[]] .smaller = true := by decide
def e1211186831862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186831862 : Closed e1211186831862 ∧ code e1211186831862 = 5609233342966 := by decide
theorem cert_e1211186831862 : check e1211186831862 [[],[]] .smaller = true := by decide
def e1211186832814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211186832814 : Closed e1211186832814 ∧ code e1211186832814 = 5609233343918 := by decide
theorem cert_e1211186832814 : check e1211186832814 [[],[]] .smaller = true := by decide
def e1211186832826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211186832826 : Closed e1211186832826 ∧ code e1211186832826 = 5609233343930 := by decide
theorem cert_e1211186832826 : check e1211186832826 [[],[]] .smaller = true := by decide
def e1211186832874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211186832874 : Closed e1211186832874 ∧ code e1211186832874 = 5609233343978 := by decide
theorem cert_e1211186832874 : check e1211186832874 [[],[]] .smaller = true := by decide
def e1211186832958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e1211186832958 : Closed e1211186832958 ∧ code e1211186832958 = 5609233344062 := by decide
theorem cert_e1211186832958 : check e1211186832958 [[],[]] .three = true := by decide
def e1211186833006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186833006 : Closed e1211186833006 ∧ code e1211186833006 = 5609233344110 := by decide
theorem cert_e1211186833006 : check e1211186833006 [[],[]] .smaller = true := by decide
def e1211186833018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186833018 : Closed e1211186833018 ∧ code e1211186833018 = 5609233344122 := by decide
theorem cert_e1211186833018 : check e1211186833018 [[],[]] .smaller = true := by decide
def e1211186833182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211186833182 : Closed e1211186833182 ∧ code e1211186833182 = 5609233344286 := by decide
theorem cert_e1211186833182 : check e1211186833182 [[],[]] .smaller = true := by decide
def e1211186833294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211186833294 : Closed e1211186833294 ∧ code e1211186833294 = 5609233344398 := by decide
theorem cert_e1211186833294 : check e1211186833294 [[],[]] .smaller = true := by decide
def e1211186833306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186833306 : Closed e1211186833306 ∧ code e1211186833306 = 5609233344410 := by decide
theorem cert_e1211186833306 : check e1211186833306 [[],[]] .smaller = true := by decide
def e1211186833350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e1211186833350 : Closed e1211186833350 ∧ code e1211186833350 = 5609233344454 := by decide
theorem cert_e1211186833350 : check e1211186833350 [[],[]] .three = true := by decide
def e1211186833374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 3))))))))
theorem wire_e1211186833374 : Closed e1211186833374 ∧ code e1211186833374 = 5609233344478 := by decide
theorem cert_e1211186833374 : check e1211186833374 [[],[]] .three = true := by decide
def e1211186836254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186836254 : Closed e1211186836254 ∧ code e1211186836254 = 5609233347358 := by decide
theorem cert_e1211186836254 : check e1211186836254 [[],[]] .smaller = true := by decide
def e1211186836422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186836422 : Closed e1211186836422 ∧ code e1211186836422 = 5609233347526 := by decide
theorem cert_e1211186836422 : check e1211186836422 [[],[]] .smaller = true := by decide
def e1211186836446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186836446 : Closed e1211186836446 ∧ code e1211186836446 = 5609233347550 := by decide
theorem cert_e1211186836446 : check e1211186836446 [[],[]] .three = true := by decide
def e1211186836462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186836462 : Closed e1211186836462 ∧ code e1211186836462 = 5609233347566 := by decide
theorem cert_e1211186836462 : check e1211186836462 [[],[]] .three = true := by decide
def e1211186837622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186837622 : Closed e1211186837622 ∧ code e1211186837622 = 5609233348726 := by decide
theorem cert_e1211186837622 : check e1211186837622 [[],[]] .smaller = true := by decide
def e1211186837866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211186837866 : Closed e1211186837866 ∧ code e1211186837866 = 5609233348970 := by decide
theorem cert_e1211186837866 : check e1211186837866 [[],[]] .smaller = true := by decide
def e1211186837902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211186837902 : Closed e1211186837902 ∧ code e1211186837902 = 5609233349006 := by decide
theorem cert_e1211186837902 : check e1211186837902 [[],[]] .smaller = true := by decide
def e1211186837914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186837914 : Closed e1211186837914 ∧ code e1211186837914 = 5609233349018 := by decide
theorem cert_e1211186837914 : check e1211186837914 [[],[]] .smaller = true := by decide
def e1211186837958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211186837958 : Closed e1211186837958 ∧ code e1211186837958 = 5609233349062 := by decide
theorem cert_e1211186837958 : check e1211186837958 [[],[]] .smaller = true := by decide
def e1211186837982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186837982 : Closed e1211186837982 ∧ code e1211186837982 = 5609233349086 := by decide
theorem cert_e1211186837982 : check e1211186837982 [[],[]] .three = true := by decide
def e1211186838006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186838006 : Closed e1211186838006 ∧ code e1211186838006 = 5609233349110 := by decide
theorem cert_e1211186838006 : check e1211186838006 [[],[]] .three = true := by decide
def e1211186838726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186838726 : Closed e1211186838726 ∧ code e1211186838726 = 5609233349830 := by decide
theorem cert_e1211186838726 : check e1211186838726 [[],[]] .three = true := by decide
def e1211186838750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186838750 : Closed e1211186838750 ∧ code e1211186838750 = 5609233349854 := by decide
theorem cert_e1211186838750 : check e1211186838750 [[],[]] .three = true := by decide
def e1211186838766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186838766 : Closed e1211186838766 ∧ code e1211186838766 = 5609233349870 := by decide
theorem cert_e1211186838766 : check e1211186838766 [[],[]] .three = true := by decide
def e1211186838774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186838774 : Closed e1211186838774 ∧ code e1211186838774 = 5609233349878 := by decide
theorem cert_e1211186838774 : check e1211186838774 [[],[]] .three = true := by decide
def e1211186838778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186838778 : Closed e1211186838778 ∧ code e1211186838778 = 5609233349882 := by decide
theorem cert_e1211186838778 : check e1211186838778 [[],[]] .three = true := by decide
def e1211186852190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 3)))))))
theorem wire_e1211186852190 : Closed e1211186852190 ∧ code e1211186852190 = 5609233363294 := by decide
theorem cert_e1211186852190 : check e1211186852190 [[],[]] .three = true := by decide
def e1211186852206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2)))))))
theorem wire_e1211186852206 : Closed e1211186852206 ∧ code e1211186852206 = 5609233363310 := by decide
theorem cert_e1211186852206 : check e1211186852206 [[],[]] .smaller = true := by decide
def e1211186852214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1)))))))
theorem wire_e1211186852214 : Closed e1211186852214 ∧ code e1211186852214 = 5609233363318 := by decide
theorem cert_e1211186852214 : check e1211186852214 [[],[]] .smaller = true := by decide
def e1211186852218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))) (.var 0)))))))
theorem wire_e1211186852218 : Closed e1211186852218 ∧ code e1211186852218 = 5609233363322 := by decide
theorem cert_e1211186852218 : check e1211186852218 [[],[]] .three = true := by decide
def e1211186852270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 2)))))))
theorem wire_e1211186852270 : Closed e1211186852270 ∧ code e1211186852270 = 5609233363374 := by decide
theorem cert_e1211186852270 : check e1211186852270 [[],[]] .smaller = true := by decide
def e1211186852282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 0)))))))
theorem wire_e1211186852282 : Closed e1211186852282 ∧ code e1211186852282 = 5609233363386 := by decide
theorem cert_e1211186852282 : check e1211186852282 [[],[]] .smaller = true := by decide
def e1211186852330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 0)))))))
theorem wire_e1211186852330 : Closed e1211186852330 ∧ code e1211186852330 = 5609233363434 := by decide
theorem cert_e1211186852330 : check e1211186852330 [[],[]] .smaller = true := by decide
def e1211186852958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e1211186852958 : Closed e1211186852958 ∧ code e1211186852958 = 5609233364062 := by decide
theorem cert_e1211186852958 : check e1211186852958 [[],[]] .three = true := by decide
def e1211186852974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186852974 : Closed e1211186852974 ∧ code e1211186852974 = 5609233364078 := by decide
theorem cert_e1211186852974 : check e1211186852974 [[],[]] .smaller = true := by decide
def e1211186852986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186852986 : Closed e1211186852986 ∧ code e1211186852986 = 5609233364090 := by decide
theorem cert_e1211186852986 : check e1211186852986 [[],[]] .smaller = true := by decide
def e1211186853150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186853150 : Closed e1211186853150 ∧ code e1211186853150 = 5609233364254 := by decide
theorem cert_e1211186853150 : check e1211186853150 [[],[]] .smaller = true := by decide
def e1211186853318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186853318 : Closed e1211186853318 ∧ code e1211186853318 = 5609233364422 := by decide
theorem cert_e1211186853318 : check e1211186853318 [[],[]] .smaller = true := by decide
def e1211186853342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e1211186853342 : Closed e1211186853342 ∧ code e1211186853342 = 5609233364446 := by decide
theorem cert_e1211186853342 : check e1211186853342 [[],[]] .three = true := by decide
def e1211186853346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211186853346 : Closed e1211186853346 ∧ code e1211186853346 = 5609233364450 := by decide
theorem cert_e1211186853346 : check e1211186853346 [[],[]] .three = true := by decide
def e1211186853358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e1211186853358 : Closed e1211186853358 ∧ code e1211186853358 = 5609233364462 := by decide
theorem cert_e1211186853358 : check e1211186853358 [[],[]] .three = true := by decide
def e1211186853422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211186853422 : Closed e1211186853422 ∧ code e1211186853422 = 5609233364526 := by decide
theorem cert_e1211186853422 : check e1211186853422 [[],[]] .smaller = true := by decide
def e1211186853598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e1211186853598 : Closed e1211186853598 ∧ code e1211186853598 = 5609233364702 := by decide
theorem cert_e1211186853598 : check e1211186853598 [[],[]] .three = true := by decide
def e1211186853602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211186853602 : Closed e1211186853602 ∧ code e1211186853602 = 5609233364706 := by decide
theorem cert_e1211186853602 : check e1211186853602 [[],[]] .smaller = true := by decide
def e1211186853614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2)))))))
theorem wire_e1211186853614 : Closed e1211186853614 ∧ code e1211186853614 = 5609233364718 := by decide
theorem cert_e1211186853614 : check e1211186853614 [[],[]] .smaller = true := by decide
def e1211186853622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e1211186853622 : Closed e1211186853622 ∧ code e1211186853622 = 5609233364726 := by decide
theorem cert_e1211186853622 : check e1211186853622 [[],[]] .three = true := by decide
def e1211186853654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186853654 : Closed e1211186853654 ∧ code e1211186853654 = 5609233364758 := by decide
theorem cert_e1211186853654 : check e1211186853654 [[],[]] .smaller = true := by decide
def e1211186853658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186853658 : Closed e1211186853658 ∧ code e1211186853658 = 5609233364762 := by decide
theorem cert_e1211186853658 : check e1211186853658 [[],[]] .smaller = true := by decide
def e1211186853702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186853702 : Closed e1211186853702 ∧ code e1211186853702 = 5609233364806 := by decide
theorem cert_e1211186853702 : check e1211186853702 [[],[]] .smaller = true := by decide
def e1211186853726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e1211186853726 : Closed e1211186853726 ∧ code e1211186853726 = 5609233364830 := by decide
theorem cert_e1211186853726 : check e1211186853726 [[],[]] .three = true := by decide
def e1211186853730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186853730 : Closed e1211186853730 ∧ code e1211186853730 = 5609233364834 := by decide
theorem cert_e1211186853730 : check e1211186853730 [[],[]] .smaller = true := by decide
def e1211186853742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2)))))))
theorem wire_e1211186853742 : Closed e1211186853742 ∧ code e1211186853742 = 5609233364846 := by decide
theorem cert_e1211186853742 : check e1211186853742 [[],[]] .smaller = true := by decide
def e1211186853750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1)))))))
theorem wire_e1211186853750 : Closed e1211186853750 ∧ code e1211186853750 = 5609233364854 := by decide
theorem cert_e1211186853750 : check e1211186853750 [[],[]] .smaller = true := by decide
def e1211186853754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e1211186853754 : Closed e1211186853754 ∧ code e1211186853754 = 5609233364858 := by decide
theorem cert_e1211186853754 : check e1211186853754 [[],[]] .three = true := by decide
def e1211186853770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186853770 : Closed e1211186853770 ∧ code e1211186853770 = 5609233364874 := by decide
theorem cert_e1211186853770 : check e1211186853770 [[],[]] .three = true := by decide
def e1211186853794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186853794 : Closed e1211186853794 ∧ code e1211186853794 = 5609233364898 := by decide
theorem cert_e1211186853794 : check e1211186853794 [[],[]] .three = true := by decide
def e1211186853806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e1211186853806 : Closed e1211186853806 ∧ code e1211186853806 = 5609233364910 := by decide
theorem cert_e1211186853806 : check e1211186853806 [[],[]] .three = true := by decide
def e1211186853814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e1211186853814 : Closed e1211186853814 ∧ code e1211186853814 = 5609233364918 := by decide
theorem cert_e1211186853814 : check e1211186853814 [[],[]] .three = true := by decide
def e1211186853818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e1211186853818 : Closed e1211186853818 ∧ code e1211186853818 = 5609233364922 := by decide
theorem cert_e1211186853818 : check e1211186853818 [[],[]] .three = true := by decide
def e1211186854062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e1211186854062 : Closed e1211186854062 ∧ code e1211186854062 = 5609233365166 := by decide
theorem cert_e1211186854062 : check e1211186854062 [[],[]] .smaller = true := by decide
def e1211186854074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e1211186854074 : Closed e1211186854074 ∧ code e1211186854074 = 5609233365178 := by decide
theorem cert_e1211186854074 : check e1211186854074 [[],[]] .smaller = true := by decide
def e1211186854446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211186854446 : Closed e1211186854446 ∧ code e1211186854446 = 5609233365550 := by decide
theorem cert_e1211186854446 : check e1211186854446 [[],[]] .smaller = true := by decide
def e1211186854622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e1211186854622 : Closed e1211186854622 ∧ code e1211186854622 = 5609233365726 := by decide
theorem cert_e1211186854622 : check e1211186854622 [[],[]] .three = true := by decide
def e1211186854626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211186854626 : Closed e1211186854626 ∧ code e1211186854626 = 5609233365730 := by decide
theorem cert_e1211186854626 : check e1211186854626 [[],[]] .smaller = true := by decide
def e1211186854638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e1211186854638 : Closed e1211186854638 ∧ code e1211186854638 = 5609233365742 := by decide
theorem cert_e1211186854638 : check e1211186854638 [[],[]] .smaller = true := by decide
def e1211186854646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e1211186854646 : Closed e1211186854646 ∧ code e1211186854646 = 5609233365750 := by decide
theorem cert_e1211186854646 : check e1211186854646 [[],[]] .three = true := by decide
def e1211186854750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e1211186854750 : Closed e1211186854750 ∧ code e1211186854750 = 5609233365854 := by decide
theorem cert_e1211186854750 : check e1211186854750 [[],[]] .three = true := by decide
def e1211186854778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e1211186854778 : Closed e1211186854778 ∧ code e1211186854778 = 5609233365882 := by decide
theorem cert_e1211186854778 : check e1211186854778 [[],[]] .three = true := by decide
def e1211186854794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186854794 : Closed e1211186854794 ∧ code e1211186854794 = 5609233365898 := by decide
theorem cert_e1211186854794 : check e1211186854794 [[],[]] .smaller = true := by decide
def e1211186854818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186854818 : Closed e1211186854818 ∧ code e1211186854818 = 5609233365922 := by decide
theorem cert_e1211186854818 : check e1211186854818 [[],[]] .smaller = true := by decide
def e1211186854830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e1211186854830 : Closed e1211186854830 ∧ code e1211186854830 = 5609233365934 := by decide
theorem cert_e1211186854830 : check e1211186854830 [[],[]] .smaller = true := by decide
def e1211186854842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e1211186854842 : Closed e1211186854842 ∧ code e1211186854842 = 5609233365946 := by decide
theorem cert_e1211186854842 : check e1211186854842 [[],[]] .smaller = true := by decide
def e1211186854870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e1211186854870 : Closed e1211186854870 ∧ code e1211186854870 = 5609233365974 := by decide
theorem cert_e1211186854870 : check e1211186854870 [[],[]] .three = true := by decide
def e1211186854874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e1211186854874 : Closed e1211186854874 ∧ code e1211186854874 = 5609233365978 := by decide
theorem cert_e1211186854874 : check e1211186854874 [[],[]] .three = true := by decide
def e1211186854998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e1211186854998 : Closed e1211186854998 ∧ code e1211186854998 = 5609233366102 := by decide
theorem cert_e1211186854998 : check e1211186854998 [[],[]] .smaller = true := by decide
def e1211186855002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e1211186855002 : Closed e1211186855002 ∧ code e1211186855002 = 5609233366106 := by decide
theorem cert_e1211186855002 : check e1211186855002 [[],[]] .smaller = true := by decide
def e1211186855018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e1211186855018 : Closed e1211186855018 ∧ code e1211186855018 = 5609233366122 := by decide
theorem cert_e1211186855018 : check e1211186855018 [[],[]] .smaller = true := by decide
def e1211186855190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186855190 : Closed e1211186855190 ∧ code e1211186855190 = 5609233366294 := by decide
theorem cert_e1211186855190 : check e1211186855190 [[],[]] .smaller = true := by decide
def e1211186855194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186855194 : Closed e1211186855194 ∧ code e1211186855194 = 5609233366298 := by decide
theorem cert_e1211186855194 : check e1211186855194 [[],[]] .smaller = true := by decide
def e1211186855238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186855238 : Closed e1211186855238 ∧ code e1211186855238 = 5609233366342 := by decide
theorem cert_e1211186855238 : check e1211186855238 [[],[]] .smaller = true := by decide
def e1211186855262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e1211186855262 : Closed e1211186855262 ∧ code e1211186855262 = 5609233366366 := by decide
theorem cert_e1211186855262 : check e1211186855262 [[],[]] .three = true := by decide
def e1211186855266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186855266 : Closed e1211186855266 ∧ code e1211186855266 = 5609233366370 := by decide
theorem cert_e1211186855266 : check e1211186855266 [[],[]] .smaller = true := by decide
def e1211186855278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211186855278 : Closed e1211186855278 ∧ code e1211186855278 = 5609233366382 := by decide
theorem cert_e1211186855278 : check e1211186855278 [[],[]] .smaller = true := by decide
def e1211186855286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211186855286 : Closed e1211186855286 ∧ code e1211186855286 = 5609233366390 := by decide
theorem cert_e1211186855286 : check e1211186855286 [[],[]] .smaller = true := by decide
def e1211186855290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e1211186855290 : Closed e1211186855290 ∧ code e1211186855290 = 5609233366394 := by decide
theorem cert_e1211186855290 : check e1211186855290 [[],[]] .three = true := by decide
def e1211186855306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186855306 : Closed e1211186855306 ∧ code e1211186855306 = 5609233366410 := by decide
theorem cert_e1211186855306 : check e1211186855306 [[],[]] .smaller = true := by decide
def e1211186855330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186855330 : Closed e1211186855330 ∧ code e1211186855330 = 5609233366434 := by decide
theorem cert_e1211186855330 : check e1211186855330 [[],[]] .smaller = true := by decide
def e1211186855342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211186855342 : Closed e1211186855342 ∧ code e1211186855342 = 5609233366446 := by decide
theorem cert_e1211186855342 : check e1211186855342 [[],[]] .smaller = true := by decide
def e1211186855354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211186855354 : Closed e1211186855354 ∧ code e1211186855354 = 5609233366458 := by decide
theorem cert_e1211186855354 : check e1211186855354 [[],[]] .smaller = true := by decide
def e1211186855382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211186855382 : Closed e1211186855382 ∧ code e1211186855382 = 5609233366486 := by decide
theorem cert_e1211186855382 : check e1211186855382 [[],[]] .smaller = true := by decide
def e1211186855386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211186855386 : Closed e1211186855386 ∧ code e1211186855386 = 5609233366490 := by decide
theorem cert_e1211186855386 : check e1211186855386 [[],[]] .smaller = true := by decide
def e1211186855402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e1211186855402 : Closed e1211186855402 ∧ code e1211186855402 = 5609233366506 := by decide
theorem cert_e1211186855402 : check e1211186855402 [[],[]] .three = true := by decide
def e1211186855466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e1211186855466 : Closed e1211186855466 ∧ code e1211186855466 = 5609233366570 := by decide
theorem cert_e1211186855466 : check e1211186855466 [[],[]] .three = true := by decide
def e1211186855562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186855562 : Closed e1211186855562 ∧ code e1211186855562 = 5609233366666 := by decide
theorem cert_e1211186855562 : check e1211186855562 [[],[]] .three = true := by decide
def e1211186855586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186855586 : Closed e1211186855586 ∧ code e1211186855586 = 5609233366690 := by decide
theorem cert_e1211186855586 : check e1211186855586 [[],[]] .three = true := by decide
def e1211186855598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211186855598 : Closed e1211186855598 ∧ code e1211186855598 = 5609233366702 := by decide
theorem cert_e1211186855598 : check e1211186855598 [[],[]] .three = true := by decide
def e1211186855606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211186855606 : Closed e1211186855606 ∧ code e1211186855606 = 5609233366710 := by decide
theorem cert_e1211186855606 : check e1211186855606 [[],[]] .three = true := by decide
def e1211186855610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211186855610 : Closed e1211186855610 ∧ code e1211186855610 = 5609233366714 := by decide
theorem cert_e1211186855610 : check e1211186855610 [[],[]] .three = true := by decide
def e1211186855638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211186855638 : Closed e1211186855638 ∧ code e1211186855638 = 5609233366742 := by decide
theorem cert_e1211186855638 : check e1211186855638 [[],[]] .three = true := by decide
def e1211186855642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211186855642 : Closed e1211186855642 ∧ code e1211186855642 = 5609233366746 := by decide
theorem cert_e1211186855642 : check e1211186855642 [[],[]] .three = true := by decide
def e1211186855658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211186855658 : Closed e1211186855658 ∧ code e1211186855658 = 5609233366762 := by decide
theorem cert_e1211186855658 : check e1211186855658 [[],[]] .three = true := by decide
def e1211186856414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 3)))))))
theorem wire_e1211186856414 : Closed e1211186856414 ∧ code e1211186856414 = 5609233367518 := by decide
theorem cert_e1211186856414 : check e1211186856414 [[],[]] .three = true := by decide
def e1211186856430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211186856430 : Closed e1211186856430 ∧ code e1211186856430 = 5609233367534 := by decide
theorem cert_e1211186856430 : check e1211186856430 [[],[]] .smaller = true := by decide
def e1211186856438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1)))))))
theorem wire_e1211186856438 : Closed e1211186856438 ∧ code e1211186856438 = 5609233367542 := by decide
theorem cert_e1211186856438 : check e1211186856438 [[],[]] .smaller = true := by decide
def e1211186856442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e1211186856442 : Closed e1211186856442 ∧ code e1211186856442 = 5609233367546 := by decide
theorem cert_e1211186856442 : check e1211186856442 [[],[]] .three = true := by decide
def e1211186856798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 3)))))))
theorem wire_e1211186856798 : Closed e1211186856798 ∧ code e1211186856798 = 5609233367902 := by decide
theorem cert_e1211186856798 : check e1211186856798 [[],[]] .three = true := by decide
def e1211186856814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e1211186856814 : Closed e1211186856814 ∧ code e1211186856814 = 5609233367918 := by decide
theorem cert_e1211186856814 : check e1211186856814 [[],[]] .smaller = true := by decide
def e1211186856826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e1211186856826 : Closed e1211186856826 ∧ code e1211186856826 = 5609233367930 := by decide
theorem cert_e1211186856826 : check e1211186856826 [[],[]] .smaller = true := by decide
end Blc.Floor42
