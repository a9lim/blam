import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1203101599246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1203101599246 : Closed e1203101599246 ∧ code e1203101599246 = 5601148110350 := by decide
theorem cert_e1203101599246 : check e1203101599246 [[]] .width = true := by decide
def e1203101599258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203101599258 : Closed e1203101599258 ∧ code e1203101599258 = 5601148110362 := by decide
theorem cert_e1203101599258 : check e1203101599258 [[]] .width = true := by decide
def e1203101599330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1203101599330 : Closed e1203101599330 ∧ code e1203101599330 = 5601148110434 := by decide
theorem cert_e1203101599330 : check e1203101599330 [[]] .width = true := by decide
def e1203101700294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203101700294 : Closed e1203101700294 ∧ code e1203101700294 = 5601148211398 := by decide
theorem cert_e1203101700294 : check e1203101700294 [[]] .width = true := by decide
def e1203101702170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203101702170 : Closed e1203101702170 ∧ code e1203101702170 = 5601148213274 := by decide
theorem cert_e1203101702170 : check e1203101702170 [[]] .width = true := by decide
def e1203101703706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203101703706 : Closed e1203101703706 ∧ code e1203101703706 = 5601148214810 := by decide
theorem cert_e1203101703706 : check e1203101703706 [[]] .width = true := by decide
def e1203101712582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203101712582 : Closed e1203101712582 ∧ code e1203101712582 = 5601148223686 := by decide
theorem cert_e1203101712582 : check e1203101712582 [[]] .width = true := by decide
def e1203101720602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203101720602 : Closed e1203101720602 ∧ code e1203101720602 = 5601148231706 := by decide
theorem cert_e1203101720602 : check e1203101720602 [[]] .width = true := by decide
def e1203101720694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203101720694 : Closed e1203101720694 ∧ code e1203101720694 = 5601148231798 := by decide
theorem cert_e1203101720694 : check e1203101720694 [[]] .width = true := by decide
def e1203101720938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203101720938 : Closed e1203101720938 ∧ code e1203101720938 = 5601148232042 := by decide
theorem cert_e1203101720938 : check e1203101720938 [[]] .width = true := by decide
def e1203101720986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203101720986 : Closed e1203101720986 ∧ code e1203101720986 = 5601148232090 := by decide
theorem cert_e1203101720986 : check e1203101720986 [[]] .width = true := by decide
def e1203101724870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203101724870 : Closed e1203101724870 ∧ code e1203101724870 = 5601148235974 := by decide
theorem cert_e1203101724870 : check e1203101724870 [[]] .width = true := by decide
def e1203101736986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203101736986 : Closed e1203101736986 ∧ code e1203101736986 = 5601148248090 := by decide
theorem cert_e1203101736986 : check e1203101736986 [[]] .width = true := by decide
def e1203101737078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203101737078 : Closed e1203101737078 ∧ code e1203101737078 = 5601148248182 := by decide
theorem cert_e1203101737078 : check e1203101737078 [[]] .width = true := by decide
def e1203101737322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203101737322 : Closed e1203101737322 ∧ code e1203101737322 = 5601148248426 := by decide
theorem cert_e1203101737322 : check e1203101737322 [[]] .width = true := by decide
def e1203101737370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203101737370 : Closed e1203101737370 ∧ code e1203101737370 = 5601148248474 := by decide
theorem cert_e1203101737370 : check e1203101737370 [[]] .width = true := by decide
def e1203101746714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203101746714 : Closed e1203101746714 ∧ code e1203101746714 = 5601148257818 := by decide
theorem cert_e1203101746714 : check e1203101746714 [[]] .width = true := by decide
def e1203101749446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203101749446 : Closed e1203101749446 ∧ code e1203101749446 = 5601148260550 := by decide
theorem cert_e1203101749446 : check e1203101749446 [[]] .width = true := by decide
def e1203101761734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203101761734 : Closed e1203101761734 ∧ code e1203101761734 = 5601148272838 := by decide
theorem cert_e1203101761734 : check e1203101761734 [[]] .width = true := by decide
def e1203101762262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1203101762262 : Closed e1203101762262 ∧ code e1203101762262 = 5601148273366 := by decide
theorem cert_e1203101762262 : check e1203101762262 [[]] .width = true := by decide
def e1203101762266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1203101762266 : Closed e1203101762266 ∧ code e1203101762266 = 5601148273370 := by decide
theorem cert_e1203101762266 : check e1203101762266 [[]] .width = true := by decide
def e1203101762282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1203101762282 : Closed e1203101762282 ∧ code e1203101762282 = 5601148273386 := by decide
theorem cert_e1203101762282 : check e1203101762282 [[]] .width = true := by decide
def e1203101762358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1203101762358 : Closed e1203101762358 ∧ code e1203101762358 = 5601148273462 := by decide
theorem cert_e1203101762358 : check e1203101762358 [[]] .width = true := by decide
def e1203101762362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1203101762362 : Closed e1203101762362 ∧ code e1203101762362 = 5601148273466 := by decide
theorem cert_e1203101762362 : check e1203101762362 [[]] .width = true := by decide
def e1203101762446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1203101762446 : Closed e1203101762446 ∧ code e1203101762446 = 5601148273550 := by decide
theorem cert_e1203101762446 : check e1203101762446 [[]] .width = true := by decide
def e1203101762458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1203101762458 : Closed e1203101762458 ∧ code e1203101762458 = 5601148273562 := by decide
theorem cert_e1203101762458 : check e1203101762458 [[]] .width = true := by decide
def e1203101764378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1203101764378 : Closed e1203101764378 ∧ code e1203101764378 = 5601148275482 := by decide
theorem cert_e1203101764378 : check e1203101764378 [[]] .width = true := by decide
def e1203101764422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1203101764422 : Closed e1203101764422 ∧ code e1203101764422 = 5601148275526 := by decide
theorem cert_e1203101764422 : check e1203101764422 [[]] .width = true := by decide
def e1203101764534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1203101764534 : Closed e1203101764534 ∧ code e1203101764534 = 5601148275638 := by decide
theorem cert_e1203101764534 : check e1203101764534 [[]] .width = true := by decide
def e1203101764662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1203101764662 : Closed e1203101764662 ∧ code e1203101764662 = 5601148275766 := by decide
theorem cert_e1203101764662 : check e1203101764662 [[]] .width = true := by decide
def e1203101764666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1203101764666 : Closed e1203101764666 ∧ code e1203101764666 = 5601148275770 := by decide
theorem cert_e1203101764666 : check e1203101764666 [[]] .width = true := by decide
def e1203101764806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203101764806 : Closed e1203101764806 ∧ code e1203101764806 = 5601148275910 := by decide
theorem cert_e1203101764806 : check e1203101764806 [[]] .width = true := by decide
def e1203101765146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203101765146 : Closed e1203101765146 ∧ code e1203101765146 = 5601148276250 := by decide
theorem cert_e1203101765146 : check e1203101765146 [[]] .width = true := by decide
def e1203101765238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1203101765238 : Closed e1203101765238 ∧ code e1203101765238 = 5601148276342 := by decide
theorem cert_e1203101765238 : check e1203101765238 [[]] .width = true := by decide
def e1203101772826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1203101772826 : Closed e1203101772826 ∧ code e1203101772826 = 5601148283930 := by decide
theorem cert_e1203101772826 : check e1203101772826 [[]] .width = true := by decide
def e1203101772870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1203101772870 : Closed e1203101772870 ∧ code e1203101772870 = 5601148283974 := by decide
theorem cert_e1203101772870 : check e1203101772870 [[]] .width = true := by decide
def e1203101772898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1203101772898 : Closed e1203101772898 ∧ code e1203101772898 = 5601148284002 := by decide
theorem cert_e1203101772898 : check e1203101772898 [[]] .width = true := by decide
def e1203101773062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1203101773062 : Closed e1203101773062 ∧ code e1203101773062 = 5601148284166 := by decide
theorem cert_e1203101773062 : check e1203101773062 [[]] .width = true := by decide
def e1203101773854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1203101773854 : Closed e1203101773854 ∧ code e1203101773854 = 5601148284958 := by decide
theorem cert_e1203101773854 : check e1203101773854 [[]] .width = true := by decide
def e1203101774022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203101774022 : Closed e1203101774022 ∧ code e1203101774022 = 5601148285126 := by decide
theorem cert_e1203101774022 : check e1203101774022 [[]] .width = true := by decide
def e1203101774050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1203101774050 : Closed e1203101774050 ∧ code e1203101774050 = 5601148285154 := by decide
theorem cert_e1203101774050 : check e1203101774050 [[]] .width = true := by decide
def e1203101774598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1203101774598 : Closed e1203101774598 ∧ code e1203101774598 = 5601148285702 := by decide
theorem cert_e1203101774598 : check e1203101774598 [[]] .width = true := by decide
def e1203102125594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203102125594 : Closed e1203102125594 ∧ code e1203102125594 = 5601148636698 := by decide
theorem cert_e1203102125594 : check e1203102125594 [[]] .width = true := by decide
def e1203102134470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203102134470 : Closed e1203102134470 ∧ code e1203102134470 = 5601148645574 := by decide
theorem cert_e1203102134470 : check e1203102134470 [[]] .width = true := by decide
def e1203102139930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203102139930 : Closed e1203102139930 ∧ code e1203102139930 = 5601148651034 := by decide
theorem cert_e1203102139930 : check e1203102139930 [[]] .width = true := by decide
def e1203102142662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203102142662 : Closed e1203102142662 ∧ code e1203102142662 = 5601148653766 := by decide
theorem cert_e1203102142662 : check e1203102142662 [[]] .width = true := by decide
def e1203530455774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1203530455774 : Closed e1203530455774 ∧ code e1203530455774 = 5601576966878 := by decide
theorem cert_e1203530455774 : check e1203530455774 [[],[]] .three = true := by decide
def e1203530455798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1203530455798 : Closed e1203530455798 ∧ code e1203530455798 = 5601576966902 := by decide
theorem cert_e1203530455798 : check e1203530455798 [[],[]] .three = true := by decide
def e1203530455902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1203530455902 : Closed e1203530455902 ∧ code e1203530455902 = 5601576967006 := by decide
theorem cert_e1203530455902 : check e1203530455902 [[],[]] .three = true := by decide
def e1203530455918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1203530455918 : Closed e1203530455918 ∧ code e1203530455918 = 5601576967022 := by decide
theorem cert_e1203530455918 : check e1203530455918 [[],[]] .smaller = true := by decide
def e1203530455926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1203530455926 : Closed e1203530455926 ∧ code e1203530455926 = 5601576967030 := by decide
theorem cert_e1203530455926 : check e1203530455926 [[],[]] .smaller = true := by decide
def e1203530455930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1203530455930 : Closed e1203530455930 ∧ code e1203530455930 = 5601576967034 := by decide
theorem cert_e1203530455930 : check e1203530455930 [[],[]] .three = true := by decide
def e1203530455990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1203530455990 : Closed e1203530455990 ∧ code e1203530455990 = 5601576967094 := by decide
theorem cert_e1203530455990 : check e1203530455990 [[],[]] .smaller = true := by decide
def e1203530456022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1203530456022 : Closed e1203530456022 ∧ code e1203530456022 = 5601576967126 := by decide
theorem cert_e1203530456022 : check e1203530456022 [[],[]] .three = true := by decide
def e1203530456026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1203530456026 : Closed e1203530456026 ∧ code e1203530456026 = 5601576967130 := by decide
theorem cert_e1203530456026 : check e1203530456026 [[],[]] .three = true := by decide
def e1203530456414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1203530456414 : Closed e1203530456414 ∧ code e1203530456414 = 5601576967518 := by decide
theorem cert_e1203530456414 : check e1203530456414 [[],[]] .three = true := by decide
def e1203530456430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1203530456430 : Closed e1203530456430 ∧ code e1203530456430 = 5601576967534 := by decide
theorem cert_e1203530456430 : check e1203530456430 [[],[]] .smaller = true := by decide
def e1203530456438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1203530456438 : Closed e1203530456438 ∧ code e1203530456438 = 5601576967542 := by decide
theorem cert_e1203530456438 : check e1203530456438 [[],[]] .smaller = true := by decide
def e1203530456442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1203530456442 : Closed e1203530456442 ∧ code e1203530456442 = 5601576967546 := by decide
theorem cert_e1203530456442 : check e1203530456442 [[],[]] .three = true := by decide
def e1203530456494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1203530456494 : Closed e1203530456494 ∧ code e1203530456494 = 5601576967598 := by decide
theorem cert_e1203530456494 : check e1203530456494 [[],[]] .smaller = true := by decide
def e1203530456506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1203530456506 : Closed e1203530456506 ∧ code e1203530456506 = 5601576967610 := by decide
theorem cert_e1203530456506 : check e1203530456506 [[],[]] .smaller = true := by decide
def e1203530456534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1203530456534 : Closed e1203530456534 ∧ code e1203530456534 = 5601576967638 := by decide
theorem cert_e1203530456534 : check e1203530456534 [[],[]] .smaller = true := by decide
def e1203530456538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1203530456538 : Closed e1203530456538 ∧ code e1203530456538 = 5601576967642 := by decide
theorem cert_e1203530456538 : check e1203530456538 [[],[]] .smaller = true := by decide
def e1203530456554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1203530456554 : Closed e1203530456554 ∧ code e1203530456554 = 5601576967658 := by decide
theorem cert_e1203530456554 : check e1203530456554 [[],[]] .three = true := by decide
def e1203530456758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1203530456758 : Closed e1203530456758 ∧ code e1203530456758 = 5601576967862 := by decide
theorem cert_e1203530456758 : check e1203530456758 [[],[]] .smaller = true := by decide
def e1203530456790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1203530456790 : Closed e1203530456790 ∧ code e1203530456790 = 5601576967894 := by decide
theorem cert_e1203530456790 : check e1203530456790 [[],[]] .smaller = true := by decide
def e1203530456794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1203530456794 : Closed e1203530456794 ∧ code e1203530456794 = 5601576967898 := by decide
theorem cert_e1203530456794 : check e1203530456794 [[],[]] .smaller = true := by decide
def e1203530456918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1203530456918 : Closed e1203530456918 ∧ code e1203530456918 = 5601576968022 := by decide
theorem cert_e1203530456918 : check e1203530456918 [[],[]] .three = true := by decide
def e1203530456922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1203530456922 : Closed e1203530456922 ∧ code e1203530456922 = 5601576968026 := by decide
theorem cert_e1203530456922 : check e1203530456922 [[],[]] .three = true := by decide
def e1203530456938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1203530456938 : Closed e1203530456938 ∧ code e1203530456938 = 5601576968042 := by decide
theorem cert_e1203530456938 : check e1203530456938 [[],[]] .three = true := by decide
def e1203530458846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1203530458846 : Closed e1203530458846 ∧ code e1203530458846 = 5601576969950 := by decide
theorem cert_e1203530458846 : check e1203530458846 [[],[]] .three = true := by decide
def e1203530458870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1203530458870 : Closed e1203530458870 ∧ code e1203530458870 = 5601576969974 := by decide
theorem cert_e1203530458870 : check e1203530458870 [[],[]] .three = true := by decide
def e1203530458974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1203530458974 : Closed e1203530458974 ∧ code e1203530458974 = 5601576970078 := by decide
theorem cert_e1203530458974 : check e1203530458974 [[],[]] .three = true := by decide
def e1203530458990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1203530458990 : Closed e1203530458990 ∧ code e1203530458990 = 5601576970094 := by decide
theorem cert_e1203530458990 : check e1203530458990 [[],[]] .smaller = true := by decide
def e1203530458998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1203530458998 : Closed e1203530458998 ∧ code e1203530458998 = 5601576970102 := by decide
theorem cert_e1203530458998 : check e1203530458998 [[],[]] .smaller = true := by decide
def e1203530459002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1203530459002 : Closed e1203530459002 ∧ code e1203530459002 = 5601576970106 := by decide
theorem cert_e1203530459002 : check e1203530459002 [[],[]] .three = true := by decide
def e1203530459062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1203530459062 : Closed e1203530459062 ∧ code e1203530459062 = 5601576970166 := by decide
theorem cert_e1203530459062 : check e1203530459062 [[],[]] .smaller = true := by decide
def e1203530459094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1203530459094 : Closed e1203530459094 ∧ code e1203530459094 = 5601576970198 := by decide
theorem cert_e1203530459094 : check e1203530459094 [[],[]] .three = true := by decide
def e1203530459098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1203530459098 : Closed e1203530459098 ∧ code e1203530459098 = 5601576970202 := by decide
theorem cert_e1203530459098 : check e1203530459098 [[],[]] .three = true := by decide
def e1203530459614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1203530459614 : Closed e1203530459614 ∧ code e1203530459614 = 5601576970718 := by decide
theorem cert_e1203530459614 : check e1203530459614 [[],[]] .three = true := by decide
def e1203530459638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1203530459638 : Closed e1203530459638 ∧ code e1203530459638 = 5601576970742 := by decide
theorem cert_e1203530459638 : check e1203530459638 [[],[]] .three = true := by decide
def e1203530460382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1203530460382 : Closed e1203530460382 ∧ code e1203530460382 = 5601576971486 := by decide
theorem cert_e1203530460382 : check e1203530460382 [[],[]] .three = true := by decide
def e1203530460398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1203530460398 : Closed e1203530460398 ∧ code e1203530460398 = 5601576971502 := by decide
theorem cert_e1203530460398 : check e1203530460398 [[],[]] .smaller = true := by decide
def e1203530460406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1203530460406 : Closed e1203530460406 ∧ code e1203530460406 = 5601576971510 := by decide
theorem cert_e1203530460406 : check e1203530460406 [[],[]] .smaller = true := by decide
def e1203530460410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1203530460410 : Closed e1203530460410 ∧ code e1203530460410 = 5601576971514 := by decide
theorem cert_e1203530460410 : check e1203530460410 [[],[]] .three = true := by decide
def e1203530460790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1203530460790 : Closed e1203530460790 ∧ code e1203530460790 = 5601576971894 := by decide
theorem cert_e1203530460790 : check e1203530460790 [[],[]] .smaller = true := by decide
def e1203530460982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1203530460982 : Closed e1203530460982 ∧ code e1203530460982 = 5601576972086 := by decide
theorem cert_e1203530460982 : check e1203530460982 [[],[]] .three = true := by decide
def e1203530460986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1203530460986 : Closed e1203530460986 ∧ code e1203530460986 = 5601576972090 := by decide
theorem cert_e1203530460986 : check e1203530460986 [[],[]] .three = true := by decide
def e1203530462046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1203530462046 : Closed e1203530462046 ∧ code e1203530462046 = 5601576973150 := by decide
theorem cert_e1203530462046 : check e1203530462046 [[],[]] .three = true := by decide
def e1203530462062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1203530462062 : Closed e1203530462062 ∧ code e1203530462062 = 5601576973166 := by decide
theorem cert_e1203530462062 : check e1203530462062 [[],[]] .smaller = true := by decide
def e1203530462070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1203530462070 : Closed e1203530462070 ∧ code e1203530462070 = 5601576973174 := by decide
theorem cert_e1203530462070 : check e1203530462070 [[],[]] .smaller = true := by decide
def e1203530462074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1203530462074 : Closed e1203530462074 ∧ code e1203530462074 = 5601576973178 := by decide
theorem cert_e1203530462074 : check e1203530462074 [[],[]] .three = true := by decide
def e1203530462126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1203530462126 : Closed e1203530462126 ∧ code e1203530462126 = 5601576973230 := by decide
theorem cert_e1203530462126 : check e1203530462126 [[],[]] .smaller = true := by decide
def e1203530462138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1203530462138 : Closed e1203530462138 ∧ code e1203530462138 = 5601576973242 := by decide
theorem cert_e1203530462138 : check e1203530462138 [[],[]] .smaller = true := by decide
def e1203530462166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1203530462166 : Closed e1203530462166 ∧ code e1203530462166 = 5601576973270 := by decide
theorem cert_e1203530462166 : check e1203530462166 [[],[]] .smaller = true := by decide
def e1203530462170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1203530462170 : Closed e1203530462170 ∧ code e1203530462170 = 5601576973274 := by decide
theorem cert_e1203530462170 : check e1203530462170 [[],[]] .smaller = true := by decide
def e1203530462186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1203530462186 : Closed e1203530462186 ∧ code e1203530462186 = 5601576973290 := by decide
theorem cert_e1203530462186 : check e1203530462186 [[],[]] .three = true := by decide
def e1203530462430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1203530462430 : Closed e1203530462430 ∧ code e1203530462430 = 5601576973534 := by decide
theorem cert_e1203530462430 : check e1203530462430 [[],[]] .three = true := by decide
def e1203530462446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1203530462446 : Closed e1203530462446 ∧ code e1203530462446 = 5601576973550 := by decide
theorem cert_e1203530462446 : check e1203530462446 [[],[]] .smaller = true := by decide
def e1203530462454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1203530462454 : Closed e1203530462454 ∧ code e1203530462454 = 5601576973558 := by decide
theorem cert_e1203530462454 : check e1203530462454 [[],[]] .smaller = true := by decide
def e1203530462458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1203530462458 : Closed e1203530462458 ∧ code e1203530462458 = 5601576973562 := by decide
theorem cert_e1203530462458 : check e1203530462458 [[],[]] .three = true := by decide
def e1203530462830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1203530462830 : Closed e1203530462830 ∧ code e1203530462830 = 5601576973934 := by decide
theorem cert_e1203530462830 : check e1203530462830 [[],[]] .smaller = true := by decide
def e1203530462842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1203530462842 : Closed e1203530462842 ∧ code e1203530462842 = 5601576973946 := by decide
theorem cert_e1203530462842 : check e1203530462842 [[],[]] .smaller = true := by decide
def e1203530463030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1203530463030 : Closed e1203530463030 ∧ code e1203530463030 = 5601576974134 := by decide
theorem cert_e1203530463030 : check e1203530463030 [[],[]] .smaller = true := by decide
def e1203530463034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1203530463034 : Closed e1203530463034 ∧ code e1203530463034 = 5601576974138 := by decide
theorem cert_e1203530463034 : check e1203530463034 [[],[]] .smaller = true := by decide
def e1203530463130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1203530463130 : Closed e1203530463130 ∧ code e1203530463130 = 5601576974234 := by decide
theorem cert_e1203530463130 : check e1203530463130 [[],[]] .three = true := by decide
def e1203530463670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1203530463670 : Closed e1203530463670 ∧ code e1203530463670 = 5601576974774 := by decide
theorem cert_e1203530463670 : check e1203530463670 [[],[]] .smaller = true := by decide
def e1203530463702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1203530463702 : Closed e1203530463702 ∧ code e1203530463702 = 5601576974806 := by decide
theorem cert_e1203530463702 : check e1203530463702 [[],[]] .smaller = true := by decide
def e1203530463706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1203530463706 : Closed e1203530463706 ∧ code e1203530463706 = 5601576974810 := by decide
theorem cert_e1203530463706 : check e1203530463706 [[],[]] .smaller = true := by decide
def e1203530463862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1203530463862 : Closed e1203530463862 ∧ code e1203530463862 = 5601576974966 := by decide
theorem cert_e1203530463862 : check e1203530463862 [[],[]] .smaller = true := by decide
def e1203530464054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1203530464054 : Closed e1203530464054 ∧ code e1203530464054 = 5601576975158 := by decide
theorem cert_e1203530464054 : check e1203530464054 [[],[]] .smaller = true := by decide
def e1203530464058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1203530464058 : Closed e1203530464058 ∧ code e1203530464058 = 5601576975162 := by decide
theorem cert_e1203530464058 : check e1203530464058 [[],[]] .smaller = true := by decide
def e1203530464470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1203530464470 : Closed e1203530464470 ∧ code e1203530464470 = 5601576975574 := by decide
theorem cert_e1203530464470 : check e1203530464470 [[],[]] .three = true := by decide
def e1203530464474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1203530464474 : Closed e1203530464474 ∧ code e1203530464474 = 5601576975578 := by decide
theorem cert_e1203530464474 : check e1203530464474 [[],[]] .three = true := by decide
def e1203530464490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1203530464490 : Closed e1203530464490 ∧ code e1203530464490 = 5601576975594 := by decide
theorem cert_e1203530464490 : check e1203530464490 [[],[]] .three = true := by decide
def e1203530464566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1203530464566 : Closed e1203530464566 ∧ code e1203530464566 = 5601576975670 := by decide
theorem cert_e1203530464566 : check e1203530464566 [[],[]] .three = true := by decide
def e1203530464570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1203530464570 : Closed e1203530464570 ∧ code e1203530464570 = 5601576975674 := by decide
theorem cert_e1203530464570 : check e1203530464570 [[],[]] .three = true := by decide
def e1203530464666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1203530464666 : Closed e1203530464666 ∧ code e1203530464666 = 5601576975770 := by decide
theorem cert_e1203530464666 : check e1203530464666 [[],[]] .three = true := by decide
def e1203530471134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1203530471134 : Closed e1203530471134 ∧ code e1203530471134 = 5601576982238 := by decide
theorem cert_e1203530471134 : check e1203530471134 [[],[]] .three = true := by decide
def e1203530471158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1203530471158 : Closed e1203530471158 ∧ code e1203530471158 = 5601576982262 := by decide
theorem cert_e1203530471158 : check e1203530471158 [[],[]] .three = true := by decide
def e1203530471262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1203530471262 : Closed e1203530471262 ∧ code e1203530471262 = 5601576982366 := by decide
theorem cert_e1203530471262 : check e1203530471262 [[],[]] .three = true := by decide
def e1203530471278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1203530471278 : Closed e1203530471278 ∧ code e1203530471278 = 5601576982382 := by decide
theorem cert_e1203530471278 : check e1203530471278 [[],[]] .smaller = true := by decide
def e1203530471286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1203530471286 : Closed e1203530471286 ∧ code e1203530471286 = 5601576982390 := by decide
theorem cert_e1203530471286 : check e1203530471286 [[],[]] .smaller = true := by decide
def e1203530471290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1203530471290 : Closed e1203530471290 ∧ code e1203530471290 = 5601576982394 := by decide
theorem cert_e1203530471290 : check e1203530471290 [[],[]] .three = true := by decide
def e1203530471350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1203530471350 : Closed e1203530471350 ∧ code e1203530471350 = 5601576982454 := by decide
theorem cert_e1203530471350 : check e1203530471350 [[],[]] .smaller = true := by decide
def e1203530471382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1203530471382 : Closed e1203530471382 ∧ code e1203530471382 = 5601576982486 := by decide
theorem cert_e1203530471382 : check e1203530471382 [[],[]] .three = true := by decide
def e1203530471386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1203530471386 : Closed e1203530471386 ∧ code e1203530471386 = 5601576982490 := by decide
theorem cert_e1203530471386 : check e1203530471386 [[],[]] .three = true := by decide
def e1203530471902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1203530471902 : Closed e1203530471902 ∧ code e1203530471902 = 5601576983006 := by decide
theorem cert_e1203530471902 : check e1203530471902 [[],[]] .three = true := by decide
def e1203530471926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1203530471926 : Closed e1203530471926 ∧ code e1203530471926 = 5601576983030 := by decide
theorem cert_e1203530471926 : check e1203530471926 [[],[]] .three = true := by decide
def e1203530472670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1203530472670 : Closed e1203530472670 ∧ code e1203530472670 = 5601576983774 := by decide
theorem cert_e1203530472670 : check e1203530472670 [[],[]] .three = true := by decide
def e1203530472686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1203530472686 : Closed e1203530472686 ∧ code e1203530472686 = 5601576983790 := by decide
theorem cert_e1203530472686 : check e1203530472686 [[],[]] .smaller = true := by decide
def e1203530472694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1203530472694 : Closed e1203530472694 ∧ code e1203530472694 = 5601576983798 := by decide
theorem cert_e1203530472694 : check e1203530472694 [[],[]] .smaller = true := by decide
def e1203530472698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1203530472698 : Closed e1203530472698 ∧ code e1203530472698 = 5601576983802 := by decide
theorem cert_e1203530472698 : check e1203530472698 [[],[]] .three = true := by decide
def e1203530473078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1203530473078 : Closed e1203530473078 ∧ code e1203530473078 = 5601576984182 := by decide
theorem cert_e1203530473078 : check e1203530473078 [[],[]] .smaller = true := by decide
def e1203530473270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203530473270 : Closed e1203530473270 ∧ code e1203530473270 = 5601576984374 := by decide
theorem cert_e1203530473270 : check e1203530473270 [[],[]] .three = true := by decide
def e1203530473274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203530473274 : Closed e1203530473274 ∧ code e1203530473274 = 5601576984378 := by decide
theorem cert_e1203530473274 : check e1203530473274 [[],[]] .three = true := by decide
def e1203530484574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1203530484574 : Closed e1203530484574 ∧ code e1203530484574 = 5601576995678 := by decide
theorem cert_e1203530484574 : check e1203530484574 [[],[]] .three = true := by decide
def e1203530484590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1203530484590 : Closed e1203530484590 ∧ code e1203530484590 = 5601576995694 := by decide
theorem cert_e1203530484590 : check e1203530484590 [[],[]] .smaller = true := by decide
def e1203530484598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1203530484598 : Closed e1203530484598 ∧ code e1203530484598 = 5601576995702 := by decide
theorem cert_e1203530484598 : check e1203530484598 [[],[]] .smaller = true := by decide
def e1203530484602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1203530484602 : Closed e1203530484602 ∧ code e1203530484602 = 5601576995706 := by decide
theorem cert_e1203530484602 : check e1203530484602 [[],[]] .three = true := by decide
def e1203530484654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1203530484654 : Closed e1203530484654 ∧ code e1203530484654 = 5601576995758 := by decide
theorem cert_e1203530484654 : check e1203530484654 [[],[]] .smaller = true := by decide
def e1203530484666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1203530484666 : Closed e1203530484666 ∧ code e1203530484666 = 5601576995770 := by decide
theorem cert_e1203530484666 : check e1203530484666 [[],[]] .smaller = true := by decide
def e1203530484694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1203530484694 : Closed e1203530484694 ∧ code e1203530484694 = 5601576995798 := by decide
theorem cert_e1203530484694 : check e1203530484694 [[],[]] .smaller = true := by decide
def e1203530484698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1203530484698 : Closed e1203530484698 ∧ code e1203530484698 = 5601576995802 := by decide
theorem cert_e1203530484698 : check e1203530484698 [[],[]] .smaller = true := by decide
def e1203530484714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1203530484714 : Closed e1203530484714 ∧ code e1203530484714 = 5601576995818 := by decide
theorem cert_e1203530484714 : check e1203530484714 [[],[]] .three = true := by decide
def e1203530484958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1203530484958 : Closed e1203530484958 ∧ code e1203530484958 = 5601576996062 := by decide
theorem cert_e1203530484958 : check e1203530484958 [[],[]] .three = true := by decide
def e1203530484974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1203530484974 : Closed e1203530484974 ∧ code e1203530484974 = 5601576996078 := by decide
theorem cert_e1203530484974 : check e1203530484974 [[],[]] .smaller = true := by decide
def e1203530484982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1203530484982 : Closed e1203530484982 ∧ code e1203530484982 = 5601576996086 := by decide
theorem cert_e1203530484982 : check e1203530484982 [[],[]] .smaller = true := by decide
def e1203530484986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1203530484986 : Closed e1203530484986 ∧ code e1203530484986 = 5601576996090 := by decide
theorem cert_e1203530484986 : check e1203530484986 [[],[]] .three = true := by decide
def e1203530485358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1203530485358 : Closed e1203530485358 ∧ code e1203530485358 = 5601576996462 := by decide
theorem cert_e1203530485358 : check e1203530485358 [[],[]] .smaller = true := by decide
def e1203530485370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1203530485370 : Closed e1203530485370 ∧ code e1203530485370 = 5601576996474 := by decide
theorem cert_e1203530485370 : check e1203530485370 [[],[]] .smaller = true := by decide
def e1203530485558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203530485558 : Closed e1203530485558 ∧ code e1203530485558 = 5601576996662 := by decide
theorem cert_e1203530485558 : check e1203530485558 [[],[]] .smaller = true := by decide
def e1203530485562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203530485562 : Closed e1203530485562 ∧ code e1203530485562 = 5601576996666 := by decide
theorem cert_e1203530485562 : check e1203530485562 [[],[]] .smaller = true := by decide
def e1203530485658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1203530485658 : Closed e1203530485658 ∧ code e1203530485658 = 5601576996762 := by decide
theorem cert_e1203530485658 : check e1203530485658 [[],[]] .three = true := by decide
def e1203530491318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1203530491318 : Closed e1203530491318 ∧ code e1203530491318 = 5601577002422 := by decide
theorem cert_e1203530491318 : check e1203530491318 [[],[]] .smaller = true := by decide
def e1203530491350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1203530491350 : Closed e1203530491350 ∧ code e1203530491350 = 5601577002454 := by decide
theorem cert_e1203530491350 : check e1203530491350 [[],[]] .smaller = true := by decide
def e1203530491354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1203530491354 : Closed e1203530491354 ∧ code e1203530491354 = 5601577002458 := by decide
theorem cert_e1203530491354 : check e1203530491354 [[],[]] .smaller = true := by decide
def e1203530491510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1203530491510 : Closed e1203530491510 ∧ code e1203530491510 = 5601577002614 := by decide
theorem cert_e1203530491510 : check e1203530491510 [[],[]] .smaller = true := by decide
def e1203530491702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1203530491702 : Closed e1203530491702 ∧ code e1203530491702 = 5601577002806 := by decide
theorem cert_e1203530491702 : check e1203530491702 [[],[]] .smaller = true := by decide
def e1203530491706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1203530491706 : Closed e1203530491706 ∧ code e1203530491706 = 5601577002810 := by decide
theorem cert_e1203530491706 : check e1203530491706 [[],[]] .smaller = true := by decide
end Blc.Floor42
