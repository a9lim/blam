import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205814942330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814942330 : Closed e1205814942330 ∧ code e1205814942330 = 5603861453434 := by decide
theorem cert_e1205814942330 : check e1205814942330 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814942518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814942518 : Closed e1205814942518 ∧ code e1205814942518 = 5603861453622 := by decide
theorem cert_e1205814942518 : check e1205814942518 [[],[]] .chain = true := by decide
def e1205814942522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814942522 : Closed e1205814942522 ∧ code e1205814942522 = 5603861453626 := by decide
theorem cert_e1205814942522 : check e1205814942522 [[],[]] .chain = true := by decide
def e1205814942618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814942618 : Closed e1205814942618 ∧ code e1205814942618 = 5603861453722 := by decide
theorem cert_e1205814942618 : check e1205814942618 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814942934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1205814942934 : Closed e1205814942934 ∧ code e1205814942934 = 5603861454038 := by decide
theorem cert_e1205814942934 : check e1205814942934 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814942938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1205814942938 : Closed e1205814942938 ∧ code e1205814942938 = 5603861454042 := by decide
theorem cert_e1205814942938 : check e1205814942938 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814942954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1205814942954 : Closed e1205814942954 ∧ code e1205814942954 = 5603861454058 := by decide
theorem cert_e1205814942954 : check e1205814942954 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814943030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814943030 : Closed e1205814943030 ∧ code e1205814943030 = 5603861454134 := by decide
theorem cert_e1205814943030 : check e1205814943030 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814943034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814943034 : Closed e1205814943034 ∧ code e1205814943034 = 5603861454138 := by decide
theorem cert_e1205814943034 : check e1205814943034 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814943130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1205814943130 : Closed e1205814943130 ∧ code e1205814943130 = 5603861454234 := by decide
theorem cert_e1205814943130 : check e1205814943130 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1205814959342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814959342 : Closed e1205814959342 ∧ code e1205814959342 = 5603861470446 := by decide
theorem cert_e1205814959342 : check e1205814959342 [[],[]] .chain = true := by decide
def e1205814959350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814959350 : Closed e1205814959350 ∧ code e1205814959350 = 5603861470454 := by decide
theorem cert_e1205814959350 : check e1205814959350 [[],[]] .chain = true := by decide
def e1205814959726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814959726 : Closed e1205814959726 ∧ code e1205814959726 = 5603861470830 := by decide
theorem cert_e1205814959726 : check e1205814959726 [[],[]] .chain = true := by decide
def e1205814959738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814959738 : Closed e1205814959738 ∧ code e1205814959738 = 5603861470842 := by decide
theorem cert_e1205814959738 : check e1205814959738 [[],[]] .chain = true := by decide
def e1205814959926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205814959926 : Closed e1205814959926 ∧ code e1205814959926 = 5603861471030 := by decide
theorem cert_e1205814959926 : check e1205814959926 [[],[]] .chain = true := by decide
def e1205814959930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205814959930 : Closed e1205814959930 ∧ code e1205814959930 = 5603861471034 := by decide
theorem cert_e1205814959930 : check e1205814959930 [[],[]] .chain = true := by decide
def e1205814963642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1205814963642 : Closed e1205814963642 ∧ code e1205814963642 = 5603861474746 := by decide
theorem cert_e1205814963642 : check e1205814963642 [[],[]] .smaller = true := by decide
def e1205814963674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1205814963674 : Closed e1205814963674 ∧ code e1205814963674 = 5603861474778 := by decide
theorem cert_e1205814963674 : check e1205814963674 [[],[]] .smaller = true := by decide
def e1205814963898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1205814963898 : Closed e1205814963898 ∧ code e1205814963898 = 5603861475002 := by decide
theorem cert_e1205814963898 : check e1205814963898 [[],[]] .smaller = true := by decide
def e1205814963946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1205814963946 : Closed e1205814963946 ∧ code e1205814963946 = 5603861475050 := by decide
theorem cert_e1205814963946 : check e1205814963946 [[],[]] .smaller = true := by decide
def e1205814964058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1205814964058 : Closed e1205814964058 ∧ code e1205814964058 = 5603861475162 := by decide
theorem cert_e1205814964058 : check e1205814964058 [[],[]] .smaller = true := by decide
def e1205814964074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1205814964074 : Closed e1205814964074 ∧ code e1205814964074 = 5603861475178 := by decide
theorem cert_e1205814964074 : check e1205814964074 [[],[]] .smaller = true := by decide
def e1205814965178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1205814965178 : Closed e1205814965178 ∧ code e1205814965178 = 5603861476282 := by decide
theorem cert_e1205814965178 : check e1205814965178 [[],[]] .smaller = true := by decide
def e1205814965210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1205814965210 : Closed e1205814965210 ∧ code e1205814965210 = 5603861476314 := by decide
theorem cert_e1205814965210 : check e1205814965210 [[],[]] .smaller = true := by decide
def e1205814965486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814965486 : Closed e1205814965486 ∧ code e1205814965486 = 5603861476590 := by decide
theorem cert_e1205814965486 : check e1205814965486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814965494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814965494 : Closed e1205814965494 ∧ code e1205814965494 = 5603861476598 := by decide
theorem cert_e1205814965494 : check e1205814965494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e1205814966714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1205814966714 : Closed e1205814966714 ∧ code e1205814966714 = 5603861477818 := by decide
theorem cert_e1205814966714 : check e1205814966714 [[],[]] .smaller = true := by decide
def e1205814966762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1205814966762 : Closed e1205814966762 ∧ code e1205814966762 = 5603861477866 := by decide
theorem cert_e1205814966762 : check e1205814966762 [[],[]] .smaller = true := by decide
def e1205814967514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1205814967514 : Closed e1205814967514 ∧ code e1205814967514 = 5603861478618 := by decide
theorem cert_e1205814967514 : check e1205814967514 [[],[]] .smaller = true := by decide
def e1205814967530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1205814967530 : Closed e1205814967530 ∧ code e1205814967530 = 5603861478634 := by decide
theorem cert_e1205814967530 : check e1205814967530 [[],[]] .smaller = true := by decide
def e1205814967790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2))))))
theorem wire_e1205814967790 : Closed e1205814967790 ∧ code e1205814967790 = 5603861478894 := by decide
theorem cert_e1205814967790 : check e1205814967790 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1205814968046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2))))))
theorem wire_e1205814968046 : Closed e1205814968046 ∧ code e1205814968046 = 5603861479150 := by decide
theorem cert_e1205814968046 : check e1205814968046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814968054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1))))))
theorem wire_e1205814968054 : Closed e1205814968054 ∧ code e1205814968054 = 5603861479158 := by decide
theorem cert_e1205814968054 : check e1205814968054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814971246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205814971246 : Closed e1205814971246 ∧ code e1205814971246 = 5603861482350 := by decide
theorem cert_e1205814971246 : check e1205814971246 [[],[]] .chain = true := by decide
def e1205814971254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205814971254 : Closed e1205814971254 ∧ code e1205814971254 = 5603861482358 := by decide
theorem cert_e1205814971254 : check e1205814971254 [[],[]] .chain = true := by decide
def e1205814971310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205814971310 : Closed e1205814971310 ∧ code e1205814971310 = 5603861482414 := by decide
theorem cert_e1205814971310 : check e1205814971310 [[],[]] .chain = true := by decide
def e1205814971322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205814971322 : Closed e1205814971322 ∧ code e1205814971322 = 5603861482426 := by decide
theorem cert_e1205814971322 : check e1205814971322 [[],[]] .chain = true := by decide
def e1205814971350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205814971350 : Closed e1205814971350 ∧ code e1205814971350 = 5603861482454 := by decide
theorem cert_e1205814971350 : check e1205814971350 [[],[]] .chain = true := by decide
def e1205814971354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205814971354 : Closed e1205814971354 ∧ code e1205814971354 = 5603861482458 := by decide
theorem cert_e1205814971354 : check e1205814971354 [[],[]] .chain = true := by decide
def e1205814971630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205814971630 : Closed e1205814971630 ∧ code e1205814971630 = 5603861482734 := by decide
theorem cert_e1205814971630 : check e1205814971630 [[],[]] .chain = true := by decide
def e1205814971638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205814971638 : Closed e1205814971638 ∧ code e1205814971638 = 5603861482742 := by decide
theorem cert_e1205814971638 : check e1205814971638 [[],[]] .chain = true := by decide
def e1205814972014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205814972014 : Closed e1205814972014 ∧ code e1205814972014 = 5603861483118 := by decide
theorem cert_e1205814972014 : check e1205814972014 [[],[]] .chain = true := by decide
def e1205814972026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205814972026 : Closed e1205814972026 ∧ code e1205814972026 = 5603861483130 := by decide
theorem cert_e1205814972026 : check e1205814972026 [[],[]] .chain = true := by decide
def e1205814972214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205814972214 : Closed e1205814972214 ∧ code e1205814972214 = 5603861483318 := by decide
theorem cert_e1205814972214 : check e1205814972214 [[],[]] .chain = true := by decide
def e1205814972218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205814972218 : Closed e1205814972218 ∧ code e1205814972218 = 5603861483322 := by decide
theorem cert_e1205814972218 : check e1205814972218 [[],[]] .chain = true := by decide
def e1205814978334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1205814978334 : Closed e1205814978334 ∧ code e1205814978334 = 5603861489438 := by decide
theorem cert_e1205814978334 : check e1205814978334 [[],[]] .chain = true := by decide
def e1205814978446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1205814978446 : Closed e1205814978446 ∧ code e1205814978446 = 5603861489550 := by decide
theorem cert_e1205814978446 : check e1205814978446 [[],[]] .chain = true := by decide
def e1205814981406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1205814981406 : Closed e1205814981406 ∧ code e1205814981406 = 5603861492510 := by decide
theorem cert_e1205814981406 : check e1205814981406 [[],[]] .chain = true := by decide
def e1205814981574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1205814981574 : Closed e1205814981574 ∧ code e1205814981574 = 5603861492678 := by decide
theorem cert_e1205814981574 : check e1205814981574 [[],[]] .chain = true := by decide
def e1205814983054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1205814983054 : Closed e1205814983054 ∧ code e1205814983054 = 5603861494158 := by decide
theorem cert_e1205814983054 : check e1205814983054 [[],[]] .chain = true := by decide
def e1205814983110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1205814983110 : Closed e1205814983110 ∧ code e1205814983110 = 5603861494214 := by decide
theorem cert_e1205814983110 : check e1205814983110 [[],[]] .chain = true := by decide
def e1205814997358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e1205814997358 : Closed e1205814997358 ∧ code e1205814997358 = 5603861508462 := by decide
theorem cert_e1205814997358 : check e1205814997358 [[],[]] .chain = true := by decide
def e1205814997366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e1205814997366 : Closed e1205814997366 ∧ code e1205814997366 = 5603861508470 := by decide
theorem cert_e1205814997366 : check e1205814997366 [[],[]] .chain = true := by decide
def e1205814998574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1205814998574 : Closed e1205814998574 ∧ code e1205814998574 = 5603861509678 := by decide
theorem cert_e1205814998574 : check e1205814998574 [[],[]] .chain = true := by decide
def e1205814998754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1205814998754 : Closed e1205814998754 ∧ code e1205814998754 = 5603861509858 := by decide
theorem cert_e1205814998754 : check e1205814998754 [[],[]] .chain = true := by decide
def e1205814998766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e1205814998766 : Closed e1205814998766 ∧ code e1205814998766 = 5603861509870 := by decide
theorem cert_e1205814998766 : check e1205814998766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205814998806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1205814998806 : Closed e1205814998806 ∧ code e1205814998806 = 5603861509910 := by decide
theorem cert_e1205814998806 : check e1205814998806 [[],[]] .chain = true := by decide
def e1205814998882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1205814998882 : Closed e1205814998882 ∧ code e1205814998882 = 5603861509986 := by decide
theorem cert_e1205814998882 : check e1205814998882 [[],[]] .chain = true := by decide
def e1205814998894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e1205814998894 : Closed e1205814998894 ∧ code e1205814998894 = 5603861509998 := by decide
theorem cert_e1205814998894 : check e1205814998894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814998902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e1205814998902 : Closed e1205814998902 ∧ code e1205814998902 = 5603861510006 := by decide
theorem cert_e1205814998902 : check e1205814998902 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814999214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e1205814999214 : Closed e1205814999214 ∧ code e1205814999214 = 5603861510318 := by decide
theorem cert_e1205814999214 : check e1205814999214 [[],[]] .chain = true := by decide
def e1205814999226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e1205814999226 : Closed e1205814999226 ∧ code e1205814999226 = 5603861510330 := by decide
theorem cert_e1205814999226 : check e1205814999226 [[],[]] .chain = true := by decide
def e1205814999598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1205814999598 : Closed e1205814999598 ∧ code e1205814999598 = 5603861510702 := by decide
theorem cert_e1205814999598 : check e1205814999598 [[],[]] .chain = true := by decide
def e1205814999778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1205814999778 : Closed e1205814999778 ∧ code e1205814999778 = 5603861510882 := by decide
theorem cert_e1205814999778 : check e1205814999778 [[],[]] .chain = true := by decide
def e1205814999790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e1205814999790 : Closed e1205814999790 ∧ code e1205814999790 = 5603861510894 := by decide
theorem cert_e1205814999790 : check e1205814999790 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205814999918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1205814999918 : Closed e1205814999918 ∧ code e1205814999918 = 5603861511022 := by decide
theorem cert_e1205814999918 : check e1205814999918 [[],[]] .chain = true := by decide
def e1205814999926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1205814999926 : Closed e1205814999926 ∧ code e1205814999926 = 5603861511030 := by decide
theorem cert_e1205814999926 : check e1205814999926 [[],[]] .chain = true := by decide
def e1205814999946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205814999946 : Closed e1205814999946 ∧ code e1205814999946 = 5603861511050 := by decide
theorem cert_e1205814999946 : check e1205814999946 [[],[]] .chain = true := by decide
def e1205814999970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205814999970 : Closed e1205814999970 ∧ code e1205814999970 = 5603861511074 := by decide
theorem cert_e1205814999970 : check e1205814999970 [[],[]] .chain = true := by decide
def e1205814999982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e1205814999982 : Closed e1205814999982 ∧ code e1205814999982 = 5603861511086 := by decide
theorem cert_e1205814999982 : check e1205814999982 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205814999990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1205814999990 : Closed e1205814999990 ∧ code e1205814999990 = 5603861511094 := by decide
theorem cert_e1205814999990 : check e1205814999990 [[],[]] .chain = true := by decide
def e1205814999994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e1205814999994 : Closed e1205814999994 ∧ code e1205814999994 = 5603861511098 := by decide
theorem cert_e1205814999994 : check e1205814999994 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815000150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1205815000150 : Closed e1205815000150 ∧ code e1205815000150 = 5603861511254 := by decide
theorem cert_e1205815000150 : check e1205815000150 [[],[]] .chain = true := by decide
def e1205815000154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1205815000154 : Closed e1205815000154 ∧ code e1205815000154 = 5603861511258 := by decide
theorem cert_e1205815000154 : check e1205815000154 [[],[]] .chain = true := by decide
def e1205815000342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e1205815000342 : Closed e1205815000342 ∧ code e1205815000342 = 5603861511446 := by decide
theorem cert_e1205815000342 : check e1205815000342 [[],[]] .chain = true := by decide
def e1205815000418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e1205815000418 : Closed e1205815000418 ∧ code e1205815000418 = 5603861511522 := by decide
theorem cert_e1205815000418 : check e1205815000418 [[],[]] .chain = true := by decide
def e1205815000430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1205815000430 : Closed e1205815000430 ∧ code e1205815000430 = 5603861511534 := by decide
theorem cert_e1205815000430 : check e1205815000430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1205815000438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1205815000438 : Closed e1205815000438 ∧ code e1205815000438 = 5603861511542 := by decide
theorem cert_e1205815000438 : check e1205815000438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815000458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205815000458 : Closed e1205815000458 ∧ code e1205815000458 = 5603861511562 := by decide
theorem cert_e1205815000458 : check e1205815000458 [[],[]] .chain = true := by decide
def e1205815000482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205815000482 : Closed e1205815000482 ∧ code e1205815000482 = 5603861511586 := by decide
theorem cert_e1205815000482 : check e1205815000482 [[],[]] .chain = true := by decide
def e1205815000494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1205815000494 : Closed e1205815000494 ∧ code e1205815000494 = 5603861511598 := by decide
theorem cert_e1205815000494 : check e1205815000494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815000502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e1205815000502 : Closed e1205815000502 ∧ code e1205815000502 = 5603861511606 := by decide
theorem cert_e1205815000502 : check e1205815000502 [[],[]] .chain = true := by decide
def e1205815000506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1205815000506 : Closed e1205815000506 ∧ code e1205815000506 = 5603861511610 := by decide
theorem cert_e1205815000506 : check e1205815000506 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205815000534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1205815000534 : Closed e1205815000534 ∧ code e1205815000534 = 5603861511638 := by decide
theorem cert_e1205815000534 : checkPay e1205815000534 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1205815000538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1205815000538 : Closed e1205815000538 ∧ code e1205815000538 = 5603861511642 := by decide
theorem cert_e1205815000538 : check e1205815000538 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1205815001582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e1205815001582 : Closed e1205815001582 ∧ code e1205815001582 = 5603861512686 := by decide
theorem cert_e1205815001582 : check e1205815001582 [[],[]] .chain = true := by decide
def e1205815001590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e1205815001590 : Closed e1205815001590 ∧ code e1205815001590 = 5603861512694 := by decide
theorem cert_e1205815001590 : check e1205815001590 [[],[]] .chain = true := by decide
def e1205815002350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815002350 : Closed e1205815002350 ∧ code e1205815002350 = 5603861513454 := by decide
theorem cert_e1205815002350 : check e1205815002350 [[],[]] .chain = true := by decide
def e1205815002358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815002358 : Closed e1205815002358 ∧ code e1205815002358 = 5603861513462 := by decide
theorem cert_e1205815002358 : check e1205815002358 [[],[]] .chain = true := by decide
def e1205815002910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1205815002910 : Closed e1205815002910 ∧ code e1205815002910 = 5603861514014 := by decide
theorem cert_e1205815002910 : check e1205815002910 [[],[]] .chain = true := by decide
def e1205815003022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e1205815003022 : Closed e1205815003022 ∧ code e1205815003022 = 5603861514126 := by decide
theorem cert_e1205815003022 : check e1205815003022 [[],[]] .chain = true := by decide
def e1205815004718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e1205815004718 : Closed e1205815004718 ∧ code e1205815004718 = 5603861515822 := by decide
theorem cert_e1205815004718 : check e1205815004718 [[],[]] .chain = true := by decide
def e1205815004898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1205815004898 : Closed e1205815004898 ∧ code e1205815004898 = 5603861516002 := by decide
theorem cert_e1205815004898 : check e1205815004898 [[],[]] .chain = true := by decide
def e1205815004910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1205815004910 : Closed e1205815004910 ∧ code e1205815004910 = 5603861516014 := by decide
theorem cert_e1205815004910 : check e1205815004910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1205815004950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e1205815004950 : Closed e1205815004950 ∧ code e1205815004950 = 5603861516054 := by decide
theorem cert_e1205815004950 : check e1205815004950 [[],[]] .chain = true := by decide
def e1205815005026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1205815005026 : Closed e1205815005026 ∧ code e1205815005026 = 5603861516130 := by decide
theorem cert_e1205815005026 : check e1205815005026 [[],[]] .chain = true := by decide
def e1205815005038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1205815005038 : Closed e1205815005038 ∧ code e1205815005038 = 5603861516142 := by decide
theorem cert_e1205815005038 : check e1205815005038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1205815005046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e1205815005046 : Closed e1205815005046 ∧ code e1205815005046 = 5603861516150 := by decide
theorem cert_e1205815005046 : check e1205815005046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1205815007294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e1205815007294 : Closed e1205815007294 ∧ code e1205815007294 = 5603861518398 := by decide
theorem cert_e1205815007294 : check e1205815007294 [[],[]] .chain = true := by decide
def e1205815007714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1205815007714 : Closed e1205815007714 ∧ code e1205815007714 = 5603861518818 := by decide
theorem cert_e1205815007714 : check e1205815007714 [[],[]] .chain = true := by decide
def e1205815007726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e1205815007726 : Closed e1205815007726 ∧ code e1205815007726 = 5603861518830 := by decide
theorem cert_e1205815007726 : check e1205815007726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1205815008286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e1205815008286 : Closed e1205815008286 ∧ code e1205815008286 = 5603861519390 := by decide
theorem cert_e1205815008286 : check e1205815008286 [[],[]] .chain = true := by decide
def e1205815008482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1205815008482 : Closed e1205815008482 ∧ code e1205815008482 = 5603861519586 := by decide
theorem cert_e1205815008482 : check e1205815008482 [[],[]] .chain = true := by decide
def e1205815008494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815008494 : Closed e1205815008494 ∧ code e1205815008494 = 5603861519598 := by decide
theorem cert_e1205815008494 : check e1205815008494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205815008502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815008502 : Closed e1205815008502 ∧ code e1205815008502 = 5603861519606 := by decide
theorem cert_e1205815008502 : check e1205815008502 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205815009518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e1205815009518 : Closed e1205815009518 ∧ code e1205815009518 = 5603861520622 := by decide
theorem cert_e1205815009518 : check e1205815009518 [[],[]] .chain = true := by decide
def e1205815009530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e1205815009530 : Closed e1205815009530 ∧ code e1205815009530 = 5603861520634 := by decide
theorem cert_e1205815009530 : check e1205815009530 [[],[]] .chain = true := by decide
def e1205815009710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e1205815009710 : Closed e1205815009710 ∧ code e1205815009710 = 5603861520814 := by decide
theorem cert_e1205815009710 : check e1205815009710 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815009902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815009902 : Closed e1205815009902 ∧ code e1205815009902 = 5603861521006 := by decide
theorem cert_e1205815009902 : check e1205815009902 [[],[]] .chain = true := by decide
def e1205815009914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815009914 : Closed e1205815009914 ∧ code e1205815009914 = 5603861521018 := by decide
theorem cert_e1205815009914 : check e1205815009914 [[],[]] .chain = true := by decide
def e1205815010078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1205815010078 : Closed e1205815010078 ∧ code e1205815010078 = 5603861521182 := by decide
theorem cert_e1205815010078 : check e1205815010078 [[],[]] .chain = true := by decide
def e1205815010246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e1205815010246 : Closed e1205815010246 ∧ code e1205815010246 = 5603861521350 := by decide
theorem cert_e1205815010246 : check e1205815010246 [[],[]] .chain = true := by decide
def e1205815010862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e1205815010862 : Closed e1205815010862 ∧ code e1205815010862 = 5603861521966 := by decide
theorem cert_e1205815010862 : check e1205815010862 [[],[]] .chain = true := by decide
def e1205815011042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1205815011042 : Closed e1205815011042 ∧ code e1205815011042 = 5603861522146 := by decide
theorem cert_e1205815011042 : check e1205815011042 [[],[]] .chain = true := by decide
def e1205815011054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e1205815011054 : Closed e1205815011054 ∧ code e1205815011054 = 5603861522158 := by decide
theorem cert_e1205815011054 : check e1205815011054 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815011182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1205815011182 : Closed e1205815011182 ∧ code e1205815011182 = 5603861522286 := by decide
theorem cert_e1205815011182 : check e1205815011182 [[],[]] .chain = true := by decide
def e1205815011190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1205815011190 : Closed e1205815011190 ∧ code e1205815011190 = 5603861522294 := by decide
theorem cert_e1205815011190 : check e1205815011190 [[],[]] .chain = true := by decide
def e1205815011210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1205815011210 : Closed e1205815011210 ∧ code e1205815011210 = 5603861522314 := by decide
theorem cert_e1205815011210 : check e1205815011210 [[],[]] .chain = true := by decide
def e1205815011234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1205815011234 : Closed e1205815011234 ∧ code e1205815011234 = 5603861522338 := by decide
theorem cert_e1205815011234 : check e1205815011234 [[],[]] .chain = true := by decide
def e1205815011246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e1205815011246 : Closed e1205815011246 ∧ code e1205815011246 = 5603861522350 := by decide
theorem cert_e1205815011246 : check e1205815011246 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815011254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1205815011254 : Closed e1205815011254 ∧ code e1205815011254 = 5603861522358 := by decide
theorem cert_e1205815011254 : check e1205815011254 [[],[]] .chain = true := by decide
def e1205815011258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1205815011258 : Closed e1205815011258 ∧ code e1205815011258 = 5603861522362 := by decide
theorem cert_e1205815011258 : check e1205815011258 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815011390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e1205815011390 : Closed e1205815011390 ∧ code e1205815011390 = 5603861522494 := by decide
theorem cert_e1205815011390 : check e1205815011390 [[],[]] .chain = true := by decide
def e1205815011810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1205815011810 : Closed e1205815011810 ∧ code e1205815011810 = 5603861522914 := by decide
theorem cert_e1205815011810 : check e1205815011810 [[],[]] .chain = true := by decide
def e1205815011822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e1205815011822 : Closed e1205815011822 ∧ code e1205815011822 = 5603861522926 := by decide
theorem cert_e1205815011822 : check e1205815011822 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815012590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815012590 : Closed e1205815012590 ∧ code e1205815012590 = 5603861523694 := by decide
theorem cert_e1205815012590 : check e1205815012590 [[],[]] .chain = true := by decide
def e1205815012598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815012598 : Closed e1205815012598 ∧ code e1205815012598 = 5603861523702 := by decide
theorem cert_e1205815012598 : check e1205815012598 [[],[]] .chain = true := by decide
def e1205815012878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e1205815012878 : Closed e1205815012878 ∧ code e1205815012878 = 5603861523982 := by decide
theorem cert_e1205815012878 : check e1205815012878 [[],[]] .chain = true := by decide
def e1205815012890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205815012890 : Closed e1205815012890 ∧ code e1205815012890 = 5603861523994 := by decide
theorem cert_e1205815012890 : check e1205815012890 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815012962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205815012962 : Closed e1205815012962 ∧ code e1205815012962 = 5603861524066 := by decide
theorem cert_e1205815012962 : check e1205815012962 [[],[]] .chain = true := by decide
def e1205815012974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815012974 : Closed e1205815012974 ∧ code e1205815012974 = 5603861524078 := by decide
theorem cert_e1205815012974 : check e1205815012974 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815012982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1205815012982 : Closed e1205815012982 ∧ code e1205815012982 = 5603861524086 := by decide
theorem cert_e1205815012982 : check e1205815012982 [[],[]] .chain = true := by decide
def e1205815012986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815012986 : Closed e1205815012986 ∧ code e1205815012986 = 5603861524090 := by decide
theorem cert_e1205815012986 : check e1205815012986 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815013494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e1205815013494 : Closed e1205815013494 ∧ code e1205815013494 = 5603861524598 := by decide
theorem cert_e1205815013494 : check e1205815013494 [[],[]] .chain = true := by decide
def e1205815013498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e1205815013498 : Closed e1205815013498 ∧ code e1205815013498 = 5603861524602 := by decide
theorem cert_e1205815013498 : check e1205815013498 [[],[]] .chain = true := by decide
def e1205815013590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1205815013590 : Closed e1205815013590 ∧ code e1205815013590 = 5603861524694 := by decide
theorem cert_e1205815013590 : checkPay e1205815013590 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815013686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815013686 : Closed e1205815013686 ∧ code e1205815013686 = 5603861524790 := by decide
theorem cert_e1205815013686 : check e1205815013686 [[],[]] .chain = true := by decide
def e1205815013690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815013690 : Closed e1205815013690 ∧ code e1205815013690 = 5603861524794 := by decide
theorem cert_e1205815013690 : check e1205815013690 [[],[]] .chain = true := by decide
def e1205815013774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1205815013774 : Closed e1205815013774 ∧ code e1205815013774 = 5603861524878 := by decide
theorem cert_e1205815013774 : check e1205815013774 [[],[]] .chain = true := by decide
def e1205815013830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1205815013830 : Closed e1205815013830 ∧ code e1205815013830 = 5603861524934 := by decide
theorem cert_e1205815013830 : check e1205815013830 [[],[]] .chain = true := by decide
def e1205815014166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e1205815014166 : Closed e1205815014166 ∧ code e1205815014166 = 5603861525270 := by decide
theorem cert_e1205815014166 : check e1205815014166 [[],[]] .chain = true := by decide
def e1205815014242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1205815014242 : Closed e1205815014242 ∧ code e1205815014242 = 5603861525346 := by decide
theorem cert_e1205815014242 : check e1205815014242 [[],[]] .chain = true := by decide
def e1205815014254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1205815014254 : Closed e1205815014254 ∧ code e1205815014254 = 5603861525358 := by decide
theorem cert_e1205815014254 : check e1205815014254 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815014262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1205815014262 : Closed e1205815014262 ∧ code e1205815014262 = 5603861525366 := by decide
theorem cert_e1205815014262 : checkPay e1205815014262 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1205815014282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1205815014282 : Closed e1205815014282 ∧ code e1205815014282 = 5603861525386 := by decide
theorem cert_e1205815014282 : check e1205815014282 [[],[]] .chain = true := by decide
def e1205815014306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1205815014306 : Closed e1205815014306 ∧ code e1205815014306 = 5603861525410 := by decide
theorem cert_e1205815014306 : check e1205815014306 [[],[]] .chain = true := by decide
def e1205815014318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1205815014318 : Closed e1205815014318 ∧ code e1205815014318 = 5603861525422 := by decide
theorem cert_e1205815014318 : check e1205815014318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205815014326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e1205815014326 : Closed e1205815014326 ∧ code e1205815014326 = 5603861525430 := by decide
theorem cert_e1205815014326 : check e1205815014326 [[],[]] .chain = true := by decide
def e1205815014330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1205815014330 : Closed e1205815014330 ∧ code e1205815014330 = 5603861525434 := by decide
theorem cert_e1205815014330 : check e1205815014330 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815014358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1205815014358 : Closed e1205815014358 ∧ code e1205815014358 = 5603861525462 := by decide
theorem cert_e1205815014358 : checkPay e1205815014358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.under]] = true := by decide
def e1205815014362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1205815014362 : Closed e1205815014362 ∧ code e1205815014362 = 5603861525466 := by decide
theorem cert_e1205815014362 : check e1205815014362 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815014430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e1205815014430 : Closed e1205815014430 ∧ code e1205815014430 = 5603861525534 := by decide
theorem cert_e1205815014430 : check e1205815014430 [[],[]] .chain = true := by decide
def e1205815014626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1205815014626 : Closed e1205815014626 ∧ code e1205815014626 = 5603861525730 := by decide
theorem cert_e1205815014626 : check e1205815014626 [[],[]] .chain = true := by decide
def e1205815014638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815014638 : Closed e1205815014638 ∧ code e1205815014638 = 5603861525742 := by decide
theorem cert_e1205815014638 : check e1205815014638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815014646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815014646 : Closed e1205815014646 ∧ code e1205815014646 = 5603861525750 := by decide
theorem cert_e1205815014646 : check e1205815014646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815014926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e1205815014926 : Closed e1205815014926 ∧ code e1205815014926 = 5603861526030 := by decide
theorem cert_e1205815014926 : check e1205815014926 [[],[]] .chain = true := by decide
def e1205815014938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205815014938 : Closed e1205815014938 ∧ code e1205815014938 = 5603861526042 := by decide
theorem cert_e1205815014938 : check e1205815014938 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1205815015010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205815015010 : Closed e1205815015010 ∧ code e1205815015010 = 5603861526114 := by decide
theorem cert_e1205815015010 : check e1205815015010 [[],[]] .chain = true := by decide
def e1205815015022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815015022 : Closed e1205815015022 ∧ code e1205815015022 = 5603861526126 := by decide
theorem cert_e1205815015022 : check e1205815015022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815015030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e1205815015030 : Closed e1205815015030 ∧ code e1205815015030 = 5603861526134 := by decide
theorem cert_e1205815015030 : check e1205815015030 [[],[]] .chain = true := by decide
end Blc.Floor42
