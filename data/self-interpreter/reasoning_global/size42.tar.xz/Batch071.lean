import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196198771178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1196198771178 : Closed e1196198771178 ∧ code e1196198771178 = 5594245282282 := by decide
theorem cert_e1196198771178 : check e1196198771178 [[],[.left]] .chain = true := by decide
def e1196198771310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196198771310 : Closed e1196198771310 ∧ code e1196198771310 = 5594245282414 := by decide
theorem cert_e1196198771310 : check e1196198771310 [[],[.left]] .chain = true := by decide
def e1196198771322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196198771322 : Closed e1196198771322 ∧ code e1196198771322 = 5594245282426 := by decide
theorem cert_e1196198771322 : check e1196198771322 [[],[.left]] .chain = true := by decide
def e1196198771610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1196198771610 : Closed e1196198771610 ∧ code e1196198771610 = 5594245282714 := by decide
theorem cert_e1196198771610 : check e1196198771610 [[],[.left]] .chain = true := by decide
def e1196198771926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1196198771926 : Closed e1196198771926 ∧ code e1196198771926 = 5594245283030 := by decide
theorem cert_e1196198771926 : check e1196198771926 [[],[.left]] .chain = true := by decide
def e1196198771930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1196198771930 : Closed e1196198771930 ∧ code e1196198771930 = 5594245283034 := by decide
theorem cert_e1196198771930 : check e1196198771930 [[],[.left]] .chain = true := by decide
def e1196198771946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1196198771946 : Closed e1196198771946 ∧ code e1196198771946 = 5594245283050 := by decide
theorem cert_e1196198771946 : check e1196198771946 [[],[.left]] .chain = true := by decide
def e1196198772022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196198772022 : Closed e1196198772022 ∧ code e1196198772022 = 5594245283126 := by decide
theorem cert_e1196198772022 : check e1196198772022 [[],[.left]] .chain = true := by decide
def e1196198772026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196198772026 : Closed e1196198772026 ∧ code e1196198772026 = 5594245283130 := by decide
theorem cert_e1196198772026 : check e1196198772026 [[],[.left]] .chain = true := by decide
def e1196198772122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1196198772122 : Closed e1196198772122 ∧ code e1196198772122 = 5594245283226 := by decide
theorem cert_e1196198772122 : check e1196198772122 [[],[.left]] .chain = true := by decide
def e1196198775662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196198775662 : Closed e1196198775662 ∧ code e1196198775662 = 5594245286766 := by decide
theorem cert_e1196198775662 : check e1196198775662 [[],[.left]] .chain = true := by decide
def e1196198775670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196198775670 : Closed e1196198775670 ∧ code e1196198775670 = 5594245286774 := by decide
theorem cert_e1196198775670 : check e1196198775670 [[],[.left]] .chain = true := by decide
def e1196198775726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196198775726 : Closed e1196198775726 ∧ code e1196198775726 = 5594245286830 := by decide
theorem cert_e1196198775726 : check e1196198775726 [[],[.left]] .chain = true := by decide
def e1196198775738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196198775738 : Closed e1196198775738 ∧ code e1196198775738 = 5594245286842 := by decide
theorem cert_e1196198775738 : check e1196198775738 [[],[.left]] .chain = true := by decide
def e1196198775766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196198775766 : Closed e1196198775766 ∧ code e1196198775766 = 5594245286870 := by decide
theorem cert_e1196198775766 : check e1196198775766 [[],[.left]] .chain = true := by decide
def e1196198775770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196198775770 : Closed e1196198775770 ∧ code e1196198775770 = 5594245286874 := by decide
theorem cert_e1196198775770 : check e1196198775770 [[],[.left]] .chain = true := by decide
def e1196198776046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196198776046 : Closed e1196198776046 ∧ code e1196198776046 = 5594245287150 := by decide
theorem cert_e1196198776046 : check e1196198776046 [[],[.left]] .chain = true := by decide
def e1196198776054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196198776054 : Closed e1196198776054 ∧ code e1196198776054 = 5594245287158 := by decide
theorem cert_e1196198776054 : check e1196198776054 [[],[.left]] .chain = true := by decide
def e1196198776430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196198776430 : Closed e1196198776430 ∧ code e1196198776430 = 5594245287534 := by decide
theorem cert_e1196198776430 : check e1196198776430 [[],[.left]] .chain = true := by decide
def e1196198776442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196198776442 : Closed e1196198776442 ∧ code e1196198776442 = 5594245287546 := by decide
theorem cert_e1196198776442 : check e1196198776442 [[],[.left]] .chain = true := by decide
def e1196198776630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196198776630 : Closed e1196198776630 ∧ code e1196198776630 = 5594245287734 := by decide
theorem cert_e1196198776630 : check e1196198776630 [[],[.left]] .chain = true := by decide
def e1196198776634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196198776634 : Closed e1196198776634 ∧ code e1196198776634 = 5594245287738 := by decide
theorem cert_e1196198776634 : check e1196198776634 [[],[.left]] .chain = true := by decide
def e1196198782382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1196198782382 : Closed e1196198782382 ∧ code e1196198782382 = 5594245293486 := by decide
theorem cert_e1196198782382 : check e1196198782382 [[],[.left]] .chain = true := by decide
def e1196198782394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1196198782394 : Closed e1196198782394 ∧ code e1196198782394 = 5594245293498 := by decide
theorem cert_e1196198782394 : check e1196198782394 [[],[.left]] .chain = true := by decide
def e1196198782442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1196198782442 : Closed e1196198782442 ∧ code e1196198782442 = 5594245293546 := by decide
theorem cert_e1196198782442 : check e1196198782442 [[],[.left]] .chain = true := by decide
def e1196198782574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1196198782574 : Closed e1196198782574 ∧ code e1196198782574 = 5594245293678 := by decide
theorem cert_e1196198782574 : check e1196198782574 [[],[.left]] .chain = true := by decide
def e1196198782586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1196198782586 : Closed e1196198782586 ∧ code e1196198782586 = 5594245293690 := by decide
theorem cert_e1196198782586 : check e1196198782586 [[],[.left]] .chain = true := by decide
def e1196198782874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1196198782874 : Closed e1196198782874 ∧ code e1196198782874 = 5594245293978 := by decide
theorem cert_e1196198782874 : check e1196198782874 [[],[.left]] .chain = true := by decide
def e1196198785750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1196198785750 : Closed e1196198785750 ∧ code e1196198785750 = 5594245296854 := by decide
theorem cert_e1196198785750 : check e1196198785750 [[],[.left]] .chain = true := by decide
def e1196198785754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1196198785754 : Closed e1196198785754 ∧ code e1196198785754 = 5594245296858 := by decide
theorem cert_e1196198785754 : check e1196198785754 [[],[.left]] .chain = true := by decide
def e1196198785770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1196198785770 : Closed e1196198785770 ∧ code e1196198785770 = 5594245296874 := by decide
theorem cert_e1196198785770 : check e1196198785770 [[],[.left]] .chain = true := by decide
def e1196198785846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1196198785846 : Closed e1196198785846 ∧ code e1196198785846 = 5594245296950 := by decide
theorem cert_e1196198785846 : check e1196198785846 [[],[.left]] .chain = true := by decide
def e1196198785850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1196198785850 : Closed e1196198785850 ∧ code e1196198785850 = 5594245296954 := by decide
theorem cert_e1196198785850 : check e1196198785850 [[],[.left]] .chain = true := by decide
def e1196198785946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1196198785946 : Closed e1196198785946 ∧ code e1196198785946 = 5594245297050 := by decide
theorem cert_e1196198785946 : check e1196198785946 [[],[.left]] .chain = true := by decide
def e1196198923118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196198923118 : Closed e1196198923118 ∧ code e1196198923118 = 5594245434222 := by decide
theorem cert_e1196198923118 : check e1196198923118 [[],[.left]] .chain = true := by decide
def e1196198923126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196198923126 : Closed e1196198923126 ∧ code e1196198923126 = 5594245434230 := by decide
theorem cert_e1196198923126 : check e1196198923126 [[],[.left]] .chain = true := by decide
def e1196198923182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196198923182 : Closed e1196198923182 ∧ code e1196198923182 = 5594245434286 := by decide
theorem cert_e1196198923182 : check e1196198923182 [[],[.left]] .chain = true := by decide
def e1196198923194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196198923194 : Closed e1196198923194 ∧ code e1196198923194 = 5594245434298 := by decide
theorem cert_e1196198923194 : check e1196198923194 [[],[.left]] .chain = true := by decide
def e1196198923222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196198923222 : Closed e1196198923222 ∧ code e1196198923222 = 5594245434326 := by decide
theorem cert_e1196198923222 : check e1196198923222 [[],[.left]] .chain = true := by decide
def e1196198923226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196198923226 : Closed e1196198923226 ∧ code e1196198923226 = 5594245434330 := by decide
theorem cert_e1196198923226 : check e1196198923226 [[],[.left]] .chain = true := by decide
def e1196198923502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196198923502 : Closed e1196198923502 ∧ code e1196198923502 = 5594245434606 := by decide
theorem cert_e1196198923502 : check e1196198923502 [[],[.left]] .chain = true := by decide
def e1196198923510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196198923510 : Closed e1196198923510 ∧ code e1196198923510 = 5594245434614 := by decide
theorem cert_e1196198923510 : check e1196198923510 [[],[.left]] .chain = true := by decide
def e1196198923886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196198923886 : Closed e1196198923886 ∧ code e1196198923886 = 5594245434990 := by decide
theorem cert_e1196198923886 : check e1196198923886 [[],[.left]] .chain = true := by decide
def e1196198923898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196198923898 : Closed e1196198923898 ∧ code e1196198923898 = 5594245435002 := by decide
theorem cert_e1196198923898 : check e1196198923898 [[],[.left]] .chain = true := by decide
def e1196198924086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196198924086 : Closed e1196198924086 ∧ code e1196198924086 = 5594245435190 := by decide
theorem cert_e1196198924086 : check e1196198924086 [[],[.left]] .chain = true := by decide
def e1196198924090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196198924090 : Closed e1196198924090 ∧ code e1196198924090 = 5594245435194 := by decide
theorem cert_e1196198924090 : check e1196198924090 [[],[.left]] .chain = true := by decide
def e1196199512942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196199512942 : Closed e1196199512942 ∧ code e1196199512942 = 5594246024046 := by decide
theorem cert_e1196199512942 : check e1196199512942 [[],[.left],[.left],[.left],[],[.left],[]] .chain = true := by decide
def e1196199512950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196199512950 : Closed e1196199512950 ∧ code e1196199512950 = 5594246024054 := by decide
theorem cert_e1196199512950 : check e1196199512950 [[],[.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1196199513006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196199513006 : Closed e1196199513006 ∧ code e1196199513006 = 5594246024110 := by decide
theorem cert_e1196199513006 : check e1196199513006 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e1196199513018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196199513018 : Closed e1196199513018 ∧ code e1196199513018 = 5594246024122 := by decide
private def t_e1196199513018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e1196199513018 : ¬ IsSelfInterpreter e1196199513018 :=
  wSource (t := t_e1196199513018) (replay_sound (ps := []) (t := e1196199513018) (by decide)) (by decide)
def e1196199513046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196199513046 : Closed e1196199513046 ∧ code e1196199513046 = 5594246024150 := by decide
theorem cert_e1196199513046 : check e1196199513046 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1196199513050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196199513050 : Closed e1196199513050 ∧ code e1196199513050 = 5594246024154 := by decide
private def t_e1196199513050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e1196199513050 : ¬ IsSelfInterpreter e1196199513050 :=
  wSource (t := t_e1196199513050) (replay_sound (ps := []) (t := e1196199513050) (by decide)) (by decide)
def e1196199513326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196199513326 : Closed e1196199513326 ∧ code e1196199513326 = 5594246024430 := by decide
theorem cert_e1196199513326 : check e1196199513326 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1196199513334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196199513334 : Closed e1196199513334 ∧ code e1196199513334 = 5594246024438 := by decide
theorem cert_e1196199513334 : check e1196199513334 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e1196199513710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196199513710 : Closed e1196199513710 ∧ code e1196199513710 = 5594246024814 := by decide
theorem cert_e1196199513710 : check e1196199513710 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .smaller = true := by decide
def e1196199513722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196199513722 : Closed e1196199513722 ∧ code e1196199513722 = 5594246024826 := by decide
theorem cert_e1196199513722 : check e1196199513722 [[],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e1196199513910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196199513910 : Closed e1196199513910 ∧ code e1196199513910 = 5594246025014 := by decide
theorem cert_e1196199513910 : check e1196199513910 [[],[.left],[.left],[.left],[],[],[.left],[]] .chain = true := by decide
def e1196199513914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196199513914 : Closed e1196199513914 ∧ code e1196199513914 = 5594246025018 := by decide
theorem cert_e1196199513914 : check e1196199513914 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1196266581530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266581530 : Closed e1196266581530 ∧ code e1196266581530 = 5594313092634 := by decide
private def t_e1196266581530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266581530 : ¬ IsSelfInterpreter e1196266581530 :=
  wSource (t := t_e1196266581530) (replay_sound (ps := []) (t := e1196266581530) (by decide)) (by decide)
def e1196266583578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266583578 : Closed e1196266583578 ∧ code e1196266583578 = 5594313094682 := by decide
private def t_e1196266583578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266583578 : ¬ IsSelfInterpreter e1196266583578 :=
  wSource (t := t_e1196266583578) (replay_sound (ps := []) (t := e1196266583578) (by decide)) (by decide)
def e1196266597914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266597914 : Closed e1196266597914 ∧ code e1196266597914 = 5594313109018 := by decide
private def t_e1196266597914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266597914 : ¬ IsSelfInterpreter e1196266597914 :=
  wSource (t := t_e1196266597914) (replay_sound (ps := []) (t := e1196266597914) (by decide)) (by decide)
def e1196266600986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266600986 : Closed e1196266600986 ∧ code e1196266600986 = 5594313112090 := by decide
private def t_e1196266600986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266600986 : ¬ IsSelfInterpreter e1196266600986 :=
  wSource (t := t_e1196266600986) (replay_sound (ps := []) (t := e1196266600986) (by decide)) (by decide)
def e1196266608154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266608154 : Closed e1196266608154 ∧ code e1196266608154 = 5594313119258 := by decide
private def t_e1196266608154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266608154 : ¬ IsSelfInterpreter e1196266608154 :=
  wSource (t := t_e1196266608154) (replay_sound (ps := []) (t := e1196266608154) (by decide)) (by decide)
def e1196266609178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266609178 : Closed e1196266609178 ∧ code e1196266609178 = 5594313120282 := by decide
private def t_e1196266609178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266609178 : ¬ IsSelfInterpreter e1196266609178 :=
  wSource (t := t_e1196266609178) (replay_sound (ps := []) (t := e1196266609178) (by decide)) (by decide)
def e1196266679834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266679834 : Closed e1196266679834 ∧ code e1196266679834 = 5594313190938 := by decide
private def t_e1196266679834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266679834 : ¬ IsSelfInterpreter e1196266679834 :=
  wSource (t := t_e1196266679834) (replay_sound (ps := []) (t := e1196266679834) (by decide)) (by decide)
def e1196266681882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266681882 : Closed e1196266681882 ∧ code e1196266681882 = 5594313192986 := by decide
private def t_e1196266681882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266681882 : ¬ IsSelfInterpreter e1196266681882 :=
  wSource (t := t_e1196266681882) (replay_sound (ps := []) (t := e1196266681882) (by decide)) (by decide)
def e1196266778138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266778138 : Closed e1196266778138 ∧ code e1196266778138 = 5594313289242 := by decide
private def t_e1196266778138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266778138 : ¬ IsSelfInterpreter e1196266778138 :=
  wSource (t := t_e1196266778138) (replay_sound (ps := []) (t := e1196266778138) (by decide)) (by decide)
def e1196266781210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266781210 : Closed e1196266781210 ∧ code e1196266781210 = 5594313292314 := by decide
private def t_e1196266781210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266781210 : ¬ IsSelfInterpreter e1196266781210 :=
  wSource (t := t_e1196266781210) (replay_sound (ps := []) (t := e1196266781210) (by decide)) (by decide)
def e1196266829338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266829338 : Closed e1196266829338 ∧ code e1196266829338 = 5594313340442 := by decide
private def t_e1196266829338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266829338 : ¬ IsSelfInterpreter e1196266829338 :=
  wSource (t := t_e1196266829338) (replay_sound (ps := []) (t := e1196266829338) (by decide)) (by decide)
def e1196266830362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196266830362 : Closed e1196266830362 ∧ code e1196266830362 = 5594313341466 := by decide
private def t_e1196266830362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196266830362 : ¬ IsSelfInterpreter e1196266830362 :=
  wSource (t := t_e1196266830362) (replay_sound (ps := []) (t := e1196266830362) (by decide)) (by decide)
def e1196282698462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1196282698462 : Closed e1196282698462 ∧ code e1196282698462 = 5594329209566 := by decide
theorem cert_e1196282698462 : check e1196282698462 [[],[.left]] .chain = true := by decide
def e1196282698486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1196282698486 : Closed e1196282698486 ∧ code e1196282698486 = 5594329209590 := by decide
theorem cert_e1196282698486 : check e1196282698486 [[],[.left]] .chain = true := by decide
def e1196282698590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1196282698590 : Closed e1196282698590 ∧ code e1196282698590 = 5594329209694 := by decide
theorem cert_e1196282698590 : check e1196282698590 [[],[.left]] .chain = true := by decide
def e1196282698606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1196282698606 : Closed e1196282698606 ∧ code e1196282698606 = 5594329209710 := by decide
theorem cert_e1196282698606 : check e1196282698606 [[],[.left]] .smaller = true := by decide
def e1196282698614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1196282698614 : Closed e1196282698614 ∧ code e1196282698614 = 5594329209718 := by decide
theorem cert_e1196282698614 : check e1196282698614 [[],[.left]] .smaller = true := by decide
def e1196282698618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1196282698618 : Closed e1196282698618 ∧ code e1196282698618 = 5594329209722 := by decide
theorem cert_e1196282698618 : check e1196282698618 [[],[.left]] .chain = true := by decide
def e1196282698678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1196282698678 : Closed e1196282698678 ∧ code e1196282698678 = 5594329209782 := by decide
theorem cert_e1196282698678 : check e1196282698678 [[],[.left]] .smaller = true := by decide
def e1196282698710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1196282698710 : Closed e1196282698710 ∧ code e1196282698710 = 5594329209814 := by decide
theorem cert_e1196282698710 : check e1196282698710 [[],[.left]] .chain = true := by decide
def e1196282698714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1196282698714 : Closed e1196282698714 ∧ code e1196282698714 = 5594329209818 := by decide
theorem cert_e1196282698714 : check e1196282698714 [[],[.left]] .chain = true := by decide
def e1196282699102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1196282699102 : Closed e1196282699102 ∧ code e1196282699102 = 5594329210206 := by decide
theorem cert_e1196282699102 : check e1196282699102 [[],[.left]] .chain = true := by decide
def e1196282699118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196282699118 : Closed e1196282699118 ∧ code e1196282699118 = 5594329210222 := by decide
theorem cert_e1196282699118 : check e1196282699118 [[],[.left]] .smaller = true := by decide
def e1196282699126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196282699126 : Closed e1196282699126 ∧ code e1196282699126 = 5594329210230 := by decide
theorem cert_e1196282699126 : check e1196282699126 [[],[.left]] .smaller = true := by decide
def e1196282699130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1196282699130 : Closed e1196282699130 ∧ code e1196282699130 = 5594329210234 := by decide
theorem cert_e1196282699130 : check e1196282699130 [[],[.left]] .chain = true := by decide
def e1196282699182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196282699182 : Closed e1196282699182 ∧ code e1196282699182 = 5594329210286 := by decide
theorem cert_e1196282699182 : check e1196282699182 [[],[.left]] .smaller = true := by decide
def e1196282699194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196282699194 : Closed e1196282699194 ∧ code e1196282699194 = 5594329210298 := by decide
theorem cert_e1196282699194 : check e1196282699194 [[],[.left]] .smaller = true := by decide
def e1196282699222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196282699222 : Closed e1196282699222 ∧ code e1196282699222 = 5594329210326 := by decide
theorem cert_e1196282699222 : check e1196282699222 [[],[.left]] .smaller = true := by decide
def e1196282699226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196282699226 : Closed e1196282699226 ∧ code e1196282699226 = 5594329210330 := by decide
theorem cert_e1196282699226 : check e1196282699226 [[],[.left]] .smaller = true := by decide
def e1196282699242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1196282699242 : Closed e1196282699242 ∧ code e1196282699242 = 5594329210346 := by decide
theorem cert_e1196282699242 : check e1196282699242 [[],[.left]] .chain = true := by decide
def e1196282699446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1196282699446 : Closed e1196282699446 ∧ code e1196282699446 = 5594329210550 := by decide
theorem cert_e1196282699446 : check e1196282699446 [[],[.left]] .smaller = true := by decide
def e1196282699478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1196282699478 : Closed e1196282699478 ∧ code e1196282699478 = 5594329210582 := by decide
theorem cert_e1196282699478 : check e1196282699478 [[],[.left]] .smaller = true := by decide
def e1196282699482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1196282699482 : Closed e1196282699482 ∧ code e1196282699482 = 5594329210586 := by decide
theorem cert_e1196282699482 : check e1196282699482 [[],[.left]] .smaller = true := by decide
def e1196282699606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1196282699606 : Closed e1196282699606 ∧ code e1196282699606 = 5594329210710 := by decide
theorem cert_e1196282699606 : check e1196282699606 [[],[.left]] .chain = true := by decide
def e1196282699610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1196282699610 : Closed e1196282699610 ∧ code e1196282699610 = 5594329210714 := by decide
theorem cert_e1196282699610 : check e1196282699610 [[],[.left]] .chain = true := by decide
def e1196282699626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1196282699626 : Closed e1196282699626 ∧ code e1196282699626 = 5594329210730 := by decide
theorem cert_e1196282699626 : check e1196282699626 [[],[.left]] .chain = true := by decide
def e1196282701534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1196282701534 : Closed e1196282701534 ∧ code e1196282701534 = 5594329212638 := by decide
theorem cert_e1196282701534 : check e1196282701534 [[],[.left]] .chain = true := by decide
def e1196282701558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1196282701558 : Closed e1196282701558 ∧ code e1196282701558 = 5594329212662 := by decide
theorem cert_e1196282701558 : check e1196282701558 [[],[.left]] .chain = true := by decide
def e1196282701662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1196282701662 : Closed e1196282701662 ∧ code e1196282701662 = 5594329212766 := by decide
theorem cert_e1196282701662 : check e1196282701662 [[],[.left]] .chain = true := by decide
def e1196282701678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1196282701678 : Closed e1196282701678 ∧ code e1196282701678 = 5594329212782 := by decide
theorem cert_e1196282701678 : check e1196282701678 [[],[.left]] .smaller = true := by decide
def e1196282701686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1196282701686 : Closed e1196282701686 ∧ code e1196282701686 = 5594329212790 := by decide
theorem cert_e1196282701686 : check e1196282701686 [[],[.left]] .smaller = true := by decide
def e1196282701690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1196282701690 : Closed e1196282701690 ∧ code e1196282701690 = 5594329212794 := by decide
theorem cert_e1196282701690 : check e1196282701690 [[],[.left]] .chain = true := by decide
def e1196282701750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1196282701750 : Closed e1196282701750 ∧ code e1196282701750 = 5594329212854 := by decide
theorem cert_e1196282701750 : check e1196282701750 [[],[.left]] .smaller = true := by decide
def e1196282701782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1196282701782 : Closed e1196282701782 ∧ code e1196282701782 = 5594329212886 := by decide
theorem cert_e1196282701782 : check e1196282701782 [[],[.left]] .chain = true := by decide
def e1196282701786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1196282701786 : Closed e1196282701786 ∧ code e1196282701786 = 5594329212890 := by decide
theorem cert_e1196282701786 : check e1196282701786 [[],[.left]] .chain = true := by decide
def e1196282702302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1196282702302 : Closed e1196282702302 ∧ code e1196282702302 = 5594329213406 := by decide
theorem cert_e1196282702302 : check e1196282702302 [[],[.left]] .chain = true := by decide
def e1196282702326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1196282702326 : Closed e1196282702326 ∧ code e1196282702326 = 5594329213430 := by decide
theorem cert_e1196282702326 : check e1196282702326 [[],[.left]] .chain = true := by decide
def e1196282703070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1196282703070 : Closed e1196282703070 ∧ code e1196282703070 = 5594329214174 := by decide
theorem cert_e1196282703070 : check e1196282703070 [[],[.left]] .chain = true := by decide
def e1196282703086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196282703086 : Closed e1196282703086 ∧ code e1196282703086 = 5594329214190 := by decide
theorem cert_e1196282703086 : check e1196282703086 [[],[.left]] .smaller = true := by decide
def e1196282703094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196282703094 : Closed e1196282703094 ∧ code e1196282703094 = 5594329214198 := by decide
theorem cert_e1196282703094 : check e1196282703094 [[],[.left]] .smaller = true := by decide
def e1196282703098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1196282703098 : Closed e1196282703098 ∧ code e1196282703098 = 5594329214202 := by decide
theorem cert_e1196282703098 : check e1196282703098 [[],[.left]] .chain = true := by decide
def e1196282703478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196282703478 : Closed e1196282703478 ∧ code e1196282703478 = 5594329214582 := by decide
theorem cert_e1196282703478 : check e1196282703478 [[],[.left]] .smaller = true := by decide
def e1196282703670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196282703670 : Closed e1196282703670 ∧ code e1196282703670 = 5594329214774 := by decide
theorem cert_e1196282703670 : check e1196282703670 [[],[.left]] .chain = true := by decide
def e1196282703674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196282703674 : Closed e1196282703674 ∧ code e1196282703674 = 5594329214778 := by decide
theorem cert_e1196282703674 : check e1196282703674 [[],[.left]] .chain = true := by decide
def e1196282704734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1196282704734 : Closed e1196282704734 ∧ code e1196282704734 = 5594329215838 := by decide
theorem cert_e1196282704734 : check e1196282704734 [[],[.left]] .chain = true := by decide
def e1196282704750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196282704750 : Closed e1196282704750 ∧ code e1196282704750 = 5594329215854 := by decide
theorem cert_e1196282704750 : check e1196282704750 [[],[.left]] .smaller = true := by decide
def e1196282704758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196282704758 : Closed e1196282704758 ∧ code e1196282704758 = 5594329215862 := by decide
theorem cert_e1196282704758 : check e1196282704758 [[],[.left]] .smaller = true := by decide
def e1196282704762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1196282704762 : Closed e1196282704762 ∧ code e1196282704762 = 5594329215866 := by decide
theorem cert_e1196282704762 : check e1196282704762 [[],[.left]] .chain = true := by decide
def e1196282704814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196282704814 : Closed e1196282704814 ∧ code e1196282704814 = 5594329215918 := by decide
theorem cert_e1196282704814 : check e1196282704814 [[],[.left]] .smaller = true := by decide
def e1196282704826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196282704826 : Closed e1196282704826 ∧ code e1196282704826 = 5594329215930 := by decide
theorem cert_e1196282704826 : check e1196282704826 [[],[.left]] .smaller = true := by decide
def e1196282704854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196282704854 : Closed e1196282704854 ∧ code e1196282704854 = 5594329215958 := by decide
theorem cert_e1196282704854 : check e1196282704854 [[],[.left]] .smaller = true := by decide
def e1196282704858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196282704858 : Closed e1196282704858 ∧ code e1196282704858 = 5594329215962 := by decide
theorem cert_e1196282704858 : check e1196282704858 [[],[.left]] .smaller = true := by decide
def e1196282704874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1196282704874 : Closed e1196282704874 ∧ code e1196282704874 = 5594329215978 := by decide
theorem cert_e1196282704874 : check e1196282704874 [[],[.left]] .chain = true := by decide
def e1196282705118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1196282705118 : Closed e1196282705118 ∧ code e1196282705118 = 5594329216222 := by decide
theorem cert_e1196282705118 : check e1196282705118 [[],[.left]] .chain = true := by decide
def e1196282705134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196282705134 : Closed e1196282705134 ∧ code e1196282705134 = 5594329216238 := by decide
theorem cert_e1196282705134 : check e1196282705134 [[],[.left]] .smaller = true := by decide
def e1196282705142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196282705142 : Closed e1196282705142 ∧ code e1196282705142 = 5594329216246 := by decide
theorem cert_e1196282705142 : check e1196282705142 [[],[.left]] .smaller = true := by decide
def e1196282705146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1196282705146 : Closed e1196282705146 ∧ code e1196282705146 = 5594329216250 := by decide
theorem cert_e1196282705146 : check e1196282705146 [[],[.left]] .chain = true := by decide
def e1196282705518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196282705518 : Closed e1196282705518 ∧ code e1196282705518 = 5594329216622 := by decide
theorem cert_e1196282705518 : check e1196282705518 [[],[.left]] .smaller = true := by decide
def e1196282705530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196282705530 : Closed e1196282705530 ∧ code e1196282705530 = 5594329216634 := by decide
theorem cert_e1196282705530 : check e1196282705530 [[],[.left]] .smaller = true := by decide
def e1196282705718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196282705718 : Closed e1196282705718 ∧ code e1196282705718 = 5594329216822 := by decide
theorem cert_e1196282705718 : check e1196282705718 [[],[.left]] .smaller = true := by decide
def e1196282705722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196282705722 : Closed e1196282705722 ∧ code e1196282705722 = 5594329216826 := by decide
theorem cert_e1196282705722 : check e1196282705722 [[],[.left]] .smaller = true := by decide
def e1196282705818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196282705818 : Closed e1196282705818 ∧ code e1196282705818 = 5594329216922 := by decide
theorem cert_e1196282705818 : check e1196282705818 [[],[.left]] .chain = true := by decide
def e1196282706358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1196282706358 : Closed e1196282706358 ∧ code e1196282706358 = 5594329217462 := by decide
theorem cert_e1196282706358 : check e1196282706358 [[],[.left]] .smaller = true := by decide
def e1196282706390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1196282706390 : Closed e1196282706390 ∧ code e1196282706390 = 5594329217494 := by decide
theorem cert_e1196282706390 : check e1196282706390 [[],[.left]] .smaller = true := by decide
def e1196282706394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1196282706394 : Closed e1196282706394 ∧ code e1196282706394 = 5594329217498 := by decide
theorem cert_e1196282706394 : check e1196282706394 [[],[.left]] .smaller = true := by decide
def e1196282706550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196282706550 : Closed e1196282706550 ∧ code e1196282706550 = 5594329217654 := by decide
theorem cert_e1196282706550 : check e1196282706550 [[],[.left]] .smaller = true := by decide
def e1196282706742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196282706742 : Closed e1196282706742 ∧ code e1196282706742 = 5594329217846 := by decide
theorem cert_e1196282706742 : check e1196282706742 [[],[.left]] .smaller = true := by decide
def e1196282706746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196282706746 : Closed e1196282706746 ∧ code e1196282706746 = 5594329217850 := by decide
theorem cert_e1196282706746 : check e1196282706746 [[],[.left]] .smaller = true := by decide
def e1196282707158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1196282707158 : Closed e1196282707158 ∧ code e1196282707158 = 5594329218262 := by decide
theorem cert_e1196282707158 : check e1196282707158 [[],[.left]] .chain = true := by decide
def e1196282707162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1196282707162 : Closed e1196282707162 ∧ code e1196282707162 = 5594329218266 := by decide
theorem cert_e1196282707162 : check e1196282707162 [[],[.left]] .chain = true := by decide
def e1196282707178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1196282707178 : Closed e1196282707178 ∧ code e1196282707178 = 5594329218282 := by decide
theorem cert_e1196282707178 : check e1196282707178 [[],[.left]] .chain = true := by decide
def e1196282707254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196282707254 : Closed e1196282707254 ∧ code e1196282707254 = 5594329218358 := by decide
theorem cert_e1196282707254 : check e1196282707254 [[],[.left]] .chain = true := by decide
def e1196282707258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196282707258 : Closed e1196282707258 ∧ code e1196282707258 = 5594329218362 := by decide
theorem cert_e1196282707258 : check e1196282707258 [[],[.left]] .chain = true := by decide
def e1196282707354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1196282707354 : Closed e1196282707354 ∧ code e1196282707354 = 5594329218458 := by decide
theorem cert_e1196282707354 : check e1196282707354 [[],[.left]] .chain = true := by decide
def e1196282713822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1196282713822 : Closed e1196282713822 ∧ code e1196282713822 = 5594329224926 := by decide
theorem cert_e1196282713822 : check e1196282713822 [[],[.left]] .chain = true := by decide
def e1196282713846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1196282713846 : Closed e1196282713846 ∧ code e1196282713846 = 5594329224950 := by decide
theorem cert_e1196282713846 : check e1196282713846 [[],[.left]] .chain = true := by decide
def e1196282713950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1196282713950 : Closed e1196282713950 ∧ code e1196282713950 = 5594329225054 := by decide
theorem cert_e1196282713950 : check e1196282713950 [[],[.left]] .chain = true := by decide
def e1196282713966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1196282713966 : Closed e1196282713966 ∧ code e1196282713966 = 5594329225070 := by decide
theorem cert_e1196282713966 : check e1196282713966 [[],[.left]] .smaller = true := by decide
def e1196282713974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1196282713974 : Closed e1196282713974 ∧ code e1196282713974 = 5594329225078 := by decide
theorem cert_e1196282713974 : check e1196282713974 [[],[.left]] .smaller = true := by decide
def e1196282713978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1196282713978 : Closed e1196282713978 ∧ code e1196282713978 = 5594329225082 := by decide
theorem cert_e1196282713978 : check e1196282713978 [[],[.left]] .chain = true := by decide
def e1196282714038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1196282714038 : Closed e1196282714038 ∧ code e1196282714038 = 5594329225142 := by decide
theorem cert_e1196282714038 : check e1196282714038 [[],[.left]] .smaller = true := by decide
def e1196282714070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1196282714070 : Closed e1196282714070 ∧ code e1196282714070 = 5594329225174 := by decide
theorem cert_e1196282714070 : check e1196282714070 [[],[.left]] .chain = true := by decide
def e1196282714074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1196282714074 : Closed e1196282714074 ∧ code e1196282714074 = 5594329225178 := by decide
theorem cert_e1196282714074 : check e1196282714074 [[],[.left]] .chain = true := by decide
def e1196282714590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196282714590 : Closed e1196282714590 ∧ code e1196282714590 = 5594329225694 := by decide
theorem cert_e1196282714590 : check e1196282714590 [[],[.left]] .chain = true := by decide
def e1196282714614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196282714614 : Closed e1196282714614 ∧ code e1196282714614 = 5594329225718 := by decide
theorem cert_e1196282714614 : check e1196282714614 [[],[.left]] .chain = true := by decide
def e1196282715358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196282715358 : Closed e1196282715358 ∧ code e1196282715358 = 5594329226462 := by decide
theorem cert_e1196282715358 : check e1196282715358 [[],[.left]] .chain = true := by decide
def e1196282715374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196282715374 : Closed e1196282715374 ∧ code e1196282715374 = 5594329226478 := by decide
theorem cert_e1196282715374 : check e1196282715374 [[],[.left]] .smaller = true := by decide
def e1196282715382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196282715382 : Closed e1196282715382 ∧ code e1196282715382 = 5594329226486 := by decide
theorem cert_e1196282715382 : check e1196282715382 [[],[.left]] .smaller = true := by decide
def e1196282715386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196282715386 : Closed e1196282715386 ∧ code e1196282715386 = 5594329226490 := by decide
theorem cert_e1196282715386 : check e1196282715386 [[],[.left]] .chain = true := by decide
def e1196282715766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196282715766 : Closed e1196282715766 ∧ code e1196282715766 = 5594329226870 := by decide
theorem cert_e1196282715766 : check e1196282715766 [[],[.left]] .smaller = true := by decide
def e1196282715958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196282715958 : Closed e1196282715958 ∧ code e1196282715958 = 5594329227062 := by decide
theorem cert_e1196282715958 : check e1196282715958 [[],[.left]] .chain = true := by decide
def e1196282715962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196282715962 : Closed e1196282715962 ∧ code e1196282715962 = 5594329227066 := by decide
theorem cert_e1196282715962 : check e1196282715962 [[],[.left]] .chain = true := by decide
end Blc.Floor42
