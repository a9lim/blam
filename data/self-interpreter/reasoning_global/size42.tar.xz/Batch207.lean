import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205521006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205521006 : Closed e1211205521006 ∧ code e1211205521006 = 5609252032110 := by decide
theorem cert_e1211205521006 : check e1211205521006 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205521014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205521014 : Closed e1211205521014 ∧ code e1211205521014 = 5609252032118 := by decide
theorem cert_e1211205521014 : check e1211205521014 [[],[]] .chain = true := by decide
def e1211205521018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205521018 : Closed e1211205521018 ∧ code e1211205521018 = 5609252032122 := by decide
theorem cert_e1211205521018 : check e1211205521018 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205521206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205521206 : Closed e1211205521206 ∧ code e1211205521206 = 5609252032310 := by decide
theorem cert_e1211205521206 : check e1211205521206 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205521210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205521210 : Closed e1211205521210 ∧ code e1211205521210 = 5609252032314 := by decide
theorem cert_e1211205521210 : check e1211205521210 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205523126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211205523126 : Closed e1211205523126 ∧ code e1211205523126 = 5609252034230 := by decide
theorem cert_e1211205523126 : check e1211205523126 [[],[]] .chain = true := by decide
def e1211205523158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211205523158 : Closed e1211205523158 ∧ code e1211205523158 = 5609252034262 := by decide
theorem cert_e1211205523158 : check e1211205523158 [[],[]] .chain = true := by decide
def e1211205523162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e1211205523162 : Closed e1211205523162 ∧ code e1211205523162 = 5609252034266 := by decide
theorem cert_e1211205523162 : check e1211205523162 [[],[]] .chain = true := by decide
def e1211205523286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e1211205523286 : Closed e1211205523286 ∧ code e1211205523286 = 5609252034390 := by decide
theorem cert_e1211205523286 : check e1211205523286 [[],[]] .chain = true := by decide
def e1211205523290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211205523290 : Closed e1211205523290 ∧ code e1211205523290 = 5609252034394 := by decide
theorem cert_e1211205523290 : check e1211205523290 [[],[]] .chain = true := by decide
def e1211205523306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211205523306 : Closed e1211205523306 ∧ code e1211205523306 = 5609252034410 := by decide
theorem cert_e1211205523306 : check e1211205523306 [[],[]] .chain = true := by decide
def e1211205523510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 1))))))
theorem wire_e1211205523510 : Closed e1211205523510 ∧ code e1211205523510 = 5609252034614 := by decide
theorem cert_e1211205523510 : check e1211205523510 [[],[]] .chain = true := by decide
def e1211205523598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.var 2)))))))
theorem wire_e1211205523598 : Closed e1211205523598 ∧ code e1211205523598 = 5609252034702 := by decide
theorem cert_e1211205523598 : check e1211205523598 [[],[]] .chain = true := by decide
def e1211205523682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.var 0)))))))
theorem wire_e1211205523682 : Closed e1211205523682 ∧ code e1211205523682 = 5609252034786 := by decide
theorem cert_e1211205523682 : check e1211205523682 [[],[]] .chain = true := by decide
def e1211205523694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211205523694 : Closed e1211205523694 ∧ code e1211205523694 = 5609252034798 := by decide
theorem cert_e1211205523694 : check e1211205523694 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205523702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211205523702 : Closed e1211205523702 ∧ code e1211205523702 = 5609252034806 := by decide
theorem cert_e1211205523702 : check e1211205523702 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205523894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211205523894 : Closed e1211205523894 ∧ code e1211205523894 = 5609252034998 := by decide
theorem cert_e1211205523894 : check e1211205523894 [[],[]] .chain = true := by decide
def e1211205523926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211205523926 : Closed e1211205523926 ∧ code e1211205523926 = 5609252035030 := by decide
theorem cert_e1211205523926 : check e1211205523926 [[],[]] .chain = true := by decide
def e1211205523930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e1211205523930 : Closed e1211205523930 ∧ code e1211205523930 = 5609252035034 := by decide
theorem cert_e1211205523930 : check e1211205523930 [[],[]] .chain = true := by decide
def e1211205524086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205524086 : Closed e1211205524086 ∧ code e1211205524086 = 5609252035190 := by decide
theorem cert_e1211205524086 : check e1211205524086 [[],[]] .chain = true := by decide
def e1211205524230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205524230 : Closed e1211205524230 ∧ code e1211205524230 = 5609252035334 := by decide
theorem cert_e1211205524230 : check e1211205524230 [[],[]] .chain = true := by decide
def e1211205524254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211205524254 : Closed e1211205524254 ∧ code e1211205524254 = 5609252035358 := by decide
theorem cert_e1211205524254 : check e1211205524254 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205524278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205524278 : Closed e1211205524278 ∧ code e1211205524278 = 5609252035382 := by decide
theorem cert_e1211205524278 : check e1211205524278 [[],[]] .chain = true := by decide
def e1211205524282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205524282 : Closed e1211205524282 ∧ code e1211205524282 = 5609252035386 := by decide
theorem cert_e1211205524282 : check e1211205524282 [[],[]] .chain = true := by decide
def e1211205524366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211205524366 : Closed e1211205524366 ∧ code e1211205524366 = 5609252035470 := by decide
theorem cert_e1211205524366 : check e1211205524366 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205524502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211205524502 : Closed e1211205524502 ∧ code e1211205524502 = 5609252035606 := by decide
theorem cert_e1211205524502 : check e1211205524502 [[],[]] .chain = true := by decide
def e1211205524506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211205524506 : Closed e1211205524506 ∧ code e1211205524506 = 5609252035610 := by decide
theorem cert_e1211205524506 : check e1211205524506 [[],[]] .chain = true := by decide
def e1211205524550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211205524550 : Closed e1211205524550 ∧ code e1211205524550 = 5609252035654 := by decide
theorem cert_e1211205524550 : check e1211205524550 [[],[]] .chain = true := by decide
def e1211205524578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211205524578 : Closed e1211205524578 ∧ code e1211205524578 = 5609252035682 := by decide
theorem cert_e1211205524578 : check e1211205524578 [[],[]] .chain = true := by decide
def e1211205524590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211205524590 : Closed e1211205524590 ∧ code e1211205524590 = 5609252035694 := by decide
theorem cert_e1211205524590 : check e1211205524590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205524598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211205524598 : Closed e1211205524598 ∧ code e1211205524598 = 5609252035702 := by decide
theorem cert_e1211205524598 : check e1211205524598 [[],[]] .chain = true := by decide
def e1211205524602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211205524602 : Closed e1211205524602 ∧ code e1211205524602 = 5609252035706 := by decide
theorem cert_e1211205524602 : check e1211205524602 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205524694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1211205524694 : Closed e1211205524694 ∧ code e1211205524694 = 5609252035798 := by decide
theorem cert_e1211205524694 : check e1211205524694 [[],[]] .chain = true := by decide
def e1211205524698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211205524698 : Closed e1211205524698 ∧ code e1211205524698 = 5609252035802 := by decide
theorem cert_e1211205524698 : check e1211205524698 [[],[]] .chain = true := by decide
def e1211205524714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211205524714 : Closed e1211205524714 ∧ code e1211205524714 = 5609252035818 := by decide
theorem cert_e1211205524714 : check e1211205524714 [[],[]] .chain = true := by decide
def e1211205524742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205524742 : Closed e1211205524742 ∧ code e1211205524742 = 5609252035846 := by decide
theorem cert_e1211205524742 : check e1211205524742 [[],[]] .chain = true := by decide
def e1211205524766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211205524766 : Closed e1211205524766 ∧ code e1211205524766 = 5609252035870 := by decide
theorem cert_e1211205524766 : check e1211205524766 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205524790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205524790 : Closed e1211205524790 ∧ code e1211205524790 = 5609252035894 := by decide
theorem cert_e1211205524790 : check e1211205524790 [[],[]] .chain = true := by decide
def e1211205524794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205524794 : Closed e1211205524794 ∧ code e1211205524794 = 5609252035898 := by decide
theorem cert_e1211205524794 : check e1211205524794 [[],[]] .chain = true := by decide
def e1211205524866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205524866 : Closed e1211205524866 ∧ code e1211205524866 = 5609252035970 := by decide
theorem cert_e1211205524866 : check e1211205524866 [[],[]] .chain = true := by decide
def e1211205524878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211205524878 : Closed e1211205524878 ∧ code e1211205524878 = 5609252035982 := by decide
theorem cert_e1211205524878 : check e1211205524878 [[],[]] .chain = true := by decide
def e1211205524890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205524890 : Closed e1211205524890 ∧ code e1211205524890 = 5609252035994 := by decide
theorem cert_e1211205524890 : check e1211205524890 [[],[]] .chain = true := by decide
def e1211205524934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211205524934 : Closed e1211205524934 ∧ code e1211205524934 = 5609252036038 := by decide
theorem cert_e1211205524934 : check e1211205524934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205525046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211205525046 : Closed e1211205525046 ∧ code e1211205525046 = 5609252036150 := by decide
theorem cert_e1211205525046 : check e1211205525046 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205525050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211205525050 : Closed e1211205525050 ∧ code e1211205525050 = 5609252036154 := by decide
theorem cert_e1211205525050 : check e1211205525050 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205525134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211205525134 : Closed e1211205525134 ∧ code e1211205525134 = 5609252036238 := by decide
theorem cert_e1211205525134 : check e1211205525134 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205525190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211205525190 : Closed e1211205525190 ∧ code e1211205525190 = 5609252036294 := by decide
theorem cert_e1211205525190 : check e1211205525190 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205525566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e1211205525566 : Closed e1211205525566 ∧ code e1211205525566 = 5609252036670 := by decide
theorem cert_e1211205525566 : check e1211205525566 [[],[]] .chain = true := by decide
def e1211205525986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211205525986 : Closed e1211205525986 ∧ code e1211205525986 = 5609252037090 := by decide
theorem cert_e1211205525986 : check e1211205525986 [[],[]] .chain = true := by decide
def e1211205525998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1211205525998 : Closed e1211205525998 ∧ code e1211205525998 = 5609252037102 := by decide
theorem cert_e1211205525998 : check e1211205525998 [[],[]] .chain = true := by decide
def e1211205526966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211205526966 : Closed e1211205526966 ∧ code e1211205526966 = 5609252038070 := by decide
theorem cert_e1211205526966 : check e1211205526966 [[],[]] .chain = true := by decide
def e1211205526998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211205526998 : Closed e1211205526998 ∧ code e1211205526998 = 5609252038102 := by decide
theorem cert_e1211205526998 : check e1211205526998 [[],[]] .chain = true := by decide
def e1211205527002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211205527002 : Closed e1211205527002 ∧ code e1211205527002 = 5609252038106 := by decide
theorem cert_e1211205527002 : check e1211205527002 [[],[]] .chain = true := by decide
def e1211205527158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205527158 : Closed e1211205527158 ∧ code e1211205527158 = 5609252038262 := by decide
theorem cert_e1211205527158 : check e1211205527158 [[],[]] .chain = true := by decide
def e1211205527302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205527302 : Closed e1211205527302 ∧ code e1211205527302 = 5609252038406 := by decide
theorem cert_e1211205527302 : check e1211205527302 [[],[]] .chain = true := by decide
def e1211205527326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211205527326 : Closed e1211205527326 ∧ code e1211205527326 = 5609252038430 := by decide
theorem cert_e1211205527326 : check e1211205527326 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205527350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205527350 : Closed e1211205527350 ∧ code e1211205527350 = 5609252038454 := by decide
theorem cert_e1211205527350 : check e1211205527350 [[],[]] .chain = true := by decide
def e1211205527354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205527354 : Closed e1211205527354 ∧ code e1211205527354 = 5609252038458 := by decide
theorem cert_e1211205527354 : check e1211205527354 [[],[]] .chain = true := by decide
def e1211205527438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211205527438 : Closed e1211205527438 ∧ code e1211205527438 = 5609252038542 := by decide
theorem cert_e1211205527438 : check e1211205527438 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205529630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211205529630 : Closed e1211205529630 ∧ code e1211205529630 = 5609252040734 := by decide
theorem cert_e1211205529630 : check e1211205529630 [[],[]] .chain = true := by decide
def e1211205529798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205529798 : Closed e1211205529798 ∧ code e1211205529798 = 5609252040902 := by decide
theorem cert_e1211205529798 : check e1211205529798 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205529822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211205529822 : Closed e1211205529822 ∧ code e1211205529822 = 5609252040926 := by decide
theorem cert_e1211205529822 : check e1211205529822 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205529826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211205529826 : Closed e1211205529826 ∧ code e1211205529826 = 5609252040930 := by decide
theorem cert_e1211205529826 : check e1211205529826 [[],[]] .chain = true := by decide
def e1211205529838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211205529838 : Closed e1211205529838 ∧ code e1211205529838 = 5609252040942 := by decide
theorem cert_e1211205529838 : check e1211205529838 [[],[]] .chain = true := by decide
def e1211205529846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211205529846 : Closed e1211205529846 ∧ code e1211205529846 = 5609252040950 := by decide
theorem cert_e1211205529846 : check e1211205529846 [[],[]] .chain = true := by decide
def e1211205529850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211205529850 : Closed e1211205529850 ∧ code e1211205529850 = 5609252040954 := by decide
theorem cert_e1211205529850 : check e1211205529850 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205530326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211205530326 : Closed e1211205530326 ∧ code e1211205530326 = 5609252041430 := by decide
theorem cert_e1211205530326 : check e1211205530326 [[],[]] .chain = true := by decide
def e1211205530330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211205530330 : Closed e1211205530330 ∧ code e1211205530330 = 5609252041434 := by decide
theorem cert_e1211205530330 : check e1211205530330 [[],[]] .chain = true := by decide
def e1211205530346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211205530346 : Closed e1211205530346 ∧ code e1211205530346 = 5609252041450 := by decide
theorem cert_e1211205530346 : check e1211205530346 [[],[]] .chain = true := by decide
def e1211205530374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205530374 : Closed e1211205530374 ∧ code e1211205530374 = 5609252041478 := by decide
theorem cert_e1211205530374 : check e1211205530374 [[],[]] .chain = true := by decide
def e1211205530398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211205530398 : Closed e1211205530398 ∧ code e1211205530398 = 5609252041502 := by decide
theorem cert_e1211205530398 : check e1211205530398 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205530422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205530422 : Closed e1211205530422 ∧ code e1211205530422 = 5609252041526 := by decide
theorem cert_e1211205530422 : check e1211205530422 [[],[]] .chain = true := by decide
def e1211205530426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205530426 : Closed e1211205530426 ∧ code e1211205530426 = 5609252041530 := by decide
theorem cert_e1211205530426 : check e1211205530426 [[],[]] .chain = true := by decide
def e1211205530498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205530498 : Closed e1211205530498 ∧ code e1211205530498 = 5609252041602 := by decide
theorem cert_e1211205530498 : check e1211205530498 [[],[]] .chain = true := by decide
def e1211205530510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211205530510 : Closed e1211205530510 ∧ code e1211205530510 = 5609252041614 := by decide
theorem cert_e1211205530510 : check e1211205530510 [[],[]] .chain = true := by decide
def e1211205530522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205530522 : Closed e1211205530522 ∧ code e1211205530522 = 5609252041626 := by decide
theorem cert_e1211205530522 : check e1211205530522 [[],[]] .chain = true := by decide
def e1211205530566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211205530566 : Closed e1211205530566 ∧ code e1211205530566 = 5609252041670 := by decide
theorem cert_e1211205530566 : check e1211205530566 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205531758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e1211205531758 : Closed e1211205531758 ∧ code e1211205531758 = 5609252042862 := by decide
theorem cert_e1211205531758 : check e1211205531758 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205531770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e1211205531770 : Closed e1211205531770 ∧ code e1211205531770 = 5609252042874 := by decide
theorem cert_e1211205531770 : check e1211205531770 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205532046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205532046 : Closed e1211205532046 ∧ code e1211205532046 = 5609252043150 := by decide
theorem cert_e1211205532046 : check e1211205532046 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205532102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205532102 : Closed e1211205532102 ∧ code e1211205532102 = 5609252043206 := by decide
theorem cert_e1211205532102 : check e1211205532102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205533818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))) (.var 0))))))
theorem wire_e1211205533818 : Closed e1211205533818 ∧ code e1211205533818 = 5609252044922 := by decide
theorem cert_e1211205533818 : check e1211205533818 [[],[]] .chain = true := by decide
def e1211205534006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205534006 : Closed e1211205534006 ∧ code e1211205534006 = 5609252045110 := by decide
theorem cert_e1211205534006 : check e1211205534006 [[],[]] .chain = true := by decide
def e1211205534010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205534010 : Closed e1211205534010 ∧ code e1211205534010 = 5609252045114 := by decide
theorem cert_e1211205534010 : check e1211205534010 [[],[]] .chain = true := by decide
def e1211205534106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205534106 : Closed e1211205534106 ∧ code e1211205534106 = 5609252045210 := by decide
theorem cert_e1211205534106 : check e1211205534106 [[],[]] .chain = true := by decide
def e1211205534150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.lam (.var 1)))))))
theorem wire_e1211205534150 : Closed e1211205534150 ∧ code e1211205534150 = 5609252045254 := by decide
theorem cert_e1211205534150 : check e1211205534150 [[],[]] .chain = true := by decide
def e1211205534490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211205534490 : Closed e1211205534490 ∧ code e1211205534490 = 5609252045594 := by decide
theorem cert_e1211205534490 : check e1211205534490 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205534534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211205534534 : Closed e1211205534534 ∧ code e1211205534534 = 5609252045638 := by decide
theorem cert_e1211205534534 : check e1211205534534 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205534574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211205534574 : Closed e1211205534574 ∧ code e1211205534574 = 5609252045678 := by decide
theorem cert_e1211205534574 : check e1211205534574 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205534586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e1211205534586 : Closed e1211205534586 ∧ code e1211205534586 = 5609252045690 := by decide
theorem cert_e1211205534586 : check e1211205534586 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205534602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205534602 : Closed e1211205534602 ∧ code e1211205534602 = 5609252045706 := by decide
theorem cert_e1211205534602 : check e1211205534602 [[],[]] .chain = true := by decide
def e1211205534638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211205534638 : Closed e1211205534638 ∧ code e1211205534638 = 5609252045742 := by decide
theorem cert_e1211205534638 : check e1211205534638 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205534646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e1211205534646 : Closed e1211205534646 ∧ code e1211205534646 = 5609252045750 := by decide
theorem cert_e1211205534646 : check e1211205534646 [[],[]] .chain = true := by decide
def e1211205534650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211205534650 : Closed e1211205534650 ∧ code e1211205534650 = 5609252045754 := by decide
theorem cert_e1211205534650 : check e1211205534650 [[],[]] .chain = true := by decide
def e1211205534682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211205534682 : Closed e1211205534682 ∧ code e1211205534682 = 5609252045786 := by decide
theorem cert_e1211205534682 : check e1211205534682 [[],[]] .chain = true := by decide
def e1211205534698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e1211205534698 : Closed e1211205534698 ∧ code e1211205534698 = 5609252045802 := by decide
theorem cert_e1211205534698 : check e1211205534698 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205534918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211205534918 : Closed e1211205534918 ∧ code e1211205534918 = 5609252046022 := by decide
theorem cert_e1211205534918 : check e1211205534918 [[],[]] .chain = true := by decide
def e1211205535246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.lam (.var 2))))))))
theorem wire_e1211205535246 : Closed e1211205535246 ∧ code e1211205535246 = 5609252046350 := by decide
theorem cert_e1211205535246 : check e1211205535246 [[],[]] .chain = true := by decide
def e1211205535258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211205535258 : Closed e1211205535258 ∧ code e1211205535258 = 5609252046362 := by decide
theorem cert_e1211205535258 : check e1211205535258 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205535330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211205535330 : Closed e1211205535330 ∧ code e1211205535330 = 5609252046434 := by decide
theorem cert_e1211205535330 : check e1211205535330 [[],[]] .chain = true := by decide
def e1211205535342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205535342 : Closed e1211205535342 ∧ code e1211205535342 = 5609252046446 := by decide
theorem cert_e1211205535342 : check e1211205535342 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205535350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205535350 : Closed e1211205535350 ∧ code e1211205535350 = 5609252046454 := by decide
theorem cert_e1211205535350 : check e1211205535350 [[],[]] .chain = true := by decide
def e1211205535354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205535354 : Closed e1211205535354 ∧ code e1211205535354 = 5609252046458 := by decide
theorem cert_e1211205535354 : check e1211205535354 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205535542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205535542 : Closed e1211205535542 ∧ code e1211205535542 = 5609252046646 := by decide
theorem cert_e1211205535542 : check e1211205535542 [[],[]] .chain = true := by decide
def e1211205535546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205535546 : Closed e1211205535546 ∧ code e1211205535546 = 5609252046650 := by decide
theorem cert_e1211205535546 : check e1211205535546 [[],[]] .chain = true := by decide
def e1211205535642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205535642 : Closed e1211205535642 ∧ code e1211205535642 = 5609252046746 := by decide
theorem cert_e1211205535642 : check e1211205535642 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205536598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e1211205536598 : Closed e1211205536598 ∧ code e1211205536598 = 5609252047702 := by decide
theorem cert_e1211205536598 : check e1211205536598 [[],[]] .chain = true := by decide
def e1211205536602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211205536602 : Closed e1211205536602 ∧ code e1211205536602 = 5609252047706 := by decide
theorem cert_e1211205536602 : check e1211205536602 [[],[]] .chain = true := by decide
def e1211205536618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211205536618 : Closed e1211205536618 ∧ code e1211205536618 = 5609252047722 := by decide
theorem cert_e1211205536618 : check e1211205536618 [[],[]] .chain = true := by decide
def e1211205536682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e1211205536682 : Closed e1211205536682 ∧ code e1211205536682 = 5609252047786 := by decide
theorem cert_e1211205536682 : check e1211205536682 [[],[]] .chain = true := by decide
def e1211205536790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211205536790 : Closed e1211205536790 ∧ code e1211205536790 = 5609252047894 := by decide
theorem cert_e1211205536790 : check e1211205536790 [[],[]] .chain = true := by decide
def e1211205536794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211205536794 : Closed e1211205536794 ∧ code e1211205536794 = 5609252047898 := by decide
theorem cert_e1211205536794 : check e1211205536794 [[],[]] .chain = true := by decide
def e1211205536838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211205536838 : Closed e1211205536838 ∧ code e1211205536838 = 5609252047942 := by decide
theorem cert_e1211205536838 : check e1211205536838 [[],[]] .chain = true := by decide
def e1211205536866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211205536866 : Closed e1211205536866 ∧ code e1211205536866 = 5609252047970 := by decide
theorem cert_e1211205536866 : check e1211205536866 [[],[]] .chain = true := by decide
def e1211205536878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211205536878 : Closed e1211205536878 ∧ code e1211205536878 = 5609252047982 := by decide
theorem cert_e1211205536878 : check e1211205536878 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205536886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211205536886 : Closed e1211205536886 ∧ code e1211205536886 = 5609252047990 := by decide
theorem cert_e1211205536886 : check e1211205536886 [[],[]] .chain = true := by decide
def e1211205536890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211205536890 : Closed e1211205536890 ∧ code e1211205536890 = 5609252047994 := by decide
theorem cert_e1211205536890 : check e1211205536890 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205536982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1211205536982 : Closed e1211205536982 ∧ code e1211205536982 = 5609252048086 := by decide
theorem cert_e1211205536982 : check e1211205536982 [[],[]] .chain = true := by decide
def e1211205536986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211205536986 : Closed e1211205536986 ∧ code e1211205536986 = 5609252048090 := by decide
theorem cert_e1211205536986 : check e1211205536986 [[],[]] .chain = true := by decide
def e1211205537002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211205537002 : Closed e1211205537002 ∧ code e1211205537002 = 5609252048106 := by decide
theorem cert_e1211205537002 : check e1211205537002 [[],[]] .chain = true := by decide
def e1211205537030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205537030 : Closed e1211205537030 ∧ code e1211205537030 = 5609252048134 := by decide
theorem cert_e1211205537030 : check e1211205537030 [[],[]] .chain = true := by decide
def e1211205537054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211205537054 : Closed e1211205537054 ∧ code e1211205537054 = 5609252048158 := by decide
theorem cert_e1211205537054 : check e1211205537054 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205537078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205537078 : Closed e1211205537078 ∧ code e1211205537078 = 5609252048182 := by decide
theorem cert_e1211205537078 : check e1211205537078 [[],[]] .chain = true := by decide
def e1211205537082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205537082 : Closed e1211205537082 ∧ code e1211205537082 = 5609252048186 := by decide
theorem cert_e1211205537082 : check e1211205537082 [[],[]] .chain = true := by decide
def e1211205537154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205537154 : Closed e1211205537154 ∧ code e1211205537154 = 5609252048258 := by decide
theorem cert_e1211205537154 : check e1211205537154 [[],[]] .chain = true := by decide
def e1211205537166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211205537166 : Closed e1211205537166 ∧ code e1211205537166 = 5609252048270 := by decide
theorem cert_e1211205537166 : check e1211205537166 [[],[]] .chain = true := by decide
def e1211205537178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205537178 : Closed e1211205537178 ∧ code e1211205537178 = 5609252048282 := by decide
theorem cert_e1211205537178 : check e1211205537178 [[],[]] .chain = true := by decide
def e1211205537222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211205537222 : Closed e1211205537222 ∧ code e1211205537222 = 5609252048326 := by decide
theorem cert_e1211205537222 : check e1211205537222 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205537290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205537290 : Closed e1211205537290 ∧ code e1211205537290 = 5609252048394 := by decide
theorem cert_e1211205537290 : check e1211205537290 [[],[]] .chain = true := by decide
def e1211205537334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211205537334 : Closed e1211205537334 ∧ code e1211205537334 = 5609252048438 := by decide
theorem cert_e1211205537334 : check e1211205537334 [[],[]] .chain = true := by decide
def e1211205537338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211205537338 : Closed e1211205537338 ∧ code e1211205537338 = 5609252048442 := by decide
theorem cert_e1211205537338 : check e1211205537338 [[],[]] .chain = true := by decide
def e1211205537386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e1211205537386 : Closed e1211205537386 ∧ code e1211205537386 = 5609252048490 := by decide
theorem cert_e1211205537386 : check e1211205537386 [[],[]] .chain = true := by decide
def e1211205537410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205537410 : Closed e1211205537410 ∧ code e1211205537410 = 5609252048514 := by decide
theorem cert_e1211205537410 : check e1211205537410 [[],[]] .chain = true := by decide
def e1211205537422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211205537422 : Closed e1211205537422 ∧ code e1211205537422 = 5609252048526 := by decide
theorem cert_e1211205537422 : check e1211205537422 [[],[]] .chain = true := by decide
def e1211205537434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205537434 : Closed e1211205537434 ∧ code e1211205537434 = 5609252048538 := by decide
theorem cert_e1211205537434 : check e1211205537434 [[],[]] .chain = true := by decide
def e1211205537478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211205537478 : Closed e1211205537478 ∧ code e1211205537478 = 5609252048582 := by decide
theorem cert_e1211205537478 : check e1211205537478 [[],[]] .chain = true := by decide
def e1211205537562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205537562 : Closed e1211205537562 ∧ code e1211205537562 = 5609252048666 := by decide
theorem cert_e1211205537562 : check e1211205537562 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205537606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205537606 : Closed e1211205537606 ∧ code e1211205537606 = 5609252048710 := by decide
theorem cert_e1211205537606 : check e1211205537606 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205537822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211205537822 : Closed e1211205537822 ∧ code e1211205537822 = 5609252048926 := by decide
theorem cert_e1211205537822 : check e1211205537822 [[],[]] .chain = true := by decide
def e1211205537990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205537990 : Closed e1211205537990 ∧ code e1211205537990 = 5609252049094 := by decide
theorem cert_e1211205537990 : check e1211205537990 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205538014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211205538014 : Closed e1211205538014 ∧ code e1211205538014 = 5609252049118 := by decide
theorem cert_e1211205538014 : check e1211205538014 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205538018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211205538018 : Closed e1211205538018 ∧ code e1211205538018 = 5609252049122 := by decide
theorem cert_e1211205538018 : check e1211205538018 [[],[]] .chain = true := by decide
def e1211205538030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211205538030 : Closed e1211205538030 ∧ code e1211205538030 = 5609252049134 := by decide
theorem cert_e1211205538030 : check e1211205538030 [[],[]] .chain = true := by decide
def e1211205538038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211205538038 : Closed e1211205538038 ∧ code e1211205538038 = 5609252049142 := by decide
theorem cert_e1211205538038 : check e1211205538038 [[],[]] .chain = true := by decide
def e1211205538042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211205538042 : Closed e1211205538042 ∧ code e1211205538042 = 5609252049146 := by decide
theorem cert_e1211205538042 : check e1211205538042 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205538518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211205538518 : Closed e1211205538518 ∧ code e1211205538518 = 5609252049622 := by decide
theorem cert_e1211205538518 : check e1211205538518 [[],[]] .chain = true := by decide
def e1211205538522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211205538522 : Closed e1211205538522 ∧ code e1211205538522 = 5609252049626 := by decide
theorem cert_e1211205538522 : check e1211205538522 [[],[]] .chain = true := by decide
def e1211205538538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211205538538 : Closed e1211205538538 ∧ code e1211205538538 = 5609252049642 := by decide
theorem cert_e1211205538538 : check e1211205538538 [[],[]] .chain = true := by decide
def e1211205538566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205538566 : Closed e1211205538566 ∧ code e1211205538566 = 5609252049670 := by decide
theorem cert_e1211205538566 : check e1211205538566 [[],[]] .chain = true := by decide
def e1211205538590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211205538590 : Closed e1211205538590 ∧ code e1211205538590 = 5609252049694 := by decide
theorem cert_e1211205538590 : check e1211205538590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205538614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205538614 : Closed e1211205538614 ∧ code e1211205538614 = 5609252049718 := by decide
theorem cert_e1211205538614 : check e1211205538614 [[],[]] .chain = true := by decide
def e1211205538618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205538618 : Closed e1211205538618 ∧ code e1211205538618 = 5609252049722 := by decide
theorem cert_e1211205538618 : check e1211205538618 [[],[]] .chain = true := by decide
def e1211205538690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205538690 : Closed e1211205538690 ∧ code e1211205538690 = 5609252049794 := by decide
theorem cert_e1211205538690 : check e1211205538690 [[],[]] .chain = true := by decide
def e1211205538702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211205538702 : Closed e1211205538702 ∧ code e1211205538702 = 5609252049806 := by decide
theorem cert_e1211205538702 : check e1211205538702 [[],[]] .chain = true := by decide
def e1211205538714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205538714 : Closed e1211205538714 ∧ code e1211205538714 = 5609252049818 := by decide
theorem cert_e1211205538714 : check e1211205538714 [[],[]] .chain = true := by decide
def e1211205538758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211205538758 : Closed e1211205538758 ∧ code e1211205538758 = 5609252049862 := by decide
theorem cert_e1211205538758 : check e1211205538758 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205539958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e1211205539958 : Closed e1211205539958 ∧ code e1211205539958 = 5609252051062 := by decide
theorem cert_e1211205539958 : check e1211205539958 [[],[]] .chain = true := by decide
def e1211205540202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e1211205540202 : Closed e1211205540202 ∧ code e1211205540202 = 5609252051306 := by decide
theorem cert_e1211205540202 : check e1211205540202 [[],[]] .chain = true := by decide
def e1211205540226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205540226 : Closed e1211205540226 ∧ code e1211205540226 = 5609252051330 := by decide
theorem cert_e1211205540226 : check e1211205540226 [[],[]] .chain = true := by decide
def e1211205540238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205540238 : Closed e1211205540238 ∧ code e1211205540238 = 5609252051342 := by decide
theorem cert_e1211205540238 : check e1211205540238 [[],[]] .chain = true := by decide
end Blc.Floor42
