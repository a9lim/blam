import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302459696366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302459696366 : Closed e302459696366 ∧ code e302459696366 = 4700506207470 := by decide
theorem cert_e302459696366 : check e302459696366 [[.under],[.under]] .smaller = true := by decide
def e302459696374 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302459696374 : Closed e302459696374 ∧ code e302459696374 = 4700506207478 := by decide
theorem cert_e302459696374 : check e302459696374 [[.under],[.under]] .smaller = true := by decide
def e302459696750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302459696750 : Closed e302459696750 ∧ code e302459696750 = 4700506207854 := by decide
theorem cert_e302459696750 : check e302459696750 [[.under],[.under]] .smaller = true := by decide
def e302459696762 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302459696762 : Closed e302459696762 ∧ code e302459696762 = 4700506207866 := by decide
theorem cert_e302459696762 : check e302459696762 [[.under],[.under]] .smaller = true := by decide
def e302459696950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302459696950 : Closed e302459696950 ∧ code e302459696950 = 4700506208054 := by decide
theorem cert_e302459696950 : check e302459696950 [[.under],[.under]] .smaller = true := by decide
def e302459696954 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302459696954 : Closed e302459696954 ∧ code e302459696954 = 4700506208058 := by decide
theorem cert_e302459696954 : check e302459696954 [[.under],[.under]] .smaller = true := by decide
def e302459697582 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302459697582 : Closed e302459697582 ∧ code e302459697582 = 4700506208686 := by decide
theorem cert_e302459697582 : check e302459697582 [[.under],[.under]] .smaller = true := by decide
def e302459697594 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302459697594 : Closed e302459697594 ∧ code e302459697594 = 4700506208698 := by decide
theorem cert_e302459697594 : check e302459697594 [[.under],[.under]] .smaller = true := by decide
def e302459697642 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302459697642 : Closed e302459697642 ∧ code e302459697642 = 4700506208746 := by decide
theorem cert_e302459697642 : check e302459697642 [[.under],[.under]] .smaller = true := by decide
def e302459697774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302459697774 : Closed e302459697774 ∧ code e302459697774 = 4700506208878 := by decide
theorem cert_e302459697774 : check e302459697774 [[.under],[.under]] .smaller = true := by decide
def e302459697786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302459697786 : Closed e302459697786 ∧ code e302459697786 = 4700506208890 := by decide
theorem cert_e302459697786 : check e302459697786 [[.under],[.under]] .smaller = true := by decide
def e302459698074 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302459698074 : Closed e302459698074 ∧ code e302459698074 = 4700506209178 := by decide
theorem cert_e302459698074 : check e302459698074 [[.under],[.under]] .smaller = true := by decide
def e302459698390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302459698390 : Closed e302459698390 ∧ code e302459698390 = 4700506209494 := by decide
theorem cert_e302459698390 : check e302459698390 [[.under],[.under]] .smaller = true := by decide
def e302459698394 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302459698394 : Closed e302459698394 ∧ code e302459698394 = 4700506209498 := by decide
theorem cert_e302459698394 : check e302459698394 [[.under],[.under]] .smaller = true := by decide
def e302459698410 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302459698410 : Closed e302459698410 ∧ code e302459698410 = 4700506209514 := by decide
theorem cert_e302459698410 : check e302459698410 [[.under],[.under]] .smaller = true := by decide
def e302459698486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302459698486 : Closed e302459698486 ∧ code e302459698486 = 4700506209590 := by decide
theorem cert_e302459698486 : check e302459698486 [[.under],[.under]] .smaller = true := by decide
def e302459698490 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302459698490 : Closed e302459698490 ∧ code e302459698490 = 4700506209594 := by decide
theorem cert_e302459698490 : check e302459698490 [[.under],[.under]] .smaller = true := by decide
def e302459698586 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302459698586 : Closed e302459698586 ∧ code e302459698586 = 4700506209690 := by decide
theorem cert_e302459698586 : check e302459698586 [[.under],[.under]] .smaller = true := by decide
def e302459702126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302459702126 : Closed e302459702126 ∧ code e302459702126 = 4700506213230 := by decide
theorem cert_e302459702126 : check e302459702126 [[.under],[.under]] .smaller = true := by decide
def e302459702134 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302459702134 : Closed e302459702134 ∧ code e302459702134 = 4700506213238 := by decide
theorem cert_e302459702134 : check e302459702134 [[.under],[.under]] .smaller = true := by decide
def e302459702190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302459702190 : Closed e302459702190 ∧ code e302459702190 = 4700506213294 := by decide
theorem cert_e302459702190 : check e302459702190 [[.under],[.under]] .smaller = true := by decide
def e302459702202 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302459702202 : Closed e302459702202 ∧ code e302459702202 = 4700506213306 := by decide
theorem cert_e302459702202 : check e302459702202 [[.under],[.under]] .smaller = true := by decide
def e302459702230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302459702230 : Closed e302459702230 ∧ code e302459702230 = 4700506213334 := by decide
theorem cert_e302459702230 : check e302459702230 [[.under],[.under]] .smaller = true := by decide
def e302459702234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302459702234 : Closed e302459702234 ∧ code e302459702234 = 4700506213338 := by decide
theorem cert_e302459702234 : check e302459702234 [[.under],[.under]] .smaller = true := by decide
def e302459702510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302459702510 : Closed e302459702510 ∧ code e302459702510 = 4700506213614 := by decide
theorem cert_e302459702510 : check e302459702510 [[.under],[.under]] .smaller = true := by decide
def e302459702518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302459702518 : Closed e302459702518 ∧ code e302459702518 = 4700506213622 := by decide
theorem cert_e302459702518 : check e302459702518 [[.under],[.under]] .smaller = true := by decide
def e302459702894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302459702894 : Closed e302459702894 ∧ code e302459702894 = 4700506213998 := by decide
theorem cert_e302459702894 : check e302459702894 [[.under],[.under]] .smaller = true := by decide
def e302459702906 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302459702906 : Closed e302459702906 ∧ code e302459702906 = 4700506214010 := by decide
theorem cert_e302459702906 : check e302459702906 [[.under],[.under]] .smaller = true := by decide
def e302459703094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302459703094 : Closed e302459703094 ∧ code e302459703094 = 4700506214198 := by decide
theorem cert_e302459703094 : check e302459703094 [[.under],[.under]] .smaller = true := by decide
def e302459703098 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302459703098 : Closed e302459703098 ∧ code e302459703098 = 4700506214202 := by decide
theorem cert_e302459703098 : check e302459703098 [[.under],[.under]] .smaller = true := by decide
def e302459708846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302459708846 : Closed e302459708846 ∧ code e302459708846 = 4700506219950 := by decide
theorem cert_e302459708846 : check e302459708846 [[.under],[.under]] .smaller = true := by decide
def e302459708858 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302459708858 : Closed e302459708858 ∧ code e302459708858 = 4700506219962 := by decide
theorem cert_e302459708858 : check e302459708858 [[.under],[.under]] .smaller = true := by decide
def e302459708906 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302459708906 : Closed e302459708906 ∧ code e302459708906 = 4700506220010 := by decide
theorem cert_e302459708906 : check e302459708906 [[.under],[.under]] .smaller = true := by decide
def e302459709038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302459709038 : Closed e302459709038 ∧ code e302459709038 = 4700506220142 := by decide
theorem cert_e302459709038 : check e302459709038 [[.under],[.under]] .smaller = true := by decide
def e302459709050 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302459709050 : Closed e302459709050 ∧ code e302459709050 = 4700506220154 := by decide
theorem cert_e302459709050 : check e302459709050 [[.under],[.under]] .smaller = true := by decide
def e302459709338 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302459709338 : Closed e302459709338 ∧ code e302459709338 = 4700506220442 := by decide
theorem cert_e302459709338 : check e302459709338 [[.under],[.under]] .smaller = true := by decide
def e302459712214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302459712214 : Closed e302459712214 ∧ code e302459712214 = 4700506223318 := by decide
theorem cert_e302459712214 : check e302459712214 [[.under],[.under]] .smaller = true := by decide
def e302459712218 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302459712218 : Closed e302459712218 ∧ code e302459712218 = 4700506223322 := by decide
theorem cert_e302459712218 : check e302459712218 [[.under],[.under]] .smaller = true := by decide
def e302459712234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302459712234 : Closed e302459712234 ∧ code e302459712234 = 4700506223338 := by decide
theorem cert_e302459712234 : check e302459712234 [[.under],[.under]] .smaller = true := by decide
def e302459712310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302459712310 : Closed e302459712310 ∧ code e302459712310 = 4700506223414 := by decide
theorem cert_e302459712310 : check e302459712310 [[.under],[.under]] .smaller = true := by decide
def e302459712314 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302459712314 : Closed e302459712314 ∧ code e302459712314 = 4700506223418 := by decide
theorem cert_e302459712314 : check e302459712314 [[.under],[.under]] .smaller = true := by decide
def e302459712410 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302459712410 : Closed e302459712410 ∧ code e302459712410 = 4700506223514 := by decide
theorem cert_e302459712410 : check e302459712410 [[.under],[.under]] .smaller = true := by decide
def e302459827950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e302459827950 : Closed e302459827950 ∧ code e302459827950 = 4700506339054 := by decide
theorem cert_e302459827950 : check e302459827950 [[.under],[.under]] .three = true := by decide
def e302459828078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e302459828078 : Closed e302459828078 ∧ code e302459828078 = 4700506339182 := by decide
theorem cert_e302459828078 : check e302459828078 [[.under],[.under]] .three = true := by decide
def e302459828086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e302459828086 : Closed e302459828086 ∧ code e302459828086 = 4700506339190 := by decide
theorem cert_e302459828086 : check e302459828086 [[.under],[.under]] .three = true := by decide
def e302459828974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e302459828974 : Closed e302459828974 ∧ code e302459828974 = 4700506340078 := by decide
theorem cert_e302459828974 : check e302459828974 [[.under],[.under]] .three = true := by decide
def e302459829166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e302459829166 : Closed e302459829166 ∧ code e302459829166 = 4700506340270 := by decide
theorem cert_e302459829166 : check e302459829166 [[.under],[.under]] .three = true := by decide
def e302459829178 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e302459829178 : Closed e302459829178 ∧ code e302459829178 = 4700506340282 := by decide
theorem cert_e302459829178 : check e302459829178 [[.under],[.under]] .three = true := by decide
def e302459829614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302459829614 : Closed e302459829614 ∧ code e302459829614 = 4700506340718 := by decide
theorem cert_e302459829614 : check e302459829614 [[.under],[.under]] .three = true := by decide
def e302459829622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302459829622 : Closed e302459829622 ∧ code e302459829622 = 4700506340726 := by decide
theorem cert_e302459829622 : check e302459829622 [[.under],[.under]] .three = true := by decide
def e302459829678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302459829678 : Closed e302459829678 ∧ code e302459829678 = 4700506340782 := by decide
theorem cert_e302459829678 : check e302459829678 [[.under],[.under]] .three = true := by decide
def e302459829690 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302459829690 : Closed e302459829690 ∧ code e302459829690 = 4700506340794 := by decide
theorem cert_e302459829690 : check e302459829690 [[.under],[.under]] .three = true := by decide
def e302459829718 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302459829718 : Closed e302459829718 ∧ code e302459829718 = 4700506340822 := by decide
theorem cert_e302459829718 : check e302459829718 [[.under],[.under]] .three = true := by decide
def e302459829722 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302459829722 : Closed e302459829722 ∧ code e302459829722 = 4700506340826 := by decide
theorem cert_e302459829722 : check e302459829722 [[.under],[.under]] .three = true := by decide
def e302459834094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e302459834094 : Closed e302459834094 ∧ code e302459834094 = 4700506345198 := by decide
theorem cert_e302459834094 : check e302459834094 [[.under],[.under]] .three = true := by decide
def e302459834222 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e302459834222 : Closed e302459834222 ∧ code e302459834222 = 4700506345326 := by decide
theorem cert_e302459834222 : check e302459834222 [[.under],[.under]] .three = true := by decide
def e302459834230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e302459834230 : Closed e302459834230 ∧ code e302459834230 = 4700506345334 := by decide
theorem cert_e302459834230 : check e302459834230 [[.under],[.under]] .three = true := by decide
def e302459836910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e302459836910 : Closed e302459836910 ∧ code e302459836910 = 4700506348014 := by decide
theorem cert_e302459836910 : check e302459836910 [[.under],[.under]] .three = true := by decide
def e302459837678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e302459837678 : Closed e302459837678 ∧ code e302459837678 = 4700506348782 := by decide
theorem cert_e302459837678 : check e302459837678 [[.under],[.under]] .three = true := by decide
def e302459837686 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e302459837686 : Closed e302459837686 ∧ code e302459837686 = 4700506348790 := by decide
theorem cert_e302459837686 : check e302459837686 [[.under],[.under]] .three = true := by decide
def e302459840238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e302459840238 : Closed e302459840238 ∧ code e302459840238 = 4700506351342 := by decide
theorem cert_e302459840238 : check e302459840238 [[.under],[.under]] .three = true := by decide
def e302459840430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e302459840430 : Closed e302459840430 ∧ code e302459840430 = 4700506351534 := by decide
theorem cert_e302459840430 : check e302459840430 [[.under],[.under]] .three = true := by decide
def e302459840442 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e302459840442 : Closed e302459840442 ∧ code e302459840442 = 4700506351546 := by decide
theorem cert_e302459840442 : check e302459840442 [[.under],[.under]] .three = true := by decide
def e302459841006 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e302459841006 : Closed e302459841006 ∧ code e302459841006 = 4700506352110 := by decide
theorem cert_e302459841006 : check e302459841006 [[.under],[.under]] .three = true := by decide
def e302459842158 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e302459842158 : Closed e302459842158 ∧ code e302459842158 = 4700506353262 := by decide
theorem cert_e302459842158 : check e302459842158 [[.under],[.under]] .three = true := by decide
def e302459842170 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e302459842170 : Closed e302459842170 ∧ code e302459842170 = 4700506353274 := by decide
theorem cert_e302459842170 : check e302459842170 [[.under],[.under]] .three = true := by decide
def e302459843438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302459843438 : Closed e302459843438 ∧ code e302459843438 = 4700506354542 := by decide
theorem cert_e302459843438 : check e302459843438 [[.under],[.under]] .three = true := by decide
def e302459843446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302459843446 : Closed e302459843446 ∧ code e302459843446 = 4700506354550 := by decide
theorem cert_e302459843446 : check e302459843446 [[.under],[.under]] .three = true := by decide
def e302459843502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302459843502 : Closed e302459843502 ∧ code e302459843502 = 4700506354606 := by decide
theorem cert_e302459843502 : check e302459843502 [[.under],[.under]] .three = true := by decide
def e302459843514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302459843514 : Closed e302459843514 ∧ code e302459843514 = 4700506354618 := by decide
theorem cert_e302459843514 : check e302459843514 [[.under],[.under]] .three = true := by decide
def e302459843542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302459843542 : Closed e302459843542 ∧ code e302459843542 = 4700506354646 := by decide
theorem cert_e302459843542 : check e302459843542 [[.under],[.under]] .three = true := by decide
def e302459843546 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302459843546 : Closed e302459843546 ∧ code e302459843546 = 4700506354650 := by decide
theorem cert_e302459843546 : check e302459843546 [[.under],[.under]] .three = true := by decide
def e302459843822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302459843822 : Closed e302459843822 ∧ code e302459843822 = 4700506354926 := by decide
theorem cert_e302459843822 : check e302459843822 [[.under],[.under]] .three = true := by decide
def e302459843830 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302459843830 : Closed e302459843830 ∧ code e302459843830 = 4700506354934 := by decide
theorem cert_e302459843830 : check e302459843830 [[.under],[.under]] .three = true := by decide
def e302459844206 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302459844206 : Closed e302459844206 ∧ code e302459844206 = 4700506355310 := by decide
theorem cert_e302459844206 : check e302459844206 [[.under],[.under]] .three = true := by decide
def e302459844218 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302459844218 : Closed e302459844218 ∧ code e302459844218 = 4700506355322 := by decide
theorem cert_e302459844218 : check e302459844218 [[.under],[.under]] .three = true := by decide
def e302459844406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302459844406 : Closed e302459844406 ∧ code e302459844406 = 4700506355510 := by decide
theorem cert_e302459844406 : check e302459844406 [[.under],[.under]] .three = true := by decide
def e302459844410 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302459844410 : Closed e302459844410 ∧ code e302459844410 = 4700506355514 := by decide
theorem cert_e302459844410 : check e302459844410 [[.under],[.under]] .three = true := by decide
def e302459849582 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302459849582 : Closed e302459849582 ∧ code e302459849582 = 4700506360686 := by decide
theorem cert_e302459849582 : check e302459849582 [[.under],[.under]] .smaller = true := by decide
def e302459849590 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302459849590 : Closed e302459849590 ∧ code e302459849590 = 4700506360694 := by decide
theorem cert_e302459849590 : check e302459849590 [[.under],[.under]] .smaller = true := by decide
def e302459849646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302459849646 : Closed e302459849646 ∧ code e302459849646 = 4700506360750 := by decide
theorem cert_e302459849646 : check e302459849646 [[.under],[.under]] .smaller = true := by decide
def e302459849658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302459849658 : Closed e302459849658 ∧ code e302459849658 = 4700506360762 := by decide
theorem cert_e302459849658 : check e302459849658 [[.under],[.under]] .smaller = true := by decide
def e302459849686 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302459849686 : Closed e302459849686 ∧ code e302459849686 = 4700506360790 := by decide
theorem cert_e302459849686 : check e302459849686 [[.under],[.under]] .smaller = true := by decide
def e302459849690 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302459849690 : Closed e302459849690 ∧ code e302459849690 = 4700506360794 := by decide
theorem cert_e302459849690 : check e302459849690 [[.under],[.under]] .smaller = true := by decide
def e302459849966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302459849966 : Closed e302459849966 ∧ code e302459849966 = 4700506361070 := by decide
theorem cert_e302459849966 : check e302459849966 [[.under],[.under]] .smaller = true := by decide
def e302459849974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302459849974 : Closed e302459849974 ∧ code e302459849974 = 4700506361078 := by decide
theorem cert_e302459849974 : check e302459849974 [[.under],[.under]] .smaller = true := by decide
def e302459850350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302459850350 : Closed e302459850350 ∧ code e302459850350 = 4700506361454 := by decide
theorem cert_e302459850350 : check e302459850350 [[.under],[.under]] .smaller = true := by decide
def e302459850362 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302459850362 : Closed e302459850362 ∧ code e302459850362 = 4700506361466 := by decide
theorem cert_e302459850362 : check e302459850362 [[.under],[.under]] .smaller = true := by decide
def e302459850550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302459850550 : Closed e302459850550 ∧ code e302459850550 = 4700506361654 := by decide
theorem cert_e302459850550 : check e302459850550 [[.under],[.under]] .smaller = true := by decide
def e302459850554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302459850554 : Closed e302459850554 ∧ code e302459850554 = 4700506361658 := by decide
theorem cert_e302459850554 : check e302459850554 [[.under],[.under]] .smaller = true := by decide
def e302459858670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e302459858670 : Closed e302459858670 ∧ code e302459858670 = 4700506369774 := by decide
theorem cert_e302459858670 : check e302459858670 [[.under],[.under]] .three = true := by decide
def e302459858798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e302459858798 : Closed e302459858798 ∧ code e302459858798 = 4700506369902 := by decide
theorem cert_e302459858798 : check e302459858798 [[.under],[.under]] .three = true := by decide
def e302459858806 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e302459858806 : Closed e302459858806 ∧ code e302459858806 = 4700506369910 := by decide
theorem cert_e302459858806 : check e302459858806 [[.under],[.under]] .three = true := by decide
def e302459861486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e302459861486 : Closed e302459861486 ∧ code e302459861486 = 4700506372590 := by decide
theorem cert_e302459861486 : check e302459861486 [[.under],[.under]] .three = true := by decide
def e302459862254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e302459862254 : Closed e302459862254 ∧ code e302459862254 = 4700506373358 := by decide
theorem cert_e302459862254 : check e302459862254 [[.under],[.under]] .three = true := by decide
def e302459862262 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e302459862262 : Closed e302459862262 ∧ code e302459862262 = 4700506373366 := by decide
theorem cert_e302459862262 : check e302459862262 [[.under],[.under]] .three = true := by decide
def e302459885294 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e302459885294 : Closed e302459885294 ∧ code e302459885294 = 4700506396398 := by decide
theorem cert_e302459885294 : check e302459885294 [[.under],[.under]] .three = true := by decide
def e302459885486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e302459885486 : Closed e302459885486 ∧ code e302459885486 = 4700506396590 := by decide
theorem cert_e302459885486 : check e302459885486 [[.under],[.under]] .three = true := by decide
def e302459885498 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e302459885498 : Closed e302459885498 ∧ code e302459885498 = 4700506396602 := by decide
theorem cert_e302459885498 : check e302459885498 [[.under],[.under]] .three = true := by decide
def e302459886062 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e302459886062 : Closed e302459886062 ∧ code e302459886062 = 4700506397166 := by decide
theorem cert_e302459886062 : check e302459886062 [[.under],[.under]] .three = true := by decide
def e302459887214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e302459887214 : Closed e302459887214 ∧ code e302459887214 = 4700506398318 := by decide
theorem cert_e302459887214 : check e302459887214 [[.under],[.under]] .three = true := by decide
def e302459887226 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e302459887226 : Closed e302459887226 ∧ code e302459887226 = 4700506398330 := by decide
theorem cert_e302459887226 : check e302459887226 [[.under],[.under]] .three = true := by decide
def e302459898734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302459898734 : Closed e302459898734 ∧ code e302459898734 = 4700506409838 := by decide
theorem cert_e302459898734 : check e302459898734 [[.under],[.under]] .three = true := by decide
def e302459898742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302459898742 : Closed e302459898742 ∧ code e302459898742 = 4700506409846 := by decide
theorem cert_e302459898742 : check e302459898742 [[.under],[.under]] .three = true := by decide
def e302459898798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302459898798 : Closed e302459898798 ∧ code e302459898798 = 4700506409902 := by decide
theorem cert_e302459898798 : check e302459898798 [[.under],[.under]] .three = true := by decide
def e302459898810 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302459898810 : Closed e302459898810 ∧ code e302459898810 = 4700506409914 := by decide
theorem cert_e302459898810 : check e302459898810 [[.under],[.under]] .three = true := by decide
def e302459898838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302459898838 : Closed e302459898838 ∧ code e302459898838 = 4700506409942 := by decide
theorem cert_e302459898838 : check e302459898838 [[.under],[.under]] .three = true := by decide
def e302459898842 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302459898842 : Closed e302459898842 ∧ code e302459898842 = 4700506409946 := by decide
theorem cert_e302459898842 : check e302459898842 [[.under],[.under]] .three = true := by decide
def e302459899118 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302459899118 : Closed e302459899118 ∧ code e302459899118 = 4700506410222 := by decide
theorem cert_e302459899118 : check e302459899118 [[.under],[.under]] .three = true := by decide
def e302459899126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302459899126 : Closed e302459899126 ∧ code e302459899126 = 4700506410230 := by decide
theorem cert_e302459899126 : check e302459899126 [[.under],[.under]] .three = true := by decide
def e302459899502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302459899502 : Closed e302459899502 ∧ code e302459899502 = 4700506410606 := by decide
theorem cert_e302459899502 : check e302459899502 [[.under],[.under]] .three = true := by decide
def e302459899514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302459899514 : Closed e302459899514 ∧ code e302459899514 = 4700506410618 := by decide
theorem cert_e302459899514 : check e302459899514 [[.under],[.under]] .three = true := by decide
def e302459899702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302459899702 : Closed e302459899702 ∧ code e302459899702 = 4700506410806 := by decide
theorem cert_e302459899702 : check e302459899702 [[.under],[.under]] .three = true := by decide
def e302459899706 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302459899706 : Closed e302459899706 ∧ code e302459899706 = 4700506410810 := by decide
theorem cert_e302459899706 : check e302459899706 [[.under],[.under]] .three = true := by decide
def e302460439406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302460439406 : Closed e302460439406 ∧ code e302460439406 = 4700506950510 := by decide
theorem cert_e302460439406 : check e302460439406 [[.under],[.under]] .smaller = true := by decide
def e302460439414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302460439414 : Closed e302460439414 ∧ code e302460439414 = 4700506950518 := by decide
theorem cert_e302460439414 : check e302460439414 [[.under],[.under]] .smaller = true := by decide
def e302460439470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302460439470 : Closed e302460439470 ∧ code e302460439470 = 4700506950574 := by decide
theorem cert_e302460439470 : check e302460439470 [[.under],[.under]] .smaller = true := by decide
def e302460439482 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302460439482 : Closed e302460439482 ∧ code e302460439482 = 4700506950586 := by decide
theorem cert_e302460439482 : check e302460439482 [[.under],[.under]] .smaller = true := by decide
def e302460439510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302460439510 : Closed e302460439510 ∧ code e302460439510 = 4700506950614 := by decide
theorem cert_e302460439510 : check e302460439510 [[.under],[.under]] .smaller = true := by decide
def e302460439514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302460439514 : Closed e302460439514 ∧ code e302460439514 = 4700506950618 := by decide
theorem cert_e302460439514 : check e302460439514 [[.under],[.under]] .smaller = true := by decide
def e302460439790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302460439790 : Closed e302460439790 ∧ code e302460439790 = 4700506950894 := by decide
theorem cert_e302460439790 : check e302460439790 [[.under],[.under]] .smaller = true := by decide
def e302460439798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302460439798 : Closed e302460439798 ∧ code e302460439798 = 4700506950902 := by decide
theorem cert_e302460439798 : check e302460439798 [[.under],[.under]] .smaller = true := by decide
def e302460440174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302460440174 : Closed e302460440174 ∧ code e302460440174 = 4700506951278 := by decide
theorem cert_e302460440174 : check e302460440174 [[.under],[.under]] .smaller = true := by decide
def e302460440186 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302460440186 : Closed e302460440186 ∧ code e302460440186 = 4700506951290 := by decide
theorem cert_e302460440186 : check e302460440186 [[.under],[.under]] .smaller = true := by decide
def e302460440374 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302460440374 : Closed e302460440374 ∧ code e302460440374 = 4700506951478 := by decide
theorem cert_e302460440374 : check e302460440374 [[.under],[.under]] .smaller = true := by decide
def e302460440378 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302460440378 : Closed e302460440378 ∧ code e302460440378 = 4700506951482 := by decide
theorem cert_e302460440378 : check e302460440378 [[.under],[.under]] .smaller = true := by decide
def e302593912174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302593912174 : Closed e302593912174 ∧ code e302593912174 = 4700640423278 := by decide
theorem cert_e302593912174 : check e302593912174 [[.under],[.under]] .smaller = true := by decide
def e302593912182 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302593912182 : Closed e302593912182 ∧ code e302593912182 = 4700640423286 := by decide
theorem cert_e302593912182 : check e302593912182 [[.under],[.under]] .smaller = true := by decide
def e302593912238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302593912238 : Closed e302593912238 ∧ code e302593912238 = 4700640423342 := by decide
theorem cert_e302593912238 : check e302593912238 [[.under],[.under]] .smaller = true := by decide
def e302593912250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302593912250 : Closed e302593912250 ∧ code e302593912250 = 4700640423354 := by decide
theorem cert_e302593912250 : check e302593912250 [[.under],[.under]] .smaller = true := by decide
def e302593912278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302593912278 : Closed e302593912278 ∧ code e302593912278 = 4700640423382 := by decide
theorem cert_e302593912278 : check e302593912278 [[.under],[.under]] .smaller = true := by decide
def e302593912282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302593912282 : Closed e302593912282 ∧ code e302593912282 = 4700640423386 := by decide
theorem cert_e302593912282 : check e302593912282 [[.under],[.under]] .smaller = true := by decide
def e302593912494 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302593912494 : Closed e302593912494 ∧ code e302593912494 = 4700640423598 := by decide
theorem cert_e302593912494 : check e302593912494 [[.under],[.under]] .smaller = true := by decide
def e302593912506 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302593912506 : Closed e302593912506 ∧ code e302593912506 = 4700640423610 := by decide
theorem cert_e302593912506 : check e302593912506 [[.under],[.under]] .smaller = true := by decide
def e302593912554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302593912554 : Closed e302593912554 ∧ code e302593912554 = 4700640423658 := by decide
theorem cert_e302593912554 : check e302593912554 [[.under],[.under]] .smaller = true := by decide
def e302593912662 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302593912662 : Closed e302593912662 ∧ code e302593912662 = 4700640423766 := by decide
theorem cert_e302593912662 : check e302593912662 [[.under],[.under]] .smaller = true := by decide
def e302593912666 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302593912666 : Closed e302593912666 ∧ code e302593912666 = 4700640423770 := by decide
theorem cert_e302593912666 : check e302593912666 [[.under],[.under]] .smaller = true := by decide
def e302593912682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302593912682 : Closed e302593912682 ∧ code e302593912682 = 4700640423786 := by decide
theorem cert_e302593912682 : check e302593912682 [[.under],[.under]] .smaller = true := by decide
def e302593913710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302593913710 : Closed e302593913710 ∧ code e302593913710 = 4700640424814 := by decide
theorem cert_e302593913710 : check e302593913710 [[.under],[.under]] .smaller = true := by decide
def e302593913718 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302593913718 : Closed e302593913718 ∧ code e302593913718 = 4700640424822 := by decide
theorem cert_e302593913718 : check e302593913718 [[.under],[.under]] .smaller = true := by decide
def e302593913774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302593913774 : Closed e302593913774 ∧ code e302593913774 = 4700640424878 := by decide
theorem cert_e302593913774 : check e302593913774 [[.under],[.under]] .smaller = true := by decide
def e302593913786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302593913786 : Closed e302593913786 ∧ code e302593913786 = 4700640424890 := by decide
theorem cert_e302593913786 : check e302593913786 [[.under],[.under]] .smaller = true := by decide
def e302593913814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302593913814 : Closed e302593913814 ∧ code e302593913814 = 4700640424918 := by decide
theorem cert_e302593913814 : check e302593913814 [[.under],[.under]] .smaller = true := by decide
def e302593913818 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302593913818 : Closed e302593913818 ∧ code e302593913818 = 4700640424922 := by decide
theorem cert_e302593913818 : check e302593913818 [[.under],[.under]] .smaller = true := by decide
def e302593914094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302593914094 : Closed e302593914094 ∧ code e302593914094 = 4700640425198 := by decide
theorem cert_e302593914094 : check e302593914094 [[.under],[.under]] .smaller = true := by decide
def e302593914102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302593914102 : Closed e302593914102 ∧ code e302593914102 = 4700640425206 := by decide
theorem cert_e302593914102 : check e302593914102 [[.under],[.under]] .smaller = true := by decide
def e302593914478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302593914478 : Closed e302593914478 ∧ code e302593914478 = 4700640425582 := by decide
theorem cert_e302593914478 : check e302593914478 [[.under],[.under]] .smaller = true := by decide
def e302593914490 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302593914490 : Closed e302593914490 ∧ code e302593914490 = 4700640425594 := by decide
theorem cert_e302593914490 : check e302593914490 [[.under],[.under]] .smaller = true := by decide
def e302593914678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302593914678 : Closed e302593914678 ∧ code e302593914678 = 4700640425782 := by decide
theorem cert_e302593914678 : check e302593914678 [[.under],[.under]] .smaller = true := by decide
def e302593914682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302593914682 : Closed e302593914682 ∧ code e302593914682 = 4700640425786 := by decide
theorem cert_e302593914682 : check e302593914682 [[.under],[.under]] .smaller = true := by decide
def e302593915310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302593915310 : Closed e302593915310 ∧ code e302593915310 = 4700640426414 := by decide
theorem cert_e302593915310 : check e302593915310 [[.under],[.under]] .smaller = true := by decide
def e302593915322 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302593915322 : Closed e302593915322 ∧ code e302593915322 = 4700640426426 := by decide
theorem cert_e302593915322 : check e302593915322 [[.under],[.under]] .smaller = true := by decide
def e302593915370 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302593915370 : Closed e302593915370 ∧ code e302593915370 = 4700640426474 := by decide
theorem cert_e302593915370 : check e302593915370 [[.under],[.under]] .smaller = true := by decide
def e302593915502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302593915502 : Closed e302593915502 ∧ code e302593915502 = 4700640426606 := by decide
theorem cert_e302593915502 : check e302593915502 [[.under],[.under]] .smaller = true := by decide
def e302593915514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302593915514 : Closed e302593915514 ∧ code e302593915514 = 4700640426618 := by decide
theorem cert_e302593915514 : check e302593915514 [[.under],[.under]] .smaller = true := by decide
def e302593915802 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302593915802 : Closed e302593915802 ∧ code e302593915802 = 4700640426906 := by decide
theorem cert_e302593915802 : check e302593915802 [[.under],[.under]] .smaller = true := by decide
def e302593916118 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302593916118 : Closed e302593916118 ∧ code e302593916118 = 4700640427222 := by decide
theorem cert_e302593916118 : check e302593916118 [[.under],[.under]] .smaller = true := by decide
def e302593916122 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302593916122 : Closed e302593916122 ∧ code e302593916122 = 4700640427226 := by decide
theorem cert_e302593916122 : check e302593916122 [[.under],[.under]] .smaller = true := by decide
def e302593916138 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302593916138 : Closed e302593916138 ∧ code e302593916138 = 4700640427242 := by decide
theorem cert_e302593916138 : check e302593916138 [[.under],[.under]] .smaller = true := by decide
def e302593916214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302593916214 : Closed e302593916214 ∧ code e302593916214 = 4700640427318 := by decide
theorem cert_e302593916214 : check e302593916214 [[.under],[.under]] .smaller = true := by decide
end Blc.Floor42
