import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182823878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211182823878 : Closed e1211182823878 ∧ code e1211182823878 = 5609229334982 := by decide
theorem cert_e1211182823878 : check e1211182823878 [[],[]] .smaller = true := by decide
def e1211182823918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211182823918 : Closed e1211182823918 ∧ code e1211182823918 = 5609229335022 := by decide
theorem cert_e1211182823918 : check e1211182823918 [[],[]] .smaller = true := by decide
def e1211182824646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211182824646 : Closed e1211182824646 ∧ code e1211182824646 = 5609229335750 := by decide
theorem cert_e1211182824646 : check e1211182824646 [[],[]] .smaller = true := by decide
def e1211182824670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182824670 : Closed e1211182824670 ∧ code e1211182824670 = 5609229335774 := by decide
theorem cert_e1211182824670 : check e1211182824670 [[],[]] .smaller = true := by decide
def e1211182824686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182824686 : Closed e1211182824686 ∧ code e1211182824686 = 5609229335790 := by decide
theorem cert_e1211182824686 : check e1211182824686 [[],[]] .smaller = true := by decide
def e1211182824694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182824694 : Closed e1211182824694 ∧ code e1211182824694 = 5609229335798 := by decide
theorem cert_e1211182824694 : check e1211182824694 [[],[]] .smaller = true := by decide
def e1211182824698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182824698 : Closed e1211182824698 ∧ code e1211182824698 = 5609229335802 := by decide
theorem cert_e1211182824698 : check e1211182824698 [[],[]] .smaller = true := by decide
def e1211182825070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182825070 : Closed e1211182825070 ∧ code e1211182825070 = 5609229336174 := by decide
theorem cert_e1211182825070 : check e1211182825070 [[],[]] .smaller = true := by decide
def e1211182825082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182825082 : Closed e1211182825082 ∧ code e1211182825082 = 5609229336186 := by decide
theorem cert_e1211182825082 : check e1211182825082 [[],[]] .smaller = true := by decide
def e1211182847542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211182847542 : Closed e1211182847542 ∧ code e1211182847542 = 5609229358646 := by decide
theorem cert_e1211182847542 : check e1211182847542 [[],[]] .three = true := by decide
def e1211182847546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211182847546 : Closed e1211182847546 ∧ code e1211182847546 = 5609229358650 := by decide
theorem cert_e1211182847546 : check e1211182847546 [[],[]] .three = true := by decide
def e1211182847630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211182847630 : Closed e1211182847630 ∧ code e1211182847630 = 5609229358734 := by decide
theorem cert_e1211182847630 : check e1211182847630 [[],[]] .three = true := by decide
def e1211182847686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211182847686 : Closed e1211182847686 ∧ code e1211182847686 = 5609229358790 := by decide
theorem cert_e1211182847686 : check e1211182847686 [[],[]] .three = true := by decide
def e1211182847726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1211182847726 : Closed e1211182847726 ∧ code e1211182847726 = 5609229358830 := by decide
theorem cert_e1211182847726 : check e1211182847726 [[],[]] .three = true := by decide
def e1211182847770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211182847770 : Closed e1211182847770 ∧ code e1211182847770 = 5609229358874 := by decide
theorem cert_e1211182847770 : check e1211182847770 [[],[]] .three = true := by decide
def e1211182847814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211182847814 : Closed e1211182847814 ∧ code e1211182847814 = 5609229358918 := by decide
theorem cert_e1211182847814 : check e1211182847814 [[],[]] .three = true := by decide
def e1211182847854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211182847854 : Closed e1211182847854 ∧ code e1211182847854 = 5609229358958 := by decide
theorem cert_e1211182847854 : check e1211182847854 [[],[]] .three = true := by decide
def e1211182847862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211182847862 : Closed e1211182847862 ∧ code e1211182847862 = 5609229358966 := by decide
theorem cert_e1211182847862 : check e1211182847862 [[],[]] .three = true := by decide
def e1211182847918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1211182847918 : Closed e1211182847918 ∧ code e1211182847918 = 5609229359022 := by decide
theorem cert_e1211182847918 : check e1211182847918 [[],[]] .three = true := by decide
def e1211182847926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211182847926 : Closed e1211182847926 ∧ code e1211182847926 = 5609229359030 := by decide
theorem cert_e1211182847926 : check e1211182847926 [[],[]] .three = true := by decide
def e1211182847930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1211182847930 : Closed e1211182847930 ∧ code e1211182847930 = 5609229359034 := by decide
theorem cert_e1211182847930 : check e1211182847930 [[],[]] .three = true := by decide
def e1211182848398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211182848398 : Closed e1211182848398 ∧ code e1211182848398 = 5609229359502 := by decide
theorem cert_e1211182848398 : check e1211182848398 [[],[]] .three = true := by decide
def e1211182848454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211182848454 : Closed e1211182848454 ∧ code e1211182848454 = 5609229359558 := by decide
theorem cert_e1211182848454 : check e1211182848454 [[],[]] .three = true := by decide
def e1211182848494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211182848494 : Closed e1211182848494 ∧ code e1211182848494 = 5609229359598 := by decide
theorem cert_e1211182848494 : check e1211182848494 [[],[]] .three = true := by decide
def e1211182849222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211182849222 : Closed e1211182849222 ∧ code e1211182849222 = 5609229360326 := by decide
theorem cert_e1211182849222 : check e1211182849222 [[],[]] .three = true := by decide
def e1211182849262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182849262 : Closed e1211182849262 ∧ code e1211182849262 = 5609229360366 := by decide
theorem cert_e1211182849262 : check e1211182849262 [[],[]] .three = true := by decide
def e1211182849270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182849270 : Closed e1211182849270 ∧ code e1211182849270 = 5609229360374 := by decide
theorem cert_e1211182849270 : check e1211182849270 [[],[]] .three = true := by decide
def e1211182849646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182849646 : Closed e1211182849646 ∧ code e1211182849646 = 5609229360750 := by decide
theorem cert_e1211182849646 : check e1211182849646 [[],[]] .three = true := by decide
def e1211182849654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182849654 : Closed e1211182849654 ∧ code e1211182849654 = 5609229360758 := by decide
theorem cert_e1211182849654 : check e1211182849654 [[],[]] .three = true := by decide
def e1211182849658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182849658 : Closed e1211182849658 ∧ code e1211182849658 = 5609229360762 := by decide
theorem cert_e1211182849658 : check e1211182849658 [[],[]] .three = true := by decide
def e1211185343726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211185343726 : Closed e1211185343726 ∧ code e1211185343726 = 5609231854830 := by decide
theorem cert_e1211185343726 : check e1211185343726 [[],[]] .smaller = true := by decide
def e1211185343734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211185343734 : Closed e1211185343734 ∧ code e1211185343734 = 5609231854838 := by decide
theorem cert_e1211185343734 : check e1211185343734 [[],[]] .smaller = true := by decide
def e1211185345774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211185345774 : Closed e1211185345774 ∧ code e1211185345774 = 5609231856878 := by decide
theorem cert_e1211185345774 : check e1211185345774 [[],[]] .smaller = true := by decide
def e1211185345782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211185345782 : Closed e1211185345782 ∧ code e1211185345782 = 5609231856886 := by decide
theorem cert_e1211185345782 : check e1211185345782 [[],[]] .smaller = true := by decide
def e1211185353966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211185353966 : Closed e1211185353966 ∧ code e1211185353966 = 5609231865070 := by decide
theorem cert_e1211185353966 : check e1211185353966 [[],[]] .smaller = true := by decide
def e1211185353974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211185353974 : Closed e1211185353974 ∧ code e1211185353974 = 5609231865078 := by decide
theorem cert_e1211185353974 : check e1211185353974 [[],[]] .smaller = true := by decide
def e1211185392878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211185392878 : Closed e1211185392878 ∧ code e1211185392878 = 5609231903982 := by decide
theorem cert_e1211185392878 : check e1211185392878 [[],[]] .smaller = true := by decide
def e1211185392886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211185392886 : Closed e1211185392886 ∧ code e1211185392886 = 5609231903990 := by decide
theorem cert_e1211185392886 : check e1211185392886 [[],[]] .smaller = true := by decide
def e1211185394926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211185394926 : Closed e1211185394926 ∧ code e1211185394926 = 5609231906030 := by decide
theorem cert_e1211185394926 : check e1211185394926 [[],[]] .smaller = true := by decide
def e1211185394934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211185394934 : Closed e1211185394934 ∧ code e1211185394934 = 5609231906038 := by decide
theorem cert_e1211185394934 : check e1211185394934 [[],[]] .smaller = true := by decide
def e1211185403614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211185403614 : Closed e1211185403614 ∧ code e1211185403614 = 5609231914718 := by decide
theorem cert_e1211185403614 : check e1211185403614 [[],[]] .three = true := by decide
def e1211185403638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211185403638 : Closed e1211185403638 ∧ code e1211185403638 = 5609231914742 := by decide
theorem cert_e1211185403638 : check e1211185403638 [[],[]] .three = true := by decide
def e1211185403742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211185403742 : Closed e1211185403742 ∧ code e1211185403742 = 5609231914846 := by decide
theorem cert_e1211185403742 : check e1211185403742 [[],[]] .three = true := by decide
def e1211185403770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211185403770 : Closed e1211185403770 ∧ code e1211185403770 = 5609231914874 := by decide
theorem cert_e1211185403770 : check e1211185403770 [[],[]] .three = true := by decide
def e1211185403862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211185403862 : Closed e1211185403862 ∧ code e1211185403862 = 5609231914966 := by decide
theorem cert_e1211185403862 : check e1211185403862 [[],[]] .three = true := by decide
def e1211185403866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211185403866 : Closed e1211185403866 ∧ code e1211185403866 = 5609231914970 := by decide
theorem cert_e1211185403866 : check e1211185403866 [[],[]] .three = true := by decide
def e1211185404382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211185404382 : Closed e1211185404382 ∧ code e1211185404382 = 5609231915486 := by decide
theorem cert_e1211185404382 : check e1211185404382 [[],[]] .three = true := by decide
def e1211185404406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211185404406 : Closed e1211185404406 ∧ code e1211185404406 = 5609231915510 := by decide
theorem cert_e1211185404406 : check e1211185404406 [[],[]] .three = true := by decide
def e1211185405150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211185405150 : Closed e1211185405150 ∧ code e1211185405150 = 5609231916254 := by decide
theorem cert_e1211185405150 : check e1211185405150 [[],[]] .three = true := by decide
def e1211185405178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211185405178 : Closed e1211185405178 ∧ code e1211185405178 = 5609231916282 := by decide
theorem cert_e1211185405178 : check e1211185405178 [[],[]] .three = true := by decide
def e1211185405750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211185405750 : Closed e1211185405750 ∧ code e1211185405750 = 5609231916854 := by decide
theorem cert_e1211185405750 : check e1211185405750 [[],[]] .three = true := by decide
def e1211185405754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211185405754 : Closed e1211185405754 ∧ code e1211185405754 = 5609231916858 := by decide
theorem cert_e1211185405754 : check e1211185405754 [[],[]] .three = true := by decide
def e1211185444078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211185444078 : Closed e1211185444078 ∧ code e1211185444078 = 5609231955182 := by decide
theorem cert_e1211185444078 : check e1211185444078 [[],[]] .smaller = true := by decide
def e1211185444086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211185444086 : Closed e1211185444086 ∧ code e1211185444086 = 5609231955190 := by decide
theorem cert_e1211185444086 : check e1211185444086 [[],[]] .smaller = true := by decide
def e1211186128630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1211186128630 : Closed e1211186128630 ∧ code e1211186128630 = 5609232639734 := by decide
theorem cert_e1211186128630 : check e1211186128630 [[],[]] .three = true := by decide
def e1211186128762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1211186128762 : Closed e1211186128762 ∧ code e1211186128762 = 5609232639866 := by decide
theorem cert_e1211186128762 : check e1211186128762 [[],[]] .three = true := by decide
def e1211186128854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1211186128854 : Closed e1211186128854 ∧ code e1211186128854 = 5609232639958 := by decide
theorem cert_e1211186128854 : check e1211186128854 [[],[]] .three = true := by decide
def e1211186128858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1211186128858 : Closed e1211186128858 ∧ code e1211186128858 = 5609232639962 := by decide
theorem cert_e1211186128858 : check e1211186128858 [[],[]] .three = true := by decide
def e1211186383582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1211186383582 : Closed e1211186383582 ∧ code e1211186383582 = 5609232894686 := by decide
theorem cert_e1211186383582 : check e1211186383582 [[],[]] .three = true := by decide
def e1211186383606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1211186383606 : Closed e1211186383606 ∧ code e1211186383606 = 5609232894710 := by decide
theorem cert_e1211186383606 : check e1211186383606 [[],[]] .three = true := by decide
def e1211186383710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1211186383710 : Closed e1211186383710 ∧ code e1211186383710 = 5609232894814 := by decide
theorem cert_e1211186383710 : check e1211186383710 [[],[]] .three = true := by decide
def e1211186383726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211186383726 : Closed e1211186383726 ∧ code e1211186383726 = 5609232894830 := by decide
theorem cert_e1211186383726 : check e1211186383726 [[],[]] .smaller = true := by decide
def e1211186383734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211186383734 : Closed e1211186383734 ∧ code e1211186383734 = 5609232894838 := by decide
theorem cert_e1211186383734 : check e1211186383734 [[],[]] .smaller = true := by decide
def e1211186383738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1211186383738 : Closed e1211186383738 ∧ code e1211186383738 = 5609232894842 := by decide
theorem cert_e1211186383738 : check e1211186383738 [[],[]] .three = true := by decide
def e1211186383798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211186383798 : Closed e1211186383798 ∧ code e1211186383798 = 5609232894902 := by decide
theorem cert_e1211186383798 : check e1211186383798 [[],[]] .smaller = true := by decide
def e1211186383830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1211186383830 : Closed e1211186383830 ∧ code e1211186383830 = 5609232894934 := by decide
theorem cert_e1211186383830 : check e1211186383830 [[],[]] .three = true := by decide
def e1211186383834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1211186383834 : Closed e1211186383834 ∧ code e1211186383834 = 5609232894938 := by decide
theorem cert_e1211186383834 : check e1211186383834 [[],[]] .three = true := by decide
def e1211186384238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211186384238 : Closed e1211186384238 ∧ code e1211186384238 = 5609232895342 := by decide
theorem cert_e1211186384238 : check e1211186384238 [[],[]] .smaller = true := by decide
def e1211186384246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211186384246 : Closed e1211186384246 ∧ code e1211186384246 = 5609232895350 := by decide
theorem cert_e1211186384246 : check e1211186384246 [[],[]] .smaller = true := by decide
def e1211186384302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211186384302 : Closed e1211186384302 ∧ code e1211186384302 = 5609232895406 := by decide
theorem cert_e1211186384302 : check e1211186384302 [[],[]] .smaller = true := by decide
def e1211186384314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211186384314 : Closed e1211186384314 ∧ code e1211186384314 = 5609232895418 := by decide
theorem cert_e1211186384314 : check e1211186384314 [[],[]] .smaller = true := by decide
def e1211186384342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211186384342 : Closed e1211186384342 ∧ code e1211186384342 = 5609232895446 := by decide
theorem cert_e1211186384342 : check e1211186384342 [[],[]] .smaller = true := by decide
def e1211186384346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211186384346 : Closed e1211186384346 ∧ code e1211186384346 = 5609232895450 := by decide
theorem cert_e1211186384346 : check e1211186384346 [[],[]] .smaller = true := by decide
def e1211186384558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211186384558 : Closed e1211186384558 ∧ code e1211186384558 = 5609232895662 := by decide
theorem cert_e1211186384558 : check e1211186384558 [[],[]] .smaller = true := by decide
def e1211186384570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211186384570 : Closed e1211186384570 ∧ code e1211186384570 = 5609232895674 := by decide
theorem cert_e1211186384570 : check e1211186384570 [[],[]] .smaller = true := by decide
def e1211186384618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211186384618 : Closed e1211186384618 ∧ code e1211186384618 = 5609232895722 := by decide
theorem cert_e1211186384618 : check e1211186384618 [[],[]] .smaller = true := by decide
def e1211186384726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211186384726 : Closed e1211186384726 ∧ code e1211186384726 = 5609232895830 := by decide
theorem cert_e1211186384726 : check e1211186384726 [[],[]] .smaller = true := by decide
def e1211186384730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211186384730 : Closed e1211186384730 ∧ code e1211186384730 = 5609232895834 := by decide
theorem cert_e1211186384730 : check e1211186384730 [[],[]] .smaller = true := by decide
def e1211186384746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211186384746 : Closed e1211186384746 ∧ code e1211186384746 = 5609232895850 := by decide
theorem cert_e1211186384746 : check e1211186384746 [[],[]] .smaller = true := by decide
def e1211186389726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e1211186389726 : Closed e1211186389726 ∧ code e1211186389726 = 5609232900830 := by decide
theorem cert_e1211186389726 : check e1211186389726 [[],[]] .three = true := by decide
def e1211186389750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e1211186389750 : Closed e1211186389750 ∧ code e1211186389750 = 5609232900854 := by decide
theorem cert_e1211186389750 : check e1211186389750 [[],[]] .three = true := by decide
def e1211186389870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211186389870 : Closed e1211186389870 ∧ code e1211186389870 = 5609232900974 := by decide
theorem cert_e1211186389870 : check e1211186389870 [[],[]] .smaller = true := by decide
def e1211186389878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211186389878 : Closed e1211186389878 ∧ code e1211186389878 = 5609232900982 := by decide
theorem cert_e1211186389878 : check e1211186389878 [[],[]] .smaller = true := by decide
def e1211186389934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211186389934 : Closed e1211186389934 ∧ code e1211186389934 = 5609232901038 := by decide
theorem cert_e1211186389934 : check e1211186389934 [[],[]] .smaller = true := by decide
def e1211186389946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211186389946 : Closed e1211186389946 ∧ code e1211186389946 = 5609232901050 := by decide
theorem cert_e1211186389946 : check e1211186389946 [[],[]] .smaller = true := by decide
def e1211186389974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211186389974 : Closed e1211186389974 ∧ code e1211186389974 = 5609232901078 := by decide
theorem cert_e1211186389974 : check e1211186389974 [[],[]] .smaller = true := by decide
def e1211186389978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211186389978 : Closed e1211186389978 ∧ code e1211186389978 = 5609232901082 := by decide
theorem cert_e1211186389978 : check e1211186389978 [[],[]] .smaller = true := by decide
def e1211186391278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211186391278 : Closed e1211186391278 ∧ code e1211186391278 = 5609232902382 := by decide
theorem cert_e1211186391278 : check e1211186391278 [[],[]] .smaller = true := by decide
def e1211186391286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211186391286 : Closed e1211186391286 ∧ code e1211186391286 = 5609232902390 := by decide
theorem cert_e1211186391286 : check e1211186391286 [[],[]] .smaller = true := by decide
def e1211186391838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211186391838 : Closed e1211186391838 ∧ code e1211186391838 = 5609232902942 := by decide
theorem cert_e1211186391838 : check e1211186391838 [[],[]] .smaller = true := by decide
def e1211186391950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211186391950 : Closed e1211186391950 ∧ code e1211186391950 = 5609232903054 := by decide
theorem cert_e1211186391950 : check e1211186391950 [[],[]] .smaller = true := by decide
def e1211186392158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e1211186392158 : Closed e1211186392158 ∧ code e1211186392158 = 5609232903262 := by decide
theorem cert_e1211186392158 : check e1211186392158 [[],[]] .three = true := by decide
def e1211186392174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186392174 : Closed e1211186392174 ∧ code e1211186392174 = 5609232903278 := by decide
theorem cert_e1211186392174 : check e1211186392174 [[],[]] .smaller = true := by decide
def e1211186392186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186392186 : Closed e1211186392186 ∧ code e1211186392186 = 5609232903290 := by decide
theorem cert_e1211186392186 : check e1211186392186 [[],[]] .smaller = true := by decide
def e1211186392350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186392350 : Closed e1211186392350 ∧ code e1211186392350 = 5609232903454 := by decide
theorem cert_e1211186392350 : check e1211186392350 [[],[]] .smaller = true := by decide
def e1211186392518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186392518 : Closed e1211186392518 ∧ code e1211186392518 = 5609232903622 := by decide
theorem cert_e1211186392518 : check e1211186392518 [[],[]] .smaller = true := by decide
def e1211186392542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e1211186392542 : Closed e1211186392542 ∧ code e1211186392542 = 5609232903646 := by decide
theorem cert_e1211186392542 : check e1211186392542 [[],[]] .three = true := by decide
def e1211186392546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e1211186392546 : Closed e1211186392546 ∧ code e1211186392546 = 5609232903650 := by decide
theorem cert_e1211186392546 : check e1211186392546 [[],[]] .three = true := by decide
def e1211186392558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e1211186392558 : Closed e1211186392558 ∧ code e1211186392558 = 5609232903662 := by decide
theorem cert_e1211186392558 : check e1211186392558 [[],[]] .three = true := by decide
def e1211186392630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186392630 : Closed e1211186392630 ∧ code e1211186392630 = 5609232903734 := by decide
theorem cert_e1211186392630 : check e1211186392630 [[],[]] .smaller = true := by decide
def e1211186392634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186392634 : Closed e1211186392634 ∧ code e1211186392634 = 5609232903738 := by decide
theorem cert_e1211186392634 : check e1211186392634 [[],[]] .smaller = true := by decide
def e1211186392718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186392718 : Closed e1211186392718 ∧ code e1211186392718 = 5609232903822 := by decide
theorem cert_e1211186392718 : check e1211186392718 [[],[]] .smaller = true := by decide
def e1211186392774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186392774 : Closed e1211186392774 ∧ code e1211186392774 = 5609232903878 := by decide
theorem cert_e1211186392774 : check e1211186392774 [[],[]] .smaller = true := by decide
def e1211186392798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e1211186392798 : Closed e1211186392798 ∧ code e1211186392798 = 5609232903902 := by decide
theorem cert_e1211186392798 : check e1211186392798 [[],[]] .three = true := by decide
def e1211186392822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e1211186392822 : Closed e1211186392822 ∧ code e1211186392822 = 5609232903926 := by decide
theorem cert_e1211186392822 : check e1211186392822 [[],[]] .three = true := by decide
def e1211186392854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186392854 : Closed e1211186392854 ∧ code e1211186392854 = 5609232903958 := by decide
theorem cert_e1211186392854 : check e1211186392854 [[],[]] .three = true := by decide
def e1211186392930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186392930 : Closed e1211186392930 ∧ code e1211186392930 = 5609232904034 := by decide
theorem cert_e1211186392930 : check e1211186392930 [[],[]] .three = true := by decide
def e1211186392942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e1211186392942 : Closed e1211186392942 ∧ code e1211186392942 = 5609232904046 := by decide
theorem cert_e1211186392942 : check e1211186392942 [[],[]] .three = true := by decide
def e1211186392950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e1211186392950 : Closed e1211186392950 ∧ code e1211186392950 = 5609232904054 := by decide
theorem cert_e1211186392950 : check e1211186392950 [[],[]] .three = true := by decide
def e1211186393438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e1211186393438 : Closed e1211186393438 ∧ code e1211186393438 = 5609232904542 := by decide
theorem cert_e1211186393438 : check e1211186393438 [[],[]] .three = true := by decide
def e1211186393454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211186393454 : Closed e1211186393454 ∧ code e1211186393454 = 5609232904558 := by decide
theorem cert_e1211186393454 : check e1211186393454 [[],[]] .smaller = true := by decide
def e1211186393462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211186393462 : Closed e1211186393462 ∧ code e1211186393462 = 5609232904566 := by decide
theorem cert_e1211186393462 : check e1211186393462 [[],[]] .smaller = true := by decide
def e1211186393466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e1211186393466 : Closed e1211186393466 ∧ code e1211186393466 = 5609232904570 := by decide
theorem cert_e1211186393466 : check e1211186393466 [[],[]] .three = true := by decide
def e1211186393518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211186393518 : Closed e1211186393518 ∧ code e1211186393518 = 5609232904622 := by decide
theorem cert_e1211186393518 : check e1211186393518 [[],[]] .smaller = true := by decide
def e1211186393530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211186393530 : Closed e1211186393530 ∧ code e1211186393530 = 5609232904634 := by decide
theorem cert_e1211186393530 : check e1211186393530 [[],[]] .smaller = true := by decide
def e1211186393578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1211186393578 : Closed e1211186393578 ∧ code e1211186393578 = 5609232904682 := by decide
theorem cert_e1211186393578 : check e1211186393578 [[],[]] .smaller = true := by decide
def e1211186394206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e1211186394206 : Closed e1211186394206 ∧ code e1211186394206 = 5609232905310 := by decide
theorem cert_e1211186394206 : check e1211186394206 [[],[]] .three = true := by decide
def e1211186394222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186394222 : Closed e1211186394222 ∧ code e1211186394222 = 5609232905326 := by decide
theorem cert_e1211186394222 : check e1211186394222 [[],[]] .smaller = true := by decide
def e1211186394234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186394234 : Closed e1211186394234 ∧ code e1211186394234 = 5609232905338 := by decide
theorem cert_e1211186394234 : check e1211186394234 [[],[]] .smaller = true := by decide
def e1211186394398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186394398 : Closed e1211186394398 ∧ code e1211186394398 = 5609232905502 := by decide
theorem cert_e1211186394398 : check e1211186394398 [[],[]] .smaller = true := by decide
def e1211186394566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186394566 : Closed e1211186394566 ∧ code e1211186394566 = 5609232905670 := by decide
theorem cert_e1211186394566 : check e1211186394566 [[],[]] .smaller = true := by decide
def e1211186394590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e1211186394590 : Closed e1211186394590 ∧ code e1211186394590 = 5609232905694 := by decide
theorem cert_e1211186394590 : check e1211186394590 [[],[]] .three = true := by decide
def e1211186394594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e1211186394594 : Closed e1211186394594 ∧ code e1211186394594 = 5609232905698 := by decide
theorem cert_e1211186394594 : check e1211186394594 [[],[]] .three = true := by decide
def e1211186394606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e1211186394606 : Closed e1211186394606 ∧ code e1211186394606 = 5609232905710 := by decide
theorem cert_e1211186394606 : check e1211186394606 [[],[]] .three = true := by decide
def e1211186394670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211186394670 : Closed e1211186394670 ∧ code e1211186394670 = 5609232905774 := by decide
theorem cert_e1211186394670 : check e1211186394670 [[],[]] .smaller = true := by decide
def e1211186394846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e1211186394846 : Closed e1211186394846 ∧ code e1211186394846 = 5609232905950 := by decide
theorem cert_e1211186394846 : check e1211186394846 [[],[]] .three = true := by decide
def e1211186394850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211186394850 : Closed e1211186394850 ∧ code e1211186394850 = 5609232905954 := by decide
theorem cert_e1211186394850 : check e1211186394850 [[],[]] .smaller = true := by decide
def e1211186394862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e1211186394862 : Closed e1211186394862 ∧ code e1211186394862 = 5609232905966 := by decide
theorem cert_e1211186394862 : check e1211186394862 [[],[]] .smaller = true := by decide
def e1211186394870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e1211186394870 : Closed e1211186394870 ∧ code e1211186394870 = 5609232905974 := by decide
theorem cert_e1211186394870 : check e1211186394870 [[],[]] .three = true := by decide
def e1211186394902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186394902 : Closed e1211186394902 ∧ code e1211186394902 = 5609232906006 := by decide
theorem cert_e1211186394902 : check e1211186394902 [[],[]] .smaller = true := by decide
def e1211186394906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186394906 : Closed e1211186394906 ∧ code e1211186394906 = 5609232906010 := by decide
theorem cert_e1211186394906 : check e1211186394906 [[],[]] .smaller = true := by decide
def e1211186394950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186394950 : Closed e1211186394950 ∧ code e1211186394950 = 5609232906054 := by decide
theorem cert_e1211186394950 : check e1211186394950 [[],[]] .smaller = true := by decide
def e1211186394974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e1211186394974 : Closed e1211186394974 ∧ code e1211186394974 = 5609232906078 := by decide
theorem cert_e1211186394974 : check e1211186394974 [[],[]] .three = true := by decide
def e1211186394978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186394978 : Closed e1211186394978 ∧ code e1211186394978 = 5609232906082 := by decide
theorem cert_e1211186394978 : check e1211186394978 [[],[]] .smaller = true := by decide
def e1211186394990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e1211186394990 : Closed e1211186394990 ∧ code e1211186394990 = 5609232906094 := by decide
theorem cert_e1211186394990 : check e1211186394990 [[],[]] .smaller = true := by decide
def e1211186394998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e1211186394998 : Closed e1211186394998 ∧ code e1211186394998 = 5609232906102 := by decide
theorem cert_e1211186394998 : check e1211186394998 [[],[]] .smaller = true := by decide
def e1211186395002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e1211186395002 : Closed e1211186395002 ∧ code e1211186395002 = 5609232906106 := by decide
theorem cert_e1211186395002 : check e1211186395002 [[],[]] .three = true := by decide
def e1211186395018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186395018 : Closed e1211186395018 ∧ code e1211186395018 = 5609232906122 := by decide
theorem cert_e1211186395018 : check e1211186395018 [[],[]] .three = true := by decide
def e1211186395042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186395042 : Closed e1211186395042 ∧ code e1211186395042 = 5609232906146 := by decide
theorem cert_e1211186395042 : check e1211186395042 [[],[]] .three = true := by decide
def e1211186395054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e1211186395054 : Closed e1211186395054 ∧ code e1211186395054 = 5609232906158 := by decide
theorem cert_e1211186395054 : check e1211186395054 [[],[]] .three = true := by decide
def e1211186395062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e1211186395062 : Closed e1211186395062 ∧ code e1211186395062 = 5609232906166 := by decide
theorem cert_e1211186395062 : check e1211186395062 [[],[]] .three = true := by decide
def e1211186395066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e1211186395066 : Closed e1211186395066 ∧ code e1211186395066 = 5609232906170 := by decide
theorem cert_e1211186395066 : check e1211186395066 [[],[]] .three = true := by decide
def e1211186395318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211186395318 : Closed e1211186395318 ∧ code e1211186395318 = 5609232906422 := by decide
theorem cert_e1211186395318 : check e1211186395318 [[],[]] .smaller = true := by decide
def e1211186395350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211186395350 : Closed e1211186395350 ∧ code e1211186395350 = 5609232906454 := by decide
theorem cert_e1211186395350 : check e1211186395350 [[],[]] .smaller = true := by decide
def e1211186395354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211186395354 : Closed e1211186395354 ∧ code e1211186395354 = 5609232906458 := by decide
theorem cert_e1211186395354 : check e1211186395354 [[],[]] .smaller = true := by decide
def e1211186395370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211186395370 : Closed e1211186395370 ∧ code e1211186395370 = 5609232906474 := by decide
theorem cert_e1211186395370 : check e1211186395370 [[],[]] .smaller = true := by decide
def e1211186395702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186395702 : Closed e1211186395702 ∧ code e1211186395702 = 5609232906806 := by decide
theorem cert_e1211186395702 : check e1211186395702 [[],[]] .smaller = true := by decide
def e1211186395706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186395706 : Closed e1211186395706 ∧ code e1211186395706 = 5609232906810 := by decide
theorem cert_e1211186395706 : check e1211186395706 [[],[]] .smaller = true := by decide
def e1211186395790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186395790 : Closed e1211186395790 ∧ code e1211186395790 = 5609232906894 := by decide
theorem cert_e1211186395790 : check e1211186395790 [[],[]] .smaller = true := by decide
def e1211186395846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186395846 : Closed e1211186395846 ∧ code e1211186395846 = 5609232906950 := by decide
theorem cert_e1211186395846 : check e1211186395846 [[],[]] .smaller = true := by decide
def e1211186395870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1211186395870 : Closed e1211186395870 ∧ code e1211186395870 = 5609232906974 := by decide
theorem cert_e1211186395870 : check e1211186395870 [[],[]] .three = true := by decide
def e1211186395894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1211186395894 : Closed e1211186395894 ∧ code e1211186395894 = 5609232906998 := by decide
theorem cert_e1211186395894 : check e1211186395894 [[],[]] .three = true := by decide
def e1211186395926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186395926 : Closed e1211186395926 ∧ code e1211186395926 = 5609232907030 := by decide
theorem cert_e1211186395926 : check e1211186395926 [[],[]] .smaller = true := by decide
def e1211186395930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186395930 : Closed e1211186395930 ∧ code e1211186395930 = 5609232907034 := by decide
theorem cert_e1211186395930 : check e1211186395930 [[],[]] .smaller = true := by decide
def e1211186395974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186395974 : Closed e1211186395974 ∧ code e1211186395974 = 5609232907078 := by decide
theorem cert_e1211186395974 : check e1211186395974 [[],[]] .smaller = true := by decide
def e1211186395998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1211186395998 : Closed e1211186395998 ∧ code e1211186395998 = 5609232907102 := by decide
theorem cert_e1211186395998 : check e1211186395998 [[],[]] .three = true := by decide
def e1211186396002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186396002 : Closed e1211186396002 ∧ code e1211186396002 = 5609232907106 := by decide
theorem cert_e1211186396002 : check e1211186396002 [[],[]] .smaller = true := by decide
def e1211186396014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211186396014 : Closed e1211186396014 ∧ code e1211186396014 = 5609232907118 := by decide
theorem cert_e1211186396014 : check e1211186396014 [[],[]] .smaller = true := by decide
def e1211186396022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211186396022 : Closed e1211186396022 ∧ code e1211186396022 = 5609232907126 := by decide
theorem cert_e1211186396022 : check e1211186396022 [[],[]] .smaller = true := by decide
def e1211186396026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1211186396026 : Closed e1211186396026 ∧ code e1211186396026 = 5609232907130 := by decide
theorem cert_e1211186396026 : check e1211186396026 [[],[]] .three = true := by decide
end Blc.Floor42
