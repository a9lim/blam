import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210910842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211210910842 : Closed e1211210910842 ∧ code e1211210910842 = 5609257421946 := by decide
theorem cert_e1211210910842 : check e1211210910842 [[],[]] .sourceHead = true := by decide
def e1211210910934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211210910934 : Closed e1211210910934 ∧ code e1211210910934 = 5609257422038 := by decide
theorem cert_e1211210910934 : check e1211210910934 [[],[]] .chain = true := by decide
def e1211210910938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211210910938 : Closed e1211210910938 ∧ code e1211210910938 = 5609257422042 := by decide
theorem cert_e1211210910938 : check e1211210910938 [[],[]] .chain = true := by decide
def e1211210910954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211210910954 : Closed e1211210910954 ∧ code e1211210910954 = 5609257422058 := by decide
theorem cert_e1211210910954 : check e1211210910954 [[],[]] .chain = true := by decide
def e1211210910982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211210910982 : Closed e1211210910982 ∧ code e1211210910982 = 5609257422086 := by decide
theorem cert_e1211210910982 : check e1211210910982 [[],[]] .chain = true := by decide
def e1211210911006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211210911006 : Closed e1211210911006 ∧ code e1211210911006 = 5609257422110 := by decide
theorem cert_e1211210911006 : check e1211210911006 [[],[]] .sourceHead = true := by decide
def e1211210911030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210911030 : Closed e1211210911030 ∧ code e1211210911030 = 5609257422134 := by decide
theorem cert_e1211210911030 : check e1211210911030 [[],[]] .chain = true := by decide
def e1211210911034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210911034 : Closed e1211210911034 ∧ code e1211210911034 = 5609257422138 := by decide
theorem cert_e1211210911034 : check e1211210911034 [[],[]] .chain = true := by decide
def e1211210911106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210911106 : Closed e1211210911106 ∧ code e1211210911106 = 5609257422210 := by decide
theorem cert_e1211210911106 : check e1211210911106 [[],[]] .chain = true := by decide
def e1211210911118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211210911118 : Closed e1211210911118 ∧ code e1211210911118 = 5609257422222 := by decide
theorem cert_e1211210911118 : check e1211210911118 [[],[]] .chain = true := by decide
def e1211210911130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210911130 : Closed e1211210911130 ∧ code e1211210911130 = 5609257422234 := by decide
theorem cert_e1211210911130 : check e1211210911130 [[],[]] .chain = true := by decide
def e1211210911174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211210911174 : Closed e1211210911174 ∧ code e1211210911174 = 5609257422278 := by decide
theorem cert_e1211210911174 : check e1211210911174 [[],[]] .sourceHead = true := by decide
def e1211210911242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211210911242 : Closed e1211210911242 ∧ code e1211210911242 = 5609257422346 := by decide
theorem cert_e1211210911242 : check e1211210911242 [[],[]] .chain = true := by decide
def e1211210911286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211210911286 : Closed e1211210911286 ∧ code e1211210911286 = 5609257422390 := by decide
theorem cert_e1211210911286 : check e1211210911286 [[],[]] .chain = true := by decide
def e1211210911290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211210911290 : Closed e1211210911290 ∧ code e1211210911290 = 5609257422394 := by decide
theorem cert_e1211210911290 : check e1211210911290 [[],[]] .chain = true := by decide
def e1211210911338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211210911338 : Closed e1211210911338 ∧ code e1211210911338 = 5609257422442 := by decide
theorem cert_e1211210911338 : check e1211210911338 [[],[]] .chain = true := by decide
def e1211210911362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210911362 : Closed e1211210911362 ∧ code e1211210911362 = 5609257422466 := by decide
theorem cert_e1211210911362 : check e1211210911362 [[],[]] .chain = true := by decide
def e1211210911374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211210911374 : Closed e1211210911374 ∧ code e1211210911374 = 5609257422478 := by decide
theorem cert_e1211210911374 : check e1211210911374 [[],[]] .chain = true := by decide
def e1211210911386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210911386 : Closed e1211210911386 ∧ code e1211210911386 = 5609257422490 := by decide
theorem cert_e1211210911386 : check e1211210911386 [[],[]] .chain = true := by decide
def e1211210911430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211210911430 : Closed e1211210911430 ∧ code e1211210911430 = 5609257422534 := by decide
theorem cert_e1211210911430 : check e1211210911430 [[],[]] .chain = true := by decide
def e1211210911514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211210911514 : Closed e1211210911514 ∧ code e1211210911514 = 5609257422618 := by decide
theorem cert_e1211210911514 : check e1211210911514 [[],[]] .sourceHead = true := by decide
def e1211210911558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211210911558 : Closed e1211210911558 ∧ code e1211210911558 = 5609257422662 := by decide
theorem cert_e1211210911558 : check e1211210911558 [[],[]] .sourceHead = true := by decide
def e1211210911774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211210911774 : Closed e1211210911774 ∧ code e1211210911774 = 5609257422878 := by decide
theorem cert_e1211210911774 : check e1211210911774 [[],[]] .chain = true := by decide
def e1211210911942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211210911942 : Closed e1211210911942 ∧ code e1211210911942 = 5609257423046 := by decide
theorem cert_e1211210911942 : check e1211210911942 [[],[]] .sourceHead = true := by decide
def e1211210911966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211210911966 : Closed e1211210911966 ∧ code e1211210911966 = 5609257423070 := by decide
theorem cert_e1211210911966 : check e1211210911966 [[],[]] .sourceHead = true := by decide
def e1211210911970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211210911970 : Closed e1211210911970 ∧ code e1211210911970 = 5609257423074 := by decide
theorem cert_e1211210911970 : check e1211210911970 [[],[]] .chain = true := by decide
def e1211210911982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210911982 : Closed e1211210911982 ∧ code e1211210911982 = 5609257423086 := by decide
theorem cert_e1211210911982 : check e1211210911982 [[],[]] .chain = true := by decide
def e1211210911990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210911990 : Closed e1211210911990 ∧ code e1211210911990 = 5609257423094 := by decide
theorem cert_e1211210911990 : check e1211210911990 [[],[]] .chain = true := by decide
def e1211210911994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211210911994 : Closed e1211210911994 ∧ code e1211210911994 = 5609257423098 := by decide
theorem cert_e1211210911994 : check e1211210911994 [[],[]] .sourceHead = true := by decide
def e1211210912470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211210912470 : Closed e1211210912470 ∧ code e1211210912470 = 5609257423574 := by decide
theorem cert_e1211210912470 : check e1211210912470 [[],[]] .chain = true := by decide
def e1211210912474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211210912474 : Closed e1211210912474 ∧ code e1211210912474 = 5609257423578 := by decide
theorem cert_e1211210912474 : check e1211210912474 [[],[]] .chain = true := by decide
def e1211210912490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211210912490 : Closed e1211210912490 ∧ code e1211210912490 = 5609257423594 := by decide
theorem cert_e1211210912490 : check e1211210912490 [[],[]] .chain = true := by decide
def e1211210912518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211210912518 : Closed e1211210912518 ∧ code e1211210912518 = 5609257423622 := by decide
theorem cert_e1211210912518 : check e1211210912518 [[],[]] .chain = true := by decide
def e1211210912542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211210912542 : Closed e1211210912542 ∧ code e1211210912542 = 5609257423646 := by decide
theorem cert_e1211210912542 : check e1211210912542 [[],[]] .sourceHead = true := by decide
def e1211210912566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210912566 : Closed e1211210912566 ∧ code e1211210912566 = 5609257423670 := by decide
theorem cert_e1211210912566 : check e1211210912566 [[],[]] .chain = true := by decide
def e1211210912570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210912570 : Closed e1211210912570 ∧ code e1211210912570 = 5609257423674 := by decide
theorem cert_e1211210912570 : check e1211210912570 [[],[]] .chain = true := by decide
def e1211210912642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210912642 : Closed e1211210912642 ∧ code e1211210912642 = 5609257423746 := by decide
theorem cert_e1211210912642 : check e1211210912642 [[],[]] .chain = true := by decide
def e1211210912654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211210912654 : Closed e1211210912654 ∧ code e1211210912654 = 5609257423758 := by decide
theorem cert_e1211210912654 : check e1211210912654 [[],[]] .chain = true := by decide
def e1211210912666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210912666 : Closed e1211210912666 ∧ code e1211210912666 = 5609257423770 := by decide
theorem cert_e1211210912666 : check e1211210912666 [[],[]] .chain = true := by decide
def e1211210912710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211210912710 : Closed e1211210912710 ∧ code e1211210912710 = 5609257423814 := by decide
theorem cert_e1211210912710 : check e1211210912710 [[],[]] .sourceHead = true := by decide
def e1211210913910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211210913910 : Closed e1211210913910 ∧ code e1211210913910 = 5609257425014 := by decide
theorem cert_e1211210913910 : check e1211210913910 [[],[]] .chain = true := by decide
def e1211210914154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211210914154 : Closed e1211210914154 ∧ code e1211210914154 = 5609257425258 := by decide
theorem cert_e1211210914154 : check e1211210914154 [[],[]] .chain = true := by decide
def e1211210914178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210914178 : Closed e1211210914178 ∧ code e1211210914178 = 5609257425282 := by decide
theorem cert_e1211210914178 : check e1211210914178 [[],[]] .chain = true := by decide
def e1211210914190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211210914190 : Closed e1211210914190 ∧ code e1211210914190 = 5609257425294 := by decide
theorem cert_e1211210914190 : check e1211210914190 [[],[]] .chain = true := by decide
def e1211210914202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210914202 : Closed e1211210914202 ∧ code e1211210914202 = 5609257425306 := by decide
theorem cert_e1211210914202 : check e1211210914202 [[],[]] .chain = true := by decide
def e1211210914246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211210914246 : Closed e1211210914246 ∧ code e1211210914246 = 5609257425350 := by decide
theorem cert_e1211210914246 : check e1211210914246 [[],[]] .chain = true := by decide
def e1211210914870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210914870 : Closed e1211210914870 ∧ code e1211210914870 = 5609257425974 := by decide
theorem cert_e1211210914870 : check e1211210914870 [[],[]] .sourceHead = true := by decide
def e1211210914874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210914874 : Closed e1211210914874 ∧ code e1211210914874 = 5609257425978 := by decide
theorem cert_e1211210914874 : check e1211210914874 [[],[]] .sourceHead = true := by decide
def e1211210915014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211210915014 : Closed e1211210915014 ∧ code e1211210915014 = 5609257426118 := by decide
theorem cert_e1211210915014 : check e1211210915014 [[],[]] .sourceHead = true := by decide
def e1211210926958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211210926958 : Closed e1211210926958 ∧ code e1211210926958 = 5609257438062 := by decide
theorem cert_e1211210926958 : check e1211210926958 [[],[]] .smaller = true := by decide
def e1211210926966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211210926966 : Closed e1211210926966 ∧ code e1211210926966 = 5609257438070 := by decide
theorem cert_e1211210926966 : check e1211210926966 [[],[]] .smaller = true := by decide
def e1211210927022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211210927022 : Closed e1211210927022 ∧ code e1211210927022 = 5609257438126 := by decide
theorem cert_e1211210927022 : check e1211210927022 [[],[]] .smaller = true := by decide
def e1211210927034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211210927034 : Closed e1211210927034 ∧ code e1211210927034 = 5609257438138 := by decide
theorem cert_e1211210927034 : check e1211210927034 [[],[]] .smaller = true := by decide
def e1211210927062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211210927062 : Closed e1211210927062 ∧ code e1211210927062 = 5609257438166 := by decide
theorem cert_e1211210927062 : check e1211210927062 [[],[]] .smaller = true := by decide
def e1211210927066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211210927066 : Closed e1211210927066 ∧ code e1211210927066 = 5609257438170 := by decide
theorem cert_e1211210927066 : check e1211210927066 [[],[]] .smaller = true := by decide
def e1211210927342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211210927342 : Closed e1211210927342 ∧ code e1211210927342 = 5609257438446 := by decide
theorem cert_e1211210927342 : check e1211210927342 [[],[]] .smaller = true := by decide
def e1211210927350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211210927350 : Closed e1211210927350 ∧ code e1211210927350 = 5609257438454 := by decide
theorem cert_e1211210927350 : check e1211210927350 [[],[]] .smaller = true := by decide
def e1211210927726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211210927726 : Closed e1211210927726 ∧ code e1211210927726 = 5609257438830 := by decide
theorem cert_e1211210927726 : check e1211210927726 [[],[]] .smaller = true := by decide
def e1211210927738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211210927738 : Closed e1211210927738 ∧ code e1211210927738 = 5609257438842 := by decide
theorem cert_e1211210927738 : check e1211210927738 [[],[]] .smaller = true := by decide
def e1211210927926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211210927926 : Closed e1211210927926 ∧ code e1211210927926 = 5609257439030 := by decide
theorem cert_e1211210927926 : check e1211210927926 [[],[]] .smaller = true := by decide
def e1211210927930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211210927930 : Closed e1211210927930 ∧ code e1211210927930 = 5609257439034 := by decide
theorem cert_e1211210927930 : check e1211210927930 [[],[]] .smaller = true := by decide
def e1211210928062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211210928062 : Closed e1211210928062 ∧ code e1211210928062 = 5609257439166 := by decide
theorem cert_e1211210928062 : check e1211210928062 [[],[]] .chain = true := by decide
def e1211210928094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211210928094 : Closed e1211210928094 ∧ code e1211210928094 = 5609257439198 := by decide
theorem cert_e1211210928094 : check e1211210928094 [[],[]] .chain = true := by decide
def e1211210935774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211210935774 : Closed e1211210935774 ∧ code e1211210935774 = 5609257446878 := by decide
theorem cert_e1211210935774 : check e1211210935774 [[],[]] .chain = true := by decide
def e1211210935790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211210935790 : Closed e1211210935790 ∧ code e1211210935790 = 5609257446894 := by decide
theorem cert_e1211210935790 : check e1211210935790 [[],[]] .chain = true := by decide
def e1211210936030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211210936030 : Closed e1211210936030 ∧ code e1211210936030 = 5609257447134 := by decide
theorem cert_e1211210936030 : check e1211210936030 [[],[]] .chain = true := by decide
def e1211210936054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211210936054 : Closed e1211210936054 ∧ code e1211210936054 = 5609257447158 := by decide
theorem cert_e1211210936054 : check e1211210936054 [[],[]] .chain = true := by decide
def e1211210936158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211210936158 : Closed e1211210936158 ∧ code e1211210936158 = 5609257447262 := by decide
theorem cert_e1211210936158 : check e1211210936158 [[],[]] .chain = true := by decide
def e1211210936186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211210936186 : Closed e1211210936186 ∧ code e1211210936186 = 5609257447290 := by decide
theorem cert_e1211210936186 : check e1211210936186 [[],[]] .chain = true := by decide
def e1211210936238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211210936238 : Closed e1211210936238 ∧ code e1211210936238 = 5609257447342 := by decide
theorem cert_e1211210936238 : check e1211210936238 [[],[]] .chain = true := by decide
def e1211210936246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211210936246 : Closed e1211210936246 ∧ code e1211210936246 = 5609257447350 := by decide
theorem cert_e1211210936246 : check e1211210936246 [[],[]] .chain = true := by decide
def e1211210936250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211210936250 : Closed e1211210936250 ∧ code e1211210936250 = 5609257447354 := by decide
theorem cert_e1211210936250 : check e1211210936250 [[],[]] .chain = true := by decide
def e1211210937310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211210937310 : Closed e1211210937310 ∧ code e1211210937310 = 5609257448414 := by decide
theorem cert_e1211210937310 : check e1211210937310 [[],[]] .chain = true := by decide
def e1211210937326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211210937326 : Closed e1211210937326 ∧ code e1211210937326 = 5609257448430 := by decide
theorem cert_e1211210937326 : check e1211210937326 [[],[]] .chain = true := by decide
def e1211210938846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211210938846 : Closed e1211210938846 ∧ code e1211210938846 = 5609257449950 := by decide
theorem cert_e1211210938846 : check e1211210938846 [[],[]] .chain = true := by decide
def e1211210938870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211210938870 : Closed e1211210938870 ∧ code e1211210938870 = 5609257449974 := by decide
theorem cert_e1211210938870 : check e1211210938870 [[],[]] .chain = true := by decide
def e1211210939614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211210939614 : Closed e1211210939614 ∧ code e1211210939614 = 5609257450718 := by decide
theorem cert_e1211210939614 : check e1211210939614 [[],[]] .chain = true := by decide
def e1211210939642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211210939642 : Closed e1211210939642 ∧ code e1211210939642 = 5609257450746 := by decide
theorem cert_e1211210939642 : check e1211210939642 [[],[]] .chain = true := by decide
def e1211210939930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211210939930 : Closed e1211210939930 ∧ code e1211210939930 = 5609257451034 := by decide
theorem cert_e1211210939930 : check e1211210939930 [[],[]] .sourceHead = true := by decide
def e1211210939966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 4))))))))))
theorem wire_e1211210939966 : Closed e1211210939966 ∧ code e1211210939966 = 5609257451070 := by decide
theorem cert_e1211210939966 : check e1211210939966 [[],[]] .sourceHead = true := by decide
def e1211210940014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210940014 : Closed e1211210940014 ∧ code e1211210940014 = 5609257451118 := by decide
theorem cert_e1211210940014 : check e1211210940014 [[],[]] .chain = true := by decide
def e1211210940022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211210940022 : Closed e1211210940022 ∧ code e1211210940022 = 5609257451126 := by decide
theorem cert_e1211210940022 : check e1211210940022 [[],[]] .chain = true := by decide
def e1211210940026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210940026 : Closed e1211210940026 ∧ code e1211210940026 = 5609257451130 := by decide
theorem cert_e1211210940026 : check e1211210940026 [[],[]] .chain = true := by decide
def e1211210968430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211210968430 : Closed e1211210968430 ∧ code e1211210968430 = 5609257479534 := by decide
theorem cert_e1211210968430 : check e1211210968430 [[],[]] .chain = true := by decide
def e1211210968438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211210968438 : Closed e1211210968438 ∧ code e1211210968438 = 5609257479542 := by decide
theorem cert_e1211210968438 : check e1211210968438 [[],[]] .chain = true := by decide
def e1211210968494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211210968494 : Closed e1211210968494 ∧ code e1211210968494 = 5609257479598 := by decide
theorem cert_e1211210968494 : check e1211210968494 [[],[]] .chain = true := by decide
def e1211210968506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211210968506 : Closed e1211210968506 ∧ code e1211210968506 = 5609257479610 := by decide
theorem cert_e1211210968506 : check e1211210968506 [[],[]] .chain = true := by decide
def e1211210968534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211210968534 : Closed e1211210968534 ∧ code e1211210968534 = 5609257479638 := by decide
theorem cert_e1211210968534 : check e1211210968534 [[],[]] .chain = true := by decide
def e1211210968538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211210968538 : Closed e1211210968538 ∧ code e1211210968538 = 5609257479642 := by decide
theorem cert_e1211210968538 : check e1211210968538 [[],[]] .chain = true := by decide
def e1211210968750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211210968750 : Closed e1211210968750 ∧ code e1211210968750 = 5609257479854 := by decide
theorem cert_e1211210968750 : check e1211210968750 [[],[]] .chain = true := by decide
def e1211210968762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211210968762 : Closed e1211210968762 ∧ code e1211210968762 = 5609257479866 := by decide
theorem cert_e1211210968762 : check e1211210968762 [[],[]] .chain = true := by decide
def e1211210968810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211210968810 : Closed e1211210968810 ∧ code e1211210968810 = 5609257479914 := by decide
theorem cert_e1211210968810 : check e1211210968810 [[],[]] .chain = true := by decide
def e1211210968918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211210968918 : Closed e1211210968918 ∧ code e1211210968918 = 5609257480022 := by decide
theorem cert_e1211210968918 : check e1211210968918 [[],[]] .chain = true := by decide
def e1211210968922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211210968922 : Closed e1211210968922 ∧ code e1211210968922 = 5609257480026 := by decide
theorem cert_e1211210968922 : check e1211210968922 [[],[]] .chain = true := by decide
def e1211210968938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211210968938 : Closed e1211210968938 ∧ code e1211210968938 = 5609257480042 := by decide
theorem cert_e1211210968938 : check e1211210968938 [[],[]] .chain = true := by decide
def e1211210969198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211210969198 : Closed e1211210969198 ∧ code e1211210969198 = 5609257480302 := by decide
theorem cert_e1211210969198 : check e1211210969198 [[],[]] .chain = true := by decide
def e1211210969374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211210969374 : Closed e1211210969374 ∧ code e1211210969374 = 5609257480478 := by decide
theorem cert_e1211210969374 : check e1211210969374 [[],[]] .chain = true := by decide
def e1211210969570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211210969570 : Closed e1211210969570 ∧ code e1211210969570 = 5609257480674 := by decide
theorem cert_e1211210969570 : check e1211210969570 [[],[]] .chain = true := by decide
def e1211210969582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211210969582 : Closed e1211210969582 ∧ code e1211210969582 = 5609257480686 := by decide
theorem cert_e1211210969582 : check e1211210969582 [[],[]] .sourceHead = true := by decide
def e1211210969966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211210969966 : Closed e1211210969966 ∧ code e1211210969966 = 5609257481070 := by decide
theorem cert_e1211210969966 : check e1211210969966 [[],[]] .chain = true := by decide
def e1211210969974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211210969974 : Closed e1211210969974 ∧ code e1211210969974 = 5609257481078 := by decide
theorem cert_e1211210969974 : check e1211210969974 [[],[]] .chain = true := by decide
def e1211210970030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211210970030 : Closed e1211210970030 ∧ code e1211210970030 = 5609257481134 := by decide
theorem cert_e1211210970030 : check e1211210970030 [[],[]] .chain = true := by decide
def e1211210970042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211210970042 : Closed e1211210970042 ∧ code e1211210970042 = 5609257481146 := by decide
theorem cert_e1211210970042 : check e1211210970042 [[],[]] .chain = true := by decide
def e1211210970070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211210970070 : Closed e1211210970070 ∧ code e1211210970070 = 5609257481174 := by decide
theorem cert_e1211210970070 : check e1211210970070 [[],[]] .chain = true := by decide
def e1211210970074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211210970074 : Closed e1211210970074 ∧ code e1211210970074 = 5609257481178 := by decide
theorem cert_e1211210970074 : check e1211210970074 [[],[]] .chain = true := by decide
def e1211210970350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210970350 : Closed e1211210970350 ∧ code e1211210970350 = 5609257481454 := by decide
theorem cert_e1211210970350 : check e1211210970350 [[],[]] .chain = true := by decide
def e1211210970358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210970358 : Closed e1211210970358 ∧ code e1211210970358 = 5609257481462 := by decide
theorem cert_e1211210970358 : check e1211210970358 [[],[]] .chain = true := by decide
def e1211210970734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210970734 : Closed e1211210970734 ∧ code e1211210970734 = 5609257481838 := by decide
theorem cert_e1211210970734 : check e1211210970734 [[],[]] .chain = true := by decide
def e1211210970746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210970746 : Closed e1211210970746 ∧ code e1211210970746 = 5609257481850 := by decide
theorem cert_e1211210970746 : check e1211210970746 [[],[]] .chain = true := by decide
def e1211210970886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211210970886 : Closed e1211210970886 ∧ code e1211210970886 = 5609257481990 := by decide
theorem cert_e1211210970886 : check e1211210970886 [[],[]] .chain = true := by decide
def e1211210970910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211210970910 : Closed e1211210970910 ∧ code e1211210970910 = 5609257482014 := by decide
theorem cert_e1211210970910 : check e1211210970910 [[],[]] .sourceHead = true := by decide
def e1211210970934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210970934 : Closed e1211210970934 ∧ code e1211210970934 = 5609257482038 := by decide
theorem cert_e1211210970934 : check e1211210970934 [[],[]] .chain = true := by decide
def e1211210970938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210970938 : Closed e1211210970938 ∧ code e1211210970938 = 5609257482042 := by decide
theorem cert_e1211210970938 : check e1211210970938 [[],[]] .chain = true := by decide
def e1211210971182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211210971182 : Closed e1211210971182 ∧ code e1211210971182 = 5609257482286 := by decide
theorem cert_e1211210971182 : check e1211210971182 [[],[]] .chain = true := by decide
def e1211210971374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211210971374 : Closed e1211210971374 ∧ code e1211210971374 = 5609257482478 := by decide
theorem cert_e1211210971374 : check e1211210971374 [[],[]] .chain = true := by decide
def e1211210971382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211210971382 : Closed e1211210971382 ∧ code e1211210971382 = 5609257482486 := by decide
theorem cert_e1211210971382 : check e1211210971382 [[],[]] .chain = true := by decide
def e1211210971566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211210971566 : Closed e1211210971566 ∧ code e1211210971566 = 5609257482670 := by decide
theorem cert_e1211210971566 : check e1211210971566 [[],[]] .chain = true := by decide
def e1211210971578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211210971578 : Closed e1211210971578 ∧ code e1211210971578 = 5609257482682 := by decide
theorem cert_e1211210971578 : check e1211210971578 [[],[]] .chain = true := by decide
def e1211210971626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211210971626 : Closed e1211210971626 ∧ code e1211210971626 = 5609257482730 := by decide
theorem cert_e1211210971626 : check e1211210971626 [[],[]] .chain = true := by decide
def e1211210971758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210971758 : Closed e1211210971758 ∧ code e1211210971758 = 5609257482862 := by decide
theorem cert_e1211210971758 : check e1211210971758 [[],[]] .chain = true := by decide
def e1211210971770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210971770 : Closed e1211210971770 ∧ code e1211210971770 = 5609257482874 := by decide
theorem cert_e1211210971770 : check e1211210971770 [[],[]] .chain = true := by decide
def e1211210971934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211210971934 : Closed e1211210971934 ∧ code e1211210971934 = 5609257483038 := by decide
theorem cert_e1211210971934 : check e1211210971934 [[],[]] .chain = true := by decide
def e1211210972034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210972034 : Closed e1211210972034 ∧ code e1211210972034 = 5609257483138 := by decide
theorem cert_e1211210972034 : check e1211210972034 [[],[]] .chain = true := by decide
def e1211210972046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211210972046 : Closed e1211210972046 ∧ code e1211210972046 = 5609257483150 := by decide
theorem cert_e1211210972046 : check e1211210972046 [[],[]] .chain = true := by decide
def e1211210972058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210972058 : Closed e1211210972058 ∧ code e1211210972058 = 5609257483162 := by decide
theorem cert_e1211210972058 : check e1211210972058 [[],[]] .chain = true := by decide
def e1211210972182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211210972182 : Closed e1211210972182 ∧ code e1211210972182 = 5609257483286 := by decide
theorem cert_e1211210972182 : check e1211210972182 [[],[]] .chain = true := by decide
def e1211210972186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211210972186 : Closed e1211210972186 ∧ code e1211210972186 = 5609257483290 := by decide
theorem cert_e1211210972186 : check e1211210972186 [[],[]] .chain = true := by decide
def e1211210972230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211210972230 : Closed e1211210972230 ∧ code e1211210972230 = 5609257483334 := by decide
theorem cert_e1211210972230 : check e1211210972230 [[],[]] .chain = true := by decide
def e1211210972258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211210972258 : Closed e1211210972258 ∧ code e1211210972258 = 5609257483362 := by decide
theorem cert_e1211210972258 : check e1211210972258 [[],[]] .chain = true := by decide
def e1211210972270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211210972270 : Closed e1211210972270 ∧ code e1211210972270 = 5609257483374 := by decide
theorem cert_e1211210972270 : check e1211210972270 [[],[]] .sourceHead = true := by decide
def e1211210972278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211210972278 : Closed e1211210972278 ∧ code e1211210972278 = 5609257483382 := by decide
theorem cert_e1211210972278 : check e1211210972278 [[],[]] .chain = true := by decide
def e1211210972282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211210972282 : Closed e1211210972282 ∧ code e1211210972282 = 5609257483386 := by decide
theorem cert_e1211210972282 : check e1211210972282 [[],[]] .sourceHead = true := by decide
def e1211210972374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211210972374 : Closed e1211210972374 ∧ code e1211210972374 = 5609257483478 := by decide
theorem cert_e1211210972374 : check e1211210972374 [[],[]] .chain = true := by decide
def e1211210972378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211210972378 : Closed e1211210972378 ∧ code e1211210972378 = 5609257483482 := by decide
theorem cert_e1211210972378 : check e1211210972378 [[],[]] .chain = true := by decide
def e1211210972394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211210972394 : Closed e1211210972394 ∧ code e1211210972394 = 5609257483498 := by decide
theorem cert_e1211210972394 : check e1211210972394 [[],[]] .chain = true := by decide
def e1211210972422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211210972422 : Closed e1211210972422 ∧ code e1211210972422 = 5609257483526 := by decide
theorem cert_e1211210972422 : check e1211210972422 [[],[]] .chain = true := by decide
def e1211210972446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211210972446 : Closed e1211210972446 ∧ code e1211210972446 = 5609257483550 := by decide
theorem cert_e1211210972446 : check e1211210972446 [[],[]] .sourceHead = true := by decide
def e1211210972470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210972470 : Closed e1211210972470 ∧ code e1211210972470 = 5609257483574 := by decide
theorem cert_e1211210972470 : check e1211210972470 [[],[]] .chain = true := by decide
def e1211210972474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210972474 : Closed e1211210972474 ∧ code e1211210972474 = 5609257483578 := by decide
theorem cert_e1211210972474 : check e1211210972474 [[],[]] .chain = true := by decide
def e1211210972546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210972546 : Closed e1211210972546 ∧ code e1211210972546 = 5609257483650 := by decide
theorem cert_e1211210972546 : check e1211210972546 [[],[]] .chain = true := by decide
def e1211210972558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211210972558 : Closed e1211210972558 ∧ code e1211210972558 = 5609257483662 := by decide
theorem cert_e1211210972558 : check e1211210972558 [[],[]] .chain = true := by decide
def e1211210972570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210972570 : Closed e1211210972570 ∧ code e1211210972570 = 5609257483674 := by decide
theorem cert_e1211210972570 : check e1211210972570 [[],[]] .chain = true := by decide
def e1211210972614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211210972614 : Closed e1211210972614 ∧ code e1211210972614 = 5609257483718 := by decide
theorem cert_e1211210972614 : check e1211210972614 [[],[]] .sourceHead = true := by decide
def e1211210973310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211210973310 : Closed e1211210973310 ∧ code e1211210973310 = 5609257484414 := by decide
theorem cert_e1211210973310 : check e1211210973310 [[],[]] .chain = true := by decide
def e1211210974174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211210974174 : Closed e1211210974174 ∧ code e1211210974174 = 5609257485278 := by decide
theorem cert_e1211210974174 : check e1211210974174 [[],[]] .chain = true := by decide
def e1211210974178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211210974178 : Closed e1211210974178 ∧ code e1211210974178 = 5609257485282 := by decide
theorem cert_e1211210974178 : check e1211210974178 [[],[]] .chain = true := by decide
def e1211210974190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211210974190 : Closed e1211210974190 ∧ code e1211210974190 = 5609257485294 := by decide
theorem cert_e1211210974190 : check e1211210974190 [[],[]] .chain = true := by decide
def e1211210976110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211210976110 : Closed e1211210976110 ∧ code e1211210976110 = 5609257487214 := by decide
theorem cert_e1211210976110 : check e1211210976110 [[],[]] .chain = true := by decide
def e1211210976118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211210976118 : Closed e1211210976118 ∧ code e1211210976118 = 5609257487222 := by decide
theorem cert_e1211210976118 : check e1211210976118 [[],[]] .chain = true := by decide
def e1211210976174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211210976174 : Closed e1211210976174 ∧ code e1211210976174 = 5609257487278 := by decide
theorem cert_e1211210976174 : check e1211210976174 [[],[]] .chain = true := by decide
def e1211210976186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211210976186 : Closed e1211210976186 ∧ code e1211210976186 = 5609257487290 := by decide
theorem cert_e1211210976186 : check e1211210976186 [[],[]] .chain = true := by decide
def e1211210976214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211210976214 : Closed e1211210976214 ∧ code e1211210976214 = 5609257487318 := by decide
theorem cert_e1211210976214 : check e1211210976214 [[],[]] .chain = true := by decide
def e1211210976218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211210976218 : Closed e1211210976218 ∧ code e1211210976218 = 5609257487322 := by decide
theorem cert_e1211210976218 : check e1211210976218 [[],[]] .chain = true := by decide
def e1211210976494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211210976494 : Closed e1211210976494 ∧ code e1211210976494 = 5609257487598 := by decide
theorem cert_e1211210976494 : check e1211210976494 [[],[]] .chain = true := by decide
def e1211210976502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211210976502 : Closed e1211210976502 ∧ code e1211210976502 = 5609257487606 := by decide
theorem cert_e1211210976502 : check e1211210976502 [[],[]] .chain = true := by decide
def e1211210976878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210976878 : Closed e1211210976878 ∧ code e1211210976878 = 5609257487982 := by decide
theorem cert_e1211210976878 : check e1211210976878 [[],[]] .chain = true := by decide
def e1211210976890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210976890 : Closed e1211210976890 ∧ code e1211210976890 = 5609257487994 := by decide
theorem cert_e1211210976890 : check e1211210976890 [[],[]] .chain = true := by decide
def e1211210977030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211210977030 : Closed e1211210977030 ∧ code e1211210977030 = 5609257488134 := by decide
theorem cert_e1211210977030 : check e1211210977030 [[],[]] .chain = true := by decide
def e1211210977054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211210977054 : Closed e1211210977054 ∧ code e1211210977054 = 5609257488158 := by decide
theorem cert_e1211210977054 : check e1211210977054 [[],[]] .sourceHead = true := by decide
def e1211210977078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211210977078 : Closed e1211210977078 ∧ code e1211210977078 = 5609257488182 := by decide
theorem cert_e1211210977078 : check e1211210977078 [[],[]] .chain = true := by decide
end Blc.Floor42
