import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210324446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211210324446 : Closed e1211210324446 ∧ code e1211210324446 = 5609256835550 := by decide
theorem cert_e1211210324446 : check e1211210324446 [[],[]] .chain = true := by decide
def e1211210324450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211210324450 : Closed e1211210324450 ∧ code e1211210324450 = 5609256835554 := by decide
theorem cert_e1211210324450 : check e1211210324450 [[],[]] .smaller = true := by decide
def e1211210324462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211210324462 : Closed e1211210324462 ∧ code e1211210324462 = 5609256835566 := by decide
theorem cert_e1211210324462 : check e1211210324462 [[],[]] .smaller = true := by decide
def e1211210324470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211210324470 : Closed e1211210324470 ∧ code e1211210324470 = 5609256835574 := by decide
theorem cert_e1211210324470 : check e1211210324470 [[],[]] .chain = true := by decide
def e1211210325022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211210325022 : Closed e1211210325022 ∧ code e1211210325022 = 5609256836126 := by decide
theorem cert_e1211210325022 : check e1211210325022 [[],[]] .smaller = true := by decide
def e1211210325214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211210325214 : Closed e1211210325214 ∧ code e1211210325214 = 5609256836318 := by decide
theorem cert_e1211210325214 : check e1211210325214 [[],[]] .chain = true := by decide
def e1211210325218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211210325218 : Closed e1211210325218 ∧ code e1211210325218 = 5609256836322 := by decide
theorem cert_e1211210325218 : check e1211210325218 [[],[]] .smaller = true := by decide
def e1211210325230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210325230 : Closed e1211210325230 ∧ code e1211210325230 = 5609256836334 := by decide
theorem cert_e1211210325230 : check e1211210325230 [[],[]] .smaller = true := by decide
def e1211210325238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210325238 : Closed e1211210325238 ∧ code e1211210325238 = 5609256836342 := by decide
theorem cert_e1211210325238 : check e1211210325238 [[],[]] .smaller = true := by decide
def e1211210325242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211210325242 : Closed e1211210325242 ∧ code e1211210325242 = 5609256836346 := by decide
theorem cert_e1211210325242 : check e1211210325242 [[],[]] .chain = true := by decide
def e1211210325614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210325614 : Closed e1211210325614 ∧ code e1211210325614 = 5609256836718 := by decide
theorem cert_e1211210325614 : check e1211210325614 [[],[]] .chain = true := by decide
def e1211210325622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211210325622 : Closed e1211210325622 ∧ code e1211210325622 = 5609256836726 := by decide
theorem cert_e1211210325622 : check e1211210325622 [[],[]] .chain = true := by decide
def e1211210325626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210325626 : Closed e1211210325626 ∧ code e1211210325626 = 5609256836730 := by decide
theorem cert_e1211210325626 : check e1211210325626 [[],[]] .chain = true := by decide
def e1211210326254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211210326254 : Closed e1211210326254 ∧ code e1211210326254 = 5609256837358 := by decide
theorem cert_e1211210326254 : check e1211210326254 [[],[]] .smaller = true := by decide
def e1211210326266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e1211210326266 : Closed e1211210326266 ∧ code e1211210326266 = 5609256837370 := by decide
theorem cert_e1211210326266 : check e1211210326266 [[],[]] .smaller = true := by decide
def e1211210326638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210326638 : Closed e1211210326638 ∧ code e1211210326638 = 5609256837742 := by decide
theorem cert_e1211210326638 : check e1211210326638 [[],[]] .smaller = true := by decide
def e1211210326650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210326650 : Closed e1211210326650 ∧ code e1211210326650 = 5609256837754 := by decide
theorem cert_e1211210326650 : check e1211210326650 [[],[]] .smaller = true := by decide
def e1211210326814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211210326814 : Closed e1211210326814 ∧ code e1211210326814 = 5609256837918 := by decide
theorem cert_e1211210326814 : check e1211210326814 [[],[]] .smaller = true := by decide
def e1211210326982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e1211210326982 : Closed e1211210326982 ∧ code e1211210326982 = 5609256838086 := by decide
theorem cert_e1211210326982 : check e1211210326982 [[],[]] .smaller = true := by decide
def e1211210327006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211210327006 : Closed e1211210327006 ∧ code e1211210327006 = 5609256838110 := by decide
theorem cert_e1211210327006 : check e1211210327006 [[],[]] .chain = true := by decide
def e1211210327022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211210327022 : Closed e1211210327022 ∧ code e1211210327022 = 5609256838126 := by decide
theorem cert_e1211210327022 : check e1211210327022 [[],[]] .chain = true := by decide
def e1211210327598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211210327598 : Closed e1211210327598 ∧ code e1211210327598 = 5609256838702 := by decide
theorem cert_e1211210327598 : check e1211210327598 [[],[]] .smaller = true := by decide
def e1211210327774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211210327774 : Closed e1211210327774 ∧ code e1211210327774 = 5609256838878 := by decide
theorem cert_e1211210327774 : check e1211210327774 [[],[]] .chain = true := by decide
def e1211210327778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211210327778 : Closed e1211210327778 ∧ code e1211210327778 = 5609256838882 := by decide
theorem cert_e1211210327778 : check e1211210327778 [[],[]] .smaller = true := by decide
def e1211210327790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e1211210327790 : Closed e1211210327790 ∧ code e1211210327790 = 5609256838894 := by decide
theorem cert_e1211210327790 : check e1211210327790 [[],[]] .smaller = true := by decide
def e1211210327798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211210327798 : Closed e1211210327798 ∧ code e1211210327798 = 5609256838902 := by decide
theorem cert_e1211210327798 : check e1211210327798 [[],[]] .chain = true := by decide
def e1211210327902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211210327902 : Closed e1211210327902 ∧ code e1211210327902 = 5609256839006 := by decide
theorem cert_e1211210327902 : check e1211210327902 [[],[]] .chain = true := by decide
def e1211210327930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211210327930 : Closed e1211210327930 ∧ code e1211210327930 = 5609256839034 := by decide
theorem cert_e1211210327930 : check e1211210327930 [[],[]] .chain = true := by decide
def e1211210327946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211210327946 : Closed e1211210327946 ∧ code e1211210327946 = 5609256839050 := by decide
theorem cert_e1211210327946 : check e1211210327946 [[],[]] .smaller = true := by decide
def e1211210327970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211210327970 : Closed e1211210327970 ∧ code e1211210327970 = 5609256839074 := by decide
theorem cert_e1211210327970 : check e1211210327970 [[],[]] .smaller = true := by decide
def e1211210327982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e1211210327982 : Closed e1211210327982 ∧ code e1211210327982 = 5609256839086 := by decide
theorem cert_e1211210327982 : check e1211210327982 [[],[]] .smaller = true := by decide
def e1211210327994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e1211210327994 : Closed e1211210327994 ∧ code e1211210327994 = 5609256839098 := by decide
theorem cert_e1211210327994 : check e1211210327994 [[],[]] .smaller = true := by decide
def e1211210328022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211210328022 : Closed e1211210328022 ∧ code e1211210328022 = 5609256839126 := by decide
theorem cert_e1211210328022 : check e1211210328022 [[],[]] .chain = true := by decide
def e1211210328026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211210328026 : Closed e1211210328026 ∧ code e1211210328026 = 5609256839130 := by decide
theorem cert_e1211210328026 : check e1211210328026 [[],[]] .chain = true := by decide
def e1211210328126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e1211210328126 : Closed e1211210328126 ∧ code e1211210328126 = 5609256839230 := by decide
theorem cert_e1211210328126 : check e1211210328126 [[],[]] .smaller = true := by decide
def e1211210328542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211210328542 : Closed e1211210328542 ∧ code e1211210328542 = 5609256839646 := by decide
theorem cert_e1211210328542 : check e1211210328542 [[],[]] .chain = true := by decide
def e1211210328546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211210328546 : Closed e1211210328546 ∧ code e1211210328546 = 5609256839650 := by decide
theorem cert_e1211210328546 : check e1211210328546 [[],[]] .smaller = true := by decide
def e1211210328558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211210328558 : Closed e1211210328558 ∧ code e1211210328558 = 5609256839662 := by decide
theorem cert_e1211210328558 : check e1211210328558 [[],[]] .smaller = true := by decide
def e1211210328566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211210328566 : Closed e1211210328566 ∧ code e1211210328566 = 5609256839670 := by decide
theorem cert_e1211210328566 : check e1211210328566 [[],[]] .chain = true := by decide
def e1211210329310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211210329310 : Closed e1211210329310 ∧ code e1211210329310 = 5609256840414 := by decide
theorem cert_e1211210329310 : check e1211210329310 [[],[]] .chain = true := by decide
def e1211210329338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211210329338 : Closed e1211210329338 ∧ code e1211210329338 = 5609256840442 := by decide
theorem cert_e1211210329338 : check e1211210329338 [[],[]] .chain = true := by decide
def e1211210329614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211210329614 : Closed e1211210329614 ∧ code e1211210329614 = 5609256840718 := by decide
theorem cert_e1211210329614 : check e1211210329614 [[],[]] .smaller = true := by decide
def e1211210329662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211210329662 : Closed e1211210329662 ∧ code e1211210329662 = 5609256840766 := by decide
theorem cert_e1211210329662 : check e1211210329662 [[],[]] .chain = true := by decide
def e1211210329698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211210329698 : Closed e1211210329698 ∧ code e1211210329698 = 5609256840802 := by decide
theorem cert_e1211210329698 : check e1211210329698 [[],[]] .smaller = true := by decide
def e1211210329710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210329710 : Closed e1211210329710 ∧ code e1211210329710 = 5609256840814 := by decide
theorem cert_e1211210329710 : check e1211210329710 [[],[]] .smaller = true := by decide
def e1211210329722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210329722 : Closed e1211210329722 ∧ code e1211210329722 = 5609256840826 := by decide
theorem cert_e1211210329722 : check e1211210329722 [[],[]] .smaller = true := by decide
def e1211210329886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211210329886 : Closed e1211210329886 ∧ code e1211210329886 = 5609256840990 := by decide
theorem cert_e1211210329886 : check e1211210329886 [[],[]] .chain = true := by decide
def e1211210329910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210329910 : Closed e1211210329910 ∧ code e1211210329910 = 5609256841014 := by decide
theorem cert_e1211210329910 : check e1211210329910 [[],[]] .chain = true := by decide
def e1211210329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210329914 : Closed e1211210329914 ∧ code e1211210329914 = 5609256841018 := by decide
theorem cert_e1211210329914 : check e1211210329914 [[],[]] .chain = true := by decide
def e1211210330230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211210330230 : Closed e1211210330230 ∧ code e1211210330230 = 5609256841334 := by decide
theorem cert_e1211210330230 : check e1211210330230 [[],[]] .smaller = true := by decide
def e1211210330234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211210330234 : Closed e1211210330234 ∧ code e1211210330234 = 5609256841338 := by decide
theorem cert_e1211210330234 : check e1211210330234 [[],[]] .smaller = true := by decide
def e1211210330422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210330422 : Closed e1211210330422 ∧ code e1211210330422 = 5609256841526 := by decide
theorem cert_e1211210330422 : check e1211210330422 [[],[]] .smaller = true := by decide
def e1211210330426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210330426 : Closed e1211210330426 ∧ code e1211210330426 = 5609256841530 := by decide
theorem cert_e1211210330426 : check e1211210330426 [[],[]] .smaller = true := by decide
def e1211210330510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211210330510 : Closed e1211210330510 ∧ code e1211210330510 = 5609256841614 := by decide
theorem cert_e1211210330510 : check e1211210330510 [[],[]] .smaller = true := by decide
def e1211210330566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211210330566 : Closed e1211210330566 ∧ code e1211210330566 = 5609256841670 := by decide
theorem cert_e1211210330566 : check e1211210330566 [[],[]] .smaller = true := by decide
def e1211210330590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211210330590 : Closed e1211210330590 ∧ code e1211210330590 = 5609256841694 := by decide
theorem cert_e1211210330590 : check e1211210330590 [[],[]] .chain = true := by decide
def e1211210330614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211210330614 : Closed e1211210330614 ∧ code e1211210330614 = 5609256841718 := by decide
theorem cert_e1211210330614 : check e1211210330614 [[],[]] .chain = true := by decide
def e1211210330902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211210330902 : Closed e1211210330902 ∧ code e1211210330902 = 5609256842006 := by decide
theorem cert_e1211210330902 : check e1211210330902 [[],[]] .smaller = true := by decide
def e1211210330974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211210330974 : Closed e1211210330974 ∧ code e1211210330974 = 5609256842078 := by decide
theorem cert_e1211210330974 : check e1211210330974 [[],[]] .chain = true := by decide
def e1211210330978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211210330978 : Closed e1211210330978 ∧ code e1211210330978 = 5609256842082 := by decide
theorem cert_e1211210330978 : check e1211210330978 [[],[]] .smaller = true := by decide
def e1211210330990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211210330990 : Closed e1211210330990 ∧ code e1211210330990 = 5609256842094 := by decide
theorem cert_e1211210330990 : check e1211210330990 [[],[]] .smaller = true := by decide
def e1211210330998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211210330998 : Closed e1211210330998 ∧ code e1211210330998 = 5609256842102 := by decide
theorem cert_e1211210330998 : check e1211210330998 [[],[]] .smaller = true := by decide
def e1211210331002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211210331002 : Closed e1211210331002 ∧ code e1211210331002 = 5609256842106 := by decide
theorem cert_e1211210331002 : check e1211210331002 [[],[]] .chain = true := by decide
def e1211210331018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211210331018 : Closed e1211210331018 ∧ code e1211210331018 = 5609256842122 := by decide
theorem cert_e1211210331018 : check e1211210331018 [[],[]] .smaller = true := by decide
def e1211210331042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211210331042 : Closed e1211210331042 ∧ code e1211210331042 = 5609256842146 := by decide
theorem cert_e1211210331042 : check e1211210331042 [[],[]] .smaller = true := by decide
def e1211210331054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211210331054 : Closed e1211210331054 ∧ code e1211210331054 = 5609256842158 := by decide
theorem cert_e1211210331054 : check e1211210331054 [[],[]] .smaller = true := by decide
def e1211210331066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211210331066 : Closed e1211210331066 ∧ code e1211210331066 = 5609256842170 := by decide
theorem cert_e1211210331066 : check e1211210331066 [[],[]] .smaller = true := by decide
def e1211210331094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211210331094 : Closed e1211210331094 ∧ code e1211210331094 = 5609256842198 := by decide
theorem cert_e1211210331094 : check e1211210331094 [[],[]] .smaller = true := by decide
def e1211210331098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211210331098 : Closed e1211210331098 ∧ code e1211210331098 = 5609256842202 := by decide
theorem cert_e1211210331098 : check e1211210331098 [[],[]] .smaller = true := by decide
def e1211210331114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211210331114 : Closed e1211210331114 ∧ code e1211210331114 = 5609256842218 := by decide
theorem cert_e1211210331114 : check e1211210331114 [[],[]] .chain = true := by decide
def e1211210331166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211210331166 : Closed e1211210331166 ∧ code e1211210331166 = 5609256842270 := by decide
theorem cert_e1211210331166 : check e1211210331166 [[],[]] .smaller = true := by decide
def e1211210331358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211210331358 : Closed e1211210331358 ∧ code e1211210331358 = 5609256842462 := by decide
theorem cert_e1211210331358 : check e1211210331358 [[],[]] .chain = true := by decide
def e1211210331362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211210331362 : Closed e1211210331362 ∧ code e1211210331362 = 5609256842466 := by decide
theorem cert_e1211210331362 : check e1211210331362 [[],[]] .smaller = true := by decide
def e1211210331374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210331374 : Closed e1211210331374 ∧ code e1211210331374 = 5609256842478 := by decide
theorem cert_e1211210331374 : check e1211210331374 [[],[]] .smaller = true := by decide
def e1211210331382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210331382 : Closed e1211210331382 ∧ code e1211210331382 = 5609256842486 := by decide
theorem cert_e1211210331382 : check e1211210331382 [[],[]] .smaller = true := by decide
def e1211210331386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211210331386 : Closed e1211210331386 ∧ code e1211210331386 = 5609256842490 := by decide
theorem cert_e1211210331386 : check e1211210331386 [[],[]] .chain = true := by decide
def e1211210331662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211210331662 : Closed e1211210331662 ∧ code e1211210331662 = 5609256842766 := by decide
theorem cert_e1211210331662 : check e1211210331662 [[],[]] .smaller = true := by decide
def e1211210331710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211210331710 : Closed e1211210331710 ∧ code e1211210331710 = 5609256842814 := by decide
theorem cert_e1211210331710 : check e1211210331710 [[],[]] .chain = true := by decide
def e1211210331746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211210331746 : Closed e1211210331746 ∧ code e1211210331746 = 5609256842850 := by decide
theorem cert_e1211210331746 : check e1211210331746 [[],[]] .smaller = true := by decide
def e1211210331758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210331758 : Closed e1211210331758 ∧ code e1211210331758 = 5609256842862 := by decide
theorem cert_e1211210331758 : check e1211210331758 [[],[]] .smaller = true := by decide
def e1211210331770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210331770 : Closed e1211210331770 ∧ code e1211210331770 = 5609256842874 := by decide
theorem cert_e1211210331770 : check e1211210331770 [[],[]] .smaller = true := by decide
def e1211210331958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210331958 : Closed e1211210331958 ∧ code e1211210331958 = 5609256843062 := by decide
theorem cert_e1211210331958 : check e1211210331958 [[],[]] .smaller = true := by decide
def e1211210331962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210331962 : Closed e1211210331962 ∧ code e1211210331962 = 5609256843066 := by decide
theorem cert_e1211210331962 : check e1211210331962 [[],[]] .smaller = true := by decide
def e1211210332046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211210332046 : Closed e1211210332046 ∧ code e1211210332046 = 5609256843150 := by decide
theorem cert_e1211210332046 : check e1211210332046 [[],[]] .chain = true := by decide
def e1211210332058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210332058 : Closed e1211210332058 ∧ code e1211210332058 = 5609256843162 := by decide
theorem cert_e1211210332058 : check e1211210332058 [[],[]] .chain = true := by decide
def e1211210332398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211210332398 : Closed e1211210332398 ∧ code e1211210332398 = 5609256843502 := by decide
theorem cert_e1211210332398 : check e1211210332398 [[],[]] .chain = true := by decide
def e1211210332406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211210332406 : Closed e1211210332406 ∧ code e1211210332406 = 5609256843510 := by decide
theorem cert_e1211210332406 : check e1211210332406 [[],[]] .chain = true := by decide
def e1211210332590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211210332590 : Closed e1211210332590 ∧ code e1211210332590 = 5609256843694 := by decide
theorem cert_e1211210332590 : check e1211210332590 [[],[]] .chain = true := by decide
def e1211210332598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211210332598 : Closed e1211210332598 ∧ code e1211210332598 = 5609256843702 := by decide
theorem cert_e1211210332598 : check e1211210332598 [[],[]] .chain = true := by decide
def e1211210332602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211210332602 : Closed e1211210332602 ∧ code e1211210332602 = 5609256843706 := by decide
theorem cert_e1211210332602 : check e1211210332602 [[],[]] .chain = true := by decide
def e1211210332630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211210332630 : Closed e1211210332630 ∧ code e1211210332630 = 5609256843734 := by decide
theorem cert_e1211210332630 : check e1211210332630 [[],[]] .chain = true := by decide
def e1211210332634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211210332634 : Closed e1211210332634 ∧ code e1211210332634 = 5609256843738 := by decide
theorem cert_e1211210332634 : check e1211210332634 [[],[]] .chain = true := by decide
def e1211210332650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211210332650 : Closed e1211210332650 ∧ code e1211210332650 = 5609256843754 := by decide
theorem cert_e1211210332650 : check e1211210332650 [[],[]] .chain = true := by decide
def e1211210332782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210332782 : Closed e1211210332782 ∧ code e1211210332782 = 5609256843886 := by decide
theorem cert_e1211210332782 : check e1211210332782 [[],[]] .chain = true := by decide
def e1211210332790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211210332790 : Closed e1211210332790 ∧ code e1211210332790 = 5609256843894 := by decide
theorem cert_e1211210332790 : check e1211210332790 [[],[]] .chain = true := by decide
def e1211210332794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210332794 : Closed e1211210332794 ∧ code e1211210332794 = 5609256843898 := by decide
theorem cert_e1211210332794 : check e1211210332794 [[],[]] .chain = true := by decide
def e1211210332958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211210332958 : Closed e1211210332958 ∧ code e1211210332958 = 5609256844062 := by decide
theorem cert_e1211210332958 : check e1211210332958 [[],[]] .chain = true := by decide
def e1211210332982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210332982 : Closed e1211210332982 ∧ code e1211210332982 = 5609256844086 := by decide
theorem cert_e1211210332982 : check e1211210332982 [[],[]] .chain = true := by decide
def e1211210332986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210332986 : Closed e1211210332986 ∧ code e1211210332986 = 5609256844090 := by decide
theorem cert_e1211210332986 : check e1211210332986 [[],[]] .chain = true := by decide
def e1211210333070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211210333070 : Closed e1211210333070 ∧ code e1211210333070 = 5609256844174 := by decide
theorem cert_e1211210333070 : check e1211210333070 [[],[]] .chain = true := by decide
def e1211210333082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210333082 : Closed e1211210333082 ∧ code e1211210333082 = 5609256844186 := by decide
theorem cert_e1211210333082 : check e1211210333082 [[],[]] .chain = true := by decide
def e1211210337134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211210337134 : Closed e1211210337134 ∧ code e1211210337134 = 5609256848238 := by decide
theorem cert_e1211210337134 : check e1211210337134 [[],[]] .smaller = true := by decide
def e1211210337142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211210337142 : Closed e1211210337142 ∧ code e1211210337142 = 5609256848246 := by decide
theorem cert_e1211210337142 : check e1211210337142 [[],[]] .smaller = true := by decide
def e1211210337198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211210337198 : Closed e1211210337198 ∧ code e1211210337198 = 5609256848302 := by decide
theorem cert_e1211210337198 : check e1211210337198 [[],[]] .smaller = true := by decide
def e1211210337210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211210337210 : Closed e1211210337210 ∧ code e1211210337210 = 5609256848314 := by decide
theorem cert_e1211210337210 : check e1211210337210 [[],[]] .smaller = true := by decide
def e1211210337238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211210337238 : Closed e1211210337238 ∧ code e1211210337238 = 5609256848342 := by decide
theorem cert_e1211210337238 : check e1211210337238 [[],[]] .smaller = true := by decide
def e1211210337242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211210337242 : Closed e1211210337242 ∧ code e1211210337242 = 5609256848346 := by decide
theorem cert_e1211210337242 : check e1211210337242 [[],[]] .smaller = true := by decide
def e1211210337518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211210337518 : Closed e1211210337518 ∧ code e1211210337518 = 5609256848622 := by decide
theorem cert_e1211210337518 : check e1211210337518 [[],[]] .smaller = true := by decide
def e1211210337526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211210337526 : Closed e1211210337526 ∧ code e1211210337526 = 5609256848630 := by decide
theorem cert_e1211210337526 : check e1211210337526 [[],[]] .smaller = true := by decide
def e1211210337902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211210337902 : Closed e1211210337902 ∧ code e1211210337902 = 5609256849006 := by decide
theorem cert_e1211210337902 : check e1211210337902 [[],[]] .smaller = true := by decide
def e1211210337914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211210337914 : Closed e1211210337914 ∧ code e1211210337914 = 5609256849018 := by decide
theorem cert_e1211210337914 : check e1211210337914 [[],[]] .smaller = true := by decide
def e1211210338102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211210338102 : Closed e1211210338102 ∧ code e1211210338102 = 5609256849206 := by decide
theorem cert_e1211210338102 : check e1211210338102 [[],[]] .smaller = true := by decide
def e1211210338106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211210338106 : Closed e1211210338106 ∧ code e1211210338106 = 5609256849210 := by decide
theorem cert_e1211210338106 : check e1211210338106 [[],[]] .smaller = true := by decide
def e1211210338238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211210338238 : Closed e1211210338238 ∧ code e1211210338238 = 5609256849342 := by decide
theorem cert_e1211210338238 : check e1211210338238 [[],[]] .chain = true := by decide
def e1211210338270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211210338270 : Closed e1211210338270 ∧ code e1211210338270 = 5609256849374 := by decide
theorem cert_e1211210338270 : check e1211210338270 [[],[]] .chain = true := by decide
def e1211210345950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211210345950 : Closed e1211210345950 ∧ code e1211210345950 = 5609256857054 := by decide
theorem cert_e1211210345950 : check e1211210345950 [[],[]] .chain = true := by decide
def e1211210345966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211210345966 : Closed e1211210345966 ∧ code e1211210345966 = 5609256857070 := by decide
theorem cert_e1211210345966 : check e1211210345966 [[],[]] .chain = true := by decide
def e1211210346030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e1211210346030 : Closed e1211210346030 ∧ code e1211210346030 = 5609256857134 := by decide
theorem cert_e1211210346030 : check e1211210346030 [[],[]] .smaller = true := by decide
def e1211210346206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211210346206 : Closed e1211210346206 ∧ code e1211210346206 = 5609256857310 := by decide
theorem cert_e1211210346206 : check e1211210346206 [[],[]] .chain = true := by decide
def e1211210346210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e1211210346210 : Closed e1211210346210 ∧ code e1211210346210 = 5609256857314 := by decide
theorem cert_e1211210346210 : check e1211210346210 [[],[]] .smaller = true := by decide
def e1211210346222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1211210346222 : Closed e1211210346222 ∧ code e1211210346222 = 5609256857326 := by decide
theorem cert_e1211210346222 : check e1211210346222 [[],[]] .smaller = true := by decide
def e1211210346230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211210346230 : Closed e1211210346230 ∧ code e1211210346230 = 5609256857334 := by decide
theorem cert_e1211210346230 : check e1211210346230 [[],[]] .chain = true := by decide
def e1211210346262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211210346262 : Closed e1211210346262 ∧ code e1211210346262 = 5609256857366 := by decide
theorem cert_e1211210346262 : check e1211210346262 [[],[]] .smaller = true := by decide
def e1211210346334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211210346334 : Closed e1211210346334 ∧ code e1211210346334 = 5609256857438 := by decide
theorem cert_e1211210346334 : check e1211210346334 [[],[]] .chain = true := by decide
def e1211210346338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211210346338 : Closed e1211210346338 ∧ code e1211210346338 = 5609256857442 := by decide
theorem cert_e1211210346338 : check e1211210346338 [[],[]] .smaller = true := by decide
def e1211210346350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1211210346350 : Closed e1211210346350 ∧ code e1211210346350 = 5609256857454 := by decide
theorem cert_e1211210346350 : check e1211210346350 [[],[]] .smaller = true := by decide
def e1211210346358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1211210346358 : Closed e1211210346358 ∧ code e1211210346358 = 5609256857462 := by decide
theorem cert_e1211210346358 : check e1211210346358 [[],[]] .smaller = true := by decide
def e1211210346362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211210346362 : Closed e1211210346362 ∧ code e1211210346362 = 5609256857466 := by decide
theorem cert_e1211210346362 : check e1211210346362 [[],[]] .chain = true := by decide
def e1211210346414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211210346414 : Closed e1211210346414 ∧ code e1211210346414 = 5609256857518 := by decide
theorem cert_e1211210346414 : check e1211210346414 [[],[]] .chain = true := by decide
def e1211210346422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211210346422 : Closed e1211210346422 ∧ code e1211210346422 = 5609256857526 := by decide
theorem cert_e1211210346422 : check e1211210346422 [[],[]] .chain = true := by decide
def e1211210346426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211210346426 : Closed e1211210346426 ∧ code e1211210346426 = 5609256857530 := by decide
theorem cert_e1211210346426 : check e1211210346426 [[],[]] .chain = true := by decide
def e1211210347486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211210347486 : Closed e1211210347486 ∧ code e1211210347486 = 5609256858590 := by decide
theorem cert_e1211210347486 : check e1211210347486 [[],[]] .chain = true := by decide
def e1211210347502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211210347502 : Closed e1211210347502 ∧ code e1211210347502 = 5609256858606 := by decide
theorem cert_e1211210347502 : check e1211210347502 [[],[]] .chain = true := by decide
def e1211210348606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e1211210348606 : Closed e1211210348606 ∧ code e1211210348606 = 5609256859710 := by decide
theorem cert_e1211210348606 : check e1211210348606 [[],[]] .smaller = true := by decide
def e1211210349022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211210349022 : Closed e1211210349022 ∧ code e1211210349022 = 5609256860126 := by decide
theorem cert_e1211210349022 : check e1211210349022 [[],[]] .chain = true := by decide
def e1211210349026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211210349026 : Closed e1211210349026 ∧ code e1211210349026 = 5609256860130 := by decide
theorem cert_e1211210349026 : check e1211210349026 [[],[]] .smaller = true := by decide
def e1211210349038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211210349038 : Closed e1211210349038 ∧ code e1211210349038 = 5609256860142 := by decide
theorem cert_e1211210349038 : check e1211210349038 [[],[]] .smaller = true := by decide
def e1211210349046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211210349046 : Closed e1211210349046 ∧ code e1211210349046 = 5609256860150 := by decide
theorem cert_e1211210349046 : check e1211210349046 [[],[]] .chain = true := by decide
def e1211210349598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211210349598 : Closed e1211210349598 ∧ code e1211210349598 = 5609256860702 := by decide
theorem cert_e1211210349598 : check e1211210349598 [[],[]] .smaller = true := by decide
def e1211210349790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211210349790 : Closed e1211210349790 ∧ code e1211210349790 = 5609256860894 := by decide
theorem cert_e1211210349790 : check e1211210349790 [[],[]] .chain = true := by decide
def e1211210349794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211210349794 : Closed e1211210349794 ∧ code e1211210349794 = 5609256860898 := by decide
theorem cert_e1211210349794 : check e1211210349794 [[],[]] .smaller = true := by decide
def e1211210349806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211210349806 : Closed e1211210349806 ∧ code e1211210349806 = 5609256860910 := by decide
theorem cert_e1211210349806 : check e1211210349806 [[],[]] .smaller = true := by decide
def e1211210349814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211210349814 : Closed e1211210349814 ∧ code e1211210349814 = 5609256860918 := by decide
theorem cert_e1211210349814 : check e1211210349814 [[],[]] .smaller = true := by decide
def e1211210349818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211210349818 : Closed e1211210349818 ∧ code e1211210349818 = 5609256860922 := by decide
theorem cert_e1211210349818 : check e1211210349818 [[],[]] .chain = true := by decide
def e1211210350190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211210350190 : Closed e1211210350190 ∧ code e1211210350190 = 5609256861294 := by decide
theorem cert_e1211210350190 : check e1211210350190 [[],[]] .chain = true := by decide
def e1211210350198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211210350198 : Closed e1211210350198 ∧ code e1211210350198 = 5609256861302 := by decide
theorem cert_e1211210350198 : check e1211210350198 [[],[]] .chain = true := by decide
def e1211210350202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211210350202 : Closed e1211210350202 ∧ code e1211210350202 = 5609256861306 := by decide
theorem cert_e1211210350202 : check e1211210350202 [[],[]] .chain = true := by decide
def e1211210368958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211210368958 : Closed e1211210368958 ∧ code e1211210368958 = 5609256880062 := by decide
theorem cert_e1211210368958 : check e1211210368958 [[],[]] .chain = true := by decide
def e1211210369006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211210369006 : Closed e1211210369006 ∧ code e1211210369006 = 5609256880110 := by decide
theorem cert_e1211210369006 : check e1211210369006 [[],[]] .chain = true := by decide
def e1211210372654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e1211210372654 : Closed e1211210372654 ∧ code e1211210372654 = 5609256883758 := by decide
theorem cert_e1211210372654 : check e1211210372654 [[],[]] .smaller = true := by decide
def e1211210372830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211210372830 : Closed e1211210372830 ∧ code e1211210372830 = 5609256883934 := by decide
theorem cert_e1211210372830 : check e1211210372830 [[],[]] .chain = true := by decide
def e1211210372834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e1211210372834 : Closed e1211210372834 ∧ code e1211210372834 = 5609256883938 := by decide
theorem cert_e1211210372834 : check e1211210372834 [[],[]] .smaller = true := by decide
def e1211210372846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1211210372846 : Closed e1211210372846 ∧ code e1211210372846 = 5609256883950 := by decide
theorem cert_e1211210372846 : check e1211210372846 [[],[]] .smaller = true := by decide
def e1211210372854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211210372854 : Closed e1211210372854 ∧ code e1211210372854 = 5609256883958 := by decide
theorem cert_e1211210372854 : check e1211210372854 [[],[]] .chain = true := by decide
def e1211210372958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211210372958 : Closed e1211210372958 ∧ code e1211210372958 = 5609256884062 := by decide
theorem cert_e1211210372958 : check e1211210372958 [[],[]] .chain = true := by decide
def e1211210372986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211210372986 : Closed e1211210372986 ∧ code e1211210372986 = 5609256884090 := by decide
theorem cert_e1211210372986 : check e1211210372986 [[],[]] .chain = true := by decide
def e1211210373002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211210373002 : Closed e1211210373002 ∧ code e1211210373002 = 5609256884106 := by decide
theorem cert_e1211210373002 : check e1211210373002 [[],[]] .smaller = true := by decide
def e1211210373026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211210373026 : Closed e1211210373026 ∧ code e1211210373026 = 5609256884130 := by decide
theorem cert_e1211210373026 : check e1211210373026 [[],[]] .smaller = true := by decide
def e1211210373038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1211210373038 : Closed e1211210373038 ∧ code e1211210373038 = 5609256884142 := by decide
theorem cert_e1211210373038 : check e1211210373038 [[],[]] .smaller = true := by decide
def e1211210373050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1211210373050 : Closed e1211210373050 ∧ code e1211210373050 = 5609256884154 := by decide
theorem cert_e1211210373050 : check e1211210373050 [[],[]] .smaller = true := by decide
end Blc.Floor42
