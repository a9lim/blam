import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211476500022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211476500022 : Closed e1211476500022 ∧ code e1211476500022 = 5609523011126 := by decide
theorem cert_e1211476500022 : check e1211476500022 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211476500026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211476500026 : Closed e1211476500026 ∧ code e1211476500026 = 5609523011130 := by decide
theorem cert_e1211476500026 : check e1211476500026 [[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211476500110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211476500110 : Closed e1211476500110 ∧ code e1211476500110 = 5609523011214 := by decide
theorem cert_e1211476500110 : check e1211476500110 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211476500166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211476500166 : Closed e1211476500166 ∧ code e1211476500166 = 5609523011270 := by decide
private def t_e1211476500166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e1211476500166 : ¬ IsSelfInterpreter e1211476500166 :=
  wSource (t := t_e1211476500166) (replay_sound (ps := []) (t := e1211476500166) (by decide)) (by decide)
def e1211476502302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211476502302 : Closed e1211476502302 ∧ code e1211476502302 = 5609523013406 := by decide
theorem cert_e1211476502302 : check e1211476502302 [[],[],[],[]] .sourceHead = true := by decide
def e1211476502414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211476502414 : Closed e1211476502414 ∧ code e1211476502414 = 5609523013518 := by decide
theorem cert_e1211476502414 : check e1211476502414 [[],[],[],[]] .sourceHead = true := by decide
def e1211476505374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211476505374 : Closed e1211476505374 ∧ code e1211476505374 = 5609523016478 := by decide
theorem cert_e1211476505374 : checkPay e1211476505374 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under],[.under,.under],[.under,.under,.under]] = true := by decide
def e1211476505542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211476505542 : Closed e1211476505542 ∧ code e1211476505542 = 5609523016646 := by decide
theorem cert_e1211476505542 : check e1211476505542 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1211476507022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211476507022 : Closed e1211476507022 ∧ code e1211476507022 = 5609523018126 := by decide
theorem cert_e1211476507022 : checkPay e1211476507022 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[]] 0 [[.under,.under,.under],[.under,.under,.under],[.under,.under,.under]] = true := by decide
def e1211476507078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211476507078 : Closed e1211476507078 ∧ code e1211476507078 = 5609523018182 := by decide
theorem cert_e1211476507078 : check e1211476507078 [[],[],[],[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211549899642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.var 0))))
theorem wire_e1211549899642 : Closed e1211549899642 ∧ code e1211549899642 = 5609596410746 := by decide
theorem cert_e1211549899642 : check e1211549899642 [[],[],[.left]] .chain = true := by decide
def e1211549899738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.var 0))))
theorem wire_e1211549899738 : Closed e1211549899738 ∧ code e1211549899738 = 5609596410842 := by decide
theorem cert_e1211549899738 : check e1211549899738 [[],[],[.left]] .chain = true := by decide
def e1211549900154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.var 0))))
theorem wire_e1211549900154 : Closed e1211549900154 ∧ code e1211549900154 = 5609596411258 := by decide
theorem cert_e1211549900154 : check e1211549900154 [[],[],[.left]] .chain = true := by decide
def e1211549900266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.var 0))))
theorem wire_e1211549900266 : Closed e1211549900266 ∧ code e1211549900266 = 5609596411370 := by decide
theorem cert_e1211549900266 : check e1211549900266 [[],[],[.left]] .chain = true := by decide
def e1211549900634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e1211549900634 : Closed e1211549900634 ∧ code e1211549900634 = 5609596411738 := by decide
theorem cert_e1211549900634 : check e1211549900634 [[],[],[.left]] .chain = true := by decide
def e1211549900650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e1211549900650 : Closed e1211549900650 ∧ code e1211549900650 = 5609596411754 := by decide
theorem cert_e1211549900650 : check e1211549900650 [[],[],[.left]] .chain = true := by decide
def e1211549902714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.var 0))))
theorem wire_e1211549902714 : Closed e1211549902714 ∧ code e1211549902714 = 5609596413818 := by decide
theorem cert_e1211549902714 : check e1211549902714 [[],[],[.left]] .chain = true := by decide
def e1211549902810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.var 0))))
theorem wire_e1211549902810 : Closed e1211549902810 ∧ code e1211549902810 = 5609596413914 := by decide
theorem cert_e1211549902810 : check e1211549902810 [[],[],[.left]] .chain = true := by decide
def e1211549905786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.var 0))))
theorem wire_e1211549905786 : Closed e1211549905786 ∧ code e1211549905786 = 5609596416890 := by decide
theorem cert_e1211549905786 : check e1211549905786 [[],[],[.left]] .chain = true := by decide
def e1211549905898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.var 0))))
theorem wire_e1211549905898 : Closed e1211549905898 ∧ code e1211549905898 = 5609596417002 := by decide
theorem cert_e1211549905898 : check e1211549905898 [[],[],[.left]] .chain = true := by decide
def e1211549908186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e1211549908186 : Closed e1211549908186 ∧ code e1211549908186 = 5609596419290 := by decide
theorem cert_e1211549908186 : check e1211549908186 [[],[],[.left]] .chain = true := by decide
def e1211549908202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e1211549908202 : Closed e1211549908202 ∧ code e1211549908202 = 5609596419306 := by decide
theorem cert_e1211549908202 : check e1211549908202 [[],[],[.left]] .chain = true := by decide
def e1211549967290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.var 0))))
theorem wire_e1211549967290 : Closed e1211549967290 ∧ code e1211549967290 = 5609596478394 := by decide
theorem cert_e1211549967290 : check e1211549967290 [[],[],[.left]] .chain = true := by decide
def e1211549967322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.var 0))))
theorem wire_e1211549967322 : Closed e1211549967322 ∧ code e1211549967322 = 5609596478426 := by decide
theorem cert_e1211549967322 : check e1211549967322 [[],[],[.left]] .chain = true := by decide
def e1211549969530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.var 0))))
theorem wire_e1211549969530 : Closed e1211549969530 ∧ code e1211549969530 = 5609596480634 := by decide
theorem cert_e1211549969530 : check e1211549969530 [[],[],[.left]] .chain = true := by decide
def e1211549969862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.var 1)))))
theorem wire_e1211549969862 : Closed e1211549969862 ∧ code e1211549969862 = 5609596480966 := by decide
theorem cert_e1211549969862 : check e1211549969862 [[],[],[.left]] .chain = true := by decide
def e1211549969890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.lam (.var 0)))))
theorem wire_e1211549969890 : Closed e1211549969890 ∧ code e1211549969890 = 5609596480994 := by decide
theorem cert_e1211549969890 : check e1211549969890 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549969978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.var 0))))
theorem wire_e1211549969978 : Closed e1211549969978 ∧ code e1211549969978 = 5609596481082 := by decide
theorem cert_e1211549969978 : check e1211549969978 [[],[],[.left]] .chain = true := by decide
def e1211549970118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.var 1)))))
theorem wire_e1211549970118 : Closed e1211549970118 ∧ code e1211549970118 = 5609596481222 := by decide
theorem cert_e1211549970118 : check e1211549970118 [[],[],[.left]] .chain = true := by decide
def e1211549970274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e1211549970274 : Closed e1211549970274 ∧ code e1211549970274 = 5609596481378 := by decide
theorem cert_e1211549970274 : check e1211549970274 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549970874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.var 0))))
theorem wire_e1211549970874 : Closed e1211549970874 ∧ code e1211549970874 = 5609596481978 := by decide
theorem cert_e1211549970874 : check e1211549970874 [[],[],[.left]] .chain = true := by decide
def e1211549970922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.var 0))))
theorem wire_e1211549970922 : Closed e1211549970922 ∧ code e1211549970922 = 5609596482026 := by decide
theorem cert_e1211549970922 : check e1211549970922 [[],[],[.left]] .chain = true := by decide
def e1211549971578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.var 0))))
theorem wire_e1211549971578 : Closed e1211549971578 ∧ code e1211549971578 = 5609596482682 := by decide
theorem cert_e1211549971578 : check e1211549971578 [[],[],[.left]] .chain = true := by decide
def e1211549971910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.var 1)))))
theorem wire_e1211549971910 : Closed e1211549971910 ∧ code e1211549971910 = 5609596483014 := by decide
theorem cert_e1211549971910 : check e1211549971910 [[],[],[.left]] .chain = true := by decide
def e1211549971938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.lam (.var 0)))))
theorem wire_e1211549971938 : Closed e1211549971938 ∧ code e1211549971938 = 5609596483042 := by decide
theorem cert_e1211549971938 : check e1211549971938 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549972250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.var 0))))
theorem wire_e1211549972250 : Closed e1211549972250 ∧ code e1211549972250 = 5609596483354 := by decide
theorem cert_e1211549972250 : check e1211549972250 [[],[],[.left]] .chain = true := by decide
def e1211549972294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.var 1)))))
theorem wire_e1211549972294 : Closed e1211549972294 ∧ code e1211549972294 = 5609596483398 := by decide
theorem cert_e1211549972294 : check e1211549972294 [[],[],[.left]] .chain = true := by decide
def e1211549972346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))) (.var 0))))
theorem wire_e1211549972346 : Closed e1211549972346 ∧ code e1211549972346 = 5609596483450 := by decide
theorem cert_e1211549972346 : check e1211549972346 [[],[],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211549972386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e1211549972386 : Closed e1211549972386 ∧ code e1211549972386 = 5609596483490 := by decide
theorem cert_e1211549972386 : check e1211549972386 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549972410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))) (.var 0))))
theorem wire_e1211549972410 : Closed e1211549972410 ∧ code e1211549972410 = 5609596483514 := by decide
theorem cert_e1211549972410 : check e1211549972410 [[],[],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211549972698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.var 0))))
theorem wire_e1211549972698 : Closed e1211549972698 ∧ code e1211549972698 = 5609596483802 := by decide
theorem cert_e1211549972698 : check e1211549972698 [[],[],[.left]] .chain = true := by decide
def e1211549972714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.var 0))))
theorem wire_e1211549972714 : Closed e1211549972714 ∧ code e1211549972714 = 5609596483818 := by decide
theorem cert_e1211549972714 : check e1211549972714 [[],[],[.left]] .chain = true := by decide
def e1211549973050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.var 0))))
theorem wire_e1211549973050 : Closed e1211549973050 ∧ code e1211549973050 = 5609596484154 := by decide
theorem cert_e1211549973050 : check e1211549973050 [[],[],[.left]] .chain = true := by decide
def e1211549973190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.var 1)))))
theorem wire_e1211549973190 : Closed e1211549973190 ∧ code e1211549973190 = 5609596484294 := by decide
theorem cert_e1211549973190 : check e1211549973190 [[],[],[.left]] .chain = true := by decide
def e1211549973274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.var 0))))
theorem wire_e1211549973274 : Closed e1211549973274 ∧ code e1211549973274 = 5609596484378 := by decide
theorem cert_e1211549973274 : check e1211549973274 [[],[],[.left]] .chain = true := by decide
def e1211549973318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.var 1)))))
theorem wire_e1211549973318 : Closed e1211549973318 ∧ code e1211549973318 = 5609596484422 := by decide
theorem cert_e1211549973318 : check e1211549973318 [[],[],[.left]] .chain = true := by decide
def e1211549973370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))) (.var 0))))
theorem wire_e1211549973370 : Closed e1211549973370 ∧ code e1211549973370 = 5609596484474 := by decide
theorem cert_e1211549973370 : check e1211549973370 [[],[],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211549973466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))) (.var 0))))
theorem wire_e1211549973466 : Closed e1211549973466 ∧ code e1211549973466 = 5609596484570 := by decide
private def t_e1211549973466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))) (.var 0))))
theorem cert_e1211549973466 : ¬ IsSelfInterpreter e1211549973466 :=
  wSource (t := t_e1211549973466) (replay_sound (ps := []) (t := e1211549973466) (by decide)) (by decide)
def e1211549973858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e1211549973858 : Closed e1211549973858 ∧ code e1211549973858 = 5609596484962 := by decide
theorem cert_e1211549973858 : check e1211549973858 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549973922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e1211549973922 : Closed e1211549973922 ∧ code e1211549973922 = 5609596485026 := by decide
theorem cert_e1211549973922 : check e1211549973922 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549973946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e1211549973946 : Closed e1211549973946 ∧ code e1211549973946 = 5609596485050 := by decide
def e1211549973978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e1211549973978 : Closed e1211549973978 ∧ code e1211549973978 = 5609596485082 := by decide
private def t_e1211549973978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))) (.var 0))))
theorem cert_e1211549973978 : ¬ IsSelfInterpreter e1211549973978 :=
  wSource (t := t_e1211549973978) (replay_sound (ps := []) (t := e1211549973978) (by decide)) (by decide)
def e1211549981818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.var 0))))
theorem wire_e1211549981818 : Closed e1211549981818 ∧ code e1211549981818 = 5609596492922 := by decide
theorem cert_e1211549981818 : check e1211549981818 [[],[],[.left]] .chain = true := by decide
def e1211549982150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.var 1)))))
theorem wire_e1211549982150 : Closed e1211549982150 ∧ code e1211549982150 = 5609596493254 := by decide
theorem cert_e1211549982150 : check e1211549982150 [[],[],[.left]] .chain = true := by decide
def e1211549982178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.lam (.var 0)))))
theorem wire_e1211549982178 : Closed e1211549982178 ∧ code e1211549982178 = 5609596493282 := by decide
theorem cert_e1211549982178 : check e1211549982178 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549982266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.var 0))))
theorem wire_e1211549982266 : Closed e1211549982266 ∧ code e1211549982266 = 5609596493370 := by decide
theorem cert_e1211549982266 : check e1211549982266 [[],[],[.left]] .chain = true := by decide
def e1211549982406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.var 1)))))
theorem wire_e1211549982406 : Closed e1211549982406 ∧ code e1211549982406 = 5609596493510 := by decide
theorem cert_e1211549982406 : check e1211549982406 [[],[],[.left]] .chain = true := by decide
def e1211549982562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.lam (.var 0)))))
theorem wire_e1211549982562 : Closed e1211549982562 ∧ code e1211549982562 = 5609596493666 := by decide
theorem cert_e1211549982562 : check e1211549982562 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549994106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.var 0))))
theorem wire_e1211549994106 : Closed e1211549994106 ∧ code e1211549994106 = 5609596505210 := by decide
theorem cert_e1211549994106 : check e1211549994106 [[],[],[.left]] .chain = true := by decide
def e1211549994438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.var 1)))))
theorem wire_e1211549994438 : Closed e1211549994438 ∧ code e1211549994438 = 5609596505542 := by decide
theorem cert_e1211549994438 : check e1211549994438 [[],[],[.left]] .chain = true := by decide
def e1211549994466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.lam (.var 0)))))
theorem wire_e1211549994466 : Closed e1211549994466 ∧ code e1211549994466 = 5609596505570 := by decide
theorem cert_e1211549994466 : check e1211549994466 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549994778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.var 0))))
theorem wire_e1211549994778 : Closed e1211549994778 ∧ code e1211549994778 = 5609596505882 := by decide
theorem cert_e1211549994778 : check e1211549994778 [[],[],[.left]] .chain = true := by decide
def e1211549994822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.var 1)))))
theorem wire_e1211549994822 : Closed e1211549994822 ∧ code e1211549994822 = 5609596505926 := by decide
theorem cert_e1211549994822 : check e1211549994822 [[],[],[.left]] .chain = true := by decide
def e1211549994874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))) (.var 0))))
theorem wire_e1211549994874 : Closed e1211549994874 ∧ code e1211549994874 = 5609596505978 := by decide
theorem cert_e1211549994874 : check e1211549994874 [[],[],[.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1211549994914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.lam (.var 0)))))
theorem wire_e1211549994914 : Closed e1211549994914 ∧ code e1211549994914 = 5609596506018 := by decide
theorem cert_e1211549994914 : check e1211549994914 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211549994938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))) (.var 0))))
theorem wire_e1211549994938 : Closed e1211549994938 ∧ code e1211549994938 = 5609596506042 := by decide
theorem cert_e1211549994938 : check e1211549994938 [[],[],[.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e1211550000698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.var 0))))
theorem wire_e1211550000698 : Closed e1211550000698 ∧ code e1211550000698 = 5609596511802 := by decide
theorem cert_e1211550000698 : check e1211550000698 [[],[],[.left]] .chain = true := by decide
def e1211550000838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.var 1)))))
theorem wire_e1211550000838 : Closed e1211550000838 ∧ code e1211550000838 = 5609596511942 := by decide
theorem cert_e1211550000838 : check e1211550000838 [[],[],[.left]] .chain = true := by decide
def e1211550000922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.var 0))))
theorem wire_e1211550000922 : Closed e1211550000922 ∧ code e1211550000922 = 5609596512026 := by decide
theorem cert_e1211550000922 : check e1211550000922 [[],[],[.left]] .chain = true := by decide
def e1211550000966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.var 1)))))
theorem wire_e1211550000966 : Closed e1211550000966 ∧ code e1211550000966 = 5609596512070 := by decide
theorem cert_e1211550000966 : check e1211550000966 [[],[],[.left]] .chain = true := by decide
def e1211550001018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))) (.var 0))))
theorem wire_e1211550001018 : Closed e1211550001018 ∧ code e1211550001018 = 5609596512122 := by decide
theorem cert_e1211550001018 : check e1211550001018 [[],[],[.left],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211550001114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))) (.var 0))))
theorem wire_e1211550001114 : Closed e1211550001114 ∧ code e1211550001114 = 5609596512218 := by decide
theorem cert_e1211550001114 : check e1211550001114 [[],[],[.left],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211550004066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))))
theorem wire_e1211550004066 : Closed e1211550004066 ∧ code e1211550004066 = 5609596515170 := by decide
theorem cert_e1211550004066 : check e1211550004066 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211550004130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))))
theorem wire_e1211550004130 : Closed e1211550004130 ∧ code e1211550004130 = 5609596515234 := by decide
theorem cert_e1211550004130 : check e1211550004130 [[],[],[.left],[.left,.left]] .chain = true := by decide
def e1211550004154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e1211550004154 : Closed e1211550004154 ∧ code e1211550004154 = 5609596515258 := by decide
def e1211550004186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e1211550004186 : Closed e1211550004186 ∧ code e1211550004186 = 5609596515290 := by decide
theorem cert_e1211550004186 : check e1211550004186 [[],[],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211550231994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e1211550231994 : Closed e1211550231994 ∧ code e1211550231994 = 5609596743098 := by decide
def e1211550232026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e1211550232026 : Closed e1211550232026 ∧ code e1211550232026 = 5609596743130 := by decide
def e1211550232282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))) (.var 0))))
theorem wire_e1211550232282 : Closed e1211550232282 ∧ code e1211550232282 = 5609596743386 := by decide
def e1211550234042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e1211550234042 : Closed e1211550234042 ∧ code e1211550234042 = 5609596745146 := by decide
def e1211550234074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e1211550234074 : Closed e1211550234074 ∧ code e1211550234074 = 5609596745178 := by decide
def e1211550234298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e1211550234298 : Closed e1211550234298 ∧ code e1211550234298 = 5609596745402 := by decide
private def t_e1211550234298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.var 0))))
theorem cert_e1211550234298 : ¬ IsSelfInterpreter e1211550234298 :=
  wSource (t := t_e1211550234298) (replay_sound (ps := []) (t := e1211550234298) (by decide)) (by decide)
def e1211550234346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e1211550234346 : Closed e1211550234346 ∧ code e1211550234346 = 5609596745450 := by decide
private def t_e1211550234346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.var 0))))
theorem cert_e1211550234346 : ¬ IsSelfInterpreter e1211550234346 :=
  wSource (t := t_e1211550234346) (replay_sound (ps := []) (t := e1211550234346) (by decide)) (by decide)
def e1211550234458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e1211550234458 : Closed e1211550234458 ∧ code e1211550234458 = 5609596745562 := by decide
private def t_e1211550234458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))) (.var 0))))
theorem cert_e1211550234458 : ¬ IsSelfInterpreter e1211550234458 :=
  wSource (t := t_e1211550234458) (replay_sound (ps := []) (t := e1211550234458) (by decide)) (by decide)
def e1211550234474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e1211550234474 : Closed e1211550234474 ∧ code e1211550234474 = 5609596745578 := by decide
private def t_e1211550234474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e1211550234474 : ¬ IsSelfInterpreter e1211550234474 :=
  wSource (t := t_e1211550234474) (replay_sound (ps := []) (t := e1211550234474) (by decide)) (by decide)
def e1211550235354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))) (.var 0))))
theorem wire_e1211550235354 : Closed e1211550235354 ∧ code e1211550235354 = 5609596746458 := by decide
def e1211550235482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e1211550235482 : Closed e1211550235482 ∧ code e1211550235482 = 5609596746586 := by decide
private def t_e1211550235482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))) (.var 0))))
theorem cert_e1211550235482 : ¬ IsSelfInterpreter e1211550235482 :=
  wSource (t := t_e1211550235482) (replay_sound (ps := []) (t := e1211550235482) (by decide)) (by decide)
def e1211550235498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e1211550235498 : Closed e1211550235498 ∧ code e1211550235498 = 5609596746602 := by decide
private def t_e1211550235498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e1211550235498 : ¬ IsSelfInterpreter e1211550235498 :=
  wSource (t := t_e1211550235498) (replay_sound (ps := []) (t := e1211550235498) (by decide)) (by decide)
def e1211550240482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.lam (.var 0)))))
theorem wire_e1211550240482 : Closed e1211550240482 ∧ code e1211550240482 = 5609596751586 := by decide
theorem cert_e1211550240482 : check e1211550240482 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left]] .chain = true := by decide
def e1211550240610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.lam (.var 0)))))
theorem wire_e1211550240610 : Closed e1211550240610 ∧ code e1211550240610 = 5609596751714 := by decide
theorem cert_e1211550240610 : check e1211550240610 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left]] .smaller = true := by decide
def e1211550244282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))) (.var 0))))
theorem wire_e1211550244282 : Closed e1211550244282 ∧ code e1211550244282 = 5609596755386 := by decide
def e1211550244314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))) (.var 0))))
theorem wire_e1211550244314 : Closed e1211550244314 ∧ code e1211550244314 = 5609596755418 := by decide
def e1211550244570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))) (.var 0))))
theorem wire_e1211550244570 : Closed e1211550244570 ∧ code e1211550244570 = 5609596755674 := by decide
def e1211550249442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.lam (.var 0)))))
theorem wire_e1211550249442 : Closed e1211550249442 ∧ code e1211550249442 = 5609596760546 := by decide
theorem cert_e1211550249442 : check e1211550249442 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1211550249914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e1211550249914 : Closed e1211550249914 ∧ code e1211550249914 = 5609596761018 := by decide
def e1211550249946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e1211550249946 : Closed e1211550249946 ∧ code e1211550249946 = 5609596761050 := by decide
def e1211550250758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550250758 : Closed e1211550250758 ∧ code e1211550250758 = 5609596761862 := by decide
theorem cert_e1211550250758 : check e1211550250758 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left]] .chain = true := by decide
def e1211550251234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.lam (.var 0)))))
theorem wire_e1211550251234 : Closed e1211550251234 ∧ code e1211550251234 = 5609596762338 := by decide
theorem cert_e1211550251234 : check e1211550251234 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550251482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))) (.var 0))))
theorem wire_e1211550251482 : Closed e1211550251482 ∧ code e1211550251482 = 5609596762586 := by decide
def e1211550251782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550251782 : Closed e1211550251782 ∧ code e1211550251782 = 5609596762886 := by decide
theorem cert_e1211550251782 : check e1211550251782 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left]] .smaller = true := by decide
def e1211550254818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.lam (.var 0)))))
theorem wire_e1211550254818 : Closed e1211550254818 ∧ code e1211550254818 = 5609596765922 := by decide
theorem cert_e1211550254818 : check e1211550254818 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550255010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.lam (.var 0)))))
theorem wire_e1211550255010 : Closed e1211550255010 ∧ code e1211550255010 = 5609596766114 := by decide
theorem cert_e1211550255010 : check e1211550255010 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550256570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))))
theorem wire_e1211550256570 : Closed e1211550256570 ∧ code e1211550256570 = 5609596767674 := by decide
def e1211550256602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0))))
theorem wire_e1211550256602 : Closed e1211550256602 ∧ code e1211550256602 = 5609596767706 := by decide
def e1211550256826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))))
theorem wire_e1211550256826 : Closed e1211550256826 ∧ code e1211550256826 = 5609596767930 := by decide
def e1211550256874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))))
theorem wire_e1211550256874 : Closed e1211550256874 ∧ code e1211550256874 = 5609596767978 := by decide
private def t_e1211550256874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))))
theorem cert_e1211550256874 : ¬ IsSelfInterpreter e1211550256874 :=
  wSource (t := t_e1211550256874) (replay_sound (ps := []) (t := e1211550256874) (by decide)) (by decide)
def e1211550256986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0))))
theorem wire_e1211550256986 : Closed e1211550256986 ∧ code e1211550256986 = 5609596768090 := by decide
def e1211550257002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))))
theorem wire_e1211550257002 : Closed e1211550257002 ∧ code e1211550257002 = 5609596768106 := by decide
private def t_e1211550257002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))))
theorem cert_e1211550257002 : ¬ IsSelfInterpreter e1211550257002 :=
  wSource (t := t_e1211550257002) (replay_sound (ps := []) (t := e1211550257002) (by decide)) (by decide)
def e1211550257634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.lam (.var 0)))))
theorem wire_e1211550257634 : Closed e1211550257634 ∧ code e1211550257634 = 5609596768738 := by decide
theorem cert_e1211550257634 : check e1211550257634 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left]] .smaller = true := by decide
def e1211550258106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e1211550258106 : Closed e1211550258106 ∧ code e1211550258106 = 5609596769210 := by decide
def e1211550258138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e1211550258138 : Closed e1211550258138 ∧ code e1211550258138 = 5609596769242 := by decide
def e1211550258950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550258950 : Closed e1211550258950 ∧ code e1211550258950 = 5609596770054 := by decide
theorem cert_e1211550258950 : check e1211550258950 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left]] .smaller = true := by decide
def e1211550259642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e1211550259642 : Closed e1211550259642 ∧ code e1211550259642 = 5609596770746 := by decide
private def t_e1211550259642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem cert_e1211550259642 : ¬ IsSelfInterpreter e1211550259642 :=
  wSource (t := t_e1211550259642) (replay_sound (ps := []) (t := e1211550259642) (by decide)) (by decide)
def e1211550259690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e1211550259690 : Closed e1211550259690 ∧ code e1211550259690 = 5609596770794 := by decide
private def t_e1211550259690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem cert_e1211550259690 : ¬ IsSelfInterpreter e1211550259690 :=
  wSource (t := t_e1211550259690) (replay_sound (ps := []) (t := e1211550259690) (by decide)) (by decide)
def e1211550260322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.lam (.var 0)))))
theorem wire_e1211550260322 : Closed e1211550260322 ∧ code e1211550260322 = 5609596771426 := by decide
private def t_e1211550260322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.lam (.var 0)))))
theorem cert_e1211550260322 : ¬ IsSelfInterpreter e1211550260322 :=
  wSource (t := t_e1211550260322) (replay_sound (ps := []) (t := e1211550260322) (by decide)) (by decide)
def e1211550260442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e1211550260442 : Closed e1211550260442 ∧ code e1211550260442 = 5609596771546 := by decide
private def t_e1211550260442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem cert_e1211550260442 : ¬ IsSelfInterpreter e1211550260442 :=
  wSource (t := t_e1211550260442) (replay_sound (ps := []) (t := e1211550260442) (by decide)) (by decide)
def e1211550260458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e1211550260458 : Closed e1211550260458 ∧ code e1211550260458 = 5609596771562 := by decide
private def t_e1211550260458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem cert_e1211550260458 : ¬ IsSelfInterpreter e1211550260458 :=
  wSource (t := t_e1211550260458) (replay_sound (ps := []) (t := e1211550260458) (by decide)) (by decide)
def e1211550260486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550260486 : Closed e1211550260486 ∧ code e1211550260486 = 5609596771590 := by decide
private def t_e1211550260486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 1))))))
theorem cert_e1211550260486 : ¬ IsSelfInterpreter e1211550260486 :=
  wSource (t := t_e1211550260486) (replay_sound (ps := []) (t := e1211550260486) (by decide)) (by decide)
def e1211550262114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.lam (.var 0)))))
theorem wire_e1211550262114 : Closed e1211550262114 ∧ code e1211550262114 = 5609596773218 := by decide
theorem cert_e1211550262114 : check e1211550262114 [[],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550262178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.lam (.var 0)))))
theorem wire_e1211550262178 : Closed e1211550262178 ∧ code e1211550262178 = 5609596773282 := by decide
theorem cert_e1211550262178 : check e1211550262178 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left]] .chain = true := by decide
def e1211550263002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))) (.var 0))))
theorem wire_e1211550263002 : Closed e1211550263002 ∧ code e1211550263002 = 5609596774106 := by decide
def e1211550263130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))) (.var 0))))
theorem wire_e1211550263130 : Closed e1211550263130 ∧ code e1211550263130 = 5609596774234 := by decide
def e1211550263146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))) (.var 0))))
theorem wire_e1211550263146 : Closed e1211550263146 ∧ code e1211550263146 = 5609596774250 := by decide
private def t_e1211550263146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))) (.var 0))))
theorem cert_e1211550263146 : ¬ IsSelfInterpreter e1211550263146 :=
  wSource (t := t_e1211550263146) (replay_sound (ps := []) (t := e1211550263146) (by decide)) (by decide)
def e1211550263522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.lam (.var 0)))))
theorem wire_e1211550263522 : Closed e1211550263522 ∧ code e1211550263522 = 5609596774626 := by decide
theorem cert_e1211550263522 : check e1211550263522 [[],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550263770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 0))))
theorem wire_e1211550263770 : Closed e1211550263770 ∧ code e1211550263770 = 5609596774874 := by decide
def e1211550264070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550264070 : Closed e1211550264070 ∧ code e1211550264070 = 5609596775174 := by decide
theorem cert_e1211550264070 : check e1211550264070 [[],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550264418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.lam (.var 0)))))
theorem wire_e1211550264418 : Closed e1211550264418 ∧ code e1211550264418 = 5609596775522 := by decide
private def t_e1211550264418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.lam (.var 0)))))
theorem cert_e1211550264418 : ¬ IsSelfInterpreter e1211550264418 :=
  wSource (t := t_e1211550264418) (replay_sound (ps := []) (t := e1211550264418) (by decide)) (by decide)
def e1211550264538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e1211550264538 : Closed e1211550264538 ∧ code e1211550264538 = 5609596775642 := by decide
private def t_e1211550264538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem cert_e1211550264538 : ¬ IsSelfInterpreter e1211550264538 :=
  wSource (t := t_e1211550264538) (replay_sound (ps := []) (t := e1211550264538) (by decide)) (by decide)
def e1211550264554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e1211550264554 : Closed e1211550264554 ∧ code e1211550264554 = 5609596775658 := by decide
private def t_e1211550264554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem cert_e1211550264554 : ¬ IsSelfInterpreter e1211550264554 :=
  wSource (t := t_e1211550264554) (replay_sound (ps := []) (t := e1211550264554) (by decide)) (by decide)
def e1211550264582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550264582 : Closed e1211550264582 ∧ code e1211550264582 = 5609596775686 := by decide
private def t_e1211550264582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 1))))))
theorem cert_e1211550264582 : ¬ IsSelfInterpreter e1211550264582 :=
  wSource (t := t_e1211550264582) (replay_sound (ps := []) (t := e1211550264582) (by decide)) (by decide)
def e1211550293434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e1211550293434 : Closed e1211550293434 ∧ code e1211550293434 = 5609596804538 := by decide
def e1211550293466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e1211550293466 : Closed e1211550293466 ∧ code e1211550293466 = 5609596804570 := by decide
def e1211550293722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.var 0))))
theorem wire_e1211550293722 : Closed e1211550293722 ∧ code e1211550293722 = 5609596804826 := by decide
def e1211550298594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.lam (.var 0)))))
theorem wire_e1211550298594 : Closed e1211550298594 ∧ code e1211550298594 = 5609596809698 := by decide
theorem cert_e1211550298594 : check e1211550298594 [[],[],[.left],[.left,.left],[.left],[.left],[.left],[],[],[]] .smaller = true := by decide
def e1211550299066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e1211550299066 : Closed e1211550299066 ∧ code e1211550299066 = 5609596810170 := by decide
def e1211550299098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e1211550299098 : Closed e1211550299098 ∧ code e1211550299098 = 5609596810202 := by decide
def e1211550299910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550299910 : Closed e1211550299910 ∧ code e1211550299910 = 5609596811014 := by decide
theorem cert_e1211550299910 : check e1211550299910 [[],[],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1211550300386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.lam (.var 0)))))
theorem wire_e1211550300386 : Closed e1211550300386 ∧ code e1211550300386 = 5609596811490 := by decide
theorem cert_e1211550300386 : check e1211550300386 [[],[],[.left],[.left,.left],[.left],[.left],[.left],[.left,.left]] .chain = true := by decide
def e1211550300634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))) (.var 0))))
theorem wire_e1211550300634 : Closed e1211550300634 ∧ code e1211550300634 = 5609596811738 := by decide
def e1211550300934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550300934 : Closed e1211550300934 ∧ code e1211550300934 = 5609596812038 := by decide
theorem cert_e1211550300934 : check e1211550300934 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left],[],[],[.under]] .identityHead = true := by decide
def e1211550346682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e1211550346682 : Closed e1211550346682 ∧ code e1211550346682 = 5609596857786 := by decide
def e1211550346714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e1211550346714 : Closed e1211550346714 ∧ code e1211550346714 = 5609596857818 := by decide
def e1211550346938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e1211550346938 : Closed e1211550346938 ∧ code e1211550346938 = 5609596858042 := by decide
def e1211550346986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e1211550346986 : Closed e1211550346986 ∧ code e1211550346986 = 5609596858090 := by decide
private def t_e1211550346986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem cert_e1211550346986 : ¬ IsSelfInterpreter e1211550346986 :=
  wSource (t := t_e1211550346986) (replay_sound (ps := []) (t := e1211550346986) (by decide)) (by decide)
def e1211550347098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e1211550347098 : Closed e1211550347098 ∧ code e1211550347098 = 5609596858202 := by decide
def e1211550347114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e1211550347114 : Closed e1211550347114 ∧ code e1211550347114 = 5609596858218 := by decide
private def t_e1211550347114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem cert_e1211550347114 : ¬ IsSelfInterpreter e1211550347114 :=
  wSource (t := t_e1211550347114) (replay_sound (ps := []) (t := e1211550347114) (by decide)) (by decide)
def e1211550347746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.lam (.var 0)))))
theorem wire_e1211550347746 : Closed e1211550347746 ∧ code e1211550347746 = 5609596858850 := by decide
theorem cert_e1211550347746 : check e1211550347746 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1211550348218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e1211550348218 : Closed e1211550348218 ∧ code e1211550348218 = 5609596859322 := by decide
def e1211550348250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e1211550348250 : Closed e1211550348250 ∧ code e1211550348250 = 5609596859354 := by decide
def e1211550349062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550349062 : Closed e1211550349062 ∧ code e1211550349062 = 5609596860166 := by decide
theorem cert_e1211550349062 : check e1211550349062 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e1211550349754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e1211550349754 : Closed e1211550349754 ∧ code e1211550349754 = 5609596860858 := by decide
def e1211550349802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e1211550349802 : Closed e1211550349802 ∧ code e1211550349802 = 5609596860906 := by decide
def e1211550350434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.lam (.var 0)))))
theorem wire_e1211550350434 : Closed e1211550350434 ∧ code e1211550350434 = 5609596861538 := by decide
theorem cert_e1211550350434 : check e1211550350434 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1211550350554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e1211550350554 : Closed e1211550350554 ∧ code e1211550350554 = 5609596861658 := by decide
def e1211550350570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e1211550350570 : Closed e1211550350570 ∧ code e1211550350570 = 5609596861674 := by decide
def e1211550350598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.var 1))))))
theorem wire_e1211550350598 : Closed e1211550350598 ∧ code e1211550350598 = 5609596861702 := by decide
theorem cert_e1211550350598 : check e1211550350598 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e1211550373594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))) (.var 0))))
theorem wire_e1211550373594 : Closed e1211550373594 ∧ code e1211550373594 = 5609596884698 := by decide
def e1211550373722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e1211550373722 : Closed e1211550373722 ∧ code e1211550373722 = 5609596884826 := by decide
def e1211550373738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e1211550373738 : Closed e1211550373738 ∧ code e1211550373738 = 5609596884842 := by decide
private def t_e1211550373738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 0))))
theorem cert_e1211550373738 : ¬ IsSelfInterpreter e1211550373738 :=
  wSource (t := t_e1211550373738) (replay_sound (ps := []) (t := e1211550373738) (by decide)) (by decide)
def e1211550374114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.lam (.var 0)))))
theorem wire_e1211550374114 : Closed e1211550374114 ∧ code e1211550374114 = 5609596885218 := by decide
theorem cert_e1211550374114 : check e1211550374114 [[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left]] .chain = true := by decide
end Blc.Floor42
