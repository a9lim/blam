import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211288194670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211288194670 : Closed e1211288194670 ∧ code e1211288194670 = 5609334705774 := by decide
theorem cert_e1211288194670 : check e1211288194670 [[],[]] .sourceHead = true := by decide
def e1211288194682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211288194682 : Closed e1211288194682 ∧ code e1211288194682 = 5609334705786 := by decide
theorem cert_e1211288194682 : check e1211288194682 [[],[]] .sourceHead = true := by decide
def e1211288194870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211288194870 : Closed e1211288194870 ∧ code e1211288194870 = 5609334705974 := by decide
theorem cert_e1211288194870 : check e1211288194870 [[],[]] .sourceHead = true := by decide
def e1211288194874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211288194874 : Closed e1211288194874 ∧ code e1211288194874 = 5609334705978 := by decide
theorem cert_e1211288194874 : check e1211288194874 [[],[]] .sourceHead = true := by decide
def e1211288792542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211288792542 : Closed e1211288792542 ∧ code e1211288792542 = 5609335303646 := by decide
theorem cert_e1211288792542 : check e1211288792542 [[],[]] .sourceHead = true := by decide
def e1211288792558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211288792558 : Closed e1211288792558 ∧ code e1211288792558 = 5609335303662 := by decide
theorem cert_e1211288792558 : check e1211288792558 [[],[]] .sourceHead = true := by decide
def e1211288792926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211288792926 : Closed e1211288792926 ∧ code e1211288792926 = 5609335304030 := by decide
theorem cert_e1211288792926 : check e1211288792926 [[],[]] .sourceHead = true := by decide
def e1211288792954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211288792954 : Closed e1211288792954 ∧ code e1211288792954 = 5609335304058 := by decide
theorem cert_e1211288792954 : check e1211288792954 [[],[]] .sourceHead = true := by decide
def e1211288793006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211288793006 : Closed e1211288793006 ∧ code e1211288793006 = 5609335304110 := by decide
theorem cert_e1211288793006 : check e1211288793006 [[],[]] .sourceHead = true := by decide
def e1211288793018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211288793018 : Closed e1211288793018 ∧ code e1211288793018 = 5609335304122 := by decide
theorem cert_e1211288793018 : check e1211288793018 [[],[]] .sourceHead = true := by decide
def e1211288794078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211288794078 : Closed e1211288794078 ∧ code e1211288794078 = 5609335305182 := by decide
theorem cert_e1211288794078 : check e1211288794078 [[],[]] .sourceHead = true := by decide
def e1211288794094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211288794094 : Closed e1211288794094 ∧ code e1211288794094 = 5609335305198 := by decide
theorem cert_e1211288794094 : check e1211288794094 [[],[]] .sourceHead = true := by decide
def e1211288796382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211288796382 : Closed e1211288796382 ∧ code e1211288796382 = 5609335307486 := by decide
theorem cert_e1211288796382 : check e1211288796382 [[],[]] .sourceHead = true := by decide
def e1211288796410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211288796410 : Closed e1211288796410 ∧ code e1211288796410 = 5609335307514 := by decide
theorem cert_e1211288796410 : check e1211288796410 [[],[]] .sourceHead = true := by decide
def e1211288796782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211288796782 : Closed e1211288796782 ∧ code e1211288796782 = 5609335307886 := by decide
theorem cert_e1211288796782 : check e1211288796782 [[],[]] .sourceHead = true := by decide
def e1211288796794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211288796794 : Closed e1211288796794 ∧ code e1211288796794 = 5609335307898 := by decide
theorem cert_e1211288796794 : check e1211288796794 [[],[]] .sourceHead = true := by decide
def e1211288825198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211288825198 : Closed e1211288825198 ∧ code e1211288825198 = 5609335336302 := by decide
theorem cert_e1211288825198 : check e1211288825198 [[],[]] .sourceHead = true := by decide
def e1211288825206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211288825206 : Closed e1211288825206 ∧ code e1211288825206 = 5609335336310 := by decide
theorem cert_e1211288825206 : check e1211288825206 [[],[]] .sourceHead = true := by decide
def e1211288825262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211288825262 : Closed e1211288825262 ∧ code e1211288825262 = 5609335336366 := by decide
theorem cert_e1211288825262 : check e1211288825262 [[],[]] .sourceHead = true := by decide
def e1211288825274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211288825274 : Closed e1211288825274 ∧ code e1211288825274 = 5609335336378 := by decide
theorem cert_e1211288825274 : check e1211288825274 [[],[]] .sourceHead = true := by decide
def e1211288825302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211288825302 : Closed e1211288825302 ∧ code e1211288825302 = 5609335336406 := by decide
theorem cert_e1211288825302 : check e1211288825302 [[],[]] .sourceHead = true := by decide
def e1211288825306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211288825306 : Closed e1211288825306 ∧ code e1211288825306 = 5609335336410 := by decide
theorem cert_e1211288825306 : check e1211288825306 [[],[]] .sourceHead = true := by decide
def e1211288825518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211288825518 : Closed e1211288825518 ∧ code e1211288825518 = 5609335336622 := by decide
theorem cert_e1211288825518 : check e1211288825518 [[],[]] .sourceHead = true := by decide
def e1211288825530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211288825530 : Closed e1211288825530 ∧ code e1211288825530 = 5609335336634 := by decide
theorem cert_e1211288825530 : check e1211288825530 [[],[]] .sourceHead = true := by decide
def e1211288825578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211288825578 : Closed e1211288825578 ∧ code e1211288825578 = 5609335336682 := by decide
theorem cert_e1211288825578 : check e1211288825578 [[],[]] .sourceHead = true := by decide
def e1211288825686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211288825686 : Closed e1211288825686 ∧ code e1211288825686 = 5609335336790 := by decide
theorem cert_e1211288825686 : check e1211288825686 [[],[]] .sourceHead = true := by decide
def e1211288825690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211288825690 : Closed e1211288825690 ∧ code e1211288825690 = 5609335336794 := by decide
theorem cert_e1211288825690 : check e1211288825690 [[],[]] .sourceHead = true := by decide
def e1211288825706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211288825706 : Closed e1211288825706 ∧ code e1211288825706 = 5609335336810 := by decide
theorem cert_e1211288825706 : check e1211288825706 [[],[]] .sourceHead = true := by decide
def e1211288826734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211288826734 : Closed e1211288826734 ∧ code e1211288826734 = 5609335337838 := by decide
theorem cert_e1211288826734 : check e1211288826734 [[],[]] .sourceHead = true := by decide
def e1211288826742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211288826742 : Closed e1211288826742 ∧ code e1211288826742 = 5609335337846 := by decide
theorem cert_e1211288826742 : check e1211288826742 [[],[]] .sourceHead = true := by decide
def e1211288826798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211288826798 : Closed e1211288826798 ∧ code e1211288826798 = 5609335337902 := by decide
theorem cert_e1211288826798 : check e1211288826798 [[],[]] .sourceHead = true := by decide
def e1211288826810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211288826810 : Closed e1211288826810 ∧ code e1211288826810 = 5609335337914 := by decide
theorem cert_e1211288826810 : check e1211288826810 [[],[]] .sourceHead = true := by decide
def e1211288826838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211288826838 : Closed e1211288826838 ∧ code e1211288826838 = 5609335337942 := by decide
theorem cert_e1211288826838 : check e1211288826838 [[],[]] .sourceHead = true := by decide
def e1211288826842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211288826842 : Closed e1211288826842 ∧ code e1211288826842 = 5609335337946 := by decide
theorem cert_e1211288826842 : check e1211288826842 [[],[]] .sourceHead = true := by decide
def e1211288827118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211288827118 : Closed e1211288827118 ∧ code e1211288827118 = 5609335338222 := by decide
theorem cert_e1211288827118 : check e1211288827118 [[],[]] .sourceHead = true := by decide
def e1211288827126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211288827126 : Closed e1211288827126 ∧ code e1211288827126 = 5609335338230 := by decide
theorem cert_e1211288827126 : check e1211288827126 [[],[]] .sourceHead = true := by decide
def e1211288827502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211288827502 : Closed e1211288827502 ∧ code e1211288827502 = 5609335338606 := by decide
theorem cert_e1211288827502 : check e1211288827502 [[],[]] .sourceHead = true := by decide
def e1211288827514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211288827514 : Closed e1211288827514 ∧ code e1211288827514 = 5609335338618 := by decide
theorem cert_e1211288827514 : check e1211288827514 [[],[]] .sourceHead = true := by decide
def e1211288827702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211288827702 : Closed e1211288827702 ∧ code e1211288827702 = 5609335338806 := by decide
theorem cert_e1211288827702 : check e1211288827702 [[],[]] .sourceHead = true := by decide
def e1211288827706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211288827706 : Closed e1211288827706 ∧ code e1211288827706 = 5609335338810 := by decide
theorem cert_e1211288827706 : check e1211288827706 [[],[]] .sourceHead = true := by decide
def e1211288828334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211288828334 : Closed e1211288828334 ∧ code e1211288828334 = 5609335339438 := by decide
theorem cert_e1211288828334 : check e1211288828334 [[],[]] .sourceHead = true := by decide
def e1211288828346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211288828346 : Closed e1211288828346 ∧ code e1211288828346 = 5609335339450 := by decide
theorem cert_e1211288828346 : check e1211288828346 [[],[]] .sourceHead = true := by decide
def e1211288828394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211288828394 : Closed e1211288828394 ∧ code e1211288828394 = 5609335339498 := by decide
theorem cert_e1211288828394 : check e1211288828394 [[],[]] .sourceHead = true := by decide
def e1211288828526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211288828526 : Closed e1211288828526 ∧ code e1211288828526 = 5609335339630 := by decide
theorem cert_e1211288828526 : check e1211288828526 [[],[]] .sourceHead = true := by decide
def e1211288828538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211288828538 : Closed e1211288828538 ∧ code e1211288828538 = 5609335339642 := by decide
theorem cert_e1211288828538 : check e1211288828538 [[],[]] .sourceHead = true := by decide
def e1211288828826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211288828826 : Closed e1211288828826 ∧ code e1211288828826 = 5609335339930 := by decide
theorem cert_e1211288828826 : check e1211288828826 [[],[]] .sourceHead = true := by decide
def e1211288829142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211288829142 : Closed e1211288829142 ∧ code e1211288829142 = 5609335340246 := by decide
theorem cert_e1211288829142 : check e1211288829142 [[],[]] .sourceHead = true := by decide
def e1211288829146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211288829146 : Closed e1211288829146 ∧ code e1211288829146 = 5609335340250 := by decide
theorem cert_e1211288829146 : check e1211288829146 [[],[]] .sourceHead = true := by decide
def e1211288829162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211288829162 : Closed e1211288829162 ∧ code e1211288829162 = 5609335340266 := by decide
theorem cert_e1211288829162 : check e1211288829162 [[],[]] .sourceHead = true := by decide
def e1211288829238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211288829238 : Closed e1211288829238 ∧ code e1211288829238 = 5609335340342 := by decide
theorem cert_e1211288829238 : check e1211288829238 [[],[]] .sourceHead = true := by decide
def e1211288829242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211288829242 : Closed e1211288829242 ∧ code e1211288829242 = 5609335340346 := by decide
theorem cert_e1211288829242 : check e1211288829242 [[],[]] .sourceHead = true := by decide
def e1211288829338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211288829338 : Closed e1211288829338 ∧ code e1211288829338 = 5609335340442 := by decide
theorem cert_e1211288829338 : check e1211288829338 [[],[]] .sourceHead = true := by decide
def e1211288830942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211288830942 : Closed e1211288830942 ∧ code e1211288830942 = 5609335342046 := by decide
theorem cert_e1211288830942 : check e1211288830942 [[],[]] .sourceHead = true := by decide
def e1211288830958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211288830958 : Closed e1211288830958 ∧ code e1211288830958 = 5609335342062 := by decide
theorem cert_e1211288830958 : check e1211288830958 [[],[]] .sourceHead = true := by decide
def e1211288832878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211288832878 : Closed e1211288832878 ∧ code e1211288832878 = 5609335343982 := by decide
theorem cert_e1211288832878 : check e1211288832878 [[],[]] .sourceHead = true := by decide
def e1211288832886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211288832886 : Closed e1211288832886 ∧ code e1211288832886 = 5609335343990 := by decide
theorem cert_e1211288832886 : check e1211288832886 [[],[]] .sourceHead = true := by decide
def e1211288832942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211288832942 : Closed e1211288832942 ∧ code e1211288832942 = 5609335344046 := by decide
theorem cert_e1211288832942 : check e1211288832942 [[],[]] .sourceHead = true := by decide
def e1211288832954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211288832954 : Closed e1211288832954 ∧ code e1211288832954 = 5609335344058 := by decide
theorem cert_e1211288832954 : check e1211288832954 [[],[]] .sourceHead = true := by decide
def e1211288832982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211288832982 : Closed e1211288832982 ∧ code e1211288832982 = 5609335344086 := by decide
theorem cert_e1211288832982 : check e1211288832982 [[],[]] .sourceHead = true := by decide
def e1211288832986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211288832986 : Closed e1211288832986 ∧ code e1211288832986 = 5609335344090 := by decide
theorem cert_e1211288832986 : check e1211288832986 [[],[]] .sourceHead = true := by decide
def e1211288833262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211288833262 : Closed e1211288833262 ∧ code e1211288833262 = 5609335344366 := by decide
theorem cert_e1211288833262 : check e1211288833262 [[],[]] .sourceHead = true := by decide
def e1211288833270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211288833270 : Closed e1211288833270 ∧ code e1211288833270 = 5609335344374 := by decide
theorem cert_e1211288833270 : check e1211288833270 [[],[]] .sourceHead = true := by decide
def e1211288833646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211288833646 : Closed e1211288833646 ∧ code e1211288833646 = 5609335344750 := by decide
theorem cert_e1211288833646 : check e1211288833646 [[],[]] .sourceHead = true := by decide
def e1211288833658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211288833658 : Closed e1211288833658 ∧ code e1211288833658 = 5609335344762 := by decide
theorem cert_e1211288833658 : check e1211288833658 [[],[]] .sourceHead = true := by decide
def e1211288833846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211288833846 : Closed e1211288833846 ∧ code e1211288833846 = 5609335344950 := by decide
theorem cert_e1211288833846 : check e1211288833846 [[],[]] .sourceHead = true := by decide
def e1211288833850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211288833850 : Closed e1211288833850 ∧ code e1211288833850 = 5609335344954 := by decide
theorem cert_e1211288833850 : check e1211288833850 [[],[]] .sourceHead = true := by decide
def e1211288838622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211288838622 : Closed e1211288838622 ∧ code e1211288838622 = 5609335349726 := by decide
theorem cert_e1211288838622 : check e1211288838622 [[],[]] .sourceHead = true := by decide
def e1211288838646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211288838646 : Closed e1211288838646 ∧ code e1211288838646 = 5609335349750 := by decide
theorem cert_e1211288838646 : check e1211288838646 [[],[]] .sourceHead = true := by decide
def e1211288839598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211288839598 : Closed e1211288839598 ∧ code e1211288839598 = 5609335350702 := by decide
theorem cert_e1211288839598 : check e1211288839598 [[],[]] .sourceHead = true := by decide
def e1211288839610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211288839610 : Closed e1211288839610 ∧ code e1211288839610 = 5609335350714 := by decide
theorem cert_e1211288839610 : check e1211288839610 [[],[]] .sourceHead = true := by decide
def e1211288839658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211288839658 : Closed e1211288839658 ∧ code e1211288839658 = 5609335350762 := by decide
theorem cert_e1211288839658 : check e1211288839658 [[],[]] .sourceHead = true := by decide
def e1211288839790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211288839790 : Closed e1211288839790 ∧ code e1211288839790 = 5609335350894 := by decide
theorem cert_e1211288839790 : check e1211288839790 [[],[]] .sourceHead = true := by decide
def e1211288839802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211288839802 : Closed e1211288839802 ∧ code e1211288839802 = 5609335350906 := by decide
theorem cert_e1211288839802 : check e1211288839802 [[],[]] .sourceHead = true := by decide
def e1211288840090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211288840090 : Closed e1211288840090 ∧ code e1211288840090 = 5609335351194 := by decide
theorem cert_e1211288840090 : check e1211288840090 [[],[]] .sourceHead = true := by decide
def e1211288842478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211288842478 : Closed e1211288842478 ∧ code e1211288842478 = 5609335353582 := by decide
theorem cert_e1211288842478 : check e1211288842478 [[],[]] .sourceHead = true := by decide
def e1211288842486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211288842486 : Closed e1211288842486 ∧ code e1211288842486 = 5609335353590 := by decide
theorem cert_e1211288842486 : check e1211288842486 [[],[]] .sourceHead = true := by decide
def e1211288842966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211288842966 : Closed e1211288842966 ∧ code e1211288842966 = 5609335354070 := by decide
theorem cert_e1211288842966 : check e1211288842966 [[],[]] .sourceHead = true := by decide
def e1211288842970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211288842970 : Closed e1211288842970 ∧ code e1211288842970 = 5609335354074 := by decide
theorem cert_e1211288842970 : check e1211288842970 [[],[]] .sourceHead = true := by decide
def e1211288842986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211288842986 : Closed e1211288842986 ∧ code e1211288842986 = 5609335354090 := by decide
theorem cert_e1211288842986 : check e1211288842986 [[],[]] .sourceHead = true := by decide
def e1211288843062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211288843062 : Closed e1211288843062 ∧ code e1211288843062 = 5609335354166 := by decide
theorem cert_e1211288843062 : check e1211288843062 [[],[]] .sourceHead = true := by decide
def e1211288843066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211288843066 : Closed e1211288843066 ∧ code e1211288843066 = 5609335354170 := by decide
theorem cert_e1211288843066 : check e1211288843066 [[],[]] .sourceHead = true := by decide
def e1211288843162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211288843162 : Closed e1211288843162 ∧ code e1211288843162 = 5609335354266 := by decide
theorem cert_e1211288843162 : check e1211288843162 [[],[]] .sourceHead = true := by decide
def e1211288980334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211288980334 : Closed e1211288980334 ∧ code e1211288980334 = 5609335491438 := by decide
theorem cert_e1211288980334 : check e1211288980334 [[],[]] .sourceHead = true := by decide
def e1211288980342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211288980342 : Closed e1211288980342 ∧ code e1211288980342 = 5609335491446 := by decide
theorem cert_e1211288980342 : check e1211288980342 [[],[]] .sourceHead = true := by decide
def e1211288980398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211288980398 : Closed e1211288980398 ∧ code e1211288980398 = 5609335491502 := by decide
theorem cert_e1211288980398 : check e1211288980398 [[],[]] .sourceHead = true := by decide
def e1211288980410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211288980410 : Closed e1211288980410 ∧ code e1211288980410 = 5609335491514 := by decide
theorem cert_e1211288980410 : check e1211288980410 [[],[]] .sourceHead = true := by decide
def e1211288980438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211288980438 : Closed e1211288980438 ∧ code e1211288980438 = 5609335491542 := by decide
theorem cert_e1211288980438 : check e1211288980438 [[],[]] .sourceHead = true := by decide
def e1211288980442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211288980442 : Closed e1211288980442 ∧ code e1211288980442 = 5609335491546 := by decide
theorem cert_e1211288980442 : check e1211288980442 [[],[]] .sourceHead = true := by decide
def e1211288980718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211288980718 : Closed e1211288980718 ∧ code e1211288980718 = 5609335491822 := by decide
theorem cert_e1211288980718 : check e1211288980718 [[],[]] .sourceHead = true := by decide
def e1211288980726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211288980726 : Closed e1211288980726 ∧ code e1211288980726 = 5609335491830 := by decide
theorem cert_e1211288980726 : check e1211288980726 [[],[]] .sourceHead = true := by decide
def e1211288981102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211288981102 : Closed e1211288981102 ∧ code e1211288981102 = 5609335492206 := by decide
theorem cert_e1211288981102 : check e1211288981102 [[],[]] .sourceHead = true := by decide
def e1211288981114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211288981114 : Closed e1211288981114 ∧ code e1211288981114 = 5609335492218 := by decide
theorem cert_e1211288981114 : check e1211288981114 [[],[]] .sourceHead = true := by decide
def e1211288981302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211288981302 : Closed e1211288981302 ∧ code e1211288981302 = 5609335492406 := by decide
theorem cert_e1211288981302 : check e1211288981302 [[],[]] .sourceHead = true := by decide
def e1211288981306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211288981306 : Closed e1211288981306 ∧ code e1211288981306 = 5609335492410 := by decide
theorem cert_e1211288981306 : check e1211288981306 [[],[]] .sourceHead = true := by decide
def e1211298262382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211298262382 : Closed e1211298262382 ∧ code e1211298262382 = 5609344773486 := by decide
theorem cert_e1211298262382 : check e1211298262382 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211298262390 : Closed e1211298262390 ∧ code e1211298262390 = 5609344773494 := by decide
theorem cert_e1211298262390 : check e1211298262390 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211298262446 : Closed e1211298262446 ∧ code e1211298262446 = 5609344773550 := by decide
theorem cert_e1211298262446 : check e1211298262446 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211298262458 : Closed e1211298262458 ∧ code e1211298262458 = 5609344773562 := by decide
theorem cert_e1211298262458 : check e1211298262458 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211298262486 : Closed e1211298262486 ∧ code e1211298262486 = 5609344773590 := by decide
theorem cert_e1211298262486 : check e1211298262486 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211298262490 : Closed e1211298262490 ∧ code e1211298262490 = 5609344773594 := by decide
theorem cert_e1211298262490 : check e1211298262490 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e1211298262702 : Closed e1211298262702 ∧ code e1211298262702 = 5609344773806 := by decide
theorem cert_e1211298262702 : check e1211298262702 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e1211298262714 : Closed e1211298262714 ∧ code e1211298262714 = 5609344773818 := by decide
theorem cert_e1211298262714 : check e1211298262714 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e1211298262762 : Closed e1211298262762 ∧ code e1211298262762 = 5609344773866 := by decide
theorem cert_e1211298262762 : check e1211298262762 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211298262870 : Closed e1211298262870 ∧ code e1211298262870 = 5609344773974 := by decide
theorem cert_e1211298262870 : check e1211298262870 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211298262874 : Closed e1211298262874 ∧ code e1211298262874 = 5609344773978 := by decide
theorem cert_e1211298262874 : check e1211298262874 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298262890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211298262890 : Closed e1211298262890 ∧ code e1211298262890 = 5609344773994 := by decide
theorem cert_e1211298262890 : check e1211298262890 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298263918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211298263918 : Closed e1211298263918 ∧ code e1211298263918 = 5609344775022 := by decide
theorem cert_e1211298263918 : check e1211298263918 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298263926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211298263926 : Closed e1211298263926 ∧ code e1211298263926 = 5609344775030 := by decide
theorem cert_e1211298263926 : check e1211298263926 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298263982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211298263982 : Closed e1211298263982 ∧ code e1211298263982 = 5609344775086 := by decide
theorem cert_e1211298263982 : check e1211298263982 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298263994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211298263994 : Closed e1211298263994 ∧ code e1211298263994 = 5609344775098 := by decide
theorem cert_e1211298263994 : check e1211298263994 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211298264022 : Closed e1211298264022 ∧ code e1211298264022 = 5609344775126 := by decide
theorem cert_e1211298264022 : check e1211298264022 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211298264026 : Closed e1211298264026 ∧ code e1211298264026 = 5609344775130 := by decide
theorem cert_e1211298264026 : check e1211298264026 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211298264302 : Closed e1211298264302 ∧ code e1211298264302 = 5609344775406 := by decide
theorem cert_e1211298264302 : check e1211298264302 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211298264310 : Closed e1211298264310 ∧ code e1211298264310 = 5609344775414 := by decide
theorem cert_e1211298264310 : check e1211298264310 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211298264686 : Closed e1211298264686 ∧ code e1211298264686 = 5609344775790 := by decide
theorem cert_e1211298264686 : check e1211298264686 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211298264698 : Closed e1211298264698 ∧ code e1211298264698 = 5609344775802 := by decide
theorem cert_e1211298264698 : check e1211298264698 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211298264886 : Closed e1211298264886 ∧ code e1211298264886 = 5609344775990 := by decide
theorem cert_e1211298264886 : check e1211298264886 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298264890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211298264890 : Closed e1211298264890 ∧ code e1211298264890 = 5609344775994 := by decide
theorem cert_e1211298264890 : check e1211298264890 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))))))
theorem wire_e1211298265022 : Closed e1211298265022 ∧ code e1211298265022 = 5609344776126 := by decide
theorem cert_e1211298265022 : check e1211298265022 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 3)))))))))
theorem wire_e1211298265054 : Closed e1211298265054 ∧ code e1211298265054 = 5609344776158 := by decide
theorem cert_e1211298265054 : check e1211298265054 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e1211298265518 : Closed e1211298265518 ∧ code e1211298265518 = 5609344776622 := by decide
theorem cert_e1211298265518 : check e1211298265518 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e1211298265530 : Closed e1211298265530 ∧ code e1211298265530 = 5609344776634 := by decide
theorem cert_e1211298265530 : check e1211298265530 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e1211298265578 : Closed e1211298265578 ∧ code e1211298265578 = 5609344776682 := by decide
theorem cert_e1211298265578 : check e1211298265578 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211298265710 : Closed e1211298265710 ∧ code e1211298265710 = 5609344776814 := by decide
theorem cert_e1211298265710 : check e1211298265710 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298265722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211298265722 : Closed e1211298265722 ∧ code e1211298265722 = 5609344776826 := by decide
theorem cert_e1211298265722 : check e1211298265722 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211298266010 : Closed e1211298266010 ∧ code e1211298266010 = 5609344777114 := by decide
theorem cert_e1211298266010 : check e1211298266010 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e1211298266046 : Closed e1211298266046 ∧ code e1211298266046 = 5609344777150 := by decide
theorem cert_e1211298266046 : check e1211298266046 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e1211298266094 : Closed e1211298266094 ∧ code e1211298266094 = 5609344777198 := by decide
theorem cert_e1211298266094 : check e1211298266094 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211298266326 : Closed e1211298266326 ∧ code e1211298266326 = 5609344777430 := by decide
theorem cert_e1211298266326 : check e1211298266326 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211298266330 : Closed e1211298266330 ∧ code e1211298266330 = 5609344777434 := by decide
theorem cert_e1211298266330 : check e1211298266330 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211298266346 : Closed e1211298266346 ∧ code e1211298266346 = 5609344777450 := by decide
theorem cert_e1211298266346 : check e1211298266346 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211298266422 : Closed e1211298266422 ∧ code e1211298266422 = 5609344777526 := by decide
theorem cert_e1211298266422 : check e1211298266422 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211298266426 : Closed e1211298266426 ∧ code e1211298266426 = 5609344777530 := by decide
theorem cert_e1211298266426 : check e1211298266426 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211298266522 : Closed e1211298266522 ∧ code e1211298266522 = 5609344777626 := by decide
theorem cert_e1211298266522 : check e1211298266522 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e1211298266558 : Closed e1211298266558 ∧ code e1211298266558 = 5609344777662 := by decide
theorem cert_e1211298266558 : check e1211298266558 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e1211298266614 : Closed e1211298266614 ∧ code e1211298266614 = 5609344777718 := by decide
private def t_e1211298266614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem cert_e1211298266614 : ¬ IsSelfInterpreter e1211298266614 :=
  wSource (t := t_e1211298266614) (replay_sound (ps := []) (t := e1211298266614) (by decide)) (by decide)
def e1211298266814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))))))
theorem wire_e1211298266814 : Closed e1211298266814 ∧ code e1211298266814 = 5609344777918 := by decide
theorem cert_e1211298266814 : check e1211298266814 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem wire_e1211298266874 : Closed e1211298266874 ∧ code e1211298266874 = 5609344777978 := by decide
theorem cert_e1211298266874 : check e1211298266874 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 3)))))))))
theorem wire_e1211298266974 : Closed e1211298266974 ∧ code e1211298266974 = 5609344778078 := by decide
theorem cert_e1211298266974 : check e1211298266974 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e1211298266990 : Closed e1211298266990 ∧ code e1211298266990 = 5609344778094 := by decide
theorem cert_e1211298266990 : check e1211298266990 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298266998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e1211298266998 : Closed e1211298266998 ∧ code e1211298266998 = 5609344778102 := by decide
private def t_e1211298266998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem cert_e1211298266998 : ¬ IsSelfInterpreter e1211298266998 :=
  wSource (t := t_e1211298266998) (replay_sound (ps := []) (t := e1211298266998) (by decide)) (by decide)
def e1211298267002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem wire_e1211298267002 : Closed e1211298267002 ∧ code e1211298267002 = 5609344778106 := by decide
theorem cert_e1211298267002 : check e1211298267002 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211298270062 : Closed e1211298270062 ∧ code e1211298270062 = 5609344781166 := by decide
theorem cert_e1211298270062 : check e1211298270062 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211298270070 : Closed e1211298270070 ∧ code e1211298270070 = 5609344781174 := by decide
theorem cert_e1211298270070 : check e1211298270070 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211298270126 : Closed e1211298270126 ∧ code e1211298270126 = 5609344781230 := by decide
theorem cert_e1211298270126 : check e1211298270126 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211298270138 : Closed e1211298270138 ∧ code e1211298270138 = 5609344781242 := by decide
theorem cert_e1211298270138 : check e1211298270138 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211298270166 : Closed e1211298270166 ∧ code e1211298270166 = 5609344781270 := by decide
theorem cert_e1211298270166 : check e1211298270166 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211298270170 : Closed e1211298270170 ∧ code e1211298270170 = 5609344781274 := by decide
theorem cert_e1211298270170 : check e1211298270170 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211298270446 : Closed e1211298270446 ∧ code e1211298270446 = 5609344781550 := by decide
theorem cert_e1211298270446 : check e1211298270446 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211298270454 : Closed e1211298270454 ∧ code e1211298270454 = 5609344781558 := by decide
theorem cert_e1211298270454 : check e1211298270454 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211298270830 : Closed e1211298270830 ∧ code e1211298270830 = 5609344781934 := by decide
theorem cert_e1211298270830 : check e1211298270830 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298270842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211298270842 : Closed e1211298270842 ∧ code e1211298270842 = 5609344781946 := by decide
theorem cert_e1211298270842 : check e1211298270842 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298271030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211298271030 : Closed e1211298271030 ∧ code e1211298271030 = 5609344782134 := by decide
theorem cert_e1211298271030 : check e1211298271030 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298271034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211298271034 : Closed e1211298271034 ∧ code e1211298271034 = 5609344782138 := by decide
theorem cert_e1211298271034 : check e1211298271034 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298271166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 4))))))))))
theorem wire_e1211298271166 : Closed e1211298271166 ∧ code e1211298271166 = 5609344782270 := by decide
theorem cert_e1211298271166 : check e1211298271166 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298271198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 3))))))))))
theorem wire_e1211298271198 : Closed e1211298271198 ∧ code e1211298271198 = 5609344782302 := by decide
theorem cert_e1211298271198 : check e1211298271198 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298276782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211298276782 : Closed e1211298276782 ∧ code e1211298276782 = 5609344787886 := by decide
theorem cert_e1211298276782 : check e1211298276782 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298276794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211298276794 : Closed e1211298276794 ∧ code e1211298276794 = 5609344787898 := by decide
theorem cert_e1211298276794 : check e1211298276794 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298276842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211298276842 : Closed e1211298276842 ∧ code e1211298276842 = 5609344787946 := by decide
theorem cert_e1211298276842 : check e1211298276842 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298276974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211298276974 : Closed e1211298276974 ∧ code e1211298276974 = 5609344788078 := by decide
theorem cert_e1211298276974 : check e1211298276974 [[],[],[.under],[.under,.under]] .three = true := by decide
end Blc.Floor42
