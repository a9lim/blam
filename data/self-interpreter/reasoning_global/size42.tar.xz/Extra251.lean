import Batch251
import ExtraBase
namespace Blc.Floor42.Extra251
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211299056558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem ex_e1211299056558 : ¬ IsSelfInterpreter e1211299056558 := by
  intro he
  have hp := replay_sound (t := (.app e1211299056558 churchTrue)) (u := t_e1211299056558) (ps := [[.left],[.left],[],[.right,.under,.right,.right,.left],[.right,.under,.right,.right],[]]) (by decide)
  apply specialized_not_so he hp
  exact (so_closed_lam (by decide) (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0)))) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))) (r := (.var 0)) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 0)) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))))))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299056558
private def t_e1211299056570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem ex_e1211299056570 : ¬ IsSelfInterpreter e1211299056570 := by
  intro he
  have hp := replay_sound (t := e1211299056570) (u := t_e1211299056570) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299056570
private def t_e1211299056602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem ex_e1211299056602 : ¬ IsSelfInterpreter e1211299056602 := by
  intro he
  have hp := replay_sound (t := e1211299056602) (u := t_e1211299056602) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299056602
private def t_e1211299056878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem ex_e1211299056878 : ¬ IsSelfInterpreter e1211299056878 := by
  intro he
  have hp := replay_sound (t := e1211299056878) (u := t_e1211299056878) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299056878
private def t_e1211299056886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem ex_e1211299056886 : ¬ IsSelfInterpreter e1211299056886 := by
  intro he
  have hp := replay_sound (t := e1211299056886) (u := t_e1211299056886) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299056886
private def t_e1211299063274 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))) (.var 0)) (.var 0)))))))
theorem ex_e1211299063274 : ¬ IsSelfInterpreter e1211299063274 := by
  intro he
  have hp := replay_sound (t := (.app e1211299063274 churchTrue)) (u := t_e1211299063274) (ps := [[.left],[.left],[],[.right,.under,.right],[.right,.under,.right,.under,.left],[.right,.under,.right,.under],[]]) (by decide)
  apply specialized_not_so he hp
  exact (so_closed_lam (by decide) (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))) (r := (.var 1)) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.app (SO.app (SO.var 2) (SO.var 0)) (SO.var 0)))) (SO.var 1) (by decide) (by rfl)))))) (SO.lam (g := (.app (.var 0) (.app (.var 1) (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))) (.var 0)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (so_dead (by decide) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))) (r := (.var 1)) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.app (SO.app (SO.var 2) (SO.var 0)) (SO.var 0)))) (SO.var 1) (by decide) (by rfl)))))) (SO.var 0)) (SO.var 0)))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1211299063274
private def t_e1211299066682 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.app (.var 0) (.lam (.lam (.var 0))))))) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))))) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.app (.var 0) (.lam (.lam (.var 0))))))) (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.app (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.app (.var 0) (.lam (.lam (.var 0))))))) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))))) (.lam (.lam (.var 0))))) (.app (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.app (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.app (.var 0) (.lam (.lam (.var 0))))))) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))))) (.lam (.lam (.var 0))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))) (.var 0))))))
theorem ex_e1211299066682 : ¬ IsSelfInterpreter e1211299066682 := by
  intro he
  have hp := replay_sound (t := (call e1211299066682 (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := t_e1211299066682) (ps := [[.left,.left],[.left,.left],[.left],[.left,.right,.under,.right,.right,.right],[.left],[],[.right,.under,.right,.right,.right],[],[],[.left],[],[.left],[.left],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := (.lam (.var 0))) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := Layouts.mismatch_sound 12 hr (by decide)
  exact (by decide : ¬ Layouts.mismatch 12 t_e1211299066682 (.lam (.var 0)) = false) hz
#print axioms ex_e1211299066682
end Blc.Floor42.Extra251
