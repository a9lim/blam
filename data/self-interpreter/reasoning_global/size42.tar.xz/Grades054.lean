import Tables
import Batch054
namespace Blc.Floor42.Grades054
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1130567044054 : ¬ IsSelfInterpreter e1130567044054 := cutM12_2 (by decide)
#print axioms ex_e1130567044054
end Blc.Floor42.Grades054
