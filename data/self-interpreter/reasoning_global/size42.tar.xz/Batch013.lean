import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302819373934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e302819373934 : Closed e302819373934 ∧ code e302819373934 = 4700865885038 := by decide
theorem cert_e302819373934 : check e302819373934 [[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302819373998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e302819373998 : Closed e302819373998 ∧ code e302819373998 = 4700865885102 := by decide
theorem cert_e302819373998 : check e302819373998 [[.left],[.left],[.left],[],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302819773294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302819773294 : Closed e302819773294 ∧ code e302819773294 = 4700866284398 := by decide
theorem cert_e302819773294 : check e302819773294 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302819773302 : Closed e302819773302 ∧ code e302819773302 = 4700866284406 := by decide
theorem cert_e302819773302 : check e302819773302 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302819773358 : Closed e302819773358 ∧ code e302819773358 = 4700866284462 := by decide
theorem cert_e302819773358 : check e302819773358 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302819773370 : Closed e302819773370 ∧ code e302819773370 = 4700866284474 := by decide
theorem cert_e302819773370 : check e302819773370 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302819773398 : Closed e302819773398 ∧ code e302819773398 = 4700866284502 := by decide
theorem cert_e302819773398 : check e302819773398 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302819773402 : Closed e302819773402 ∧ code e302819773402 = 4700866284506 := by decide
theorem cert_e302819773402 : check e302819773402 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302819773678 : Closed e302819773678 ∧ code e302819773678 = 4700866284782 := by decide
theorem cert_e302819773678 : check e302819773678 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819773686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302819773686 : Closed e302819773686 ∧ code e302819773686 = 4700866284790 := by decide
theorem cert_e302819773686 : check e302819773686 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819774062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302819774062 : Closed e302819774062 ∧ code e302819774062 = 4700866285166 := by decide
theorem cert_e302819774062 : check e302819774062 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819774074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302819774074 : Closed e302819774074 ∧ code e302819774074 = 4700866285178 := by decide
theorem cert_e302819774074 : check e302819774074 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819774262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302819774262 : Closed e302819774262 ∧ code e302819774262 = 4700866285366 := by decide
theorem cert_e302819774262 : check e302819774262 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819774266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302819774266 : Closed e302819774266 ∧ code e302819774266 = 4700866285370 := by decide
theorem cert_e302819774266 : check e302819774266 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e302819859318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e302819859318 : Closed e302819859318 ∧ code e302819859318 = 4700866370422 := by decide
theorem cert_e302819859318 : checkPay e302819859318 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302819859382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e302819859382 : Closed e302819859382 ∧ code e302819859382 = 4700866370486 := by decide
theorem cert_e302819859382 : checkPay e302819859382 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302819859830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e302819859830 : Closed e302819859830 ∧ code e302819859830 = 4700866370934 := by decide
theorem cert_e302819859830 : checkPay e302819859830 [[.left],[.left],[.left],[]] 0 [[.under,.left]] = true := by decide
def e302819859926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e302819859926 : Closed e302819859926 ∧ code e302819859926 = 4700866371030 := by decide
theorem cert_e302819859926 : checkPay e302819859926 [[.left],[.left],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right,.under,.left],[.under,.left,.left,.right,.under,.left,.left],[.under,.left,.left,.right,.under,.left],[.under,.left,.left,.right,.under]] = true := by decide
def e302819860150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e302819860150 : Closed e302819860150 ∧ code e302819860150 = 4700866371254 := by decide
theorem cert_e302819860150 : checkPay e302819860150 [[.left],[.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e302819860182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e302819860182 : Closed e302819860182 ∧ code e302819860182 = 4700866371286 := by decide
theorem cert_e302819860182 : checkPay e302819860182 [[.left],[.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.left,.right,.under,.left]] = true := by decide
def e302819862390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e302819862390 : Closed e302819862390 ∧ code e302819862390 = 4700866373494 := by decide
theorem cert_e302819862390 : checkPay e302819862390 [[.left],[.left],[.left],[]] 0 [[.under,.right],[.under,.right,.left],[.under,.right],[.under,.right,.left,.right,.under,.right],[.under,.right,.left,.right,.under,.right,.left],[.under,.right,.left,.right,.under,.right]] = true := by decide
def e302819862454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e302819862454 : Closed e302819862454 ∧ code e302819862454 = 4700866373558 := by decide
theorem cert_e302819862454 : checkPay e302819862454 [[.left],[.left],[.left],[]] 0 [[.under,.right],[.under,.right,.under,.left,.right,.under,.right]] = true := by decide
def e302819865462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e302819865462 : Closed e302819865462 ∧ code e302819865462 = 4700866376566 := by decide
theorem cert_e302819865462 : checkPay e302819865462 [[.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e302819865558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e302819865558 : Closed e302819865558 ∧ code e302819865558 = 4700866376662 := by decide
theorem cert_e302819865558 : checkPay e302819865558 [[.left],[.left],[.left],[]] 0 [[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right,.under]] = true := by decide
def e302819867062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e302819867062 : Closed e302819867062 ∧ code e302819867062 = 4700866378166 := by decide
theorem cert_e302819867062 : checkPay e302819867062 [[.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e302819867094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e302819867094 : Closed e302819867094 ∧ code e302819867094 = 4700866378198 := by decide
theorem cert_e302819867094 : checkPay e302819867094 [[.left],[.left],[.left],[]] 0 [[.under],[.under,.under,.left,.right,.under,.left],[.under,.under,.right]] = true := by decide
def e302820035438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302820035438 : Closed e302820035438 ∧ code e302820035438 = 4700866546542 := by decide
theorem cert_e302820035438 : checkPay e302820035438 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302820035446 : Closed e302820035446 ∧ code e302820035446 = 4700866546550 := by decide
theorem cert_e302820035446 : checkPay e302820035446 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302820035502 : Closed e302820035502 ∧ code e302820035502 = 4700866546606 := by decide
theorem cert_e302820035502 : checkPay e302820035502 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302820035514 : Closed e302820035514 ∧ code e302820035514 = 4700866546618 := by decide
theorem cert_e302820035514 : checkPay e302820035514 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302820035542 : Closed e302820035542 ∧ code e302820035542 = 4700866546646 := by decide
theorem cert_e302820035542 : checkPay e302820035542 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302820035546 : Closed e302820035546 ∧ code e302820035546 = 4700866546650 := by decide
theorem cert_e302820035546 : checkPay e302820035546 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302820035822 : Closed e302820035822 ∧ code e302820035822 = 4700866546926 := by decide
theorem cert_e302820035822 : checkPay e302820035822 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820035830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302820035830 : Closed e302820035830 ∧ code e302820035830 = 4700866546934 := by decide
theorem cert_e302820035830 : checkPay e302820035830 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820036206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302820036206 : Closed e302820036206 ∧ code e302820036206 = 4700866547310 := by decide
theorem cert_e302820036206 : checkPay e302820036206 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820036218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302820036218 : Closed e302820036218 ∧ code e302820036218 = 4700866547322 := by decide
theorem cert_e302820036218 : checkPay e302820036218 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820036406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820036406 : Closed e302820036406 ∧ code e302820036406 = 4700866547510 := by decide
theorem cert_e302820036406 : checkPay e302820036406 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820036410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820036410 : Closed e302820036410 ∧ code e302820036410 = 4700866547514 := by decide
theorem cert_e302820036410 : checkPay e302820036410 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e302820715998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e302820715998 : Closed e302820715998 ∧ code e302820715998 = 4700867227102 := by decide
theorem cert_e302820715998 : check e302820715998 [[.under],[.under]] .chain = true := by decide
def e302820716014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e302820716014 : Closed e302820716014 ∧ code e302820716014 = 4700867227118 := by decide
theorem cert_e302820716014 : check e302820716014 [[.under],[.under]] .chain = true := by decide
def e302820716254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e302820716254 : Closed e302820716254 ∧ code e302820716254 = 4700867227358 := by decide
theorem cert_e302820716254 : check e302820716254 [[.under],[.under]] .chain = true := by decide
def e302820716278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e302820716278 : Closed e302820716278 ∧ code e302820716278 = 4700867227382 := by decide
theorem cert_e302820716278 : check e302820716278 [[.under],[.under]] .chain = true := by decide
def e302820716398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e302820716398 : Closed e302820716398 ∧ code e302820716398 = 4700867227502 := by decide
theorem cert_e302820716398 : check e302820716398 [[.under],[.under]] .chain = true := by decide
def e302820716406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e302820716406 : Closed e302820716406 ∧ code e302820716406 = 4700867227510 := by decide
theorem cert_e302820716406 : check e302820716406 [[.under],[.under]] .chain = true := by decide
def e302820718046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e302820718046 : Closed e302820718046 ∧ code e302820718046 = 4700867229150 := by decide
theorem cert_e302820718046 : check e302820718046 [[.under],[.under]] .chain = true := by decide
def e302820718062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e302820718062 : Closed e302820718062 ∧ code e302820718062 = 4700867229166 := by decide
theorem cert_e302820718062 : check e302820718062 [[.under],[.under]] .chain = true := by decide
def e302820718430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e302820718430 : Closed e302820718430 ∧ code e302820718430 = 4700867229534 := by decide
theorem cert_e302820718430 : check e302820718430 [[.under],[.under]] .chain = true := by decide
def e302820718458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e302820718458 : Closed e302820718458 ∧ code e302820718458 = 4700867229562 := by decide
theorem cert_e302820718458 : check e302820718458 [[.under],[.under]] .chain = true := by decide
def e302820718510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e302820718510 : Closed e302820718510 ∧ code e302820718510 = 4700867229614 := by decide
theorem cert_e302820718510 : check e302820718510 [[.under],[.under]] .chain = true := by decide
def e302820718522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e302820718522 : Closed e302820718522 ∧ code e302820718522 = 4700867229626 := by decide
theorem cert_e302820718522 : check e302820718522 [[.under],[.under]] .chain = true := by decide
def e302820719326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302820719326 : Closed e302820719326 ∧ code e302820719326 = 4700867230430 := by decide
theorem cert_e302820719326 : check e302820719326 [[.under],[.under]] .chain = true := by decide
def e302820719350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302820719350 : Closed e302820719350 ∧ code e302820719350 = 4700867230454 := by decide
theorem cert_e302820719350 : check e302820719350 [[.under],[.under]] .chain = true := by decide
def e302820719454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302820719454 : Closed e302820719454 ∧ code e302820719454 = 4700867230558 := by decide
theorem cert_e302820719454 : check e302820719454 [[.under],[.under]] .chain = true := by decide
def e302820719482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302820719482 : Closed e302820719482 ∧ code e302820719482 = 4700867230586 := by decide
theorem cert_e302820719482 : check e302820719482 [[.under],[.under]] .chain = true := by decide
def e302820719574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302820719574 : Closed e302820719574 ∧ code e302820719574 = 4700867230678 := by decide
theorem cert_e302820719574 : check e302820719574 [[.under],[.under]] .chain = true := by decide
def e302820719578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302820719578 : Closed e302820719578 ∧ code e302820719578 = 4700867230682 := by decide
theorem cert_e302820719578 : check e302820719578 [[.under],[.under]] .chain = true := by decide
def e302820719982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302820719982 : Closed e302820719982 ∧ code e302820719982 = 4700867231086 := by decide
theorem cert_e302820719982 : check e302820719982 [[.under],[.under]] .chain = true := by decide
def e302820719990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302820719990 : Closed e302820719990 ∧ code e302820719990 = 4700867231094 := by decide
theorem cert_e302820719990 : check e302820719990 [[.under],[.under]] .chain = true := by decide
def e302820720046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302820720046 : Closed e302820720046 ∧ code e302820720046 = 4700867231150 := by decide
theorem cert_e302820720046 : check e302820720046 [[.under],[.under]] .chain = true := by decide
def e302820720058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302820720058 : Closed e302820720058 ∧ code e302820720058 = 4700867231162 := by decide
theorem cert_e302820720058 : check e302820720058 [[.under],[.under]] .chain = true := by decide
def e302820720086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302820720086 : Closed e302820720086 ∧ code e302820720086 = 4700867231190 := by decide
theorem cert_e302820720086 : check e302820720086 [[.under],[.under]] .chain = true := by decide
def e302820720090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302820720090 : Closed e302820720090 ∧ code e302820720090 = 4700867231194 := by decide
theorem cert_e302820720090 : check e302820720090 [[.under],[.under]] .chain = true := by decide
def e302820728286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e302820728286 : Closed e302820728286 ∧ code e302820728286 = 4700867239390 := by decide
theorem cert_e302820728286 : check e302820728286 [[.under],[.under]] .chain = true := by decide
def e302820728302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e302820728302 : Closed e302820728302 ∧ code e302820728302 = 4700867239406 := by decide
theorem cert_e302820728302 : check e302820728302 [[.under],[.under]] .chain = true := by decide
def e302820728542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e302820728542 : Closed e302820728542 ∧ code e302820728542 = 4700867239646 := by decide
theorem cert_e302820728542 : check e302820728542 [[.under],[.under]] .chain = true := by decide
def e302820728566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e302820728566 : Closed e302820728566 ∧ code e302820728566 = 4700867239670 := by decide
theorem cert_e302820728566 : check e302820728566 [[.under],[.under]] .chain = true := by decide
def e302820728686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e302820728686 : Closed e302820728686 ∧ code e302820728686 = 4700867239790 := by decide
theorem cert_e302820728686 : check e302820728686 [[.under],[.under]] .chain = true := by decide
def e302820728694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e302820728694 : Closed e302820728694 ∧ code e302820728694 = 4700867239798 := by decide
theorem cert_e302820728694 : check e302820728694 [[.under],[.under]] .chain = true := by decide
def e302820733918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302820733918 : Closed e302820733918 ∧ code e302820733918 = 4700867245022 := by decide
theorem cert_e302820733918 : check e302820733918 [[.under],[.under]] .chain = true := by decide
def e302820733934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302820733934 : Closed e302820733934 ∧ code e302820733934 = 4700867245038 := by decide
theorem cert_e302820733934 : check e302820733934 [[.under],[.under]] .chain = true := by decide
def e302820735454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302820735454 : Closed e302820735454 ∧ code e302820735454 = 4700867246558 := by decide
theorem cert_e302820735454 : check e302820735454 [[.under],[.under]] .chain = true := by decide
def e302820735478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302820735478 : Closed e302820735478 ∧ code e302820735478 = 4700867246582 := by decide
theorem cert_e302820735478 : check e302820735478 [[.under],[.under]] .chain = true := by decide
def e302820736238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302820736238 : Closed e302820736238 ∧ code e302820736238 = 4700867247342 := by decide
theorem cert_e302820736238 : check e302820736238 [[.under],[.under]] .chain = true := by decide
def e302820736246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302820736246 : Closed e302820736246 ∧ code e302820736246 = 4700867247350 := by decide
theorem cert_e302820736246 : check e302820736246 [[.under],[.under]] .chain = true := by decide
def e302820740574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e302820740574 : Closed e302820740574 ∧ code e302820740574 = 4700867251678 := by decide
theorem cert_e302820740574 : check e302820740574 [[.under],[.under]] .chain = true := by decide
def e302820740590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e302820740590 : Closed e302820740590 ∧ code e302820740590 = 4700867251694 := by decide
theorem cert_e302820740590 : check e302820740590 [[.under],[.under]] .chain = true := by decide
def e302820740958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e302820740958 : Closed e302820740958 ∧ code e302820740958 = 4700867252062 := by decide
theorem cert_e302820740958 : check e302820740958 [[.under],[.under]] .chain = true := by decide
def e302820740986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e302820740986 : Closed e302820740986 ∧ code e302820740986 = 4700867252090 := by decide
theorem cert_e302820740986 : check e302820740986 [[.under],[.under]] .chain = true := by decide
def e302820741038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e302820741038 : Closed e302820741038 ∧ code e302820741038 = 4700867252142 := by decide
theorem cert_e302820741038 : check e302820741038 [[.under],[.under]] .chain = true := by decide
def e302820741050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e302820741050 : Closed e302820741050 ∧ code e302820741050 = 4700867252154 := by decide
theorem cert_e302820741050 : check e302820741050 [[.under],[.under]] .chain = true := by decide
def e302820742110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e302820742110 : Closed e302820742110 ∧ code e302820742110 = 4700867253214 := by decide
theorem cert_e302820742110 : check e302820742110 [[.under],[.under]] .chain = true := by decide
def e302820742126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e302820742126 : Closed e302820742126 ∧ code e302820742126 = 4700867253230 := by decide
theorem cert_e302820742126 : check e302820742126 [[.under],[.under]] .chain = true := by decide
def e302820744414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302820744414 : Closed e302820744414 ∧ code e302820744414 = 4700867255518 := by decide
theorem cert_e302820744414 : check e302820744414 [[.under],[.under]] .chain = true := by decide
def e302820744442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302820744442 : Closed e302820744442 ∧ code e302820744442 = 4700867255546 := by decide
theorem cert_e302820744442 : check e302820744442 [[.under],[.under]] .chain = true := by decide
def e302820744814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302820744814 : Closed e302820744814 ∧ code e302820744814 = 4700867255918 := by decide
theorem cert_e302820744814 : check e302820744814 [[.under],[.under]] .chain = true := by decide
def e302820744826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302820744826 : Closed e302820744826 ∧ code e302820744826 = 4700867255930 := by decide
theorem cert_e302820744826 : check e302820744826 [[.under],[.under]] .chain = true := by decide
def e302820746974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302820746974 : Closed e302820746974 ∧ code e302820746974 = 4700867258078 := by decide
theorem cert_e302820746974 : check e302820746974 [[.under],[.under]] .chain = true := by decide
def e302820746998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302820746998 : Closed e302820746998 ∧ code e302820746998 = 4700867258102 := by decide
theorem cert_e302820746998 : check e302820746998 [[.under],[.under]] .chain = true := by decide
def e302820747102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302820747102 : Closed e302820747102 ∧ code e302820747102 = 4700867258206 := by decide
theorem cert_e302820747102 : check e302820747102 [[.under],[.under]] .chain = true := by decide
def e302820747130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302820747130 : Closed e302820747130 ∧ code e302820747130 = 4700867258234 := by decide
theorem cert_e302820747130 : check e302820747130 [[.under],[.under]] .chain = true := by decide
def e302820747222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302820747222 : Closed e302820747222 ∧ code e302820747222 = 4700867258326 := by decide
theorem cert_e302820747222 : check e302820747222 [[.under],[.under]] .chain = true := by decide
def e302820747226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302820747226 : Closed e302820747226 ∧ code e302820747226 = 4700867258330 := by decide
theorem cert_e302820747226 : check e302820747226 [[.under],[.under]] .chain = true := by decide
def e302820747742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302820747742 : Closed e302820747742 ∧ code e302820747742 = 4700867258846 := by decide
theorem cert_e302820747742 : check e302820747742 [[.under],[.under]] .chain = true := by decide
def e302820747766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302820747766 : Closed e302820747766 ∧ code e302820747766 = 4700867258870 := by decide
theorem cert_e302820747766 : check e302820747766 [[.under],[.under]] .chain = true := by decide
def e302820748510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302820748510 : Closed e302820748510 ∧ code e302820748510 = 4700867259614 := by decide
theorem cert_e302820748510 : check e302820748510 [[.under],[.under]] .chain = true := by decide
def e302820748538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302820748538 : Closed e302820748538 ∧ code e302820748538 = 4700867259642 := by decide
theorem cert_e302820748538 : check e302820748538 [[.under],[.under]] .chain = true := by decide
def e302820749110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820749110 : Closed e302820749110 ∧ code e302820749110 = 4700867260214 := by decide
theorem cert_e302820749110 : check e302820749110 [[.under],[.under]] .chain = true := by decide
def e302820749114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820749114 : Closed e302820749114 ∧ code e302820749114 = 4700867260218 := by decide
theorem cert_e302820749114 : check e302820749114 [[.under],[.under]] .chain = true := by decide
def e302820750190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302820750190 : Closed e302820750190 ∧ code e302820750190 = 4700867261294 := by decide
theorem cert_e302820750190 : check e302820750190 [[.under],[.under]] .chain = true := by decide
def e302820750198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302820750198 : Closed e302820750198 ∧ code e302820750198 = 4700867261302 := by decide
theorem cert_e302820750198 : check e302820750198 [[.under],[.under]] .chain = true := by decide
def e302820750254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302820750254 : Closed e302820750254 ∧ code e302820750254 = 4700867261358 := by decide
theorem cert_e302820750254 : check e302820750254 [[.under],[.under]] .chain = true := by decide
def e302820750266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302820750266 : Closed e302820750266 ∧ code e302820750266 = 4700867261370 := by decide
theorem cert_e302820750266 : check e302820750266 [[.under],[.under]] .chain = true := by decide
def e302820750294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302820750294 : Closed e302820750294 ∧ code e302820750294 = 4700867261398 := by decide
theorem cert_e302820750294 : check e302820750294 [[.under],[.under]] .chain = true := by decide
def e302820750298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302820750298 : Closed e302820750298 ∧ code e302820750298 = 4700867261402 := by decide
theorem cert_e302820750298 : check e302820750298 [[.under],[.under]] .chain = true := by decide
def e302820750574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302820750574 : Closed e302820750574 ∧ code e302820750574 = 4700867261678 := by decide
theorem cert_e302820750574 : check e302820750574 [[.under],[.under]] .chain = true := by decide
def e302820750582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302820750582 : Closed e302820750582 ∧ code e302820750582 = 4700867261686 := by decide
theorem cert_e302820750582 : check e302820750582 [[.under],[.under]] .chain = true := by decide
def e302820750958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302820750958 : Closed e302820750958 ∧ code e302820750958 = 4700867262062 := by decide
theorem cert_e302820750958 : check e302820750958 [[.under],[.under]] .chain = true := by decide
def e302820750970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302820750970 : Closed e302820750970 ∧ code e302820750970 = 4700867262074 := by decide
theorem cert_e302820750970 : check e302820750970 [[.under],[.under]] .chain = true := by decide
def e302820751158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820751158 : Closed e302820751158 ∧ code e302820751158 = 4700867262262 := by decide
theorem cert_e302820751158 : check e302820751158 [[.under],[.under]] .chain = true := by decide
def e302820751162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820751162 : Closed e302820751162 ∧ code e302820751162 = 4700867262266 := by decide
theorem cert_e302820751162 : check e302820751162 [[.under],[.under]] .chain = true := by decide
def e302820777438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e302820777438 : Closed e302820777438 ∧ code e302820777438 = 4700867288542 := by decide
theorem cert_e302820777438 : check e302820777438 [[.under],[.under]] .chain = true := by decide
def e302820777454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e302820777454 : Closed e302820777454 ∧ code e302820777454 = 4700867288558 := by decide
theorem cert_e302820777454 : check e302820777454 [[.under],[.under]] .chain = true := by decide
def e302820777694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e302820777694 : Closed e302820777694 ∧ code e302820777694 = 4700867288798 := by decide
theorem cert_e302820777694 : check e302820777694 [[.under],[.under]] .chain = true := by decide
def e302820777718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e302820777718 : Closed e302820777718 ∧ code e302820777718 = 4700867288822 := by decide
theorem cert_e302820777718 : check e302820777718 [[.under],[.under]] .chain = true := by decide
def e302820777838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e302820777838 : Closed e302820777838 ∧ code e302820777838 = 4700867288942 := by decide
theorem cert_e302820777838 : check e302820777838 [[.under],[.under]] .chain = true := by decide
def e302820777846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e302820777846 : Closed e302820777846 ∧ code e302820777846 = 4700867288950 := by decide
theorem cert_e302820777846 : check e302820777846 [[.under],[.under]] .chain = true := by decide
def e302820783070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e302820783070 : Closed e302820783070 ∧ code e302820783070 = 4700867294174 := by decide
theorem cert_e302820783070 : check e302820783070 [[.under],[.under]] .chain = true := by decide
def e302820783086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e302820783086 : Closed e302820783086 ∧ code e302820783086 = 4700867294190 := by decide
theorem cert_e302820783086 : check e302820783086 [[.under],[.under]] .chain = true := by decide
def e302820784606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e302820784606 : Closed e302820784606 ∧ code e302820784606 = 4700867295710 := by decide
theorem cert_e302820784606 : check e302820784606 [[.under],[.under]] .chain = true := by decide
def e302820784630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e302820784630 : Closed e302820784630 ∧ code e302820784630 = 4700867295734 := by decide
theorem cert_e302820784630 : check e302820784630 [[.under],[.under]] .chain = true := by decide
def e302820785390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e302820785390 : Closed e302820785390 ∧ code e302820785390 = 4700867296494 := by decide
theorem cert_e302820785390 : check e302820785390 [[.under],[.under]] .chain = true := by decide
def e302820785398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e302820785398 : Closed e302820785398 ∧ code e302820785398 = 4700867296502 := by decide
theorem cert_e302820785398 : check e302820785398 [[.under],[.under]] .chain = true := by decide
def e302820830686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e302820830686 : Closed e302820830686 ∧ code e302820830686 = 4700867341790 := by decide
theorem cert_e302820830686 : check e302820830686 [[.under],[.under]] .chain = true := by decide
def e302820830702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e302820830702 : Closed e302820830702 ∧ code e302820830702 = 4700867341806 := by decide
theorem cert_e302820830702 : check e302820830702 [[.under],[.under]] .chain = true := by decide
def e302820831070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e302820831070 : Closed e302820831070 ∧ code e302820831070 = 4700867342174 := by decide
theorem cert_e302820831070 : check e302820831070 [[.under],[.under]] .chain = true := by decide
def e302820831098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e302820831098 : Closed e302820831098 ∧ code e302820831098 = 4700867342202 := by decide
theorem cert_e302820831098 : check e302820831098 [[.under],[.under]] .chain = true := by decide
def e302820831150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e302820831150 : Closed e302820831150 ∧ code e302820831150 = 4700867342254 := by decide
theorem cert_e302820831150 : check e302820831150 [[.under],[.under]] .chain = true := by decide
def e302820831162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e302820831162 : Closed e302820831162 ∧ code e302820831162 = 4700867342266 := by decide
theorem cert_e302820831162 : check e302820831162 [[.under],[.under]] .chain = true := by decide
def e302820832222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e302820832222 : Closed e302820832222 ∧ code e302820832222 = 4700867343326 := by decide
theorem cert_e302820832222 : check e302820832222 [[.under],[.under]] .chain = true := by decide
def e302820832238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e302820832238 : Closed e302820832238 ∧ code e302820832238 = 4700867343342 := by decide
theorem cert_e302820832238 : check e302820832238 [[.under],[.under]] .chain = true := by decide
def e302820834526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e302820834526 : Closed e302820834526 ∧ code e302820834526 = 4700867345630 := by decide
theorem cert_e302820834526 : check e302820834526 [[.under],[.under]] .chain = true := by decide
def e302820834554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e302820834554 : Closed e302820834554 ∧ code e302820834554 = 4700867345658 := by decide
theorem cert_e302820834554 : check e302820834554 [[.under],[.under]] .chain = true := by decide
def e302820834926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e302820834926 : Closed e302820834926 ∧ code e302820834926 = 4700867346030 := by decide
theorem cert_e302820834926 : check e302820834926 [[.under],[.under]] .chain = true := by decide
def e302820834938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e302820834938 : Closed e302820834938 ∧ code e302820834938 = 4700867346042 := by decide
theorem cert_e302820834938 : check e302820834938 [[.under],[.under]] .chain = true := by decide
def e302820857566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302820857566 : Closed e302820857566 ∧ code e302820857566 = 4700867368670 := by decide
theorem cert_e302820857566 : check e302820857566 [[.under],[.under]] .chain = true := by decide
def e302820857590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302820857590 : Closed e302820857590 ∧ code e302820857590 = 4700867368694 := by decide
theorem cert_e302820857590 : check e302820857590 [[.under],[.under]] .chain = true := by decide
def e302820857694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302820857694 : Closed e302820857694 ∧ code e302820857694 = 4700867368798 := by decide
theorem cert_e302820857694 : check e302820857694 [[.under],[.under]] .chain = true := by decide
def e302820857722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302820857722 : Closed e302820857722 ∧ code e302820857722 = 4700867368826 := by decide
theorem cert_e302820857722 : check e302820857722 [[.under],[.under]] .chain = true := by decide
def e302820857814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302820857814 : Closed e302820857814 ∧ code e302820857814 = 4700867368918 := by decide
theorem cert_e302820857814 : check e302820857814 [[.under],[.under]] .chain = true := by decide
def e302820857818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302820857818 : Closed e302820857818 ∧ code e302820857818 = 4700867368922 := by decide
theorem cert_e302820857818 : check e302820857818 [[.under],[.under]] .chain = true := by decide
def e302820858334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302820858334 : Closed e302820858334 ∧ code e302820858334 = 4700867369438 := by decide
theorem cert_e302820858334 : check e302820858334 [[.under],[.under]] .chain = true := by decide
def e302820858358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302820858358 : Closed e302820858358 ∧ code e302820858358 = 4700867369462 := by decide
theorem cert_e302820858358 : check e302820858358 [[.under],[.under]] .chain = true := by decide
def e302820859102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302820859102 : Closed e302820859102 ∧ code e302820859102 = 4700867370206 := by decide
theorem cert_e302820859102 : check e302820859102 [[.under],[.under]] .chain = true := by decide
def e302820859130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302820859130 : Closed e302820859130 ∧ code e302820859130 = 4700867370234 := by decide
theorem cert_e302820859130 : check e302820859130 [[.under],[.under]] .chain = true := by decide
def e302820859702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820859702 : Closed e302820859702 ∧ code e302820859702 = 4700867370806 := by decide
theorem cert_e302820859702 : check e302820859702 [[.under],[.under]] .chain = true := by decide
def e302820859706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820859706 : Closed e302820859706 ∧ code e302820859706 = 4700867370810 := by decide
theorem cert_e302820859706 : check e302820859706 [[.under],[.under]] .chain = true := by decide
def e302820871022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302820871022 : Closed e302820871022 ∧ code e302820871022 = 4700867382126 := by decide
theorem cert_e302820871022 : check e302820871022 [[.under],[.under]] .chain = true := by decide
def e302820871030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302820871030 : Closed e302820871030 ∧ code e302820871030 = 4700867382134 := by decide
theorem cert_e302820871030 : check e302820871030 [[.under],[.under]] .chain = true := by decide
def e302820871086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302820871086 : Closed e302820871086 ∧ code e302820871086 = 4700867382190 := by decide
theorem cert_e302820871086 : check e302820871086 [[.under],[.under]] .chain = true := by decide
def e302820871098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302820871098 : Closed e302820871098 ∧ code e302820871098 = 4700867382202 := by decide
theorem cert_e302820871098 : check e302820871098 [[.under],[.under]] .chain = true := by decide
def e302820871126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302820871126 : Closed e302820871126 ∧ code e302820871126 = 4700867382230 := by decide
theorem cert_e302820871126 : check e302820871126 [[.under],[.under]] .chain = true := by decide
def e302820871130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302820871130 : Closed e302820871130 ∧ code e302820871130 = 4700867382234 := by decide
theorem cert_e302820871130 : check e302820871130 [[.under],[.under]] .chain = true := by decide
def e302820871406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302820871406 : Closed e302820871406 ∧ code e302820871406 = 4700867382510 := by decide
theorem cert_e302820871406 : check e302820871406 [[.under],[.under]] .chain = true := by decide
def e302820871414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302820871414 : Closed e302820871414 ∧ code e302820871414 = 4700867382518 := by decide
theorem cert_e302820871414 : check e302820871414 [[.under],[.under]] .chain = true := by decide
def e302820871790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302820871790 : Closed e302820871790 ∧ code e302820871790 = 4700867382894 := by decide
theorem cert_e302820871790 : check e302820871790 [[.under],[.under]] .chain = true := by decide
def e302820871802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302820871802 : Closed e302820871802 ∧ code e302820871802 = 4700867382906 := by decide
theorem cert_e302820871802 : check e302820871802 [[.under],[.under]] .chain = true := by decide
def e302820871990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820871990 : Closed e302820871990 ∧ code e302820871990 = 4700867383094 := by decide
theorem cert_e302820871990 : check e302820871990 [[.under],[.under]] .chain = true := by decide
def e302820871994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820871994 : Closed e302820871994 ∧ code e302820871994 = 4700867383098 := by decide
theorem cert_e302820871994 : check e302820871994 [[.under],[.under]] .chain = true := by decide
def e302825540462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302825540462 : Closed e302825540462 ∧ code e302825540462 = 4700872051566 := by decide
theorem cert_e302825540462 : check e302825540462 [[.under],[.under],[.under,.under]] .three = true := by decide
def e302825540470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302825540470 : Closed e302825540470 ∧ code e302825540470 = 4700872051574 := by decide
theorem cert_e302825540470 : check e302825540470 [[.under],[.under],[.under,.under]] .three = true := by decide
end Blc.Floor42
