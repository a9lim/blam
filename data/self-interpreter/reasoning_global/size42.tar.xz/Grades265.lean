import Tables
import Batch265
namespace Blc.Floor42.Grades265
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211608685942 : ¬ IsSelfInterpreter e1211608685942 := cutM0_2 (by decide)
#print axioms ex_e1211608685942
theorem ex_e1211608691574 : ¬ IsSelfInterpreter e1211608691574 := cutM0_2 (by decide)
#print axioms ex_e1211608691574
theorem ex_e1211608691670 : ¬ IsSelfInterpreter e1211608691670 := cutM0_2 (by decide)
#print axioms ex_e1211608691670
theorem ex_e1211608693206 : ¬ IsSelfInterpreter e1211608693206 := cutM0_2 (by decide)
#print axioms ex_e1211608693206
theorem ex_e1211608714158 : ¬ IsSelfInterpreter e1211608714158 := cutM0_2 (by decide)
#print axioms ex_e1211608714158
theorem ex_e1211608714862 : ¬ IsSelfInterpreter e1211608714862 := cutM0_2 (by decide)
#print axioms ex_e1211608714862
theorem ex_e1211608714874 : ¬ IsSelfInterpreter e1211608714874 := cutM0_2 (by decide)
#print axioms ex_e1211608714874
theorem ex_e1211608715066 : ¬ IsSelfInterpreter e1211608715066 := cutM0_2 (by decide)
#print axioms ex_e1211608715066
theorem ex_e1211608714094 : ¬ IsSelfInterpreter e1211608714094 := cutM1_2 (by decide)
#print axioms ex_e1211608714094
theorem ex_e1211608714102 : ¬ IsSelfInterpreter e1211608714102 := cutM1_2 (by decide)
#print axioms ex_e1211608714102
theorem ex_e1211608714198 : ¬ IsSelfInterpreter e1211608714198 := cutM1_2 (by decide)
#print axioms ex_e1211608714198
theorem ex_e1211608714478 : ¬ IsSelfInterpreter e1211608714478 := cutM1_2 (by decide)
#print axioms ex_e1211608714478
theorem ex_e1211608714486 : ¬ IsSelfInterpreter e1211608714486 := cutM1_2 (by decide)
#print axioms ex_e1211608714486
theorem ex_e1211608715062 : ¬ IsSelfInterpreter e1211608715062 := cutM1_2 (by decide)
#print axioms ex_e1211608715062
theorem ex_e1211608620526 : ¬ IsSelfInterpreter e1211608620526 := cutM3_1 (by decide)
#print axioms ex_e1211608620526
theorem ex_e1211608685430 : ¬ IsSelfInterpreter e1211608685430 := cutM3_1 (by decide)
#print axioms ex_e1211608685430
theorem ex_e1211608685494 : ¬ IsSelfInterpreter e1211608685494 := cutM3_1 (by decide)
#print axioms ex_e1211608685494
theorem ex_e1211608686262 : ¬ IsSelfInterpreter e1211608686262 := cutM3_1 (by decide)
#print axioms ex_e1211608686262
theorem ex_e1211608688502 : ¬ IsSelfInterpreter e1211608688502 := cutM3_1 (by decide)
#print axioms ex_e1211608688502
theorem ex_e1211608688566 : ¬ IsSelfInterpreter e1211608688566 := cutM3_1 (by decide)
#print axioms ex_e1211608688566
theorem ex_e1211608693174 : ¬ IsSelfInterpreter e1211608693174 := cutM3_1 (by decide)
#print axioms ex_e1211608693174
end Blc.Floor42.Grades265
