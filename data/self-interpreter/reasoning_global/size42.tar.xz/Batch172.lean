import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188366562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211188366562 : Closed e1211188366562 ∧ code e1211188366562 = 5609234877666 := by decide
theorem cert_e1211188366562 : check e1211188366562 [[],[]] .smaller = true := by decide
def e1211188366574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188366574 : Closed e1211188366574 ∧ code e1211188366574 = 5609234877678 := by decide
theorem cert_e1211188366574 : check e1211188366574 [[],[]] .smaller = true := by decide
def e1211188366582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188366582 : Closed e1211188366582 ∧ code e1211188366582 = 5609234877686 := by decide
theorem cert_e1211188366582 : check e1211188366582 [[],[]] .smaller = true := by decide
def e1211188366586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211188366586 : Closed e1211188366586 ∧ code e1211188366586 = 5609234877690 := by decide
theorem cert_e1211188366586 : check e1211188366586 [[],[]] .three = true := by decide
def e1211188366862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188366862 : Closed e1211188366862 ∧ code e1211188366862 = 5609234877966 := by decide
theorem cert_e1211188366862 : check e1211188366862 [[],[]] .smaller = true := by decide
def e1211188366910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211188366910 : Closed e1211188366910 ∧ code e1211188366910 = 5609234878014 := by decide
theorem cert_e1211188366910 : check e1211188366910 [[],[]] .three = true := by decide
def e1211188366946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188366946 : Closed e1211188366946 ∧ code e1211188366946 = 5609234878050 := by decide
theorem cert_e1211188366946 : check e1211188366946 [[],[]] .smaller = true := by decide
def e1211188366958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188366958 : Closed e1211188366958 ∧ code e1211188366958 = 5609234878062 := by decide
theorem cert_e1211188366958 : check e1211188366958 [[],[]] .smaller = true := by decide
def e1211188366970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188366970 : Closed e1211188366970 ∧ code e1211188366970 = 5609234878074 := by decide
theorem cert_e1211188366970 : check e1211188366970 [[],[]] .smaller = true := by decide
def e1211188367158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188367158 : Closed e1211188367158 ∧ code e1211188367158 = 5609234878262 := by decide
theorem cert_e1211188367158 : check e1211188367158 [[],[]] .smaller = true := by decide
def e1211188367162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188367162 : Closed e1211188367162 ∧ code e1211188367162 = 5609234878266 := by decide
theorem cert_e1211188367162 : check e1211188367162 [[],[]] .smaller = true := by decide
def e1211188367246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211188367246 : Closed e1211188367246 ∧ code e1211188367246 = 5609234878350 := by decide
theorem cert_e1211188367246 : check e1211188367246 [[],[]] .three = true := by decide
def e1211188367258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188367258 : Closed e1211188367258 ∧ code e1211188367258 = 5609234878362 := by decide
theorem cert_e1211188367258 : check e1211188367258 [[],[]] .three = true := by decide
def e1211188372874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188372874 : Closed e1211188372874 ∧ code e1211188372874 = 5609234883978 := by decide
theorem cert_e1211188372874 : check e1211188372874 [[],[]] .three = true := by decide
def e1211188372898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188372898 : Closed e1211188372898 ∧ code e1211188372898 = 5609234884002 := by decide
theorem cert_e1211188372898 : check e1211188372898 [[],[]] .three = true := by decide
def e1211188372910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211188372910 : Closed e1211188372910 ∧ code e1211188372910 = 5609234884014 := by decide
theorem cert_e1211188372910 : check e1211188372910 [[],[]] .three = true := by decide
def e1211188372918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211188372918 : Closed e1211188372918 ∧ code e1211188372918 = 5609234884022 := by decide
theorem cert_e1211188372918 : check e1211188372918 [[],[]] .three = true := by decide
def e1211188372922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211188372922 : Closed e1211188372922 ∧ code e1211188372922 = 5609234884026 := by decide
theorem cert_e1211188372922 : check e1211188372922 [[],[]] .three = true := by decide
def e1211188372950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211188372950 : Closed e1211188372950 ∧ code e1211188372950 = 5609234884054 := by decide
theorem cert_e1211188372950 : check e1211188372950 [[],[]] .three = true := by decide
def e1211188372954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211188372954 : Closed e1211188372954 ∧ code e1211188372954 = 5609234884058 := by decide
theorem cert_e1211188372954 : check e1211188372954 [[],[]] .three = true := by decide
def e1211188372970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211188372970 : Closed e1211188372970 ∧ code e1211188372970 = 5609234884074 := by decide
theorem cert_e1211188372970 : check e1211188372970 [[],[]] .three = true := by decide
def e1211188373006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188373006 : Closed e1211188373006 ∧ code e1211188373006 = 5609234884110 := by decide
theorem cert_e1211188373006 : check e1211188373006 [[],[]] .three = true := by decide
def e1211188373018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188373018 : Closed e1211188373018 ∧ code e1211188373018 = 5609234884122 := by decide
theorem cert_e1211188373018 : check e1211188373018 [[],[]] .three = true := by decide
def e1211188373054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211188373054 : Closed e1211188373054 ∧ code e1211188373054 = 5609234884158 := by decide
theorem cert_e1211188373054 : check e1211188373054 [[],[]] .three = true := by decide
def e1211188373090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188373090 : Closed e1211188373090 ∧ code e1211188373090 = 5609234884194 := by decide
theorem cert_e1211188373090 : check e1211188373090 [[],[]] .three = true := by decide
def e1211188373102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188373102 : Closed e1211188373102 ∧ code e1211188373102 = 5609234884206 := by decide
theorem cert_e1211188373102 : check e1211188373102 [[],[]] .three = true := by decide
def e1211188373110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188373110 : Closed e1211188373110 ∧ code e1211188373110 = 5609234884214 := by decide
theorem cert_e1211188373110 : check e1211188373110 [[],[]] .three = true := by decide
def e1211188373114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188373114 : Closed e1211188373114 ∧ code e1211188373114 = 5609234884218 := by decide
theorem cert_e1211188373114 : check e1211188373114 [[],[]] .three = true := by decide
def e1211188373278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211188373278 : Closed e1211188373278 ∧ code e1211188373278 = 5609234884382 := by decide
theorem cert_e1211188373278 : check e1211188373278 [[],[]] .three = true := by decide
def e1211188373302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188373302 : Closed e1211188373302 ∧ code e1211188373302 = 5609234884406 := by decide
theorem cert_e1211188373302 : check e1211188373302 [[],[]] .three = true := by decide
def e1211188373306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188373306 : Closed e1211188373306 ∧ code e1211188373306 = 5609234884410 := by decide
theorem cert_e1211188373306 : check e1211188373306 [[],[]] .three = true := by decide
def e1211188373390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211188373390 : Closed e1211188373390 ∧ code e1211188373390 = 5609234884494 := by decide
theorem cert_e1211188373390 : check e1211188373390 [[],[]] .three = true := by decide
def e1211188373402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188373402 : Closed e1211188373402 ∧ code e1211188373402 = 5609234884506 := by decide
theorem cert_e1211188373402 : check e1211188373402 [[],[]] .three = true := by decide
def e1211188373446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211188373446 : Closed e1211188373446 ∧ code e1211188373446 = 5609234884550 := by decide
theorem cert_e1211188373446 : check e1211188373446 [[],[]] .three = true := by decide
def e1211188665790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 4)))))))))
theorem wire_e1211188665790 : Closed e1211188665790 ∧ code e1211188665790 = 5609235176894 := by decide
theorem cert_e1211188665790 : check e1211188665790 [[],[]] .three = true := by decide
def e1211188665822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211188665822 : Closed e1211188665822 ∧ code e1211188665822 = 5609235176926 := by decide
theorem cert_e1211188665822 : check e1211188665822 [[],[]] .smaller = true := by decide
def e1211188665838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211188665838 : Closed e1211188665838 ∧ code e1211188665838 = 5609235176942 := by decide
theorem cert_e1211188665838 : check e1211188665838 [[],[]] .smaller = true := by decide
def e1211188665846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 4)) (.var 1)))))))))
theorem wire_e1211188665846 : Closed e1211188665846 ∧ code e1211188665846 = 5609235176950 := by decide
theorem cert_e1211188665846 : check e1211188665846 [[],[]] .three = true := by decide
def e1211188666078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211188666078 : Closed e1211188666078 ∧ code e1211188666078 = 5609235177182 := by decide
theorem cert_e1211188666078 : check e1211188666078 [[],[]] .smaller = true := by decide
def e1211188666102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211188666102 : Closed e1211188666102 ∧ code e1211188666102 = 5609235177206 := by decide
theorem cert_e1211188666102 : check e1211188666102 [[],[]] .smaller = true := by decide
def e1211188666222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211188666222 : Closed e1211188666222 ∧ code e1211188666222 = 5609235177326 := by decide
theorem cert_e1211188666222 : check e1211188666222 [[],[]] .smaller = true := by decide
def e1211188666230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211188666230 : Closed e1211188666230 ∧ code e1211188666230 = 5609235177334 := by decide
theorem cert_e1211188666230 : check e1211188666230 [[],[]] .smaller = true := by decide
def e1211188666294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 4) (.var 1)) (.var 1)))))))))
theorem wire_e1211188666294 : Closed e1211188666294 ∧ code e1211188666294 = 5609235177398 := by decide
theorem cert_e1211188666294 : check e1211188666294 [[],[]] .three = true := by decide
def e1211188671422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211188671422 : Closed e1211188671422 ∧ code e1211188671422 = 5609235182526 := by decide
theorem cert_e1211188671422 : check e1211188671422 [[],[]] .three = true := by decide
def e1211188671454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211188671454 : Closed e1211188671454 ∧ code e1211188671454 = 5609235182558 := by decide
theorem cert_e1211188671454 : check e1211188671454 [[],[]] .smaller = true := by decide
def e1211188671470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211188671470 : Closed e1211188671470 ∧ code e1211188671470 = 5609235182574 := by decide
theorem cert_e1211188671470 : check e1211188671470 [[],[]] .smaller = true := by decide
def e1211188671478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211188671478 : Closed e1211188671478 ∧ code e1211188671478 = 5609235182582 := by decide
theorem cert_e1211188671478 : check e1211188671478 [[],[]] .three = true := by decide
def e1211188672990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211188672990 : Closed e1211188672990 ∧ code e1211188672990 = 5609235184094 := by decide
theorem cert_e1211188672990 : check e1211188672990 [[],[]] .smaller = true := by decide
def e1211188673014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211188673014 : Closed e1211188673014 ∧ code e1211188673014 = 5609235184118 := by decide
theorem cert_e1211188673014 : check e1211188673014 [[],[]] .smaller = true := by decide
def e1211188673774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188673774 : Closed e1211188673774 ∧ code e1211188673774 = 5609235184878 := by decide
theorem cert_e1211188673774 : check e1211188673774 [[],[]] .smaller = true := by decide
def e1211188673782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188673782 : Closed e1211188673782 ∧ code e1211188673782 = 5609235184886 := by decide
theorem cert_e1211188673782 : check e1211188673782 [[],[]] .smaller = true := by decide
def e1211188674166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188674166 : Closed e1211188674166 ∧ code e1211188674166 = 5609235185270 := by decide
theorem cert_e1211188674166 : check e1211188674166 [[],[]] .three = true := by decide
def e1211188730038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e1211188730038 : Closed e1211188730038 ∧ code e1211188730038 = 5609235241142 := by decide
theorem cert_e1211188730038 : check e1211188730038 [[],[]] .smaller = true := by decide
def e1211188730070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211188730070 : Closed e1211188730070 ∧ code e1211188730070 = 5609235241174 := by decide
theorem cert_e1211188730070 : check e1211188730070 [[],[]] .smaller = true := by decide
def e1211188730074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211188730074 : Closed e1211188730074 ∧ code e1211188730074 = 5609235241178 := by decide
theorem cert_e1211188730074 : check e1211188730074 [[],[]] .smaller = true := by decide
def e1211188730090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211188730090 : Closed e1211188730090 ∧ code e1211188730090 = 5609235241194 := by decide
theorem cert_e1211188730090 : check e1211188730090 [[],[]] .smaller = true := by decide
def e1211188730422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211188730422 : Closed e1211188730422 ∧ code e1211188730422 = 5609235241526 := by decide
theorem cert_e1211188730422 : check e1211188730422 [[],[]] .smaller = true := by decide
def e1211188730426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211188730426 : Closed e1211188730426 ∧ code e1211188730426 = 5609235241530 := by decide
theorem cert_e1211188730426 : check e1211188730426 [[],[]] .smaller = true := by decide
def e1211188730510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211188730510 : Closed e1211188730510 ∧ code e1211188730510 = 5609235241614 := by decide
theorem cert_e1211188730510 : check e1211188730510 [[],[]] .smaller = true := by decide
def e1211188730566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211188730566 : Closed e1211188730566 ∧ code e1211188730566 = 5609235241670 := by decide
theorem cert_e1211188730566 : check e1211188730566 [[],[]] .smaller = true := by decide
def e1211188730590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211188730590 : Closed e1211188730590 ∧ code e1211188730590 = 5609235241694 := by decide
theorem cert_e1211188730590 : check e1211188730590 [[],[]] .three = true := by decide
def e1211188730614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211188730614 : Closed e1211188730614 ∧ code e1211188730614 = 5609235241718 := by decide
theorem cert_e1211188730614 : check e1211188730614 [[],[]] .three = true := by decide
def e1211188730646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211188730646 : Closed e1211188730646 ∧ code e1211188730646 = 5609235241750 := by decide
theorem cert_e1211188730646 : check e1211188730646 [[],[]] .smaller = true := by decide
def e1211188730650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211188730650 : Closed e1211188730650 ∧ code e1211188730650 = 5609235241754 := by decide
theorem cert_e1211188730650 : check e1211188730650 [[],[]] .smaller = true := by decide
def e1211188730694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211188730694 : Closed e1211188730694 ∧ code e1211188730694 = 5609235241798 := by decide
theorem cert_e1211188730694 : check e1211188730694 [[],[]] .smaller = true := by decide
def e1211188730718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211188730718 : Closed e1211188730718 ∧ code e1211188730718 = 5609235241822 := by decide
theorem cert_e1211188730718 : check e1211188730718 [[],[]] .three = true := by decide
def e1211188730722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211188730722 : Closed e1211188730722 ∧ code e1211188730722 = 5609235241826 := by decide
theorem cert_e1211188730722 : check e1211188730722 [[],[]] .smaller = true := by decide
def e1211188730734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211188730734 : Closed e1211188730734 ∧ code e1211188730734 = 5609235241838 := by decide
theorem cert_e1211188730734 : check e1211188730734 [[],[]] .smaller = true := by decide
def e1211188730742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211188730742 : Closed e1211188730742 ∧ code e1211188730742 = 5609235241846 := by decide
theorem cert_e1211188730742 : check e1211188730742 [[],[]] .smaller = true := by decide
def e1211188730746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211188730746 : Closed e1211188730746 ∧ code e1211188730746 = 5609235241850 := by decide
theorem cert_e1211188730746 : check e1211188730746 [[],[]] .three = true := by decide
def e1211188730806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211188730806 : Closed e1211188730806 ∧ code e1211188730806 = 5609235241910 := by decide
theorem cert_e1211188730806 : check e1211188730806 [[],[]] .smaller = true := by decide
def e1211188730838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211188730838 : Closed e1211188730838 ∧ code e1211188730838 = 5609235241942 := by decide
theorem cert_e1211188730838 : check e1211188730838 [[],[]] .three = true := by decide
def e1211188730842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211188730842 : Closed e1211188730842 ∧ code e1211188730842 = 5609235241946 := by decide
theorem cert_e1211188730842 : check e1211188730842 [[],[]] .three = true := by decide
def e1211188730966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211188730966 : Closed e1211188730966 ∧ code e1211188730966 = 5609235242070 := by decide
theorem cert_e1211188730966 : check e1211188730966 [[],[]] .smaller = true := by decide
def e1211188730970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211188730970 : Closed e1211188730970 ∧ code e1211188730970 = 5609235242074 := by decide
theorem cert_e1211188730970 : check e1211188730970 [[],[]] .smaller = true := by decide
def e1211188730986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e1211188730986 : Closed e1211188730986 ∧ code e1211188730986 = 5609235242090 := by decide
theorem cert_e1211188730986 : check e1211188730986 [[],[]] .smaller = true := by decide
def e1211188731158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211188731158 : Closed e1211188731158 ∧ code e1211188731158 = 5609235242262 := by decide
theorem cert_e1211188731158 : check e1211188731158 [[],[]] .smaller = true := by decide
def e1211188731162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211188731162 : Closed e1211188731162 ∧ code e1211188731162 = 5609235242266 := by decide
theorem cert_e1211188731162 : check e1211188731162 [[],[]] .smaller = true := by decide
def e1211188731206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211188731206 : Closed e1211188731206 ∧ code e1211188731206 = 5609235242310 := by decide
theorem cert_e1211188731206 : check e1211188731206 [[],[]] .smaller = true := by decide
def e1211188731230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211188731230 : Closed e1211188731230 ∧ code e1211188731230 = 5609235242334 := by decide
theorem cert_e1211188731230 : check e1211188731230 [[],[]] .three = true := by decide
def e1211188731234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211188731234 : Closed e1211188731234 ∧ code e1211188731234 = 5609235242338 := by decide
theorem cert_e1211188731234 : check e1211188731234 [[],[]] .smaller = true := by decide
def e1211188731246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211188731246 : Closed e1211188731246 ∧ code e1211188731246 = 5609235242350 := by decide
theorem cert_e1211188731246 : check e1211188731246 [[],[]] .smaller = true := by decide
def e1211188731254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211188731254 : Closed e1211188731254 ∧ code e1211188731254 = 5609235242358 := by decide
theorem cert_e1211188731254 : check e1211188731254 [[],[]] .smaller = true := by decide
def e1211188731258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211188731258 : Closed e1211188731258 ∧ code e1211188731258 = 5609235242362 := by decide
theorem cert_e1211188731258 : check e1211188731258 [[],[]] .three = true := by decide
def e1211188731274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188731274 : Closed e1211188731274 ∧ code e1211188731274 = 5609235242378 := by decide
theorem cert_e1211188731274 : check e1211188731274 [[],[]] .smaller = true := by decide
def e1211188731298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188731298 : Closed e1211188731298 ∧ code e1211188731298 = 5609235242402 := by decide
theorem cert_e1211188731298 : check e1211188731298 [[],[]] .smaller = true := by decide
def e1211188731310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211188731310 : Closed e1211188731310 ∧ code e1211188731310 = 5609235242414 := by decide
theorem cert_e1211188731310 : check e1211188731310 [[],[]] .smaller = true := by decide
def e1211188731322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211188731322 : Closed e1211188731322 ∧ code e1211188731322 = 5609235242426 := by decide
theorem cert_e1211188731322 : check e1211188731322 [[],[]] .smaller = true := by decide
def e1211188731350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211188731350 : Closed e1211188731350 ∧ code e1211188731350 = 5609235242454 := by decide
theorem cert_e1211188731350 : check e1211188731350 [[],[]] .smaller = true := by decide
def e1211188731354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211188731354 : Closed e1211188731354 ∧ code e1211188731354 = 5609235242458 := by decide
theorem cert_e1211188731354 : check e1211188731354 [[],[]] .smaller = true := by decide
def e1211188731370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211188731370 : Closed e1211188731370 ∧ code e1211188731370 = 5609235242474 := by decide
theorem cert_e1211188731370 : check e1211188731370 [[],[]] .three = true := by decide
def e1211188731574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211188731574 : Closed e1211188731574 ∧ code e1211188731574 = 5609235242678 := by decide
theorem cert_e1211188731574 : check e1211188731574 [[],[]] .smaller = true := by decide
def e1211188731606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211188731606 : Closed e1211188731606 ∧ code e1211188731606 = 5609235242710 := by decide
theorem cert_e1211188731606 : check e1211188731606 [[],[]] .smaller = true := by decide
def e1211188731610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211188731610 : Closed e1211188731610 ∧ code e1211188731610 = 5609235242714 := by decide
theorem cert_e1211188731610 : check e1211188731610 [[],[]] .smaller = true := by decide
def e1211188731734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211188731734 : Closed e1211188731734 ∧ code e1211188731734 = 5609235242838 := by decide
theorem cert_e1211188731734 : check e1211188731734 [[],[]] .three = true := by decide
def e1211188731738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211188731738 : Closed e1211188731738 ∧ code e1211188731738 = 5609235242842 := by decide
theorem cert_e1211188731738 : check e1211188731738 [[],[]] .three = true := by decide
def e1211188731754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211188731754 : Closed e1211188731754 ∧ code e1211188731754 = 5609235242858 := by decide
theorem cert_e1211188731754 : check e1211188731754 [[],[]] .three = true := by decide
def e1211188732150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211188732150 : Closed e1211188732150 ∧ code e1211188732150 = 5609235243254 := by decide
theorem cert_e1211188732150 : check e1211188732150 [[],[]] .smaller = true := by decide
def e1211188732342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e1211188732342 : Closed e1211188732342 ∧ code e1211188732342 = 5609235243446 := by decide
theorem cert_e1211188732342 : check e1211188732342 [[],[]] .smaller = true := by decide
def e1211188732346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e1211188732346 : Closed e1211188732346 ∧ code e1211188732346 = 5609235243450 := by decide
theorem cert_e1211188732346 : check e1211188732346 [[],[]] .smaller = true := by decide
def e1211188732374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e1211188732374 : Closed e1211188732374 ∧ code e1211188732374 = 5609235243478 := by decide
theorem cert_e1211188732374 : check e1211188732374 [[],[]] .smaller = true := by decide
def e1211188732394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e1211188732394 : Closed e1211188732394 ∧ code e1211188732394 = 5609235243498 := by decide
theorem cert_e1211188732394 : check e1211188732394 [[],[]] .smaller = true := by decide
def e1211188732534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188732534 : Closed e1211188732534 ∧ code e1211188732534 = 5609235243638 := by decide
theorem cert_e1211188732534 : check e1211188732534 [[],[]] .smaller = true := by decide
def e1211188732726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188732726 : Closed e1211188732726 ∧ code e1211188732726 = 5609235243830 := by decide
theorem cert_e1211188732726 : check e1211188732726 [[],[]] .smaller = true := by decide
def e1211188732730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188732730 : Closed e1211188732730 ∧ code e1211188732730 = 5609235243834 := by decide
theorem cert_e1211188732730 : check e1211188732730 [[],[]] .smaller = true := by decide
def e1211188732814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211188732814 : Closed e1211188732814 ∧ code e1211188732814 = 5609235243918 := by decide
theorem cert_e1211188732814 : check e1211188732814 [[],[]] .smaller = true := by decide
def e1211188732826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188732826 : Closed e1211188732826 ∧ code e1211188732826 = 5609235243930 := by decide
theorem cert_e1211188732826 : check e1211188732826 [[],[]] .smaller = true := by decide
def e1211188732894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211188732894 : Closed e1211188732894 ∧ code e1211188732894 = 5609235243998 := by decide
theorem cert_e1211188732894 : check e1211188732894 [[],[]] .three = true := by decide
def e1211188732910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211188732910 : Closed e1211188732910 ∧ code e1211188732910 = 5609235244014 := by decide
theorem cert_e1211188732910 : check e1211188732910 [[],[]] .three = true := by decide
def e1211188733494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211188733494 : Closed e1211188733494 ∧ code e1211188733494 = 5609235244598 := by decide
theorem cert_e1211188733494 : check e1211188733494 [[],[]] .smaller = true := by decide
def e1211188733498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211188733498 : Closed e1211188733498 ∧ code e1211188733498 = 5609235244602 := by decide
theorem cert_e1211188733498 : check e1211188733498 [[],[]] .smaller = true := by decide
def e1211188733582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211188733582 : Closed e1211188733582 ∧ code e1211188733582 = 5609235244686 := by decide
theorem cert_e1211188733582 : check e1211188733582 [[],[]] .smaller = true := by decide
def e1211188733638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211188733638 : Closed e1211188733638 ∧ code e1211188733638 = 5609235244742 := by decide
theorem cert_e1211188733638 : check e1211188733638 [[],[]] .smaller = true := by decide
def e1211188733662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211188733662 : Closed e1211188733662 ∧ code e1211188733662 = 5609235244766 := by decide
theorem cert_e1211188733662 : check e1211188733662 [[],[]] .three = true := by decide
def e1211188733686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211188733686 : Closed e1211188733686 ∧ code e1211188733686 = 5609235244790 := by decide
theorem cert_e1211188733686 : check e1211188733686 [[],[]] .three = true := by decide
def e1211188733718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211188733718 : Closed e1211188733718 ∧ code e1211188733718 = 5609235244822 := by decide
theorem cert_e1211188733718 : check e1211188733718 [[],[]] .smaller = true := by decide
def e1211188733722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211188733722 : Closed e1211188733722 ∧ code e1211188733722 = 5609235244826 := by decide
theorem cert_e1211188733722 : check e1211188733722 [[],[]] .smaller = true := by decide
def e1211188733766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211188733766 : Closed e1211188733766 ∧ code e1211188733766 = 5609235244870 := by decide
theorem cert_e1211188733766 : check e1211188733766 [[],[]] .smaller = true := by decide
def e1211188733790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211188733790 : Closed e1211188733790 ∧ code e1211188733790 = 5609235244894 := by decide
theorem cert_e1211188733790 : check e1211188733790 [[],[]] .three = true := by decide
def e1211188733794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211188733794 : Closed e1211188733794 ∧ code e1211188733794 = 5609235244898 := by decide
theorem cert_e1211188733794 : check e1211188733794 [[],[]] .smaller = true := by decide
def e1211188733806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211188733806 : Closed e1211188733806 ∧ code e1211188733806 = 5609235244910 := by decide
theorem cert_e1211188733806 : check e1211188733806 [[],[]] .smaller = true := by decide
def e1211188733814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211188733814 : Closed e1211188733814 ∧ code e1211188733814 = 5609235244918 := by decide
theorem cert_e1211188733814 : check e1211188733814 [[],[]] .smaller = true := by decide
def e1211188733818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211188733818 : Closed e1211188733818 ∧ code e1211188733818 = 5609235244922 := by decide
theorem cert_e1211188733818 : check e1211188733818 [[],[]] .three = true := by decide
def e1211188733878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211188733878 : Closed e1211188733878 ∧ code e1211188733878 = 5609235244982 := by decide
theorem cert_e1211188733878 : check e1211188733878 [[],[]] .smaller = true := by decide
def e1211188733910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211188733910 : Closed e1211188733910 ∧ code e1211188733910 = 5609235245014 := by decide
theorem cert_e1211188733910 : check e1211188733910 [[],[]] .three = true := by decide
def e1211188733914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211188733914 : Closed e1211188733914 ∧ code e1211188733914 = 5609235245018 := by decide
theorem cert_e1211188733914 : check e1211188733914 [[],[]] .three = true := by decide
def e1211188734062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188734062 : Closed e1211188734062 ∧ code e1211188734062 = 5609235245166 := by decide
theorem cert_e1211188734062 : check e1211188734062 [[],[]] .smaller = true := by decide
def e1211188734074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188734074 : Closed e1211188734074 ∧ code e1211188734074 = 5609235245178 := by decide
theorem cert_e1211188734074 : check e1211188734074 [[],[]] .smaller = true := by decide
def e1211188734350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211188734350 : Closed e1211188734350 ∧ code e1211188734350 = 5609235245454 := by decide
theorem cert_e1211188734350 : check e1211188734350 [[],[]] .smaller = true := by decide
def e1211188734406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211188734406 : Closed e1211188734406 ∧ code e1211188734406 = 5609235245510 := by decide
theorem cert_e1211188734406 : check e1211188734406 [[],[]] .smaller = true := by decide
def e1211188734430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211188734430 : Closed e1211188734430 ∧ code e1211188734430 = 5609235245534 := by decide
theorem cert_e1211188734430 : check e1211188734430 [[],[]] .three = true := by decide
def e1211188734454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211188734454 : Closed e1211188734454 ∧ code e1211188734454 = 5609235245558 := by decide
theorem cert_e1211188734454 : check e1211188734454 [[],[]] .three = true := by decide
def e1211188735006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211188735006 : Closed e1211188735006 ∧ code e1211188735006 = 5609235246110 := by decide
theorem cert_e1211188735006 : check e1211188735006 [[],[]] .smaller = true := by decide
def e1211188735030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188735030 : Closed e1211188735030 ∧ code e1211188735030 = 5609235246134 := by decide
theorem cert_e1211188735030 : check e1211188735030 [[],[]] .smaller = true := by decide
def e1211188735034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188735034 : Closed e1211188735034 ∧ code e1211188735034 = 5609235246138 := by decide
theorem cert_e1211188735034 : check e1211188735034 [[],[]] .smaller = true := by decide
def e1211188735174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211188735174 : Closed e1211188735174 ∧ code e1211188735174 = 5609235246278 := by decide
theorem cert_e1211188735174 : check e1211188735174 [[],[]] .smaller = true := by decide
def e1211188735198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211188735198 : Closed e1211188735198 ∧ code e1211188735198 = 5609235246302 := by decide
theorem cert_e1211188735198 : check e1211188735198 [[],[]] .three = true := by decide
def e1211188735202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211188735202 : Closed e1211188735202 ∧ code e1211188735202 = 5609235246306 := by decide
theorem cert_e1211188735202 : check e1211188735202 [[],[]] .smaller = true := by decide
def e1211188735214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211188735214 : Closed e1211188735214 ∧ code e1211188735214 = 5609235246318 := by decide
theorem cert_e1211188735214 : check e1211188735214 [[],[]] .smaller = true := by decide
def e1211188735222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211188735222 : Closed e1211188735222 ∧ code e1211188735222 = 5609235246326 := by decide
theorem cert_e1211188735222 : check e1211188735222 [[],[]] .smaller = true := by decide
def e1211188735226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211188735226 : Closed e1211188735226 ∧ code e1211188735226 = 5609235246330 := by decide
theorem cert_e1211188735226 : check e1211188735226 [[],[]] .three = true := by decide
def e1211188735550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211188735550 : Closed e1211188735550 ∧ code e1211188735550 = 5609235246654 := by decide
theorem cert_e1211188735550 : check e1211188735550 [[],[]] .three = true := by decide
def e1211188735606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188735606 : Closed e1211188735606 ∧ code e1211188735606 = 5609235246710 := by decide
theorem cert_e1211188735606 : check e1211188735606 [[],[]] .smaller = true := by decide
def e1211188735774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211188735774 : Closed e1211188735774 ∧ code e1211188735774 = 5609235246878 := by decide
theorem cert_e1211188735774 : check e1211188735774 [[],[]] .three = true := by decide
def e1211188735798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188735798 : Closed e1211188735798 ∧ code e1211188735798 = 5609235246902 := by decide
theorem cert_e1211188735798 : check e1211188735798 [[],[]] .three = true := by decide
def e1211188735802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188735802 : Closed e1211188735802 ∧ code e1211188735802 = 5609235246906 := by decide
theorem cert_e1211188735802 : check e1211188735802 [[],[]] .three = true := by decide
def e1211188736118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211188736118 : Closed e1211188736118 ∧ code e1211188736118 = 5609235247222 := by decide
theorem cert_e1211188736118 : check e1211188736118 [[],[]] .smaller = true := by decide
def e1211188736122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211188736122 : Closed e1211188736122 ∧ code e1211188736122 = 5609235247226 := by decide
theorem cert_e1211188736122 : check e1211188736122 [[],[]] .smaller = true := by decide
def e1211188736218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e1211188736218 : Closed e1211188736218 ∧ code e1211188736218 = 5609235247322 := by decide
theorem cert_e1211188736218 : check e1211188736218 [[],[]] .smaller = true := by decide
def e1211188736234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e1211188736234 : Closed e1211188736234 ∧ code e1211188736234 = 5609235247338 := by decide
theorem cert_e1211188736234 : check e1211188736234 [[],[]] .smaller = true := by decide
def e1211188736310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188736310 : Closed e1211188736310 ∧ code e1211188736310 = 5609235247414 := by decide
theorem cert_e1211188736310 : check e1211188736310 [[],[]] .smaller = true := by decide
def e1211188736314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188736314 : Closed e1211188736314 ∧ code e1211188736314 = 5609235247418 := by decide
theorem cert_e1211188736314 : check e1211188736314 [[],[]] .smaller = true := by decide
def e1211188736398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211188736398 : Closed e1211188736398 ∧ code e1211188736398 = 5609235247502 := by decide
theorem cert_e1211188736398 : check e1211188736398 [[],[]] .smaller = true := by decide
def e1211188736410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188736410 : Closed e1211188736410 ∧ code e1211188736410 = 5609235247514 := by decide
theorem cert_e1211188736410 : check e1211188736410 [[],[]] .smaller = true := by decide
def e1211188736454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211188736454 : Closed e1211188736454 ∧ code e1211188736454 = 5609235247558 := by decide
theorem cert_e1211188736454 : check e1211188736454 [[],[]] .smaller = true := by decide
def e1211188736478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211188736478 : Closed e1211188736478 ∧ code e1211188736478 = 5609235247582 := by decide
theorem cert_e1211188736478 : check e1211188736478 [[],[]] .three = true := by decide
def e1211188736502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211188736502 : Closed e1211188736502 ∧ code e1211188736502 = 5609235247606 := by decide
theorem cert_e1211188736502 : check e1211188736502 [[],[]] .three = true := by decide
def e1211188736790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211188736790 : Closed e1211188736790 ∧ code e1211188736790 = 5609235247894 := by decide
theorem cert_e1211188736790 : check e1211188736790 [[],[]] .smaller = true := by decide
def e1211188736794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211188736794 : Closed e1211188736794 ∧ code e1211188736794 = 5609235247898 := by decide
theorem cert_e1211188736794 : check e1211188736794 [[],[]] .smaller = true := by decide
def e1211188736838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211188736838 : Closed e1211188736838 ∧ code e1211188736838 = 5609235247942 := by decide
theorem cert_e1211188736838 : check e1211188736838 [[],[]] .smaller = true := by decide
end Blc.Floor42
