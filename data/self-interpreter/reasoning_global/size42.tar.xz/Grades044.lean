import Tables
import Batch044
namespace Blc.Floor42.Grades044
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1124576877934 : ¬ IsSelfInterpreter e1124576877934 := cutM6_2 (by decide)
#print axioms ex_e1124576877934
end Blc.Floor42.Grades044
