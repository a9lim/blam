import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211299056558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211299056558 : Closed e1211299056558 ∧ code e1211299056558 = 5609345567662 := by decide
def e1211299056570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211299056570 : Closed e1211299056570 ∧ code e1211299056570 = 5609345567674 := by decide
def e1211299056598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211299056598 : Closed e1211299056598 ∧ code e1211299056598 = 5609345567702 := by decide
private def t_e1211299056598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e1211299056598 : ¬ IsSelfInterpreter e1211299056598 :=
  wSource (t := t_e1211299056598) (replay_sound (ps := []) (t := e1211299056598) (by decide)) (by decide)
def e1211299056602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211299056602 : Closed e1211299056602 ∧ code e1211299056602 = 5609345567706 := by decide
def e1211299056878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211299056878 : Closed e1211299056878 ∧ code e1211299056878 = 5609345567982 := by decide
def e1211299056886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211299056886 : Closed e1211299056886 ∧ code e1211299056886 = 5609345567990 := by decide
def e1211299057262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211299057262 : Closed e1211299057262 ∧ code e1211299057262 = 5609345568366 := by decide
def e1211299057274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211299057274 : Closed e1211299057274 ∧ code e1211299057274 = 5609345568378 := by decide
def e1211299057462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211299057462 : Closed e1211299057462 ∧ code e1211299057462 = 5609345568566 := by decide
def e1211299057466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211299057466 : Closed e1211299057466 ∧ code e1211299057466 = 5609345568570 := by decide
def e1211299062238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211299062238 : Closed e1211299062238 ∧ code e1211299062238 = 5609345573342 := by decide
def e1211299062262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211299062262 : Closed e1211299062262 ∧ code e1211299062262 = 5609345573366 := by decide
def e1211299063214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211299063214 : Closed e1211299063214 ∧ code e1211299063214 = 5609345574318 := by decide
def e1211299063226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211299063226 : Closed e1211299063226 ∧ code e1211299063226 = 5609345574330 := by decide
def e1211299063274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211299063274 : Closed e1211299063274 ∧ code e1211299063274 = 5609345574378 := by decide
def e1211299063406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211299063406 : Closed e1211299063406 ∧ code e1211299063406 = 5609345574510 := by decide
def e1211299063418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211299063418 : Closed e1211299063418 ∧ code e1211299063418 = 5609345574522 := by decide
def e1211299063582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211299063582 : Closed e1211299063582 ∧ code e1211299063582 = 5609345574686 := by decide
theorem cert_e1211299063582 : checkPay e1211299063582 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e1211299063682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211299063682 : Closed e1211299063682 ∧ code e1211299063682 = 5609345574786 := by decide
theorem cert_e1211299063682 : checkPay e1211299063682 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 1 [[],[.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211299063694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211299063694 : Closed e1211299063694 ∧ code e1211299063694 = 5609345574798 := by decide
theorem cert_e1211299063694 : checkPay e1211299063694 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [[],[.under]] = true := by decide
def e1211299063706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211299063706 : Closed e1211299063706 ∧ code e1211299063706 = 5609345574810 := by decide
def e1211299066094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211299066094 : Closed e1211299066094 ∧ code e1211299066094 = 5609345577198 := by decide
theorem cert_e1211299066094 : check e1211299066094 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .chain = true := by decide
def e1211299066102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211299066102 : Closed e1211299066102 ∧ code e1211299066102 = 5609345577206 := by decide
theorem cert_e1211299066102 : check e1211299066102 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .chain = true := by decide
def e1211299066582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211299066582 : Closed e1211299066582 ∧ code e1211299066582 = 5609345577686 := by decide
private def t_e1211299066582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem cert_e1211299066582 : ¬ IsSelfInterpreter e1211299066582 :=
  wSource (t := t_e1211299066582) (replay_sound (ps := []) (t := e1211299066582) (by decide)) (by decide)
def e1211299066586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211299066586 : Closed e1211299066586 ∧ code e1211299066586 = 5609345577690 := by decide
theorem cert_e1211299066586 : check e1211299066586 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211299066602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211299066602 : Closed e1211299066602 ∧ code e1211299066602 = 5609345577706 := by decide
theorem cert_e1211299066602 : check e1211299066602 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211299066678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211299066678 : Closed e1211299066678 ∧ code e1211299066678 = 5609345577782 := by decide
def e1211299066682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211299066682 : Closed e1211299066682 ∧ code e1211299066682 = 5609345577786 := by decide
def e1211299066754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211299066754 : Closed e1211299066754 ∧ code e1211299066754 = 5609345577858 := by decide
theorem cert_e1211299066754 : check e1211299066754 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e1211299066766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211299066766 : Closed e1211299066766 ∧ code e1211299066766 = 5609345577870 := by decide
theorem cert_e1211299066766 : checkPay e1211299066766 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[]] 0 [] = true := by decide
def e1211299066778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211299066778 : Closed e1211299066778 ∧ code e1211299066778 = 5609345577882 := by decide
def e1211299137470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211299137470 : Closed e1211299137470 ∧ code e1211299137470 = 5609345648574 := by decide
theorem cert_e1211299137470 : check e1211299137470 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299137518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211299137518 : Closed e1211299137518 ∧ code e1211299137518 = 5609345648622 := by decide
theorem cert_e1211299137518 : check e1211299137518 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299141342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211299141342 : Closed e1211299141342 ∧ code e1211299141342 = 5609345652446 := by decide
theorem cert_e1211299141342 : check e1211299141342 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299141366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211299141366 : Closed e1211299141366 ∧ code e1211299141366 = 5609345652470 := by decide
theorem cert_e1211299141366 : check e1211299141366 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299141470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211299141470 : Closed e1211299141470 ∧ code e1211299141470 = 5609345652574 := by decide
theorem cert_e1211299141470 : check e1211299141470 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299141498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211299141498 : Closed e1211299141498 ∧ code e1211299141498 = 5609345652602 := by decide
theorem cert_e1211299141498 : check e1211299141498 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299141590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211299141590 : Closed e1211299141590 ∧ code e1211299141590 = 5609345652694 := by decide
theorem cert_e1211299141590 : check e1211299141590 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299141594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211299141594 : Closed e1211299141594 ∧ code e1211299141594 = 5609345652698 := by decide
theorem cert_e1211299141594 : check e1211299141594 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299142110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211299142110 : Closed e1211299142110 ∧ code e1211299142110 = 5609345653214 := by decide
theorem cert_e1211299142110 : check e1211299142110 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299142134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211299142134 : Closed e1211299142134 ∧ code e1211299142134 = 5609345653238 := by decide
theorem cert_e1211299142134 : check e1211299142134 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299142878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211299142878 : Closed e1211299142878 ∧ code e1211299142878 = 5609345653982 := by decide
theorem cert_e1211299142878 : check e1211299142878 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299142906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211299142906 : Closed e1211299142906 ∧ code e1211299142906 = 5609345654010 := by decide
theorem cert_e1211299142906 : check e1211299142906 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299143478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211299143478 : Closed e1211299143478 ∧ code e1211299143478 = 5609345654582 := by decide
theorem cert_e1211299143478 : check e1211299143478 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299143482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211299143482 : Closed e1211299143482 ∧ code e1211299143482 = 5609345654586 := by decide
theorem cert_e1211299143482 : check e1211299143482 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299157678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211299157678 : Closed e1211299157678 ∧ code e1211299157678 = 5609345668782 := by decide
theorem cert_e1211299157678 : check e1211299157678 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299157690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211299157690 : Closed e1211299157690 ∧ code e1211299157690 = 5609345668794 := by decide
theorem cert_e1211299157690 : check e1211299157690 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299157738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211299157738 : Closed e1211299157738 ∧ code e1211299157738 = 5609345668842 := by decide
theorem cert_e1211299157738 : check e1211299157738 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299157930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211299157930 : Closed e1211299157930 ∧ code e1211299157930 = 5609345669034 := by decide
theorem cert_e1211299157930 : check e1211299157930 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e1211299158062 : Closed e1211299158062 ∧ code e1211299158062 = 5609345669166 := by decide
theorem cert_e1211299158062 : check e1211299158062 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211299158254 : Closed e1211299158254 ∧ code e1211299158254 = 5609345669358 := by decide
theorem cert_e1211299158254 : check e1211299158254 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211299158262 : Closed e1211299158262 ∧ code e1211299158262 = 5609345669366 := by decide
theorem cert_e1211299158262 : check e1211299158262 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211299158446 : Closed e1211299158446 ∧ code e1211299158446 = 5609345669550 := by decide
theorem cert_e1211299158446 : check e1211299158446 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211299158458 : Closed e1211299158458 ∧ code e1211299158458 = 5609345669562 := by decide
theorem cert_e1211299158458 : check e1211299158458 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211299158506 : Closed e1211299158506 ∧ code e1211299158506 = 5609345669610 := by decide
theorem cert_e1211299158506 : check e1211299158506 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211299158638 : Closed e1211299158638 ∧ code e1211299158638 = 5609345669742 := by decide
theorem cert_e1211299158638 : check e1211299158638 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211299158650 : Closed e1211299158650 ∧ code e1211299158650 = 5609345669754 := by decide
theorem cert_e1211299158650 : check e1211299158650 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211299158814 : Closed e1211299158814 ∧ code e1211299158814 = 5609345669918 := by decide
theorem cert_e1211299158814 : check e1211299158814 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211299158914 : Closed e1211299158914 ∧ code e1211299158914 = 5609345670018 := by decide
theorem cert_e1211299158914 : check e1211299158914 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211299158926 : Closed e1211299158926 ∧ code e1211299158926 = 5609345670030 := by decide
theorem cert_e1211299158926 : check e1211299158926 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299158938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211299158938 : Closed e1211299158938 ∧ code e1211299158938 = 5609345670042 := by decide
theorem cert_e1211299158938 : check e1211299158938 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211299159150 : Closed e1211299159150 ∧ code e1211299159150 = 5609345670254 := by decide
theorem cert_e1211299159150 : check e1211299159150 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211299159162 : Closed e1211299159162 ∧ code e1211299159162 = 5609345670266 := by decide
theorem cert_e1211299159162 : check e1211299159162 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211299159326 : Closed e1211299159326 ∧ code e1211299159326 = 5609345670430 := by decide
theorem cert_e1211299159326 : check e1211299159326 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211299159494 : Closed e1211299159494 ∧ code e1211299159494 = 5609345670598 := by decide
theorem cert_e1211299159494 : check e1211299159494 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211299159562 : Closed e1211299159562 ∧ code e1211299159562 = 5609345670666 := by decide
theorem cert_e1211299159562 : check e1211299159562 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211299159606 : Closed e1211299159606 ∧ code e1211299159606 = 5609345670710 := by decide
theorem cert_e1211299159606 : check e1211299159606 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211299159610 : Closed e1211299159610 ∧ code e1211299159610 = 5609345670714 := by decide
theorem cert_e1211299159610 : check e1211299159610 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211299159658 : Closed e1211299159658 ∧ code e1211299159658 = 5609345670762 := by decide
theorem cert_e1211299159658 : check e1211299159658 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211299159682 : Closed e1211299159682 ∧ code e1211299159682 = 5609345670786 := by decide
theorem cert_e1211299159682 : check e1211299159682 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211299159694 : Closed e1211299159694 ∧ code e1211299159694 = 5609345670798 := by decide
theorem cert_e1211299159694 : check e1211299159694 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211299159706 : Closed e1211299159706 ∧ code e1211299159706 = 5609345670810 := by decide
theorem cert_e1211299159706 : check e1211299159706 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299159750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211299159750 : Closed e1211299159750 ∧ code e1211299159750 = 5609345670854 := by decide
theorem cert_e1211299159750 : check e1211299159750 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299160542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211299160542 : Closed e1211299160542 ∧ code e1211299160542 = 5609345671646 := by decide
theorem cert_e1211299160542 : check e1211299160542 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299160566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211299160566 : Closed e1211299160566 ∧ code e1211299160566 = 5609345671670 := by decide
theorem cert_e1211299160566 : check e1211299160566 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211299161518 : Closed e1211299161518 ∧ code e1211299161518 = 5609345672622 := by decide
theorem cert_e1211299161518 : check e1211299161518 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211299161530 : Closed e1211299161530 ∧ code e1211299161530 = 5609345672634 := by decide
theorem cert_e1211299161530 : check e1211299161530 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211299161578 : Closed e1211299161578 ∧ code e1211299161578 = 5609345672682 := by decide
theorem cert_e1211299161578 : check e1211299161578 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211299161710 : Closed e1211299161710 ∧ code e1211299161710 = 5609345672814 := by decide
theorem cert_e1211299161710 : check e1211299161710 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211299161722 : Closed e1211299161722 ∧ code e1211299161722 = 5609345672826 := by decide
theorem cert_e1211299161722 : check e1211299161722 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211299161886 : Closed e1211299161886 ∧ code e1211299161886 = 5609345672990 := by decide
theorem cert_e1211299161886 : check e1211299161886 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211299161986 : Closed e1211299161986 ∧ code e1211299161986 = 5609345673090 := by decide
theorem cert_e1211299161986 : check e1211299161986 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299161998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211299161998 : Closed e1211299161998 ∧ code e1211299161998 = 5609345673102 := by decide
theorem cert_e1211299161998 : check e1211299161998 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299162010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211299162010 : Closed e1211299162010 ∧ code e1211299162010 = 5609345673114 := by decide
theorem cert_e1211299162010 : check e1211299162010 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299164958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211299164958 : Closed e1211299164958 ∧ code e1211299164958 = 5609345676062 := by decide
theorem cert_e1211299164958 : check e1211299164958 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299165126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211299165126 : Closed e1211299165126 ∧ code e1211299165126 = 5609345676230 := by decide
theorem cert_e1211299165126 : check e1211299165126 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299166326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211299166326 : Closed e1211299166326 ∧ code e1211299166326 = 5609345677430 := by decide
theorem cert_e1211299166326 : check e1211299166326 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299166570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211299166570 : Closed e1211299166570 ∧ code e1211299166570 = 5609345677674 := by decide
theorem cert_e1211299166570 : check e1211299166570 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299166594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211299166594 : Closed e1211299166594 ∧ code e1211299166594 = 5609345677698 := by decide
theorem cert_e1211299166594 : check e1211299166594 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299166606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211299166606 : Closed e1211299166606 ∧ code e1211299166606 = 5609345677710 := by decide
theorem cert_e1211299166606 : check e1211299166606 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299166618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211299166618 : Closed e1211299166618 ∧ code e1211299166618 = 5609345677722 := by decide
theorem cert_e1211299166618 : check e1211299166618 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299166662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211299166662 : Closed e1211299166662 ∧ code e1211299166662 = 5609345677766 := by decide
theorem cert_e1211299166662 : check e1211299166662 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e1211299202014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211299202014 : Closed e1211299202014 ∧ code e1211299202014 = 5609345713118 := by decide
theorem cert_e1211299202014 : check e1211299202014 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299202030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211299202030 : Closed e1211299202030 ∧ code e1211299202030 = 5609345713134 := by decide
theorem cert_e1211299202030 : check e1211299202030 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299203950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211299203950 : Closed e1211299203950 ∧ code e1211299203950 = 5609345715054 := by decide
private def t_e1211299203950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e1211299203950 : ¬ IsSelfInterpreter e1211299203950 :=
  wSource (t := t_e1211299203950) (replay_sound (ps := []) (t := e1211299203950) (by decide)) (by decide)
def e1211299203958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211299203958 : Closed e1211299203958 ∧ code e1211299203958 = 5609345715062 := by decide
theorem cert_e1211299203958 : check e1211299203958 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211299204014 : Closed e1211299204014 ∧ code e1211299204014 = 5609345715118 := by decide
private def t_e1211299204014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e1211299204014 : ¬ IsSelfInterpreter e1211299204014 :=
  wSource (t := t_e1211299204014) (replay_sound (ps := []) (t := e1211299204014) (by decide)) (by decide)
def e1211299204026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211299204026 : Closed e1211299204026 ∧ code e1211299204026 = 5609345715130 := by decide
theorem cert_e1211299204026 : check e1211299204026 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211299204054 : Closed e1211299204054 ∧ code e1211299204054 = 5609345715158 := by decide
theorem cert_e1211299204054 : check e1211299204054 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211299204058 : Closed e1211299204058 ∧ code e1211299204058 = 5609345715162 := by decide
theorem cert_e1211299204058 : check e1211299204058 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211299204334 : Closed e1211299204334 ∧ code e1211299204334 = 5609345715438 := by decide
theorem cert_e1211299204334 : check e1211299204334 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211299204342 : Closed e1211299204342 ∧ code e1211299204342 = 5609345715446 := by decide
theorem cert_e1211299204342 : check e1211299204342 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211299204718 : Closed e1211299204718 ∧ code e1211299204718 = 5609345715822 := by decide
theorem cert_e1211299204718 : check e1211299204718 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211299204730 : Closed e1211299204730 ∧ code e1211299204730 = 5609345715834 := by decide
theorem cert_e1211299204730 : check e1211299204730 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211299204918 : Closed e1211299204918 ∧ code e1211299204918 = 5609345716022 := by decide
theorem cert_e1211299204918 : check e1211299204918 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299204922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211299204922 : Closed e1211299204922 ∧ code e1211299204922 = 5609345716026 := by decide
theorem cert_e1211299204922 : check e1211299204922 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211299212118 : Closed e1211299212118 ∧ code e1211299212118 = 5609345723222 := by decide
private def t_e1211299212118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem cert_e1211299212118 : ¬ IsSelfInterpreter e1211299212118 :=
  wSource (t := t_e1211299212118) (replay_sound (ps := []) (t := e1211299212118) (by decide)) (by decide)
def e1211299212122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211299212122 : Closed e1211299212122 ∧ code e1211299212122 = 5609345723226 := by decide
private def t_e1211299212122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem cert_e1211299212122 : ¬ IsSelfInterpreter e1211299212122 :=
  wSource (t := t_e1211299212122) (replay_sound (ps := []) (t := e1211299212122) (by decide)) (by decide)
def e1211299212138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211299212138 : Closed e1211299212138 ∧ code e1211299212138 = 5609345723242 := by decide
theorem cert_e1211299212138 : check e1211299212138 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e1211299212202 : Closed e1211299212202 ∧ code e1211299212202 = 5609345723306 := by decide
theorem cert_e1211299212202 : check e1211299212202 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211299212310 : Closed e1211299212310 ∧ code e1211299212310 = 5609345723414 := by decide
theorem cert_e1211299212310 : check e1211299212310 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211299212406 : Closed e1211299212406 ∧ code e1211299212406 = 5609345723510 := by decide
theorem cert_e1211299212406 : check e1211299212406 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211299212502 : Closed e1211299212502 ∧ code e1211299212502 = 5609345723606 := by decide
private def t_e1211299212502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem cert_e1211299212502 : ¬ IsSelfInterpreter e1211299212502 :=
  wSource (t := t_e1211299212502) (replay_sound (ps := []) (t := e1211299212502) (by decide)) (by decide)
def e1211299212506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211299212506 : Closed e1211299212506 ∧ code e1211299212506 = 5609345723610 := by decide
theorem cert_e1211299212506 : check e1211299212506 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211299212522 : Closed e1211299212522 ∧ code e1211299212522 = 5609345723626 := by decide
theorem cert_e1211299212522 : check e1211299212522 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211299212598 : Closed e1211299212598 ∧ code e1211299212598 = 5609345723702 := by decide
private def t_e1211299212598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211299212598 : ¬ IsSelfInterpreter e1211299212598 :=
  wSource (t := t_e1211299212598) (replay_sound (ps := []) (t := e1211299212598) (by decide)) (by decide)
def e1211299212602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211299212602 : Closed e1211299212602 ∧ code e1211299212602 = 5609345723706 := by decide
private def t_e1211299212602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211299212602 : ¬ IsSelfInterpreter e1211299212602 :=
  wSource (t := t_e1211299212602) (replay_sound (ps := []) (t := e1211299212602) (by decide)) (by decide)
def e1211299212674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211299212674 : Closed e1211299212674 ∧ code e1211299212674 = 5609345723778 := by decide
theorem cert_e1211299212674 : check e1211299212674 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211299212686 : Closed e1211299212686 ∧ code e1211299212686 = 5609345723790 := by decide
theorem cert_e1211299212686 : check e1211299212686 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211299212698 : Closed e1211299212698 ∧ code e1211299212698 = 5609345723802 := by decide
theorem cert_e1211299212698 : check e1211299212698 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211299212810 : Closed e1211299212810 ∧ code e1211299212810 = 5609345723914 := by decide
theorem cert_e1211299212810 : check e1211299212810 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211299212854 : Closed e1211299212854 ∧ code e1211299212854 = 5609345723958 := by decide
theorem cert_e1211299212854 : check e1211299212854 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211299212858 : Closed e1211299212858 ∧ code e1211299212858 = 5609345723962 := by decide
theorem cert_e1211299212858 : check e1211299212858 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e1211299212906 : Closed e1211299212906 ∧ code e1211299212906 = 5609345724010 := by decide
theorem cert_e1211299212906 : check e1211299212906 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211299212930 : Closed e1211299212930 ∧ code e1211299212930 = 5609345724034 := by decide
theorem cert_e1211299212930 : check e1211299212930 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211299212942 : Closed e1211299212942 ∧ code e1211299212942 = 5609345724046 := by decide
theorem cert_e1211299212942 : check e1211299212942 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211299212954 : Closed e1211299212954 ∧ code e1211299212954 = 5609345724058 := by decide
theorem cert_e1211299212954 : check e1211299212954 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299212998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211299212998 : Closed e1211299212998 ∧ code e1211299212998 = 5609345724102 := by decide
theorem cert_e1211299212998 : check e1211299212998 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299213550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211299213550 : Closed e1211299213550 ∧ code e1211299213550 = 5609345724654 := by decide
theorem cert_e1211299213550 : check e1211299213550 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299213558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211299213558 : Closed e1211299213558 ∧ code e1211299213558 = 5609345724662 := by decide
theorem cert_e1211299213558 : check e1211299213558 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211299214038 : Closed e1211299214038 ∧ code e1211299214038 = 5609345725142 := by decide
private def t_e1211299214038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem cert_e1211299214038 : ¬ IsSelfInterpreter e1211299214038 :=
  wSource (t := t_e1211299214038) (replay_sound (ps := []) (t := e1211299214038) (by decide)) (by decide)
def e1211299214042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211299214042 : Closed e1211299214042 ∧ code e1211299214042 = 5609345725146 := by decide
theorem cert_e1211299214042 : check e1211299214042 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211299214058 : Closed e1211299214058 ∧ code e1211299214058 = 5609345725162 := by decide
theorem cert_e1211299214058 : check e1211299214058 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211299214134 : Closed e1211299214134 ∧ code e1211299214134 = 5609345725238 := by decide
theorem cert_e1211299214134 : check e1211299214134 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211299214138 : Closed e1211299214138 ∧ code e1211299214138 = 5609345725242 := by decide
theorem cert_e1211299214138 : check e1211299214138 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211299214210 : Closed e1211299214210 ∧ code e1211299214210 = 5609345725314 := by decide
theorem cert_e1211299214210 : check e1211299214210 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211299214222 : Closed e1211299214222 ∧ code e1211299214222 = 5609345725326 := by decide
theorem cert_e1211299214222 : check e1211299214222 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299214234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211299214234 : Closed e1211299214234 ∧ code e1211299214234 = 5609345725338 := by decide
theorem cert_e1211299214234 : check e1211299214234 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299215478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211299215478 : Closed e1211299215478 ∧ code e1211299215478 = 5609345726582 := by decide
theorem cert_e1211299215478 : check e1211299215478 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299215722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211299215722 : Closed e1211299215722 ∧ code e1211299215722 = 5609345726826 := by decide
theorem cert_e1211299215722 : check e1211299215722 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299215746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211299215746 : Closed e1211299215746 ∧ code e1211299215746 = 5609345726850 := by decide
theorem cert_e1211299215746 : check e1211299215746 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299215758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211299215758 : Closed e1211299215758 ∧ code e1211299215758 = 5609345726862 := by decide
theorem cert_e1211299215758 : check e1211299215758 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299215770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211299215770 : Closed e1211299215770 ∧ code e1211299215770 = 5609345726874 := by decide
theorem cert_e1211299215770 : check e1211299215770 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211299215814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211299215814 : Closed e1211299215814 ∧ code e1211299215814 = 5609345726918 := by decide
theorem cert_e1211299215814 : check e1211299215814 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e1211301113274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211301113274 : Closed e1211301113274 ∧ code e1211301113274 = 5609347624378 := by decide
theorem cert_e1211301113274 : check e1211301113274 [[],[],[.under]] .sourceHead = true := by decide
def e1211301113306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211301113306 : Closed e1211301113306 ∧ code e1211301113306 = 5609347624410 := by decide
theorem cert_e1211301113306 : check e1211301113306 [[],[],[.under]] .sourceHead = true := by decide
def e1211301113530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211301113530 : Closed e1211301113530 ∧ code e1211301113530 = 5609347624634 := by decide
theorem cert_e1211301113530 : check e1211301113530 [[],[],[.under]] .sourceHead = true := by decide
def e1211301113578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211301113578 : Closed e1211301113578 ∧ code e1211301113578 = 5609347624682 := by decide
theorem cert_e1211301113578 : check e1211301113578 [[],[],[.under]] .sourceHead = true := by decide
def e1211301113690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211301113690 : Closed e1211301113690 ∧ code e1211301113690 = 5609347624794 := by decide
theorem cert_e1211301113690 : check e1211301113690 [[],[],[.under]] .sourceHead = true := by decide
def e1211301113706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211301113706 : Closed e1211301113706 ∧ code e1211301113706 = 5609347624810 := by decide
theorem cert_e1211301113706 : check e1211301113706 [[],[],[.under]] .sourceHead = true := by decide
def e1211301114810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211301114810 : Closed e1211301114810 ∧ code e1211301114810 = 5609347625914 := by decide
theorem cert_e1211301114810 : check e1211301114810 [[],[],[.under]] .sourceHead = true := by decide
def e1211301114842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211301114842 : Closed e1211301114842 ∧ code e1211301114842 = 5609347625946 := by decide
theorem cert_e1211301114842 : check e1211301114842 [[],[],[.under]] .sourceHead = true := by decide
def e1211301116346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211301116346 : Closed e1211301116346 ∧ code e1211301116346 = 5609347627450 := by decide
theorem cert_e1211301116346 : check e1211301116346 [[],[],[.under]] .sourceHead = true := by decide
def e1211301116394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211301116394 : Closed e1211301116394 ∧ code e1211301116394 = 5609347627498 := by decide
theorem cert_e1211301116394 : check e1211301116394 [[],[],[.under]] .sourceHead = true := by decide
def e1211301117146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211301117146 : Closed e1211301117146 ∧ code e1211301117146 = 5609347628250 := by decide
theorem cert_e1211301117146 : check e1211301117146 [[],[],[.under]] .sourceHead = true := by decide
def e1211301117162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211301117162 : Closed e1211301117162 ∧ code e1211301117162 = 5609347628266 := by decide
theorem cert_e1211301117162 : check e1211301117162 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211301170030 : Closed e1211301170030 ∧ code e1211301170030 = 5609347681134 := by decide
theorem cert_e1211301170030 : check e1211301170030 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211301170038 : Closed e1211301170038 ∧ code e1211301170038 = 5609347681142 := by decide
theorem cert_e1211301170038 : check e1211301170038 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211301170094 : Closed e1211301170094 ∧ code e1211301170094 = 5609347681198 := by decide
theorem cert_e1211301170094 : check e1211301170094 [[],[],[.under]] .sourceHead = true := by decide
def e1211301170106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211301170106 : Closed e1211301170106 ∧ code e1211301170106 = 5609347681210 := by decide
theorem cert_e1211301170106 : check e1211301170106 [[],[],[.under]] .sourceHead = true := by decide
end Blc.Floor42
