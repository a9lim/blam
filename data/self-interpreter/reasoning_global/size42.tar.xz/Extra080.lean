import Batch080
import ExtraBase
namespace Blc.Floor42.Extra080
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1196691054038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem ex_e1196691054038 : ¬ IsSelfInterpreter e1196691054038 := by
  intro he
  have hp := replay_sound (t := e1196691054038) (u := t_e1196691054038) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 1)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691054038
private def t_e1196691054294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem ex_e1196691054294 : ¬ IsSelfInterpreter e1196691054294 := by
  intro he
  have hp := replay_sound (t := e1196691054294) (u := t_e1196691054294) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 1)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691054294
private def t_e1196691056502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem ex_e1196691056502 : ¬ IsSelfInterpreter e1196691056502 := by
  intro he
  have hp := replay_sound (t := e1196691056502) (u := t_e1196691056502) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 1)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691056502
private def t_e1196691056566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem ex_e1196691056566 : ¬ IsSelfInterpreter e1196691056566 := by
  intro he
  have hp := replay_sound (t := e1196691056566) (u := t_e1196691056566) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 1)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691056566
private def t_e1196691229550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem ex_e1196691229550 : ¬ IsSelfInterpreter e1196691229550 := by
  intro he
  have hp := replay_sound (t := e1196691229550) (u := t_e1196691229550) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 2 (by decide : Closed t_e1196691229550) (by decide) (by decide) hj
#print axioms ex_e1196691229550
private def t_e1196691229558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem ex_e1196691229558 : ¬ IsSelfInterpreter e1196691229558 := by
  intro he
  have hp := replay_sound (t := e1196691229558) (u := t_e1196691229558) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 2 (by decide : Closed t_e1196691229558) (by decide) (by decide) hj
#print axioms ex_e1196691229558
private def t_e1196691229614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem ex_e1196691229614 : ¬ IsSelfInterpreter e1196691229614 := by
  intro he
  have hp := replay_sound (t := e1196691229614) (u := t_e1196691229614) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 2 (by decide : Closed t_e1196691229614) (by decide) (by decide) hj
#print axioms ex_e1196691229614
private def t_e1196691229626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem ex_e1196691229626 : ¬ IsSelfInterpreter e1196691229626 := by
  intro he
  have hp := replay_sound (t := e1196691229626) (u := t_e1196691229626) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691229626
private def t_e1196691229654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem ex_e1196691229654 : ¬ IsSelfInterpreter e1196691229654 := by
  intro he
  have hp := replay_sound (t := e1196691229654) (u := t_e1196691229654) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 2 (by decide : Closed t_e1196691229654) (by decide) (by decide) hj
#print axioms ex_e1196691229654
private def t_e1196691229658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1196691229658 : ¬ IsSelfInterpreter e1196691229658 := by
  intro he
  have hp := replay_sound (t := e1196691229658) (u := t_e1196691229658) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691229658
private def t_e1196691229934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem ex_e1196691229934 : ¬ IsSelfInterpreter e1196691229934 := by
  intro he
  have hp := replay_sound (t := e1196691229934) (u := t_e1196691229934) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691229934
private def t_e1196691229942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1196691229942 : ¬ IsSelfInterpreter e1196691229942 := by
  intro he
  have hp := replay_sound (t := e1196691229942) (u := t_e1196691229942) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691229942
private def t_e1196691230318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem ex_e1196691230318 : ¬ IsSelfInterpreter e1196691230318 := by
  intro he
  have hp := replay_sound (t := e1196691230318) (u := t_e1196691230318) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 2 (by decide : Closed t_e1196691230318) (by decide) (by decide) hj
#print axioms ex_e1196691230318
private def t_e1196691230330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem ex_e1196691230330 : ¬ IsSelfInterpreter e1196691230330 := by
  intro he
  have hp := replay_sound (t := e1196691230330) (u := t_e1196691230330) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 2 (by decide : Closed t_e1196691230330) (by decide) (by decide) hj
#print axioms ex_e1196691230330
private def t_e1196691303866 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691303866 : ¬ IsSelfInterpreter e1196691303866 := by
  intro he
  have hp := replay_sound (t := (.app e1196691303866 diag)) (u := t_e1196691303866) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691303866) (by decide) (by decide) hj
#print axioms ex_e1196691303866
private def t_e1196691304122 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691304122 : ¬ IsSelfInterpreter e1196691304122 := by
  intro he
  have hp := replay_sound (t := (.app e1196691304122 diag)) (u := t_e1196691304122) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691304122) (by decide) (by decide) hj
#print axioms ex_e1196691304122
private def t_e1196691304170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem ex_e1196691304170 : ¬ IsSelfInterpreter e1196691304170 := by
  intro he
  have hp := replay_sound (t := e1196691304170) (u := t_e1196691304170) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691304170
private def t_e1196691304298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem ex_e1196691304298 : ¬ IsSelfInterpreter e1196691304298 := by
  intro he
  have hp := replay_sound (t := e1196691304298) (u := t_e1196691304298) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691304298
private def t_e1196691305402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem ex_e1196691305402 : ¬ IsSelfInterpreter e1196691305402 := by
  intro he
  have hp := replay_sound (t := e1196691305402) (u := t_e1196691305402) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691305402
private def t_e1196691305434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem ex_e1196691305434 : ¬ IsSelfInterpreter e1196691305434 := by
  intro he
  have hp := replay_sound (t := e1196691305434) (u := t_e1196691305434) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691305434
private def t_e1196691306938 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691306938 : ¬ IsSelfInterpreter e1196691306938 := by
  intro he
  have hp := replay_sound (t := (.app e1196691306938 diag)) (u := t_e1196691306938) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691306938) (by decide) (by decide) hj
#print axioms ex_e1196691306938
private def t_e1196691306986 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691306986 : ¬ IsSelfInterpreter e1196691306986 := by
  intro he
  have hp := replay_sound (t := (.app e1196691306986 diag)) (u := t_e1196691306986) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691306986) (by decide) (by decide) hj
#print axioms ex_e1196691306986
private def t_e1196691307738 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691307738 : ¬ IsSelfInterpreter e1196691307738 := by
  intro he
  have hp := replay_sound (t := (.app e1196691307738 diag)) (u := t_e1196691307738) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691307738) (by decide) (by decide) hj
#print axioms ex_e1196691307738
private def t_e1196691307754 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691307754 : ¬ IsSelfInterpreter e1196691307754 := by
  intro he
  have hp := replay_sound (t := (.app e1196691307754 diag)) (u := t_e1196691307754) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691307754) (by decide) (by decide) hj
#print axioms ex_e1196691307754
private def t_e1196691360630 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691360630 : ¬ IsSelfInterpreter e1196691360630 := by
  intro he
  have hp := replay_sound (t := (.app e1196691360630 diag)) (u := t_e1196691360630) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691360630) (by decide) (by decide) hj
#print axioms ex_e1196691360630
private def t_e1196691360698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem ex_e1196691360698 : ¬ IsSelfInterpreter e1196691360698 := by
  intro he
  have hp := replay_sound (t := e1196691360698) (u := t_e1196691360698) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691360698
private def t_e1196691360726 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691360726 : ¬ IsSelfInterpreter e1196691360726 := by
  intro he
  have hp := replay_sound (t := (.app e1196691360726 diag)) (u := t_e1196691360726) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691360726) (by decide) (by decide) hj
#print axioms ex_e1196691360726
private def t_e1196691360730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1196691360730 : ¬ IsSelfInterpreter e1196691360730 := by
  intro he
  have hp := replay_sound (t := e1196691360730) (u := t_e1196691360730) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691360730
private def t_e1196691361006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem ex_e1196691361006 : ¬ IsSelfInterpreter e1196691361006 := by
  intro he
  have hp := replay_sound (t := e1196691361006) (u := t_e1196691361006) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691361006
private def t_e1196691361014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1196691361014 : ¬ IsSelfInterpreter e1196691361014 := by
  intro he
  have hp := replay_sound (t := e1196691361014) (u := t_e1196691361014) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196691361014
private def t_e1196691361390 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691361390 : ¬ IsSelfInterpreter e1196691361390 := by
  intro he
  have hp := replay_sound (t := (.app e1196691361390 diag)) (u := t_e1196691361390) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691361390) (by decide) (by decide) hj
#print axioms ex_e1196691361390
private def t_e1196691361402 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1196691361402 : ¬ IsSelfInterpreter e1196691361402 := by
  intro he
  have hp := replay_sound (t := (.app e1196691361402 diag)) (u := t_e1196691361402) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1196691361402) (by decide) (by decide) hj
#print axioms ex_e1196691361402
end Blc.Floor42.Extra080
