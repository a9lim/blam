import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e276335280854 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276335280854 : Closed e276335280854 ∧ code e276335280854 = 4674381791958 := by decide
theorem cert_e276335280854 : check e276335280854 [[.under]] .three = true := by decide
def e276335280858 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276335280858 : Closed e276335280858 ∧ code e276335280858 = 4674381791962 := by decide
theorem cert_e276335280858 : check e276335280858 [[.under]] .three = true := by decide
def e276335280874 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276335280874 : Closed e276335280874 ∧ code e276335280874 = 4674381791978 := by decide
theorem cert_e276335280874 : check e276335280874 [[.under]] .three = true := by decide
def e276335280950 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276335280950 : Closed e276335280950 ∧ code e276335280950 = 4674381792054 := by decide
theorem cert_e276335280950 : check e276335280950 [[.under]] .three = true := by decide
def e276335280954 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276335280954 : Closed e276335280954 ∧ code e276335280954 = 4674381792058 := by decide
theorem cert_e276335280954 : check e276335280954 [[.under]] .three = true := by decide
def e276335281050 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276335281050 : Closed e276335281050 ∧ code e276335281050 = 4674381792154 := by decide
theorem cert_e276335281050 : check e276335281050 [[.under]] .three = true := by decide
def e276336329430 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276336329430 : Closed e276336329430 ∧ code e276336329430 = 4674382840534 := by decide
theorem cert_e276336329430 : check e276336329430 [[.under]] .three = true := by decide
def e276336329434 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276336329434 : Closed e276336329434 ∧ code e276336329434 = 4674382840538 := by decide
theorem cert_e276336329434 : check e276336329434 [[.under]] .three = true := by decide
def e276336329450 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276336329450 : Closed e276336329450 ∧ code e276336329450 = 4674382840554 := by decide
theorem cert_e276336329450 : check e276336329450 [[.under]] .three = true := by decide
def e276336329526 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276336329526 : Closed e276336329526 ∧ code e276336329526 = 4674382840630 := by decide
theorem cert_e276336329526 : check e276336329526 [[.under]] .three = true := by decide
def e276336329530 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276336329530 : Closed e276336329530 ∧ code e276336329530 = 4674382840634 := by decide
theorem cert_e276336329530 : check e276336329530 [[.under]] .three = true := by decide
def e276336329626 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276336329626 : Closed e276336329626 ∧ code e276336329626 = 4674382840730 := by decide
theorem cert_e276336329626 : check e276336329626 [[.under]] .three = true := by decide
def e276336394966 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276336394966 : Closed e276336394966 ∧ code e276336394966 = 4674382906070 := by decide
theorem cert_e276336394966 : check e276336394966 [[.under]] .three = true := by decide
def e276336394970 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276336394970 : Closed e276336394970 ∧ code e276336394970 = 4674382906074 := by decide
theorem cert_e276336394970 : check e276336394970 [[.under]] .three = true := by decide
def e276336394986 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276336394986 : Closed e276336394986 ∧ code e276336394986 = 4674382906090 := by decide
theorem cert_e276336394986 : check e276336394986 [[.under]] .three = true := by decide
def e276336395062 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276336395062 : Closed e276336395062 ∧ code e276336395062 = 4674382906166 := by decide
theorem cert_e276336395062 : check e276336395062 [[.under]] .three = true := by decide
def e276336395066 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276336395066 : Closed e276336395066 ∧ code e276336395066 = 4674382906170 := by decide
theorem cert_e276336395066 : check e276336395066 [[.under]] .three = true := by decide
def e276336395162 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276336395162 : Closed e276336395162 ∧ code e276336395162 = 4674382906266 := by decide
theorem cert_e276336395162 : check e276336395162 [[.under]] .three = true := by decide
def e276343669462 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276343669462 : Closed e276343669462 ∧ code e276343669462 = 4674390180566 := by decide
theorem cert_e276343669462 : check e276343669462 [[.under]] .three = true := by decide
def e276343669466 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276343669466 : Closed e276343669466 ∧ code e276343669466 = 4674390180570 := by decide
theorem cert_e276343669466 : check e276343669466 [[.under]] .three = true := by decide
def e276343669482 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276343669482 : Closed e276343669482 ∧ code e276343669482 = 4674390180586 := by decide
theorem cert_e276343669482 : check e276343669482 [[.under]] .three = true := by decide
def e276343669558 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276343669558 : Closed e276343669558 ∧ code e276343669558 = 4674390180662 := by decide
theorem cert_e276343669558 : check e276343669558 [[.under]] .three = true := by decide
def e276343669562 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276343669562 : Closed e276343669562 ∧ code e276343669562 = 4674390180666 := by decide
theorem cert_e276343669562 : check e276343669562 [[.under]] .three = true := by decide
def e276343669658 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276343669658 : Closed e276343669658 ∧ code e276343669658 = 4674390180762 := by decide
theorem cert_e276343669658 : check e276343669658 [[.under]] .three = true := by decide
def e276345242326 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276345242326 : Closed e276345242326 ∧ code e276345242326 = 4674391753430 := by decide
theorem cert_e276345242326 : check e276345242326 [[.under]] .three = true := by decide
def e276345242330 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276345242330 : Closed e276345242330 ∧ code e276345242330 = 4674391753434 := by decide
theorem cert_e276345242330 : check e276345242330 [[.under]] .three = true := by decide
def e276345242346 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276345242346 : Closed e276345242346 ∧ code e276345242346 = 4674391753450 := by decide
theorem cert_e276345242346 : check e276345242346 [[.under]] .three = true := by decide
def e276345242422 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276345242422 : Closed e276345242422 ∧ code e276345242422 = 4674391753526 := by decide
theorem cert_e276345242422 : check e276345242422 [[.under]] .three = true := by decide
def e276345242426 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276345242426 : Closed e276345242426 ∧ code e276345242426 = 4674391753530 := by decide
theorem cert_e276345242426 : check e276345242426 [[.under]] .three = true := by decide
def e276345242522 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276345242522 : Closed e276345242522 ∧ code e276345242522 = 4674391753626 := by decide
theorem cert_e276345242522 : check e276345242522 [[.under]] .three = true := by decide
def e276345340630 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276345340630 : Closed e276345340630 ∧ code e276345340630 = 4674391851734 := by decide
theorem cert_e276345340630 : check e276345340630 [[.under]] .three = true := by decide
def e276345340634 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276345340634 : Closed e276345340634 ∧ code e276345340634 = 4674391851738 := by decide
theorem cert_e276345340634 : check e276345340634 [[.under]] .three = true := by decide
def e276345340650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276345340650 : Closed e276345340650 ∧ code e276345340650 = 4674391851754 := by decide
theorem cert_e276345340650 : check e276345340650 [[.under]] .three = true := by decide
def e276345340726 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276345340726 : Closed e276345340726 ∧ code e276345340726 = 4674391851830 := by decide
theorem cert_e276345340726 : check e276345340726 [[.under]] .three = true := by decide
def e276345340730 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276345340730 : Closed e276345340730 ∧ code e276345340730 = 4674391851834 := by decide
theorem cert_e276345340730 : check e276345340730 [[.under]] .three = true := by decide
def e276345340826 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276345340826 : Closed e276345340826 ∧ code e276345340826 = 4674391851930 := by decide
theorem cert_e276345340826 : check e276345340826 [[.under]] .three = true := by decide
def e276348912342 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276348912342 : Closed e276348912342 ∧ code e276348912342 = 4674395423446 := by decide
theorem cert_e276348912342 : check e276348912342 [[.under]] .three = true := by decide
def e276348912346 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276348912346 : Closed e276348912346 ∧ code e276348912346 = 4674395423450 := by decide
theorem cert_e276348912346 : check e276348912346 [[.under]] .three = true := by decide
def e276348912362 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276348912362 : Closed e276348912362 ∧ code e276348912362 = 4674395423466 := by decide
theorem cert_e276348912362 : check e276348912362 [[.under]] .three = true := by decide
def e276348912438 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276348912438 : Closed e276348912438 ∧ code e276348912438 = 4674395423542 := by decide
theorem cert_e276348912438 : check e276348912438 [[.under]] .three = true := by decide
def e276348912442 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276348912442 : Closed e276348912442 ∧ code e276348912442 = 4674395423546 := by decide
theorem cert_e276348912442 : check e276348912442 [[.under]] .three = true := by decide
def e276348912538 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276348912538 : Closed e276348912538 ∧ code e276348912538 = 4674395423642 := by decide
theorem cert_e276348912538 : check e276348912538 [[.under]] .three = true := by decide
def e276348977878 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276348977878 : Closed e276348977878 ∧ code e276348977878 = 4674395488982 := by decide
theorem cert_e276348977878 : check e276348977878 [[.under]] .three = true := by decide
def e276348977882 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276348977882 : Closed e276348977882 ∧ code e276348977882 = 4674395488986 := by decide
theorem cert_e276348977882 : check e276348977882 [[.under]] .three = true := by decide
def e276348977898 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276348977898 : Closed e276348977898 ∧ code e276348977898 = 4674395489002 := by decide
theorem cert_e276348977898 : check e276348977898 [[.under]] .three = true := by decide
def e276348977974 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276348977974 : Closed e276348977974 ∧ code e276348977974 = 4674395489078 := by decide
theorem cert_e276348977974 : check e276348977974 [[.under]] .three = true := by decide
def e276348977978 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276348977978 : Closed e276348977978 ∧ code e276348977978 = 4674395489082 := by decide
theorem cert_e276348977978 : check e276348977978 [[.under]] .three = true := by decide
def e276348978074 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276348978074 : Closed e276348978074 ∧ code e276348978074 = 4674395489178 := by decide
theorem cert_e276348978074 : check e276348978074 [[.under]] .three = true := by decide
def e276349436630 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276349436630 : Closed e276349436630 ∧ code e276349436630 = 4674395947734 := by decide
theorem cert_e276349436630 : check e276349436630 [[.under]] .three = true := by decide
def e276349436634 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276349436634 : Closed e276349436634 ∧ code e276349436634 = 4674395947738 := by decide
theorem cert_e276349436634 : check e276349436634 [[.under]] .three = true := by decide
def e276349436650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276349436650 : Closed e276349436650 ∧ code e276349436650 = 4674395947754 := by decide
theorem cert_e276349436650 : check e276349436650 [[.under]] .three = true := by decide
def e276349436726 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276349436726 : Closed e276349436726 ∧ code e276349436726 = 4674395947830 := by decide
theorem cert_e276349436726 : check e276349436726 [[.under]] .three = true := by decide
def e276349436730 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276349436730 : Closed e276349436730 ∧ code e276349436730 = 4674395947834 := by decide
theorem cert_e276349436730 : check e276349436730 [[.under]] .three = true := by decide
def e276349436826 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276349436826 : Closed e276349436826 ∧ code e276349436826 = 4674395947930 := by decide
theorem cert_e276349436826 : check e276349436826 [[.under]] .three = true := by decide
def e276349534934 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276349534934 : Closed e276349534934 ∧ code e276349534934 = 4674396046038 := by decide
theorem cert_e276349534934 : check e276349534934 [[.under]] .three = true := by decide
def e276349534938 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276349534938 : Closed e276349534938 ∧ code e276349534938 = 4674396046042 := by decide
theorem cert_e276349534938 : check e276349534938 [[.under]] .three = true := by decide
def e276349534954 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276349534954 : Closed e276349534954 ∧ code e276349534954 = 4674396046058 := by decide
theorem cert_e276349534954 : check e276349534954 [[.under]] .three = true := by decide
def e276349535030 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276349535030 : Closed e276349535030 ∧ code e276349535030 = 4674396046134 := by decide
theorem cert_e276349535030 : check e276349535030 [[.under]] .three = true := by decide
def e276349535034 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276349535034 : Closed e276349535034 ∧ code e276349535034 = 4674396046138 := by decide
theorem cert_e276349535034 : check e276349535034 [[.under]] .three = true := by decide
def e276349535130 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276349535130 : Closed e276349535130 ∧ code e276349535130 = 4674396046234 := by decide
theorem cert_e276349535130 : check e276349535130 [[.under]] .three = true := by decide
def e276349764310 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276349764310 : Closed e276349764310 ∧ code e276349764310 = 4674396275414 := by decide
private def t_e276349764310 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e276349764310 : ¬ IsSelfInterpreter e276349764310 :=
  wSource (t := t_e276349764310) (replay_sound (ps := []) (t := e276349764310) (by decide)) (by decide)
def e276349764314 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276349764314 : Closed e276349764314 ∧ code e276349764314 = 4674396275418 := by decide
theorem cert_e276349764314 : check e276349764314 [[.under]] .three = true := by decide
def e276349764330 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276349764330 : Closed e276349764330 ∧ code e276349764330 = 4674396275434 := by decide
theorem cert_e276349764330 : check e276349764330 [[.under]] .three = true := by decide
def e276349764406 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276349764406 : Closed e276349764406 ∧ code e276349764406 = 4674396275510 := by decide
theorem cert_e276349764406 : check e276349764406 [[.under]] .three = true := by decide
def e276349764410 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276349764410 : Closed e276349764410 ∧ code e276349764410 = 4674396275514 := by decide
theorem cert_e276349764410 : check e276349764410 [[.under]] .three = true := by decide
def e276349764506 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276349764506 : Closed e276349764506 ∧ code e276349764506 = 4674396275610 := by decide
theorem cert_e276349764506 : check e276349764506 [[.under]] .three = true := by decide
def e276349797078 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276349797078 : Closed e276349797078 ∧ code e276349797078 = 4674396308182 := by decide
private def t_e276349797078 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e276349797078 : ¬ IsSelfInterpreter e276349797078 :=
  wSource (t := t_e276349797078) (replay_sound (ps := []) (t := e276349797078) (by decide)) (by decide)
def e276349797082 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276349797082 : Closed e276349797082 ∧ code e276349797082 = 4674396308186 := by decide
theorem cert_e276349797082 : check e276349797082 [[.under]] .three = true := by decide
def e276349797098 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276349797098 : Closed e276349797098 ∧ code e276349797098 = 4674396308202 := by decide
theorem cert_e276349797098 : check e276349797098 [[.under]] .three = true := by decide
def e276349797174 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276349797174 : Closed e276349797174 ∧ code e276349797174 = 4674396308278 := by decide
theorem cert_e276349797174 : check e276349797174 [[.under]] .three = true := by decide
def e276349797178 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276349797178 : Closed e276349797178 ∧ code e276349797178 = 4674396308282 := by decide
theorem cert_e276349797178 : check e276349797178 [[.under]] .three = true := by decide
def e276349797274 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276349797274 : Closed e276349797274 ∧ code e276349797274 = 4674396308378 := by decide
theorem cert_e276349797274 : check e276349797274 [[.under]] .three = true := by decide
def e276385612502 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276385612502 : Closed e276385612502 ∧ code e276385612502 = 4674432123606 := by decide
theorem cert_e276385612502 : check e276385612502 [[.under]] .three = true := by decide
def e276385612506 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276385612506 : Closed e276385612506 ∧ code e276385612506 = 4674432123610 := by decide
theorem cert_e276385612506 : check e276385612506 [[.under]] .three = true := by decide
def e276385612522 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276385612522 : Closed e276385612522 ∧ code e276385612522 = 4674432123626 := by decide
theorem cert_e276385612522 : check e276385612522 [[.under]] .three = true := by decide
def e276385612598 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276385612598 : Closed e276385612598 ∧ code e276385612598 = 4674432123702 := by decide
theorem cert_e276385612598 : check e276385612598 [[.under]] .three = true := by decide
def e276385612602 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276385612602 : Closed e276385612602 ∧ code e276385612602 = 4674432123706 := by decide
theorem cert_e276385612602 : check e276385612602 [[.under]] .three = true := by decide
def e276385612698 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276385612698 : Closed e276385612698 ∧ code e276385612698 = 4674432123802 := by decide
theorem cert_e276385612698 : check e276385612698 [[.under]] .three = true := by decide
def e276386661078 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276386661078 : Closed e276386661078 ∧ code e276386661078 = 4674433172182 := by decide
theorem cert_e276386661078 : check e276386661078 [[.under]] .three = true := by decide
def e276386661082 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276386661082 : Closed e276386661082 ∧ code e276386661082 = 4674433172186 := by decide
theorem cert_e276386661082 : check e276386661082 [[.under]] .three = true := by decide
def e276386661098 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276386661098 : Closed e276386661098 ∧ code e276386661098 = 4674433172202 := by decide
theorem cert_e276386661098 : check e276386661098 [[.under]] .three = true := by decide
def e276386661174 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276386661174 : Closed e276386661174 ∧ code e276386661174 = 4674433172278 := by decide
theorem cert_e276386661174 : check e276386661174 [[.under]] .three = true := by decide
def e276386661178 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276386661178 : Closed e276386661178 ∧ code e276386661178 = 4674433172282 := by decide
theorem cert_e276386661178 : check e276386661178 [[.under]] .three = true := by decide
def e276386661274 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276386661274 : Closed e276386661274 ∧ code e276386661274 = 4674433172378 := by decide
theorem cert_e276386661274 : check e276386661274 [[.under]] .three = true := by decide
def e276386726614 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276386726614 : Closed e276386726614 ∧ code e276386726614 = 4674433237718 := by decide
theorem cert_e276386726614 : check e276386726614 [[.under]] .three = true := by decide
def e276386726618 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276386726618 : Closed e276386726618 ∧ code e276386726618 = 4674433237722 := by decide
theorem cert_e276386726618 : check e276386726618 [[.under]] .three = true := by decide
def e276386726634 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276386726634 : Closed e276386726634 ∧ code e276386726634 = 4674433237738 := by decide
theorem cert_e276386726634 : check e276386726634 [[.under]] .three = true := by decide
def e276386726710 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276386726710 : Closed e276386726710 ∧ code e276386726710 = 4674433237814 := by decide
theorem cert_e276386726710 : check e276386726710 [[.under]] .three = true := by decide
def e276386726714 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276386726714 : Closed e276386726714 ∧ code e276386726714 = 4674433237818 := by decide
theorem cert_e276386726714 : check e276386726714 [[.under]] .three = true := by decide
def e276386726810 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276386726810 : Closed e276386726810 ∧ code e276386726810 = 4674433237914 := by decide
theorem cert_e276386726810 : check e276386726810 [[.under]] .three = true := by decide
def e276408681174 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276408681174 : Closed e276408681174 ∧ code e276408681174 = 4674455192278 := by decide
theorem cert_e276408681174 : check e276408681174 [[.under]] .three = true := by decide
def e276408681178 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276408681178 : Closed e276408681178 ∧ code e276408681178 = 4674455192282 := by decide
theorem cert_e276408681178 : check e276408681178 [[.under]] .three = true := by decide
def e276408681194 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276408681194 : Closed e276408681194 ∧ code e276408681194 = 4674455192298 := by decide
theorem cert_e276408681194 : check e276408681194 [[.under]] .three = true := by decide
def e276408681270 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276408681270 : Closed e276408681270 ∧ code e276408681270 = 4674455192374 := by decide
theorem cert_e276408681270 : check e276408681270 [[.under]] .three = true := by decide
def e276408681274 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276408681274 : Closed e276408681274 ∧ code e276408681274 = 4674455192378 := by decide
theorem cert_e276408681274 : check e276408681274 [[.under]] .three = true := by decide
def e276408681370 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276408681370 : Closed e276408681370 ∧ code e276408681370 = 4674455192474 := by decide
theorem cert_e276408681370 : check e276408681370 [[.under]] .three = true := by decide
def e276414972630 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276414972630 : Closed e276414972630 ∧ code e276414972630 = 4674461483734 := by decide
theorem cert_e276414972630 : check e276414972630 [[.under]] .three = true := by decide
def e276414972634 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276414972634 : Closed e276414972634 ∧ code e276414972634 = 4674461483738 := by decide
theorem cert_e276414972634 : check e276414972634 [[.under]] .three = true := by decide
def e276414972650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276414972650 : Closed e276414972650 ∧ code e276414972650 = 4674461483754 := by decide
theorem cert_e276414972650 : check e276414972650 [[.under]] .three = true := by decide
def e276414972726 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276414972726 : Closed e276414972726 ∧ code e276414972726 = 4674461483830 := by decide
theorem cert_e276414972726 : check e276414972726 [[.under]] .three = true := by decide
def e276414972730 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276414972730 : Closed e276414972730 ∧ code e276414972730 = 4674461483834 := by decide
theorem cert_e276414972730 : check e276414972730 [[.under]] .three = true := by decide
def e276414972826 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276414972826 : Closed e276414972826 ∧ code e276414972826 = 4674461483930 := by decide
theorem cert_e276414972826 : check e276414972826 [[.under]] .three = true := by decide
def e276415038166 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276415038166 : Closed e276415038166 ∧ code e276415038166 = 4674461549270 := by decide
theorem cert_e276415038166 : check e276415038166 [[.under]] .three = true := by decide
def e276415038170 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276415038170 : Closed e276415038170 ∧ code e276415038170 = 4674461549274 := by decide
theorem cert_e276415038170 : check e276415038170 [[.under]] .three = true := by decide
def e276415038186 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276415038186 : Closed e276415038186 ∧ code e276415038186 = 4674461549290 := by decide
theorem cert_e276415038186 : check e276415038186 [[.under]] .three = true := by decide
def e276415038262 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276415038262 : Closed e276415038262 ∧ code e276415038262 = 4674461549366 := by decide
theorem cert_e276415038262 : check e276415038262 [[.under]] .three = true := by decide
def e276415038266 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276415038266 : Closed e276415038266 ∧ code e276415038266 = 4674461549370 := by decide
theorem cert_e276415038266 : check e276415038266 [[.under]] .three = true := by decide
def e276415038362 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276415038362 : Closed e276415038362 ∧ code e276415038362 = 4674461549466 := by decide
theorem cert_e276415038362 : check e276415038362 [[.under]] .three = true := by decide
def e276435944150 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276435944150 : Closed e276435944150 ∧ code e276435944150 = 4674482455254 := by decide
theorem cert_e276435944150 : check e276435944150 [[.under]] .three = true := by decide
def e276435944154 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276435944154 : Closed e276435944154 ∧ code e276435944154 = 4674482455258 := by decide
theorem cert_e276435944154 : check e276435944154 [[.under]] .three = true := by decide
def e276435944170 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276435944170 : Closed e276435944170 ∧ code e276435944170 = 4674482455274 := by decide
theorem cert_e276435944170 : check e276435944170 [[.under]] .three = true := by decide
def e276435944246 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276435944246 : Closed e276435944246 ∧ code e276435944246 = 4674482455350 := by decide
theorem cert_e276435944246 : check e276435944246 [[.under]] .three = true := by decide
def e276435944250 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276435944250 : Closed e276435944250 ∧ code e276435944250 = 4674482455354 := by decide
theorem cert_e276435944250 : check e276435944250 [[.under]] .three = true := by decide
def e276435944346 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276435944346 : Closed e276435944346 ∧ code e276435944346 = 4674482455450 := by decide
theorem cert_e276435944346 : check e276435944346 [[.under]] .three = true := by decide
def e276437517014 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276437517014 : Closed e276437517014 ∧ code e276437517014 = 4674484028118 := by decide
theorem cert_e276437517014 : check e276437517014 [[.under]] .three = true := by decide
def e276437517018 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276437517018 : Closed e276437517018 ∧ code e276437517018 = 4674484028122 := by decide
theorem cert_e276437517018 : check e276437517018 [[.under]] .three = true := by decide
def e276437517034 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276437517034 : Closed e276437517034 ∧ code e276437517034 = 4674484028138 := by decide
theorem cert_e276437517034 : check e276437517034 [[.under]] .three = true := by decide
def e276437517110 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276437517110 : Closed e276437517110 ∧ code e276437517110 = 4674484028214 := by decide
theorem cert_e276437517110 : check e276437517110 [[.under]] .three = true := by decide
def e276437517114 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276437517114 : Closed e276437517114 ∧ code e276437517114 = 4674484028218 := by decide
theorem cert_e276437517114 : check e276437517114 [[.under]] .three = true := by decide
def e276437517210 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276437517210 : Closed e276437517210 ∧ code e276437517210 = 4674484028314 := by decide
theorem cert_e276437517210 : check e276437517210 [[.under]] .three = true := by decide
def e276437615318 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276437615318 : Closed e276437615318 ∧ code e276437615318 = 4674484126422 := by decide
theorem cert_e276437615318 : check e276437615318 [[.under]] .three = true := by decide
def e276437615322 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276437615322 : Closed e276437615322 ∧ code e276437615322 = 4674484126426 := by decide
theorem cert_e276437615322 : check e276437615322 [[.under]] .three = true := by decide
def e276437615338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276437615338 : Closed e276437615338 ∧ code e276437615338 = 4674484126442 := by decide
theorem cert_e276437615338 : check e276437615338 [[.under]] .three = true := by decide
def e276437615414 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276437615414 : Closed e276437615414 ∧ code e276437615414 = 4674484126518 := by decide
theorem cert_e276437615414 : check e276437615414 [[.under]] .three = true := by decide
def e276437615418 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276437615418 : Closed e276437615418 ∧ code e276437615418 = 4674484126522 := by decide
theorem cert_e276437615418 : check e276437615418 [[.under]] .three = true := by decide
def e276437615514 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276437615514 : Closed e276437615514 ∧ code e276437615514 = 4674484126618 := by decide
theorem cert_e276437615514 : check e276437615514 [[.under]] .three = true := by decide
def e276442235606 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276442235606 : Closed e276442235606 ∧ code e276442235606 = 4674488746710 := by decide
theorem cert_e276442235606 : check e276442235606 [[.under]] .three = true := by decide
def e276442235610 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276442235610 : Closed e276442235610 ∧ code e276442235610 = 4674488746714 := by decide
theorem cert_e276442235610 : check e276442235610 [[.under]] .three = true := by decide
def e276442235626 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276442235626 : Closed e276442235626 ∧ code e276442235626 = 4674488746730 := by decide
theorem cert_e276442235626 : check e276442235626 [[.under]] .three = true := by decide
def e276442235702 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276442235702 : Closed e276442235702 ∧ code e276442235702 = 4674488746806 := by decide
theorem cert_e276442235702 : check e276442235702 [[.under]] .three = true := by decide
def e276442235706 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276442235706 : Closed e276442235706 ∧ code e276442235706 = 4674488746810 := by decide
theorem cert_e276442235706 : check e276442235706 [[.under]] .three = true := by decide
def e276442235802 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276442235802 : Closed e276442235802 ∧ code e276442235802 = 4674488746906 := by decide
theorem cert_e276442235802 : check e276442235802 [[.under]] .three = true := by decide
def e276451672790 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276451672790 : Closed e276451672790 ∧ code e276451672790 = 4674498183894 := by decide
theorem cert_e276451672790 : check e276451672790 [[.under]] .three = true := by decide
def e276451672794 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276451672794 : Closed e276451672794 ∧ code e276451672794 = 4674498183898 := by decide
theorem cert_e276451672794 : check e276451672794 [[.under]] .three = true := by decide
def e276451672810 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276451672810 : Closed e276451672810 ∧ code e276451672810 = 4674498183914 := by decide
theorem cert_e276451672810 : check e276451672810 [[.under]] .three = true := by decide
def e276451672886 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276451672886 : Closed e276451672886 ∧ code e276451672886 = 4674498183990 := by decide
theorem cert_e276451672886 : check e276451672886 [[.under]] .three = true := by decide
def e276451672890 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276451672890 : Closed e276451672890 ∧ code e276451672890 = 4674498183994 := by decide
theorem cert_e276451672890 : check e276451672890 [[.under]] .three = true := by decide
def e276451672986 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276451672986 : Closed e276451672986 ∧ code e276451672986 = 4674498184090 := by decide
theorem cert_e276451672986 : check e276451672986 [[.under]] .three = true := by decide
def e276451771094 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276451771094 : Closed e276451771094 ∧ code e276451771094 = 4674498282198 := by decide
theorem cert_e276451771094 : check e276451771094 [[.under]] .three = true := by decide
def e276451771098 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276451771098 : Closed e276451771098 ∧ code e276451771098 = 4674498282202 := by decide
theorem cert_e276451771098 : check e276451771098 [[.under]] .three = true := by decide
def e276451771114 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276451771114 : Closed e276451771114 ∧ code e276451771114 = 4674498282218 := by decide
theorem cert_e276451771114 : check e276451771114 [[.under]] .three = true := by decide
def e276451771190 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276451771190 : Closed e276451771190 ∧ code e276451771190 = 4674498282294 := by decide
theorem cert_e276451771190 : check e276451771190 [[.under]] .three = true := by decide
def e276451771194 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276451771194 : Closed e276451771194 ∧ code e276451771194 = 4674498282298 := by decide
theorem cert_e276451771194 : check e276451771194 [[.under]] .three = true := by decide
def e276451771290 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276451771290 : Closed e276451771290 ∧ code e276451771290 = 4674498282394 := by decide
theorem cert_e276451771290 : check e276451771290 [[.under]] .three = true := by decide
def e276462158550 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276462158550 : Closed e276462158550 ∧ code e276462158550 = 4674508669654 := by decide
theorem cert_e276462158550 : check e276462158550 [[.under]] .three = true := by decide
def e276462158554 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276462158554 : Closed e276462158554 ∧ code e276462158554 = 4674508669658 := by decide
theorem cert_e276462158554 : check e276462158554 [[.under]] .three = true := by decide
def e276462158570 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276462158570 : Closed e276462158570 ∧ code e276462158570 = 4674508669674 := by decide
theorem cert_e276462158570 : check e276462158570 [[.under]] .three = true := by decide
def e276462158646 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276462158646 : Closed e276462158646 ∧ code e276462158646 = 4674508669750 := by decide
theorem cert_e276462158646 : check e276462158646 [[.under]] .three = true := by decide
def e276462158650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276462158650 : Closed e276462158650 ∧ code e276462158650 = 4674508669754 := by decide
theorem cert_e276462158650 : check e276462158650 [[.under]] .three = true := by decide
def e276462158746 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276462158746 : Closed e276462158746 ∧ code e276462158746 = 4674508669850 := by decide
theorem cert_e276462158746 : check e276462158746 [[.under]] .three = true := by decide
def e276462224086 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276462224086 : Closed e276462224086 ∧ code e276462224086 = 4674508735190 := by decide
theorem cert_e276462224086 : check e276462224086 [[.under]] .three = true := by decide
def e276462224090 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276462224090 : Closed e276462224090 ∧ code e276462224090 = 4674508735194 := by decide
theorem cert_e276462224090 : check e276462224090 [[.under]] .three = true := by decide
def e276462224106 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276462224106 : Closed e276462224106 ∧ code e276462224106 = 4674508735210 := by decide
theorem cert_e276462224106 : check e276462224106 [[.under]] .three = true := by decide
def e276462224182 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276462224182 : Closed e276462224182 ∧ code e276462224182 = 4674508735286 := by decide
theorem cert_e276462224182 : check e276462224182 [[.under]] .three = true := by decide
def e276462224186 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276462224186 : Closed e276462224186 ∧ code e276462224186 = 4674508735290 := by decide
theorem cert_e276462224186 : check e276462224186 [[.under]] .three = true := by decide
def e276462224282 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276462224282 : Closed e276462224282 ∧ code e276462224282 = 4674508735386 := by decide
theorem cert_e276462224282 : check e276462224282 [[.under]] .three = true := by decide
def e276462682838 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276462682838 : Closed e276462682838 ∧ code e276462682838 = 4674509193942 := by decide
theorem cert_e276462682838 : check e276462682838 [[.under]] .three = true := by decide
def e276462682842 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276462682842 : Closed e276462682842 ∧ code e276462682842 = 4674509193946 := by decide
theorem cert_e276462682842 : check e276462682842 [[.under]] .three = true := by decide
def e276462682858 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276462682858 : Closed e276462682858 ∧ code e276462682858 = 4674509193962 := by decide
theorem cert_e276462682858 : check e276462682858 [[.under]] .three = true := by decide
def e276462682934 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276462682934 : Closed e276462682934 ∧ code e276462682934 = 4674509194038 := by decide
theorem cert_e276462682934 : check e276462682934 [[.under]] .three = true := by decide
end Blc.Floor42
