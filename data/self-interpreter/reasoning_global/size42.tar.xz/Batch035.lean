import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e431242021806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e431242021806 : Closed e431242021806 ∧ code e431242021806 = 4829288532910 := by decide
theorem cert_e431242021806 : check e431242021806 [] .sourceHead = true := by decide
def e431242021818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e431242021818 : Closed e431242021818 ∧ code e431242021818 = 4829288532922 := by decide
theorem cert_e431242021818 : check e431242021818 [] .sourceHead = true := by decide
def e431242021846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e431242021846 : Closed e431242021846 ∧ code e431242021846 = 4829288532950 := by decide
theorem cert_e431242021846 : check e431242021846 [] .sourceHead = true := by decide
def e431242021850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e431242021850 : Closed e431242021850 ∧ code e431242021850 = 4829288532954 := by decide
theorem cert_e431242021850 : check e431242021850 [] .sourceHead = true := by decide
def e431242022126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e431242022126 : Closed e431242022126 ∧ code e431242022126 = 4829288533230 := by decide
theorem cert_e431242022126 : check e431242022126 [] .sourceHead = true := by decide
def e431242022134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e431242022134 : Closed e431242022134 ∧ code e431242022134 = 4829288533238 := by decide
theorem cert_e431242022134 : check e431242022134 [] .sourceHead = true := by decide
def e431242022510 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e431242022510 : Closed e431242022510 ∧ code e431242022510 = 4829288533614 := by decide
theorem cert_e431242022510 : check e431242022510 [] .sourceHead = true := by decide
def e431242022522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e431242022522 : Closed e431242022522 ∧ code e431242022522 = 4829288533626 := by decide
theorem cert_e431242022522 : check e431242022522 [] .sourceHead = true := by decide
def e431242022710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431242022710 : Closed e431242022710 ∧ code e431242022710 = 4829288533814 := by decide
theorem cert_e431242022710 : check e431242022710 [] .sourceHead = true := by decide
def e431242022714 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431242022714 : Closed e431242022714 ∧ code e431242022714 = 4829288533818 := by decide
theorem cert_e431242022714 : check e431242022714 [] .sourceHead = true := by decide
def e431242030190 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e431242030190 : Closed e431242030190 ∧ code e431242030190 = 4829288541294 := by decide
theorem cert_e431242030190 : check e431242030190 [] .sourceHead = true := by decide
def e431242030202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e431242030202 : Closed e431242030202 ∧ code e431242030202 = 4829288541306 := by decide
theorem cert_e431242030202 : check e431242030202 [] .sourceHead = true := by decide
def e431242030366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e431242030366 : Closed e431242030366 ∧ code e431242030366 = 4829288541470 := by decide
theorem cert_e431242030366 : check e431242030366 [] .sourceHead = true := by decide
def e431242030534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e431242030534 : Closed e431242030534 ∧ code e431242030534 = 4829288541638 := by decide
theorem cert_e431242030534 : check e431242030534 [] .sourceHead = true := by decide
def e431242030874 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e431242030874 : Closed e431242030874 ∧ code e431242030874 = 4829288541978 := by decide
theorem cert_e431242030874 : check e431242030874 [] .sourceHead = true := by decide
def e431242030918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e431242030918 : Closed e431242030918 ∧ code e431242030918 = 4829288542022 := by decide
theorem cert_e431242030918 : check e431242030918 [] .sourceHead = true := by decide
def e431242031902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e431242031902 : Closed e431242031902 ∧ code e431242031902 = 4829288543006 := by decide
theorem cert_e431242031902 : check e431242031902 [] .sourceHead = true := by decide
def e431242032070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e431242032070 : Closed e431242032070 ∧ code e431242032070 = 4829288543174 := by decide
theorem cert_e431242032070 : check e431242032070 [] .sourceHead = true := by decide
def e431242034374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e431242034374 : Closed e431242034374 ∧ code e431242034374 = 4829288545478 := by decide
theorem cert_e431242034374 : check e431242034374 [] .sourceHead = true := by decide
def e431242057270 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e431242057270 : Closed e431242057270 ∧ code e431242057270 = 4829288568374 := by decide
theorem cert_e431242057270 : check e431242057270 [] .sourceHead = true := by decide
def e431242057274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e431242057274 : Closed e431242057274 ∧ code e431242057274 = 4829288568378 := by decide
theorem cert_e431242057274 : check e431242057274 [] .sourceHead = true := by decide
def e431242057358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e431242057358 : Closed e431242057358 ∧ code e431242057358 = 4829288568462 := by decide
theorem cert_e431242057358 : check e431242057358 [] .sourceHead = true := by decide
def e431242057414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e431242057414 : Closed e431242057414 ∧ code e431242057414 = 4829288568518 := by decide
theorem cert_e431242057414 : check e431242057414 [] .sourceHead = true := by decide
def e431242057498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e431242057498 : Closed e431242057498 ∧ code e431242057498 = 4829288568602 := by decide
theorem cert_e431242057498 : check e431242057498 [] .sourceHead = true := by decide
def e431242057542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e431242057542 : Closed e431242057542 ∧ code e431242057542 = 4829288568646 := by decide
theorem cert_e431242057542 : check e431242057542 [] .sourceHead = true := by decide
def e431242058126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e431242058126 : Closed e431242058126 ∧ code e431242058126 = 4829288569230 := by decide
theorem cert_e431242058126 : check e431242058126 [] .sourceHead = true := by decide
def e431242058182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e431242058182 : Closed e431242058182 ∧ code e431242058182 = 4829288569286 := by decide
theorem cert_e431242058182 : check e431242058182 [] .sourceHead = true := by decide
def e431242058950 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e431242058950 : Closed e431242058950 ∧ code e431242058950 = 4829288570054 := by decide
theorem cert_e431242058950 : check e431242058950 [] .sourceHead = true := by decide
def e431243155694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e431243155694 : Closed e431243155694 ∧ code e431243155694 = 4829289666798 := by decide
theorem cert_e431243155694 : check e431243155694 [] .sourceHead = true := by decide
def e431243155702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e431243155702 : Closed e431243155702 ∧ code e431243155702 = 4829289666806 := by decide
theorem cert_e431243155702 : check e431243155702 [] .sourceHead = true := by decide
def e431243156254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e431243156254 : Closed e431243156254 ∧ code e431243156254 = 4829289667358 := by decide
theorem cert_e431243156254 : check e431243156254 [] .sourceHead = true := by decide
def e431243156366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e431243156366 : Closed e431243156366 ∧ code e431243156366 = 4829289667470 := by decide
theorem cert_e431243156366 : check e431243156366 [] .sourceHead = true := by decide
def e431243156590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e431243156590 : Closed e431243156590 ∧ code e431243156590 = 4829289667694 := by decide
theorem cert_e431243156590 : check e431243156590 [] .sourceHead = true := by decide
def e431243156602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e431243156602 : Closed e431243156602 ∧ code e431243156602 = 4829289667706 := by decide
theorem cert_e431243156602 : check e431243156602 [] .sourceHead = true := by decide
def e431243156766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e431243156766 : Closed e431243156766 ∧ code e431243156766 = 4829289667870 := by decide
theorem cert_e431243156766 : check e431243156766 [] .sourceHead = true := by decide
def e431243156934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e431243156934 : Closed e431243156934 ∧ code e431243156934 = 4829289668038 := by decide
theorem cert_e431243156934 : check e431243156934 [] .sourceHead = true := by decide
def e431243157046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e431243157046 : Closed e431243157046 ∧ code e431243157046 = 4829289668150 := by decide
theorem cert_e431243157046 : check e431243157046 [] .sourceHead = true := by decide
def e431243157050 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e431243157050 : Closed e431243157050 ∧ code e431243157050 = 4829289668154 := by decide
theorem cert_e431243157050 : check e431243157050 [] .sourceHead = true := by decide
def e431243157134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e431243157134 : Closed e431243157134 ∧ code e431243157134 = 4829289668238 := by decide
theorem cert_e431243157134 : check e431243157134 [] .sourceHead = true := by decide
def e431243157190 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e431243157190 : Closed e431243157190 ∧ code e431243157190 = 4829289668294 := by decide
theorem cert_e431243157190 : check e431243157190 [] .sourceHead = true := by decide
def e431243159326 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e431243159326 : Closed e431243159326 ∧ code e431243159326 = 4829289670430 := by decide
theorem cert_e431243159326 : check e431243159326 [] .sourceHead = true := by decide
def e431243159438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e431243159438 : Closed e431243159438 ∧ code e431243159438 = 4829289670542 := by decide
theorem cert_e431243159438 : check e431243159438 [] .sourceHead = true := by decide
def e431243162398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e431243162398 : Closed e431243162398 ∧ code e431243162398 = 4829289673502 := by decide
theorem cert_e431243162398 : check e431243162398 [] .sourceHead = true := by decide
def e431243162566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e431243162566 : Closed e431243162566 ∧ code e431243162566 = 4829289673670 := by decide
theorem cert_e431243162566 : check e431243162566 [] .sourceHead = true := by decide
def e431243164046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e431243164046 : Closed e431243164046 ∧ code e431243164046 = 4829289675150 := by decide
theorem cert_e431243164046 : check e431243164046 [] .sourceHead = true := by decide
def e431243164102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e431243164102 : Closed e431243164102 ∧ code e431243164102 = 4829289675206 := by decide
theorem cert_e431243164102 : check e431243164102 [] .sourceHead = true := by decide
def e431247857374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e431247857374 : Closed e431247857374 ∧ code e431247857374 = 4829294368478 := by decide
theorem cert_e431247857374 : check e431247857374 [] .sourceHead = true := by decide
def e431247857398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e431247857398 : Closed e431247857398 ∧ code e431247857398 = 4829294368502 := by decide
theorem cert_e431247857398 : check e431247857398 [] .sourceHead = true := by decide
def e431247857502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e431247857502 : Closed e431247857502 ∧ code e431247857502 = 4829294368606 := by decide
theorem cert_e431247857502 : check e431247857502 [] .sourceHead = true := by decide
def e431247857530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e431247857530 : Closed e431247857530 ∧ code e431247857530 = 4829294368634 := by decide
theorem cert_e431247857530 : check e431247857530 [] .sourceHead = true := by decide
def e431247857622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e431247857622 : Closed e431247857622 ∧ code e431247857622 = 4829294368726 := by decide
theorem cert_e431247857622 : check e431247857622 [] .sourceHead = true := by decide
def e431247857626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e431247857626 : Closed e431247857626 ∧ code e431247857626 = 4829294368730 := by decide
theorem cert_e431247857626 : check e431247857626 [] .sourceHead = true := by decide
def e431247858142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e431247858142 : Closed e431247858142 ∧ code e431247858142 = 4829294369246 := by decide
theorem cert_e431247858142 : check e431247858142 [] .sourceHead = true := by decide
def e431247858166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e431247858166 : Closed e431247858166 ∧ code e431247858166 = 4829294369270 := by decide
theorem cert_e431247858166 : check e431247858166 [] .sourceHead = true := by decide
def e431247858910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e431247858910 : Closed e431247858910 ∧ code e431247858910 = 4829294370014 := by decide
theorem cert_e431247858910 : check e431247858910 [] .sourceHead = true := by decide
def e431247858938 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e431247858938 : Closed e431247858938 ∧ code e431247858938 = 4829294370042 := by decide
theorem cert_e431247858938 : check e431247858938 [] .sourceHead = true := by decide
def e431247859510 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e431247859510 : Closed e431247859510 ∧ code e431247859510 = 4829294370614 := by decide
theorem cert_e431247859510 : check e431247859510 [] .sourceHead = true := by decide
def e431247859514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e431247859514 : Closed e431247859514 ∧ code e431247859514 = 4829294370618 := by decide
theorem cert_e431247859514 : check e431247859514 [] .sourceHead = true := by decide
def e431247874286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e431247874286 : Closed e431247874286 ∧ code e431247874286 = 4829294385390 := by decide
theorem cert_e431247874286 : check e431247874286 [] .sourceHead = true := by decide
def e431247874294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e431247874294 : Closed e431247874294 ∧ code e431247874294 = 4829294385398 := by decide
theorem cert_e431247874294 : check e431247874294 [] .sourceHead = true := by decide
def e431247874846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e431247874846 : Closed e431247874846 ∧ code e431247874846 = 4829294385950 := by decide
theorem cert_e431247874846 : check e431247874846 [] .sourceHead = true := by decide
def e431247874958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e431247874958 : Closed e431247874958 ∧ code e431247874958 = 4829294386062 := by decide
theorem cert_e431247874958 : check e431247874958 [] .sourceHead = true := by decide
def e431247875182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e431247875182 : Closed e431247875182 ∧ code e431247875182 = 4829294386286 := by decide
theorem cert_e431247875182 : check e431247875182 [] .sourceHead = true := by decide
def e431247875194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e431247875194 : Closed e431247875194 ∧ code e431247875194 = 4829294386298 := by decide
theorem cert_e431247875194 : check e431247875194 [] .sourceHead = true := by decide
def e431247875358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e431247875358 : Closed e431247875358 ∧ code e431247875358 = 4829294386462 := by decide
theorem cert_e431247875358 : check e431247875358 [] .sourceHead = true := by decide
def e431247875526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e431247875526 : Closed e431247875526 ∧ code e431247875526 = 4829294386630 := by decide
theorem cert_e431247875526 : check e431247875526 [] .sourceHead = true := by decide
def e431247875638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e431247875638 : Closed e431247875638 ∧ code e431247875638 = 4829294386742 := by decide
theorem cert_e431247875638 : check e431247875638 [] .sourceHead = true := by decide
def e431247875642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e431247875642 : Closed e431247875642 ∧ code e431247875642 = 4829294386746 := by decide
theorem cert_e431247875642 : check e431247875642 [] .sourceHead = true := by decide
def e431247875726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e431247875726 : Closed e431247875726 ∧ code e431247875726 = 4829294386830 := by decide
theorem cert_e431247875726 : check e431247875726 [] .sourceHead = true := by decide
def e431247875782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e431247875782 : Closed e431247875782 ∧ code e431247875782 = 4829294386886 := by decide
theorem cert_e431247875782 : check e431247875782 [] .sourceHead = true := by decide
def e431247877918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e431247877918 : Closed e431247877918 ∧ code e431247877918 = 4829294389022 := by decide
theorem cert_e431247877918 : check e431247877918 [] .sourceHead = true := by decide
def e431247878030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e431247878030 : Closed e431247878030 ∧ code e431247878030 = 4829294389134 := by decide
theorem cert_e431247878030 : check e431247878030 [] .sourceHead = true := by decide
def e431247880990 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e431247880990 : Closed e431247880990 ∧ code e431247880990 = 4829294392094 := by decide
theorem cert_e431247880990 : check e431247880990 [] .sourceHead = true := by decide
def e431247881158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e431247881158 : Closed e431247881158 ∧ code e431247881158 = 4829294392262 := by decide
theorem cert_e431247881158 : check e431247881158 [] .sourceHead = true := by decide
def e431247882638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e431247882638 : Closed e431247882638 ∧ code e431247882638 = 4829294393742 := by decide
theorem cert_e431247882638 : check e431247882638 [] .sourceHead = true := by decide
def e431247882694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e431247882694 : Closed e431247882694 ∧ code e431247882694 = 4829294393798 := by decide
theorem cert_e431247882694 : check e431247882694 [] .sourceHead = true := by decide
def e1105298645018 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105298645018 : Closed e1105298645018 ∧ code e1105298645018 = 5503345156122 := by decide
theorem cert_e1105298645018 : check e1105298645018 [[]] .width = true := by decide
def e1105298645110 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105298645110 : Closed e1105298645110 ∧ code e1105298645110 = 5503345156214 := by decide
theorem cert_e1105298645110 : check e1105298645110 [[]] .width = true := by decide
def e1105298645354 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105298645354 : Closed e1105298645354 ∧ code e1105298645354 = 5503345156458 := by decide
theorem cert_e1105298645354 : check e1105298645354 [[]] .width = true := by decide
def e1105298645402 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105298645402 : Closed e1105298645402 ∧ code e1105298645402 = 5503345156506 := by decide
theorem cert_e1105298645402 : check e1105298645402 [[]] .width = true := by decide
def e1105341120710 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105341120710 : Closed e1105341120710 ∧ code e1105341120710 = 5503387631814 := by decide
theorem cert_e1105341120710 : check e1105341120710 [[]] .width = true := by decide
def e1105341121238 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105341121238 : Closed e1105341121238 ∧ code e1105341121238 = 5503387632342 := by decide
theorem cert_e1105341121238 : check e1105341121238 [[]] .width = true := by decide
def e1105341121242 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105341121242 : Closed e1105341121242 ∧ code e1105341121242 = 5503387632346 := by decide
theorem cert_e1105341121242 : check e1105341121242 [[]] .width = true := by decide
def e1105341121258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105341121258 : Closed e1105341121258 ∧ code e1105341121258 = 5503387632362 := by decide
theorem cert_e1105341121258 : check e1105341121258 [[]] .width = true := by decide
def e1105341121334 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105341121334 : Closed e1105341121334 ∧ code e1105341121334 = 5503387632438 := by decide
theorem cert_e1105341121334 : check e1105341121334 [[]] .width = true := by decide
def e1105341121338 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105341121338 : Closed e1105341121338 ∧ code e1105341121338 = 5503387632442 := by decide
theorem cert_e1105341121338 : check e1105341121338 [[]] .width = true := by decide
def e1105341121422 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105341121422 : Closed e1105341121422 ∧ code e1105341121422 = 5503387632526 := by decide
theorem cert_e1105341121422 : check e1105341121422 [[]] .width = true := by decide
def e1105341121434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105341121434 : Closed e1105341121434 ∧ code e1105341121434 = 5503387632538 := by decide
theorem cert_e1105341121434 : check e1105341121434 [[]] .width = true := by decide
def e1105341123354 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105341123354 : Closed e1105341123354 ∧ code e1105341123354 = 5503387634458 := by decide
theorem cert_e1105341123354 : check e1105341123354 [[]] .width = true := by decide
def e1105341123398 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105341123398 : Closed e1105341123398 ∧ code e1105341123398 = 5503387634502 := by decide
theorem cert_e1105341123398 : check e1105341123398 [[]] .width = true := by decide
def e1105341123638 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105341123638 : Closed e1105341123638 ∧ code e1105341123638 = 5503387634742 := by decide
theorem cert_e1105341123638 : check e1105341123638 [[]] .width = true := by decide
def e1105341123642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105341123642 : Closed e1105341123642 ∧ code e1105341123642 = 5503387634746 := by decide
theorem cert_e1105341123642 : check e1105341123642 [[]] .width = true := by decide
def e1105341123782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105341123782 : Closed e1105341123782 ∧ code e1105341123782 = 5503387634886 := by decide
theorem cert_e1105341123782 : check e1105341123782 [[]] .width = true := by decide
def e1105342685210 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105342685210 : Closed e1105342685210 ∧ code e1105342685210 = 5503389196314 := by decide
theorem cert_e1105342685210 : check e1105342685210 [[]] .width = true := by decide
def e1105342685302 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105342685302 : Closed e1105342685302 ∧ code e1105342685302 = 5503389196406 := by decide
theorem cert_e1105342685302 : check e1105342685302 [[]] .width = true := by decide
def e1105342685546 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105342685546 : Closed e1105342685546 ∧ code e1105342685546 = 5503389196650 := by decide
theorem cert_e1105342685546 : check e1105342685546 [[]] .width = true := by decide
def e1105342685594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105342685594 : Closed e1105342685594 ∧ code e1105342685594 = 5503389196698 := by decide
theorem cert_e1105342685594 : check e1105342685594 [[]] .width = true := by decide
def e1105345315014 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105345315014 : Closed e1105345315014 ∧ code e1105345315014 = 5503391826118 := by decide
theorem cert_e1105345315014 : check e1105345315014 [[]] .width = true := by decide
def e1105345315542 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105345315542 : Closed e1105345315542 ∧ code e1105345315542 = 5503391826646 := by decide
theorem cert_e1105345315542 : check e1105345315542 [[]] .width = true := by decide
def e1105345315546 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105345315546 : Closed e1105345315546 ∧ code e1105345315546 = 5503391826650 := by decide
theorem cert_e1105345315546 : check e1105345315546 [[]] .width = true := by decide
def e1105345315562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105345315562 : Closed e1105345315562 ∧ code e1105345315562 = 5503391826666 := by decide
theorem cert_e1105345315562 : check e1105345315562 [[]] .width = true := by decide
def e1105345315638 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105345315638 : Closed e1105345315638 ∧ code e1105345315638 = 5503391826742 := by decide
theorem cert_e1105345315638 : check e1105345315638 [[]] .width = true := by decide
def e1105345315642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105345315642 : Closed e1105345315642 ∧ code e1105345315642 = 5503391826746 := by decide
theorem cert_e1105345315642 : check e1105345315642 [[]] .width = true := by decide
def e1105345315726 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105345315726 : Closed e1105345315726 ∧ code e1105345315726 = 5503391826830 := by decide
theorem cert_e1105345315726 : check e1105345315726 [[]] .width = true := by decide
def e1105345315738 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105345315738 : Closed e1105345315738 ∧ code e1105345315738 = 5503391826842 := by decide
theorem cert_e1105345315738 : check e1105345315738 [[]] .width = true := by decide
def e1105345317658 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105345317658 : Closed e1105345317658 ∧ code e1105345317658 = 5503391828762 := by decide
theorem cert_e1105345317658 : check e1105345317658 [[]] .width = true := by decide
def e1105345317702 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105345317702 : Closed e1105345317702 ∧ code e1105345317702 = 5503391828806 := by decide
theorem cert_e1105345317702 : check e1105345317702 [[]] .width = true := by decide
def e1105345317942 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105345317942 : Closed e1105345317942 ∧ code e1105345317942 = 5503391829046 := by decide
theorem cert_e1105345317942 : check e1105345317942 [[]] .width = true := by decide
def e1105345317946 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105345317946 : Closed e1105345317946 ∧ code e1105345317946 = 5503391829050 := by decide
theorem cert_e1105345317946 : check e1105345317946 [[]] .width = true := by decide
def e1105345318086 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105345318086 : Closed e1105345318086 ∧ code e1105345318086 = 5503391829190 := by decide
theorem cert_e1105345318086 : check e1105345318086 [[]] .width = true := by decide
def e1105345437722 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105345437722 : Closed e1105345437722 ∧ code e1105345437722 = 5503391948826 := by decide
theorem cert_e1105345437722 : check e1105345437722 [[]] .width = true := by decide
def e1105345437814 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105345437814 : Closed e1105345437814 ∧ code e1105345437814 = 5503391948918 := by decide
theorem cert_e1105345437814 : check e1105345437814 [[]] .width = true := by decide
def e1105345438058 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105345438058 : Closed e1105345438058 ∧ code e1105345438058 = 5503391949162 := by decide
theorem cert_e1105345438058 : check e1105345438058 [[]] .width = true := by decide
def e1105345438106 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105345438106 : Closed e1105345438106 ∧ code e1105345438106 = 5503391949210 := by decide
theorem cert_e1105345438106 : check e1105345438106 [[]] .width = true := by decide
def e1105345577158 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105345577158 : Closed e1105345577158 ∧ code e1105345577158 = 5503392088262 := by decide
theorem cert_e1105345577158 : check e1105345577158 [[]] .width = true := by decide
def e1105345577686 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105345577686 : Closed e1105345577686 ∧ code e1105345577686 = 5503392088790 := by decide
theorem cert_e1105345577686 : check e1105345577686 [[]] .width = true := by decide
def e1105345577690 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105345577690 : Closed e1105345577690 ∧ code e1105345577690 = 5503392088794 := by decide
theorem cert_e1105345577690 : check e1105345577690 [[]] .width = true := by decide
def e1105345577706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105345577706 : Closed e1105345577706 ∧ code e1105345577706 = 5503392088810 := by decide
theorem cert_e1105345577706 : check e1105345577706 [[]] .width = true := by decide
def e1105345577782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105345577782 : Closed e1105345577782 ∧ code e1105345577782 = 5503392088886 := by decide
theorem cert_e1105345577782 : check e1105345577782 [[]] .width = true := by decide
def e1105345577786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105345577786 : Closed e1105345577786 ∧ code e1105345577786 = 5503392088890 := by decide
theorem cert_e1105345577786 : check e1105345577786 [[]] .width = true := by decide
def e1105345577870 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105345577870 : Closed e1105345577870 ∧ code e1105345577870 = 5503392088974 := by decide
theorem cert_e1105345577870 : check e1105345577870 [[]] .width = true := by decide
def e1105345577882 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105345577882 : Closed e1105345577882 ∧ code e1105345577882 = 5503392088986 := by decide
theorem cert_e1105345577882 : check e1105345577882 [[]] .width = true := by decide
def e1105345579802 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105345579802 : Closed e1105345579802 ∧ code e1105345579802 = 5503392090906 := by decide
theorem cert_e1105345579802 : check e1105345579802 [[]] .width = true := by decide
def e1105345579846 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105345579846 : Closed e1105345579846 ∧ code e1105345579846 = 5503392090950 := by decide
theorem cert_e1105345579846 : check e1105345579846 [[]] .width = true := by decide
def e1105345580086 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105345580086 : Closed e1105345580086 ∧ code e1105345580086 = 5503392091190 := by decide
theorem cert_e1105345580086 : check e1105345580086 [[]] .width = true := by decide
def e1105345580090 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105345580090 : Closed e1105345580090 ∧ code e1105345580090 = 5503392091194 := by decide
theorem cert_e1105345580090 : check e1105345580090 [[]] .width = true := by decide
def e1105345580230 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105345580230 : Closed e1105345580230 ∧ code e1105345580230 = 5503392091334 := by decide
theorem cert_e1105345580230 : check e1105345580230 [[]] .width = true := by decide
def e1105357365274 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105357365274 : Closed e1105357365274 ∧ code e1105357365274 = 5503403876378 := by decide
theorem cert_e1105357365274 : check e1105357365274 [[]] .width = true := by decide
def e1105357365366 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105357365366 : Closed e1105357365366 ∧ code e1105357365366 = 5503403876470 := by decide
theorem cert_e1105357365366 : check e1105357365366 [[]] .width = true := by decide
def e1105357365610 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105357365610 : Closed e1105357365610 ∧ code e1105357365610 = 5503403876714 := by decide
theorem cert_e1105357365610 : check e1105357365610 [[]] .width = true := by decide
def e1105357365658 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105357365658 : Closed e1105357365658 ∧ code e1105357365658 = 5503403876762 := by decide
theorem cert_e1105357365658 : check e1105357365658 [[]] .width = true := by decide
def e1105374675142 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105374675142 : Closed e1105374675142 ∧ code e1105374675142 = 5503421186246 := by decide
theorem cert_e1105374675142 : check e1105374675142 [[]] .width = true := by decide
def e1105374675670 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105374675670 : Closed e1105374675670 ∧ code e1105374675670 = 5503421186774 := by decide
theorem cert_e1105374675670 : check e1105374675670 [[]] .width = true := by decide
def e1105374675674 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105374675674 : Closed e1105374675674 ∧ code e1105374675674 = 5503421186778 := by decide
theorem cert_e1105374675674 : check e1105374675674 [[]] .width = true := by decide
def e1105374675690 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105374675690 : Closed e1105374675690 ∧ code e1105374675690 = 5503421186794 := by decide
theorem cert_e1105374675690 : check e1105374675690 [[]] .width = true := by decide
def e1105374675766 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105374675766 : Closed e1105374675766 ∧ code e1105374675766 = 5503421186870 := by decide
theorem cert_e1105374675766 : check e1105374675766 [[]] .width = true := by decide
def e1105374675770 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105374675770 : Closed e1105374675770 ∧ code e1105374675770 = 5503421186874 := by decide
theorem cert_e1105374675770 : check e1105374675770 [[]] .width = true := by decide
def e1105374675854 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105374675854 : Closed e1105374675854 ∧ code e1105374675854 = 5503421186958 := by decide
theorem cert_e1105374675854 : check e1105374675854 [[]] .width = true := by decide
def e1105374675866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105374675866 : Closed e1105374675866 ∧ code e1105374675866 = 5503421186970 := by decide
theorem cert_e1105374675866 : check e1105374675866 [[]] .width = true := by decide
def e1105374677786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105374677786 : Closed e1105374677786 ∧ code e1105374677786 = 5503421188890 := by decide
theorem cert_e1105374677786 : check e1105374677786 [[]] .width = true := by decide
def e1105374677830 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105374677830 : Closed e1105374677830 ∧ code e1105374677830 = 5503421188934 := by decide
theorem cert_e1105374677830 : check e1105374677830 [[]] .width = true := by decide
def e1105374678070 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105374678070 : Closed e1105374678070 ∧ code e1105374678070 = 5503421189174 := by decide
theorem cert_e1105374678070 : check e1105374678070 [[]] .width = true := by decide
def e1105374678074 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105374678074 : Closed e1105374678074 ∧ code e1105374678074 = 5503421189178 := by decide
theorem cert_e1105374678074 : check e1105374678074 [[]] .width = true := by decide
def e1105374678214 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105374678214 : Closed e1105374678214 ∧ code e1105374678214 = 5503421189318 := by decide
theorem cert_e1105374678214 : check e1105374678214 [[]] .width = true := by decide
def e1105379909658 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105379909658 : Closed e1105379909658 ∧ code e1105379909658 = 5503426420762 := by decide
theorem cert_e1105379909658 : check e1105379909658 [[]] .width = true := by decide
def e1105379909750 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105379909750 : Closed e1105379909750 ∧ code e1105379909750 = 5503426420854 := by decide
theorem cert_e1105379909750 : check e1105379909750 [[]] .width = true := by decide
def e1105379909994 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105379909994 : Closed e1105379909994 ∧ code e1105379909994 = 5503426421098 := by decide
theorem cert_e1105379909994 : check e1105379909994 [[]] .width = true := by decide
def e1105379910042 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105379910042 : Closed e1105379910042 ∧ code e1105379910042 = 5503426421146 := by decide
theorem cert_e1105379910042 : check e1105379910042 [[]] .width = true := by decide
def e1105380966598 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105380966598 : Closed e1105380966598 ∧ code e1105380966598 = 5503427477702 := by decide
theorem cert_e1105380966598 : check e1105380966598 [[]] .width = true := by decide
def e1105380967126 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105380967126 : Closed e1105380967126 ∧ code e1105380967126 = 5503427478230 := by decide
theorem cert_e1105380967126 : check e1105380967126 [[]] .width = true := by decide
def e1105380967130 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105380967130 : Closed e1105380967130 ∧ code e1105380967130 = 5503427478234 := by decide
theorem cert_e1105380967130 : check e1105380967130 [[]] .width = true := by decide
def e1105380967146 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105380967146 : Closed e1105380967146 ∧ code e1105380967146 = 5503427478250 := by decide
theorem cert_e1105380967146 : check e1105380967146 [[]] .width = true := by decide
def e1105380967222 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105380967222 : Closed e1105380967222 ∧ code e1105380967222 = 5503427478326 := by decide
theorem cert_e1105380967222 : check e1105380967222 [[]] .width = true := by decide
def e1105380967226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105380967226 : Closed e1105380967226 ∧ code e1105380967226 = 5503427478330 := by decide
theorem cert_e1105380967226 : check e1105380967226 [[]] .width = true := by decide
def e1105380967310 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105380967310 : Closed e1105380967310 ∧ code e1105380967310 = 5503427478414 := by decide
theorem cert_e1105380967310 : check e1105380967310 [[]] .width = true := by decide
def e1105380967322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105380967322 : Closed e1105380967322 ∧ code e1105380967322 = 5503427478426 := by decide
theorem cert_e1105380967322 : check e1105380967322 [[]] .width = true := by decide
def e1105380969242 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105380969242 : Closed e1105380969242 ∧ code e1105380969242 = 5503427480346 := by decide
theorem cert_e1105380969242 : check e1105380969242 [[]] .width = true := by decide
def e1105380969286 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105380969286 : Closed e1105380969286 ∧ code e1105380969286 = 5503427480390 := by decide
theorem cert_e1105380969286 : check e1105380969286 [[]] .width = true := by decide
def e1105380969526 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105380969526 : Closed e1105380969526 ∧ code e1105380969526 = 5503427480630 := by decide
theorem cert_e1105380969526 : check e1105380969526 [[]] .width = true := by decide
def e1105380969530 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105380969530 : Closed e1105380969530 ∧ code e1105380969530 = 5503427480634 := by decide
theorem cert_e1105380969530 : check e1105380969530 [[]] .width = true := by decide
end Blc.Floor42
