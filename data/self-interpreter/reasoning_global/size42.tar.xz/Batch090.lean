import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1203076433314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1203076433314 : Closed e1203076433314 ∧ code e1203076433314 = 5601122944418 := by decide
theorem cert_e1203076433314 : check e1203076433314 [[]] .width = true := by decide
def e1203076433422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1203076433422 : Closed e1203076433422 ∧ code e1203076433422 = 5601122944526 := by decide
theorem cert_e1203076433422 : check e1203076433422 [[]] .width = true := by decide
def e1203076433434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203076433434 : Closed e1203076433434 ∧ code e1203076433434 = 5601122944538 := by decide
theorem cert_e1203076433434 : check e1203076433434 [[]] .width = true := by decide
def e1203076433506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1203076433506 : Closed e1203076433506 ∧ code e1203076433506 = 5601122944610 := by decide
theorem cert_e1203076433506 : check e1203076433506 [[]] .width = true := by decide
def e1203076534470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203076534470 : Closed e1203076534470 ∧ code e1203076534470 = 5601123045574 := by decide
theorem cert_e1203076534470 : check e1203076534470 [[]] .width = true := by decide
def e1203076536346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203076536346 : Closed e1203076536346 ∧ code e1203076536346 = 5601123047450 := by decide
theorem cert_e1203076536346 : check e1203076536346 [[]] .width = true := by decide
def e1203076537882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203076537882 : Closed e1203076537882 ∧ code e1203076537882 = 5601123048986 := by decide
theorem cert_e1203076537882 : check e1203076537882 [[]] .width = true := by decide
def e1203076546758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203076546758 : Closed e1203076546758 ∧ code e1203076546758 = 5601123057862 := by decide
theorem cert_e1203076546758 : check e1203076546758 [[]] .width = true := by decide
def e1203076554778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203076554778 : Closed e1203076554778 ∧ code e1203076554778 = 5601123065882 := by decide
theorem cert_e1203076554778 : check e1203076554778 [[]] .width = true := by decide
def e1203076554870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203076554870 : Closed e1203076554870 ∧ code e1203076554870 = 5601123065974 := by decide
theorem cert_e1203076554870 : check e1203076554870 [[]] .width = true := by decide
def e1203076555114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203076555114 : Closed e1203076555114 ∧ code e1203076555114 = 5601123066218 := by decide
theorem cert_e1203076555114 : check e1203076555114 [[]] .width = true := by decide
def e1203076555162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203076555162 : Closed e1203076555162 ∧ code e1203076555162 = 5601123066266 := by decide
theorem cert_e1203076555162 : check e1203076555162 [[]] .width = true := by decide
def e1203076559046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203076559046 : Closed e1203076559046 ∧ code e1203076559046 = 5601123070150 := by decide
theorem cert_e1203076559046 : check e1203076559046 [[]] .width = true := by decide
def e1203076571162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203076571162 : Closed e1203076571162 ∧ code e1203076571162 = 5601123082266 := by decide
theorem cert_e1203076571162 : check e1203076571162 [[]] .width = true := by decide
def e1203076571254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203076571254 : Closed e1203076571254 ∧ code e1203076571254 = 5601123082358 := by decide
theorem cert_e1203076571254 : check e1203076571254 [[]] .width = true := by decide
def e1203076571498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203076571498 : Closed e1203076571498 ∧ code e1203076571498 = 5601123082602 := by decide
theorem cert_e1203076571498 : check e1203076571498 [[]] .width = true := by decide
def e1203076571546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203076571546 : Closed e1203076571546 ∧ code e1203076571546 = 5601123082650 := by decide
theorem cert_e1203076571546 : check e1203076571546 [[]] .width = true := by decide
def e1203076580890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203076580890 : Closed e1203076580890 ∧ code e1203076580890 = 5601123091994 := by decide
theorem cert_e1203076580890 : check e1203076580890 [[]] .width = true := by decide
def e1203076583622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203076583622 : Closed e1203076583622 ∧ code e1203076583622 = 5601123094726 := by decide
theorem cert_e1203076583622 : check e1203076583622 [[]] .width = true := by decide
def e1203076595910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203076595910 : Closed e1203076595910 ∧ code e1203076595910 = 5601123107014 := by decide
theorem cert_e1203076595910 : check e1203076595910 [[]] .width = true := by decide
def e1203076596438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1203076596438 : Closed e1203076596438 ∧ code e1203076596438 = 5601123107542 := by decide
theorem cert_e1203076596438 : check e1203076596438 [[]] .width = true := by decide
def e1203076596442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1203076596442 : Closed e1203076596442 ∧ code e1203076596442 = 5601123107546 := by decide
theorem cert_e1203076596442 : check e1203076596442 [[]] .width = true := by decide
def e1203076596458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1203076596458 : Closed e1203076596458 ∧ code e1203076596458 = 5601123107562 := by decide
theorem cert_e1203076596458 : check e1203076596458 [[]] .width = true := by decide
def e1203076596534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1203076596534 : Closed e1203076596534 ∧ code e1203076596534 = 5601123107638 := by decide
theorem cert_e1203076596534 : check e1203076596534 [[]] .width = true := by decide
def e1203076596538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1203076596538 : Closed e1203076596538 ∧ code e1203076596538 = 5601123107642 := by decide
theorem cert_e1203076596538 : check e1203076596538 [[]] .width = true := by decide
def e1203076596622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1203076596622 : Closed e1203076596622 ∧ code e1203076596622 = 5601123107726 := by decide
theorem cert_e1203076596622 : check e1203076596622 [[]] .width = true := by decide
def e1203076596634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1203076596634 : Closed e1203076596634 ∧ code e1203076596634 = 5601123107738 := by decide
theorem cert_e1203076596634 : check e1203076596634 [[]] .width = true := by decide
def e1203076598554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1203076598554 : Closed e1203076598554 ∧ code e1203076598554 = 5601123109658 := by decide
theorem cert_e1203076598554 : check e1203076598554 [[]] .width = true := by decide
def e1203076598598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1203076598598 : Closed e1203076598598 ∧ code e1203076598598 = 5601123109702 := by decide
theorem cert_e1203076598598 : check e1203076598598 [[]] .width = true := by decide
def e1203076598710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1203076598710 : Closed e1203076598710 ∧ code e1203076598710 = 5601123109814 := by decide
theorem cert_e1203076598710 : check e1203076598710 [[]] .width = true := by decide
def e1203076598838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1203076598838 : Closed e1203076598838 ∧ code e1203076598838 = 5601123109942 := by decide
theorem cert_e1203076598838 : check e1203076598838 [[]] .width = true := by decide
def e1203076598842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1203076598842 : Closed e1203076598842 ∧ code e1203076598842 = 5601123109946 := by decide
theorem cert_e1203076598842 : check e1203076598842 [[]] .width = true := by decide
def e1203076598982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203076598982 : Closed e1203076598982 ∧ code e1203076598982 = 5601123110086 := by decide
theorem cert_e1203076598982 : check e1203076598982 [[]] .width = true := by decide
def e1203076599322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203076599322 : Closed e1203076599322 ∧ code e1203076599322 = 5601123110426 := by decide
theorem cert_e1203076599322 : check e1203076599322 [[]] .width = true := by decide
def e1203076599414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1203076599414 : Closed e1203076599414 ∧ code e1203076599414 = 5601123110518 := by decide
theorem cert_e1203076599414 : check e1203076599414 [[]] .width = true := by decide
def e1203076607002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1203076607002 : Closed e1203076607002 ∧ code e1203076607002 = 5601123118106 := by decide
theorem cert_e1203076607002 : check e1203076607002 [[]] .width = true := by decide
def e1203076607046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1203076607046 : Closed e1203076607046 ∧ code e1203076607046 = 5601123118150 := by decide
theorem cert_e1203076607046 : check e1203076607046 [[]] .width = true := by decide
def e1203076607074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1203076607074 : Closed e1203076607074 ∧ code e1203076607074 = 5601123118178 := by decide
theorem cert_e1203076607074 : check e1203076607074 [[]] .width = true := by decide
def e1203076607238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1203076607238 : Closed e1203076607238 ∧ code e1203076607238 = 5601123118342 := by decide
theorem cert_e1203076607238 : check e1203076607238 [[]] .width = true := by decide
def e1203076608030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1203076608030 : Closed e1203076608030 ∧ code e1203076608030 = 5601123119134 := by decide
theorem cert_e1203076608030 : check e1203076608030 [[]] .width = true := by decide
def e1203076608198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203076608198 : Closed e1203076608198 ∧ code e1203076608198 = 5601123119302 := by decide
theorem cert_e1203076608198 : check e1203076608198 [[]] .width = true := by decide
def e1203076608226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1203076608226 : Closed e1203076608226 ∧ code e1203076608226 = 5601123119330 := by decide
theorem cert_e1203076608226 : check e1203076608226 [[]] .width = true := by decide
def e1203076608774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1203076608774 : Closed e1203076608774 ∧ code e1203076608774 = 5601123119878 := by decide
theorem cert_e1203076608774 : check e1203076608774 [[]] .width = true := by decide
def e1203095658010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095658010 : Closed e1203095658010 ∧ code e1203095658010 = 5601142169114 := by decide
theorem cert_e1203095658010 : check e1203095658010 [[]] .width = true := by decide
def e1203095664154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095664154 : Closed e1203095664154 ∧ code e1203095664154 = 5601142175258 := by decide
private def t_e1203095664154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1203095664154 : ¬ IsSelfInterpreter e1203095664154 :=
  wSource (t := t_e1203095664154) (replay_sound (ps := []) (t := e1203095664154) (by decide)) (by decide)
def e1203095690778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095690778 : Closed e1203095690778 ∧ code e1203095690778 = 5601142201882 := by decide
theorem cert_e1203095690778 : check e1203095690778 [[]] .width = true := by decide
def e1203095697946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095697946 : Closed e1203095697946 ∧ code e1203095697946 = 5601142209050 := by decide
theorem cert_e1203095697946 : check e1203095697946 [[]] .width = true := by decide
def e1203095721498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095721498 : Closed e1203095721498 ∧ code e1203095721498 = 5601142232602 := by decide
private def t_e1203095721498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1203095721498 : ¬ IsSelfInterpreter e1203095721498 :=
  wSource (t := t_e1203095721498) (replay_sound (ps := []) (t := e1203095721498) (by decide)) (by decide)
def e1203095722522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095722522 : Closed e1203095722522 ∧ code e1203095722522 = 5601142233626 := by decide
theorem cert_e1203095722522 : check e1203095722522 [[]] .width = true := by decide
def e1203095854618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095854618 : Closed e1203095854618 ∧ code e1203095854618 = 5601142365722 := by decide
theorem cert_e1203095854618 : check e1203095854618 [[]] .width = true := by decide
def e1203095860762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203095860762 : Closed e1203095860762 ∧ code e1203095860762 = 5601142371866 := by decide
theorem cert_e1203095860762 : check e1203095860762 [[]] .width = true := by decide
def e1203096025114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203096025114 : Closed e1203096025114 ∧ code e1203096025114 = 5601142536218 := by decide
theorem cert_e1203096025114 : check e1203096025114 [[]] .width = true := by decide
def e1203096051226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203096051226 : Closed e1203096051226 ∧ code e1203096051226 = 5601142562330 := by decide
theorem cert_e1203096051226 : check e1203096051226 [[]] .width = true := by decide
def e1203096058394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203096058394 : Closed e1203096058394 ∧ code e1203096058394 = 5601142569498 := by decide
theorem cert_e1203096058394 : check e1203096058394 [[]] .width = true := by decide
def e1203096109254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203096109254 : Closed e1203096109254 ∧ code e1203096109254 = 5601142620358 := by decide
theorem cert_e1203096109254 : check e1203096109254 [[]] .width = true := by decide
def e1203096139802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203096139802 : Closed e1203096139802 ∧ code e1203096139802 = 5601142650906 := by decide
theorem cert_e1203096139802 : check e1203096139802 [[]] .width = true := by decide
def e1203096174790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203096174790 : Closed e1203096174790 ∧ code e1203096174790 = 5601142685894 := by decide
theorem cert_e1203096174790 : check e1203096174790 [[]] .width = true := by decide
def e1203096204826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203096204826 : Closed e1203096204826 ∧ code e1203096204826 = 5601142715930 := by decide
theorem cert_e1203096204826 : check e1203096204826 [[]] .width = true := by decide
def e1203096205850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203096205850 : Closed e1203096205850 ∧ code e1203096205850 = 5601142716954 := by decide
theorem cert_e1203096205850 : check e1203096205850 [[]] .width = true := by decide
def e1203099971782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203099971782 : Closed e1203099971782 ∧ code e1203099971782 = 5601146482886 := by decide
theorem cert_e1203099971782 : check e1203099971782 [[]] .width = true := by decide
def e1203099981850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203099981850 : Closed e1203099981850 ∧ code e1203099981850 = 5601146492954 := by decide
theorem cert_e1203099981850 : check e1203099981850 [[]] .width = true := by decide
def e1203099985946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203099985946 : Closed e1203099985946 ∧ code e1203099985946 = 5601146497050 := by decide
theorem cert_e1203099985946 : check e1203099985946 [[]] .width = true := by decide
def e1203099987482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203099987482 : Closed e1203099987482 ∧ code e1203099987482 = 5601146498586 := by decide
theorem cert_e1203099987482 : check e1203099987482 [[]] .width = true := by decide
def e1203099989530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203099989530 : Closed e1203099989530 ∧ code e1203099989530 = 5601146500634 := by decide
theorem cert_e1203099989530 : check e1203099989530 [[]] .width = true := by decide
def e1203100071962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100071962 : Closed e1203100071962 ∧ code e1203100071962 = 5601146583066 := by decide
theorem cert_e1203100071962 : check e1203100071962 [[]] .width = true := by decide
def e1203100106950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203100106950 : Closed e1203100106950 ∧ code e1203100106950 = 5601146618054 := by decide
theorem cert_e1203100106950 : check e1203100106950 [[]] .width = true := by decide
def e1203100127430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100127430 : Closed e1203100127430 ∧ code e1203100127430 = 5601146638534 := by decide
theorem cert_e1203100127430 : check e1203100127430 [[]] .width = true := by decide
def e1203100129306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100129306 : Closed e1203100129306 ∧ code e1203100129306 = 5601146640410 := by decide
theorem cert_e1203100129306 : check e1203100129306 [[]] .width = true := by decide
def e1203100130842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100130842 : Closed e1203100130842 ∧ code e1203100130842 = 5601146641946 := by decide
theorem cert_e1203100130842 : check e1203100130842 [[]] .width = true := by decide
def e1203100139718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203100139718 : Closed e1203100139718 ∧ code e1203100139718 = 5601146650822 := by decide
theorem cert_e1203100139718 : check e1203100139718 [[]] .width = true := by decide
def e1203100147738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203100147738 : Closed e1203100147738 ∧ code e1203100147738 = 5601146658842 := by decide
theorem cert_e1203100147738 : check e1203100147738 [[]] .width = true := by decide
def e1203100147830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203100147830 : Closed e1203100147830 ∧ code e1203100147830 = 5601146658934 := by decide
theorem cert_e1203100147830 : check e1203100147830 [[]] .width = true := by decide
def e1203100148074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203100148074 : Closed e1203100148074 ∧ code e1203100148074 = 5601146659178 := by decide
theorem cert_e1203100148074 : check e1203100148074 [[]] .width = true := by decide
def e1203100148122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203100148122 : Closed e1203100148122 ∧ code e1203100148122 = 5601146659226 := by decide
theorem cert_e1203100148122 : check e1203100148122 [[]] .width = true := by decide
def e1203100152006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100152006 : Closed e1203100152006 ∧ code e1203100152006 = 5601146663110 := by decide
theorem cert_e1203100152006 : check e1203100152006 [[]] .width = true := by decide
def e1203100159514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100159514 : Closed e1203100159514 ∧ code e1203100159514 = 5601146670618 := by decide
theorem cert_e1203100159514 : check e1203100159514 [[]] .width = true := by decide
def e1203100168390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100168390 : Closed e1203100168390 ∧ code e1203100168390 = 5601146679494 := by decide
theorem cert_e1203100168390 : check e1203100168390 [[]] .width = true := by decide
def e1203100209350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100209350 : Closed e1203100209350 ∧ code e1203100209350 = 5601146720454 := by decide
theorem cert_e1203100209350 : check e1203100209350 [[]] .width = true := by decide
def e1203100215322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100215322 : Closed e1203100215322 ∧ code e1203100215322 = 5601146726426 := by decide
theorem cert_e1203100215322 : check e1203100215322 [[]] .width = true := by decide
def e1203100216858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100216858 : Closed e1203100216858 ∧ code e1203100216858 = 5601146727962 := by decide
theorem cert_e1203100216858 : check e1203100216858 [[]] .width = true := by decide
def e1203100219930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100219930 : Closed e1203100219930 ∧ code e1203100219930 = 5601146731034 := by decide
theorem cert_e1203100219930 : check e1203100219930 [[]] .width = true := by decide
def e1203100258502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100258502 : Closed e1203100258502 ∧ code e1203100258502 = 5601146769606 := by decide
theorem cert_e1203100258502 : check e1203100258502 [[]] .width = true := by decide
def e1203100260378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100260378 : Closed e1203100260378 ∧ code e1203100260378 = 5601146771482 := by decide
theorem cert_e1203100260378 : check e1203100260378 [[]] .width = true := by decide
def e1203100261914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100261914 : Closed e1203100261914 ∧ code e1203100261914 = 5601146773018 := by decide
theorem cert_e1203100261914 : check e1203100261914 [[]] .width = true := by decide
def e1203100270790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203100270790 : Closed e1203100270790 ∧ code e1203100270790 = 5601146781894 := by decide
theorem cert_e1203100270790 : check e1203100270790 [[]] .width = true := by decide
def e1203100278810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203100278810 : Closed e1203100278810 ∧ code e1203100278810 = 5601146789914 := by decide
theorem cert_e1203100278810 : check e1203100278810 [[]] .width = true := by decide
def e1203100278902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203100278902 : Closed e1203100278902 ∧ code e1203100278902 = 5601146790006 := by decide
theorem cert_e1203100278902 : check e1203100278902 [[]] .width = true := by decide
def e1203100279146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203100279146 : Closed e1203100279146 ∧ code e1203100279146 = 5601146790250 := by decide
theorem cert_e1203100279146 : check e1203100279146 [[]] .width = true := by decide
def e1203100279194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203100279194 : Closed e1203100279194 ∧ code e1203100279194 = 5601146790298 := by decide
theorem cert_e1203100279194 : check e1203100279194 [[]] .width = true := by decide
def e1203100283078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100283078 : Closed e1203100283078 ∧ code e1203100283078 = 5601146794182 := by decide
theorem cert_e1203100283078 : check e1203100283078 [[]] .width = true := by decide
def e1203100295194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203100295194 : Closed e1203100295194 ∧ code e1203100295194 = 5601146806298 := by decide
theorem cert_e1203100295194 : check e1203100295194 [[]] .width = true := by decide
def e1203100295286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203100295286 : Closed e1203100295286 ∧ code e1203100295286 = 5601146806390 := by decide
private def t_e1203100295286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1203100295286 : ¬ IsSelfInterpreter e1203100295286 :=
  wSource (t := t_e1203100295286) (replay_sound (ps := []) (t := e1203100295286) (by decide)) (by decide)
def e1203100295530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203100295530 : Closed e1203100295530 ∧ code e1203100295530 = 5601146806634 := by decide
private def t_e1203100295530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1203100295530 : ¬ IsSelfInterpreter e1203100295530 :=
  wSource (t := t_e1203100295530) (replay_sound (ps := []) (t := e1203100295530) (by decide)) (by decide)
def e1203100295578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203100295578 : Closed e1203100295578 ∧ code e1203100295578 = 5601146806682 := by decide
private def t_e1203100295578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1203100295578 : ¬ IsSelfInterpreter e1203100295578 :=
  wSource (t := t_e1203100295578) (replay_sound (ps := []) (t := e1203100295578) (by decide)) (by decide)
def e1203100304922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100304922 : Closed e1203100304922 ∧ code e1203100304922 = 5601146816026 := by decide
private def t_e1203100304922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1203100304922 : ¬ IsSelfInterpreter e1203100304922 :=
  wSource (t := t_e1203100304922) (replay_sound (ps := []) (t := e1203100304922) (by decide)) (by decide)
def e1203100307654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100307654 : Closed e1203100307654 ∧ code e1203100307654 = 5601146818758 := by decide
theorem cert_e1203100307654 : check e1203100307654 [[]] .width = true := by decide
def e1203100333594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100333594 : Closed e1203100333594 ∧ code e1203100333594 = 5601146844698 := by decide
theorem cert_e1203100333594 : check e1203100333594 [[]] .width = true := by decide
def e1203100334618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100334618 : Closed e1203100334618 ∧ code e1203100334618 = 5601146845722 := by decide
theorem cert_e1203100334618 : check e1203100334618 [[]] .width = true := by decide
def e1203100356122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100356122 : Closed e1203100356122 ∧ code e1203100356122 = 5601146867226 := by decide
theorem cert_e1203100356122 : check e1203100356122 [[]] .width = true := by decide
def e1203100364998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100364998 : Closed e1203100364998 ∧ code e1203100364998 = 5601146876102 := by decide
theorem cert_e1203100364998 : check e1203100364998 [[]] .width = true := by decide
def e1203100370458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100370458 : Closed e1203100370458 ∧ code e1203100370458 = 5601146881562 := by decide
private def t_e1203100370458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1203100370458 : ¬ IsSelfInterpreter e1203100370458 :=
  wSource (t := t_e1203100370458) (replay_sound (ps := []) (t := e1203100370458) (by decide)) (by decide)
def e1203100373190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100373190 : Closed e1203100373190 ∧ code e1203100373190 = 5601146884294 := by decide
theorem cert_e1203100373190 : check e1203100373190 [[]] .width = true := by decide
def e1203100512454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100512454 : Closed e1203100512454 ∧ code e1203100512454 = 5601147023558 := by decide
theorem cert_e1203100512454 : check e1203100512454 [[]] .width = true := by decide
def e1203100563482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100563482 : Closed e1203100563482 ∧ code e1203100563482 = 5601147074586 := by decide
theorem cert_e1203100563482 : check e1203100563482 [[]] .width = true := by decide
def e1203100575770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100575770 : Closed e1203100575770 ∧ code e1203100575770 = 5601147086874 := by decide
theorem cert_e1203100575770 : check e1203100575770 [[]] .width = true := by decide
def e1203100680218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203100680218 : Closed e1203100680218 ∧ code e1203100680218 = 5601147191322 := by decide
theorem cert_e1203100680218 : check e1203100680218 [[]] .width = true := by decide
def e1203100680310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1203100680310 : Closed e1203100680310 ∧ code e1203100680310 = 5601147191414 := by decide
theorem cert_e1203100680310 : check e1203100680310 [[]] .width = true := by decide
def e1203100680554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1203100680554 : Closed e1203100680554 ∧ code e1203100680554 = 5601147191658 := by decide
theorem cert_e1203100680554 : check e1203100680554 [[]] .width = true := by decide
def e1203100680602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1203100680602 : Closed e1203100680602 ∧ code e1203100680602 = 5601147191706 := by decide
theorem cert_e1203100680602 : check e1203100680602 [[]] .width = true := by decide
def e1203100681610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1203100681610 : Closed e1203100681610 ∧ code e1203100681610 = 5601147192714 := by decide
theorem cert_e1203100681610 : check e1203100681610 [[]] .width = true := by decide
def e1203100681634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1203100681634 : Closed e1203100681634 ∧ code e1203100681634 = 5601147192738 := by decide
theorem cert_e1203100681634 : check e1203100681634 [[]] .width = true := by decide
def e1203100681742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1203100681742 : Closed e1203100681742 ∧ code e1203100681742 = 5601147192846 := by decide
theorem cert_e1203100681742 : check e1203100681742 [[]] .width = true := by decide
def e1203100681754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203100681754 : Closed e1203100681754 ∧ code e1203100681754 = 5601147192858 := by decide
theorem cert_e1203100681754 : check e1203100681754 [[]] .width = true := by decide
def e1203100681826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1203100681826 : Closed e1203100681826 ∧ code e1203100681826 = 5601147192930 := by decide
theorem cert_e1203100681826 : check e1203100681826 [[]] .width = true := by decide
def e1203100858394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100858394 : Closed e1203100858394 ∧ code e1203100858394 = 5601147369498 := by decide
theorem cert_e1203100858394 : check e1203100858394 [[]] .width = true := by decide
def e1203100893382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203100893382 : Closed e1203100893382 ∧ code e1203100893382 = 5601147404486 := by decide
theorem cert_e1203100893382 : check e1203100893382 [[]] .width = true := by decide
def e1203100913862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100913862 : Closed e1203100913862 ∧ code e1203100913862 = 5601147424966 := by decide
theorem cert_e1203100913862 : check e1203100913862 [[]] .width = true := by decide
def e1203100915738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203100915738 : Closed e1203100915738 ∧ code e1203100915738 = 5601147426842 := by decide
theorem cert_e1203100915738 : check e1203100915738 [[]] .width = true := by decide
def e1203100917274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100917274 : Closed e1203100917274 ∧ code e1203100917274 = 5601147428378 := by decide
theorem cert_e1203100917274 : check e1203100917274 [[]] .width = true := by decide
def e1203100926150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203100926150 : Closed e1203100926150 ∧ code e1203100926150 = 5601147437254 := by decide
theorem cert_e1203100926150 : check e1203100926150 [[]] .width = true := by decide
def e1203100934170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203100934170 : Closed e1203100934170 ∧ code e1203100934170 = 5601147445274 := by decide
theorem cert_e1203100934170 : check e1203100934170 [[]] .width = true := by decide
def e1203100934262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203100934262 : Closed e1203100934262 ∧ code e1203100934262 = 5601147445366 := by decide
theorem cert_e1203100934262 : check e1203100934262 [[]] .width = true := by decide
def e1203100934506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203100934506 : Closed e1203100934506 ∧ code e1203100934506 = 5601147445610 := by decide
theorem cert_e1203100934506 : check e1203100934506 [[]] .width = true := by decide
def e1203100934554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203100934554 : Closed e1203100934554 ∧ code e1203100934554 = 5601147445658 := by decide
theorem cert_e1203100934554 : check e1203100934554 [[]] .width = true := by decide
def e1203100938438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100938438 : Closed e1203100938438 ∧ code e1203100938438 = 5601147449542 := by decide
theorem cert_e1203100938438 : check e1203100938438 [[]] .width = true := by decide
def e1203100945946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203100945946 : Closed e1203100945946 ∧ code e1203100945946 = 5601147457050 := by decide
theorem cert_e1203100945946 : check e1203100945946 [[]] .width = true := by decide
def e1203100954822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203100954822 : Closed e1203100954822 ∧ code e1203100954822 = 5601147465926 := by decide
theorem cert_e1203100954822 : check e1203100954822 [[]] .width = true := by decide
def e1203101237446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203101237446 : Closed e1203101237446 ∧ code e1203101237446 = 5601147748550 := by decide
theorem cert_e1203101237446 : check e1203101237446 [[]] .width = true := by decide
def e1203101237974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1203101237974 : Closed e1203101237974 ∧ code e1203101237974 = 5601147749078 := by decide
theorem cert_e1203101237974 : check e1203101237974 [[]] .width = true := by decide
def e1203101237978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1203101237978 : Closed e1203101237978 ∧ code e1203101237978 = 5601147749082 := by decide
theorem cert_e1203101237978 : check e1203101237978 [[]] .width = true := by decide
def e1203101237994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1203101237994 : Closed e1203101237994 ∧ code e1203101237994 = 5601147749098 := by decide
theorem cert_e1203101237994 : check e1203101237994 [[]] .width = true := by decide
def e1203101238070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1203101238070 : Closed e1203101238070 ∧ code e1203101238070 = 5601147749174 := by decide
theorem cert_e1203101238070 : check e1203101238070 [[]] .width = true := by decide
def e1203101238074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1203101238074 : Closed e1203101238074 ∧ code e1203101238074 = 5601147749178 := by decide
theorem cert_e1203101238074 : check e1203101238074 [[]] .width = true := by decide
def e1203101238158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1203101238158 : Closed e1203101238158 ∧ code e1203101238158 = 5601147749262 := by decide
theorem cert_e1203101238158 : check e1203101238158 [[]] .width = true := by decide
def e1203101238170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1203101238170 : Closed e1203101238170 ∧ code e1203101238170 = 5601147749274 := by decide
theorem cert_e1203101238170 : check e1203101238170 [[]] .width = true := by decide
def e1203101240090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1203101240090 : Closed e1203101240090 ∧ code e1203101240090 = 5601147751194 := by decide
theorem cert_e1203101240090 : check e1203101240090 [[]] .width = true := by decide
def e1203101240134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1203101240134 : Closed e1203101240134 ∧ code e1203101240134 = 5601147751238 := by decide
theorem cert_e1203101240134 : check e1203101240134 [[]] .width = true := by decide
def e1203101240246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1203101240246 : Closed e1203101240246 ∧ code e1203101240246 = 5601147751350 := by decide
theorem cert_e1203101240246 : check e1203101240246 [[]] .width = true := by decide
def e1203101240374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1203101240374 : Closed e1203101240374 ∧ code e1203101240374 = 5601147751478 := by decide
theorem cert_e1203101240374 : check e1203101240374 [[]] .width = true := by decide
def e1203101240378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1203101240378 : Closed e1203101240378 ∧ code e1203101240378 = 5601147751482 := by decide
theorem cert_e1203101240378 : check e1203101240378 [[]] .width = true := by decide
def e1203101240518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203101240518 : Closed e1203101240518 ∧ code e1203101240518 = 5601147751622 := by decide
theorem cert_e1203101240518 : check e1203101240518 [[]] .width = true := by decide
def e1203101240858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203101240858 : Closed e1203101240858 ∧ code e1203101240858 = 5601147751962 := by decide
theorem cert_e1203101240858 : check e1203101240858 [[]] .width = true := by decide
def e1203101240950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1203101240950 : Closed e1203101240950 ∧ code e1203101240950 = 5601147752054 := by decide
theorem cert_e1203101240950 : check e1203101240950 [[]] .width = true := by decide
def e1203101248538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1203101248538 : Closed e1203101248538 ∧ code e1203101248538 = 5601147759642 := by decide
theorem cert_e1203101248538 : check e1203101248538 [[]] .width = true := by decide
def e1203101248582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1203101248582 : Closed e1203101248582 ∧ code e1203101248582 = 5601147759686 := by decide
theorem cert_e1203101248582 : check e1203101248582 [[]] .width = true := by decide
def e1203101248610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1203101248610 : Closed e1203101248610 ∧ code e1203101248610 = 5601147759714 := by decide
theorem cert_e1203101248610 : check e1203101248610 [[]] .width = true := by decide
def e1203101248774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1203101248774 : Closed e1203101248774 ∧ code e1203101248774 = 5601147759878 := by decide
theorem cert_e1203101248774 : check e1203101248774 [[]] .width = true := by decide
def e1203101249566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1203101249566 : Closed e1203101249566 ∧ code e1203101249566 = 5601147760670 := by decide
theorem cert_e1203101249566 : check e1203101249566 [[]] .width = true := by decide
def e1203101249734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203101249734 : Closed e1203101249734 ∧ code e1203101249734 = 5601147760838 := by decide
theorem cert_e1203101249734 : check e1203101249734 [[]] .width = true := by decide
def e1203101249762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1203101249762 : Closed e1203101249762 ∧ code e1203101249762 = 5601147760866 := by decide
theorem cert_e1203101249762 : check e1203101249762 [[]] .width = true := by decide
def e1203101250310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1203101250310 : Closed e1203101250310 ∧ code e1203101250310 = 5601147761414 := by decide
theorem cert_e1203101250310 : check e1203101250310 [[]] .width = true := by decide
def e1203101528262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203101528262 : Closed e1203101528262 ∧ code e1203101528262 = 5601148039366 := by decide
theorem cert_e1203101528262 : check e1203101528262 [[]] .width = true := by decide
def e1203101554714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203101554714 : Closed e1203101554714 ∧ code e1203101554714 = 5601148065818 := by decide
theorem cert_e1203101554714 : check e1203101554714 [[]] .width = true := by decide
def e1203101558810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203101558810 : Closed e1203101558810 ∧ code e1203101558810 = 5601148069914 := by decide
theorem cert_e1203101558810 : check e1203101558810 [[]] .width = true := by decide
def e1203101597722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203101597722 : Closed e1203101597722 ∧ code e1203101597722 = 5601148108826 := by decide
theorem cert_e1203101597722 : check e1203101597722 [[]] .width = true := by decide
def e1203101597814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1203101597814 : Closed e1203101597814 ∧ code e1203101597814 = 5601148108918 := by decide
theorem cert_e1203101597814 : check e1203101597814 [[]] .width = true := by decide
def e1203101598058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1203101598058 : Closed e1203101598058 ∧ code e1203101598058 = 5601148109162 := by decide
theorem cert_e1203101598058 : check e1203101598058 [[]] .width = true := by decide
def e1203101598106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1203101598106 : Closed e1203101598106 ∧ code e1203101598106 = 5601148109210 := by decide
theorem cert_e1203101598106 : check e1203101598106 [[]] .width = true := by decide
def e1203101599114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1203101599114 : Closed e1203101599114 ∧ code e1203101599114 = 5601148110218 := by decide
theorem cert_e1203101599114 : check e1203101599114 [[]] .width = true := by decide
def e1203101599138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1203101599138 : Closed e1203101599138 ∧ code e1203101599138 = 5601148110242 := by decide
theorem cert_e1203101599138 : check e1203101599138 [[]] .width = true := by decide
end Blc.Floor42
