import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211206047582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211206047582 : Closed e1211206047582 ∧ code e1211206047582 = 5609252558686 := by decide
theorem cert_e1211206047582 : check e1211206047582 [[],[]] .smaller = true := by decide
def e1211206047598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e1211206047598 : Closed e1211206047598 ∧ code e1211206047598 = 5609252558702 := by decide
theorem cert_e1211206047598 : check e1211206047598 [[],[]] .smaller = true := by decide
def e1211206047606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e1211206047606 : Closed e1211206047606 ∧ code e1211206047606 = 5609252558710 := by decide
theorem cert_e1211206047606 : check e1211206047606 [[],[]] .smaller = true := by decide
def e1211206047610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211206047610 : Closed e1211206047610 ∧ code e1211206047610 = 5609252558714 := by decide
theorem cert_e1211206047610 : check e1211206047610 [[],[]] .smaller = true := by decide
def e1211206047670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e1211206047670 : Closed e1211206047670 ∧ code e1211206047670 = 5609252558774 := by decide
theorem cert_e1211206047670 : check e1211206047670 [[],[]] .smaller = true := by decide
def e1211206047702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211206047702 : Closed e1211206047702 ∧ code e1211206047702 = 5609252558806 := by decide
theorem cert_e1211206047702 : check e1211206047702 [[],[]] .smaller = true := by decide
def e1211206047706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211206047706 : Closed e1211206047706 ∧ code e1211206047706 = 5609252558810 := by decide
theorem cert_e1211206047706 : check e1211206047706 [[],[]] .smaller = true := by decide
def e1211206048222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211206048222 : Closed e1211206048222 ∧ code e1211206048222 = 5609252559326 := by decide
theorem cert_e1211206048222 : check e1211206048222 [[],[]] .smaller = true := by decide
def e1211206048246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211206048246 : Closed e1211206048246 ∧ code e1211206048246 = 5609252559350 := by decide
theorem cert_e1211206048246 : check e1211206048246 [[],[]] .smaller = true := by decide
def e1211206048990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211206048990 : Closed e1211206048990 ∧ code e1211206048990 = 5609252560094 := by decide
theorem cert_e1211206048990 : check e1211206048990 [[],[]] .smaller = true := by decide
def e1211206049006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211206049006 : Closed e1211206049006 ∧ code e1211206049006 = 5609252560110 := by decide
theorem cert_e1211206049006 : check e1211206049006 [[],[]] .smaller = true := by decide
def e1211206049014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211206049014 : Closed e1211206049014 ∧ code e1211206049014 = 5609252560118 := by decide
theorem cert_e1211206049014 : check e1211206049014 [[],[]] .smaller = true := by decide
def e1211206049018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211206049018 : Closed e1211206049018 ∧ code e1211206049018 = 5609252560122 := by decide
theorem cert_e1211206049018 : check e1211206049018 [[],[]] .smaller = true := by decide
def e1211206049342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e1211206049342 : Closed e1211206049342 ∧ code e1211206049342 = 5609252560446 := by decide
theorem cert_e1211206049342 : check e1211206049342 [[],[]] .smaller = true := by decide
def e1211206049398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211206049398 : Closed e1211206049398 ∧ code e1211206049398 = 5609252560502 := by decide
theorem cert_e1211206049398 : check e1211206049398 [[],[]] .smaller = true := by decide
def e1211206049566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e1211206049566 : Closed e1211206049566 ∧ code e1211206049566 = 5609252560670 := by decide
theorem cert_e1211206049566 : check e1211206049566 [[],[]] .smaller = true := by decide
def e1211206049590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206049590 : Closed e1211206049590 ∧ code e1211206049590 = 5609252560694 := by decide
theorem cert_e1211206049590 : check e1211206049590 [[],[]] .smaller = true := by decide
def e1211206049594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206049594 : Closed e1211206049594 ∧ code e1211206049594 = 5609252560698 := by decide
theorem cert_e1211206049594 : check e1211206049594 [[],[]] .smaller = true := by decide
def e1211206060894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211206060894 : Closed e1211206060894 ∧ code e1211206060894 = 5609252571998 := by decide
theorem cert_e1211206060894 : check e1211206060894 [[],[]] .smaller = true := by decide
def e1211206060910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211206060910 : Closed e1211206060910 ∧ code e1211206060910 = 5609252572014 := by decide
theorem cert_e1211206060910 : check e1211206060910 [[],[]] .smaller = true := by decide
def e1211206060918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211206060918 : Closed e1211206060918 ∧ code e1211206060918 = 5609252572022 := by decide
theorem cert_e1211206060918 : check e1211206060918 [[],[]] .smaller = true := by decide
def e1211206060922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211206060922 : Closed e1211206060922 ∧ code e1211206060922 = 5609252572026 := by decide
theorem cert_e1211206060922 : check e1211206060922 [[],[]] .smaller = true := by decide
def e1211206060974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211206060974 : Closed e1211206060974 ∧ code e1211206060974 = 5609252572078 := by decide
theorem cert_e1211206060974 : check e1211206060974 [[],[]] .smaller = true := by decide
def e1211206060986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211206060986 : Closed e1211206060986 ∧ code e1211206060986 = 5609252572090 := by decide
theorem cert_e1211206060986 : check e1211206060986 [[],[]] .smaller = true := by decide
def e1211206061014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211206061014 : Closed e1211206061014 ∧ code e1211206061014 = 5609252572118 := by decide
theorem cert_e1211206061014 : check e1211206061014 [[],[]] .smaller = true := by decide
def e1211206061018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211206061018 : Closed e1211206061018 ∧ code e1211206061018 = 5609252572122 := by decide
theorem cert_e1211206061018 : check e1211206061018 [[],[]] .smaller = true := by decide
def e1211206061034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211206061034 : Closed e1211206061034 ∧ code e1211206061034 = 5609252572138 := by decide
theorem cert_e1211206061034 : check e1211206061034 [[],[]] .smaller = true := by decide
def e1211206061278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211206061278 : Closed e1211206061278 ∧ code e1211206061278 = 5609252572382 := by decide
theorem cert_e1211206061278 : check e1211206061278 [[],[]] .smaller = true := by decide
def e1211206061294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211206061294 : Closed e1211206061294 ∧ code e1211206061294 = 5609252572398 := by decide
theorem cert_e1211206061294 : check e1211206061294 [[],[]] .smaller = true := by decide
def e1211206061302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211206061302 : Closed e1211206061302 ∧ code e1211206061302 = 5609252572406 := by decide
theorem cert_e1211206061302 : check e1211206061302 [[],[]] .smaller = true := by decide
def e1211206061306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211206061306 : Closed e1211206061306 ∧ code e1211206061306 = 5609252572410 := by decide
theorem cert_e1211206061306 : check e1211206061306 [[],[]] .smaller = true := by decide
def e1211206061678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211206061678 : Closed e1211206061678 ∧ code e1211206061678 = 5609252572782 := by decide
theorem cert_e1211206061678 : check e1211206061678 [[],[]] .smaller = true := by decide
def e1211206061690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211206061690 : Closed e1211206061690 ∧ code e1211206061690 = 5609252572794 := by decide
theorem cert_e1211206061690 : check e1211206061690 [[],[]] .smaller = true := by decide
def e1211206061878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206061878 : Closed e1211206061878 ∧ code e1211206061878 = 5609252572982 := by decide
theorem cert_e1211206061878 : check e1211206061878 [[],[]] .smaller = true := by decide
def e1211206061882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206061882 : Closed e1211206061882 ∧ code e1211206061882 = 5609252572986 := by decide
theorem cert_e1211206061882 : check e1211206061882 [[],[]] .smaller = true := by decide
def e1211206061978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211206061978 : Closed e1211206061978 ∧ code e1211206061978 = 5609252573082 := by decide
theorem cert_e1211206061978 : check e1211206061978 [[],[]] .smaller = true := by decide
def e1211206067638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211206067638 : Closed e1211206067638 ∧ code e1211206067638 = 5609252578742 := by decide
theorem cert_e1211206067638 : check e1211206067638 [[],[]] .smaller = true := by decide
def e1211206067670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211206067670 : Closed e1211206067670 ∧ code e1211206067670 = 5609252578774 := by decide
theorem cert_e1211206067670 : check e1211206067670 [[],[]] .smaller = true := by decide
def e1211206067674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211206067674 : Closed e1211206067674 ∧ code e1211206067674 = 5609252578778 := by decide
theorem cert_e1211206067674 : check e1211206067674 [[],[]] .smaller = true := by decide
def e1211206067774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e1211206067774 : Closed e1211206067774 ∧ code e1211206067774 = 5609252578878 := by decide
theorem cert_e1211206067774 : check e1211206067774 [[],[]] .smaller = true := by decide
def e1211206067830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211206067830 : Closed e1211206067830 ∧ code e1211206067830 = 5609252578934 := by decide
theorem cert_e1211206067830 : check e1211206067830 [[],[]] .smaller = true := by decide
def e1211206068022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206068022 : Closed e1211206068022 ∧ code e1211206068022 = 5609252579126 := by decide
theorem cert_e1211206068022 : check e1211206068022 [[],[]] .smaller = true := by decide
def e1211206068026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206068026 : Closed e1211206068026 ∧ code e1211206068026 = 5609252579130 := by decide
theorem cert_e1211206068026 : check e1211206068026 [[],[]] .smaller = true := by decide
def e1211206068166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e1211206068166 : Closed e1211206068166 ∧ code e1211206068166 = 5609252579270 := by decide
theorem cert_e1211206068166 : check e1211206068166 [[],[]] .smaller = true := by decide
def e1211206070998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211206070998 : Closed e1211206070998 ∧ code e1211206070998 = 5609252582102 := by decide
theorem cert_e1211206070998 : check e1211206070998 [[],[]] .smaller = true := by decide
def e1211206071002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211206071002 : Closed e1211206071002 ∧ code e1211206071002 = 5609252582106 := by decide
theorem cert_e1211206071002 : check e1211206071002 [[],[]] .smaller = true := by decide
def e1211206071018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211206071018 : Closed e1211206071018 ∧ code e1211206071018 = 5609252582122 := by decide
theorem cert_e1211206071018 : check e1211206071018 [[],[]] .smaller = true := by decide
def e1211206071070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211206071070 : Closed e1211206071070 ∧ code e1211206071070 = 5609252582174 := by decide
theorem cert_e1211206071070 : check e1211206071070 [[],[]] .smaller = true := by decide
def e1211206071094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211206071094 : Closed e1211206071094 ∧ code e1211206071094 = 5609252582198 := by decide
theorem cert_e1211206071094 : check e1211206071094 [[],[]] .smaller = true := by decide
def e1211206071098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211206071098 : Closed e1211206071098 ∧ code e1211206071098 = 5609252582202 := by decide
theorem cert_e1211206071098 : check e1211206071098 [[],[]] .smaller = true := by decide
def e1211206071194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211206071194 : Closed e1211206071194 ∧ code e1211206071194 = 5609252582298 := by decide
theorem cert_e1211206071194 : check e1211206071194 [[],[]] .smaller = true := by decide
def e1211206071238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211206071238 : Closed e1211206071238 ∧ code e1211206071238 = 5609252582342 := by decide
theorem cert_e1211206071238 : check e1211206071238 [[],[]] .smaller = true := by decide
def e1211206296286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e1211206296286 : Closed e1211206296286 ∧ code e1211206296286 = 5609252807390 := by decide
theorem cert_e1211206296286 : check e1211206296286 [[],[]] .chain = true := by decide
def e1211206296310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e1211206296310 : Closed e1211206296310 ∧ code e1211206296310 = 5609252807414 := by decide
theorem cert_e1211206296310 : check e1211206296310 [[],[]] .chain = true := by decide
def e1211206296430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e1211206296430 : Closed e1211206296430 ∧ code e1211206296430 = 5609252807534 := by decide
theorem cert_e1211206296430 : check e1211206296430 [[],[]] .smaller = true := by decide
def e1211206296438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e1211206296438 : Closed e1211206296438 ∧ code e1211206296438 = 5609252807542 := by decide
theorem cert_e1211206296438 : check e1211206296438 [[],[]] .smaller = true := by decide
def e1211206296494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e1211206296494 : Closed e1211206296494 ∧ code e1211206296494 = 5609252807598 := by decide
theorem cert_e1211206296494 : check e1211206296494 [[],[]] .smaller = true := by decide
def e1211206296506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e1211206296506 : Closed e1211206296506 ∧ code e1211206296506 = 5609252807610 := by decide
theorem cert_e1211206296506 : check e1211206296506 [[],[]] .smaller = true := by decide
def e1211206296534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e1211206296534 : Closed e1211206296534 ∧ code e1211206296534 = 5609252807638 := by decide
theorem cert_e1211206296534 : check e1211206296534 [[],[]] .smaller = true := by decide
def e1211206296538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e1211206296538 : Closed e1211206296538 ∧ code e1211206296538 = 5609252807642 := by decide
theorem cert_e1211206296538 : check e1211206296538 [[],[]] .smaller = true := by decide
def e1211206297838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211206297838 : Closed e1211206297838 ∧ code e1211206297838 = 5609252808942 := by decide
theorem cert_e1211206297838 : check e1211206297838 [[],[]] .smaller = true := by decide
def e1211206297846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211206297846 : Closed e1211206297846 ∧ code e1211206297846 = 5609252808950 := by decide
theorem cert_e1211206297846 : check e1211206297846 [[],[]] .smaller = true := by decide
def e1211206298398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211206298398 : Closed e1211206298398 ∧ code e1211206298398 = 5609252809502 := by decide
theorem cert_e1211206298398 : check e1211206298398 [[],[]] .smaller = true := by decide
def e1211206298510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211206298510 : Closed e1211206298510 ∧ code e1211206298510 = 5609252809614 := by decide
theorem cert_e1211206298510 : check e1211206298510 [[],[]] .smaller = true := by decide
def e1211206298718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211206298718 : Closed e1211206298718 ∧ code e1211206298718 = 5609252809822 := by decide
theorem cert_e1211206298718 : check e1211206298718 [[],[]] .chain = true := by decide
def e1211206298734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211206298734 : Closed e1211206298734 ∧ code e1211206298734 = 5609252809838 := by decide
theorem cert_e1211206298734 : check e1211206298734 [[],[]] .smaller = true := by decide
def e1211206298746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211206298746 : Closed e1211206298746 ∧ code e1211206298746 = 5609252809850 := by decide
theorem cert_e1211206298746 : check e1211206298746 [[],[]] .smaller = true := by decide
def e1211206298910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211206298910 : Closed e1211206298910 ∧ code e1211206298910 = 5609252810014 := by decide
theorem cert_e1211206298910 : check e1211206298910 [[],[]] .smaller = true := by decide
def e1211206299078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211206299078 : Closed e1211206299078 ∧ code e1211206299078 = 5609252810182 := by decide
theorem cert_e1211206299078 : check e1211206299078 [[],[]] .smaller = true := by decide
def e1211206299102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e1211206299102 : Closed e1211206299102 ∧ code e1211206299102 = 5609252810206 := by decide
theorem cert_e1211206299102 : check e1211206299102 [[],[]] .chain = true := by decide
def e1211206299106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211206299106 : Closed e1211206299106 ∧ code e1211206299106 = 5609252810210 := by decide
theorem cert_e1211206299106 : check e1211206299106 [[],[]] .chain = true := by decide
def e1211206299118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e1211206299118 : Closed e1211206299118 ∧ code e1211206299118 = 5609252810222 := by decide
theorem cert_e1211206299118 : check e1211206299118 [[],[]] .chain = true := by decide
def e1211206299190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211206299190 : Closed e1211206299190 ∧ code e1211206299190 = 5609252810294 := by decide
theorem cert_e1211206299190 : check e1211206299190 [[],[]] .smaller = true := by decide
def e1211206299194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211206299194 : Closed e1211206299194 ∧ code e1211206299194 = 5609252810298 := by decide
theorem cert_e1211206299194 : check e1211206299194 [[],[]] .smaller = true := by decide
def e1211206299278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211206299278 : Closed e1211206299278 ∧ code e1211206299278 = 5609252810382 := by decide
theorem cert_e1211206299278 : check e1211206299278 [[],[]] .smaller = true := by decide
def e1211206299334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211206299334 : Closed e1211206299334 ∧ code e1211206299334 = 5609252810438 := by decide
theorem cert_e1211206299334 : check e1211206299334 [[],[]] .smaller = true := by decide
def e1211206299358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e1211206299358 : Closed e1211206299358 ∧ code e1211206299358 = 5609252810462 := by decide
theorem cert_e1211206299358 : check e1211206299358 [[],[]] .chain = true := by decide
def e1211206299382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e1211206299382 : Closed e1211206299382 ∧ code e1211206299382 = 5609252810486 := by decide
theorem cert_e1211206299382 : check e1211206299382 [[],[]] .chain = true := by decide
def e1211206299414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211206299414 : Closed e1211206299414 ∧ code e1211206299414 = 5609252810518 := by decide
theorem cert_e1211206299414 : check e1211206299414 [[],[]] .chain = true := by decide
def e1211206299490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211206299490 : Closed e1211206299490 ∧ code e1211206299490 = 5609252810594 := by decide
theorem cert_e1211206299490 : check e1211206299490 [[],[]] .chain = true := by decide
def e1211206299502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e1211206299502 : Closed e1211206299502 ∧ code e1211206299502 = 5609252810606 := by decide
theorem cert_e1211206299502 : check e1211206299502 [[],[]] .chain = true := by decide
def e1211206299510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e1211206299510 : Closed e1211206299510 ∧ code e1211206299510 = 5609252810614 := by decide
theorem cert_e1211206299510 : check e1211206299510 [[],[]] .chain = true := by decide
def e1211206299998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e1211206299998 : Closed e1211206299998 ∧ code e1211206299998 = 5609252811102 := by decide
theorem cert_e1211206299998 : check e1211206299998 [[],[]] .chain = true := by decide
def e1211206300026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e1211206300026 : Closed e1211206300026 ∧ code e1211206300026 = 5609252811130 := by decide
theorem cert_e1211206300026 : check e1211206300026 [[],[]] .chain = true := by decide
def e1211206300078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e1211206300078 : Closed e1211206300078 ∧ code e1211206300078 = 5609252811182 := by decide
theorem cert_e1211206300078 : check e1211206300078 [[],[]] .smaller = true := by decide
def e1211206300090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e1211206300090 : Closed e1211206300090 ∧ code e1211206300090 = 5609252811194 := by decide
theorem cert_e1211206300090 : check e1211206300090 [[],[]] .smaller = true := by decide
def e1211206300138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e1211206300138 : Closed e1211206300138 ∧ code e1211206300138 = 5609252811242 := by decide
theorem cert_e1211206300138 : check e1211206300138 [[],[]] .smaller = true := by decide
def e1211206300766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211206300766 : Closed e1211206300766 ∧ code e1211206300766 = 5609252811870 := by decide
theorem cert_e1211206300766 : check e1211206300766 [[],[]] .chain = true := by decide
def e1211206300782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211206300782 : Closed e1211206300782 ∧ code e1211206300782 = 5609252811886 := by decide
theorem cert_e1211206300782 : check e1211206300782 [[],[]] .smaller = true := by decide
def e1211206300794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211206300794 : Closed e1211206300794 ∧ code e1211206300794 = 5609252811898 := by decide
theorem cert_e1211206300794 : check e1211206300794 [[],[]] .smaller = true := by decide
def e1211206300958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211206300958 : Closed e1211206300958 ∧ code e1211206300958 = 5609252812062 := by decide
theorem cert_e1211206300958 : check e1211206300958 [[],[]] .smaller = true := by decide
def e1211206301126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211206301126 : Closed e1211206301126 ∧ code e1211206301126 = 5609252812230 := by decide
theorem cert_e1211206301126 : check e1211206301126 [[],[]] .smaller = true := by decide
def e1211206301150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211206301150 : Closed e1211206301150 ∧ code e1211206301150 = 5609252812254 := by decide
theorem cert_e1211206301150 : check e1211206301150 [[],[]] .chain = true := by decide
def e1211206301154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211206301154 : Closed e1211206301154 ∧ code e1211206301154 = 5609252812258 := by decide
theorem cert_e1211206301154 : check e1211206301154 [[],[]] .chain = true := by decide
def e1211206301166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211206301166 : Closed e1211206301166 ∧ code e1211206301166 = 5609252812270 := by decide
theorem cert_e1211206301166 : check e1211206301166 [[],[]] .chain = true := by decide
def e1211206301466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211206301466 : Closed e1211206301466 ∧ code e1211206301466 = 5609252812570 := by decide
theorem cert_e1211206301466 : check e1211206301466 [[],[]] .smaller = true := by decide
def e1211206301510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211206301510 : Closed e1211206301510 ∧ code e1211206301510 = 5609252812614 := by decide
theorem cert_e1211206301510 : check e1211206301510 [[],[]] .smaller = true := by decide
def e1211206301534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211206301534 : Closed e1211206301534 ∧ code e1211206301534 = 5609252812638 := by decide
theorem cert_e1211206301534 : check e1211206301534 [[],[]] .chain = true := by decide
def e1211206301562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211206301562 : Closed e1211206301562 ∧ code e1211206301562 = 5609252812666 := by decide
theorem cert_e1211206301562 : check e1211206301562 [[],[]] .chain = true := by decide
def e1211206301578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211206301578 : Closed e1211206301578 ∧ code e1211206301578 = 5609252812682 := by decide
theorem cert_e1211206301578 : check e1211206301578 [[],[]] .chain = true := by decide
def e1211206301602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211206301602 : Closed e1211206301602 ∧ code e1211206301602 = 5609252812706 := by decide
theorem cert_e1211206301602 : check e1211206301602 [[],[]] .chain = true := by decide
def e1211206301614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211206301614 : Closed e1211206301614 ∧ code e1211206301614 = 5609252812718 := by decide
theorem cert_e1211206301614 : check e1211206301614 [[],[]] .chain = true := by decide
def e1211206301626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211206301626 : Closed e1211206301626 ∧ code e1211206301626 = 5609252812730 := by decide
theorem cert_e1211206301626 : check e1211206301626 [[],[]] .chain = true := by decide
def e1211206301910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e1211206301910 : Closed e1211206301910 ∧ code e1211206301910 = 5609252813014 := by decide
theorem cert_e1211206301910 : check e1211206301910 [[],[]] .smaller = true := by decide
def e1211206301914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e1211206301914 : Closed e1211206301914 ∧ code e1211206301914 = 5609252813018 := by decide
theorem cert_e1211206301914 : check e1211206301914 [[],[]] .smaller = true := by decide
def e1211206301930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e1211206301930 : Closed e1211206301930 ∧ code e1211206301930 = 5609252813034 := by decide
theorem cert_e1211206301930 : check e1211206301930 [[],[]] .smaller = true := by decide
def e1211206302262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211206302262 : Closed e1211206302262 ∧ code e1211206302262 = 5609252813366 := by decide
theorem cert_e1211206302262 : check e1211206302262 [[],[]] .smaller = true := by decide
def e1211206302266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211206302266 : Closed e1211206302266 ∧ code e1211206302266 = 5609252813370 := by decide
theorem cert_e1211206302266 : check e1211206302266 [[],[]] .smaller = true := by decide
def e1211206302350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211206302350 : Closed e1211206302350 ∧ code e1211206302350 = 5609252813454 := by decide
theorem cert_e1211206302350 : check e1211206302350 [[],[]] .smaller = true := by decide
def e1211206302406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211206302406 : Closed e1211206302406 ∧ code e1211206302406 = 5609252813510 := by decide
theorem cert_e1211206302406 : check e1211206302406 [[],[]] .smaller = true := by decide
def e1211206302430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211206302430 : Closed e1211206302430 ∧ code e1211206302430 = 5609252813534 := by decide
theorem cert_e1211206302430 : check e1211206302430 [[],[]] .chain = true := by decide
def e1211206302454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211206302454 : Closed e1211206302454 ∧ code e1211206302454 = 5609252813558 := by decide
theorem cert_e1211206302454 : check e1211206302454 [[],[]] .chain = true := by decide
def e1211206302490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211206302490 : Closed e1211206302490 ∧ code e1211206302490 = 5609252813594 := by decide
theorem cert_e1211206302490 : check e1211206302490 [[],[]] .smaller = true := by decide
def e1211206302534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211206302534 : Closed e1211206302534 ∧ code e1211206302534 = 5609252813638 := by decide
theorem cert_e1211206302534 : check e1211206302534 [[],[]] .smaller = true := by decide
def e1211206302558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211206302558 : Closed e1211206302558 ∧ code e1211206302558 = 5609252813662 := by decide
theorem cert_e1211206302558 : check e1211206302558 [[],[]] .chain = true := by decide
def e1211206302586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211206302586 : Closed e1211206302586 ∧ code e1211206302586 = 5609252813690 := by decide
theorem cert_e1211206302586 : check e1211206302586 [[],[]] .chain = true := by decide
def e1211206302678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211206302678 : Closed e1211206302678 ∧ code e1211206302678 = 5609252813782 := by decide
theorem cert_e1211206302678 : check e1211206302678 [[],[]] .chain = true := by decide
def e1211206302682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211206302682 : Closed e1211206302682 ∧ code e1211206302682 = 5609252813786 := by decide
theorem cert_e1211206302682 : check e1211206302682 [[],[]] .chain = true := by decide
def e1211206302806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211206302806 : Closed e1211206302806 ∧ code e1211206302806 = 5609252813910 := by decide
theorem cert_e1211206302806 : check e1211206302806 [[],[]] .chain = true := by decide
def e1211206302810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211206302810 : Closed e1211206302810 ∧ code e1211206302810 = 5609252813914 := by decide
theorem cert_e1211206302810 : check e1211206302810 [[],[]] .chain = true := by decide
def e1211206302998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211206302998 : Closed e1211206302998 ∧ code e1211206302998 = 5609252814102 := by decide
theorem cert_e1211206302998 : check e1211206302998 [[],[]] .chain = true := by decide
def e1211206303074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211206303074 : Closed e1211206303074 ∧ code e1211206303074 = 5609252814178 := by decide
theorem cert_e1211206303074 : check e1211206303074 [[],[]] .chain = true := by decide
def e1211206303086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211206303086 : Closed e1211206303086 ∧ code e1211206303086 = 5609252814190 := by decide
theorem cert_e1211206303086 : check e1211206303086 [[],[]] .chain = true := by decide
def e1211206303094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211206303094 : Closed e1211206303094 ∧ code e1211206303094 = 5609252814198 := by decide
theorem cert_e1211206303094 : check e1211206303094 [[],[]] .chain = true := by decide
def e1211206303114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211206303114 : Closed e1211206303114 ∧ code e1211206303114 = 5609252814218 := by decide
theorem cert_e1211206303114 : check e1211206303114 [[],[]] .chain = true := by decide
def e1211206303138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211206303138 : Closed e1211206303138 ∧ code e1211206303138 = 5609252814242 := by decide
theorem cert_e1211206303138 : check e1211206303138 [[],[]] .chain = true := by decide
def e1211206303150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211206303150 : Closed e1211206303150 ∧ code e1211206303150 = 5609252814254 := by decide
theorem cert_e1211206303150 : check e1211206303150 [[],[]] .chain = true := by decide
def e1211206303162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211206303162 : Closed e1211206303162 ∧ code e1211206303162 = 5609252814266 := by decide
theorem cert_e1211206303162 : check e1211206303162 [[],[]] .chain = true := by decide
def e1211206303190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211206303190 : Closed e1211206303190 ∧ code e1211206303190 = 5609252814294 := by decide
theorem cert_e1211206303190 : check e1211206303190 [[],[]] .chain = true := by decide
def e1211206303194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211206303194 : Closed e1211206303194 ∧ code e1211206303194 = 5609252814298 := by decide
theorem cert_e1211206303194 : check e1211206303194 [[],[]] .chain = true := by decide
def e1211206304734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 3))))))))
theorem wire_e1211206304734 : Closed e1211206304734 ∧ code e1211206304734 = 5609252815838 := by decide
theorem cert_e1211206304734 : check e1211206304734 [[],[]] .chain = true := by decide
def e1211206304758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 1))))))))
theorem wire_e1211206304758 : Closed e1211206304758 ∧ code e1211206304758 = 5609252815862 := by decide
theorem cert_e1211206304758 : check e1211206304758 [[],[]] .chain = true := by decide
def e1211206305518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e1211206305518 : Closed e1211206305518 ∧ code e1211206305518 = 5609252816622 := by decide
theorem cert_e1211206305518 : check e1211206305518 [[],[]] .smaller = true := by decide
def e1211206305526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e1211206305526 : Closed e1211206305526 ∧ code e1211206305526 = 5609252816630 := by decide
theorem cert_e1211206305526 : check e1211206305526 [[],[]] .smaller = true := by decide
def e1211206305710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e1211206305710 : Closed e1211206305710 ∧ code e1211206305710 = 5609252816814 := by decide
theorem cert_e1211206305710 : check e1211206305710 [[],[]] .smaller = true := by decide
def e1211206305750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e1211206305750 : Closed e1211206305750 ∧ code e1211206305750 = 5609252816854 := by decide
theorem cert_e1211206305750 : check e1211206305750 [[],[]] .smaller = true := by decide
def e1211206306270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211206306270 : Closed e1211206306270 ∧ code e1211206306270 = 5609252817374 := by decide
theorem cert_e1211206306270 : check e1211206306270 [[],[]] .chain = true := by decide
def e1211206306294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211206306294 : Closed e1211206306294 ∧ code e1211206306294 = 5609252817398 := by decide
theorem cert_e1211206306294 : check e1211206306294 [[],[]] .chain = true := by decide
def e1211206307054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211206307054 : Closed e1211206307054 ∧ code e1211206307054 = 5609252818158 := by decide
theorem cert_e1211206307054 : check e1211206307054 [[],[]] .smaller = true := by decide
def e1211206307062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211206307062 : Closed e1211206307062 ∧ code e1211206307062 = 5609252818166 := by decide
theorem cert_e1211206307062 : check e1211206307062 [[],[]] .smaller = true := by decide
def e1211206307390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 4)))))))))
theorem wire_e1211206307390 : Closed e1211206307390 ∧ code e1211206307390 = 5609252818494 := by decide
theorem cert_e1211206307390 : check e1211206307390 [[],[]] .chain = true := by decide
def e1211206307438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211206307438 : Closed e1211206307438 ∧ code e1211206307438 = 5609252818542 := by decide
theorem cert_e1211206307438 : check e1211206307438 [[],[]] .smaller = true := by decide
def e1211206307450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211206307450 : Closed e1211206307450 ∧ code e1211206307450 = 5609252818554 := by decide
theorem cert_e1211206307450 : check e1211206307450 [[],[]] .smaller = true := by decide
def e1211206307638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211206307638 : Closed e1211206307638 ∧ code e1211206307638 = 5609252818742 := by decide
theorem cert_e1211206307638 : check e1211206307638 [[],[]] .smaller = true := by decide
def e1211206307642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211206307642 : Closed e1211206307642 ∧ code e1211206307642 = 5609252818746 := by decide
theorem cert_e1211206307642 : check e1211206307642 [[],[]] .smaller = true := by decide
def e1211206307726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 2)))))))))
theorem wire_e1211206307726 : Closed e1211206307726 ∧ code e1211206307726 = 5609252818830 := by decide
theorem cert_e1211206307726 : check e1211206307726 [[],[]] .chain = true := by decide
def e1211206310126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211206310126 : Closed e1211206310126 ∧ code e1211206310126 = 5609252821230 := by decide
theorem cert_e1211206310126 : check e1211206310126 [[],[]] .smaller = true := by decide
def e1211206310134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211206310134 : Closed e1211206310134 ∧ code e1211206310134 = 5609252821238 := by decide
theorem cert_e1211206310134 : check e1211206310134 [[],[]] .smaller = true := by decide
def e1211206310686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211206310686 : Closed e1211206310686 ∧ code e1211206310686 = 5609252821790 := by decide
theorem cert_e1211206310686 : check e1211206310686 [[],[]] .smaller = true := by decide
def e1211206310798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211206310798 : Closed e1211206310798 ∧ code e1211206310798 = 5609252821902 := by decide
theorem cert_e1211206310798 : check e1211206310798 [[],[]] .smaller = true := by decide
def e1211206311006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e1211206311006 : Closed e1211206311006 ∧ code e1211206311006 = 5609252822110 := by decide
theorem cert_e1211206311006 : check e1211206311006 [[],[]] .chain = true := by decide
def e1211206311022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211206311022 : Closed e1211206311022 ∧ code e1211206311022 = 5609252822126 := by decide
theorem cert_e1211206311022 : check e1211206311022 [[],[]] .smaller = true := by decide
def e1211206311034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211206311034 : Closed e1211206311034 ∧ code e1211206311034 = 5609252822138 := by decide
theorem cert_e1211206311034 : check e1211206311034 [[],[]] .smaller = true := by decide
def e1211206311198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211206311198 : Closed e1211206311198 ∧ code e1211206311198 = 5609252822302 := by decide
theorem cert_e1211206311198 : check e1211206311198 [[],[]] .smaller = true := by decide
def e1211206311366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211206311366 : Closed e1211206311366 ∧ code e1211206311366 = 5609252822470 := by decide
theorem cert_e1211206311366 : check e1211206311366 [[],[]] .smaller = true := by decide
def e1211206311390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e1211206311390 : Closed e1211206311390 ∧ code e1211206311390 = 5609252822494 := by decide
theorem cert_e1211206311390 : check e1211206311390 [[],[]] .chain = true := by decide
def e1211206311394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211206311394 : Closed e1211206311394 ∧ code e1211206311394 = 5609252822498 := by decide
theorem cert_e1211206311394 : check e1211206311394 [[],[]] .chain = true := by decide
def e1211206311406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e1211206311406 : Closed e1211206311406 ∧ code e1211206311406 = 5609252822510 := by decide
theorem cert_e1211206311406 : check e1211206311406 [[],[]] .chain = true := by decide
def e1211206311478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211206311478 : Closed e1211206311478 ∧ code e1211206311478 = 5609252822582 := by decide
theorem cert_e1211206311478 : check e1211206311478 [[],[]] .smaller = true := by decide
def e1211206311482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211206311482 : Closed e1211206311482 ∧ code e1211206311482 = 5609252822586 := by decide
theorem cert_e1211206311482 : check e1211206311482 [[],[]] .smaller = true := by decide
end Blc.Floor42
