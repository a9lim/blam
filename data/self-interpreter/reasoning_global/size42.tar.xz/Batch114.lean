import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205816048954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205816048954 : Closed e1205816048954 ∧ code e1205816048954 = 5603862560058 := by decide
theorem cert_e1205816048954 : check e1205816048954 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816049050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205816049050 : Closed e1205816049050 ∧ code e1205816049050 = 5603862560154 := by decide
theorem cert_e1205816049050 : check e1205816049050 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816050654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1205816050654 : Closed e1205816050654 ∧ code e1205816050654 = 5603862561758 := by decide
theorem cert_e1205816050654 : check e1205816050654 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816050670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1205816050670 : Closed e1205816050670 ∧ code e1205816050670 = 5603862561774 := by decide
theorem cert_e1205816050670 : check e1205816050670 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1205816052502 : Closed e1205816052502 ∧ code e1205816052502 = 5603862563606 := by decide
theorem cert_e1205816052502 : check e1205816052502 [[],[]] .chain = true := by decide
def e1205816052578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1205816052578 : Closed e1205816052578 ∧ code e1205816052578 = 5603862563682 := by decide
theorem cert_e1205816052578 : check e1205816052578 [[],[]] .chain = true := by decide
def e1205816052590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205816052590 : Closed e1205816052590 ∧ code e1205816052590 = 5603862563694 := by decide
theorem cert_e1205816052590 : check e1205816052590 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205816052598 : Closed e1205816052598 ∧ code e1205816052598 = 5603862563702 := by decide
theorem cert_e1205816052598 : check e1205816052598 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205816052618 : Closed e1205816052618 ∧ code e1205816052618 = 5603862563722 := by decide
theorem cert_e1205816052618 : check e1205816052618 [[],[]] .chain = true := by decide
def e1205816052642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205816052642 : Closed e1205816052642 ∧ code e1205816052642 = 5603862563746 := by decide
theorem cert_e1205816052642 : check e1205816052642 [[],[]] .chain = true := by decide
def e1205816052654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205816052654 : Closed e1205816052654 ∧ code e1205816052654 = 5603862563758 := by decide
theorem cert_e1205816052654 : check e1205816052654 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e1205816052662 : Closed e1205816052662 ∧ code e1205816052662 = 5603862563766 := by decide
theorem cert_e1205816052662 : check e1205816052662 [[],[]] .chain = true := by decide
def e1205816052666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205816052666 : Closed e1205816052666 ∧ code e1205816052666 = 5603862563770 := by decide
theorem cert_e1205816052666 : check e1205816052666 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205816052694 : Closed e1205816052694 ∧ code e1205816052694 = 5603862563798 := by decide
theorem cert_e1205816052694 : check e1205816052694 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205816052698 : Closed e1205816052698 ∧ code e1205816052698 = 5603862563802 := by decide
theorem cert_e1205816052698 : check e1205816052698 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1205816052766 : Closed e1205816052766 ∧ code e1205816052766 = 5603862563870 := by decide
theorem cert_e1205816052766 : check e1205816052766 [[],[]] .chain = true := by decide
def e1205816052962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1205816052962 : Closed e1205816052962 ∧ code e1205816052962 = 5603862564066 := by decide
theorem cert_e1205816052962 : check e1205816052962 [[],[]] .chain = true := by decide
def e1205816052974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205816052974 : Closed e1205816052974 ∧ code e1205816052974 = 5603862564078 := by decide
theorem cert_e1205816052974 : check e1205816052974 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816052982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205816052982 : Closed e1205816052982 ∧ code e1205816052982 = 5603862564086 := by decide
theorem cert_e1205816052982 : check e1205816052982 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816053262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1205816053262 : Closed e1205816053262 ∧ code e1205816053262 = 5603862564366 := by decide
theorem cert_e1205816053262 : check e1205816053262 [[],[]] .chain = true := by decide
def e1205816053274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1205816053274 : Closed e1205816053274 ∧ code e1205816053274 = 5603862564378 := by decide
theorem cert_e1205816053274 : check e1205816053274 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816053346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205816053346 : Closed e1205816053346 ∧ code e1205816053346 = 5603862564450 := by decide
theorem cert_e1205816053346 : check e1205816053346 [[],[]] .chain = true := by decide
def e1205816053358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205816053358 : Closed e1205816053358 ∧ code e1205816053358 = 5603862564462 := by decide
theorem cert_e1205816053358 : check e1205816053358 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816053366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205816053366 : Closed e1205816053366 ∧ code e1205816053366 = 5603862564470 := by decide
theorem cert_e1205816053366 : check e1205816053366 [[],[]] .chain = true := by decide
def e1205816053370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205816053370 : Closed e1205816053370 ∧ code e1205816053370 = 5603862564474 := by decide
theorem cert_e1205816053370 : check e1205816053370 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816053558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205816053558 : Closed e1205816053558 ∧ code e1205816053558 = 5603862564662 := by decide
theorem cert_e1205816053558 : check e1205816053558 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816053562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205816053562 : Closed e1205816053562 ∧ code e1205816053562 = 5603862564666 := by decide
theorem cert_e1205816053562 : check e1205816053562 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816058334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1205816058334 : Closed e1205816058334 ∧ code e1205816058334 = 5603862569438 := by decide
theorem cert_e1205816058334 : check e1205816058334 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816058358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1205816058358 : Closed e1205816058358 ∧ code e1205816058358 = 5603862569462 := by decide
theorem cert_e1205816058358 : check e1205816058358 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205816059274 : Closed e1205816059274 ∧ code e1205816059274 = 5603862570378 := by decide
theorem cert_e1205816059274 : check e1205816059274 [[],[]] .chain = true := by decide
def e1205816059298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205816059298 : Closed e1205816059298 ∧ code e1205816059298 = 5603862570402 := by decide
theorem cert_e1205816059298 : check e1205816059298 [[],[]] .chain = true := by decide
def e1205816059310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1205816059310 : Closed e1205816059310 ∧ code e1205816059310 = 5603862570414 := by decide
theorem cert_e1205816059310 : check e1205816059310 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1205816059318 : Closed e1205816059318 ∧ code e1205816059318 = 5603862570422 := by decide
theorem cert_e1205816059318 : check e1205816059318 [[],[]] .chain = true := by decide
def e1205816059322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1205816059322 : Closed e1205816059322 ∧ code e1205816059322 = 5603862570426 := by decide
theorem cert_e1205816059322 : check e1205816059322 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1205816059350 : Closed e1205816059350 ∧ code e1205816059350 = 5603862570454 := by decide
theorem cert_e1205816059350 : check e1205816059350 [[],[]] .chain = true := by decide
def e1205816059354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1205816059354 : Closed e1205816059354 ∧ code e1205816059354 = 5603862570458 := by decide
theorem cert_e1205816059354 : check e1205816059354 [[],[]] .chain = true := by decide
def e1205816059370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1205816059370 : Closed e1205816059370 ∧ code e1205816059370 = 5603862570474 := by decide
theorem cert_e1205816059370 : check e1205816059370 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e1205816059406 : Closed e1205816059406 ∧ code e1205816059406 = 5603862570510 := by decide
theorem cert_e1205816059406 : check e1205816059406 [[],[]] .chain = true := by decide
def e1205816059418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1205816059418 : Closed e1205816059418 ∧ code e1205816059418 = 5603862570522 := by decide
theorem cert_e1205816059418 : check e1205816059418 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205816059490 : Closed e1205816059490 ∧ code e1205816059490 = 5603862570594 := by decide
theorem cert_e1205816059490 : check e1205816059490 [[],[]] .chain = true := by decide
def e1205816059502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205816059502 : Closed e1205816059502 ∧ code e1205816059502 = 5603862570606 := by decide
theorem cert_e1205816059502 : check e1205816059502 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205816059510 : Closed e1205816059510 ∧ code e1205816059510 = 5603862570614 := by decide
theorem cert_e1205816059510 : check e1205816059510 [[],[]] .chain = true := by decide
def e1205816059514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205816059514 : Closed e1205816059514 ∧ code e1205816059514 = 5603862570618 := by decide
theorem cert_e1205816059514 : check e1205816059514 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816059702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205816059702 : Closed e1205816059702 ∧ code e1205816059702 = 5603862570806 := by decide
theorem cert_e1205816059702 : check e1205816059702 [[],[]] .chain = true := by decide
def e1205816059706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205816059706 : Closed e1205816059706 ∧ code e1205816059706 = 5603862570810 := by decide
theorem cert_e1205816059706 : check e1205816059706 [[],[]] .chain = true := by decide
def e1205816059802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205816059802 : Closed e1205816059802 ∧ code e1205816059802 = 5603862570906 := by decide
theorem cert_e1205816059802 : check e1205816059802 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1205816062190 : Closed e1205816062190 ∧ code e1205816062190 = 5603862573294 := by decide
theorem cert_e1205816062190 : check e1205816062190 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1205816062198 : Closed e1205816062198 ∧ code e1205816062198 = 5603862573302 := by decide
theorem cert_e1205816062198 : check e1205816062198 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1205816062678 : Closed e1205816062678 ∧ code e1205816062678 = 5603862573782 := by decide
theorem cert_e1205816062678 : check e1205816062678 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1205816062682 : Closed e1205816062682 ∧ code e1205816062682 = 5603862573786 := by decide
theorem cert_e1205816062682 : check e1205816062682 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1205816062698 : Closed e1205816062698 ∧ code e1205816062698 = 5603862573802 := by decide
theorem cert_e1205816062698 : check e1205816062698 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205816062774 : Closed e1205816062774 ∧ code e1205816062774 = 5603862573878 := by decide
theorem cert_e1205816062774 : check e1205816062774 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205816062778 : Closed e1205816062778 ∧ code e1205816062778 = 5603862573882 := by decide
theorem cert_e1205816062778 : check e1205816062778 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816062874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205816062874 : Closed e1205816062874 ∧ code e1205816062874 = 5603862573978 := by decide
theorem cert_e1205816062874 : check e1205816062874 [[],[],[.under,.under]] .smaller = true := by decide
def e1205821311854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205821311854 : Closed e1205821311854 ∧ code e1205821311854 = 5603867822958 := by decide
theorem cert_e1205821311854 : check e1205821311854 [[],[],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e1205821311862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205821311862 : Closed e1205821311862 ∧ code e1205821311862 = 5603867822966 := by decide
theorem cert_e1205821311862 : check e1205821311862 [[],[],[.under],[.under],[.under,.left],[.under,.left,.left]] .smaller = true := by decide
def e1205821311918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205821311918 : Closed e1205821311918 ∧ code e1205821311918 = 5603867823022 := by decide
theorem cert_e1205821311918 : check e1205821311918 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1205821311930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205821311930 : Closed e1205821311930 ∧ code e1205821311930 = 5603867823034 := by decide
theorem cert_e1205821311930 : check e1205821311930 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1205821311958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205821311958 : Closed e1205821311958 ∧ code e1205821311958 = 5603867823062 := by decide
theorem cert_e1205821311958 : check e1205821311958 [[],[],[.under],[.under],[.under,.left]] .smaller = true := by decide
def e1205821311962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205821311962 : Closed e1205821311962 ∧ code e1205821311962 = 5603867823066 := by decide
theorem cert_e1205821311962 : check e1205821311962 [[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e1205821312238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205821312238 : Closed e1205821312238 ∧ code e1205821312238 = 5603867823342 := by decide
theorem cert_e1205821312238 : check e1205821312238 [[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e1205821312246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205821312246 : Closed e1205821312246 ∧ code e1205821312246 = 5603867823350 := by decide
theorem cert_e1205821312246 : check e1205821312246 [[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[.left,.left],[.left],[],[],[],[],[.left,.left],[.left],[],[],[],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e1205821312622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205821312622 : Closed e1205821312622 ∧ code e1205821312622 = 5603867823726 := by decide
theorem cert_e1205821312622 : check e1205821312622 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1205821312634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205821312634 : Closed e1205821312634 ∧ code e1205821312634 = 5603867823738 := by decide
theorem cert_e1205821312634 : check e1205821312634 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e1205821312822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205821312822 : Closed e1205821312822 ∧ code e1205821312822 = 5603867823926 := by decide
theorem cert_e1205821312822 : check e1205821312822 [[],[],[.under],[.under],[.under]] .smaller = true := by decide
def e1205821312826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205821312826 : Closed e1205821312826 ∧ code e1205821312826 = 5603867823930 := by decide
theorem cert_e1205821312826 : check e1205821312826 [[],[],[.under],[.under],[.under]] .smaller = true := by decide
def e1205823614394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1205823614394 : Closed e1205823614394 ∧ code e1205823614394 = 5603870125498 := by decide
theorem cert_e1205823614394 : check e1205823614394 [[],[]] .smaller = true := by decide
def e1205823614426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1205823614426 : Closed e1205823614426 ∧ code e1205823614426 = 5603870125530 := by decide
theorem cert_e1205823614426 : check e1205823614426 [[],[]] .smaller = true := by decide
def e1205823614650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1205823614650 : Closed e1205823614650 ∧ code e1205823614650 = 5603870125754 := by decide
theorem cert_e1205823614650 : check e1205823614650 [[],[]] .smaller = true := by decide
def e1205823614698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1205823614698 : Closed e1205823614698 ∧ code e1205823614698 = 5603870125802 := by decide
theorem cert_e1205823614698 : check e1205823614698 [[],[]] .smaller = true := by decide
def e1205823614810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1205823614810 : Closed e1205823614810 ∧ code e1205823614810 = 5603870125914 := by decide
theorem cert_e1205823614810 : check e1205823614810 [[],[]] .smaller = true := by decide
def e1205823614826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1205823614826 : Closed e1205823614826 ∧ code e1205823614826 = 5603870125930 := by decide
theorem cert_e1205823614826 : check e1205823614826 [[],[]] .smaller = true := by decide
def e1205823615930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1205823615930 : Closed e1205823615930 ∧ code e1205823615930 = 5603870127034 := by decide
theorem cert_e1205823615930 : check e1205823615930 [[],[]] .smaller = true := by decide
def e1205823615962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1205823615962 : Closed e1205823615962 ∧ code e1205823615962 = 5603870127066 := by decide
theorem cert_e1205823615962 : check e1205823615962 [[],[]] .smaller = true := by decide
def e1205823617466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1205823617466 : Closed e1205823617466 ∧ code e1205823617466 = 5603870128570 := by decide
theorem cert_e1205823617466 : check e1205823617466 [[],[]] .smaller = true := by decide
def e1205823617514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1205823617514 : Closed e1205823617514 ∧ code e1205823617514 = 5603870128618 := by decide
theorem cert_e1205823617514 : check e1205823617514 [[],[]] .smaller = true := by decide
def e1205823618266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1205823618266 : Closed e1205823618266 ∧ code e1205823618266 = 5603870129370 := by decide
theorem cert_e1205823618266 : check e1205823618266 [[],[]] .smaller = true := by decide
def e1205823618282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1205823618282 : Closed e1205823618282 ∧ code e1205823618282 = 5603870129386 := by decide
theorem cert_e1205823618282 : check e1205823618282 [[],[]] .smaller = true := by decide
def e1205823649506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e1205823649506 : Closed e1205823649506 ∧ code e1205823649506 = 5603870160610 := by decide
theorem cert_e1205823649506 : check e1205823649506 [[],[]] .chain = true := by decide
def e1205823649634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e1205823649634 : Closed e1205823649634 ∧ code e1205823649634 = 5603870160738 := by decide
theorem cert_e1205823649634 : check e1205823649634 [[],[]] .chain = true := by decide
def e1205823650530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e1205823650530 : Closed e1205823650530 ∧ code e1205823650530 = 5603870161634 := by decide
theorem cert_e1205823650530 : check e1205823650530 [[],[]] .chain = true := by decide
def e1205823650722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e1205823650722 : Closed e1205823650722 ∧ code e1205823650722 = 5603870161826 := by decide
theorem cert_e1205823650722 : check e1205823650722 [[],[]] .chain = true := by decide
def e1205823651170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e1205823651170 : Closed e1205823651170 ∧ code e1205823651170 = 5603870162274 := by decide
theorem cert_e1205823651170 : check e1205823651170 [[],[]] .chain = true := by decide
def e1205823651234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e1205823651234 : Closed e1205823651234 ∧ code e1205823651234 = 5603870162338 := by decide
theorem cert_e1205823651234 : check e1205823651234 [[],[]] .chain = true := by decide
def e1205823655650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))
theorem wire_e1205823655650 : Closed e1205823655650 ∧ code e1205823655650 = 5603870166754 := by decide
theorem cert_e1205823655650 : check e1205823655650 [[],[]] .chain = true := by decide
def e1205823655778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))
theorem wire_e1205823655778 : Closed e1205823655778 ∧ code e1205823655778 = 5603870166882 := by decide
theorem cert_e1205823655778 : check e1205823655778 [[],[]] .chain = true := by decide
def e1205823661794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))
theorem wire_e1205823661794 : Closed e1205823661794 ∧ code e1205823661794 = 5603870172898 := by decide
theorem cert_e1205823661794 : check e1205823661794 [[],[]] .chain = true := by decide
def e1205823661986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))
theorem wire_e1205823661986 : Closed e1205823661986 ∧ code e1205823661986 = 5603870173090 := by decide
theorem cert_e1205823661986 : check e1205823661986 [[],[]] .chain = true := by decide
def e1205823664994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))
theorem wire_e1205823664994 : Closed e1205823664994 ∧ code e1205823664994 = 5603870176098 := by decide
theorem cert_e1205823664994 : check e1205823664994 [[],[]] .chain = true := by decide
def e1205823665058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))
theorem wire_e1205823665058 : Closed e1205823665058 ∧ code e1205823665058 = 5603870176162 := by decide
theorem cert_e1205823665058 : check e1205823665058 [[],[]] .chain = true := by decide
def e1205823671150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205823671150 : Closed e1205823671150 ∧ code e1205823671150 = 5603870182254 := by decide
theorem cert_e1205823671150 : check e1205823671150 [[],[]] .chain = true := by decide
def e1205823671158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205823671158 : Closed e1205823671158 ∧ code e1205823671158 = 5603870182262 := by decide
theorem cert_e1205823671158 : check e1205823671158 [[],[]] .chain = true := by decide
def e1205823671214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205823671214 : Closed e1205823671214 ∧ code e1205823671214 = 5603870182318 := by decide
theorem cert_e1205823671214 : check e1205823671214 [[],[]] .chain = true := by decide
def e1205823671226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205823671226 : Closed e1205823671226 ∧ code e1205823671226 = 5603870182330 := by decide
theorem cert_e1205823671226 : check e1205823671226 [[],[]] .chain = true := by decide
def e1205823671254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205823671254 : Closed e1205823671254 ∧ code e1205823671254 = 5603870182358 := by decide
theorem cert_e1205823671254 : check e1205823671254 [[],[]] .chain = true := by decide
def e1205823671258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205823671258 : Closed e1205823671258 ∧ code e1205823671258 = 5603870182362 := by decide
theorem cert_e1205823671258 : check e1205823671258 [[],[]] .chain = true := by decide
def e1205823671534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205823671534 : Closed e1205823671534 ∧ code e1205823671534 = 5603870182638 := by decide
theorem cert_e1205823671534 : check e1205823671534 [[],[]] .chain = true := by decide
def e1205823671542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205823671542 : Closed e1205823671542 ∧ code e1205823671542 = 5603870182646 := by decide
theorem cert_e1205823671542 : check e1205823671542 [[],[]] .chain = true := by decide
def e1205823671918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205823671918 : Closed e1205823671918 ∧ code e1205823671918 = 5603870183022 := by decide
theorem cert_e1205823671918 : check e1205823671918 [[],[]] .chain = true := by decide
def e1205823671930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205823671930 : Closed e1205823671930 ∧ code e1205823671930 = 5603870183034 := by decide
theorem cert_e1205823671930 : check e1205823671930 [[],[]] .chain = true := by decide
def e1205823672118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205823672118 : Closed e1205823672118 ∧ code e1205823672118 = 5603870183222 := by decide
theorem cert_e1205823672118 : check e1205823672118 [[],[]] .chain = true := by decide
def e1205823672122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205823672122 : Closed e1205823672122 ∧ code e1205823672122 = 5603870183226 := by decide
theorem cert_e1205823672122 : check e1205823672122 [[],[]] .chain = true := by decide
def e1205823867758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205823867758 : Closed e1205823867758 ∧ code e1205823867758 = 5603870378862 := by decide
theorem cert_e1205823867758 : check e1205823867758 [[],[]] .smaller = true := by decide
def e1205823867766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205823867766 : Closed e1205823867766 ∧ code e1205823867766 = 5603870378870 := by decide
theorem cert_e1205823867766 : check e1205823867766 [[],[]] .smaller = true := by decide
def e1205823867822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205823867822 : Closed e1205823867822 ∧ code e1205823867822 = 5603870378926 := by decide
theorem cert_e1205823867822 : check e1205823867822 [[],[]] .smaller = true := by decide
def e1205823867834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205823867834 : Closed e1205823867834 ∧ code e1205823867834 = 5603870378938 := by decide
theorem cert_e1205823867834 : check e1205823867834 [[],[]] .smaller = true := by decide
def e1205823867862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205823867862 : Closed e1205823867862 ∧ code e1205823867862 = 5603870378966 := by decide
theorem cert_e1205823867862 : check e1205823867862 [[],[]] .smaller = true := by decide
def e1205823867866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205823867866 : Closed e1205823867866 ∧ code e1205823867866 = 5603870378970 := by decide
theorem cert_e1205823867866 : check e1205823867866 [[],[]] .smaller = true := by decide
def e1205823868142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205823868142 : Closed e1205823868142 ∧ code e1205823868142 = 5603870379246 := by decide
theorem cert_e1205823868142 : check e1205823868142 [[],[]] .smaller = true := by decide
def e1205823868150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205823868150 : Closed e1205823868150 ∧ code e1205823868150 = 5603870379254 := by decide
theorem cert_e1205823868150 : check e1205823868150 [[],[]] .smaller = true := by decide
def e1205823868526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205823868526 : Closed e1205823868526 ∧ code e1205823868526 = 5603870379630 := by decide
theorem cert_e1205823868526 : check e1205823868526 [[],[]] .smaller = true := by decide
def e1205823868538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205823868538 : Closed e1205823868538 ∧ code e1205823868538 = 5603870379642 := by decide
theorem cert_e1205823868538 : check e1205823868538 [[],[]] .smaller = true := by decide
def e1205823868726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205823868726 : Closed e1205823868726 ∧ code e1205823868726 = 5603870379830 := by decide
theorem cert_e1205823868726 : check e1205823868726 [[],[]] .smaller = true := by decide
def e1205823868730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205823868730 : Closed e1205823868730 ∧ code e1205823868730 = 5603870379834 := by decide
theorem cert_e1205823868730 : check e1205823868730 [[],[]] .smaller = true := by decide
def e1205824150390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e1205824150390 : Closed e1205824150390 ∧ code e1205824150390 = 5603870661494 := by decide
theorem cert_e1205824150390 : check e1205824150390 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824150454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e1205824150454 : Closed e1205824150454 ∧ code e1205824150454 = 5603870661558 := by decide
theorem cert_e1205824150454 : check e1205824150454 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824150902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e1205824150902 : Closed e1205824150902 ∧ code e1205824150902 = 5603870662006 := by decide
theorem cert_e1205824150902 : check e1205824150902 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824150998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e1205824150998 : Closed e1205824150998 ∧ code e1205824150998 = 5603870662102 := by decide
theorem cert_e1205824150998 : check e1205824150998 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824151222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1205824151222 : Closed e1205824151222 ∧ code e1205824151222 = 5603870662326 := by decide
theorem cert_e1205824151222 : check e1205824151222 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824151254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1205824151254 : Closed e1205824151254 ∧ code e1205824151254 = 5603870662358 := by decide
theorem cert_e1205824151254 : check e1205824151254 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824153462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e1205824153462 : Closed e1205824153462 ∧ code e1205824153462 = 5603870664566 := by decide
theorem cert_e1205824153462 : check e1205824153462 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824153526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e1205824153526 : Closed e1205824153526 ∧ code e1205824153526 = 5603870664630 := by decide
theorem cert_e1205824153526 : check e1205824153526 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824156534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1205824156534 : Closed e1205824156534 ∧ code e1205824156534 = 5603870667638 := by decide
theorem cert_e1205824156534 : check e1205824156534 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824156630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1205824156630 : Closed e1205824156630 ∧ code e1205824156630 = 5603870667734 := by decide
theorem cert_e1205824156630 : check e1205824156630 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824158134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1205824158134 : Closed e1205824158134 ∧ code e1205824158134 = 5603870669238 := by decide
theorem cert_e1205824158134 : check e1205824158134 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824158166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1205824158166 : Closed e1205824158166 ∧ code e1205824158166 = 5603870669270 := by decide
theorem cert_e1205824158166 : check e1205824158166 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824326510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205824326510 : Closed e1205824326510 ∧ code e1205824326510 = 5603870837614 := by decide
theorem cert_e1205824326510 : check e1205824326510 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1205824326518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205824326518 : Closed e1205824326518 ∧ code e1205824326518 = 5603870837622 := by decide
theorem cert_e1205824326518 : check e1205824326518 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1205824326574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205824326574 : Closed e1205824326574 ∧ code e1205824326574 = 5603870837678 := by decide
theorem cert_e1205824326574 : check e1205824326574 [[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1205824326586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205824326586 : Closed e1205824326586 ∧ code e1205824326586 = 5603870837690 := by decide
theorem cert_e1205824326586 : check e1205824326586 [[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e1205824326614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205824326614 : Closed e1205824326614 ∧ code e1205824326614 = 5603870837718 := by decide
theorem cert_e1205824326614 : check e1205824326614 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1205824326618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205824326618 : Closed e1205824326618 ∧ code e1205824326618 = 5603870837722 := by decide
def e1205824326894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205824326894 : Closed e1205824326894 ∧ code e1205824326894 = 5603870837998 := by decide
theorem cert_e1205824326894 : check e1205824326894 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1205824326902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205824326902 : Closed e1205824326902 ∧ code e1205824326902 = 5603870838006 := by decide
def e1205824327278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205824327278 : Closed e1205824327278 ∧ code e1205824327278 = 5603870838382 := by decide
theorem cert_e1205824327278 : checkPay e1205824327278 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [[],[.right]] = true := by decide
def e1205824327290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205824327290 : Closed e1205824327290 ∧ code e1205824327290 = 5603870838394 := by decide
theorem cert_e1205824327290 : checkPay e1205824327290 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [[]] = true := by decide
def e1205824327478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205824327478 : Closed e1205824327478 ∧ code e1205824327478 = 5603870838582 := by decide
theorem cert_e1205824327478 : check e1205824327478 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824327482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205824327482 : Closed e1205824327482 ∧ code e1205824327482 = 5603870838586 := by decide
theorem cert_e1205824327482 : check e1205824327482 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205824663006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1205824663006 : Closed e1205824663006 ∧ code e1205824663006 = 5603871174110 := by decide
theorem cert_e1205824663006 : check e1205824663006 [[],[]] .smaller = true := by decide
def e1205824663022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1205824663022 : Closed e1205824663022 ∧ code e1205824663022 = 5603871174126 := by decide
theorem cert_e1205824663022 : check e1205824663022 [[],[]] .smaller = true := by decide
def e1205824663390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1205824663390 : Closed e1205824663390 ∧ code e1205824663390 = 5603871174494 := by decide
theorem cert_e1205824663390 : check e1205824663390 [[],[]] .smaller = true := by decide
def e1205824663418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1205824663418 : Closed e1205824663418 ∧ code e1205824663418 = 5603871174522 := by decide
theorem cert_e1205824663418 : check e1205824663418 [[],[]] .smaller = true := by decide
def e1205824663470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1205824663470 : Closed e1205824663470 ∧ code e1205824663470 = 5603871174574 := by decide
theorem cert_e1205824663470 : check e1205824663470 [[],[]] .smaller = true := by decide
def e1205824663482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1205824663482 : Closed e1205824663482 ∧ code e1205824663482 = 5603871174586 := by decide
theorem cert_e1205824663482 : check e1205824663482 [[],[]] .smaller = true := by decide
def e1205824664542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1205824664542 : Closed e1205824664542 ∧ code e1205824664542 = 5603871175646 := by decide
theorem cert_e1205824664542 : check e1205824664542 [[],[]] .smaller = true := by decide
def e1205824664558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1205824664558 : Closed e1205824664558 ∧ code e1205824664558 = 5603871175662 := by decide
theorem cert_e1205824664558 : check e1205824664558 [[],[]] .smaller = true := by decide
def e1205824666846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1205824666846 : Closed e1205824666846 ∧ code e1205824666846 = 5603871177950 := by decide
theorem cert_e1205824666846 : check e1205824666846 [[],[]] .smaller = true := by decide
def e1205824666874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1205824666874 : Closed e1205824666874 ∧ code e1205824666874 = 5603871177978 := by decide
theorem cert_e1205824666874 : check e1205824666874 [[],[]] .smaller = true := by decide
def e1205824667246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205824667246 : Closed e1205824667246 ∧ code e1205824667246 = 5603871178350 := by decide
theorem cert_e1205824667246 : check e1205824667246 [[],[]] .smaller = true := by decide
def e1205824667258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205824667258 : Closed e1205824667258 ∧ code e1205824667258 = 5603871178362 := by decide
theorem cert_e1205824667258 : check e1205824667258 [[],[]] .smaller = true := by decide
def e1205824695662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1205824695662 : Closed e1205824695662 ∧ code e1205824695662 = 5603871206766 := by decide
theorem cert_e1205824695662 : check e1205824695662 [[],[]] .smaller = true := by decide
def e1205824695670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1205824695670 : Closed e1205824695670 ∧ code e1205824695670 = 5603871206774 := by decide
theorem cert_e1205824695670 : check e1205824695670 [[],[]] .smaller = true := by decide
def e1205824695726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1205824695726 : Closed e1205824695726 ∧ code e1205824695726 = 5603871206830 := by decide
theorem cert_e1205824695726 : check e1205824695726 [[],[]] .smaller = true := by decide
def e1205824695738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1205824695738 : Closed e1205824695738 ∧ code e1205824695738 = 5603871206842 := by decide
theorem cert_e1205824695738 : check e1205824695738 [[],[]] .smaller = true := by decide
def e1205824695766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1205824695766 : Closed e1205824695766 ∧ code e1205824695766 = 5603871206870 := by decide
theorem cert_e1205824695766 : check e1205824695766 [[],[]] .smaller = true := by decide
def e1205824695770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1205824695770 : Closed e1205824695770 ∧ code e1205824695770 = 5603871206874 := by decide
theorem cert_e1205824695770 : check e1205824695770 [[],[]] .smaller = true := by decide
def e1205824695982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1205824695982 : Closed e1205824695982 ∧ code e1205824695982 = 5603871207086 := by decide
theorem cert_e1205824695982 : check e1205824695982 [[],[]] .smaller = true := by decide
def e1205824695994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1205824695994 : Closed e1205824695994 ∧ code e1205824695994 = 5603871207098 := by decide
theorem cert_e1205824695994 : check e1205824695994 [[],[]] .smaller = true := by decide
def e1205824696042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1205824696042 : Closed e1205824696042 ∧ code e1205824696042 = 5603871207146 := by decide
theorem cert_e1205824696042 : check e1205824696042 [[],[]] .smaller = true := by decide
def e1205824696150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1205824696150 : Closed e1205824696150 ∧ code e1205824696150 = 5603871207254 := by decide
theorem cert_e1205824696150 : check e1205824696150 [[],[]] .smaller = true := by decide
end Blc.Floor42
