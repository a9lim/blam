import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203484086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211203484086 : Closed e1211203484086 ∧ code e1211203484086 = 5609249995190 := by decide
theorem cert_e1211203484086 : check e1211203484086 [[],[]] .chain = true := by decide
def e1211203484118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211203484118 : Closed e1211203484118 ∧ code e1211203484118 = 5609249995222 := by decide
theorem cert_e1211203484118 : check e1211203484118 [[],[]] .chain = true := by decide
def e1211203484122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1211203484122 : Closed e1211203484122 ∧ code e1211203484122 = 5609249995226 := by decide
theorem cert_e1211203484122 : check e1211203484122 [[],[]] .chain = true := by decide
def e1211203484278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203484278 : Closed e1211203484278 ∧ code e1211203484278 = 5609249995382 := by decide
theorem cert_e1211203484278 : check e1211203484278 [[],[]] .chain = true := by decide
def e1211203484422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203484422 : Closed e1211203484422 ∧ code e1211203484422 = 5609249995526 := by decide
theorem cert_e1211203484422 : check e1211203484422 [[],[]] .chain = true := by decide
def e1211203484446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203484446 : Closed e1211203484446 ∧ code e1211203484446 = 5609249995550 := by decide
theorem cert_e1211203484446 : check e1211203484446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203484470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203484470 : Closed e1211203484470 ∧ code e1211203484470 = 5609249995574 := by decide
theorem cert_e1211203484470 : check e1211203484470 [[],[]] .chain = true := by decide
def e1211203484474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203484474 : Closed e1211203484474 ∧ code e1211203484474 = 5609249995578 := by decide
theorem cert_e1211203484474 : check e1211203484474 [[],[]] .chain = true := by decide
def e1211203484558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203484558 : Closed e1211203484558 ∧ code e1211203484558 = 5609249995662 := by decide
theorem cert_e1211203484558 : check e1211203484558 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203491694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1211203491694 : Closed e1211203491694 ∧ code e1211203491694 = 5609250002798 := by decide
theorem cert_e1211203491694 : check e1211203491694 [[],[]] .chain = true := by decide
def e1211203491702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1211203491702 : Closed e1211203491702 ∧ code e1211203491702 = 5609250002806 := by decide
theorem cert_e1211203491702 : check e1211203491702 [[],[]] .chain = true := by decide
def e1211203491766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1211203491766 : Closed e1211203491766 ∧ code e1211203491766 = 5609250002870 := by decide
theorem cert_e1211203491766 : check e1211203491766 [[],[]] .chain = true := by decide
def e1211203493102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1211203493102 : Closed e1211203493102 ∧ code e1211203493102 = 5609250004206 := by decide
theorem cert_e1211203493102 : check e1211203493102 [[],[]] .chain = true := by decide
def e1211203493110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1211203493110 : Closed e1211203493110 ∧ code e1211203493110 = 5609250004214 := by decide
theorem cert_e1211203493110 : check e1211203493110 [[],[]] .chain = true := by decide
def e1211203493494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1211203493494 : Closed e1211203493494 ∧ code e1211203493494 = 5609250004598 := by decide
theorem cert_e1211203493494 : check e1211203493494 [[],[]] .chain = true := by decide
def e1211203502206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e1211203502206 : Closed e1211203502206 ∧ code e1211203502206 = 5609250013310 := by decide
theorem cert_e1211203502206 : check e1211203502206 [[],[]] .chain = true := by decide
def e1211203503070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211203503070 : Closed e1211203503070 ∧ code e1211203503070 = 5609250014174 := by decide
theorem cert_e1211203503070 : check e1211203503070 [[],[]] .chain = true := by decide
def e1211203503074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211203503074 : Closed e1211203503074 ∧ code e1211203503074 = 5609250014178 := by decide
theorem cert_e1211203503074 : check e1211203503074 [[],[]] .chain = true := by decide
def e1211203503086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211203503086 : Closed e1211203503086 ∧ code e1211203503086 = 5609250014190 := by decide
theorem cert_e1211203503086 : check e1211203503086 [[],[]] .chain = true := by decide
def e1211203505006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211203505006 : Closed e1211203505006 ∧ code e1211203505006 = 5609250016110 := by decide
theorem cert_e1211203505006 : check e1211203505006 [[],[]] .chain = true := by decide
def e1211203505014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211203505014 : Closed e1211203505014 ∧ code e1211203505014 = 5609250016118 := by decide
theorem cert_e1211203505014 : check e1211203505014 [[],[]] .chain = true := by decide
def e1211203505070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211203505070 : Closed e1211203505070 ∧ code e1211203505070 = 5609250016174 := by decide
theorem cert_e1211203505070 : check e1211203505070 [[],[]] .chain = true := by decide
def e1211203505082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211203505082 : Closed e1211203505082 ∧ code e1211203505082 = 5609250016186 := by decide
theorem cert_e1211203505082 : check e1211203505082 [[],[]] .chain = true := by decide
def e1211203505110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211203505110 : Closed e1211203505110 ∧ code e1211203505110 = 5609250016214 := by decide
theorem cert_e1211203505110 : check e1211203505110 [[],[]] .chain = true := by decide
def e1211203505114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211203505114 : Closed e1211203505114 ∧ code e1211203505114 = 5609250016218 := by decide
theorem cert_e1211203505114 : check e1211203505114 [[],[]] .chain = true := by decide
def e1211203505390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211203505390 : Closed e1211203505390 ∧ code e1211203505390 = 5609250016494 := by decide
theorem cert_e1211203505390 : check e1211203505390 [[],[]] .chain = true := by decide
def e1211203505398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211203505398 : Closed e1211203505398 ∧ code e1211203505398 = 5609250016502 := by decide
theorem cert_e1211203505398 : check e1211203505398 [[],[]] .chain = true := by decide
def e1211203505774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203505774 : Closed e1211203505774 ∧ code e1211203505774 = 5609250016878 := by decide
theorem cert_e1211203505774 : check e1211203505774 [[],[]] .chain = true := by decide
def e1211203505786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203505786 : Closed e1211203505786 ∧ code e1211203505786 = 5609250016890 := by decide
theorem cert_e1211203505786 : check e1211203505786 [[],[]] .chain = true := by decide
def e1211203505926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203505926 : Closed e1211203505926 ∧ code e1211203505926 = 5609250017030 := by decide
theorem cert_e1211203505926 : check e1211203505926 [[],[]] .chain = true := by decide
def e1211203505950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1211203505950 : Closed e1211203505950 ∧ code e1211203505950 = 5609250017054 := by decide
theorem cert_e1211203505950 : check e1211203505950 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203505974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203505974 : Closed e1211203505974 ∧ code e1211203505974 = 5609250017078 := by decide
theorem cert_e1211203505974 : check e1211203505974 [[],[]] .chain = true := by decide
def e1211203505978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203505978 : Closed e1211203505978 ∧ code e1211203505978 = 5609250017082 := by decide
theorem cert_e1211203505978 : check e1211203505978 [[],[]] .chain = true := by decide
def e1211203510334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e1211203510334 : Closed e1211203510334 ∧ code e1211203510334 = 5609250021438 := by decide
theorem cert_e1211203510334 : check e1211203510334 [[],[]] .chain = true := by decide
def e1211203510754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211203510754 : Closed e1211203510754 ∧ code e1211203510754 = 5609250021858 := by decide
theorem cert_e1211203510754 : check e1211203510754 [[],[]] .chain = true := by decide
def e1211203510766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1211203510766 : Closed e1211203510766 ∧ code e1211203510766 = 5609250021870 := by decide
theorem cert_e1211203510766 : check e1211203510766 [[],[]] .chain = true := by decide
def e1211203511734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211203511734 : Closed e1211203511734 ∧ code e1211203511734 = 5609250022838 := by decide
theorem cert_e1211203511734 : check e1211203511734 [[],[]] .chain = true := by decide
def e1211203511766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211203511766 : Closed e1211203511766 ∧ code e1211203511766 = 5609250022870 := by decide
theorem cert_e1211203511766 : check e1211203511766 [[],[]] .chain = true := by decide
def e1211203511770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211203511770 : Closed e1211203511770 ∧ code e1211203511770 = 5609250022874 := by decide
theorem cert_e1211203511770 : check e1211203511770 [[],[]] .chain = true := by decide
def e1211203511926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211203511926 : Closed e1211203511926 ∧ code e1211203511926 = 5609250023030 := by decide
theorem cert_e1211203511926 : check e1211203511926 [[],[]] .chain = true := by decide
def e1211203512070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203512070 : Closed e1211203512070 ∧ code e1211203512070 = 5609250023174 := by decide
theorem cert_e1211203512070 : check e1211203512070 [[],[]] .chain = true := by decide
def e1211203512094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203512094 : Closed e1211203512094 ∧ code e1211203512094 = 5609250023198 := by decide
theorem cert_e1211203512094 : check e1211203512094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203512118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203512118 : Closed e1211203512118 ∧ code e1211203512118 = 5609250023222 := by decide
theorem cert_e1211203512118 : check e1211203512118 [[],[]] .chain = true := by decide
def e1211203512122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203512122 : Closed e1211203512122 ∧ code e1211203512122 = 5609250023226 := by decide
theorem cert_e1211203512122 : check e1211203512122 [[],[]] .chain = true := by decide
def e1211203512206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203512206 : Closed e1211203512206 ∧ code e1211203512206 = 5609250023310 := by decide
theorem cert_e1211203512206 : check e1211203512206 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203518958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211203518958 : Closed e1211203518958 ∧ code e1211203518958 = 5609250030062 := by decide
theorem cert_e1211203518958 : check e1211203518958 [[],[]] .chain = true := by decide
def e1211203518970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 5))))) (.var 0))))))
theorem wire_e1211203518970 : Closed e1211203518970 ∧ code e1211203518970 = 5609250030074 := by decide
theorem cert_e1211203518970 : check e1211203518970 [[],[]] .chain = true := by decide
def e1211203519726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203519726 : Closed e1211203519726 ∧ code e1211203519726 = 5609250030830 := by decide
theorem cert_e1211203519726 : check e1211203519726 [[],[]] .chain = true := by decide
def e1211203519734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203519734 : Closed e1211203519734 ∧ code e1211203519734 = 5609250030838 := by decide
theorem cert_e1211203519734 : check e1211203519734 [[],[]] .chain = true := by decide
def e1211203520110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203520110 : Closed e1211203520110 ∧ code e1211203520110 = 5609250031214 := by decide
theorem cert_e1211203520110 : check e1211203520110 [[],[]] .chain = true := by decide
def e1211203520122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203520122 : Closed e1211203520122 ∧ code e1211203520122 = 5609250031226 := by decide
theorem cert_e1211203520122 : check e1211203520122 [[],[]] .chain = true := by decide
def e1211203520286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211203520286 : Closed e1211203520286 ∧ code e1211203520286 = 5609250031390 := by decide
theorem cert_e1211203520286 : check e1211203520286 [[],[]] .chain = true := by decide
def e1211203520454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.lam (.var 1)))))))
theorem wire_e1211203520454 : Closed e1211203520454 ∧ code e1211203520454 = 5609250031558 := by decide
theorem cert_e1211203520454 : check e1211203520454 [[],[]] .chain = true := by decide
def e1211203521646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211203521646 : Closed e1211203521646 ∧ code e1211203521646 = 5609250032750 := by decide
theorem cert_e1211203521646 : check e1211203521646 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203521822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211203521822 : Closed e1211203521822 ∧ code e1211203521822 = 5609250032926 := by decide
theorem cert_e1211203521822 : check e1211203521822 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203522030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 2))))))
theorem wire_e1211203522030 : Closed e1211203522030 ∧ code e1211203522030 = 5609250033134 := by decide
theorem cert_e1211203522030 : check e1211203522030 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203522094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211203522094 : Closed e1211203522094 ∧ code e1211203522094 = 5609250033198 := by decide
theorem cert_e1211203522094 : check e1211203522094 [[],[]] .chain = true := by decide
def e1211203522286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1211203522286 : Closed e1211203522286 ∧ code e1211203522286 = 5609250033390 := by decide
theorem cert_e1211203522286 : check e1211203522286 [[],[]] .chain = true := by decide
def e1211203522294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e1211203522294 : Closed e1211203522294 ∧ code e1211203522294 = 5609250033398 := by decide
theorem cert_e1211203522294 : check e1211203522294 [[],[]] .chain = true := by decide
def e1211203522414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1211203522414 : Closed e1211203522414 ∧ code e1211203522414 = 5609250033518 := by decide
theorem cert_e1211203522414 : check e1211203522414 [[],[]] .chain = true := by decide
def e1211203522426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e1211203522426 : Closed e1211203522426 ∧ code e1211203522426 = 5609250033530 := by decide
theorem cert_e1211203522426 : check e1211203522426 [[],[]] .chain = true := by decide
def e1211203522442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203522442 : Closed e1211203522442 ∧ code e1211203522442 = 5609250033546 := by decide
theorem cert_e1211203522442 : check e1211203522442 [[],[]] .chain = true := by decide
def e1211203522478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 2))))))
theorem wire_e1211203522478 : Closed e1211203522478 ∧ code e1211203522478 = 5609250033582 := by decide
theorem cert_e1211203522478 : check e1211203522478 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203522486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e1211203522486 : Closed e1211203522486 ∧ code e1211203522486 = 5609250033590 := by decide
theorem cert_e1211203522486 : check e1211203522486 [[],[]] .chain = true := by decide
def e1211203522490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e1211203522490 : Closed e1211203522490 ∧ code e1211203522490 = 5609250033594 := by decide
theorem cert_e1211203522490 : check e1211203522490 [[],[]] .chain = true := by decide
def e1211203523358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203523358 : Closed e1211203523358 ∧ code e1211203523358 = 5609250034462 := by decide
theorem cert_e1211203523358 : check e1211203523358 [[],[]] .chain = true := by decide
def e1211203523526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203523526 : Closed e1211203523526 ∧ code e1211203523526 = 5609250034630 := by decide
theorem cert_e1211203523526 : check e1211203523526 [[],[]] .chain = true := by decide
def e1211203524670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e1211203524670 : Closed e1211203524670 ∧ code e1211203524670 = 5609250035774 := by decide
theorem cert_e1211203524670 : check e1211203524670 [[],[]] .chain = true := by decide
def e1211203525090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211203525090 : Closed e1211203525090 ∧ code e1211203525090 = 5609250036194 := by decide
theorem cert_e1211203525090 : check e1211203525090 [[],[]] .chain = true := by decide
def e1211203525102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203525102 : Closed e1211203525102 ∧ code e1211203525102 = 5609250036206 := by decide
theorem cert_e1211203525102 : check e1211203525102 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203525870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203525870 : Closed e1211203525870 ∧ code e1211203525870 = 5609250036974 := by decide
theorem cert_e1211203525870 : check e1211203525870 [[],[]] .chain = true := by decide
def e1211203525878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203525878 : Closed e1211203525878 ∧ code e1211203525878 = 5609250036982 := by decide
theorem cert_e1211203525878 : check e1211203525878 [[],[]] .chain = true := by decide
def e1211203526158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.lam (.var 2))))))))
theorem wire_e1211203526158 : Closed e1211203526158 ∧ code e1211203526158 = 5609250037262 := by decide
theorem cert_e1211203526158 : check e1211203526158 [[],[]] .chain = true := by decide
def e1211203526170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203526170 : Closed e1211203526170 ∧ code e1211203526170 = 5609250037274 := by decide
theorem cert_e1211203526170 : check e1211203526170 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203526242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203526242 : Closed e1211203526242 ∧ code e1211203526242 = 5609250037346 := by decide
theorem cert_e1211203526242 : check e1211203526242 [[],[]] .chain = true := by decide
def e1211203526254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203526254 : Closed e1211203526254 ∧ code e1211203526254 = 5609250037358 := by decide
theorem cert_e1211203526254 : check e1211203526254 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203526262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203526262 : Closed e1211203526262 ∧ code e1211203526262 = 5609250037366 := by decide
theorem cert_e1211203526262 : check e1211203526262 [[],[]] .chain = true := by decide
def e1211203526266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203526266 : Closed e1211203526266 ∧ code e1211203526266 = 5609250037370 := by decide
theorem cert_e1211203526266 : check e1211203526266 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203530094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1211203530094 : Closed e1211203530094 ∧ code e1211203530094 = 5609250041198 := by decide
theorem cert_e1211203530094 : check e1211203530094 [[],[]] .chain = true := by decide
def e1211203530102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1211203530102 : Closed e1211203530102 ∧ code e1211203530102 = 5609250041206 := by decide
theorem cert_e1211203530102 : check e1211203530102 [[],[]] .chain = true := by decide
def e1211203530158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1211203530158 : Closed e1211203530158 ∧ code e1211203530158 = 5609250041262 := by decide
theorem cert_e1211203530158 : check e1211203530158 [[],[]] .chain = true := by decide
def e1211203530170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1211203530170 : Closed e1211203530170 ∧ code e1211203530170 = 5609250041274 := by decide
theorem cert_e1211203530170 : check e1211203530170 [[],[]] .chain = true := by decide
def e1211203530198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1211203530198 : Closed e1211203530198 ∧ code e1211203530198 = 5609250041302 := by decide
theorem cert_e1211203530198 : check e1211203530198 [[],[]] .chain = true := by decide
def e1211203530202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1211203530202 : Closed e1211203530202 ∧ code e1211203530202 = 5609250041306 := by decide
theorem cert_e1211203530202 : check e1211203530202 [[],[]] .chain = true := by decide
def e1211203530414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1211203530414 : Closed e1211203530414 ∧ code e1211203530414 = 5609250041518 := by decide
theorem cert_e1211203530414 : check e1211203530414 [[],[]] .chain = true := by decide
def e1211203530426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1211203530426 : Closed e1211203530426 ∧ code e1211203530426 = 5609250041530 := by decide
theorem cert_e1211203530426 : check e1211203530426 [[],[]] .chain = true := by decide
def e1211203530474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1211203530474 : Closed e1211203530474 ∧ code e1211203530474 = 5609250041578 := by decide
theorem cert_e1211203530474 : check e1211203530474 [[],[]] .chain = true := by decide
def e1211203530582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211203530582 : Closed e1211203530582 ∧ code e1211203530582 = 5609250041686 := by decide
theorem cert_e1211203530582 : check e1211203530582 [[],[]] .chain = true := by decide
def e1211203530586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211203530586 : Closed e1211203530586 ∧ code e1211203530586 = 5609250041690 := by decide
theorem cert_e1211203530586 : check e1211203530586 [[],[]] .chain = true := by decide
def e1211203530602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211203530602 : Closed e1211203530602 ∧ code e1211203530602 = 5609250041706 := by decide
theorem cert_e1211203530602 : check e1211203530602 [[],[]] .chain = true := by decide
def e1211203530862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211203530862 : Closed e1211203530862 ∧ code e1211203530862 = 5609250041966 := by decide
theorem cert_e1211203530862 : check e1211203530862 [[],[]] .chain = true := by decide
def e1211203531038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211203531038 : Closed e1211203531038 ∧ code e1211203531038 = 5609250042142 := by decide
theorem cert_e1211203531038 : check e1211203531038 [[],[]] .chain = true := by decide
def e1211203531234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211203531234 : Closed e1211203531234 ∧ code e1211203531234 = 5609250042338 := by decide
theorem cert_e1211203531234 : check e1211203531234 [[],[]] .chain = true := by decide
def e1211203531246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211203531246 : Closed e1211203531246 ∧ code e1211203531246 = 5609250042350 := by decide
theorem cert_e1211203531246 : check e1211203531246 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203531630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211203531630 : Closed e1211203531630 ∧ code e1211203531630 = 5609250042734 := by decide
theorem cert_e1211203531630 : check e1211203531630 [[],[]] .chain = true := by decide
def e1211203531638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1211203531638 : Closed e1211203531638 ∧ code e1211203531638 = 5609250042742 := by decide
theorem cert_e1211203531638 : check e1211203531638 [[],[]] .chain = true := by decide
def e1211203531694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211203531694 : Closed e1211203531694 ∧ code e1211203531694 = 5609250042798 := by decide
theorem cert_e1211203531694 : check e1211203531694 [[],[]] .chain = true := by decide
def e1211203531706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211203531706 : Closed e1211203531706 ∧ code e1211203531706 = 5609250042810 := by decide
theorem cert_e1211203531706 : check e1211203531706 [[],[]] .chain = true := by decide
def e1211203531734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1211203531734 : Closed e1211203531734 ∧ code e1211203531734 = 5609250042838 := by decide
theorem cert_e1211203531734 : check e1211203531734 [[],[]] .chain = true := by decide
def e1211203531738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211203531738 : Closed e1211203531738 ∧ code e1211203531738 = 5609250042842 := by decide
theorem cert_e1211203531738 : check e1211203531738 [[],[]] .chain = true := by decide
def e1211203532014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203532014 : Closed e1211203532014 ∧ code e1211203532014 = 5609250043118 := by decide
theorem cert_e1211203532014 : check e1211203532014 [[],[]] .chain = true := by decide
def e1211203532022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203532022 : Closed e1211203532022 ∧ code e1211203532022 = 5609250043126 := by decide
theorem cert_e1211203532022 : check e1211203532022 [[],[]] .chain = true := by decide
def e1211203532398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203532398 : Closed e1211203532398 ∧ code e1211203532398 = 5609250043502 := by decide
theorem cert_e1211203532398 : check e1211203532398 [[],[]] .chain = true := by decide
def e1211203532410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203532410 : Closed e1211203532410 ∧ code e1211203532410 = 5609250043514 := by decide
theorem cert_e1211203532410 : check e1211203532410 [[],[]] .chain = true := by decide
def e1211203532550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203532550 : Closed e1211203532550 ∧ code e1211203532550 = 5609250043654 := by decide
theorem cert_e1211203532550 : check e1211203532550 [[],[]] .chain = true := by decide
def e1211203532574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211203532574 : Closed e1211203532574 ∧ code e1211203532574 = 5609250043678 := by decide
theorem cert_e1211203532574 : check e1211203532574 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203532598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203532598 : Closed e1211203532598 ∧ code e1211203532598 = 5609250043702 := by decide
theorem cert_e1211203532598 : check e1211203532598 [[],[]] .chain = true := by decide
def e1211203532602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203532602 : Closed e1211203532602 ∧ code e1211203532602 = 5609250043706 := by decide
theorem cert_e1211203532602 : check e1211203532602 [[],[]] .chain = true := by decide
def e1211203532846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211203532846 : Closed e1211203532846 ∧ code e1211203532846 = 5609250043950 := by decide
theorem cert_e1211203532846 : check e1211203532846 [[],[]] .chain = true := by decide
def e1211203533038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203533038 : Closed e1211203533038 ∧ code e1211203533038 = 5609250044142 := by decide
theorem cert_e1211203533038 : check e1211203533038 [[],[]] .chain = true := by decide
def e1211203533046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203533046 : Closed e1211203533046 ∧ code e1211203533046 = 5609250044150 := by decide
theorem cert_e1211203533046 : check e1211203533046 [[],[]] .chain = true := by decide
def e1211203533230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211203533230 : Closed e1211203533230 ∧ code e1211203533230 = 5609250044334 := by decide
theorem cert_e1211203533230 : check e1211203533230 [[],[]] .chain = true := by decide
def e1211203533242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211203533242 : Closed e1211203533242 ∧ code e1211203533242 = 5609250044346 := by decide
theorem cert_e1211203533242 : check e1211203533242 [[],[]] .chain = true := by decide
def e1211203533290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211203533290 : Closed e1211203533290 ∧ code e1211203533290 = 5609250044394 := by decide
theorem cert_e1211203533290 : check e1211203533290 [[],[]] .chain = true := by decide
def e1211203533422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203533422 : Closed e1211203533422 ∧ code e1211203533422 = 5609250044526 := by decide
theorem cert_e1211203533422 : check e1211203533422 [[],[]] .chain = true := by decide
def e1211203533434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203533434 : Closed e1211203533434 ∧ code e1211203533434 = 5609250044538 := by decide
theorem cert_e1211203533434 : check e1211203533434 [[],[]] .chain = true := by decide
def e1211203533598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203533598 : Closed e1211203533598 ∧ code e1211203533598 = 5609250044702 := by decide
theorem cert_e1211203533598 : check e1211203533598 [[],[]] .chain = true := by decide
def e1211203533698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203533698 : Closed e1211203533698 ∧ code e1211203533698 = 5609250044802 := by decide
theorem cert_e1211203533698 : check e1211203533698 [[],[]] .chain = true := by decide
def e1211203533710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203533710 : Closed e1211203533710 ∧ code e1211203533710 = 5609250044814 := by decide
theorem cert_e1211203533710 : check e1211203533710 [[],[]] .chain = true := by decide
def e1211203533722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203533722 : Closed e1211203533722 ∧ code e1211203533722 = 5609250044826 := by decide
theorem cert_e1211203533722 : check e1211203533722 [[],[]] .chain = true := by decide
def e1211203533846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203533846 : Closed e1211203533846 ∧ code e1211203533846 = 5609250044950 := by decide
theorem cert_e1211203533846 : check e1211203533846 [[],[]] .chain = true := by decide
def e1211203533850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203533850 : Closed e1211203533850 ∧ code e1211203533850 = 5609250044954 := by decide
theorem cert_e1211203533850 : check e1211203533850 [[],[]] .chain = true := by decide
def e1211203533894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203533894 : Closed e1211203533894 ∧ code e1211203533894 = 5609250044998 := by decide
theorem cert_e1211203533894 : check e1211203533894 [[],[]] .chain = true := by decide
def e1211203533922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203533922 : Closed e1211203533922 ∧ code e1211203533922 = 5609250045026 := by decide
theorem cert_e1211203533922 : check e1211203533922 [[],[]] .chain = true := by decide
def e1211203533934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203533934 : Closed e1211203533934 ∧ code e1211203533934 = 5609250045038 := by decide
theorem cert_e1211203533934 : check e1211203533934 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203533942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203533942 : Closed e1211203533942 ∧ code e1211203533942 = 5609250045046 := by decide
theorem cert_e1211203533942 : check e1211203533942 [[],[]] .chain = true := by decide
def e1211203533946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203533946 : Closed e1211203533946 ∧ code e1211203533946 = 5609250045050 := by decide
theorem cert_e1211203533946 : check e1211203533946 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203534038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203534038 : Closed e1211203534038 ∧ code e1211203534038 = 5609250045142 := by decide
theorem cert_e1211203534038 : check e1211203534038 [[],[]] .chain = true := by decide
def e1211203534042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211203534042 : Closed e1211203534042 ∧ code e1211203534042 = 5609250045146 := by decide
theorem cert_e1211203534042 : check e1211203534042 [[],[]] .chain = true := by decide
def e1211203534058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211203534058 : Closed e1211203534058 ∧ code e1211203534058 = 5609250045162 := by decide
theorem cert_e1211203534058 : check e1211203534058 [[],[]] .chain = true := by decide
def e1211203534086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203534086 : Closed e1211203534086 ∧ code e1211203534086 = 5609250045190 := by decide
theorem cert_e1211203534086 : check e1211203534086 [[],[]] .chain = true := by decide
def e1211203534110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203534110 : Closed e1211203534110 ∧ code e1211203534110 = 5609250045214 := by decide
theorem cert_e1211203534110 : check e1211203534110 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203534134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203534134 : Closed e1211203534134 ∧ code e1211203534134 = 5609250045238 := by decide
theorem cert_e1211203534134 : check e1211203534134 [[],[]] .chain = true := by decide
def e1211203534138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203534138 : Closed e1211203534138 ∧ code e1211203534138 = 5609250045242 := by decide
theorem cert_e1211203534138 : check e1211203534138 [[],[]] .chain = true := by decide
def e1211203534210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203534210 : Closed e1211203534210 ∧ code e1211203534210 = 5609250045314 := by decide
theorem cert_e1211203534210 : check e1211203534210 [[],[]] .chain = true := by decide
def e1211203534222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203534222 : Closed e1211203534222 ∧ code e1211203534222 = 5609250045326 := by decide
theorem cert_e1211203534222 : check e1211203534222 [[],[]] .chain = true := by decide
def e1211203534234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203534234 : Closed e1211203534234 ∧ code e1211203534234 = 5609250045338 := by decide
theorem cert_e1211203534234 : check e1211203534234 [[],[]] .chain = true := by decide
def e1211203534278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203534278 : Closed e1211203534278 ∧ code e1211203534278 = 5609250045382 := by decide
theorem cert_e1211203534278 : check e1211203534278 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203534974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e1211203534974 : Closed e1211203534974 ∧ code e1211203534974 = 5609250046078 := by decide
theorem cert_e1211203534974 : check e1211203534974 [[],[]] .chain = true := by decide
def e1211203535838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211203535838 : Closed e1211203535838 ∧ code e1211203535838 = 5609250046942 := by decide
theorem cert_e1211203535838 : check e1211203535838 [[],[]] .chain = true := by decide
def e1211203535842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211203535842 : Closed e1211203535842 ∧ code e1211203535842 = 5609250046946 := by decide
theorem cert_e1211203535842 : check e1211203535842 [[],[]] .chain = true := by decide
def e1211203535854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211203535854 : Closed e1211203535854 ∧ code e1211203535854 = 5609250046958 := by decide
theorem cert_e1211203535854 : check e1211203535854 [[],[]] .chain = true := by decide
def e1211203537774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211203537774 : Closed e1211203537774 ∧ code e1211203537774 = 5609250048878 := by decide
theorem cert_e1211203537774 : check e1211203537774 [[],[]] .chain = true := by decide
def e1211203537782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211203537782 : Closed e1211203537782 ∧ code e1211203537782 = 5609250048886 := by decide
theorem cert_e1211203537782 : check e1211203537782 [[],[]] .chain = true := by decide
def e1211203537838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211203537838 : Closed e1211203537838 ∧ code e1211203537838 = 5609250048942 := by decide
theorem cert_e1211203537838 : check e1211203537838 [[],[]] .chain = true := by decide
def e1211203537850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211203537850 : Closed e1211203537850 ∧ code e1211203537850 = 5609250048954 := by decide
theorem cert_e1211203537850 : check e1211203537850 [[],[]] .chain = true := by decide
def e1211203537878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211203537878 : Closed e1211203537878 ∧ code e1211203537878 = 5609250048982 := by decide
theorem cert_e1211203537878 : check e1211203537878 [[],[]] .chain = true := by decide
def e1211203537882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211203537882 : Closed e1211203537882 ∧ code e1211203537882 = 5609250048986 := by decide
theorem cert_e1211203537882 : check e1211203537882 [[],[]] .chain = true := by decide
def e1211203538158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211203538158 : Closed e1211203538158 ∧ code e1211203538158 = 5609250049262 := by decide
theorem cert_e1211203538158 : check e1211203538158 [[],[]] .chain = true := by decide
def e1211203538166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211203538166 : Closed e1211203538166 ∧ code e1211203538166 = 5609250049270 := by decide
theorem cert_e1211203538166 : check e1211203538166 [[],[]] .chain = true := by decide
def e1211203538542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211203538542 : Closed e1211203538542 ∧ code e1211203538542 = 5609250049646 := by decide
theorem cert_e1211203538542 : check e1211203538542 [[],[]] .chain = true := by decide
def e1211203538554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211203538554 : Closed e1211203538554 ∧ code e1211203538554 = 5609250049658 := by decide
theorem cert_e1211203538554 : check e1211203538554 [[],[]] .chain = true := by decide
def e1211203538694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203538694 : Closed e1211203538694 ∧ code e1211203538694 = 5609250049798 := by decide
theorem cert_e1211203538694 : check e1211203538694 [[],[]] .chain = true := by decide
def e1211203538718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1211203538718 : Closed e1211203538718 ∧ code e1211203538718 = 5609250049822 := by decide
theorem cert_e1211203538718 : check e1211203538718 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203538742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203538742 : Closed e1211203538742 ∧ code e1211203538742 = 5609250049846 := by decide
theorem cert_e1211203538742 : check e1211203538742 [[],[]] .chain = true := by decide
def e1211203538746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203538746 : Closed e1211203538746 ∧ code e1211203538746 = 5609250049850 := by decide
theorem cert_e1211203538746 : check e1211203538746 [[],[]] .chain = true := by decide
def e1211203543518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211203543518 : Closed e1211203543518 ∧ code e1211203543518 = 5609250054622 := by decide
theorem cert_e1211203543518 : check e1211203543518 [[],[]] .chain = true := by decide
def e1211203543542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211203543542 : Closed e1211203543542 ∧ code e1211203543542 = 5609250054646 := by decide
theorem cert_e1211203543542 : check e1211203543542 [[],[]] .chain = true := by decide
def e1211203544494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211203544494 : Closed e1211203544494 ∧ code e1211203544494 = 5609250055598 := by decide
theorem cert_e1211203544494 : check e1211203544494 [[],[]] .chain = true := by decide
def e1211203544506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211203544506 : Closed e1211203544506 ∧ code e1211203544506 = 5609250055610 := by decide
theorem cert_e1211203544506 : check e1211203544506 [[],[]] .chain = true := by decide
end Blc.Floor42
