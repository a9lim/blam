import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211558382550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211558382550 : Closed e1211558382550 ∧ code e1211558382550 = 5609604893654 := by decide
private def t_e1211558382550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1211558382550 : ¬ IsSelfInterpreter e1211558382550 :=
  wSource (t := t_e1211558382550) (replay_sound (ps := []) (t := e1211558382550) (by decide)) (by decide)
def e1211558382554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211558382554 : Closed e1211558382554 ∧ code e1211558382554 = 5609604893658 := by decide
private def t_e1211558382554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1211558382554 : ¬ IsSelfInterpreter e1211558382554 :=
  wSource (t := t_e1211558382554) (replay_sound (ps := []) (t := e1211558382554) (by decide)) (by decide)
def e1211558382830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211558382830 : Closed e1211558382830 ∧ code e1211558382830 = 5609604893934 := by decide
private def t_e1211558382830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211558382830 : ¬ IsSelfInterpreter e1211558382830 :=
  wSource (t := t_e1211558382830) (replay_sound (ps := []) (t := e1211558382830) (by decide)) (by decide)
def e1211558382838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211558382838 : Closed e1211558382838 ∧ code e1211558382838 = 5609604893942 := by decide
private def t_e1211558382838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211558382838 : ¬ IsSelfInterpreter e1211558382838 :=
  wSource (t := t_e1211558382838) (replay_sound (ps := []) (t := e1211558382838) (by decide)) (by decide)
def e1211558383214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211558383214 : Closed e1211558383214 ∧ code e1211558383214 = 5609604894318 := by decide
private def t_e1211558383214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211558383214 : ¬ IsSelfInterpreter e1211558383214 :=
  wSource (t := t_e1211558383214) (replay_sound (ps := []) (t := e1211558383214) (by decide)) (by decide)
def e1211558383226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211558383226 : Closed e1211558383226 ∧ code e1211558383226 = 5609604894330 := by decide
private def t_e1211558383226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211558383226 : ¬ IsSelfInterpreter e1211558383226 :=
  wSource (t := t_e1211558383226) (replay_sound (ps := []) (t := e1211558383226) (by decide)) (by decide)
def e1211558383414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211558383414 : Closed e1211558383414 ∧ code e1211558383414 = 5609604894518 := by decide
private def t_e1211558383414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211558383414 : ¬ IsSelfInterpreter e1211558383414 :=
  wSource (t := t_e1211558383414) (replay_sound (ps := []) (t := e1211558383414) (by decide)) (by decide)
def e1211558383418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211558383418 : Closed e1211558383418 ∧ code e1211558383418 = 5609604894522 := by decide
private def t_e1211558383418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211558383418 : ¬ IsSelfInterpreter e1211558383418 :=
  wSource (t := t_e1211558383418) (replay_sound (ps := []) (t := e1211558383418) (by decide)) (by decide)
def e1211558389174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211558389174 : Closed e1211558389174 ∧ code e1211558389174 = 5609604900278 := by decide
private def t_e1211558389174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem cert_e1211558389174 : ¬ IsSelfInterpreter e1211558389174 :=
  wSource (t := t_e1211558389174) (replay_sound (ps := []) (t := e1211558389174) (by decide)) (by decide)
def e1211558389206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211558389206 : Closed e1211558389206 ∧ code e1211558389206 = 5609604900310 := by decide
private def t_e1211558389206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem cert_e1211558389206 : ¬ IsSelfInterpreter e1211558389206 :=
  wSource (t := t_e1211558389206) (replay_sound (ps := []) (t := e1211558389206) (by decide)) (by decide)
def e1211558389210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211558389210 : Closed e1211558389210 ∧ code e1211558389210 = 5609604900314 := by decide
private def t_e1211558389210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem cert_e1211558389210 : ¬ IsSelfInterpreter e1211558389210 :=
  wSource (t := t_e1211558389210) (replay_sound (ps := []) (t := e1211558389210) (by decide)) (by decide)
def e1211558389366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211558389366 : Closed e1211558389366 ∧ code e1211558389366 = 5609604900470 := by decide
private def t_e1211558389366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem cert_e1211558389366 : ¬ IsSelfInterpreter e1211558389366 :=
  wSource (t := t_e1211558389366) (replay_sound (ps := []) (t := e1211558389366) (by decide)) (by decide)
def e1211558389558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211558389558 : Closed e1211558389558 ∧ code e1211558389558 = 5609604900662 := by decide
private def t_e1211558389558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211558389558 : ¬ IsSelfInterpreter e1211558389558 :=
  wSource (t := t_e1211558389558) (replay_sound (ps := []) (t := e1211558389558) (by decide)) (by decide)
def e1211558389562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211558389562 : Closed e1211558389562 ∧ code e1211558389562 = 5609604900666 := by decide
private def t_e1211558389562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211558389562 : ¬ IsSelfInterpreter e1211558389562 :=
  wSource (t := t_e1211558389562) (replay_sound (ps := []) (t := e1211558389562) (by decide)) (by decide)
def e1211558726510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211558726510 : Closed e1211558726510 ∧ code e1211558726510 = 5609605237614 := by decide
private def t_e1211558726510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1211558726510 : ¬ IsSelfInterpreter e1211558726510 :=
  wSource (t := t_e1211558726510) (replay_sound (ps := []) (t := e1211558726510) (by decide)) (by decide)
def e1211558726518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211558726518 : Closed e1211558726518 ∧ code e1211558726518 = 5609605237622 := by decide
private def t_e1211558726518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1211558726518 : ¬ IsSelfInterpreter e1211558726518 :=
  wSource (t := t_e1211558726518) (replay_sound (ps := []) (t := e1211558726518) (by decide)) (by decide)
def e1211558726574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211558726574 : Closed e1211558726574 ∧ code e1211558726574 = 5609605237678 := by decide
private def t_e1211558726574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1211558726574 : ¬ IsSelfInterpreter e1211558726574 :=
  wSource (t := t_e1211558726574) (replay_sound (ps := []) (t := e1211558726574) (by decide)) (by decide)
def e1211558726586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211558726586 : Closed e1211558726586 ∧ code e1211558726586 = 5609605237690 := by decide
private def t_e1211558726586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1211558726586 : ¬ IsSelfInterpreter e1211558726586 :=
  wSource (t := t_e1211558726586) (replay_sound (ps := []) (t := e1211558726586) (by decide)) (by decide)
def e1211558726614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211558726614 : Closed e1211558726614 ∧ code e1211558726614 = 5609605237718 := by decide
private def t_e1211558726614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1211558726614 : ¬ IsSelfInterpreter e1211558726614 :=
  wSource (t := t_e1211558726614) (replay_sound (ps := []) (t := e1211558726614) (by decide)) (by decide)
def e1211558726618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211558726618 : Closed e1211558726618 ∧ code e1211558726618 = 5609605237722 := by decide
private def t_e1211558726618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1211558726618 : ¬ IsSelfInterpreter e1211558726618 :=
  wSource (t := t_e1211558726618) (replay_sound (ps := []) (t := e1211558726618) (by decide)) (by decide)
def e1211558726894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211558726894 : Closed e1211558726894 ∧ code e1211558726894 = 5609605237998 := by decide
private def t_e1211558726894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211558726894 : ¬ IsSelfInterpreter e1211558726894 :=
  wSource (t := t_e1211558726894) (replay_sound (ps := []) (t := e1211558726894) (by decide)) (by decide)
def e1211558726902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211558726902 : Closed e1211558726902 ∧ code e1211558726902 = 5609605238006 := by decide
private def t_e1211558726902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211558726902 : ¬ IsSelfInterpreter e1211558726902 :=
  wSource (t := t_e1211558726902) (replay_sound (ps := []) (t := e1211558726902) (by decide)) (by decide)
def e1211558727278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211558727278 : Closed e1211558727278 ∧ code e1211558727278 = 5609605238382 := by decide
private def t_e1211558727278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211558727278 : ¬ IsSelfInterpreter e1211558727278 :=
  wSource (t := t_e1211558727278) (replay_sound (ps := []) (t := e1211558727278) (by decide)) (by decide)
def e1211558727290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211558727290 : Closed e1211558727290 ∧ code e1211558727290 = 5609605238394 := by decide
private def t_e1211558727290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211558727290 : ¬ IsSelfInterpreter e1211558727290 :=
  wSource (t := t_e1211558727290) (replay_sound (ps := []) (t := e1211558727290) (by decide)) (by decide)
def e1211558727478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211558727478 : Closed e1211558727478 ∧ code e1211558727478 = 5609605238582 := by decide
private def t_e1211558727478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211558727478 : ¬ IsSelfInterpreter e1211558727478 :=
  wSource (t := t_e1211558727478) (replay_sound (ps := []) (t := e1211558727478) (by decide)) (by decide)
def e1211558727482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211558727482 : Closed e1211558727482 ∧ code e1211558727482 = 5609605238586 := by decide
private def t_e1211558727482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211558727482 : ¬ IsSelfInterpreter e1211558727482 :=
  wSource (t := t_e1211558727482) (replay_sound (ps := []) (t := e1211558727482) (by decide)) (by decide)
def e1211583454078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 5))))))))))
theorem wire_e1211583454078 : Closed e1211583454078 ∧ code e1211583454078 = 5609629965182 := by decide
theorem cert_e1211583454078 : check e1211583454078 [[],[],[],[]] .three = true := by decide
def e1211583454198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 5)) (.var 1))))))))))
theorem wire_e1211583454198 : Closed e1211583454198 ∧ code e1211583454198 = 5609629965302 := by decide
theorem cert_e1211583454198 : check e1211583454198 [[],[],[],[]] .three = true := by decide
def e1211583454590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 5))))))))))
theorem wire_e1211583454590 : Closed e1211583454590 ∧ code e1211583454590 = 5609629965694 := by decide
theorem cert_e1211583454590 : check e1211583454590 [[],[],[],[]] .three = true := by decide
def e1211583454714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 5)) (.var 0))))))))))
theorem wire_e1211583454714 : Closed e1211583454714 ∧ code e1211583454714 = 5609629965818 := by decide
theorem cert_e1211583454714 : check e1211583454714 [[],[],[],[]] .three = true := by decide
def e1211583455190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 0)) (.var 1))))))))))
theorem wire_e1211583455190 : Closed e1211583455190 ∧ code e1211583455190 = 5609629966294 := by decide
theorem cert_e1211583455190 : check e1211583455190 [[],[],[],[]] .three = true := by decide
def e1211583455194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 1)) (.var 0))))))))))
theorem wire_e1211583455194 : Closed e1211583455194 ∧ code e1211583455194 = 5609629966298 := by decide
theorem cert_e1211583455194 : check e1211583455194 [[],[],[],[]] .three = true := by decide
def e1211583457150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 5)))))))))))
theorem wire_e1211583457150 : Closed e1211583457150 ∧ code e1211583457150 = 5609629968254 := by decide
theorem cert_e1211583457150 : check e1211583457150 [[],[],[],[]] .three = true := by decide
def e1211583457270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.var 1)))))))))))
theorem wire_e1211583457270 : Closed e1211583457270 ∧ code e1211583457270 = 5609629968374 := by decide
theorem cert_e1211583457270 : check e1211583457270 [[],[],[],[]] .three = true := by decide
def e1211583460222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 5)))))))))))
theorem wire_e1211583460222 : Closed e1211583460222 ∧ code e1211583460222 = 5609629971326 := by decide
theorem cert_e1211583460222 : check e1211583460222 [[],[],[],[]] .three = true := by decide
def e1211583460346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 5) (.var 0)))))))))))
theorem wire_e1211583460346 : Closed e1211583460346 ∧ code e1211583460346 = 5609629971450 := by decide
theorem cert_e1211583460346 : check e1211583460346 [[],[],[],[]] .three = true := by decide
def e1211583463222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583463222 : Closed e1211583463222 ∧ code e1211583463222 = 5609629974326 := by decide
theorem cert_e1211583463222 : check e1211583463222 [[],[],[],[]] .three = true := by decide
def e1211583463226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583463226 : Closed e1211583463226 ∧ code e1211583463226 = 5609629974330 := by decide
theorem cert_e1211583463226 : check e1211583463226 [[],[],[],[]] .three = true := by decide
def e1211583519454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e1211583519454 : Closed e1211583519454 ∧ code e1211583519454 = 5609630030558 := by decide
theorem cert_e1211583519454 : check e1211583519454 [[],[],[],[]] .three = true := by decide
def e1211583519478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e1211583519478 : Closed e1211583519478 ∧ code e1211583519478 = 5609630030582 := by decide
theorem cert_e1211583519478 : check e1211583519478 [[],[],[],[]] .three = true := by decide
def e1211583519582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e1211583519582 : Closed e1211583519582 ∧ code e1211583519582 = 5609630030686 := by decide
theorem cert_e1211583519582 : check e1211583519582 [[],[],[],[]] .three = true := by decide
def e1211583519598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e1211583519598 : Closed e1211583519598 ∧ code e1211583519598 = 5609630030702 := by decide
theorem cert_e1211583519598 : check e1211583519598 [[],[],[],[]] .smaller = true := by decide
def e1211583519606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e1211583519606 : Closed e1211583519606 ∧ code e1211583519606 = 5609630030710 := by decide
theorem cert_e1211583519606 : check e1211583519606 [[],[],[],[]] .smaller = true := by decide
def e1211583519610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e1211583519610 : Closed e1211583519610 ∧ code e1211583519610 = 5609630030714 := by decide
theorem cert_e1211583519610 : check e1211583519610 [[],[],[],[]] .three = true := by decide
def e1211583519670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e1211583519670 : Closed e1211583519670 ∧ code e1211583519670 = 5609630030774 := by decide
theorem cert_e1211583519670 : check e1211583519670 [[],[],[],[]] .smaller = true := by decide
def e1211583519702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e1211583519702 : Closed e1211583519702 ∧ code e1211583519702 = 5609630030806 := by decide
theorem cert_e1211583519702 : check e1211583519702 [[],[],[],[]] .three = true := by decide
def e1211583519706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e1211583519706 : Closed e1211583519706 ∧ code e1211583519706 = 5609630030810 := by decide
theorem cert_e1211583519706 : check e1211583519706 [[],[],[],[]] .three = true := by decide
def e1211583520094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e1211583520094 : Closed e1211583520094 ∧ code e1211583520094 = 5609630031198 := by decide
theorem cert_e1211583520094 : check e1211583520094 [[],[],[],[]] .three = true := by decide
def e1211583520110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211583520110 : Closed e1211583520110 ∧ code e1211583520110 = 5609630031214 := by decide
theorem cert_e1211583520110 : check e1211583520110 [[],[],[],[]] .smaller = true := by decide
def e1211583520118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211583520118 : Closed e1211583520118 ∧ code e1211583520118 = 5609630031222 := by decide
theorem cert_e1211583520118 : check e1211583520118 [[],[],[],[]] .smaller = true := by decide
def e1211583520122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e1211583520122 : Closed e1211583520122 ∧ code e1211583520122 = 5609630031226 := by decide
theorem cert_e1211583520122 : check e1211583520122 [[],[],[],[]] .three = true := by decide
def e1211583520174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211583520174 : Closed e1211583520174 ∧ code e1211583520174 = 5609630031278 := by decide
theorem cert_e1211583520174 : check e1211583520174 [[],[],[],[]] .smaller = true := by decide
def e1211583520186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211583520186 : Closed e1211583520186 ∧ code e1211583520186 = 5609630031290 := by decide
theorem cert_e1211583520186 : check e1211583520186 [[],[],[],[]] .smaller = true := by decide
def e1211583520214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211583520214 : Closed e1211583520214 ∧ code e1211583520214 = 5609630031318 := by decide
theorem cert_e1211583520214 : check e1211583520214 [[],[],[],[]] .smaller = true := by decide
def e1211583520218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211583520218 : Closed e1211583520218 ∧ code e1211583520218 = 5609630031322 := by decide
theorem cert_e1211583520218 : check e1211583520218 [[],[],[],[]] .smaller = true := by decide
def e1211583520234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e1211583520234 : Closed e1211583520234 ∧ code e1211583520234 = 5609630031338 := by decide
theorem cert_e1211583520234 : check e1211583520234 [[],[],[],[]] .three = true := by decide
def e1211583520438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211583520438 : Closed e1211583520438 ∧ code e1211583520438 = 5609630031542 := by decide
theorem cert_e1211583520438 : check e1211583520438 [[],[],[],[]] .smaller = true := by decide
def e1211583520470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211583520470 : Closed e1211583520470 ∧ code e1211583520470 = 5609630031574 := by decide
theorem cert_e1211583520470 : check e1211583520470 [[],[],[],[]] .smaller = true := by decide
def e1211583520474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211583520474 : Closed e1211583520474 ∧ code e1211583520474 = 5609630031578 := by decide
theorem cert_e1211583520474 : check e1211583520474 [[],[],[],[]] .smaller = true := by decide
def e1211583520598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211583520598 : Closed e1211583520598 ∧ code e1211583520598 = 5609630031702 := by decide
theorem cert_e1211583520598 : check e1211583520598 [[],[],[],[]] .three = true := by decide
def e1211583520602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211583520602 : Closed e1211583520602 ∧ code e1211583520602 = 5609630031706 := by decide
theorem cert_e1211583520602 : check e1211583520602 [[],[],[],[]] .three = true := by decide
def e1211583520618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211583520618 : Closed e1211583520618 ∧ code e1211583520618 = 5609630031722 := by decide
theorem cert_e1211583520618 : check e1211583520618 [[],[],[],[]] .three = true := by decide
def e1211583521726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 4)))))))))
theorem wire_e1211583521726 : Closed e1211583521726 ∧ code e1211583521726 = 5609630032830 := by decide
theorem cert_e1211583521726 : check e1211583521726 [[],[],[],[]] .three = true := by decide
def e1211583521782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.var 1)))))))))
theorem wire_e1211583521782 : Closed e1211583521782 ∧ code e1211583521782 = 5609630032886 := by decide
theorem cert_e1211583521782 : check e1211583521782 [[],[],[],[]] .three = true := by decide
def e1211583522526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e1211583522526 : Closed e1211583522526 ∧ code e1211583522526 = 5609630033630 := by decide
theorem cert_e1211583522526 : check e1211583522526 [[],[],[],[]] .three = true := by decide
def e1211583522550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e1211583522550 : Closed e1211583522550 ∧ code e1211583522550 = 5609630033654 := by decide
theorem cert_e1211583522550 : check e1211583522550 [[],[],[],[]] .three = true := by decide
def e1211583522654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e1211583522654 : Closed e1211583522654 ∧ code e1211583522654 = 5609630033758 := by decide
theorem cert_e1211583522654 : check e1211583522654 [[],[],[],[]] .three = true := by decide
def e1211583522670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e1211583522670 : Closed e1211583522670 ∧ code e1211583522670 = 5609630033774 := by decide
theorem cert_e1211583522670 : check e1211583522670 [[],[],[],[]] .smaller = true := by decide
def e1211583522678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e1211583522678 : Closed e1211583522678 ∧ code e1211583522678 = 5609630033782 := by decide
theorem cert_e1211583522678 : check e1211583522678 [[],[],[],[]] .smaller = true := by decide
def e1211583522682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e1211583522682 : Closed e1211583522682 ∧ code e1211583522682 = 5609630033786 := by decide
theorem cert_e1211583522682 : check e1211583522682 [[],[],[],[]] .three = true := by decide
def e1211583522742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e1211583522742 : Closed e1211583522742 ∧ code e1211583522742 = 5609630033846 := by decide
theorem cert_e1211583522742 : check e1211583522742 [[],[],[],[]] .smaller = true := by decide
def e1211583522774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e1211583522774 : Closed e1211583522774 ∧ code e1211583522774 = 5609630033878 := by decide
theorem cert_e1211583522774 : check e1211583522774 [[],[],[],[]] .three = true := by decide
def e1211583522778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e1211583522778 : Closed e1211583522778 ∧ code e1211583522778 = 5609630033882 := by decide
theorem cert_e1211583522778 : check e1211583522778 [[],[],[],[]] .three = true := by decide
def e1211583523294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211583523294 : Closed e1211583523294 ∧ code e1211583523294 = 5609630034398 := by decide
theorem cert_e1211583523294 : check e1211583523294 [[],[],[],[]] .three = true := by decide
def e1211583523318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211583523318 : Closed e1211583523318 ∧ code e1211583523318 = 5609630034422 := by decide
theorem cert_e1211583523318 : check e1211583523318 [[],[],[],[]] .three = true := by decide
def e1211583523966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 5))))))))))
theorem wire_e1211583523966 : Closed e1211583523966 ∧ code e1211583523966 = 5609630035070 := by decide
theorem cert_e1211583523966 : check e1211583523966 [[],[],[],[]] .three = true := by decide
def e1211583524062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211583524062 : Closed e1211583524062 ∧ code e1211583524062 = 5609630035166 := by decide
theorem cert_e1211583524062 : check e1211583524062 [[],[],[],[]] .three = true := by decide
def e1211583524078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211583524078 : Closed e1211583524078 ∧ code e1211583524078 = 5609630035182 := by decide
theorem cert_e1211583524078 : check e1211583524078 [[],[],[],[]] .smaller = true := by decide
def e1211583524086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211583524086 : Closed e1211583524086 ∧ code e1211583524086 = 5609630035190 := by decide
theorem cert_e1211583524086 : check e1211583524086 [[],[],[],[]] .smaller = true := by decide
def e1211583524090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211583524090 : Closed e1211583524090 ∧ code e1211583524090 = 5609630035194 := by decide
theorem cert_e1211583524090 : check e1211583524090 [[],[],[],[]] .three = true := by decide
def e1211583524470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211583524470 : Closed e1211583524470 ∧ code e1211583524470 = 5609630035574 := by decide
theorem cert_e1211583524470 : check e1211583524470 [[],[],[],[]] .smaller = true := by decide
def e1211583524662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211583524662 : Closed e1211583524662 ∧ code e1211583524662 = 5609630035766 := by decide
theorem cert_e1211583524662 : check e1211583524662 [[],[],[],[]] .three = true := by decide
def e1211583524666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211583524666 : Closed e1211583524666 ∧ code e1211583524666 = 5609630035770 := by decide
theorem cert_e1211583524666 : check e1211583524666 [[],[],[],[]] .three = true := by decide
def e1211583524750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.var 2))))))))))
theorem wire_e1211583524750 : Closed e1211583524750 ∧ code e1211583524750 = 5609630035854 := by decide
theorem cert_e1211583524750 : check e1211583524750 [[],[],[],[]] .three = true := by decide
def e1211583525310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e1211583525310 : Closed e1211583525310 ∧ code e1211583525310 = 5609630036414 := by decide
theorem cert_e1211583525310 : check e1211583525310 [[],[],[],[]] .three = true := by decide
def e1211583525370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e1211583525370 : Closed e1211583525370 ∧ code e1211583525370 = 5609630036474 := by decide
theorem cert_e1211583525370 : check e1211583525370 [[],[],[],[]] .three = true := by decide
def e1211583525726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e1211583525726 : Closed e1211583525726 ∧ code e1211583525726 = 5609630036830 := by decide
theorem cert_e1211583525726 : check e1211583525726 [[],[],[],[]] .three = true := by decide
def e1211583525742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211583525742 : Closed e1211583525742 ∧ code e1211583525742 = 5609630036846 := by decide
theorem cert_e1211583525742 : check e1211583525742 [[],[],[],[]] .smaller = true := by decide
def e1211583525750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211583525750 : Closed e1211583525750 ∧ code e1211583525750 = 5609630036854 := by decide
theorem cert_e1211583525750 : check e1211583525750 [[],[],[],[]] .smaller = true := by decide
def e1211583525754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e1211583525754 : Closed e1211583525754 ∧ code e1211583525754 = 5609630036858 := by decide
theorem cert_e1211583525754 : check e1211583525754 [[],[],[],[]] .three = true := by decide
def e1211583525806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211583525806 : Closed e1211583525806 ∧ code e1211583525806 = 5609630036910 := by decide
theorem cert_e1211583525806 : check e1211583525806 [[],[],[],[]] .smaller = true := by decide
def e1211583525818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211583525818 : Closed e1211583525818 ∧ code e1211583525818 = 5609630036922 := by decide
theorem cert_e1211583525818 : check e1211583525818 [[],[],[],[]] .smaller = true := by decide
def e1211583525846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211583525846 : Closed e1211583525846 ∧ code e1211583525846 = 5609630036950 := by decide
theorem cert_e1211583525846 : check e1211583525846 [[],[],[],[]] .smaller = true := by decide
def e1211583525850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211583525850 : Closed e1211583525850 ∧ code e1211583525850 = 5609630036954 := by decide
theorem cert_e1211583525850 : check e1211583525850 [[],[],[],[]] .smaller = true := by decide
def e1211583525866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e1211583525866 : Closed e1211583525866 ∧ code e1211583525866 = 5609630036970 := by decide
theorem cert_e1211583525866 : check e1211583525866 [[],[],[],[]] .three = true := by decide
def e1211583526014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e1211583526014 : Closed e1211583526014 ∧ code e1211583526014 = 5609630037118 := by decide
theorem cert_e1211583526014 : check e1211583526014 [[],[],[],[]] .three = true := by decide
def e1211583526110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211583526110 : Closed e1211583526110 ∧ code e1211583526110 = 5609630037214 := by decide
theorem cert_e1211583526110 : check e1211583526110 [[],[],[],[]] .three = true := by decide
def e1211583526126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211583526126 : Closed e1211583526126 ∧ code e1211583526126 = 5609630037230 := by decide
theorem cert_e1211583526126 : check e1211583526126 [[],[],[],[]] .smaller = true := by decide
def e1211583526134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211583526134 : Closed e1211583526134 ∧ code e1211583526134 = 5609630037238 := by decide
theorem cert_e1211583526134 : check e1211583526134 [[],[],[],[]] .smaller = true := by decide
def e1211583526138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211583526138 : Closed e1211583526138 ∧ code e1211583526138 = 5609630037242 := by decide
theorem cert_e1211583526138 : check e1211583526138 [[],[],[],[]] .three = true := by decide
def e1211583526510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211583526510 : Closed e1211583526510 ∧ code e1211583526510 = 5609630037614 := by decide
theorem cert_e1211583526510 : check e1211583526510 [[],[],[],[]] .smaller = true := by decide
def e1211583526522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211583526522 : Closed e1211583526522 ∧ code e1211583526522 = 5609630037626 := by decide
theorem cert_e1211583526522 : check e1211583526522 [[],[],[],[]] .smaller = true := by decide
def e1211583526710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211583526710 : Closed e1211583526710 ∧ code e1211583526710 = 5609630037814 := by decide
theorem cert_e1211583526710 : check e1211583526710 [[],[],[],[]] .smaller = true := by decide
def e1211583526714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211583526714 : Closed e1211583526714 ∧ code e1211583526714 = 5609630037818 := by decide
theorem cert_e1211583526714 : check e1211583526714 [[],[],[],[]] .smaller = true := by decide
def e1211583526810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211583526810 : Closed e1211583526810 ∧ code e1211583526810 = 5609630037914 := by decide
theorem cert_e1211583526810 : check e1211583526810 [[],[],[],[]] .three = true := by decide
def e1211583526846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 4)))))))))
theorem wire_e1211583526846 : Closed e1211583526846 ∧ code e1211583526846 = 5609630037950 := by decide
theorem cert_e1211583526846 : check e1211583526846 [[],[],[],[]] .three = true := by decide
def e1211583526854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e1211583526854 : Closed e1211583526854 ∧ code e1211583526854 = 5609630037958 := by decide
theorem cert_e1211583526854 : check e1211583526854 [[],[],[],[]] .three = true := by decide
def e1211583526878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 3)))))))))
theorem wire_e1211583526878 : Closed e1211583526878 ∧ code e1211583526878 = 5609630037982 := by decide
theorem cert_e1211583526878 : check e1211583526878 [[],[],[],[]] .three = true := by decide
def e1211583527350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211583527350 : Closed e1211583527350 ∧ code e1211583527350 = 5609630038454 := by decide
theorem cert_e1211583527350 : check e1211583527350 [[],[],[],[]] .smaller = true := by decide
def e1211583527382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211583527382 : Closed e1211583527382 ∧ code e1211583527382 = 5609630038486 := by decide
theorem cert_e1211583527382 : check e1211583527382 [[],[],[],[]] .smaller = true := by decide
def e1211583527386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211583527386 : Closed e1211583527386 ∧ code e1211583527386 = 5609630038490 := by decide
theorem cert_e1211583527386 : check e1211583527386 [[],[],[],[]] .smaller = true := by decide
def e1211583527542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211583527542 : Closed e1211583527542 ∧ code e1211583527542 = 5609630038646 := by decide
theorem cert_e1211583527542 : check e1211583527542 [[],[],[],[]] .smaller = true := by decide
def e1211583527734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211583527734 : Closed e1211583527734 ∧ code e1211583527734 = 5609630038838 := by decide
theorem cert_e1211583527734 : check e1211583527734 [[],[],[],[]] .smaller = true := by decide
def e1211583527738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211583527738 : Closed e1211583527738 ∧ code e1211583527738 = 5609630038842 := by decide
theorem cert_e1211583527738 : check e1211583527738 [[],[],[],[]] .smaller = true := by decide
def e1211583528150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211583528150 : Closed e1211583528150 ∧ code e1211583528150 = 5609630039254 := by decide
theorem cert_e1211583528150 : check e1211583528150 [[],[],[],[]] .three = true := by decide
def e1211583528154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211583528154 : Closed e1211583528154 ∧ code e1211583528154 = 5609630039258 := by decide
theorem cert_e1211583528154 : check e1211583528154 [[],[],[],[]] .three = true := by decide
def e1211583528170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211583528170 : Closed e1211583528170 ∧ code e1211583528170 = 5609630039274 := by decide
theorem cert_e1211583528170 : check e1211583528170 [[],[],[],[]] .three = true := by decide
def e1211583528246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211583528246 : Closed e1211583528246 ∧ code e1211583528246 = 5609630039350 := by decide
theorem cert_e1211583528246 : check e1211583528246 [[],[],[],[]] .three = true := by decide
def e1211583528250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211583528250 : Closed e1211583528250 ∧ code e1211583528250 = 5609630039354 := by decide
theorem cert_e1211583528250 : check e1211583528250 [[],[],[],[]] .three = true := by decide
def e1211583528346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211583528346 : Closed e1211583528346 ∧ code e1211583528346 = 5609630039450 := by decide
theorem cert_e1211583528346 : check e1211583528346 [[],[],[],[]] .three = true := by decide
def e1211583528382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 4)))))))))
theorem wire_e1211583528382 : Closed e1211583528382 ∧ code e1211583528382 = 5609630039486 := by decide
theorem cert_e1211583528382 : check e1211583528382 [[],[],[],[]] .three = true := by decide
def e1211583528438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 1)))))))))
theorem wire_e1211583528438 : Closed e1211583528438 ∧ code e1211583528438 = 5609630039542 := by decide
private def t_e1211583528438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 1)))))))))
theorem cert_e1211583528438 : ¬ IsSelfInterpreter e1211583528438 :=
  wSource (t := t_e1211583528438) (replay_sound (ps := []) (t := e1211583528438) (by decide)) (by decide)
def e1211583528502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211583528502 : Closed e1211583528502 ∧ code e1211583528502 = 5609630039606 := by decide
theorem cert_e1211583528502 : check e1211583528502 [[],[],[],[]] .three = true := by decide
def e1211583528506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211583528506 : Closed e1211583528506 ∧ code e1211583528506 = 5609630039610 := by decide
theorem cert_e1211583528506 : check e1211583528506 [[],[],[],[]] .three = true := by decide
def e1211583528590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211583528590 : Closed e1211583528590 ∧ code e1211583528590 = 5609630039694 := by decide
theorem cert_e1211583528590 : check e1211583528590 [[],[],[],[]] .three = true := by decide
def e1211583528646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211583528646 : Closed e1211583528646 ∧ code e1211583528646 = 5609630039750 := by decide
theorem cert_e1211583528646 : check e1211583528646 [[],[],[],[]] .three = true := by decide
def e1211583528670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 3)))))))))
theorem wire_e1211583528670 : Closed e1211583528670 ∧ code e1211583528670 = 5609630039774 := by decide
theorem cert_e1211583528670 : check e1211583528670 [[],[],[],[]] .three = true := by decide
def e1211583528694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 1)))))))))
theorem wire_e1211583528694 : Closed e1211583528694 ∧ code e1211583528694 = 5609630039798 := by decide
private def t_e1211583528694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 1)))))))))
theorem cert_e1211583528694 : ¬ IsSelfInterpreter e1211583528694 :=
  wSource (t := t_e1211583528694) (replay_sound (ps := []) (t := e1211583528694) (by decide)) (by decide)
def e1211583534814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211583534814 : Closed e1211583534814 ∧ code e1211583534814 = 5609630045918 := by decide
theorem cert_e1211583534814 : check e1211583534814 [[],[],[],[]] .three = true := by decide
def e1211583534838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211583534838 : Closed e1211583534838 ∧ code e1211583534838 = 5609630045942 := by decide
theorem cert_e1211583534838 : check e1211583534838 [[],[],[],[]] .three = true := by decide
def e1211583534942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211583534942 : Closed e1211583534942 ∧ code e1211583534942 = 5609630046046 := by decide
theorem cert_e1211583534942 : check e1211583534942 [[],[],[],[]] .three = true := by decide
def e1211583534958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e1211583534958 : Closed e1211583534958 ∧ code e1211583534958 = 5609630046062 := by decide
theorem cert_e1211583534958 : check e1211583534958 [[],[],[],[]] .smaller = true := by decide
def e1211583534966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e1211583534966 : Closed e1211583534966 ∧ code e1211583534966 = 5609630046070 := by decide
theorem cert_e1211583534966 : check e1211583534966 [[],[],[],[]] .smaller = true := by decide
def e1211583534970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211583534970 : Closed e1211583534970 ∧ code e1211583534970 = 5609630046074 := by decide
theorem cert_e1211583534970 : check e1211583534970 [[],[],[],[]] .three = true := by decide
def e1211583535030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e1211583535030 : Closed e1211583535030 ∧ code e1211583535030 = 5609630046134 := by decide
theorem cert_e1211583535030 : check e1211583535030 [[],[],[],[]] .smaller = true := by decide
def e1211583535062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211583535062 : Closed e1211583535062 ∧ code e1211583535062 = 5609630046166 := by decide
theorem cert_e1211583535062 : check e1211583535062 [[],[],[],[]] .three = true := by decide
def e1211583535066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211583535066 : Closed e1211583535066 ∧ code e1211583535066 = 5609630046170 := by decide
theorem cert_e1211583535066 : check e1211583535066 [[],[],[],[]] .three = true := by decide
def e1211583535582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211583535582 : Closed e1211583535582 ∧ code e1211583535582 = 5609630046686 := by decide
theorem cert_e1211583535582 : check e1211583535582 [[],[],[],[]] .three = true := by decide
def e1211583535606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211583535606 : Closed e1211583535606 ∧ code e1211583535606 = 5609630046710 := by decide
theorem cert_e1211583535606 : check e1211583535606 [[],[],[],[]] .three = true := by decide
def e1211583536254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e1211583536254 : Closed e1211583536254 ∧ code e1211583536254 = 5609630047358 := by decide
theorem cert_e1211583536254 : check e1211583536254 [[],[],[],[]] .three = true := by decide
def e1211583536350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211583536350 : Closed e1211583536350 ∧ code e1211583536350 = 5609630047454 := by decide
theorem cert_e1211583536350 : check e1211583536350 [[],[],[],[]] .three = true := by decide
def e1211583536366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211583536366 : Closed e1211583536366 ∧ code e1211583536366 = 5609630047470 := by decide
theorem cert_e1211583536366 : check e1211583536366 [[],[],[],[]] .smaller = true := by decide
def e1211583536374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211583536374 : Closed e1211583536374 ∧ code e1211583536374 = 5609630047478 := by decide
theorem cert_e1211583536374 : check e1211583536374 [[],[],[],[]] .smaller = true := by decide
def e1211583536378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211583536378 : Closed e1211583536378 ∧ code e1211583536378 = 5609630047482 := by decide
theorem cert_e1211583536378 : check e1211583536378 [[],[],[],[]] .three = true := by decide
def e1211583536758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211583536758 : Closed e1211583536758 ∧ code e1211583536758 = 5609630047862 := by decide
theorem cert_e1211583536758 : check e1211583536758 [[],[],[],[]] .smaller = true := by decide
def e1211583536950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211583536950 : Closed e1211583536950 ∧ code e1211583536950 = 5609630048054 := by decide
theorem cert_e1211583536950 : check e1211583536950 [[],[],[],[]] .three = true := by decide
def e1211583536954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211583536954 : Closed e1211583536954 ∧ code e1211583536954 = 5609630048058 := by decide
theorem cert_e1211583536954 : check e1211583536954 [[],[],[],[]] .three = true := by decide
def e1211583537038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e1211583537038 : Closed e1211583537038 ∧ code e1211583537038 = 5609630048142 := by decide
theorem cert_e1211583537038 : check e1211583537038 [[],[],[],[]] .three = true := by decide
def e1211583548254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211583548254 : Closed e1211583548254 ∧ code e1211583548254 = 5609630059358 := by decide
theorem cert_e1211583548254 : check e1211583548254 [[],[],[],[]] .three = true := by decide
def e1211583548270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211583548270 : Closed e1211583548270 ∧ code e1211583548270 = 5609630059374 := by decide
theorem cert_e1211583548270 : check e1211583548270 [[],[],[],[]] .smaller = true := by decide
def e1211583548278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211583548278 : Closed e1211583548278 ∧ code e1211583548278 = 5609630059382 := by decide
theorem cert_e1211583548278 : check e1211583548278 [[],[],[],[]] .smaller = true := by decide
def e1211583548282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211583548282 : Closed e1211583548282 ∧ code e1211583548282 = 5609630059386 := by decide
theorem cert_e1211583548282 : check e1211583548282 [[],[],[],[]] .three = true := by decide
def e1211583548334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211583548334 : Closed e1211583548334 ∧ code e1211583548334 = 5609630059438 := by decide
theorem cert_e1211583548334 : check e1211583548334 [[],[],[],[]] .smaller = true := by decide
def e1211583548346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211583548346 : Closed e1211583548346 ∧ code e1211583548346 = 5609630059450 := by decide
theorem cert_e1211583548346 : check e1211583548346 [[],[],[],[]] .smaller = true := by decide
def e1211583548374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211583548374 : Closed e1211583548374 ∧ code e1211583548374 = 5609630059478 := by decide
theorem cert_e1211583548374 : check e1211583548374 [[],[],[],[]] .smaller = true := by decide
def e1211583548378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211583548378 : Closed e1211583548378 ∧ code e1211583548378 = 5609630059482 := by decide
theorem cert_e1211583548378 : check e1211583548378 [[],[],[],[]] .smaller = true := by decide
def e1211583548394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211583548394 : Closed e1211583548394 ∧ code e1211583548394 = 5609630059498 := by decide
theorem cert_e1211583548394 : check e1211583548394 [[],[],[],[]] .three = true := by decide
def e1211583548542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e1211583548542 : Closed e1211583548542 ∧ code e1211583548542 = 5609630059646 := by decide
theorem cert_e1211583548542 : check e1211583548542 [[],[],[],[]] .three = true := by decide
def e1211583548638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211583548638 : Closed e1211583548638 ∧ code e1211583548638 = 5609630059742 := by decide
theorem cert_e1211583548638 : check e1211583548638 [[],[],[],[]] .three = true := by decide
def e1211583548654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211583548654 : Closed e1211583548654 ∧ code e1211583548654 = 5609630059758 := by decide
theorem cert_e1211583548654 : check e1211583548654 [[],[],[],[]] .smaller = true := by decide
end Blc.Floor42
