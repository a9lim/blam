import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1204487457750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204487457750 : Closed e1204487457750 ∧ code e1204487457750 = 5602533968854 := by decide
theorem cert_e1204487457750 : check e1204487457750 [[],[],[]] .smaller = true := by decide
def e1204487457754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204487457754 : Closed e1204487457754 ∧ code e1204487457754 = 5602533968858 := by decide
theorem cert_e1204487457754 : check e1204487457754 [[],[],[]] .smaller = true := by decide
def e1204487458030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204487458030 : Closed e1204487458030 ∧ code e1204487458030 = 5602533969134 := by decide
theorem cert_e1204487458030 : check e1204487458030 [[],[],[]] .smaller = true := by decide
def e1204487458038 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204487458038 : Closed e1204487458038 ∧ code e1204487458038 = 5602533969142 := by decide
theorem cert_e1204487458038 : check e1204487458038 [[],[],[]] .smaller = true := by decide
def e1204487458414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204487458414 : Closed e1204487458414 ∧ code e1204487458414 = 5602533969518 := by decide
theorem cert_e1204487458414 : check e1204487458414 [[],[],[]] .smaller = true := by decide
def e1204487458426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204487458426 : Closed e1204487458426 ∧ code e1204487458426 = 5602533969530 := by decide
theorem cert_e1204487458426 : check e1204487458426 [[],[],[]] .smaller = true := by decide
def e1204487458614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204487458614 : Closed e1204487458614 ∧ code e1204487458614 = 5602533969718 := by decide
theorem cert_e1204487458614 : check e1204487458614 [[],[],[]] .smaller = true := by decide
def e1204487458618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204487458618 : Closed e1204487458618 ∧ code e1204487458618 = 5602533969722 := by decide
theorem cert_e1204487458618 : check e1204487458618 [[],[],[]] .smaller = true := by decide
def e1204520971802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204520971802 : Closed e1204520971802 ∧ code e1204520971802 = 5602567482906 := by decide
private def t_e1204520971802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204520971802 : ¬ IsSelfInterpreter e1204520971802 :=
  wSource (t := t_e1204520971802) (replay_sound (ps := []) (t := e1204520971802) (by decide)) (by decide)
def e1204520973850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204520973850 : Closed e1204520973850 ∧ code e1204520973850 = 5602567484954 := by decide
private def t_e1204520973850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204520973850 : ¬ IsSelfInterpreter e1204520973850 :=
  wSource (t := t_e1204520973850) (replay_sound (ps := []) (t := e1204520973850) (by decide)) (by decide)
def e1204520988186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204520988186 : Closed e1204520988186 ∧ code e1204520988186 = 5602567499290 := by decide
private def t_e1204520988186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204520988186 : ¬ IsSelfInterpreter e1204520988186 :=
  wSource (t := t_e1204520988186) (replay_sound (ps := []) (t := e1204520988186) (by decide)) (by decide)
def e1204520991258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204520991258 : Closed e1204520991258 ∧ code e1204520991258 = 5602567502362 := by decide
private def t_e1204520991258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204520991258 : ¬ IsSelfInterpreter e1204520991258 :=
  wSource (t := t_e1204520991258) (replay_sound (ps := []) (t := e1204520991258) (by decide)) (by decide)
def e1204520998426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204520998426 : Closed e1204520998426 ∧ code e1204520998426 = 5602567509530 := by decide
private def t_e1204520998426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204520998426 : ¬ IsSelfInterpreter e1204520998426 :=
  wSource (t := t_e1204520998426) (replay_sound (ps := []) (t := e1204520998426) (by decide)) (by decide)
def e1204520999450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204520999450 : Closed e1204520999450 ∧ code e1204520999450 = 5602567510554 := by decide
private def t_e1204520999450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204520999450 : ¬ IsSelfInterpreter e1204520999450 :=
  wSource (t := t_e1204520999450) (replay_sound (ps := []) (t := e1204520999450) (by decide)) (by decide)
def e1204521070106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204521070106 : Closed e1204521070106 ∧ code e1204521070106 = 5602567581210 := by decide
private def t_e1204521070106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204521070106 : ¬ IsSelfInterpreter e1204521070106 :=
  wSource (t := t_e1204521070106) (replay_sound (ps := []) (t := e1204521070106) (by decide)) (by decide)
def e1204521072154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204521072154 : Closed e1204521072154 ∧ code e1204521072154 = 5602567583258 := by decide
private def t_e1204521072154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204521072154 : ¬ IsSelfInterpreter e1204521072154 :=
  wSource (t := t_e1204521072154) (replay_sound (ps := []) (t := e1204521072154) (by decide)) (by decide)
def e1204521168410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204521168410 : Closed e1204521168410 ∧ code e1204521168410 = 5602567679514 := by decide
private def t_e1204521168410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204521168410 : ¬ IsSelfInterpreter e1204521168410 :=
  wSource (t := t_e1204521168410) (replay_sound (ps := []) (t := e1204521168410) (by decide)) (by decide)
def e1204521171482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204521171482 : Closed e1204521171482 ∧ code e1204521171482 = 5602567682586 := by decide
private def t_e1204521171482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204521171482 : ¬ IsSelfInterpreter e1204521171482 :=
  wSource (t := t_e1204521171482) (replay_sound (ps := []) (t := e1204521171482) (by decide)) (by decide)
def e1204521219610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204521219610 : Closed e1204521219610 ∧ code e1204521219610 = 5602567730714 := by decide
private def t_e1204521219610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204521219610 : ¬ IsSelfInterpreter e1204521219610 :=
  wSource (t := t_e1204521219610) (replay_sound (ps := []) (t := e1204521219610) (by decide)) (by decide)
def e1204521220634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1204521220634 : Closed e1204521220634 ∧ code e1204521220634 = 5602567731738 := by decide
private def t_e1204521220634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1204521220634 : ¬ IsSelfInterpreter e1204521220634 :=
  wSource (t := t_e1204521220634) (replay_sound (ps := []) (t := e1204521220634) (by decide)) (by decide)
def e1204537044334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1204537044334 : Closed e1204537044334 ∧ code e1204537044334 = 5602583555438 := by decide
theorem cert_e1204537044334 : check e1204537044334 [[],[]] .smaller = true := by decide
def e1204537044342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1204537044342 : Closed e1204537044342 ∧ code e1204537044342 = 5602583555446 := by decide
theorem cert_e1204537044342 : check e1204537044342 [[],[]] .smaller = true := by decide
def e1204537044398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1204537044398 : Closed e1204537044398 ∧ code e1204537044398 = 5602583555502 := by decide
theorem cert_e1204537044398 : check e1204537044398 [[],[]] .smaller = true := by decide
def e1204537044410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1204537044410 : Closed e1204537044410 ∧ code e1204537044410 = 5602583555514 := by decide
theorem cert_e1204537044410 : check e1204537044410 [[],[]] .smaller = true := by decide
def e1204537044438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1204537044438 : Closed e1204537044438 ∧ code e1204537044438 = 5602583555542 := by decide
theorem cert_e1204537044438 : check e1204537044438 [[],[]] .smaller = true := by decide
def e1204537044442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1204537044442 : Closed e1204537044442 ∧ code e1204537044442 = 5602583555546 := by decide
theorem cert_e1204537044442 : check e1204537044442 [[],[]] .smaller = true := by decide
def e1204537044654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1204537044654 : Closed e1204537044654 ∧ code e1204537044654 = 5602583555758 := by decide
theorem cert_e1204537044654 : check e1204537044654 [[],[]] .smaller = true := by decide
def e1204537044666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1204537044666 : Closed e1204537044666 ∧ code e1204537044666 = 5602583555770 := by decide
theorem cert_e1204537044666 : check e1204537044666 [[],[]] .smaller = true := by decide
def e1204537044714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1204537044714 : Closed e1204537044714 ∧ code e1204537044714 = 5602583555818 := by decide
theorem cert_e1204537044714 : check e1204537044714 [[],[]] .smaller = true := by decide
def e1204537044822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1204537044822 : Closed e1204537044822 ∧ code e1204537044822 = 5602583555926 := by decide
theorem cert_e1204537044822 : check e1204537044822 [[],[]] .smaller = true := by decide
def e1204537044826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1204537044826 : Closed e1204537044826 ∧ code e1204537044826 = 5602583555930 := by decide
theorem cert_e1204537044826 : check e1204537044826 [[],[]] .smaller = true := by decide
def e1204537044842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1204537044842 : Closed e1204537044842 ∧ code e1204537044842 = 5602583555946 := by decide
theorem cert_e1204537044842 : check e1204537044842 [[],[]] .smaller = true := by decide
def e1204537045870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1204537045870 : Closed e1204537045870 ∧ code e1204537045870 = 5602583556974 := by decide
theorem cert_e1204537045870 : check e1204537045870 [[],[]] .smaller = true := by decide
def e1204537045878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1204537045878 : Closed e1204537045878 ∧ code e1204537045878 = 5602583556982 := by decide
theorem cert_e1204537045878 : check e1204537045878 [[],[]] .smaller = true := by decide
def e1204537045934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1204537045934 : Closed e1204537045934 ∧ code e1204537045934 = 5602583557038 := by decide
theorem cert_e1204537045934 : check e1204537045934 [[],[]] .smaller = true := by decide
def e1204537045946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1204537045946 : Closed e1204537045946 ∧ code e1204537045946 = 5602583557050 := by decide
theorem cert_e1204537045946 : check e1204537045946 [[],[]] .smaller = true := by decide
def e1204537045974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1204537045974 : Closed e1204537045974 ∧ code e1204537045974 = 5602583557078 := by decide
theorem cert_e1204537045974 : check e1204537045974 [[],[]] .smaller = true := by decide
def e1204537045978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1204537045978 : Closed e1204537045978 ∧ code e1204537045978 = 5602583557082 := by decide
theorem cert_e1204537045978 : check e1204537045978 [[],[]] .smaller = true := by decide
def e1204537046254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1204537046254 : Closed e1204537046254 ∧ code e1204537046254 = 5602583557358 := by decide
theorem cert_e1204537046254 : check e1204537046254 [[],[]] .smaller = true := by decide
def e1204537046262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1204537046262 : Closed e1204537046262 ∧ code e1204537046262 = 5602583557366 := by decide
theorem cert_e1204537046262 : check e1204537046262 [[],[]] .smaller = true := by decide
def e1204537046638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1204537046638 : Closed e1204537046638 ∧ code e1204537046638 = 5602583557742 := by decide
theorem cert_e1204537046638 : check e1204537046638 [[],[]] .smaller = true := by decide
def e1204537046650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1204537046650 : Closed e1204537046650 ∧ code e1204537046650 = 5602583557754 := by decide
theorem cert_e1204537046650 : check e1204537046650 [[],[]] .smaller = true := by decide
def e1204537046838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1204537046838 : Closed e1204537046838 ∧ code e1204537046838 = 5602583557942 := by decide
theorem cert_e1204537046838 : check e1204537046838 [[],[]] .smaller = true := by decide
def e1204537046842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1204537046842 : Closed e1204537046842 ∧ code e1204537046842 = 5602583557946 := by decide
theorem cert_e1204537046842 : check e1204537046842 [[],[]] .smaller = true := by decide
def e1204537047470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1204537047470 : Closed e1204537047470 ∧ code e1204537047470 = 5602583558574 := by decide
theorem cert_e1204537047470 : check e1204537047470 [[],[]] .smaller = true := by decide
def e1204537047482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1204537047482 : Closed e1204537047482 ∧ code e1204537047482 = 5602583558586 := by decide
theorem cert_e1204537047482 : check e1204537047482 [[],[]] .smaller = true := by decide
def e1204537047530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1204537047530 : Closed e1204537047530 ∧ code e1204537047530 = 5602583558634 := by decide
theorem cert_e1204537047530 : check e1204537047530 [[],[]] .smaller = true := by decide
def e1204537047662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1204537047662 : Closed e1204537047662 ∧ code e1204537047662 = 5602583558766 := by decide
theorem cert_e1204537047662 : check e1204537047662 [[],[]] .smaller = true := by decide
def e1204537047674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1204537047674 : Closed e1204537047674 ∧ code e1204537047674 = 5602583558778 := by decide
theorem cert_e1204537047674 : check e1204537047674 [[],[]] .smaller = true := by decide
def e1204537047962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1204537047962 : Closed e1204537047962 ∧ code e1204537047962 = 5602583559066 := by decide
theorem cert_e1204537047962 : check e1204537047962 [[],[]] .smaller = true := by decide
def e1204537048278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1204537048278 : Closed e1204537048278 ∧ code e1204537048278 = 5602583559382 := by decide
theorem cert_e1204537048278 : check e1204537048278 [[],[]] .smaller = true := by decide
def e1204537048282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1204537048282 : Closed e1204537048282 ∧ code e1204537048282 = 5602583559386 := by decide
theorem cert_e1204537048282 : check e1204537048282 [[],[]] .smaller = true := by decide
def e1204537048298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1204537048298 : Closed e1204537048298 ∧ code e1204537048298 = 5602583559402 := by decide
theorem cert_e1204537048298 : check e1204537048298 [[],[]] .smaller = true := by decide
def e1204537048374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1204537048374 : Closed e1204537048374 ∧ code e1204537048374 = 5602583559478 := by decide
theorem cert_e1204537048374 : check e1204537048374 [[],[]] .smaller = true := by decide
def e1204537048378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1204537048378 : Closed e1204537048378 ∧ code e1204537048378 = 5602583559482 := by decide
theorem cert_e1204537048378 : check e1204537048378 [[],[]] .smaller = true := by decide
def e1204537048474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1204537048474 : Closed e1204537048474 ∧ code e1204537048474 = 5602583559578 := by decide
theorem cert_e1204537048474 : check e1204537048474 [[],[]] .smaller = true := by decide
def e1204537052014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1204537052014 : Closed e1204537052014 ∧ code e1204537052014 = 5602583563118 := by decide
theorem cert_e1204537052014 : check e1204537052014 [[],[]] .smaller = true := by decide
def e1204537052022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1204537052022 : Closed e1204537052022 ∧ code e1204537052022 = 5602583563126 := by decide
theorem cert_e1204537052022 : check e1204537052022 [[],[]] .smaller = true := by decide
def e1204537052078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1204537052078 : Closed e1204537052078 ∧ code e1204537052078 = 5602583563182 := by decide
theorem cert_e1204537052078 : check e1204537052078 [[],[]] .smaller = true := by decide
def e1204537052090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1204537052090 : Closed e1204537052090 ∧ code e1204537052090 = 5602583563194 := by decide
theorem cert_e1204537052090 : check e1204537052090 [[],[]] .smaller = true := by decide
def e1204537052118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1204537052118 : Closed e1204537052118 ∧ code e1204537052118 = 5602583563222 := by decide
theorem cert_e1204537052118 : check e1204537052118 [[],[]] .smaller = true := by decide
def e1204537052122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1204537052122 : Closed e1204537052122 ∧ code e1204537052122 = 5602583563226 := by decide
theorem cert_e1204537052122 : check e1204537052122 [[],[]] .smaller = true := by decide
def e1204537052398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1204537052398 : Closed e1204537052398 ∧ code e1204537052398 = 5602583563502 := by decide
theorem cert_e1204537052398 : check e1204537052398 [[],[]] .smaller = true := by decide
def e1204537052406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1204537052406 : Closed e1204537052406 ∧ code e1204537052406 = 5602583563510 := by decide
theorem cert_e1204537052406 : check e1204537052406 [[],[]] .smaller = true := by decide
def e1204537052782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204537052782 : Closed e1204537052782 ∧ code e1204537052782 = 5602583563886 := by decide
theorem cert_e1204537052782 : check e1204537052782 [[],[]] .smaller = true := by decide
def e1204537052794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204537052794 : Closed e1204537052794 ∧ code e1204537052794 = 5602583563898 := by decide
theorem cert_e1204537052794 : check e1204537052794 [[],[]] .smaller = true := by decide
def e1204537052982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204537052982 : Closed e1204537052982 ∧ code e1204537052982 = 5602583564086 := by decide
theorem cert_e1204537052982 : check e1204537052982 [[],[]] .smaller = true := by decide
def e1204537052986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204537052986 : Closed e1204537052986 ∧ code e1204537052986 = 5602583564090 := by decide
theorem cert_e1204537052986 : check e1204537052986 [[],[]] .smaller = true := by decide
def e1204537058734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1204537058734 : Closed e1204537058734 ∧ code e1204537058734 = 5602583569838 := by decide
theorem cert_e1204537058734 : check e1204537058734 [[],[]] .smaller = true := by decide
def e1204537058746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1204537058746 : Closed e1204537058746 ∧ code e1204537058746 = 5602583569850 := by decide
theorem cert_e1204537058746 : check e1204537058746 [[],[]] .smaller = true := by decide
def e1204537058794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1204537058794 : Closed e1204537058794 ∧ code e1204537058794 = 5602583569898 := by decide
theorem cert_e1204537058794 : check e1204537058794 [[],[]] .smaller = true := by decide
def e1204537058926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204537058926 : Closed e1204537058926 ∧ code e1204537058926 = 5602583570030 := by decide
theorem cert_e1204537058926 : check e1204537058926 [[],[]] .smaller = true := by decide
def e1204537058938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204537058938 : Closed e1204537058938 ∧ code e1204537058938 = 5602583570042 := by decide
theorem cert_e1204537058938 : check e1204537058938 [[],[]] .smaller = true := by decide
def e1204537059226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1204537059226 : Closed e1204537059226 ∧ code e1204537059226 = 5602583570330 := by decide
theorem cert_e1204537059226 : check e1204537059226 [[],[]] .smaller = true := by decide
def e1204537062102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1204537062102 : Closed e1204537062102 ∧ code e1204537062102 = 5602583573206 := by decide
theorem cert_e1204537062102 : check e1204537062102 [[],[]] .smaller = true := by decide
def e1204537062106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1204537062106 : Closed e1204537062106 ∧ code e1204537062106 = 5602583573210 := by decide
theorem cert_e1204537062106 : check e1204537062106 [[],[]] .smaller = true := by decide
def e1204537062122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1204537062122 : Closed e1204537062122 ∧ code e1204537062122 = 5602583573226 := by decide
theorem cert_e1204537062122 : check e1204537062122 [[],[]] .smaller = true := by decide
def e1204537062198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204537062198 : Closed e1204537062198 ∧ code e1204537062198 = 5602583573302 := by decide
theorem cert_e1204537062198 : check e1204537062198 [[],[]] .smaller = true := by decide
def e1204537062202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204537062202 : Closed e1204537062202 ∧ code e1204537062202 = 5602583573306 := by decide
theorem cert_e1204537062202 : check e1204537062202 [[],[]] .smaller = true := by decide
def e1204537062298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1204537062298 : Closed e1204537062298 ∧ code e1204537062298 = 5602583573402 := by decide
theorem cert_e1204537062298 : check e1204537062298 [[],[]] .smaller = true := by decide
def e1204537177838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1204537177838 : Closed e1204537177838 ∧ code e1204537177838 = 5602583688942 := by decide
theorem cert_e1204537177838 : check e1204537177838 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1204537177966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1204537177966 : Closed e1204537177966 ∧ code e1204537177966 = 5602583689070 := by decide
theorem cert_e1204537177966 : check e1204537177966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1204537177974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1204537177974 : Closed e1204537177974 ∧ code e1204537177974 = 5602583689078 := by decide
theorem cert_e1204537177974 : check e1204537177974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204537178862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1204537178862 : Closed e1204537178862 ∧ code e1204537178862 = 5602583689966 := by decide
theorem cert_e1204537178862 : check e1204537178862 [[],[]] .sourceHead = true := by decide
def e1204537179054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1204537179054 : Closed e1204537179054 ∧ code e1204537179054 = 5602583690158 := by decide
theorem cert_e1204537179054 : check e1204537179054 [[],[]] .sourceHead = true := by decide
def e1204537179066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1204537179066 : Closed e1204537179066 ∧ code e1204537179066 = 5602583690170 := by decide
theorem cert_e1204537179066 : check e1204537179066 [[],[]] .sourceHead = true := by decide
def e1204537179502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1204537179502 : Closed e1204537179502 ∧ code e1204537179502 = 5602583690606 := by decide
theorem cert_e1204537179502 : check e1204537179502 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204537179510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1204537179510 : Closed e1204537179510 ∧ code e1204537179510 = 5602583690614 := by decide
theorem cert_e1204537179510 : check e1204537179510 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204537179566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1204537179566 : Closed e1204537179566 ∧ code e1204537179566 = 5602583690670 := by decide
theorem cert_e1204537179566 : check e1204537179566 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204537179578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1204537179578 : Closed e1204537179578 ∧ code e1204537179578 = 5602583690682 := by decide
theorem cert_e1204537179578 : check e1204537179578 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1204537179606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1204537179606 : Closed e1204537179606 ∧ code e1204537179606 = 5602583690710 := by decide
private def t_e1204537179606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e1204537179606 : ¬ IsSelfInterpreter e1204537179606 :=
  wSource (t := t_e1204537179606) (replay_sound (ps := []) (t := e1204537179606) (by decide)) (by decide)
def e1204537179610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1204537179610 : Closed e1204537179610 ∧ code e1204537179610 = 5602583690714 := by decide
private def t_e1204537179610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e1204537179610 : ¬ IsSelfInterpreter e1204537179610 :=
  wSource (t := t_e1204537179610) (replay_sound (ps := []) (t := e1204537179610) (by decide)) (by decide)
def e1204537183982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1204537183982 : Closed e1204537183982 ∧ code e1204537183982 = 5602583695086 := by decide
theorem cert_e1204537183982 : check e1204537183982 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204537184110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1204537184110 : Closed e1204537184110 ∧ code e1204537184110 = 5602583695214 := by decide
theorem cert_e1204537184110 : check e1204537184110 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e1204537184118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1204537184118 : Closed e1204537184118 ∧ code e1204537184118 = 5602583695222 := by decide
theorem cert_e1204537184118 : check e1204537184118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1204537186798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1204537186798 : Closed e1204537186798 ∧ code e1204537186798 = 5602583697902 := by decide
theorem cert_e1204537186798 : check e1204537186798 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1204537187566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204537187566 : Closed e1204537187566 ∧ code e1204537187566 = 5602583698670 := by decide
theorem cert_e1204537187566 : check e1204537187566 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204537187574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204537187574 : Closed e1204537187574 ∧ code e1204537187574 = 5602583698678 := by decide
theorem cert_e1204537187574 : check e1204537187574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1204537190126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1204537190126 : Closed e1204537190126 ∧ code e1204537190126 = 5602583701230 := by decide
theorem cert_e1204537190126 : checkPay e1204537190126 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e1204537190318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1204537190318 : Closed e1204537190318 ∧ code e1204537190318 = 5602583701422 := by decide
theorem cert_e1204537190318 : checkPay e1204537190318 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.under,.under,.left,.right]] = true := by decide
def e1204537190330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1204537190330 : Closed e1204537190330 ∧ code e1204537190330 = 5602583701434 := by decide
theorem cert_e1204537190330 : checkPay e1204537190330 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1204537190894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1204537190894 : Closed e1204537190894 ∧ code e1204537190894 = 5602583701998 := by decide
theorem cert_e1204537190894 : checkPay e1204537190894 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1204537192046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204537192046 : Closed e1204537192046 ∧ code e1204537192046 = 5602583703150 := by decide
theorem cert_e1204537192046 : checkPay e1204537192046 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1204537192058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204537192058 : Closed e1204537192058 ∧ code e1204537192058 = 5602583703162 := by decide
theorem cert_e1204537192058 : checkPay e1204537192058 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1204537193326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1204537193326 : Closed e1204537193326 ∧ code e1204537193326 = 5602583704430 := by decide
theorem cert_e1204537193326 : check e1204537193326 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204537193334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1204537193334 : Closed e1204537193334 ∧ code e1204537193334 = 5602583704438 := by decide
theorem cert_e1204537193334 : check e1204537193334 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1204537193390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1204537193390 : Closed e1204537193390 ∧ code e1204537193390 = 5602583704494 := by decide
theorem cert_e1204537193390 : check e1204537193390 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204537193402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1204537193402 : Closed e1204537193402 ∧ code e1204537193402 = 5602583704506 := by decide
theorem cert_e1204537193402 : check e1204537193402 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1204537193430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1204537193430 : Closed e1204537193430 ∧ code e1204537193430 = 5602583704534 := by decide
theorem cert_e1204537193430 : check e1204537193430 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1204537193434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1204537193434 : Closed e1204537193434 ∧ code e1204537193434 = 5602583704538 := by decide
theorem cert_e1204537193434 : check e1204537193434 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1204537193710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1204537193710 : Closed e1204537193710 ∧ code e1204537193710 = 5602583704814 := by decide
theorem cert_e1204537193710 : check e1204537193710 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204537193718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1204537193718 : Closed e1204537193718 ∧ code e1204537193718 = 5602583704822 := by decide
theorem cert_e1204537193718 : check e1204537193718 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204537194094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1204537194094 : Closed e1204537194094 ∧ code e1204537194094 = 5602583705198 := by decide
theorem cert_e1204537194094 : check e1204537194094 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204537194106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1204537194106 : Closed e1204537194106 ∧ code e1204537194106 = 5602583705210 := by decide
theorem cert_e1204537194106 : check e1204537194106 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1204537194294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1204537194294 : Closed e1204537194294 ∧ code e1204537194294 = 5602583705398 := by decide
private def t_e1204537194294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e1204537194294 : ¬ IsSelfInterpreter e1204537194294 :=
  wSource (t := t_e1204537194294) (replay_sound (ps := []) (t := e1204537194294) (by decide)) (by decide)
def e1204537194298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1204537194298 : Closed e1204537194298 ∧ code e1204537194298 = 5602583705402 := by decide
private def t_e1204537194298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e1204537194298 : ¬ IsSelfInterpreter e1204537194298 :=
  wSource (t := t_e1204537194298) (replay_sound (ps := []) (t := e1204537194298) (by decide)) (by decide)
def e1204537199470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1204537199470 : Closed e1204537199470 ∧ code e1204537199470 = 5602583710574 := by decide
theorem cert_e1204537199470 : check e1204537199470 [[],[]] .smaller = true := by decide
def e1204537199478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1204537199478 : Closed e1204537199478 ∧ code e1204537199478 = 5602583710582 := by decide
theorem cert_e1204537199478 : check e1204537199478 [[],[]] .smaller = true := by decide
def e1204537199534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1204537199534 : Closed e1204537199534 ∧ code e1204537199534 = 5602583710638 := by decide
theorem cert_e1204537199534 : check e1204537199534 [[],[]] .smaller = true := by decide
def e1204537199546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1204537199546 : Closed e1204537199546 ∧ code e1204537199546 = 5602583710650 := by decide
theorem cert_e1204537199546 : check e1204537199546 [[],[]] .smaller = true := by decide
def e1204537199574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1204537199574 : Closed e1204537199574 ∧ code e1204537199574 = 5602583710678 := by decide
theorem cert_e1204537199574 : check e1204537199574 [[],[]] .smaller = true := by decide
def e1204537199578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1204537199578 : Closed e1204537199578 ∧ code e1204537199578 = 5602583710682 := by decide
theorem cert_e1204537199578 : check e1204537199578 [[],[]] .smaller = true := by decide
def e1204537199854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1204537199854 : Closed e1204537199854 ∧ code e1204537199854 = 5602583710958 := by decide
theorem cert_e1204537199854 : check e1204537199854 [[],[]] .smaller = true := by decide
def e1204537199862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1204537199862 : Closed e1204537199862 ∧ code e1204537199862 = 5602583710966 := by decide
theorem cert_e1204537199862 : check e1204537199862 [[],[]] .smaller = true := by decide
def e1204537200238 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1204537200238 : Closed e1204537200238 ∧ code e1204537200238 = 5602583711342 := by decide
theorem cert_e1204537200238 : check e1204537200238 [[],[]] .smaller = true := by decide
def e1204537200250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1204537200250 : Closed e1204537200250 ∧ code e1204537200250 = 5602583711354 := by decide
theorem cert_e1204537200250 : check e1204537200250 [[],[]] .smaller = true := by decide
def e1204537200438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1204537200438 : Closed e1204537200438 ∧ code e1204537200438 = 5602583711542 := by decide
theorem cert_e1204537200438 : check e1204537200438 [[],[]] .smaller = true := by decide
def e1204537200442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1204537200442 : Closed e1204537200442 ∧ code e1204537200442 = 5602583711546 := by decide
theorem cert_e1204537200442 : check e1204537200442 [[],[]] .smaller = true := by decide
def e1204537208558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1204537208558 : Closed e1204537208558 ∧ code e1204537208558 = 5602583719662 := by decide
theorem cert_e1204537208558 : check e1204537208558 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204537208686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1204537208686 : Closed e1204537208686 ∧ code e1204537208686 = 5602583719790 := by decide
theorem cert_e1204537208686 : checkPay e1204537208686 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e1204537208694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1204537208694 : Closed e1204537208694 ∧ code e1204537208694 = 5602583719798 := by decide
theorem cert_e1204537208694 : check e1204537208694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1204537211374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1204537211374 : Closed e1204537211374 ∧ code e1204537211374 = 5602583722478 := by decide
theorem cert_e1204537211374 : check e1204537211374 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204537212142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1204537212142 : Closed e1204537212142 ∧ code e1204537212142 = 5602583723246 := by decide
theorem cert_e1204537212142 : check e1204537212142 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1204537212150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1204537212150 : Closed e1204537212150 ∧ code e1204537212150 = 5602583723254 := by decide
theorem cert_e1204537212150 : check e1204537212150 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1204537235182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1204537235182 : Closed e1204537235182 ∧ code e1204537235182 = 5602583746286 := by decide
theorem cert_e1204537235182 : check e1204537235182 [[],[]] .sourceHead = true := by decide
def e1204537235374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1204537235374 : Closed e1204537235374 ∧ code e1204537235374 = 5602583746478 := by decide
theorem cert_e1204537235374 : check e1204537235374 [[],[]] .sourceHead = true := by decide
def e1204537235386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1204537235386 : Closed e1204537235386 ∧ code e1204537235386 = 5602583746490 := by decide
theorem cert_e1204537235386 : check e1204537235386 [[],[]] .sourceHead = true := by decide
def e1204537235950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1204537235950 : Closed e1204537235950 ∧ code e1204537235950 = 5602583747054 := by decide
theorem cert_e1204537235950 : check e1204537235950 [[],[]] .sourceHead = true := by decide
def e1204537237102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1204537237102 : Closed e1204537237102 ∧ code e1204537237102 = 5602583748206 := by decide
theorem cert_e1204537237102 : check e1204537237102 [[],[]] .sourceHead = true := by decide
def e1204537237114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1204537237114 : Closed e1204537237114 ∧ code e1204537237114 = 5602583748218 := by decide
theorem cert_e1204537237114 : check e1204537237114 [[],[]] .sourceHead = true := by decide
def e1204537248622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1204537248622 : Closed e1204537248622 ∧ code e1204537248622 = 5602583759726 := by decide
theorem cert_e1204537248622 : check e1204537248622 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537248630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1204537248630 : Closed e1204537248630 ∧ code e1204537248630 = 5602583759734 := by decide
theorem cert_e1204537248630 : check e1204537248630 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537248686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1204537248686 : Closed e1204537248686 ∧ code e1204537248686 = 5602583759790 := by decide
theorem cert_e1204537248686 : check e1204537248686 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537248698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1204537248698 : Closed e1204537248698 ∧ code e1204537248698 = 5602583759802 := by decide
theorem cert_e1204537248698 : check e1204537248698 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537248726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1204537248726 : Closed e1204537248726 ∧ code e1204537248726 = 5602583759830 := by decide
theorem cert_e1204537248726 : check e1204537248726 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537248730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1204537248730 : Closed e1204537248730 ∧ code e1204537248730 = 5602583759834 := by decide
theorem cert_e1204537248730 : check e1204537248730 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537249006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1204537249006 : Closed e1204537249006 ∧ code e1204537249006 = 5602583760110 := by decide
theorem cert_e1204537249006 : check e1204537249006 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537249014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1204537249014 : Closed e1204537249014 ∧ code e1204537249014 = 5602583760118 := by decide
theorem cert_e1204537249014 : check e1204537249014 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537249390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1204537249390 : Closed e1204537249390 ∧ code e1204537249390 = 5602583760494 := by decide
theorem cert_e1204537249390 : check e1204537249390 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537249402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1204537249402 : Closed e1204537249402 ∧ code e1204537249402 = 5602583760506 := by decide
theorem cert_e1204537249402 : check e1204537249402 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537249590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1204537249590 : Closed e1204537249590 ∧ code e1204537249590 = 5602583760694 := by decide
theorem cert_e1204537249590 : check e1204537249590 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537249594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1204537249594 : Closed e1204537249594 ∧ code e1204537249594 = 5602583760698 := by decide
theorem cert_e1204537249594 : check e1204537249594 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e1204537789294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1204537789294 : Closed e1204537789294 ∧ code e1204537789294 = 5602584300398 := by decide
theorem cert_e1204537789294 : check e1204537789294 [[],[]] .smaller = true := by decide
def e1204537789302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1204537789302 : Closed e1204537789302 ∧ code e1204537789302 = 5602584300406 := by decide
theorem cert_e1204537789302 : check e1204537789302 [[],[]] .smaller = true := by decide
def e1204537789358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1204537789358 : Closed e1204537789358 ∧ code e1204537789358 = 5602584300462 := by decide
theorem cert_e1204537789358 : check e1204537789358 [[],[]] .smaller = true := by decide
def e1204537789370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1204537789370 : Closed e1204537789370 ∧ code e1204537789370 = 5602584300474 := by decide
theorem cert_e1204537789370 : check e1204537789370 [[],[]] .smaller = true := by decide
def e1204537789398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1204537789398 : Closed e1204537789398 ∧ code e1204537789398 = 5602584300502 := by decide
theorem cert_e1204537789398 : check e1204537789398 [[],[]] .smaller = true := by decide
def e1204537789402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1204537789402 : Closed e1204537789402 ∧ code e1204537789402 = 5602584300506 := by decide
theorem cert_e1204537789402 : check e1204537789402 [[],[]] .smaller = true := by decide
def e1204537789678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1204537789678 : Closed e1204537789678 ∧ code e1204537789678 = 5602584300782 := by decide
theorem cert_e1204537789678 : check e1204537789678 [[],[]] .smaller = true := by decide
def e1204537789686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1204537789686 : Closed e1204537789686 ∧ code e1204537789686 = 5602584300790 := by decide
theorem cert_e1204537789686 : check e1204537789686 [[],[]] .smaller = true := by decide
end Blc.Floor42
