import R1209577550766Data
namespace Certgen.R1209577550766
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl936 : FloorIndex.rangeOK validState 936 12 = true := by decide +kernel
theorem bl948 : FloorIndex.rangeOK validState 948 12 = true := by decide +kernel
theorem bl960 : FloorIndex.rangeOK validState 960 12 = true := by decide +kernel
theorem bl972 : FloorIndex.rangeOK validState 972 12 = true := by decide +kernel
theorem bl984 : FloorIndex.rangeOK validState 984 12 = true := by decide +kernel
theorem bl996 : FloorIndex.rangeOK validState 996 12 = true := by decide +kernel
end Certgen.R1209577550766
