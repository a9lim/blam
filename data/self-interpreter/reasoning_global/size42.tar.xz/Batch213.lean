import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211207349946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211207349946 : Closed e1211207349946 ∧ code e1211207349946 = 5609253861050 := by decide
theorem cert_e1211207349946 : check e1211207349946 [[],[]] .chain = true := by decide
def e1211207349994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211207349994 : Closed e1211207349994 ∧ code e1211207349994 = 5609253861098 := by decide
theorem cert_e1211207349994 : check e1211207349994 [[],[]] .chain = true := by decide
def e1211207350102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211207350102 : Closed e1211207350102 ∧ code e1211207350102 = 5609253861206 := by decide
theorem cert_e1211207350102 : check e1211207350102 [[],[]] .chain = true := by decide
def e1211207350106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211207350106 : Closed e1211207350106 ∧ code e1211207350106 = 5609253861210 := by decide
theorem cert_e1211207350106 : check e1211207350106 [[],[]] .chain = true := by decide
def e1211207350122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211207350122 : Closed e1211207350122 ∧ code e1211207350122 = 5609253861226 := by decide
theorem cert_e1211207350122 : check e1211207350122 [[],[]] .chain = true := by decide
def e1211207350966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211207350966 : Closed e1211207350966 ∧ code e1211207350966 = 5609253862070 := by decide
theorem cert_e1211207350966 : check e1211207350966 [[],[]] .chain = true := by decide
def e1211207350998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211207350998 : Closed e1211207350998 ∧ code e1211207350998 = 5609253862102 := by decide
theorem cert_e1211207350998 : check e1211207350998 [[],[]] .chain = true := by decide
def e1211207351002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211207351002 : Closed e1211207351002 ∧ code e1211207351002 = 5609253862106 := by decide
theorem cert_e1211207351002 : check e1211207351002 [[],[]] .chain = true := by decide
def e1211207351126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211207351126 : Closed e1211207351126 ∧ code e1211207351126 = 5609253862230 := by decide
theorem cert_e1211207351126 : check e1211207351126 [[],[]] .chain = true := by decide
def e1211207351130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211207351130 : Closed e1211207351130 ∧ code e1211207351130 = 5609253862234 := by decide
theorem cert_e1211207351130 : check e1211207351130 [[],[]] .chain = true := by decide
def e1211207351146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211207351146 : Closed e1211207351146 ∧ code e1211207351146 = 5609253862250 := by decide
theorem cert_e1211207351146 : check e1211207351146 [[],[]] .chain = true := by decide
def e1211207353198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e1211207353198 : Closed e1211207353198 ∧ code e1211207353198 = 5609253864302 := by decide
theorem cert_e1211207353198 : check e1211207353198 [[],[]] .chain = true := by decide
def e1211207353206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e1211207353206 : Closed e1211207353206 ∧ code e1211207353206 = 5609253864310 := by decide
theorem cert_e1211207353206 : check e1211207353206 [[],[]] .chain = true := by decide
def e1211207354606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211207354606 : Closed e1211207354606 ∧ code e1211207354606 = 5609253865710 := by decide
theorem cert_e1211207354606 : check e1211207354606 [[],[]] .chain = true := by decide
def e1211207354614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211207354614 : Closed e1211207354614 ∧ code e1211207354614 = 5609253865718 := by decide
theorem cert_e1211207354614 : check e1211207354614 [[],[]] .chain = true := by decide
def e1211207355166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211207355166 : Closed e1211207355166 ∧ code e1211207355166 = 5609253866270 := by decide
theorem cert_e1211207355166 : check e1211207355166 [[],[]] .chain = true := by decide
def e1211207355278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211207355278 : Closed e1211207355278 ∧ code e1211207355278 = 5609253866382 := by decide
theorem cert_e1211207355278 : check e1211207355278 [[],[]] .chain = true := by decide
def e1211207355950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211207355950 : Closed e1211207355950 ∧ code e1211207355950 = 5609253867054 := by decide
theorem cert_e1211207355950 : check e1211207355950 [[],[]] .chain = true := by decide
def e1211207356130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211207356130 : Closed e1211207356130 ∧ code e1211207356130 = 5609253867234 := by decide
theorem cert_e1211207356130 : check e1211207356130 [[],[]] .chain = true := by decide
def e1211207356142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e1211207356142 : Closed e1211207356142 ∧ code e1211207356142 = 5609253867246 := by decide
theorem cert_e1211207356142 : check e1211207356142 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207356182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211207356182 : Closed e1211207356182 ∧ code e1211207356182 = 5609253867286 := by decide
theorem cert_e1211207356182 : check e1211207356182 [[],[]] .chain = true := by decide
def e1211207356258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211207356258 : Closed e1211207356258 ∧ code e1211207356258 = 5609253867362 := by decide
theorem cert_e1211207356258 : check e1211207356258 [[],[]] .chain = true := by decide
def e1211207356270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e1211207356270 : Closed e1211207356270 ∧ code e1211207356270 = 5609253867374 := by decide
theorem cert_e1211207356270 : check e1211207356270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207356278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e1211207356278 : Closed e1211207356278 ∧ code e1211207356278 = 5609253867382 := by decide
theorem cert_e1211207356278 : check e1211207356278 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211207359342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211207359342 : Closed e1211207359342 ∧ code e1211207359342 = 5609253870446 := by decide
theorem cert_e1211207359342 : check e1211207359342 [[],[]] .chain = true := by decide
def e1211207359350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211207359350 : Closed e1211207359350 ∧ code e1211207359350 = 5609253870454 := by decide
theorem cert_e1211207359350 : check e1211207359350 [[],[]] .chain = true := by decide
def e1211207359414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e1211207359414 : Closed e1211207359414 ∧ code e1211207359414 = 5609253870518 := by decide
theorem cert_e1211207359414 : check e1211207359414 [[],[]] .chain = true := by decide
def e1211207359854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211207359854 : Closed e1211207359854 ∧ code e1211207359854 = 5609253870958 := by decide
theorem cert_e1211207359854 : check e1211207359854 [[],[]] .chain = true := by decide
def e1211207359862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211207359862 : Closed e1211207359862 ∧ code e1211207359862 = 5609253870966 := by decide
theorem cert_e1211207359862 : check e1211207359862 [[],[]] .chain = true := by decide
def e1211207359918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211207359918 : Closed e1211207359918 ∧ code e1211207359918 = 5609253871022 := by decide
theorem cert_e1211207359918 : check e1211207359918 [[],[]] .chain = true := by decide
def e1211207359930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211207359930 : Closed e1211207359930 ∧ code e1211207359930 = 5609253871034 := by decide
theorem cert_e1211207359930 : check e1211207359930 [[],[]] .chain = true := by decide
def e1211207359958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211207359958 : Closed e1211207359958 ∧ code e1211207359958 = 5609253871062 := by decide
theorem cert_e1211207359958 : check e1211207359958 [[],[]] .chain = true := by decide
def e1211207359962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211207359962 : Closed e1211207359962 ∧ code e1211207359962 = 5609253871066 := by decide
theorem cert_e1211207359962 : check e1211207359962 [[],[]] .chain = true := by decide
def e1211207360182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211207360182 : Closed e1211207360182 ∧ code e1211207360182 = 5609253871286 := by decide
theorem cert_e1211207360182 : check e1211207360182 [[],[]] .chain = true := by decide
def e1211207360214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211207360214 : Closed e1211207360214 ∧ code e1211207360214 = 5609253871318 := by decide
theorem cert_e1211207360214 : check e1211207360214 [[],[]] .chain = true := by decide
def e1211207360218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211207360218 : Closed e1211207360218 ∧ code e1211207360218 = 5609253871322 := by decide
theorem cert_e1211207360218 : check e1211207360218 [[],[]] .chain = true := by decide
def e1211207362414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211207362414 : Closed e1211207362414 ∧ code e1211207362414 = 5609253873518 := by decide
theorem cert_e1211207362414 : check e1211207362414 [[],[]] .chain = true := by decide
def e1211207362422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211207362422 : Closed e1211207362422 ∧ code e1211207362422 = 5609253873526 := by decide
theorem cert_e1211207362422 : check e1211207362422 [[],[]] .chain = true := by decide
def e1211207362486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211207362486 : Closed e1211207362486 ∧ code e1211207362486 = 5609253873590 := by decide
theorem cert_e1211207362486 : check e1211207362486 [[],[]] .chain = true := by decide
def e1211207363822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207363822 : Closed e1211207363822 ∧ code e1211207363822 = 5609253874926 := by decide
theorem cert_e1211207363822 : check e1211207363822 [[],[]] .chain = true := by decide
def e1211207363830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207363830 : Closed e1211207363830 ∧ code e1211207363830 = 5609253874934 := by decide
theorem cert_e1211207363830 : check e1211207363830 [[],[]] .chain = true := by decide
def e1211207364214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207364214 : Closed e1211207364214 ∧ code e1211207364214 = 5609253875318 := by decide
theorem cert_e1211207364214 : check e1211207364214 [[],[]] .chain = true := by decide
def e1211207364718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211207364718 : Closed e1211207364718 ∧ code e1211207364718 = 5609253875822 := by decide
theorem cert_e1211207364718 : check e1211207364718 [[],[]] .chain = true := by decide
def e1211207364894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211207364894 : Closed e1211207364894 ∧ code e1211207364894 = 5609253875998 := by decide
theorem cert_e1211207364894 : check e1211207364894 [[],[]] .chain = true := by decide
def e1211207365090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211207365090 : Closed e1211207365090 ∧ code e1211207365090 = 5609253876194 := by decide
theorem cert_e1211207365090 : check e1211207365090 [[],[]] .chain = true := by decide
def e1211207365102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211207365102 : Closed e1211207365102 ∧ code e1211207365102 = 5609253876206 := by decide
theorem cert_e1211207365102 : check e1211207365102 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207365486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211207365486 : Closed e1211207365486 ∧ code e1211207365486 = 5609253876590 := by decide
theorem cert_e1211207365486 : check e1211207365486 [[],[]] .chain = true := by decide
def e1211207365494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211207365494 : Closed e1211207365494 ∧ code e1211207365494 = 5609253876598 := by decide
theorem cert_e1211207365494 : check e1211207365494 [[],[]] .chain = true := by decide
def e1211207365550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211207365550 : Closed e1211207365550 ∧ code e1211207365550 = 5609253876654 := by decide
theorem cert_e1211207365550 : check e1211207365550 [[],[]] .chain = true := by decide
def e1211207365562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211207365562 : Closed e1211207365562 ∧ code e1211207365562 = 5609253876666 := by decide
theorem cert_e1211207365562 : check e1211207365562 [[],[]] .chain = true := by decide
def e1211207365590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211207365590 : Closed e1211207365590 ∧ code e1211207365590 = 5609253876694 := by decide
theorem cert_e1211207365590 : check e1211207365590 [[],[]] .chain = true := by decide
def e1211207365594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211207365594 : Closed e1211207365594 ∧ code e1211207365594 = 5609253876698 := by decide
theorem cert_e1211207365594 : check e1211207365594 [[],[]] .chain = true := by decide
def e1211207365870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207365870 : Closed e1211207365870 ∧ code e1211207365870 = 5609253876974 := by decide
theorem cert_e1211207365870 : check e1211207365870 [[],[]] .chain = true := by decide
def e1211207365878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207365878 : Closed e1211207365878 ∧ code e1211207365878 = 5609253876982 := by decide
theorem cert_e1211207365878 : check e1211207365878 [[],[]] .chain = true := by decide
def e1211207366254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207366254 : Closed e1211207366254 ∧ code e1211207366254 = 5609253877358 := by decide
theorem cert_e1211207366254 : check e1211207366254 [[],[]] .chain = true := by decide
def e1211207366266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207366266 : Closed e1211207366266 ∧ code e1211207366266 = 5609253877370 := by decide
theorem cert_e1211207366266 : check e1211207366266 [[],[]] .chain = true := by decide
def e1211207366406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207366406 : Closed e1211207366406 ∧ code e1211207366406 = 5609253877510 := by decide
theorem cert_e1211207366406 : check e1211207366406 [[],[]] .chain = true := by decide
def e1211207366430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211207366430 : Closed e1211207366430 ∧ code e1211207366430 = 5609253877534 := by decide
theorem cert_e1211207366430 : check e1211207366430 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207366454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207366454 : Closed e1211207366454 ∧ code e1211207366454 = 5609253877558 := by decide
theorem cert_e1211207366454 : check e1211207366454 [[],[]] .chain = true := by decide
def e1211207366458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207366458 : Closed e1211207366458 ∧ code e1211207366458 = 5609253877562 := by decide
theorem cert_e1211207366458 : check e1211207366458 [[],[]] .chain = true := by decide
def e1211207366710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211207366710 : Closed e1211207366710 ∧ code e1211207366710 = 5609253877814 := by decide
theorem cert_e1211207366710 : check e1211207366710 [[],[]] .chain = true := by decide
def e1211207366798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211207366798 : Closed e1211207366798 ∧ code e1211207366798 = 5609253877902 := by decide
theorem cert_e1211207366798 : check e1211207366798 [[],[]] .chain = true := by decide
def e1211207366882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211207366882 : Closed e1211207366882 ∧ code e1211207366882 = 5609253877986 := by decide
theorem cert_e1211207366882 : check e1211207366882 [[],[]] .chain = true := by decide
def e1211207366894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211207366894 : Closed e1211207366894 ∧ code e1211207366894 = 5609253877998 := by decide
theorem cert_e1211207366894 : check e1211207366894 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211207366902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211207366902 : Closed e1211207366902 ∧ code e1211207366902 = 5609253878006 := by decide
theorem cert_e1211207366902 : check e1211207366902 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207367094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211207367094 : Closed e1211207367094 ∧ code e1211207367094 = 5609253878198 := by decide
theorem cert_e1211207367094 : check e1211207367094 [[],[]] .chain = true := by decide
def e1211207367126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211207367126 : Closed e1211207367126 ∧ code e1211207367126 = 5609253878230 := by decide
theorem cert_e1211207367126 : check e1211207367126 [[],[]] .chain = true := by decide
def e1211207367130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211207367130 : Closed e1211207367130 ∧ code e1211207367130 = 5609253878234 := by decide
theorem cert_e1211207367130 : check e1211207367130 [[],[]] .chain = true := by decide
def e1211207367286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211207367286 : Closed e1211207367286 ∧ code e1211207367286 = 5609253878390 := by decide
theorem cert_e1211207367286 : check e1211207367286 [[],[]] .chain = true := by decide
def e1211207367430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207367430 : Closed e1211207367430 ∧ code e1211207367430 = 5609253878534 := by decide
theorem cert_e1211207367430 : check e1211207367430 [[],[]] .chain = true := by decide
def e1211207367454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211207367454 : Closed e1211207367454 ∧ code e1211207367454 = 5609253878558 := by decide
theorem cert_e1211207367454 : check e1211207367454 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211207367478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207367478 : Closed e1211207367478 ∧ code e1211207367478 = 5609253878582 := by decide
theorem cert_e1211207367478 : check e1211207367478 [[],[]] .chain = true := by decide
def e1211207367482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207367482 : Closed e1211207367482 ∧ code e1211207367482 = 5609253878586 := by decide
theorem cert_e1211207367482 : check e1211207367482 [[],[]] .chain = true := by decide
def e1211207367566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211207367566 : Closed e1211207367566 ∧ code e1211207367566 = 5609253878670 := by decide
theorem cert_e1211207367566 : check e1211207367566 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211207369070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e1211207369070 : Closed e1211207369070 ∧ code e1211207369070 = 5609253880174 := by decide
theorem cert_e1211207369070 : check e1211207369070 [[],[]] .chain = true := by decide
def e1211207369078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e1211207369078 : Closed e1211207369078 ∧ code e1211207369078 = 5609253880182 := by decide
theorem cert_e1211207369078 : check e1211207369078 [[],[]] .chain = true := by decide
def e1211207369134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211207369134 : Closed e1211207369134 ∧ code e1211207369134 = 5609253880238 := by decide
theorem cert_e1211207369134 : check e1211207369134 [[],[]] .chain = true := by decide
def e1211207369146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211207369146 : Closed e1211207369146 ∧ code e1211207369146 = 5609253880250 := by decide
theorem cert_e1211207369146 : check e1211207369146 [[],[]] .chain = true := by decide
def e1211207369838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211207369838 : Closed e1211207369838 ∧ code e1211207369838 = 5609253880942 := by decide
theorem cert_e1211207369838 : check e1211207369838 [[],[]] .chain = true := by decide
def e1211207369850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211207369850 : Closed e1211207369850 ∧ code e1211207369850 = 5609253880954 := by decide
theorem cert_e1211207369850 : check e1211207369850 [[],[]] .chain = true := by decide
def e1211207370014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211207370014 : Closed e1211207370014 ∧ code e1211207370014 = 5609253881118 := by decide
theorem cert_e1211207370014 : check e1211207370014 [[],[]] .chain = true := by decide
def e1211207370182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211207370182 : Closed e1211207370182 ∧ code e1211207370182 = 5609253881286 := by decide
theorem cert_e1211207370182 : check e1211207370182 [[],[]] .chain = true := by decide
def e1211207370286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211207370286 : Closed e1211207370286 ∧ code e1211207370286 = 5609253881390 := by decide
theorem cert_e1211207370286 : check e1211207370286 [[],[]] .chain = true := by decide
def e1211207370466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211207370466 : Closed e1211207370466 ∧ code e1211207370466 = 5609253881570 := by decide
theorem cert_e1211207370466 : check e1211207370466 [[],[]] .chain = true := by decide
def e1211207370478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211207370478 : Closed e1211207370478 ∧ code e1211207370478 = 5609253881582 := by decide
theorem cert_e1211207370478 : check e1211207370478 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207370606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1211207370606 : Closed e1211207370606 ∧ code e1211207370606 = 5609253881710 := by decide
theorem cert_e1211207370606 : check e1211207370606 [[],[]] .chain = true := by decide
def e1211207370614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1211207370614 : Closed e1211207370614 ∧ code e1211207370614 = 5609253881718 := by decide
theorem cert_e1211207370614 : check e1211207370614 [[],[]] .chain = true := by decide
def e1211207370634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211207370634 : Closed e1211207370634 ∧ code e1211207370634 = 5609253881738 := by decide
theorem cert_e1211207370634 : check e1211207370634 [[],[]] .chain = true := by decide
def e1211207370658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211207370658 : Closed e1211207370658 ∧ code e1211207370658 = 5609253881762 := by decide
theorem cert_e1211207370658 : check e1211207370658 [[],[]] .chain = true := by decide
def e1211207370670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211207370670 : Closed e1211207370670 ∧ code e1211207370670 = 5609253881774 := by decide
theorem cert_e1211207370670 : check e1211207370670 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207370678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1211207370678 : Closed e1211207370678 ∧ code e1211207370678 = 5609253881782 := by decide
theorem cert_e1211207370678 : check e1211207370678 [[],[]] .chain = true := by decide
def e1211207370682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211207370682 : Closed e1211207370682 ∧ code e1211207370682 = 5609253881786 := by decide
theorem cert_e1211207370682 : check e1211207370682 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207372142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211207372142 : Closed e1211207372142 ∧ code e1211207372142 = 5609253883246 := by decide
theorem cert_e1211207372142 : check e1211207372142 [[],[]] .chain = true := by decide
def e1211207372150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211207372150 : Closed e1211207372150 ∧ code e1211207372150 = 5609253883254 := by decide
theorem cert_e1211207372150 : check e1211207372150 [[],[]] .chain = true := by decide
def e1211207372206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211207372206 : Closed e1211207372206 ∧ code e1211207372206 = 5609253883310 := by decide
theorem cert_e1211207372206 : check e1211207372206 [[],[]] .chain = true := by decide
def e1211207372218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211207372218 : Closed e1211207372218 ∧ code e1211207372218 = 5609253883322 := by decide
theorem cert_e1211207372218 : check e1211207372218 [[],[]] .chain = true := by decide
def e1211207372246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211207372246 : Closed e1211207372246 ∧ code e1211207372246 = 5609253883350 := by decide
theorem cert_e1211207372246 : check e1211207372246 [[],[]] .chain = true := by decide
def e1211207372250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211207372250 : Closed e1211207372250 ∧ code e1211207372250 = 5609253883354 := by decide
theorem cert_e1211207372250 : check e1211207372250 [[],[]] .chain = true := by decide
def e1211207372462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211207372462 : Closed e1211207372462 ∧ code e1211207372462 = 5609253883566 := by decide
theorem cert_e1211207372462 : check e1211207372462 [[],[]] .chain = true := by decide
def e1211207372474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211207372474 : Closed e1211207372474 ∧ code e1211207372474 = 5609253883578 := by decide
theorem cert_e1211207372474 : check e1211207372474 [[],[]] .chain = true := by decide
def e1211207372522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211207372522 : Closed e1211207372522 ∧ code e1211207372522 = 5609253883626 := by decide
theorem cert_e1211207372522 : check e1211207372522 [[],[]] .chain = true := by decide
def e1211207372630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211207372630 : Closed e1211207372630 ∧ code e1211207372630 = 5609253883734 := by decide
theorem cert_e1211207372630 : check e1211207372630 [[],[]] .chain = true := by decide
def e1211207372634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211207372634 : Closed e1211207372634 ∧ code e1211207372634 = 5609253883738 := by decide
theorem cert_e1211207372634 : check e1211207372634 [[],[]] .chain = true := by decide
def e1211207372650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211207372650 : Closed e1211207372650 ∧ code e1211207372650 = 5609253883754 := by decide
theorem cert_e1211207372650 : check e1211207372650 [[],[]] .chain = true := by decide
def e1211207372910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211207372910 : Closed e1211207372910 ∧ code e1211207372910 = 5609253884014 := by decide
theorem cert_e1211207372910 : check e1211207372910 [[],[]] .chain = true := by decide
def e1211207373086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211207373086 : Closed e1211207373086 ∧ code e1211207373086 = 5609253884190 := by decide
theorem cert_e1211207373086 : check e1211207373086 [[],[]] .chain = true := by decide
def e1211207373282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211207373282 : Closed e1211207373282 ∧ code e1211207373282 = 5609253884386 := by decide
theorem cert_e1211207373282 : check e1211207373282 [[],[]] .chain = true := by decide
def e1211207373294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211207373294 : Closed e1211207373294 ∧ code e1211207373294 = 5609253884398 := by decide
theorem cert_e1211207373294 : check e1211207373294 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207373678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211207373678 : Closed e1211207373678 ∧ code e1211207373678 = 5609253884782 := by decide
theorem cert_e1211207373678 : check e1211207373678 [[],[]] .chain = true := by decide
def e1211207373686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211207373686 : Closed e1211207373686 ∧ code e1211207373686 = 5609253884790 := by decide
theorem cert_e1211207373686 : check e1211207373686 [[],[]] .chain = true := by decide
def e1211207373742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211207373742 : Closed e1211207373742 ∧ code e1211207373742 = 5609253884846 := by decide
theorem cert_e1211207373742 : check e1211207373742 [[],[]] .chain = true := by decide
def e1211207373754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211207373754 : Closed e1211207373754 ∧ code e1211207373754 = 5609253884858 := by decide
theorem cert_e1211207373754 : check e1211207373754 [[],[]] .chain = true := by decide
def e1211207373782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211207373782 : Closed e1211207373782 ∧ code e1211207373782 = 5609253884886 := by decide
theorem cert_e1211207373782 : check e1211207373782 [[],[]] .chain = true := by decide
def e1211207373786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211207373786 : Closed e1211207373786 ∧ code e1211207373786 = 5609253884890 := by decide
theorem cert_e1211207373786 : check e1211207373786 [[],[]] .chain = true := by decide
def e1211207374062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211207374062 : Closed e1211207374062 ∧ code e1211207374062 = 5609253885166 := by decide
theorem cert_e1211207374062 : check e1211207374062 [[],[]] .chain = true := by decide
def e1211207374070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211207374070 : Closed e1211207374070 ∧ code e1211207374070 = 5609253885174 := by decide
theorem cert_e1211207374070 : check e1211207374070 [[],[]] .chain = true := by decide
def e1211207374446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207374446 : Closed e1211207374446 ∧ code e1211207374446 = 5609253885550 := by decide
theorem cert_e1211207374446 : check e1211207374446 [[],[]] .chain = true := by decide
def e1211207374458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207374458 : Closed e1211207374458 ∧ code e1211207374458 = 5609253885562 := by decide
theorem cert_e1211207374458 : check e1211207374458 [[],[]] .chain = true := by decide
def e1211207374598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207374598 : Closed e1211207374598 ∧ code e1211207374598 = 5609253885702 := by decide
theorem cert_e1211207374598 : check e1211207374598 [[],[]] .chain = true := by decide
def e1211207374622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211207374622 : Closed e1211207374622 ∧ code e1211207374622 = 5609253885726 := by decide
theorem cert_e1211207374622 : check e1211207374622 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207374646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207374646 : Closed e1211207374646 ∧ code e1211207374646 = 5609253885750 := by decide
theorem cert_e1211207374646 : check e1211207374646 [[],[]] .chain = true := by decide
def e1211207374650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207374650 : Closed e1211207374650 ∧ code e1211207374650 = 5609253885754 := by decide
theorem cert_e1211207374650 : check e1211207374650 [[],[]] .chain = true := by decide
def e1211207374894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211207374894 : Closed e1211207374894 ∧ code e1211207374894 = 5609253885998 := by decide
theorem cert_e1211207374894 : check e1211207374894 [[],[]] .chain = true := by decide
def e1211207375086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211207375086 : Closed e1211207375086 ∧ code e1211207375086 = 5609253886190 := by decide
theorem cert_e1211207375086 : check e1211207375086 [[],[]] .chain = true := by decide
def e1211207375094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211207375094 : Closed e1211207375094 ∧ code e1211207375094 = 5609253886198 := by decide
theorem cert_e1211207375094 : check e1211207375094 [[],[]] .chain = true := by decide
def e1211207375278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211207375278 : Closed e1211207375278 ∧ code e1211207375278 = 5609253886382 := by decide
theorem cert_e1211207375278 : check e1211207375278 [[],[]] .chain = true := by decide
def e1211207375290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211207375290 : Closed e1211207375290 ∧ code e1211207375290 = 5609253886394 := by decide
theorem cert_e1211207375290 : check e1211207375290 [[],[]] .chain = true := by decide
def e1211207375338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211207375338 : Closed e1211207375338 ∧ code e1211207375338 = 5609253886442 := by decide
theorem cert_e1211207375338 : check e1211207375338 [[],[]] .chain = true := by decide
def e1211207375470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211207375470 : Closed e1211207375470 ∧ code e1211207375470 = 5609253886574 := by decide
theorem cert_e1211207375470 : check e1211207375470 [[],[]] .chain = true := by decide
def e1211207375482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211207375482 : Closed e1211207375482 ∧ code e1211207375482 = 5609253886586 := by decide
theorem cert_e1211207375482 : check e1211207375482 [[],[]] .chain = true := by decide
def e1211207375646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211207375646 : Closed e1211207375646 ∧ code e1211207375646 = 5609253886750 := by decide
theorem cert_e1211207375646 : check e1211207375646 [[],[]] .chain = true := by decide
def e1211207375746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211207375746 : Closed e1211207375746 ∧ code e1211207375746 = 5609253886850 := by decide
theorem cert_e1211207375746 : check e1211207375746 [[],[]] .chain = true := by decide
def e1211207375758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211207375758 : Closed e1211207375758 ∧ code e1211207375758 = 5609253886862 := by decide
theorem cert_e1211207375758 : check e1211207375758 [[],[]] .chain = true := by decide
def e1211207375770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211207375770 : Closed e1211207375770 ∧ code e1211207375770 = 5609253886874 := by decide
theorem cert_e1211207375770 : check e1211207375770 [[],[]] .chain = true := by decide
def e1211207375894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211207375894 : Closed e1211207375894 ∧ code e1211207375894 = 5609253886998 := by decide
theorem cert_e1211207375894 : check e1211207375894 [[],[]] .chain = true := by decide
def e1211207375898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211207375898 : Closed e1211207375898 ∧ code e1211207375898 = 5609253887002 := by decide
theorem cert_e1211207375898 : check e1211207375898 [[],[]] .chain = true := by decide
def e1211207375942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211207375942 : Closed e1211207375942 ∧ code e1211207375942 = 5609253887046 := by decide
theorem cert_e1211207375942 : check e1211207375942 [[],[]] .chain = true := by decide
def e1211207375970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211207375970 : Closed e1211207375970 ∧ code e1211207375970 = 5609253887074 := by decide
theorem cert_e1211207375970 : check e1211207375970 [[],[]] .chain = true := by decide
def e1211207375982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211207375982 : Closed e1211207375982 ∧ code e1211207375982 = 5609253887086 := by decide
theorem cert_e1211207375982 : check e1211207375982 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207375990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211207375990 : Closed e1211207375990 ∧ code e1211207375990 = 5609253887094 := by decide
theorem cert_e1211207375990 : check e1211207375990 [[],[]] .chain = true := by decide
def e1211207375994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211207375994 : Closed e1211207375994 ∧ code e1211207375994 = 5609253887098 := by decide
theorem cert_e1211207375994 : check e1211207375994 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207376086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211207376086 : Closed e1211207376086 ∧ code e1211207376086 = 5609253887190 := by decide
theorem cert_e1211207376086 : check e1211207376086 [[],[]] .chain = true := by decide
def e1211207376090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211207376090 : Closed e1211207376090 ∧ code e1211207376090 = 5609253887194 := by decide
theorem cert_e1211207376090 : check e1211207376090 [[],[]] .chain = true := by decide
def e1211207376106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211207376106 : Closed e1211207376106 ∧ code e1211207376106 = 5609253887210 := by decide
theorem cert_e1211207376106 : check e1211207376106 [[],[]] .chain = true := by decide
def e1211207376134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211207376134 : Closed e1211207376134 ∧ code e1211207376134 = 5609253887238 := by decide
theorem cert_e1211207376134 : check e1211207376134 [[],[]] .chain = true := by decide
def e1211207376158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211207376158 : Closed e1211207376158 ∧ code e1211207376158 = 5609253887262 := by decide
theorem cert_e1211207376158 : check e1211207376158 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207376182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211207376182 : Closed e1211207376182 ∧ code e1211207376182 = 5609253887286 := by decide
theorem cert_e1211207376182 : check e1211207376182 [[],[]] .chain = true := by decide
def e1211207376186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211207376186 : Closed e1211207376186 ∧ code e1211207376186 = 5609253887290 := by decide
theorem cert_e1211207376186 : check e1211207376186 [[],[]] .chain = true := by decide
def e1211207376258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211207376258 : Closed e1211207376258 ∧ code e1211207376258 = 5609253887362 := by decide
theorem cert_e1211207376258 : check e1211207376258 [[],[]] .chain = true := by decide
def e1211207376270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211207376270 : Closed e1211207376270 ∧ code e1211207376270 = 5609253887374 := by decide
theorem cert_e1211207376270 : check e1211207376270 [[],[]] .chain = true := by decide
def e1211207376282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211207376282 : Closed e1211207376282 ∧ code e1211207376282 = 5609253887386 := by decide
theorem cert_e1211207376282 : check e1211207376282 [[],[]] .chain = true := by decide
def e1211207376326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211207376326 : Closed e1211207376326 ∧ code e1211207376326 = 5609253887430 := by decide
theorem cert_e1211207376326 : check e1211207376326 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207377078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e1211207377078 : Closed e1211207377078 ∧ code e1211207377078 = 5609253888182 := by decide
theorem cert_e1211207377078 : check e1211207377078 [[],[]] .chain = true := by decide
def e1211207377110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211207377110 : Closed e1211207377110 ∧ code e1211207377110 = 5609253888214 := by decide
theorem cert_e1211207377110 : check e1211207377110 [[],[]] .chain = true := by decide
def e1211207377114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211207377114 : Closed e1211207377114 ∧ code e1211207377114 = 5609253888218 := by decide
theorem cert_e1211207377114 : check e1211207377114 [[],[]] .chain = true := by decide
def e1211207377462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211207377462 : Closed e1211207377462 ∧ code e1211207377462 = 5609253888566 := by decide
theorem cert_e1211207377462 : check e1211207377462 [[],[]] .chain = true := by decide
def e1211207377466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211207377466 : Closed e1211207377466 ∧ code e1211207377466 = 5609253888570 := by decide
theorem cert_e1211207377466 : check e1211207377466 [[],[]] .chain = true := by decide
def e1211207377550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211207377550 : Closed e1211207377550 ∧ code e1211207377550 = 5609253888654 := by decide
theorem cert_e1211207377550 : check e1211207377550 [[],[]] .chain = true := by decide
def e1211207377606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211207377606 : Closed e1211207377606 ∧ code e1211207377606 = 5609253888710 := by decide
theorem cert_e1211207377606 : check e1211207377606 [[],[]] .chain = true := by decide
def e1211207377686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211207377686 : Closed e1211207377686 ∧ code e1211207377686 = 5609253888790 := by decide
theorem cert_e1211207377686 : check e1211207377686 [[],[]] .chain = true := by decide
end Blc.Floor42
