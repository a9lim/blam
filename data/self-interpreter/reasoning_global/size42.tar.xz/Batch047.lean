import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1129630785654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129630785654 : Closed e1129630785654 ∧ code e1129630785654 = 5527677296758 := by decide
theorem cert_e1129630785654 : check e1129630785654 [[]] .width = true := by decide
def e1129630785898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129630785898 : Closed e1129630785898 ∧ code e1129630785898 = 5527677297002 := by decide
theorem cert_e1129630785898 : check e1129630785898 [[]] .width = true := by decide
def e1129630785946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129630785946 : Closed e1129630785946 ∧ code e1129630785946 = 5527677297050 := by decide
theorem cert_e1129630785946 : check e1129630785946 [[]] .width = true := by decide
def e1129630843078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129630843078 : Closed e1129630843078 ∧ code e1129630843078 = 5527677354182 := by decide
theorem cert_e1129630843078 : check e1129630843078 [[]] .width = true := by decide
def e1129630851098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129630851098 : Closed e1129630851098 ∧ code e1129630851098 = 5527677362202 := by decide
theorem cert_e1129630851098 : check e1129630851098 [[]] .width = true := by decide
def e1129630851190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129630851190 : Closed e1129630851190 ∧ code e1129630851190 = 5527677362294 := by decide
theorem cert_e1129630851190 : check e1129630851190 [[]] .width = true := by decide
def e1129630851434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129630851434 : Closed e1129630851434 ∧ code e1129630851434 = 5527677362538 := by decide
theorem cert_e1129630851434 : check e1129630851434 [[]] .width = true := by decide
def e1129630851482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129630851482 : Closed e1129630851482 ∧ code e1129630851482 = 5527677362586 := by decide
theorem cert_e1129630851482 : check e1129630851482 [[]] .width = true := by decide
def e1129636937926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129636937926 : Closed e1129636937926 ∧ code e1129636937926 = 5527683449030 := by decide
theorem cert_e1129636937926 : check e1129636937926 [[]] .width = true := by decide
def e1129637167302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129637167302 : Closed e1129637167302 ∧ code e1129637167302 = 5527683678406 := by decide
theorem cert_e1129637167302 : check e1129637167302 [[]] .width = true := by decide
def e1129640222746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129640222746 : Closed e1129640222746 ∧ code e1129640222746 = 5527686733850 := by decide
theorem cert_e1129640222746 : check e1129640222746 [[]] .width = true := by decide
def e1129640222838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129640222838 : Closed e1129640222838 ∧ code e1129640222838 = 5527686733942 := by decide
theorem cert_e1129640222838 : check e1129640222838 [[]] .width = true := by decide
def e1129640223082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129640223082 : Closed e1129640223082 ∧ code e1129640223082 = 5527686734186 := by decide
theorem cert_e1129640223082 : check e1129640223082 [[]] .width = true := by decide
def e1129640223130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129640223130 : Closed e1129640223130 ∧ code e1129640223130 = 5527686734234 := by decide
theorem cert_e1129640223130 : check e1129640223130 [[]] .width = true := by decide
def e1129640337434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129640337434 : Closed e1129640337434 ∧ code e1129640337434 = 5527686848538 := by decide
theorem cert_e1129640337434 : check e1129640337434 [[]] .width = true := by decide
def e1129640337526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129640337526 : Closed e1129640337526 ∧ code e1129640337526 = 5527686848630 := by decide
theorem cert_e1129640337526 : check e1129640337526 [[]] .width = true := by decide
def e1129640337770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129640337770 : Closed e1129640337770 ∧ code e1129640337770 = 5527686848874 := by decide
theorem cert_e1129640337770 : check e1129640337770 [[]] .width = true := by decide
def e1129640337818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129640337818 : Closed e1129640337818 ∧ code e1129640337818 = 5527686848922 := by decide
theorem cert_e1129640337818 : check e1129640337818 [[]] .width = true := by decide
def e1129641853126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129641853126 : Closed e1129641853126 ∧ code e1129641853126 = 5527688364230 := by decide
theorem cert_e1129641853126 : check e1129641853126 [[]] .width = true := by decide
def e1129641861146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129641861146 : Closed e1129641861146 ∧ code e1129641861146 = 5527688372250 := by decide
theorem cert_e1129641861146 : check e1129641861146 [[]] .width = true := by decide
def e1129641861238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129641861238 : Closed e1129641861238 ∧ code e1129641861238 = 5527688372342 := by decide
theorem cert_e1129641861238 : check e1129641861238 [[]] .width = true := by decide
def e1129641861482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129641861482 : Closed e1129641861482 ∧ code e1129641861482 = 5527688372586 := by decide
theorem cert_e1129641861482 : check e1129641861482 [[]] .width = true := by decide
def e1129641861530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129641861530 : Closed e1129641861530 ∧ code e1129641861530 = 5527688372634 := by decide
theorem cert_e1129641861530 : check e1129641861530 [[]] .width = true := by decide
def e1129641885894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129641885894 : Closed e1129641885894 ∧ code e1129641885894 = 5527688396998 := by decide
theorem cert_e1129641885894 : check e1129641885894 [[]] .width = true := by decide
def e1129641910298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129641910298 : Closed e1129641910298 ∧ code e1129641910298 = 5527688421402 := by decide
theorem cert_e1129641910298 : check e1129641910298 [[]] .width = true := by decide
def e1129641910390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129641910390 : Closed e1129641910390 ∧ code e1129641910390 = 5527688421494 := by decide
theorem cert_e1129641910390 : check e1129641910390 [[]] .width = true := by decide
def e1129641910634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129641910634 : Closed e1129641910634 ∧ code e1129641910634 = 5527688421738 := by decide
theorem cert_e1129641910634 : check e1129641910634 [[]] .width = true := by decide
def e1129641910682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129641910682 : Closed e1129641910682 ∧ code e1129641910682 = 5527688421786 := by decide
theorem cert_e1129641910682 : check e1129641910682 [[]] .width = true := by decide
def e1129758253082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129758253082 : Closed e1129758253082 ∧ code e1129758253082 = 5527804764186 := by decide
theorem cert_e1129758253082 : check e1129758253082 [[]] .width = true := by decide
def e1129758253174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129758253174 : Closed e1129758253174 ∧ code e1129758253174 = 5527804764278 := by decide
private def t_e1129758253174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129758253174 : ¬ IsSelfInterpreter e1129758253174 :=
  wSource (t := t_e1129758253174) (replay_sound (ps := []) (t := e1129758253174) (by decide)) (by decide)
def e1129758253418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129758253418 : Closed e1129758253418 ∧ code e1129758253418 = 5527804764522 := by decide
private def t_e1129758253418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129758253418 : ¬ IsSelfInterpreter e1129758253418 :=
  wSource (t := t_e1129758253418) (replay_sound (ps := []) (t := e1129758253418) (by decide)) (by decide)
def e1129758253466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129758253466 : Closed e1129758253466 ∧ code e1129758253466 = 5527804764570 := by decide
private def t_e1129758253466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129758253466 : ¬ IsSelfInterpreter e1129758253466 :=
  wSource (t := t_e1129758253466) (replay_sound (ps := []) (t := e1129758253466) (by decide)) (by decide)
def e1129758285850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129758285850 : Closed e1129758285850 ∧ code e1129758285850 = 5527804796954 := by decide
theorem cert_e1129758285850 : check e1129758285850 [[]] .width = true := by decide
def e1129758285942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129758285942 : Closed e1129758285942 ∧ code e1129758285942 = 5527804797046 := by decide
private def t_e1129758285942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129758285942 : ¬ IsSelfInterpreter e1129758285942 :=
  wSource (t := t_e1129758285942) (replay_sound (ps := []) (t := e1129758285942) (by decide)) (by decide)
def e1129758286186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129758286186 : Closed e1129758286186 ∧ code e1129758286186 = 5527804797290 := by decide
private def t_e1129758286186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129758286186 : ¬ IsSelfInterpreter e1129758286186 :=
  wSource (t := t_e1129758286186) (replay_sound (ps := []) (t := e1129758286186) (by decide)) (by decide)
def e1129758286234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129758286234 : Closed e1129758286234 ∧ code e1129758286234 = 5527804797338 := by decide
private def t_e1129758286234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129758286234 : ¬ IsSelfInterpreter e1129758286234 :=
  wSource (t := t_e1129758286234) (replay_sound (ps := []) (t := e1129758286234) (by decide)) (by decide)
def e1129758515226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129758515226 : Closed e1129758515226 ∧ code e1129758515226 = 5527805026330 := by decide
theorem cert_e1129758515226 : check e1129758515226 [[]] .width = true := by decide
def e1129758515318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129758515318 : Closed e1129758515318 ∧ code e1129758515318 = 5527805026422 := by decide
theorem cert_e1129758515318 : check e1129758515318 [[]] .width = true := by decide
def e1129758515562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129758515562 : Closed e1129758515562 ∧ code e1129758515562 = 5527805026666 := by decide
theorem cert_e1129758515562 : check e1129758515562 [[]] .width = true := by decide
def e1129758515610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129758515610 : Closed e1129758515610 ∧ code e1129758515610 = 5527805026714 := by decide
theorem cert_e1129758515610 : check e1129758515610 [[]] .width = true := by decide
def e1129758552262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129758552262 : Closed e1129758552262 ∧ code e1129758552262 = 5527805063366 := by decide
theorem cert_e1129758552262 : check e1129758552262 [[]] .width = true := by decide
def e1129758564378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129758564378 : Closed e1129758564378 ∧ code e1129758564378 = 5527805075482 := by decide
theorem cert_e1129758564378 : check e1129758564378 [[]] .width = true := by decide
def e1129758564470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129758564470 : Closed e1129758564470 ∧ code e1129758564470 = 5527805075574 := by decide
theorem cert_e1129758564470 : check e1129758564470 [[]] .width = true := by decide
def e1129758564714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129758564714 : Closed e1129758564714 ∧ code e1129758564714 = 5527805075818 := by decide
theorem cert_e1129758564714 : check e1129758564714 [[]] .width = true := by decide
def e1129758564762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129758564762 : Closed e1129758564762 ∧ code e1129758564762 = 5527805075866 := by decide
theorem cert_e1129758564762 : check e1129758564762 [[]] .width = true := by decide
def e1129758568646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129758568646 : Closed e1129758568646 ∧ code e1129758568646 = 5527805079750 := by decide
theorem cert_e1129758568646 : check e1129758568646 [[]] .width = true := by decide
def e1129758570522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129758570522 : Closed e1129758570522 ∧ code e1129758570522 = 5527805081626 := by decide
theorem cert_e1129758570522 : check e1129758570522 [[]] .width = true := by decide
def e1129758679066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129758679066 : Closed e1129758679066 ∧ code e1129758679066 = 5527805190170 := by decide
theorem cert_e1129758679066 : check e1129758679066 [[]] .width = true := by decide
def e1129758679158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129758679158 : Closed e1129758679158 ∧ code e1129758679158 = 5527805190262 := by decide
private def t_e1129758679158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129758679158 : ¬ IsSelfInterpreter e1129758679158 :=
  wSource (t := t_e1129758679158) (replay_sound (ps := []) (t := e1129758679158) (by decide)) (by decide)
def e1129758679402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129758679402 : Closed e1129758679402 ∧ code e1129758679402 = 5527805190506 := by decide
private def t_e1129758679402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129758679402 : ¬ IsSelfInterpreter e1129758679402 :=
  wSource (t := t_e1129758679402) (replay_sound (ps := []) (t := e1129758679402) (by decide)) (by decide)
def e1129758679450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129758679450 : Closed e1129758679450 ∧ code e1129758679450 = 5527805190554 := by decide
private def t_e1129758679450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129758679450 : ¬ IsSelfInterpreter e1129758679450 :=
  wSource (t := t_e1129758679450) (replay_sound (ps := []) (t := e1129758679450) (by decide)) (by decide)
def e1129758695450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129758695450 : Closed e1129758695450 ∧ code e1129758695450 = 5527805206554 := by decide
theorem cert_e1129758695450 : check e1129758695450 [[]] .width = true := by decide
def e1129758695542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129758695542 : Closed e1129758695542 ∧ code e1129758695542 = 5527805206646 := by decide
private def t_e1129758695542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129758695542 : ¬ IsSelfInterpreter e1129758695542 :=
  wSource (t := t_e1129758695542) (replay_sound (ps := []) (t := e1129758695542) (by decide)) (by decide)
def e1129758695786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129758695786 : Closed e1129758695786 ∧ code e1129758695786 = 5527805206890 := by decide
private def t_e1129758695786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129758695786 : ¬ IsSelfInterpreter e1129758695786 :=
  wSource (t := t_e1129758695786) (replay_sound (ps := []) (t := e1129758695786) (by decide)) (by decide)
def e1129758695834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129758695834 : Closed e1129758695834 ∧ code e1129758695834 = 5527805206938 := by decide
private def t_e1129758695834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129758695834 : ¬ IsSelfInterpreter e1129758695834 :=
  wSource (t := t_e1129758695834) (replay_sound (ps := []) (t := e1129758695834) (by decide)) (by decide)
def e1129758699718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129758699718 : Closed e1129758699718 ∧ code e1129758699718 = 5527805210822 := by decide
theorem cert_e1129758699718 : check e1129758699718 [[]] .width = true := by decide
def e1129758701594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129758701594 : Closed e1129758701594 ∧ code e1129758701594 = 5527805212698 := by decide
theorem cert_e1129758701594 : check e1129758701594 [[]] .width = true := by decide
def e1129758709786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129758709786 : Closed e1129758709786 ∧ code e1129758709786 = 5527805220890 := by decide
theorem cert_e1129758709786 : check e1129758709786 [[]] .width = true := by decide
def e1129759563802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129759563802 : Closed e1129759563802 ∧ code e1129759563802 = 5527806074906 := by decide
theorem cert_e1129759563802 : check e1129759563802 [[]] .width = true := by decide
def e1129759563894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129759563894 : Closed e1129759563894 ∧ code e1129759563894 = 5527806074998 := by decide
theorem cert_e1129759563894 : check e1129759563894 [[]] .width = true := by decide
def e1129759564138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129759564138 : Closed e1129759564138 ∧ code e1129759564138 = 5527806075242 := by decide
theorem cert_e1129759564138 : check e1129759564138 [[]] .width = true := by decide
def e1129759564186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129759564186 : Closed e1129759564186 ∧ code e1129759564186 = 5527806075290 := by decide
theorem cert_e1129759564186 : check e1129759564186 [[]] .width = true := by decide
def e1129759600838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129759600838 : Closed e1129759600838 ∧ code e1129759600838 = 5527806111942 := by decide
theorem cert_e1129759600838 : check e1129759600838 [[]] .width = true := by decide
def e1129759612954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129759612954 : Closed e1129759612954 ∧ code e1129759612954 = 5527806124058 := by decide
theorem cert_e1129759612954 : check e1129759612954 [[]] .width = true := by decide
def e1129759613046 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129759613046 : Closed e1129759613046 ∧ code e1129759613046 = 5527806124150 := by decide
theorem cert_e1129759613046 : check e1129759613046 [[]] .width = true := by decide
def e1129759613290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129759613290 : Closed e1129759613290 ∧ code e1129759613290 = 5527806124394 := by decide
theorem cert_e1129759613290 : check e1129759613290 [[]] .width = true := by decide
def e1129759613338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129759613338 : Closed e1129759613338 ∧ code e1129759613338 = 5527806124442 := by decide
theorem cert_e1129759613338 : check e1129759613338 [[]] .width = true := by decide
def e1129759617222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129759617222 : Closed e1129759617222 ∧ code e1129759617222 = 5527806128326 := by decide
theorem cert_e1129759617222 : check e1129759617222 [[]] .width = true := by decide
def e1129759619098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129759619098 : Closed e1129759619098 ∧ code e1129759619098 = 5527806130202 := by decide
theorem cert_e1129759619098 : check e1129759619098 [[]] .width = true := by decide
def e1129759731910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129759731910 : Closed e1129759731910 ∧ code e1129759731910 = 5527806243014 := by decide
theorem cert_e1129759731910 : check e1129759731910 [[]] .width = true := by decide
def e1129759756486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129759756486 : Closed e1129759756486 ∧ code e1129759756486 = 5527806267590 := by decide
theorem cert_e1129759756486 : check e1129759756486 [[]] .width = true := by decide
def e1129759809562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129759809562 : Closed e1129759809562 ∧ code e1129759809562 = 5527806320666 := by decide
theorem cert_e1129759809562 : check e1129759809562 [[]] .width = true := by decide
def e1129759809654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129759809654 : Closed e1129759809654 ∧ code e1129759809654 = 5527806320758 := by decide
theorem cert_e1129759809654 : check e1129759809654 [[]] .width = true := by decide
def e1129759809898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129759809898 : Closed e1129759809898 ∧ code e1129759809898 = 5527806321002 := by decide
theorem cert_e1129759809898 : check e1129759809898 [[]] .width = true := by decide
def e1129759809946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129759809946 : Closed e1129759809946 ∧ code e1129759809946 = 5527806321050 := by decide
theorem cert_e1129759809946 : check e1129759809946 [[]] .width = true := by decide
def e1129759813830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129759813830 : Closed e1129759813830 ∧ code e1129759813830 = 5527806324934 := by decide
theorem cert_e1129759813830 : check e1129759813830 [[]] .width = true := by decide
def e1129759815706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129759815706 : Closed e1129759815706 ∧ code e1129759815706 = 5527806326810 := by decide
theorem cert_e1129759815706 : check e1129759815706 [[]] .width = true := by decide
def e1129759822022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129759822022 : Closed e1129759822022 ∧ code e1129759822022 = 5527806333126 := by decide
theorem cert_e1129759822022 : check e1129759822022 [[]] .width = true := by decide
def e1129759827994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129759827994 : Closed e1129759827994 ∧ code e1129759827994 = 5527806339098 := by decide
theorem cert_e1129759827994 : check e1129759827994 [[]] .width = true := by decide
def e1129760251930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129760251930 : Closed e1129760251930 ∧ code e1129760251930 = 5527806763034 := by decide
theorem cert_e1129760251930 : check e1129760251930 [[]] .width = true := by decide
def e1129760252022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129760252022 : Closed e1129760252022 ∧ code e1129760252022 = 5527806763126 := by decide
private def t_e1129760252022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129760252022 : ¬ IsSelfInterpreter e1129760252022 :=
  wSource (t := t_e1129760252022) (replay_sound (ps := []) (t := e1129760252022) (by decide)) (by decide)
def e1129760252266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129760252266 : Closed e1129760252266 ∧ code e1129760252266 = 5527806763370 := by decide
private def t_e1129760252266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129760252266 : ¬ IsSelfInterpreter e1129760252266 :=
  wSource (t := t_e1129760252266) (replay_sound (ps := []) (t := e1129760252266) (by decide)) (by decide)
def e1129760252314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129760252314 : Closed e1129760252314 ∧ code e1129760252314 = 5527806763418 := by decide
private def t_e1129760252314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129760252314 : ¬ IsSelfInterpreter e1129760252314 :=
  wSource (t := t_e1129760252314) (replay_sound (ps := []) (t := e1129760252314) (by decide)) (by decide)
def e1129760268314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129760268314 : Closed e1129760268314 ∧ code e1129760268314 = 5527806779418 := by decide
theorem cert_e1129760268314 : check e1129760268314 [[]] .width = true := by decide
def e1129760268406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129760268406 : Closed e1129760268406 ∧ code e1129760268406 = 5527806779510 := by decide
private def t_e1129760268406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129760268406 : ¬ IsSelfInterpreter e1129760268406 :=
  wSource (t := t_e1129760268406) (replay_sound (ps := []) (t := e1129760268406) (by decide)) (by decide)
def e1129760268650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129760268650 : Closed e1129760268650 ∧ code e1129760268650 = 5527806779754 := by decide
private def t_e1129760268650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129760268650 : ¬ IsSelfInterpreter e1129760268650 :=
  wSource (t := t_e1129760268650) (replay_sound (ps := []) (t := e1129760268650) (by decide)) (by decide)
def e1129760268698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129760268698 : Closed e1129760268698 ∧ code e1129760268698 = 5527806779802 := by decide
private def t_e1129760268698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129760268698 : ¬ IsSelfInterpreter e1129760268698 :=
  wSource (t := t_e1129760268698) (replay_sound (ps := []) (t := e1129760268698) (by decide)) (by decide)
def e1129760272582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129760272582 : Closed e1129760272582 ∧ code e1129760272582 = 5527806783686 := by decide
theorem cert_e1129760272582 : check e1129760272582 [[]] .width = true := by decide
def e1129760274458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129760274458 : Closed e1129760274458 ∧ code e1129760274458 = 5527806785562 := by decide
theorem cert_e1129760274458 : check e1129760274458 [[]] .width = true := by decide
def e1129760282650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129760282650 : Closed e1129760282650 ∧ code e1129760282650 = 5527806793754 := by decide
theorem cert_e1129760282650 : check e1129760282650 [[]] .width = true := by decide
def e1129760333850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129760333850 : Closed e1129760333850 ∧ code e1129760333850 = 5527806844954 := by decide
theorem cert_e1129760333850 : check e1129760333850 [[]] .width = true := by decide
def e1129760333942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129760333942 : Closed e1129760333942 ∧ code e1129760333942 = 5527806845046 := by decide
theorem cert_e1129760333942 : check e1129760333942 [[]] .width = true := by decide
def e1129760334186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129760334186 : Closed e1129760334186 ∧ code e1129760334186 = 5527806845290 := by decide
theorem cert_e1129760334186 : check e1129760334186 [[]] .width = true := by decide
def e1129760334234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129760334234 : Closed e1129760334234 ∧ code e1129760334234 = 5527806845338 := by decide
theorem cert_e1129760334234 : check e1129760334234 [[]] .width = true := by decide
def e1129760338118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129760338118 : Closed e1129760338118 ∧ code e1129760338118 = 5527806849222 := by decide
theorem cert_e1129760338118 : check e1129760338118 [[]] .width = true := by decide
def e1129760339994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129760339994 : Closed e1129760339994 ∧ code e1129760339994 = 5527806851098 := by decide
theorem cert_e1129760339994 : check e1129760339994 [[]] .width = true := by decide
def e1129760346310 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129760346310 : Closed e1129760346310 ∧ code e1129760346310 = 5527806857414 := by decide
theorem cert_e1129760346310 : check e1129760346310 [[]] .width = true := by decide
def e1129760352282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129760352282 : Closed e1129760352282 ∧ code e1129760352282 = 5527806863386 := by decide
theorem cert_e1129760352282 : check e1129760352282 [[]] .width = true := by decide
def e1129760380954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129760380954 : Closed e1129760380954 ∧ code e1129760380954 = 5527806892058 := by decide
theorem cert_e1129760380954 : check e1129760380954 [[]] .width = true := by decide
def e1129760385050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129760385050 : Closed e1129760385050 ∧ code e1129760385050 = 5527806896154 := by decide
theorem cert_e1129760385050 : check e1129760385050 [[]] .width = true := by decide
def e1129762898118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129762898118 : Closed e1129762898118 ∧ code e1129762898118 = 5527809409222 := by decide
theorem cert_e1129762898118 : check e1129762898118 [[]] .width = true := by decide
def e1129762963654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129762963654 : Closed e1129762963654 ∧ code e1129762963654 = 5527809474758 := by decide
theorem cert_e1129762963654 : check e1129762963654 [[]] .width = true := by decide
def e1129764544538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129764544538 : Closed e1129764544538 ∧ code e1129764544538 = 5527811055642 := by decide
theorem cert_e1129764544538 : check e1129764544538 [[]] .width = true := by decide
def e1129764544630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129764544630 : Closed e1129764544630 ∧ code e1129764544630 = 5527811055734 := by decide
theorem cert_e1129764544630 : check e1129764544630 [[]] .width = true := by decide
def e1129764544874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129764544874 : Closed e1129764544874 ∧ code e1129764544874 = 5527811055978 := by decide
theorem cert_e1129764544874 : check e1129764544874 [[]] .width = true := by decide
def e1129764544922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129764544922 : Closed e1129764544922 ∧ code e1129764544922 = 5527811056026 := by decide
theorem cert_e1129764544922 : check e1129764544922 [[]] .width = true := by decide
def e1129764577306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129764577306 : Closed e1129764577306 ∧ code e1129764577306 = 5527811088410 := by decide
theorem cert_e1129764577306 : check e1129764577306 [[]] .width = true := by decide
def e1129764577398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129764577398 : Closed e1129764577398 ∧ code e1129764577398 = 5527811088502 := by decide
private def t_e1129764577398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129764577398 : ¬ IsSelfInterpreter e1129764577398 :=
  wSource (t := t_e1129764577398) (replay_sound (ps := []) (t := e1129764577398) (by decide)) (by decide)
def e1129764577642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129764577642 : Closed e1129764577642 ∧ code e1129764577642 = 5527811088746 := by decide
private def t_e1129764577642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129764577642 : ¬ IsSelfInterpreter e1129764577642 :=
  wSource (t := t_e1129764577642) (replay_sound (ps := []) (t := e1129764577642) (by decide)) (by decide)
def e1129764577690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129764577690 : Closed e1129764577690 ∧ code e1129764577690 = 5527811088794 := by decide
private def t_e1129764577690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129764577690 : ¬ IsSelfInterpreter e1129764577690 :=
  wSource (t := t_e1129764577690) (replay_sound (ps := []) (t := e1129764577690) (by decide)) (by decide)
def e1129764806682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129764806682 : Closed e1129764806682 ∧ code e1129764806682 = 5527811317786 := by decide
theorem cert_e1129764806682 : check e1129764806682 [[]] .width = true := by decide
def e1129764806774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129764806774 : Closed e1129764806774 ∧ code e1129764806774 = 5527811317878 := by decide
theorem cert_e1129764806774 : check e1129764806774 [[]] .width = true := by decide
def e1129764807018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129764807018 : Closed e1129764807018 ∧ code e1129764807018 = 5527811318122 := by decide
theorem cert_e1129764807018 : check e1129764807018 [[]] .width = true := by decide
def e1129764807066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129764807066 : Closed e1129764807066 ∧ code e1129764807066 = 5527811318170 := by decide
theorem cert_e1129764807066 : check e1129764807066 [[]] .width = true := by decide
def e1129764843718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129764843718 : Closed e1129764843718 ∧ code e1129764843718 = 5527811354822 := by decide
theorem cert_e1129764843718 : check e1129764843718 [[]] .width = true := by decide
def e1129764855834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129764855834 : Closed e1129764855834 ∧ code e1129764855834 = 5527811366938 := by decide
theorem cert_e1129764855834 : check e1129764855834 [[]] .width = true := by decide
def e1129764855926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129764855926 : Closed e1129764855926 ∧ code e1129764855926 = 5527811367030 := by decide
theorem cert_e1129764855926 : check e1129764855926 [[]] .width = true := by decide
def e1129764856170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129764856170 : Closed e1129764856170 ∧ code e1129764856170 = 5527811367274 := by decide
theorem cert_e1129764856170 : check e1129764856170 [[]] .width = true := by decide
def e1129764856218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129764856218 : Closed e1129764856218 ∧ code e1129764856218 = 5527811367322 := by decide
theorem cert_e1129764856218 : check e1129764856218 [[]] .width = true := by decide
def e1129764860102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129764860102 : Closed e1129764860102 ∧ code e1129764860102 = 5527811371206 := by decide
theorem cert_e1129764860102 : check e1129764860102 [[]] .width = true := by decide
def e1129764861978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129764861978 : Closed e1129764861978 ∧ code e1129764861978 = 5527811373082 := by decide
theorem cert_e1129764861978 : check e1129764861978 [[]] .width = true := by decide
def e1129764970522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129764970522 : Closed e1129764970522 ∧ code e1129764970522 = 5527811481626 := by decide
theorem cert_e1129764970522 : check e1129764970522 [[]] .width = true := by decide
def e1129764970614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129764970614 : Closed e1129764970614 ∧ code e1129764970614 = 5527811481718 := by decide
private def t_e1129764970614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129764970614 : ¬ IsSelfInterpreter e1129764970614 :=
  wSource (t := t_e1129764970614) (replay_sound (ps := []) (t := e1129764970614) (by decide)) (by decide)
def e1129764970858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129764970858 : Closed e1129764970858 ∧ code e1129764970858 = 5527811481962 := by decide
private def t_e1129764970858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129764970858 : ¬ IsSelfInterpreter e1129764970858 :=
  wSource (t := t_e1129764970858) (replay_sound (ps := []) (t := e1129764970858) (by decide)) (by decide)
def e1129764970906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129764970906 : Closed e1129764970906 ∧ code e1129764970906 = 5527811482010 := by decide
private def t_e1129764970906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129764970906 : ¬ IsSelfInterpreter e1129764970906 :=
  wSource (t := t_e1129764970906) (replay_sound (ps := []) (t := e1129764970906) (by decide)) (by decide)
def e1129764986906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129764986906 : Closed e1129764986906 ∧ code e1129764986906 = 5527811498010 := by decide
theorem cert_e1129764986906 : check e1129764986906 [[]] .width = true := by decide
def e1129764986998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129764986998 : Closed e1129764986998 ∧ code e1129764986998 = 5527811498102 := by decide
theorem cert_e1129764986998 : check e1129764986998 [[]] .width = true := by decide
def e1129764987242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129764987242 : Closed e1129764987242 ∧ code e1129764987242 = 5527811498346 := by decide
theorem cert_e1129764987242 : check e1129764987242 [[]] .width = true := by decide
def e1129764987290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129764987290 : Closed e1129764987290 ∧ code e1129764987290 = 5527811498394 := by decide
theorem cert_e1129764987290 : check e1129764987290 [[]] .width = true := by decide
def e1129764991174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129764991174 : Closed e1129764991174 ∧ code e1129764991174 = 5527811502278 := by decide
theorem cert_e1129764991174 : check e1129764991174 [[]] .width = true := by decide
def e1129764993050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129764993050 : Closed e1129764993050 ∧ code e1129764993050 = 5527811504154 := by decide
theorem cert_e1129764993050 : check e1129764993050 [[]] .width = true := by decide
def e1129765001242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129765001242 : Closed e1129765001242 ∧ code e1129765001242 = 5527811512346 := by decide
theorem cert_e1129765001242 : check e1129765001242 [[]] .width = true := by decide
def e1129766117402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129766117402 : Closed e1129766117402 ∧ code e1129766117402 = 5527812628506 := by decide
theorem cert_e1129766117402 : check e1129766117402 [[]] .width = true := by decide
def e1129766117494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129766117494 : Closed e1129766117494 ∧ code e1129766117494 = 5527812628598 := by decide
private def t_e1129766117494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129766117494 : ¬ IsSelfInterpreter e1129766117494 :=
  wSource (t := t_e1129766117494) (replay_sound (ps := []) (t := e1129766117494) (by decide)) (by decide)
def e1129766117738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129766117738 : Closed e1129766117738 ∧ code e1129766117738 = 5527812628842 := by decide
private def t_e1129766117738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129766117738 : ¬ IsSelfInterpreter e1129766117738 :=
  wSource (t := t_e1129766117738) (replay_sound (ps := []) (t := e1129766117738) (by decide)) (by decide)
def e1129766117786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129766117786 : Closed e1129766117786 ∧ code e1129766117786 = 5527812628890 := by decide
private def t_e1129766117786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129766117786 : ¬ IsSelfInterpreter e1129766117786 :=
  wSource (t := t_e1129766117786) (replay_sound (ps := []) (t := e1129766117786) (by decide)) (by decide)
def e1129766150170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129766150170 : Closed e1129766150170 ∧ code e1129766150170 = 5527812661274 := by decide
theorem cert_e1129766150170 : check e1129766150170 [[]] .width = true := by decide
def e1129766150262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129766150262 : Closed e1129766150262 ∧ code e1129766150262 = 5527812661366 := by decide
private def t_e1129766150262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129766150262 : ¬ IsSelfInterpreter e1129766150262 :=
  wSource (t := t_e1129766150262) (replay_sound (ps := []) (t := e1129766150262) (by decide)) (by decide)
def e1129766150506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129766150506 : Closed e1129766150506 ∧ code e1129766150506 = 5527812661610 := by decide
private def t_e1129766150506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129766150506 : ¬ IsSelfInterpreter e1129766150506 :=
  wSource (t := t_e1129766150506) (replay_sound (ps := []) (t := e1129766150506) (by decide)) (by decide)
def e1129766150554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129766150554 : Closed e1129766150554 ∧ code e1129766150554 = 5527812661658 := by decide
private def t_e1129766150554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129766150554 : ¬ IsSelfInterpreter e1129766150554 :=
  wSource (t := t_e1129766150554) (replay_sound (ps := []) (t := e1129766150554) (by decide)) (by decide)
def e1129767485638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129767485638 : Closed e1129767485638 ∧ code e1129767485638 = 5527813996742 := by decide
theorem cert_e1129767485638 : check e1129767485638 [[]] .width = true := by decide
def e1129767690266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129767690266 : Closed e1129767690266 ∧ code e1129767690266 = 5527814201370 := by decide
theorem cert_e1129767690266 : check e1129767690266 [[]] .width = true := by decide
def e1129767690358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129767690358 : Closed e1129767690358 ∧ code e1129767690358 = 5527814201462 := by decide
theorem cert_e1129767690358 : check e1129767690358 [[]] .width = true := by decide
def e1129767690602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129767690602 : Closed e1129767690602 ∧ code e1129767690602 = 5527814201706 := by decide
theorem cert_e1129767690602 : check e1129767690602 [[]] .width = true := by decide
def e1129767690650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129767690650 : Closed e1129767690650 ∧ code e1129767690650 = 5527814201754 := by decide
theorem cert_e1129767690650 : check e1129767690650 [[]] .width = true := by decide
def e1129767727302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129767727302 : Closed e1129767727302 ∧ code e1129767727302 = 5527814238406 := by decide
theorem cert_e1129767727302 : check e1129767727302 [[]] .width = true := by decide
def e1129767739418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129767739418 : Closed e1129767739418 ∧ code e1129767739418 = 5527814250522 := by decide
theorem cert_e1129767739418 : check e1129767739418 [[]] .width = true := by decide
def e1129767739510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129767739510 : Closed e1129767739510 ∧ code e1129767739510 = 5527814250614 := by decide
theorem cert_e1129767739510 : check e1129767739510 [[]] .width = true := by decide
def e1129767739754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129767739754 : Closed e1129767739754 ∧ code e1129767739754 = 5527814250858 := by decide
theorem cert_e1129767739754 : check e1129767739754 [[]] .width = true := by decide
def e1129767739802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129767739802 : Closed e1129767739802 ∧ code e1129767739802 = 5527814250906 := by decide
theorem cert_e1129767739802 : check e1129767739802 [[]] .width = true := by decide
def e1129767743686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129767743686 : Closed e1129767743686 ∧ code e1129767743686 = 5527814254790 := by decide
theorem cert_e1129767743686 : check e1129767743686 [[]] .width = true := by decide
def e1129767745562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129767745562 : Closed e1129767745562 ∧ code e1129767745562 = 5527814256666 := by decide
theorem cert_e1129767745562 : check e1129767745562 [[]] .width = true := by decide
def e1129768157210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129768157210 : Closed e1129768157210 ∧ code e1129768157210 = 5527814668314 := by decide
theorem cert_e1129768157210 : check e1129768157210 [[]] .width = true := by decide
def e1129768157302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129768157302 : Closed e1129768157302 ∧ code e1129768157302 = 5527814668406 := by decide
theorem cert_e1129768157302 : check e1129768157302 [[]] .width = true := by decide
def e1129768157546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129768157546 : Closed e1129768157546 ∧ code e1129768157546 = 5527814668650 := by decide
theorem cert_e1129768157546 : check e1129768157546 [[]] .width = true := by decide
def e1129768157594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129768157594 : Closed e1129768157594 ∧ code e1129768157594 = 5527814668698 := by decide
theorem cert_e1129768157594 : check e1129768157594 [[]] .width = true := by decide
def e1129768157678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129768157678 : Closed e1129768157678 ∧ code e1129768157678 = 5527814668782 := by decide
theorem cert_e1129768157678 : check e1129768157678 [[]] .width = true := by decide
def e1129768158602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129768158602 : Closed e1129768158602 ∧ code e1129768158602 = 5527814669706 := by decide
theorem cert_e1129768158602 : check e1129768158602 [[]] .width = true := by decide
def e1129768158626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129768158626 : Closed e1129768158626 ∧ code e1129768158626 = 5527814669730 := by decide
theorem cert_e1129768158626 : check e1129768158626 [[]] .width = true := by decide
def e1129768158646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129768158646 : Closed e1129768158646 ∧ code e1129768158646 = 5527814669750 := by decide
theorem cert_e1129768158646 : check e1129768158646 [[]] .width = true := by decide
end Blc.Floor42
