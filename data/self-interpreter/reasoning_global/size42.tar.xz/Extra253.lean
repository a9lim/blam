import Batch253
import ExtraBase
namespace Blc.Floor42.Extra253
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211550004154 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.app (.lam (.lam (.lam (.app (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.app (.var 2) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))))))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4))))))))))))
theorem ex_e1211550004154 : ¬ IsSelfInterpreter e1211550004154 := by
  intro he
  have hp := replay_sound (t := e1211550004154) (u := t_e1211550004154) (ps := [[],[],[.left],[.left,.left],[.left],[],[.right],[.right,.under,.under,.right,.right,.under,.under,.under],[],[.left],[],[.right],[.right,.under,.under],[],[.left],[]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.app (.lam (.lam (.lam (.app (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.app (.var 2) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))))))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))) (.var 0))) (.app (.var 1) (.app (.var 3) (.var 4)))))))))))) h
#print axioms ex_e1211550004154
private def t_e1211550231994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))) (.var 0))))
theorem ex_e1211550231994 : ¬ IsSelfInterpreter e1211550231994 := by
  intro he
  have hp := replay_sound (t := e1211550231994) (u := t_e1211550231994) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550231994) (by decide) (by decide) hj
#print axioms ex_e1211550231994
private def t_e1211550234042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))) (.var 0))))
theorem ex_e1211550234042 : ¬ IsSelfInterpreter e1211550234042 := by
  intro he
  have hp := replay_sound (t := e1211550234042) (u := t_e1211550234042) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550234042) (by decide) (by decide) hj
#print axioms ex_e1211550234042
private def t_e1211550244282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))) (.var 0))))
theorem ex_e1211550244282 : ¬ IsSelfInterpreter e1211550244282 := by
  intro he
  have hp := replay_sound (t := e1211550244282) (u := t_e1211550244282) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550244282) (by decide) (by decide) hj
#print axioms ex_e1211550244282
private def t_e1211550249914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem ex_e1211550249914 : ¬ IsSelfInterpreter e1211550249914 := by
  intro he
  have hp := replay_sound (t := e1211550249914) (u := t_e1211550249914) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550249914) (by decide) (by decide) hj
#print axioms ex_e1211550249914
private def t_e1211550249946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem ex_e1211550249946 : ¬ IsSelfInterpreter e1211550249946 := by
  intro he
  have hp := replay_sound (t := e1211550249946) (u := t_e1211550249946) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550249946) (by decide) (by decide) hj
#print axioms ex_e1211550249946
private def t_e1211550251482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))) (.var 0))))
theorem ex_e1211550251482 : ¬ IsSelfInterpreter e1211550251482 := by
  intro he
  have hp := replay_sound (t := e1211550251482) (u := t_e1211550251482) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550251482) (by decide) (by decide) hj
#print axioms ex_e1211550251482
private def t_e1211550256570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))))
theorem ex_e1211550256570 : ¬ IsSelfInterpreter e1211550256570 := by
  intro he
  have hp := replay_sound (t := e1211550256570) (u := t_e1211550256570) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550256570) (by decide) (by decide) hj
#print axioms ex_e1211550256570
private def t_e1211550256826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))))
theorem ex_e1211550256826 : ¬ IsSelfInterpreter e1211550256826 := by
  intro he
  have hp := replay_sound (t := e1211550256826) (u := t_e1211550256826) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550256826) (by decide) (by decide) hj
#print axioms ex_e1211550256826
private def t_e1211550258106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem ex_e1211550258106 : ¬ IsSelfInterpreter e1211550258106 := by
  intro he
  have hp := replay_sound (t := e1211550258106) (u := t_e1211550258106) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550258106) (by decide) (by decide) hj
#print axioms ex_e1211550258106
private def t_e1211550258138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem ex_e1211550258138 : ¬ IsSelfInterpreter e1211550258138 := by
  intro he
  have hp := replay_sound (t := e1211550258138) (u := t_e1211550258138) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550258138) (by decide) (by decide) hj
#print axioms ex_e1211550258138
private def t_e1211550263770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 0))))
theorem ex_e1211550263770 : ¬ IsSelfInterpreter e1211550263770 := by
  intro he
  have hp := replay_sound (t := e1211550263770) (u := t_e1211550263770) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550263770) (by decide) (by decide) hj
#print axioms ex_e1211550263770
private def t_e1211550293434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 0))))
theorem ex_e1211550293434 : ¬ IsSelfInterpreter e1211550293434 := by
  intro he
  have hp := replay_sound (t := e1211550293434) (u := t_e1211550293434) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2))) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))) (SO.var 0))))
#print axioms ex_e1211550293434
private def t_e1211550293466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.var 0))))
theorem ex_e1211550293466 : ¬ IsSelfInterpreter e1211550293466 := by
  intro he
  have hp := replay_sound (t := e1211550293466) (u := t_e1211550293466) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1))) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))) (SO.var 0))))
#print axioms ex_e1211550293466
private def t_e1211550293722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.var 0))))
theorem ex_e1211550293722 : ¬ IsSelfInterpreter e1211550293722 := by
  intro he
  have hp := replay_sound (t := e1211550293722) (u := t_e1211550293722) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))) (SO.var 0))))
#print axioms ex_e1211550293722
private def t_e1211550299066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem ex_e1211550299066 : ¬ IsSelfInterpreter e1211550299066 := by
  intro he
  have hp := replay_sound (t := e1211550299066) (u := t_e1211550299066) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.app (.var 0) (.var 1)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.var 1) (SO.var 2)))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 1))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))) (SO.var 0))))
#print axioms ex_e1211550299066
private def t_e1211550299098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem ex_e1211550299098 : ¬ IsSelfInterpreter e1211550299098 := by
  intro he
  have hp := replay_sound (t := e1211550299098) (u := t_e1211550299098) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.app (.var 1) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.app (SO.var 2) (SO.var 1)))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))) (SO.var 0))))
#print axioms ex_e1211550299098
private def t_e1211550300634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))) (.var 0))))
theorem ex_e1211550300634 : ¬ IsSelfInterpreter e1211550300634 := by
  intro he
  have hp := replay_sound (t := e1211550300634) (u := t_e1211550300634) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))) (r := (.var 0)) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1)))) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))) (SO.var 0))))
#print axioms ex_e1211550300634
private def t_e1211550373594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))) (.var 0))))
theorem ex_e1211550373594 : ¬ IsSelfInterpreter e1211550373594 := by
  intro he
  have hp := replay_sound (t := e1211550373594) (u := t_e1211550373594) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550373594) (by decide) (by decide) hj
#print axioms ex_e1211550373594
private def t_e1211550373722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 0))))
theorem ex_e1211550373722 : ¬ IsSelfInterpreter e1211550373722 := by
  intro he
  have hp := replay_sound (t := e1211550373722) (u := t_e1211550373722) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := rawCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211550373722) (by decide) (by decide) hj
#print axioms ex_e1211550373722
end Blc.Floor42.Extra253
