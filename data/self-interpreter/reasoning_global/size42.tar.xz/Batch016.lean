import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302912872046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e302912872046 : Closed e302912872046 ∧ code e302912872046 = 4700959383150 := by decide
theorem cert_e302912872046 : check e302912872046 [[.under],[.under]] .sourceHead = true := by decide
def e302912872058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e302912872058 : Closed e302912872058 ∧ code e302912872058 = 4700959383162 := by decide
theorem cert_e302912872058 : check e302912872058 [[.under],[.under]] .sourceHead = true := by decide
def e302912883566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302912883566 : Closed e302912883566 ∧ code e302912883566 = 4700959394670 := by decide
theorem cert_e302912883566 : check e302912883566 [[.under],[.under]] .sourceHead = true := by decide
def e302912883574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302912883574 : Closed e302912883574 ∧ code e302912883574 = 4700959394678 := by decide
theorem cert_e302912883574 : check e302912883574 [[.under],[.under]] .sourceHead = true := by decide
def e302912883630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302912883630 : Closed e302912883630 ∧ code e302912883630 = 4700959394734 := by decide
theorem cert_e302912883630 : check e302912883630 [[.under],[.under]] .sourceHead = true := by decide
def e302912883642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302912883642 : Closed e302912883642 ∧ code e302912883642 = 4700959394746 := by decide
theorem cert_e302912883642 : check e302912883642 [[.under],[.under]] .sourceHead = true := by decide
def e302912883670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302912883670 : Closed e302912883670 ∧ code e302912883670 = 4700959394774 := by decide
theorem cert_e302912883670 : check e302912883670 [[.under],[.under]] .sourceHead = true := by decide
def e302912883674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302912883674 : Closed e302912883674 ∧ code e302912883674 = 4700959394778 := by decide
theorem cert_e302912883674 : check e302912883674 [[.under],[.under]] .sourceHead = true := by decide
def e302912883950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302912883950 : Closed e302912883950 ∧ code e302912883950 = 4700959395054 := by decide
theorem cert_e302912883950 : check e302912883950 [[.under],[.under]] .sourceHead = true := by decide
def e302912883958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302912883958 : Closed e302912883958 ∧ code e302912883958 = 4700959395062 := by decide
theorem cert_e302912883958 : check e302912883958 [[.under],[.under]] .sourceHead = true := by decide
def e302912884334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302912884334 : Closed e302912884334 ∧ code e302912884334 = 4700959395438 := by decide
theorem cert_e302912884334 : check e302912884334 [[.under],[.under]] .sourceHead = true := by decide
def e302912884346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302912884346 : Closed e302912884346 ∧ code e302912884346 = 4700959395450 := by decide
theorem cert_e302912884346 : check e302912884346 [[.under],[.under]] .sourceHead = true := by decide
def e302912884534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302912884534 : Closed e302912884534 ∧ code e302912884534 = 4700959395638 := by decide
theorem cert_e302912884534 : check e302912884534 [[.under],[.under]] .sourceHead = true := by decide
def e302912884538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302912884538 : Closed e302912884538 ∧ code e302912884538 = 4700959395642 := by decide
theorem cert_e302912884538 : check e302912884538 [[.under],[.under]] .sourceHead = true := by decide
def e302913424238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e302913424238 : Closed e302913424238 ∧ code e302913424238 = 4700959935342 := by decide
theorem cert_e302913424238 : check e302913424238 [[.under],[.under]] .smaller = true := by decide
def e302913424246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e302913424246 : Closed e302913424246 ∧ code e302913424246 = 4700959935350 := by decide
theorem cert_e302913424246 : check e302913424246 [[.under],[.under]] .smaller = true := by decide
def e302913424302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e302913424302 : Closed e302913424302 ∧ code e302913424302 = 4700959935406 := by decide
theorem cert_e302913424302 : check e302913424302 [[.under],[.under]] .smaller = true := by decide
def e302913424314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e302913424314 : Closed e302913424314 ∧ code e302913424314 = 4700959935418 := by decide
theorem cert_e302913424314 : check e302913424314 [[.under],[.under]] .smaller = true := by decide
def e302913424342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e302913424342 : Closed e302913424342 ∧ code e302913424342 = 4700959935446 := by decide
theorem cert_e302913424342 : check e302913424342 [[.under],[.under]] .smaller = true := by decide
def e302913424346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e302913424346 : Closed e302913424346 ∧ code e302913424346 = 4700959935450 := by decide
theorem cert_e302913424346 : check e302913424346 [[.under],[.under]] .smaller = true := by decide
def e302913424622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e302913424622 : Closed e302913424622 ∧ code e302913424622 = 4700959935726 := by decide
theorem cert_e302913424622 : check e302913424622 [[.under],[.under]] .smaller = true := by decide
def e302913424630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e302913424630 : Closed e302913424630 ∧ code e302913424630 = 4700959935734 := by decide
theorem cert_e302913424630 : check e302913424630 [[.under],[.under]] .smaller = true := by decide
def e302913425006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e302913425006 : Closed e302913425006 ∧ code e302913425006 = 4700959936110 := by decide
theorem cert_e302913425006 : check e302913425006 [[.under],[.under]] .smaller = true := by decide
def e302913425018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e302913425018 : Closed e302913425018 ∧ code e302913425018 = 4700959936122 := by decide
theorem cert_e302913425018 : check e302913425018 [[.under],[.under]] .smaller = true := by decide
def e302913425206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302913425206 : Closed e302913425206 ∧ code e302913425206 = 4700959936310 := by decide
theorem cert_e302913425206 : check e302913425206 [[.under],[.under]] .smaller = true := by decide
def e302913425210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302913425210 : Closed e302913425210 ∧ code e302913425210 = 4700959936314 := by decide
theorem cert_e302913425210 : check e302913425210 [[.under],[.under]] .smaller = true := by decide
def e303197936350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e303197936350 : Closed e303197936350 ∧ code e303197936350 = 4701244447454 := by decide
theorem cert_e303197936350 : check e303197936350 [[.under]] .sourceHead = true := by decide
def e303197936374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e303197936374 : Closed e303197936374 ∧ code e303197936374 = 4701244447478 := by decide
theorem cert_e303197936374 : check e303197936374 [[.under]] .sourceHead = true := by decide
def e303197936478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e303197936478 : Closed e303197936478 ∧ code e303197936478 = 4701244447582 := by decide
theorem cert_e303197936478 : check e303197936478 [[.under]] .sourceHead = true := by decide
def e303197936494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e303197936494 : Closed e303197936494 ∧ code e303197936494 = 4701244447598 := by decide
theorem cert_e303197936494 : check e303197936494 [[.under]] .sourceHead = true := by decide
def e303197936502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e303197936502 : Closed e303197936502 ∧ code e303197936502 = 4701244447606 := by decide
theorem cert_e303197936502 : check e303197936502 [[.under]] .sourceHead = true := by decide
def e303197936506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e303197936506 : Closed e303197936506 ∧ code e303197936506 = 4701244447610 := by decide
theorem cert_e303197936506 : check e303197936506 [[.under]] .sourceHead = true := by decide
def e303197936566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e303197936566 : Closed e303197936566 ∧ code e303197936566 = 4701244447670 := by decide
theorem cert_e303197936566 : check e303197936566 [[.under]] .sourceHead = true := by decide
def e303197936598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e303197936598 : Closed e303197936598 ∧ code e303197936598 = 4701244447702 := by decide
theorem cert_e303197936598 : check e303197936598 [[.under]] .sourceHead = true := by decide
def e303197936602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e303197936602 : Closed e303197936602 ∧ code e303197936602 = 4701244447706 := by decide
theorem cert_e303197936602 : check e303197936602 [[.under]] .sourceHead = true := by decide
def e303197936990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e303197936990 : Closed e303197936990 ∧ code e303197936990 = 4701244448094 := by decide
theorem cert_e303197936990 : check e303197936990 [[.under]] .sourceHead = true := by decide
def e303197937006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e303197937006 : Closed e303197937006 ∧ code e303197937006 = 4701244448110 := by decide
theorem cert_e303197937006 : check e303197937006 [[.under]] .sourceHead = true := by decide
def e303197937014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e303197937014 : Closed e303197937014 ∧ code e303197937014 = 4701244448118 := by decide
theorem cert_e303197937014 : check e303197937014 [[.under]] .sourceHead = true := by decide
def e303197937018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e303197937018 : Closed e303197937018 ∧ code e303197937018 = 4701244448122 := by decide
theorem cert_e303197937018 : check e303197937018 [[.under]] .sourceHead = true := by decide
def e303197937070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e303197937070 : Closed e303197937070 ∧ code e303197937070 = 4701244448174 := by decide
theorem cert_e303197937070 : check e303197937070 [[.under]] .sourceHead = true := by decide
def e303197937082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e303197937082 : Closed e303197937082 ∧ code e303197937082 = 4701244448186 := by decide
theorem cert_e303197937082 : check e303197937082 [[.under]] .sourceHead = true := by decide
def e303197937110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e303197937110 : Closed e303197937110 ∧ code e303197937110 = 4701244448214 := by decide
theorem cert_e303197937110 : check e303197937110 [[.under]] .sourceHead = true := by decide
def e303197937114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e303197937114 : Closed e303197937114 ∧ code e303197937114 = 4701244448218 := by decide
theorem cert_e303197937114 : check e303197937114 [[.under]] .sourceHead = true := by decide
def e303197937130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e303197937130 : Closed e303197937130 ∧ code e303197937130 = 4701244448234 := by decide
theorem cert_e303197937130 : check e303197937130 [[.under]] .sourceHead = true := by decide
def e303197937334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e303197937334 : Closed e303197937334 ∧ code e303197937334 = 4701244448438 := by decide
theorem cert_e303197937334 : check e303197937334 [[.under]] .sourceHead = true := by decide
def e303197937366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e303197937366 : Closed e303197937366 ∧ code e303197937366 = 4701244448470 := by decide
theorem cert_e303197937366 : check e303197937366 [[.under]] .sourceHead = true := by decide
def e303197937370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e303197937370 : Closed e303197937370 ∧ code e303197937370 = 4701244448474 := by decide
theorem cert_e303197937370 : check e303197937370 [[.under]] .sourceHead = true := by decide
def e303197937494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e303197937494 : Closed e303197937494 ∧ code e303197937494 = 4701244448598 := by decide
theorem cert_e303197937494 : check e303197937494 [[.under]] .sourceHead = true := by decide
def e303197937498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e303197937498 : Closed e303197937498 ∧ code e303197937498 = 4701244448602 := by decide
theorem cert_e303197937498 : check e303197937498 [[.under]] .sourceHead = true := by decide
def e303197937514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e303197937514 : Closed e303197937514 ∧ code e303197937514 = 4701244448618 := by decide
theorem cert_e303197937514 : check e303197937514 [[.under]] .sourceHead = true := by decide
def e303197939422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e303197939422 : Closed e303197939422 ∧ code e303197939422 = 4701244450526 := by decide
theorem cert_e303197939422 : check e303197939422 [[.under]] .sourceHead = true := by decide
def e303197939446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e303197939446 : Closed e303197939446 ∧ code e303197939446 = 4701244450550 := by decide
theorem cert_e303197939446 : check e303197939446 [[.under]] .sourceHead = true := by decide
def e303197939550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e303197939550 : Closed e303197939550 ∧ code e303197939550 = 4701244450654 := by decide
theorem cert_e303197939550 : check e303197939550 [[.under]] .sourceHead = true := by decide
def e303197939566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e303197939566 : Closed e303197939566 ∧ code e303197939566 = 4701244450670 := by decide
theorem cert_e303197939566 : check e303197939566 [[.under]] .sourceHead = true := by decide
def e303197939574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e303197939574 : Closed e303197939574 ∧ code e303197939574 = 4701244450678 := by decide
theorem cert_e303197939574 : check e303197939574 [[.under]] .sourceHead = true := by decide
def e303197939578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e303197939578 : Closed e303197939578 ∧ code e303197939578 = 4701244450682 := by decide
theorem cert_e303197939578 : check e303197939578 [[.under]] .sourceHead = true := by decide
def e303197939638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e303197939638 : Closed e303197939638 ∧ code e303197939638 = 4701244450742 := by decide
theorem cert_e303197939638 : check e303197939638 [[.under]] .sourceHead = true := by decide
def e303197939670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e303197939670 : Closed e303197939670 ∧ code e303197939670 = 4701244450774 := by decide
theorem cert_e303197939670 : check e303197939670 [[.under]] .sourceHead = true := by decide
def e303197939674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e303197939674 : Closed e303197939674 ∧ code e303197939674 = 4701244450778 := by decide
theorem cert_e303197939674 : check e303197939674 [[.under]] .sourceHead = true := by decide
def e303197940190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e303197940190 : Closed e303197940190 ∧ code e303197940190 = 4701244451294 := by decide
theorem cert_e303197940190 : check e303197940190 [[.under]] .sourceHead = true := by decide
def e303197940214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e303197940214 : Closed e303197940214 ∧ code e303197940214 = 4701244451318 := by decide
theorem cert_e303197940214 : check e303197940214 [[.under]] .sourceHead = true := by decide
def e303197940958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e303197940958 : Closed e303197940958 ∧ code e303197940958 = 4701244452062 := by decide
theorem cert_e303197940958 : check e303197940958 [[.under]] .sourceHead = true := by decide
def e303197940974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e303197940974 : Closed e303197940974 ∧ code e303197940974 = 4701244452078 := by decide
theorem cert_e303197940974 : check e303197940974 [[.under]] .sourceHead = true := by decide
def e303197940982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e303197940982 : Closed e303197940982 ∧ code e303197940982 = 4701244452086 := by decide
theorem cert_e303197940982 : check e303197940982 [[.under]] .sourceHead = true := by decide
def e303197940986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e303197940986 : Closed e303197940986 ∧ code e303197940986 = 4701244452090 := by decide
theorem cert_e303197940986 : check e303197940986 [[.under]] .sourceHead = true := by decide
def e303197941366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e303197941366 : Closed e303197941366 ∧ code e303197941366 = 4701244452470 := by decide
theorem cert_e303197941366 : check e303197941366 [[.under]] .sourceHead = true := by decide
def e303197941558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e303197941558 : Closed e303197941558 ∧ code e303197941558 = 4701244452662 := by decide
theorem cert_e303197941558 : check e303197941558 [[.under]] .sourceHead = true := by decide
def e303197941562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e303197941562 : Closed e303197941562 ∧ code e303197941562 = 4701244452666 := by decide
theorem cert_e303197941562 : check e303197941562 [[.under]] .sourceHead = true := by decide
def e303197942622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e303197942622 : Closed e303197942622 ∧ code e303197942622 = 4701244453726 := by decide
theorem cert_e303197942622 : check e303197942622 [[.under]] .sourceHead = true := by decide
def e303197942638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e303197942638 : Closed e303197942638 ∧ code e303197942638 = 4701244453742 := by decide
theorem cert_e303197942638 : check e303197942638 [[.under]] .sourceHead = true := by decide
def e303197942646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e303197942646 : Closed e303197942646 ∧ code e303197942646 = 4701244453750 := by decide
theorem cert_e303197942646 : check e303197942646 [[.under]] .sourceHead = true := by decide
def e303197942650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e303197942650 : Closed e303197942650 ∧ code e303197942650 = 4701244453754 := by decide
theorem cert_e303197942650 : check e303197942650 [[.under]] .sourceHead = true := by decide
def e303197942702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e303197942702 : Closed e303197942702 ∧ code e303197942702 = 4701244453806 := by decide
theorem cert_e303197942702 : check e303197942702 [[.under]] .sourceHead = true := by decide
def e303197942714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e303197942714 : Closed e303197942714 ∧ code e303197942714 = 4701244453818 := by decide
theorem cert_e303197942714 : check e303197942714 [[.under]] .sourceHead = true := by decide
def e303197942742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e303197942742 : Closed e303197942742 ∧ code e303197942742 = 4701244453846 := by decide
theorem cert_e303197942742 : check e303197942742 [[.under]] .sourceHead = true := by decide
def e303197942746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e303197942746 : Closed e303197942746 ∧ code e303197942746 = 4701244453850 := by decide
theorem cert_e303197942746 : check e303197942746 [[.under]] .sourceHead = true := by decide
def e303197942762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e303197942762 : Closed e303197942762 ∧ code e303197942762 = 4701244453866 := by decide
theorem cert_e303197942762 : check e303197942762 [[.under]] .sourceHead = true := by decide
def e303197943006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e303197943006 : Closed e303197943006 ∧ code e303197943006 = 4701244454110 := by decide
theorem cert_e303197943006 : check e303197943006 [[.under]] .sourceHead = true := by decide
def e303197943022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e303197943022 : Closed e303197943022 ∧ code e303197943022 = 4701244454126 := by decide
theorem cert_e303197943022 : check e303197943022 [[.under]] .sourceHead = true := by decide
def e303197943030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e303197943030 : Closed e303197943030 ∧ code e303197943030 = 4701244454134 := by decide
theorem cert_e303197943030 : check e303197943030 [[.under]] .sourceHead = true := by decide
def e303197943034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e303197943034 : Closed e303197943034 ∧ code e303197943034 = 4701244454138 := by decide
theorem cert_e303197943034 : check e303197943034 [[.under]] .sourceHead = true := by decide
def e303197943406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e303197943406 : Closed e303197943406 ∧ code e303197943406 = 4701244454510 := by decide
theorem cert_e303197943406 : check e303197943406 [[.under]] .sourceHead = true := by decide
def e303197943418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e303197943418 : Closed e303197943418 ∧ code e303197943418 = 4701244454522 := by decide
theorem cert_e303197943418 : check e303197943418 [[.under]] .sourceHead = true := by decide
def e303197943606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e303197943606 : Closed e303197943606 ∧ code e303197943606 = 4701244454710 := by decide
theorem cert_e303197943606 : check e303197943606 [[.under]] .sourceHead = true := by decide
def e303197943610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e303197943610 : Closed e303197943610 ∧ code e303197943610 = 4701244454714 := by decide
theorem cert_e303197943610 : check e303197943610 [[.under]] .sourceHead = true := by decide
def e303197943706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e303197943706 : Closed e303197943706 ∧ code e303197943706 = 4701244454810 := by decide
theorem cert_e303197943706 : check e303197943706 [[.under]] .sourceHead = true := by decide
def e303197944246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e303197944246 : Closed e303197944246 ∧ code e303197944246 = 4701244455350 := by decide
theorem cert_e303197944246 : check e303197944246 [[.under]] .sourceHead = true := by decide
def e303197944278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e303197944278 : Closed e303197944278 ∧ code e303197944278 = 4701244455382 := by decide
theorem cert_e303197944278 : check e303197944278 [[.under]] .sourceHead = true := by decide
def e303197944282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e303197944282 : Closed e303197944282 ∧ code e303197944282 = 4701244455386 := by decide
theorem cert_e303197944282 : check e303197944282 [[.under]] .sourceHead = true := by decide
def e303197944438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e303197944438 : Closed e303197944438 ∧ code e303197944438 = 4701244455542 := by decide
theorem cert_e303197944438 : check e303197944438 [[.under]] .sourceHead = true := by decide
def e303197944630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e303197944630 : Closed e303197944630 ∧ code e303197944630 = 4701244455734 := by decide
theorem cert_e303197944630 : check e303197944630 [[.under]] .sourceHead = true := by decide
def e303197944634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e303197944634 : Closed e303197944634 ∧ code e303197944634 = 4701244455738 := by decide
theorem cert_e303197944634 : check e303197944634 [[.under]] .sourceHead = true := by decide
def e303197945046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e303197945046 : Closed e303197945046 ∧ code e303197945046 = 4701244456150 := by decide
theorem cert_e303197945046 : check e303197945046 [[.under]] .sourceHead = true := by decide
def e303197945050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e303197945050 : Closed e303197945050 ∧ code e303197945050 = 4701244456154 := by decide
theorem cert_e303197945050 : check e303197945050 [[.under]] .sourceHead = true := by decide
def e303197945066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e303197945066 : Closed e303197945066 ∧ code e303197945066 = 4701244456170 := by decide
theorem cert_e303197945066 : check e303197945066 [[.under]] .sourceHead = true := by decide
def e303197945142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e303197945142 : Closed e303197945142 ∧ code e303197945142 = 4701244456246 := by decide
theorem cert_e303197945142 : check e303197945142 [[.under]] .sourceHead = true := by decide
def e303197945146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e303197945146 : Closed e303197945146 ∧ code e303197945146 = 4701244456250 := by decide
theorem cert_e303197945146 : check e303197945146 [[.under]] .sourceHead = true := by decide
def e303197945242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e303197945242 : Closed e303197945242 ∧ code e303197945242 = 4701244456346 := by decide
theorem cert_e303197945242 : check e303197945242 [[.under]] .sourceHead = true := by decide
def e303197951710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e303197951710 : Closed e303197951710 ∧ code e303197951710 = 4701244462814 := by decide
theorem cert_e303197951710 : check e303197951710 [[.under]] .sourceHead = true := by decide
def e303197951734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e303197951734 : Closed e303197951734 ∧ code e303197951734 = 4701244462838 := by decide
theorem cert_e303197951734 : check e303197951734 [[.under]] .sourceHead = true := by decide
def e303197951838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e303197951838 : Closed e303197951838 ∧ code e303197951838 = 4701244462942 := by decide
theorem cert_e303197951838 : check e303197951838 [[.under]] .sourceHead = true := by decide
def e303197951854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e303197951854 : Closed e303197951854 ∧ code e303197951854 = 4701244462958 := by decide
theorem cert_e303197951854 : check e303197951854 [[.under]] .sourceHead = true := by decide
def e303197951862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e303197951862 : Closed e303197951862 ∧ code e303197951862 = 4701244462966 := by decide
theorem cert_e303197951862 : check e303197951862 [[.under]] .sourceHead = true := by decide
def e303197951866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e303197951866 : Closed e303197951866 ∧ code e303197951866 = 4701244462970 := by decide
theorem cert_e303197951866 : check e303197951866 [[.under]] .sourceHead = true := by decide
def e303197951926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e303197951926 : Closed e303197951926 ∧ code e303197951926 = 4701244463030 := by decide
theorem cert_e303197951926 : check e303197951926 [[.under]] .sourceHead = true := by decide
def e303197951958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e303197951958 : Closed e303197951958 ∧ code e303197951958 = 4701244463062 := by decide
theorem cert_e303197951958 : check e303197951958 [[.under]] .sourceHead = true := by decide
def e303197951962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e303197951962 : Closed e303197951962 ∧ code e303197951962 = 4701244463066 := by decide
theorem cert_e303197951962 : check e303197951962 [[.under]] .sourceHead = true := by decide
def e303197952478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e303197952478 : Closed e303197952478 ∧ code e303197952478 = 4701244463582 := by decide
theorem cert_e303197952478 : check e303197952478 [[.under]] .sourceHead = true := by decide
def e303197952502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e303197952502 : Closed e303197952502 ∧ code e303197952502 = 4701244463606 := by decide
theorem cert_e303197952502 : check e303197952502 [[.under]] .sourceHead = true := by decide
def e303197953246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e303197953246 : Closed e303197953246 ∧ code e303197953246 = 4701244464350 := by decide
theorem cert_e303197953246 : check e303197953246 [[.under]] .sourceHead = true := by decide
def e303197953262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e303197953262 : Closed e303197953262 ∧ code e303197953262 = 4701244464366 := by decide
theorem cert_e303197953262 : check e303197953262 [[.under]] .sourceHead = true := by decide
def e303197953270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e303197953270 : Closed e303197953270 ∧ code e303197953270 = 4701244464374 := by decide
theorem cert_e303197953270 : check e303197953270 [[.under]] .sourceHead = true := by decide
def e303197953274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e303197953274 : Closed e303197953274 ∧ code e303197953274 = 4701244464378 := by decide
theorem cert_e303197953274 : check e303197953274 [[.under]] .sourceHead = true := by decide
def e303197953654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e303197953654 : Closed e303197953654 ∧ code e303197953654 = 4701244464758 := by decide
theorem cert_e303197953654 : check e303197953654 [[.under]] .sourceHead = true := by decide
def e303197953846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303197953846 : Closed e303197953846 ∧ code e303197953846 = 4701244464950 := by decide
theorem cert_e303197953846 : check e303197953846 [[.under]] .sourceHead = true := by decide
def e303197953850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303197953850 : Closed e303197953850 ∧ code e303197953850 = 4701244464954 := by decide
theorem cert_e303197953850 : check e303197953850 [[.under]] .sourceHead = true := by decide
def e303197965150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e303197965150 : Closed e303197965150 ∧ code e303197965150 = 4701244476254 := by decide
theorem cert_e303197965150 : check e303197965150 [[.under]] .sourceHead = true := by decide
def e303197965166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e303197965166 : Closed e303197965166 ∧ code e303197965166 = 4701244476270 := by decide
theorem cert_e303197965166 : check e303197965166 [[.under]] .sourceHead = true := by decide
def e303197965174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e303197965174 : Closed e303197965174 ∧ code e303197965174 = 4701244476278 := by decide
theorem cert_e303197965174 : check e303197965174 [[.under]] .sourceHead = true := by decide
def e303197965178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e303197965178 : Closed e303197965178 ∧ code e303197965178 = 4701244476282 := by decide
theorem cert_e303197965178 : check e303197965178 [[.under]] .sourceHead = true := by decide
def e303197965230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e303197965230 : Closed e303197965230 ∧ code e303197965230 = 4701244476334 := by decide
theorem cert_e303197965230 : check e303197965230 [[.under]] .sourceHead = true := by decide
def e303197965242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e303197965242 : Closed e303197965242 ∧ code e303197965242 = 4701244476346 := by decide
theorem cert_e303197965242 : check e303197965242 [[.under]] .sourceHead = true := by decide
def e303197965270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e303197965270 : Closed e303197965270 ∧ code e303197965270 = 4701244476374 := by decide
theorem cert_e303197965270 : check e303197965270 [[.under]] .sourceHead = true := by decide
def e303197965274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e303197965274 : Closed e303197965274 ∧ code e303197965274 = 4701244476378 := by decide
theorem cert_e303197965274 : check e303197965274 [[.under]] .sourceHead = true := by decide
def e303197965290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e303197965290 : Closed e303197965290 ∧ code e303197965290 = 4701244476394 := by decide
theorem cert_e303197965290 : check e303197965290 [[.under]] .sourceHead = true := by decide
def e303197965534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e303197965534 : Closed e303197965534 ∧ code e303197965534 = 4701244476638 := by decide
theorem cert_e303197965534 : check e303197965534 [[.under]] .sourceHead = true := by decide
def e303197965550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e303197965550 : Closed e303197965550 ∧ code e303197965550 = 4701244476654 := by decide
theorem cert_e303197965550 : check e303197965550 [[.under]] .sourceHead = true := by decide
def e303197965558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e303197965558 : Closed e303197965558 ∧ code e303197965558 = 4701244476662 := by decide
theorem cert_e303197965558 : check e303197965558 [[.under]] .sourceHead = true := by decide
def e303197965562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e303197965562 : Closed e303197965562 ∧ code e303197965562 = 4701244476666 := by decide
theorem cert_e303197965562 : check e303197965562 [[.under]] .sourceHead = true := by decide
def e303197965934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e303197965934 : Closed e303197965934 ∧ code e303197965934 = 4701244477038 := by decide
theorem cert_e303197965934 : check e303197965934 [[.under]] .sourceHead = true := by decide
def e303197965946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e303197965946 : Closed e303197965946 ∧ code e303197965946 = 4701244477050 := by decide
theorem cert_e303197965946 : check e303197965946 [[.under]] .sourceHead = true := by decide
def e303197966134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303197966134 : Closed e303197966134 ∧ code e303197966134 = 4701244477238 := by decide
theorem cert_e303197966134 : check e303197966134 [[.under]] .sourceHead = true := by decide
def e303197966138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303197966138 : Closed e303197966138 ∧ code e303197966138 = 4701244477242 := by decide
theorem cert_e303197966138 : check e303197966138 [[.under]] .sourceHead = true := by decide
def e303197966234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e303197966234 : Closed e303197966234 ∧ code e303197966234 = 4701244477338 := by decide
theorem cert_e303197966234 : check e303197966234 [[.under]] .sourceHead = true := by decide
def e303197971894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e303197971894 : Closed e303197971894 ∧ code e303197971894 = 4701244482998 := by decide
theorem cert_e303197971894 : check e303197971894 [[.under]] .sourceHead = true := by decide
def e303197971926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e303197971926 : Closed e303197971926 ∧ code e303197971926 = 4701244483030 := by decide
theorem cert_e303197971926 : check e303197971926 [[.under]] .sourceHead = true := by decide
def e303197971930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e303197971930 : Closed e303197971930 ∧ code e303197971930 = 4701244483034 := by decide
theorem cert_e303197971930 : check e303197971930 [[.under]] .sourceHead = true := by decide
def e303197972086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e303197972086 : Closed e303197972086 ∧ code e303197972086 = 4701244483190 := by decide
theorem cert_e303197972086 : check e303197972086 [[.under]] .sourceHead = true := by decide
def e303197972278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303197972278 : Closed e303197972278 ∧ code e303197972278 = 4701244483382 := by decide
theorem cert_e303197972278 : check e303197972278 [[.under]] .sourceHead = true := by decide
def e303197972282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303197972282 : Closed e303197972282 ∧ code e303197972282 = 4701244483386 := by decide
theorem cert_e303197972282 : check e303197972282 [[.under]] .sourceHead = true := by decide
def e303197975254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e303197975254 : Closed e303197975254 ∧ code e303197975254 = 4701244486358 := by decide
theorem cert_e303197975254 : check e303197975254 [[.under]] .sourceHead = true := by decide
def e303197975258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e303197975258 : Closed e303197975258 ∧ code e303197975258 = 4701244486362 := by decide
theorem cert_e303197975258 : check e303197975258 [[.under]] .sourceHead = true := by decide
def e303197975274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e303197975274 : Closed e303197975274 ∧ code e303197975274 = 4701244486378 := by decide
theorem cert_e303197975274 : check e303197975274 [[.under]] .sourceHead = true := by decide
def e303197975350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303197975350 : Closed e303197975350 ∧ code e303197975350 = 4701244486454 := by decide
theorem cert_e303197975350 : check e303197975350 [[.under]] .sourceHead = true := by decide
def e303197975354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303197975354 : Closed e303197975354 ∧ code e303197975354 = 4701244486458 := by decide
theorem cert_e303197975354 : check e303197975354 [[.under]] .sourceHead = true := by decide
def e303197975450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e303197975450 : Closed e303197975450 ∧ code e303197975450 = 4701244486554 := by decide
theorem cert_e303197975450 : check e303197975450 [[.under]] .sourceHead = true := by decide
def e303198200686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e303198200686 : Closed e303198200686 ∧ code e303198200686 = 4701244711790 := by decide
theorem cert_e303198200686 : check e303198200686 [[.under]] .sourceHead = true := by decide
def e303198200694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e303198200694 : Closed e303198200694 ∧ code e303198200694 = 4701244711798 := by decide
theorem cert_e303198200694 : check e303198200694 [[.under]] .sourceHead = true := by decide
def e303198200750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e303198200750 : Closed e303198200750 ∧ code e303198200750 = 4701244711854 := by decide
theorem cert_e303198200750 : check e303198200750 [[.under]] .sourceHead = true := by decide
def e303198200762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e303198200762 : Closed e303198200762 ∧ code e303198200762 = 4701244711866 := by decide
theorem cert_e303198200762 : check e303198200762 [[.under]] .sourceHead = true := by decide
def e303198200790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e303198200790 : Closed e303198200790 ∧ code e303198200790 = 4701244711894 := by decide
theorem cert_e303198200790 : check e303198200790 [[.under]] .sourceHead = true := by decide
def e303198200794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e303198200794 : Closed e303198200794 ∧ code e303198200794 = 4701244711898 := by decide
theorem cert_e303198200794 : check e303198200794 [[.under]] .sourceHead = true := by decide
def e303198202094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e303198202094 : Closed e303198202094 ∧ code e303198202094 = 4701244713198 := by decide
theorem cert_e303198202094 : check e303198202094 [[.under]] .sourceHead = true := by decide
def e303198202102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e303198202102 : Closed e303198202102 ∧ code e303198202102 = 4701244713206 := by decide
theorem cert_e303198202102 : check e303198202102 [[.under]] .sourceHead = true := by decide
def e303198202654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e303198202654 : Closed e303198202654 ∧ code e303198202654 = 4701244713758 := by decide
theorem cert_e303198202654 : check e303198202654 [[.under]] .sourceHead = true := by decide
def e303198202766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e303198202766 : Closed e303198202766 ∧ code e303198202766 = 4701244713870 := by decide
theorem cert_e303198202766 : check e303198202766 [[.under]] .sourceHead = true := by decide
def e303198202990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e303198202990 : Closed e303198202990 ∧ code e303198202990 = 4701244714094 := by decide
theorem cert_e303198202990 : check e303198202990 [[.under]] .sourceHead = true := by decide
def e303198203002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e303198203002 : Closed e303198203002 ∧ code e303198203002 = 4701244714106 := by decide
theorem cert_e303198203002 : check e303198203002 [[.under]] .sourceHead = true := by decide
def e303198203166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e303198203166 : Closed e303198203166 ∧ code e303198203166 = 4701244714270 := by decide
theorem cert_e303198203166 : check e303198203166 [[.under]] .sourceHead = true := by decide
def e303198203334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e303198203334 : Closed e303198203334 ∧ code e303198203334 = 4701244714438 := by decide
theorem cert_e303198203334 : check e303198203334 [[.under]] .sourceHead = true := by decide
end Blc.Floor42
