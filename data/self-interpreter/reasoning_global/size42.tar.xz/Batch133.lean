import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211180874550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211180874550 : Closed e1211180874550 ∧ code e1211180874550 = 5609227385654 := by decide
theorem cert_e1211180874550 : check e1211180874550 [[],[]] .smaller = true := by decide
def e1211180874554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211180874554 : Closed e1211180874554 ∧ code e1211180874554 = 5609227385658 := by decide
theorem cert_e1211180874554 : check e1211180874554 [[],[]] .smaller = true := by decide
def e1211180874966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e1211180874966 : Closed e1211180874966 ∧ code e1211180874966 = 5609227386070 := by decide
theorem cert_e1211180874966 : check e1211180874966 [[],[]] .smaller = true := by decide
def e1211180874970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e1211180874970 : Closed e1211180874970 ∧ code e1211180874970 = 5609227386074 := by decide
theorem cert_e1211180874970 : check e1211180874970 [[],[]] .smaller = true := by decide
def e1211180874986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e1211180874986 : Closed e1211180874986 ∧ code e1211180874986 = 5609227386090 := by decide
theorem cert_e1211180874986 : check e1211180874986 [[],[]] .smaller = true := by decide
def e1211180875062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211180875062 : Closed e1211180875062 ∧ code e1211180875062 = 5609227386166 := by decide
theorem cert_e1211180875062 : check e1211180875062 [[],[]] .smaller = true := by decide
def e1211180875066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211180875066 : Closed e1211180875066 ∧ code e1211180875066 = 5609227386170 := by decide
theorem cert_e1211180875066 : check e1211180875066 [[],[]] .smaller = true := by decide
def e1211180875162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211180875162 : Closed e1211180875162 ∧ code e1211180875162 = 5609227386266 := by decide
theorem cert_e1211180875162 : check e1211180875162 [[],[]] .smaller = true := by decide
def e1211180881630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))))
theorem wire_e1211180881630 : Closed e1211180881630 ∧ code e1211180881630 = 5609227392734 := by decide
theorem cert_e1211180881630 : check e1211180881630 [[],[]] .smaller = true := by decide
def e1211180881654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))))
theorem wire_e1211180881654 : Closed e1211180881654 ∧ code e1211180881654 = 5609227392758 := by decide
theorem cert_e1211180881654 : check e1211180881654 [[],[]] .smaller = true := by decide
def e1211180881758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))))
theorem wire_e1211180881758 : Closed e1211180881758 ∧ code e1211180881758 = 5609227392862 := by decide
theorem cert_e1211180881758 : check e1211180881758 [[],[]] .smaller = true := by decide
def e1211180881774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))))
theorem wire_e1211180881774 : Closed e1211180881774 ∧ code e1211180881774 = 5609227392878 := by decide
theorem cert_e1211180881774 : check e1211180881774 [[],[]] .smaller = true := by decide
def e1211180881782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))))
theorem wire_e1211180881782 : Closed e1211180881782 ∧ code e1211180881782 = 5609227392886 := by decide
theorem cert_e1211180881782 : check e1211180881782 [[],[]] .smaller = true := by decide
def e1211180881786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))))
theorem wire_e1211180881786 : Closed e1211180881786 ∧ code e1211180881786 = 5609227392890 := by decide
theorem cert_e1211180881786 : check e1211180881786 [[],[]] .smaller = true := by decide
def e1211180881846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))))
theorem wire_e1211180881846 : Closed e1211180881846 ∧ code e1211180881846 = 5609227392950 := by decide
theorem cert_e1211180881846 : check e1211180881846 [[],[]] .smaller = true := by decide
def e1211180881878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))))
theorem wire_e1211180881878 : Closed e1211180881878 ∧ code e1211180881878 = 5609227392982 := by decide
theorem cert_e1211180881878 : check e1211180881878 [[],[]] .smaller = true := by decide
def e1211180881882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))))
theorem wire_e1211180881882 : Closed e1211180881882 ∧ code e1211180881882 = 5609227392986 := by decide
theorem cert_e1211180881882 : check e1211180881882 [[],[]] .smaller = true := by decide
def e1211180882398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))))
theorem wire_e1211180882398 : Closed e1211180882398 ∧ code e1211180882398 = 5609227393502 := by decide
theorem cert_e1211180882398 : check e1211180882398 [[],[]] .smaller = true := by decide
def e1211180882422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))))
theorem wire_e1211180882422 : Closed e1211180882422 ∧ code e1211180882422 = 5609227393526 := by decide
theorem cert_e1211180882422 : check e1211180882422 [[],[]] .smaller = true := by decide
def e1211180883166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))))
theorem wire_e1211180883166 : Closed e1211180883166 ∧ code e1211180883166 = 5609227394270 := by decide
theorem cert_e1211180883166 : check e1211180883166 [[],[]] .smaller = true := by decide
def e1211180883182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))))
theorem wire_e1211180883182 : Closed e1211180883182 ∧ code e1211180883182 = 5609227394286 := by decide
theorem cert_e1211180883182 : check e1211180883182 [[],[]] .smaller = true := by decide
def e1211180883190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))))
theorem wire_e1211180883190 : Closed e1211180883190 ∧ code e1211180883190 = 5609227394294 := by decide
theorem cert_e1211180883190 : check e1211180883190 [[],[]] .smaller = true := by decide
def e1211180883194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))))
theorem wire_e1211180883194 : Closed e1211180883194 ∧ code e1211180883194 = 5609227394298 := by decide
theorem cert_e1211180883194 : check e1211180883194 [[],[]] .smaller = true := by decide
def e1211180883574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))))
theorem wire_e1211180883574 : Closed e1211180883574 ∧ code e1211180883574 = 5609227394678 := by decide
theorem cert_e1211180883574 : check e1211180883574 [[],[]] .smaller = true := by decide
def e1211180883766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211180883766 : Closed e1211180883766 ∧ code e1211180883766 = 5609227394870 := by decide
theorem cert_e1211180883766 : check e1211180883766 [[],[]] .smaller = true := by decide
def e1211180883770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211180883770 : Closed e1211180883770 ∧ code e1211180883770 = 5609227394874 := by decide
theorem cert_e1211180883770 : check e1211180883770 [[],[]] .smaller = true := by decide
def e1211180895070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))))
theorem wire_e1211180895070 : Closed e1211180895070 ∧ code e1211180895070 = 5609227406174 := by decide
theorem cert_e1211180895070 : check e1211180895070 [[],[]] .smaller = true := by decide
def e1211180895086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e1211180895086 : Closed e1211180895086 ∧ code e1211180895086 = 5609227406190 := by decide
theorem cert_e1211180895086 : check e1211180895086 [[],[]] .smaller = true := by decide
def e1211180895094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e1211180895094 : Closed e1211180895094 ∧ code e1211180895094 = 5609227406198 := by decide
theorem cert_e1211180895094 : check e1211180895094 [[],[]] .smaller = true := by decide
def e1211180895098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))))
theorem wire_e1211180895098 : Closed e1211180895098 ∧ code e1211180895098 = 5609227406202 := by decide
theorem cert_e1211180895098 : check e1211180895098 [[],[]] .smaller = true := by decide
def e1211180895150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e1211180895150 : Closed e1211180895150 ∧ code e1211180895150 = 5609227406254 := by decide
theorem cert_e1211180895150 : check e1211180895150 [[],[]] .smaller = true := by decide
def e1211180895162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e1211180895162 : Closed e1211180895162 ∧ code e1211180895162 = 5609227406266 := by decide
theorem cert_e1211180895162 : check e1211180895162 [[],[]] .smaller = true := by decide
def e1211180895190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e1211180895190 : Closed e1211180895190 ∧ code e1211180895190 = 5609227406294 := by decide
theorem cert_e1211180895190 : check e1211180895190 [[],[]] .smaller = true := by decide
def e1211180895194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e1211180895194 : Closed e1211180895194 ∧ code e1211180895194 = 5609227406298 := by decide
theorem cert_e1211180895194 : check e1211180895194 [[],[]] .smaller = true := by decide
def e1211180895210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))))
theorem wire_e1211180895210 : Closed e1211180895210 ∧ code e1211180895210 = 5609227406314 := by decide
theorem cert_e1211180895210 : check e1211180895210 [[],[]] .smaller = true := by decide
def e1211180895454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))))
theorem wire_e1211180895454 : Closed e1211180895454 ∧ code e1211180895454 = 5609227406558 := by decide
theorem cert_e1211180895454 : check e1211180895454 [[],[]] .smaller = true := by decide
def e1211180895470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e1211180895470 : Closed e1211180895470 ∧ code e1211180895470 = 5609227406574 := by decide
theorem cert_e1211180895470 : check e1211180895470 [[],[]] .smaller = true := by decide
def e1211180895478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e1211180895478 : Closed e1211180895478 ∧ code e1211180895478 = 5609227406582 := by decide
theorem cert_e1211180895478 : check e1211180895478 [[],[]] .smaller = true := by decide
def e1211180895482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))))
theorem wire_e1211180895482 : Closed e1211180895482 ∧ code e1211180895482 = 5609227406586 := by decide
theorem cert_e1211180895482 : check e1211180895482 [[],[]] .smaller = true := by decide
def e1211180895854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e1211180895854 : Closed e1211180895854 ∧ code e1211180895854 = 5609227406958 := by decide
theorem cert_e1211180895854 : check e1211180895854 [[],[]] .smaller = true := by decide
def e1211180895866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e1211180895866 : Closed e1211180895866 ∧ code e1211180895866 = 5609227406970 := by decide
theorem cert_e1211180895866 : check e1211180895866 [[],[]] .smaller = true := by decide
def e1211180896054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211180896054 : Closed e1211180896054 ∧ code e1211180896054 = 5609227407158 := by decide
theorem cert_e1211180896054 : check e1211180896054 [[],[]] .smaller = true := by decide
def e1211180896058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211180896058 : Closed e1211180896058 ∧ code e1211180896058 = 5609227407162 := by decide
theorem cert_e1211180896058 : check e1211180896058 [[],[]] .smaller = true := by decide
def e1211180896154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))))
theorem wire_e1211180896154 : Closed e1211180896154 ∧ code e1211180896154 = 5609227407258 := by decide
theorem cert_e1211180896154 : check e1211180896154 [[],[]] .smaller = true := by decide
def e1211180901814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))))
theorem wire_e1211180901814 : Closed e1211180901814 ∧ code e1211180901814 = 5609227412918 := by decide
theorem cert_e1211180901814 : check e1211180901814 [[],[]] .smaller = true := by decide
def e1211180901846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))))
theorem wire_e1211180901846 : Closed e1211180901846 ∧ code e1211180901846 = 5609227412950 := by decide
theorem cert_e1211180901846 : check e1211180901846 [[],[]] .smaller = true := by decide
def e1211180901850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))))
theorem wire_e1211180901850 : Closed e1211180901850 ∧ code e1211180901850 = 5609227412954 := by decide
theorem cert_e1211180901850 : check e1211180901850 [[],[]] .smaller = true := by decide
def e1211180902006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))))
theorem wire_e1211180902006 : Closed e1211180902006 ∧ code e1211180902006 = 5609227413110 := by decide
theorem cert_e1211180902006 : check e1211180902006 [[],[]] .smaller = true := by decide
def e1211180902198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211180902198 : Closed e1211180902198 ∧ code e1211180902198 = 5609227413302 := by decide
theorem cert_e1211180902198 : check e1211180902198 [[],[]] .smaller = true := by decide
def e1211180902202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211180902202 : Closed e1211180902202 ∧ code e1211180902202 = 5609227413306 := by decide
theorem cert_e1211180902202 : check e1211180902202 [[],[]] .smaller = true := by decide
def e1211180905174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e1211180905174 : Closed e1211180905174 ∧ code e1211180905174 = 5609227416278 := by decide
theorem cert_e1211180905174 : check e1211180905174 [[],[]] .smaller = true := by decide
def e1211180905178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e1211180905178 : Closed e1211180905178 ∧ code e1211180905178 = 5609227416282 := by decide
theorem cert_e1211180905178 : check e1211180905178 [[],[]] .smaller = true := by decide
def e1211180905194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e1211180905194 : Closed e1211180905194 ∧ code e1211180905194 = 5609227416298 := by decide
theorem cert_e1211180905194 : check e1211180905194 [[],[]] .smaller = true := by decide
def e1211180905270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211180905270 : Closed e1211180905270 ∧ code e1211180905270 = 5609227416374 := by decide
theorem cert_e1211180905270 : check e1211180905270 [[],[]] .smaller = true := by decide
def e1211180905274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211180905274 : Closed e1211180905274 ∧ code e1211180905274 = 5609227416378 := by decide
theorem cert_e1211180905274 : check e1211180905274 [[],[]] .smaller = true := by decide
def e1211180905370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e1211180905370 : Closed e1211180905370 ∧ code e1211180905370 = 5609227416474 := by decide
theorem cert_e1211180905370 : check e1211180905370 [[],[]] .smaller = true := by decide
def e1211181130606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))))
theorem wire_e1211181130606 : Closed e1211181130606 ∧ code e1211181130606 = 5609227641710 := by decide
theorem cert_e1211181130606 : check e1211181130606 [[],[]] .smaller = true := by decide
def e1211181130614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))))
theorem wire_e1211181130614 : Closed e1211181130614 ∧ code e1211181130614 = 5609227641718 := by decide
theorem cert_e1211181130614 : check e1211181130614 [[],[]] .smaller = true := by decide
def e1211181130670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))))
theorem wire_e1211181130670 : Closed e1211181130670 ∧ code e1211181130670 = 5609227641774 := by decide
theorem cert_e1211181130670 : check e1211181130670 [[],[]] .smaller = true := by decide
def e1211181130682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))))
theorem wire_e1211181130682 : Closed e1211181130682 ∧ code e1211181130682 = 5609227641786 := by decide
theorem cert_e1211181130682 : check e1211181130682 [[],[]] .smaller = true := by decide
def e1211181130710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))))
theorem wire_e1211181130710 : Closed e1211181130710 ∧ code e1211181130710 = 5609227641814 := by decide
theorem cert_e1211181130710 : check e1211181130710 [[],[]] .smaller = true := by decide
def e1211181130714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))))
theorem wire_e1211181130714 : Closed e1211181130714 ∧ code e1211181130714 = 5609227641818 := by decide
theorem cert_e1211181130714 : check e1211181130714 [[],[]] .smaller = true := by decide
def e1211181132014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211181132014 : Closed e1211181132014 ∧ code e1211181132014 = 5609227643118 := by decide
theorem cert_e1211181132014 : check e1211181132014 [[],[]] .smaller = true := by decide
def e1211181132022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211181132022 : Closed e1211181132022 ∧ code e1211181132022 = 5609227643126 := by decide
theorem cert_e1211181132022 : check e1211181132022 [[],[]] .smaller = true := by decide
def e1211181132574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211181132574 : Closed e1211181132574 ∧ code e1211181132574 = 5609227643678 := by decide
theorem cert_e1211181132574 : check e1211181132574 [[],[]] .smaller = true := by decide
def e1211181132670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 5)))))))))
theorem wire_e1211181132670 : Closed e1211181132670 ∧ code e1211181132670 = 5609227643774 := by decide
theorem cert_e1211181132670 : check e1211181132670 [[],[]] .three = true := by decide
def e1211181132686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211181132686 : Closed e1211181132686 ∧ code e1211181132686 = 5609227643790 := by decide
theorem cert_e1211181132686 : check e1211181132686 [[],[]] .smaller = true := by decide
def e1211181132734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 4)))))))))
theorem wire_e1211181132734 : Closed e1211181132734 ∧ code e1211181132734 = 5609227643838 := by decide
theorem cert_e1211181132734 : check e1211181132734 [[],[]] .smaller = true := by decide
def e1211181132782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 2)))))))))
theorem wire_e1211181132782 : Closed e1211181132782 ∧ code e1211181132782 = 5609227643886 := by decide
theorem cert_e1211181132782 : check e1211181132782 [[],[]] .smaller = true := by decide
def e1211181132790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 5)) (.var 1)))))))))
theorem wire_e1211181132790 : Closed e1211181132790 ∧ code e1211181132790 = 5609227643894 := by decide
theorem cert_e1211181132790 : check e1211181132790 [[],[]] .three = true := by decide
def e1211181132910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211181132910 : Closed e1211181132910 ∧ code e1211181132910 = 5609227644014 := by decide
theorem cert_e1211181132910 : check e1211181132910 [[],[]] .smaller = true := by decide
def e1211181132922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211181132922 : Closed e1211181132922 ∧ code e1211181132922 = 5609227644026 := by decide
theorem cert_e1211181132922 : check e1211181132922 [[],[]] .smaller = true := by decide
def e1211181133086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211181133086 : Closed e1211181133086 ∧ code e1211181133086 = 5609227644190 := by decide
theorem cert_e1211181133086 : check e1211181133086 [[],[]] .smaller = true := by decide
def e1211181133182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 5)))))))))
theorem wire_e1211181133182 : Closed e1211181133182 ∧ code e1211181133182 = 5609227644286 := by decide
theorem cert_e1211181133182 : check e1211181133182 [[],[]] .three = true := by decide
def e1211181133246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 4)))))))))
theorem wire_e1211181133246 : Closed e1211181133246 ∧ code e1211181133246 = 5609227644350 := by decide
theorem cert_e1211181133246 : check e1211181133246 [[],[]] .smaller = true := by decide
def e1211181133254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211181133254 : Closed e1211181133254 ∧ code e1211181133254 = 5609227644358 := by decide
theorem cert_e1211181133254 : check e1211181133254 [[],[]] .smaller = true := by decide
def e1211181133302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 1)))))))))
theorem wire_e1211181133302 : Closed e1211181133302 ∧ code e1211181133302 = 5609227644406 := by decide
theorem cert_e1211181133302 : check e1211181133302 [[],[]] .smaller = true := by decide
def e1211181133306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 5)) (.var 0)))))))))
theorem wire_e1211181133306 : Closed e1211181133306 ∧ code e1211181133306 = 5609227644410 := by decide
theorem cert_e1211181133306 : check e1211181133306 [[],[]] .three = true := by decide
def e1211181133366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211181133366 : Closed e1211181133366 ∧ code e1211181133366 = 5609227644470 := by decide
theorem cert_e1211181133366 : check e1211181133366 [[],[]] .smaller = true := by decide
def e1211181133370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211181133370 : Closed e1211181133370 ∧ code e1211181133370 = 5609227644474 := by decide
theorem cert_e1211181133370 : check e1211181133370 [[],[]] .smaller = true := by decide
def e1211181133454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211181133454 : Closed e1211181133454 ∧ code e1211181133454 = 5609227644558 := by decide
theorem cert_e1211181133454 : check e1211181133454 [[],[]] .smaller = true := by decide
def e1211181133502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 4)))))))))
theorem wire_e1211181133502 : Closed e1211181133502 ∧ code e1211181133502 = 5609227644606 := by decide
theorem cert_e1211181133502 : check e1211181133502 [[],[]] .smaller = true := by decide
def e1211181133510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211181133510 : Closed e1211181133510 ∧ code e1211181133510 = 5609227644614 := by decide
theorem cert_e1211181133510 : check e1211181133510 [[],[]] .smaller = true := by decide
def e1211181133562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 4)) (.var 0)))))))))
theorem wire_e1211181133562 : Closed e1211181133562 ∧ code e1211181133562 = 5609227644666 := by decide
theorem cert_e1211181133562 : check e1211181133562 [[],[]] .smaller = true := by decide
def e1211181133742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 2)))))))))
theorem wire_e1211181133742 : Closed e1211181133742 ∧ code e1211181133742 = 5609227644846 := by decide
theorem cert_e1211181133742 : check e1211181133742 [[],[]] .smaller = true := by decide
def e1211181133750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 1)))))))))
theorem wire_e1211181133750 : Closed e1211181133750 ∧ code e1211181133750 = 5609227644854 := by decide
theorem cert_e1211181133750 : check e1211181133750 [[],[]] .smaller = true := by decide
def e1211181133754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 2)) (.var 0)))))))))
theorem wire_e1211181133754 : Closed e1211181133754 ∧ code e1211181133754 = 5609227644858 := by decide
theorem cert_e1211181133754 : check e1211181133754 [[],[]] .smaller = true := by decide
def e1211181133782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 5)) (.var 0)) (.var 1)))))))))
theorem wire_e1211181133782 : Closed e1211181133782 ∧ code e1211181133782 = 5609227644886 := by decide
theorem cert_e1211181133782 : check e1211181133782 [[],[]] .three = true := by decide
def e1211181133786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 5)) (.var 1)) (.var 0)))))))))
theorem wire_e1211181133786 : Closed e1211181133786 ∧ code e1211181133786 = 5609227644890 := by decide
theorem cert_e1211181133786 : check e1211181133786 [[],[]] .three = true := by decide
def e1211181134254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))))
theorem wire_e1211181134254 : Closed e1211181134254 ∧ code e1211181134254 = 5609227645358 := by decide
theorem cert_e1211181134254 : check e1211181134254 [[],[]] .smaller = true := by decide
def e1211181134266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))))
theorem wire_e1211181134266 : Closed e1211181134266 ∧ code e1211181134266 = 5609227645370 := by decide
theorem cert_e1211181134266 : check e1211181134266 [[],[]] .smaller = true := by decide
def e1211181134314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))))
theorem wire_e1211181134314 : Closed e1211181134314 ∧ code e1211181134314 = 5609227645418 := by decide
theorem cert_e1211181134314 : check e1211181134314 [[],[]] .smaller = true := by decide
def e1211181134958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211181134958 : Closed e1211181134958 ∧ code e1211181134958 = 5609227646062 := by decide
theorem cert_e1211181134958 : check e1211181134958 [[],[]] .smaller = true := by decide
def e1211181134970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211181134970 : Closed e1211181134970 ∧ code e1211181134970 = 5609227646074 := by decide
theorem cert_e1211181134970 : check e1211181134970 [[],[]] .smaller = true := by decide
def e1211181135134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211181135134 : Closed e1211181135134 ∧ code e1211181135134 = 5609227646238 := by decide
theorem cert_e1211181135134 : check e1211181135134 [[],[]] .smaller = true := by decide
def e1211181135230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 5)))))))))
theorem wire_e1211181135230 : Closed e1211181135230 ∧ code e1211181135230 = 5609227646334 := by decide
theorem cert_e1211181135230 : check e1211181135230 [[],[]] .three = true := by decide
def e1211181135294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 4)))))))))
theorem wire_e1211181135294 : Closed e1211181135294 ∧ code e1211181135294 = 5609227646398 := by decide
theorem cert_e1211181135294 : check e1211181135294 [[],[]] .smaller = true := by decide
def e1211181135302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211181135302 : Closed e1211181135302 ∧ code e1211181135302 = 5609227646406 := by decide
theorem cert_e1211181135302 : check e1211181135302 [[],[]] .smaller = true := by decide
def e1211181135350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 1)))))))))
theorem wire_e1211181135350 : Closed e1211181135350 ∧ code e1211181135350 = 5609227646454 := by decide
theorem cert_e1211181135350 : check e1211181135350 [[],[]] .smaller = true := by decide
def e1211181135354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 5)) (.var 0)))))))))
theorem wire_e1211181135354 : Closed e1211181135354 ∧ code e1211181135354 = 5609227646458 := by decide
theorem cert_e1211181135354 : check e1211181135354 [[],[]] .three = true := by decide
def e1211181135550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 4)))))))))
theorem wire_e1211181135550 : Closed e1211181135550 ∧ code e1211181135550 = 5609227646654 := by decide
theorem cert_e1211181135550 : check e1211181135550 [[],[]] .smaller = true := by decide
def e1211181135610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 4)) (.var 0)))))))))
theorem wire_e1211181135610 : Closed e1211181135610 ∧ code e1211181135610 = 5609227646714 := by decide
theorem cert_e1211181135610 : check e1211181135610 [[],[]] .smaller = true := by decide
def e1211181135642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211181135642 : Closed e1211181135642 ∧ code e1211181135642 = 5609227646746 := by decide
theorem cert_e1211181135642 : check e1211181135642 [[],[]] .smaller = true := by decide
def e1211181135686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211181135686 : Closed e1211181135686 ∧ code e1211181135686 = 5609227646790 := by decide
theorem cert_e1211181135686 : check e1211181135686 [[],[]] .smaller = true := by decide
def e1211181135830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 1)))))))))
theorem wire_e1211181135830 : Closed e1211181135830 ∧ code e1211181135830 = 5609227646934 := by decide
theorem cert_e1211181135830 : check e1211181135830 [[],[]] .smaller = true := by decide
def e1211181135834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 1)) (.var 0)))))))))
theorem wire_e1211181135834 : Closed e1211181135834 ∧ code e1211181135834 = 5609227646938 := by decide
theorem cert_e1211181135834 : check e1211181135834 [[],[]] .smaller = true := by decide
def e1211181135850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 5)) (.var 0)) (.var 0)))))))))
theorem wire_e1211181135850 : Closed e1211181135850 ∧ code e1211181135850 = 5609227646954 := by decide
theorem cert_e1211181135850 : check e1211181135850 [[],[]] .three = true := by decide
def e1211181136086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))))
theorem wire_e1211181136086 : Closed e1211181136086 ∧ code e1211181136086 = 5609227647190 := by decide
theorem cert_e1211181136086 : check e1211181136086 [[],[]] .smaller = true := by decide
def e1211181136090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))))
theorem wire_e1211181136090 : Closed e1211181136090 ∧ code e1211181136090 = 5609227647194 := by decide
theorem cert_e1211181136090 : check e1211181136090 [[],[]] .smaller = true := by decide
def e1211181136106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))))
theorem wire_e1211181136106 : Closed e1211181136106 ∧ code e1211181136106 = 5609227647210 := by decide
theorem cert_e1211181136106 : check e1211181136106 [[],[]] .smaller = true := by decide
def e1211181136438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211181136438 : Closed e1211181136438 ∧ code e1211181136438 = 5609227647542 := by decide
theorem cert_e1211181136438 : check e1211181136438 [[],[]] .smaller = true := by decide
def e1211181136442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211181136442 : Closed e1211181136442 ∧ code e1211181136442 = 5609227647546 := by decide
theorem cert_e1211181136442 : check e1211181136442 [[],[]] .smaller = true := by decide
def e1211181136526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211181136526 : Closed e1211181136526 ∧ code e1211181136526 = 5609227647630 := by decide
theorem cert_e1211181136526 : check e1211181136526 [[],[]] .smaller = true := by decide
def e1211181136574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 4)))))))))
theorem wire_e1211181136574 : Closed e1211181136574 ∧ code e1211181136574 = 5609227647678 := by decide
theorem cert_e1211181136574 : check e1211181136574 [[],[]] .smaller = true := by decide
def e1211181136582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211181136582 : Closed e1211181136582 ∧ code e1211181136582 = 5609227647686 := by decide
theorem cert_e1211181136582 : check e1211181136582 [[],[]] .smaller = true := by decide
def e1211181136634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 4)) (.var 0)))))))))
theorem wire_e1211181136634 : Closed e1211181136634 ∧ code e1211181136634 = 5609227647738 := by decide
theorem cert_e1211181136634 : check e1211181136634 [[],[]] .smaller = true := by decide
def e1211181136666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211181136666 : Closed e1211181136666 ∧ code e1211181136666 = 5609227647770 := by decide
theorem cert_e1211181136666 : check e1211181136666 [[],[]] .smaller = true := by decide
def e1211181136710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211181136710 : Closed e1211181136710 ∧ code e1211181136710 = 5609227647814 := by decide
theorem cert_e1211181136710 : check e1211181136710 [[],[]] .smaller = true := by decide
def e1211181136874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 0)) (.var 0)))))))))
theorem wire_e1211181136874 : Closed e1211181136874 ∧ code e1211181136874 = 5609227647978 := by decide
theorem cert_e1211181136874 : check e1211181136874 [[],[]] .smaller = true := by decide
def e1211181137582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e1211181137582 : Closed e1211181137582 ∧ code e1211181137582 = 5609227648686 := by decide
theorem cert_e1211181137582 : check e1211181137582 [[],[]] .smaller = true := by decide
def e1211181137590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e1211181137590 : Closed e1211181137590 ∧ code e1211181137590 = 5609227648694 := by decide
theorem cert_e1211181137590 : check e1211181137590 [[],[]] .smaller = true := by decide
def e1211181137594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e1211181137594 : Closed e1211181137594 ∧ code e1211181137594 = 5609227648698 := by decide
theorem cert_e1211181137594 : check e1211181137594 [[],[]] .smaller = true := by decide
def e1211181137622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e1211181137622 : Closed e1211181137622 ∧ code e1211181137622 = 5609227648726 := by decide
theorem cert_e1211181137622 : check e1211181137622 [[],[]] .smaller = true := by decide
def e1211181137626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e1211181137626 : Closed e1211181137626 ∧ code e1211181137626 = 5609227648730 := by decide
theorem cert_e1211181137626 : check e1211181137626 [[],[]] .smaller = true := by decide
def e1211181137642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e1211181137642 : Closed e1211181137642 ∧ code e1211181137642 = 5609227648746 := by decide
theorem cert_e1211181137642 : check e1211181137642 [[],[]] .smaller = true := by decide
def e1211181137750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211181137750 : Closed e1211181137750 ∧ code e1211181137750 = 5609227648854 := by decide
theorem cert_e1211181137750 : check e1211181137750 [[],[]] .three = true := by decide
def e1211181137754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211181137754 : Closed e1211181137754 ∧ code e1211181137754 = 5609227648858 := by decide
theorem cert_e1211181137754 : check e1211181137754 [[],[]] .three = true := by decide
def e1211181137770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211181137770 : Closed e1211181137770 ∧ code e1211181137770 = 5609227648874 := by decide
theorem cert_e1211181137770 : check e1211181137770 [[],[]] .three = true := by decide
def e1211181141230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211181141230 : Closed e1211181141230 ∧ code e1211181141230 = 5609227652334 := by decide
theorem cert_e1211181141230 : check e1211181141230 [[],[]] .smaller = true := by decide
def e1211181141238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211181141238 : Closed e1211181141238 ∧ code e1211181141238 = 5609227652342 := by decide
theorem cert_e1211181141238 : check e1211181141238 [[],[]] .smaller = true := by decide
def e1211181141614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211181141614 : Closed e1211181141614 ∧ code e1211181141614 = 5609227652718 := by decide
theorem cert_e1211181141614 : check e1211181141614 [[],[]] .smaller = true := by decide
def e1211181141626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211181141626 : Closed e1211181141626 ∧ code e1211181141626 = 5609227652730 := by decide
theorem cert_e1211181141626 : check e1211181141626 [[],[]] .smaller = true := by decide
def e1211181141814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211181141814 : Closed e1211181141814 ∧ code e1211181141814 = 5609227652918 := by decide
theorem cert_e1211181141814 : check e1211181141814 [[],[]] .smaller = true := by decide
def e1211181141818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211181141818 : Closed e1211181141818 ∧ code e1211181141818 = 5609227652922 := by decide
theorem cert_e1211181141818 : check e1211181141818 [[],[]] .smaller = true := by decide
def e1211181144302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))))
theorem wire_e1211181144302 : Closed e1211181144302 ∧ code e1211181144302 = 5609227655406 := by decide
theorem cert_e1211181144302 : check e1211181144302 [[],[]] .smaller = true := by decide
def e1211181144310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))))
theorem wire_e1211181144310 : Closed e1211181144310 ∧ code e1211181144310 = 5609227655414 := by decide
theorem cert_e1211181144310 : check e1211181144310 [[],[]] .smaller = true := by decide
def e1211181144862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))))
theorem wire_e1211181144862 : Closed e1211181144862 ∧ code e1211181144862 = 5609227655966 := by decide
theorem cert_e1211181144862 : check e1211181144862 [[],[]] .smaller = true := by decide
def e1211181144958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 5)))))))))
theorem wire_e1211181144958 : Closed e1211181144958 ∧ code e1211181144958 = 5609227656062 := by decide
theorem cert_e1211181144958 : check e1211181144958 [[],[]] .three = true := by decide
def e1211181144974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))))
theorem wire_e1211181144974 : Closed e1211181144974 ∧ code e1211181144974 = 5609227656078 := by decide
theorem cert_e1211181144974 : check e1211181144974 [[],[]] .smaller = true := by decide
def e1211181145022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 4)))))))))
theorem wire_e1211181145022 : Closed e1211181145022 ∧ code e1211181145022 = 5609227656126 := by decide
theorem cert_e1211181145022 : check e1211181145022 [[],[]] .smaller = true := by decide
def e1211181145070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 2)))))))))
theorem wire_e1211181145070 : Closed e1211181145070 ∧ code e1211181145070 = 5609227656174 := by decide
theorem cert_e1211181145070 : check e1211181145070 [[],[]] .smaller = true := by decide
def e1211181145078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 5))) (.var 1)))))))))
theorem wire_e1211181145078 : Closed e1211181145078 ∧ code e1211181145078 = 5609227656182 := by decide
theorem cert_e1211181145078 : check e1211181145078 [[],[]] .three = true := by decide
def e1211181145198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))))
theorem wire_e1211181145198 : Closed e1211181145198 ∧ code e1211181145198 = 5609227656302 := by decide
theorem cert_e1211181145198 : check e1211181145198 [[],[]] .smaller = true := by decide
def e1211181145210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))))
theorem wire_e1211181145210 : Closed e1211181145210 ∧ code e1211181145210 = 5609227656314 := by decide
theorem cert_e1211181145210 : check e1211181145210 [[],[]] .smaller = true := by decide
def e1211181145374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))))
theorem wire_e1211181145374 : Closed e1211181145374 ∧ code e1211181145374 = 5609227656478 := by decide
theorem cert_e1211181145374 : check e1211181145374 [[],[]] .smaller = true := by decide
def e1211181145470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 5)))))))))
theorem wire_e1211181145470 : Closed e1211181145470 ∧ code e1211181145470 = 5609227656574 := by decide
theorem cert_e1211181145470 : check e1211181145470 [[],[]] .three = true := by decide
def e1211181145534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 4)))))))))
theorem wire_e1211181145534 : Closed e1211181145534 ∧ code e1211181145534 = 5609227656638 := by decide
theorem cert_e1211181145534 : check e1211181145534 [[],[]] .smaller = true := by decide
def e1211181145542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))))
theorem wire_e1211181145542 : Closed e1211181145542 ∧ code e1211181145542 = 5609227656646 := by decide
theorem cert_e1211181145542 : check e1211181145542 [[],[]] .smaller = true := by decide
def e1211181145590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 1)))))))))
theorem wire_e1211181145590 : Closed e1211181145590 ∧ code e1211181145590 = 5609227656694 := by decide
theorem cert_e1211181145590 : check e1211181145590 [[],[]] .smaller = true := by decide
def e1211181145594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 5))) (.var 0)))))))))
theorem wire_e1211181145594 : Closed e1211181145594 ∧ code e1211181145594 = 5609227656698 := by decide
theorem cert_e1211181145594 : check e1211181145594 [[],[]] .three = true := by decide
def e1211181145654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))))
theorem wire_e1211181145654 : Closed e1211181145654 ∧ code e1211181145654 = 5609227656758 := by decide
theorem cert_e1211181145654 : check e1211181145654 [[],[]] .smaller = true := by decide
def e1211181145658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e1211181145658 : Closed e1211181145658 ∧ code e1211181145658 = 5609227656762 := by decide
theorem cert_e1211181145658 : check e1211181145658 [[],[]] .smaller = true := by decide
def e1211181145742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))))
theorem wire_e1211181145742 : Closed e1211181145742 ∧ code e1211181145742 = 5609227656846 := by decide
theorem cert_e1211181145742 : check e1211181145742 [[],[]] .smaller = true := by decide
def e1211181145790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 4)))))))))
theorem wire_e1211181145790 : Closed e1211181145790 ∧ code e1211181145790 = 5609227656894 := by decide
theorem cert_e1211181145790 : check e1211181145790 [[],[]] .smaller = true := by decide
def e1211181145798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))))
theorem wire_e1211181145798 : Closed e1211181145798 ∧ code e1211181145798 = 5609227656902 := by decide
theorem cert_e1211181145798 : check e1211181145798 [[],[]] .smaller = true := by decide
def e1211181145850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 4))) (.var 0)))))))))
theorem wire_e1211181145850 : Closed e1211181145850 ∧ code e1211181145850 = 5609227656954 := by decide
theorem cert_e1211181145850 : check e1211181145850 [[],[]] .smaller = true := by decide
def e1211181146030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 2)))))))))
theorem wire_e1211181146030 : Closed e1211181146030 ∧ code e1211181146030 = 5609227657134 := by decide
theorem cert_e1211181146030 : check e1211181146030 [[],[]] .smaller = true := by decide
def e1211181146038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 1)))))))))
theorem wire_e1211181146038 : Closed e1211181146038 ∧ code e1211181146038 = 5609227657142 := by decide
theorem cert_e1211181146038 : check e1211181146038 [[],[]] .smaller = true := by decide
def e1211181146042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 2))) (.var 0)))))))))
theorem wire_e1211181146042 : Closed e1211181146042 ∧ code e1211181146042 = 5609227657146 := by decide
theorem cert_e1211181146042 : check e1211181146042 [[],[]] .smaller = true := by decide
def e1211181146070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 5) (.var 0))) (.var 1)))))))))
theorem wire_e1211181146070 : Closed e1211181146070 ∧ code e1211181146070 = 5609227657174 := by decide
theorem cert_e1211181146070 : check e1211181146070 [[],[]] .three = true := by decide
end Blc.Floor42
