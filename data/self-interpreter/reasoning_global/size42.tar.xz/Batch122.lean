import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209167615838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1209167615838 : Closed e1209167615838 ∧ code e1209167615838 = 5607214126942 := by decide
theorem cert_e1209167615838 : check e1209167615838 [[],[]] .three = true := by decide
def e1209167615854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1209167615854 : Closed e1209167615854 ∧ code e1209167615854 = 5607214126958 := by decide
theorem cert_e1209167615854 : check e1209167615854 [[],[]] .smaller = true := by decide
def e1209167615862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1209167615862 : Closed e1209167615862 ∧ code e1209167615862 = 5607214126966 := by decide
theorem cert_e1209167615862 : check e1209167615862 [[],[]] .smaller = true := by decide
def e1209167615866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1209167615866 : Closed e1209167615866 ∧ code e1209167615866 = 5607214126970 := by decide
theorem cert_e1209167615866 : check e1209167615866 [[],[]] .three = true := by decide
def e1209167615926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1209167615926 : Closed e1209167615926 ∧ code e1209167615926 = 5607214127030 := by decide
theorem cert_e1209167615926 : check e1209167615926 [[],[]] .smaller = true := by decide
def e1209167615958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1209167615958 : Closed e1209167615958 ∧ code e1209167615958 = 5607214127062 := by decide
theorem cert_e1209167615958 : check e1209167615958 [[],[]] .three = true := by decide
def e1209167615962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1209167615962 : Closed e1209167615962 ∧ code e1209167615962 = 5607214127066 := by decide
theorem cert_e1209167615962 : check e1209167615962 [[],[]] .three = true := by decide
def e1209167616478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209167616478 : Closed e1209167616478 ∧ code e1209167616478 = 5607214127582 := by decide
theorem cert_e1209167616478 : check e1209167616478 [[],[]] .three = true := by decide
def e1209167616502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209167616502 : Closed e1209167616502 ∧ code e1209167616502 = 5607214127606 := by decide
theorem cert_e1209167616502 : check e1209167616502 [[],[]] .three = true := by decide
def e1209167617246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209167617246 : Closed e1209167617246 ∧ code e1209167617246 = 5607214128350 := by decide
theorem cert_e1209167617246 : check e1209167617246 [[],[]] .three = true := by decide
def e1209167617262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209167617262 : Closed e1209167617262 ∧ code e1209167617262 = 5607214128366 := by decide
theorem cert_e1209167617262 : check e1209167617262 [[],[]] .smaller = true := by decide
def e1209167617270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209167617270 : Closed e1209167617270 ∧ code e1209167617270 = 5607214128374 := by decide
theorem cert_e1209167617270 : check e1209167617270 [[],[]] .smaller = true := by decide
def e1209167617274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209167617274 : Closed e1209167617274 ∧ code e1209167617274 = 5607214128378 := by decide
theorem cert_e1209167617274 : check e1209167617274 [[],[]] .three = true := by decide
def e1209167617654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209167617654 : Closed e1209167617654 ∧ code e1209167617654 = 5607214128758 := by decide
theorem cert_e1209167617654 : check e1209167617654 [[],[]] .smaller = true := by decide
def e1209167617846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209167617846 : Closed e1209167617846 ∧ code e1209167617846 = 5607214128950 := by decide
theorem cert_e1209167617846 : check e1209167617846 [[],[]] .three = true := by decide
def e1209167617850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209167617850 : Closed e1209167617850 ∧ code e1209167617850 = 5607214128954 := by decide
theorem cert_e1209167617850 : check e1209167617850 [[],[]] .three = true := by decide
def e1209167629150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1209167629150 : Closed e1209167629150 ∧ code e1209167629150 = 5607214140254 := by decide
theorem cert_e1209167629150 : check e1209167629150 [[],[]] .three = true := by decide
def e1209167629166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209167629166 : Closed e1209167629166 ∧ code e1209167629166 = 5607214140270 := by decide
theorem cert_e1209167629166 : check e1209167629166 [[],[]] .smaller = true := by decide
def e1209167629174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209167629174 : Closed e1209167629174 ∧ code e1209167629174 = 5607214140278 := by decide
theorem cert_e1209167629174 : check e1209167629174 [[],[]] .smaller = true := by decide
def e1209167629178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1209167629178 : Closed e1209167629178 ∧ code e1209167629178 = 5607214140282 := by decide
theorem cert_e1209167629178 : check e1209167629178 [[],[]] .three = true := by decide
def e1209167629230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209167629230 : Closed e1209167629230 ∧ code e1209167629230 = 5607214140334 := by decide
theorem cert_e1209167629230 : check e1209167629230 [[],[]] .smaller = true := by decide
def e1209167629242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209167629242 : Closed e1209167629242 ∧ code e1209167629242 = 5607214140346 := by decide
theorem cert_e1209167629242 : check e1209167629242 [[],[]] .smaller = true := by decide
def e1209167629270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209167629270 : Closed e1209167629270 ∧ code e1209167629270 = 5607214140374 := by decide
theorem cert_e1209167629270 : check e1209167629270 [[],[]] .smaller = true := by decide
def e1209167629274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209167629274 : Closed e1209167629274 ∧ code e1209167629274 = 5607214140378 := by decide
theorem cert_e1209167629274 : check e1209167629274 [[],[]] .smaller = true := by decide
def e1209167629290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1209167629290 : Closed e1209167629290 ∧ code e1209167629290 = 5607214140394 := by decide
theorem cert_e1209167629290 : check e1209167629290 [[],[]] .three = true := by decide
def e1209167629534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209167629534 : Closed e1209167629534 ∧ code e1209167629534 = 5607214140638 := by decide
theorem cert_e1209167629534 : check e1209167629534 [[],[]] .three = true := by decide
def e1209167629550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209167629550 : Closed e1209167629550 ∧ code e1209167629550 = 5607214140654 := by decide
theorem cert_e1209167629550 : check e1209167629550 [[],[]] .smaller = true := by decide
def e1209167629558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209167629558 : Closed e1209167629558 ∧ code e1209167629558 = 5607214140662 := by decide
theorem cert_e1209167629558 : check e1209167629558 [[],[]] .smaller = true := by decide
def e1209167629562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209167629562 : Closed e1209167629562 ∧ code e1209167629562 = 5607214140666 := by decide
theorem cert_e1209167629562 : check e1209167629562 [[],[]] .three = true := by decide
def e1209167629934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209167629934 : Closed e1209167629934 ∧ code e1209167629934 = 5607214141038 := by decide
theorem cert_e1209167629934 : check e1209167629934 [[],[]] .smaller = true := by decide
def e1209167629946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209167629946 : Closed e1209167629946 ∧ code e1209167629946 = 5607214141050 := by decide
theorem cert_e1209167629946 : check e1209167629946 [[],[]] .smaller = true := by decide
def e1209167630134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209167630134 : Closed e1209167630134 ∧ code e1209167630134 = 5607214141238 := by decide
theorem cert_e1209167630134 : check e1209167630134 [[],[]] .smaller = true := by decide
def e1209167630138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209167630138 : Closed e1209167630138 ∧ code e1209167630138 = 5607214141242 := by decide
theorem cert_e1209167630138 : check e1209167630138 [[],[]] .smaller = true := by decide
def e1209167630234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209167630234 : Closed e1209167630234 ∧ code e1209167630234 = 5607214141338 := by decide
theorem cert_e1209167630234 : check e1209167630234 [[],[]] .three = true := by decide
def e1209167635894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1209167635894 : Closed e1209167635894 ∧ code e1209167635894 = 5607214146998 := by decide
theorem cert_e1209167635894 : check e1209167635894 [[],[]] .smaller = true := by decide
def e1209167635926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1209167635926 : Closed e1209167635926 ∧ code e1209167635926 = 5607214147030 := by decide
theorem cert_e1209167635926 : check e1209167635926 [[],[]] .smaller = true := by decide
def e1209167635930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1209167635930 : Closed e1209167635930 ∧ code e1209167635930 = 5607214147034 := by decide
theorem cert_e1209167635930 : check e1209167635930 [[],[]] .smaller = true := by decide
def e1209167636086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1209167636086 : Closed e1209167636086 ∧ code e1209167636086 = 5607214147190 := by decide
theorem cert_e1209167636086 : check e1209167636086 [[],[]] .smaller = true := by decide
def e1209167636278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209167636278 : Closed e1209167636278 ∧ code e1209167636278 = 5607214147382 := by decide
theorem cert_e1209167636278 : check e1209167636278 [[],[]] .smaller = true := by decide
def e1209167636282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209167636282 : Closed e1209167636282 ∧ code e1209167636282 = 5607214147386 := by decide
theorem cert_e1209167636282 : check e1209167636282 [[],[]] .smaller = true := by decide
def e1209167639254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1209167639254 : Closed e1209167639254 ∧ code e1209167639254 = 5607214150358 := by decide
theorem cert_e1209167639254 : check e1209167639254 [[],[]] .three = true := by decide
def e1209167639258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1209167639258 : Closed e1209167639258 ∧ code e1209167639258 = 5607214150362 := by decide
theorem cert_e1209167639258 : check e1209167639258 [[],[]] .three = true := by decide
def e1209167639274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1209167639274 : Closed e1209167639274 ∧ code e1209167639274 = 5607214150378 := by decide
theorem cert_e1209167639274 : check e1209167639274 [[],[]] .three = true := by decide
def e1209167639350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209167639350 : Closed e1209167639350 ∧ code e1209167639350 = 5607214150454 := by decide
theorem cert_e1209167639350 : check e1209167639350 [[],[]] .three = true := by decide
def e1209167639354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209167639354 : Closed e1209167639354 ∧ code e1209167639354 = 5607214150458 := by decide
theorem cert_e1209167639354 : check e1209167639354 [[],[]] .three = true := by decide
def e1209167639450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209167639450 : Closed e1209167639450 ∧ code e1209167639450 = 5607214150554 := by decide
theorem cert_e1209167639450 : check e1209167639450 [[],[]] .three = true := by decide
def e1209167864686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1209167864686 : Closed e1209167864686 ∧ code e1209167864686 = 5607214375790 := by decide
theorem cert_e1209167864686 : check e1209167864686 [[],[]] .chain = true := by decide
def e1209167864694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1209167864694 : Closed e1209167864694 ∧ code e1209167864694 = 5607214375798 := by decide
theorem cert_e1209167864694 : check e1209167864694 [[],[]] .chain = true := by decide
def e1209167864750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1209167864750 : Closed e1209167864750 ∧ code e1209167864750 = 5607214375854 := by decide
theorem cert_e1209167864750 : check e1209167864750 [[],[]] .chain = true := by decide
def e1209167864762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1209167864762 : Closed e1209167864762 ∧ code e1209167864762 = 5607214375866 := by decide
theorem cert_e1209167864762 : check e1209167864762 [[],[]] .chain = true := by decide
def e1209167864790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1209167864790 : Closed e1209167864790 ∧ code e1209167864790 = 5607214375894 := by decide
theorem cert_e1209167864790 : check e1209167864790 [[],[]] .chain = true := by decide
def e1209167864794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1209167864794 : Closed e1209167864794 ∧ code e1209167864794 = 5607214375898 := by decide
theorem cert_e1209167864794 : check e1209167864794 [[],[]] .chain = true := by decide
def e1209167866094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1209167866094 : Closed e1209167866094 ∧ code e1209167866094 = 5607214377198 := by decide
theorem cert_e1209167866094 : check e1209167866094 [[],[]] .chain = true := by decide
def e1209167866102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1209167866102 : Closed e1209167866102 ∧ code e1209167866102 = 5607214377206 := by decide
theorem cert_e1209167866102 : check e1209167866102 [[],[]] .chain = true := by decide
def e1209167866654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1209167866654 : Closed e1209167866654 ∧ code e1209167866654 = 5607214377758 := by decide
theorem cert_e1209167866654 : check e1209167866654 [[],[]] .chain = true := by decide
def e1209167866766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1209167866766 : Closed e1209167866766 ∧ code e1209167866766 = 5607214377870 := by decide
theorem cert_e1209167866766 : check e1209167866766 [[],[]] .chain = true := by decide
def e1209167866990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1209167866990 : Closed e1209167866990 ∧ code e1209167866990 = 5607214378094 := by decide
theorem cert_e1209167866990 : check e1209167866990 [[],[]] .chain = true := by decide
def e1209167867002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1209167867002 : Closed e1209167867002 ∧ code e1209167867002 = 5607214378106 := by decide
theorem cert_e1209167867002 : check e1209167867002 [[],[]] .chain = true := by decide
def e1209167867166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1209167867166 : Closed e1209167867166 ∧ code e1209167867166 = 5607214378270 := by decide
theorem cert_e1209167867166 : check e1209167867166 [[],[]] .chain = true := by decide
def e1209167867334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1209167867334 : Closed e1209167867334 ∧ code e1209167867334 = 5607214378438 := by decide
theorem cert_e1209167867334 : check e1209167867334 [[],[]] .chain = true := by decide
def e1209167867446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1209167867446 : Closed e1209167867446 ∧ code e1209167867446 = 5607214378550 := by decide
theorem cert_e1209167867446 : check e1209167867446 [[],[]] .chain = true := by decide
def e1209167867450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1209167867450 : Closed e1209167867450 ∧ code e1209167867450 = 5607214378554 := by decide
theorem cert_e1209167867450 : check e1209167867450 [[],[]] .chain = true := by decide
def e1209167867534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1209167867534 : Closed e1209167867534 ∧ code e1209167867534 = 5607214378638 := by decide
theorem cert_e1209167867534 : check e1209167867534 [[],[]] .chain = true := by decide
def e1209167867590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1209167867590 : Closed e1209167867590 ∧ code e1209167867590 = 5607214378694 := by decide
theorem cert_e1209167867590 : check e1209167867590 [[],[]] .chain = true := by decide
def e1209167868334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1209167868334 : Closed e1209167868334 ∧ code e1209167868334 = 5607214379438 := by decide
theorem cert_e1209167868334 : check e1209167868334 [[],[]] .chain = true := by decide
def e1209167868346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1209167868346 : Closed e1209167868346 ∧ code e1209167868346 = 5607214379450 := by decide
theorem cert_e1209167868346 : check e1209167868346 [[],[]] .chain = true := by decide
def e1209167868394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1209167868394 : Closed e1209167868394 ∧ code e1209167868394 = 5607214379498 := by decide
theorem cert_e1209167868394 : check e1209167868394 [[],[]] .chain = true := by decide
def e1209167869038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1209167869038 : Closed e1209167869038 ∧ code e1209167869038 = 5607214380142 := by decide
theorem cert_e1209167869038 : check e1209167869038 [[],[]] .chain = true := by decide
def e1209167869050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1209167869050 : Closed e1209167869050 ∧ code e1209167869050 = 5607214380154 := by decide
theorem cert_e1209167869050 : check e1209167869050 [[],[]] .chain = true := by decide
def e1209167869214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1209167869214 : Closed e1209167869214 ∧ code e1209167869214 = 5607214380318 := by decide
theorem cert_e1209167869214 : check e1209167869214 [[],[]] .chain = true := by decide
def e1209167869382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1209167869382 : Closed e1209167869382 ∧ code e1209167869382 = 5607214380486 := by decide
theorem cert_e1209167869382 : check e1209167869382 [[],[]] .chain = true := by decide
def e1209167869722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1209167869722 : Closed e1209167869722 ∧ code e1209167869722 = 5607214380826 := by decide
theorem cert_e1209167869722 : check e1209167869722 [[],[]] .chain = true := by decide
def e1209167869766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1209167869766 : Closed e1209167869766 ∧ code e1209167869766 = 5607214380870 := by decide
theorem cert_e1209167869766 : check e1209167869766 [[],[]] .chain = true := by decide
def e1209167870166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1209167870166 : Closed e1209167870166 ∧ code e1209167870166 = 5607214381270 := by decide
theorem cert_e1209167870166 : check e1209167870166 [[],[]] .chain = true := by decide
def e1209167870170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1209167870170 : Closed e1209167870170 ∧ code e1209167870170 = 5607214381274 := by decide
theorem cert_e1209167870170 : check e1209167870170 [[],[]] .chain = true := by decide
def e1209167870186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1209167870186 : Closed e1209167870186 ∧ code e1209167870186 = 5607214381290 := by decide
theorem cert_e1209167870186 : check e1209167870186 [[],[]] .chain = true := by decide
def e1209167870518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1209167870518 : Closed e1209167870518 ∧ code e1209167870518 = 5607214381622 := by decide
theorem cert_e1209167870518 : check e1209167870518 [[],[]] .chain = true := by decide
def e1209167870522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1209167870522 : Closed e1209167870522 ∧ code e1209167870522 = 5607214381626 := by decide
theorem cert_e1209167870522 : check e1209167870522 [[],[]] .chain = true := by decide
def e1209167870606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1209167870606 : Closed e1209167870606 ∧ code e1209167870606 = 5607214381710 := by decide
theorem cert_e1209167870606 : check e1209167870606 [[],[]] .chain = true := by decide
def e1209167870662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1209167870662 : Closed e1209167870662 ∧ code e1209167870662 = 5607214381766 := by decide
theorem cert_e1209167870662 : check e1209167870662 [[],[]] .chain = true := by decide
def e1209167870746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1209167870746 : Closed e1209167870746 ∧ code e1209167870746 = 5607214381850 := by decide
theorem cert_e1209167870746 : check e1209167870746 [[],[]] .chain = true := by decide
def e1209167870790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1209167870790 : Closed e1209167870790 ∧ code e1209167870790 = 5607214381894 := by decide
theorem cert_e1209167870790 : check e1209167870790 [[],[]] .chain = true := by decide
def e1209167875310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1209167875310 : Closed e1209167875310 ∧ code e1209167875310 = 5607214386414 := by decide
theorem cert_e1209167875310 : check e1209167875310 [[],[]] .chain = true := by decide
def e1209167875318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1209167875318 : Closed e1209167875318 ∧ code e1209167875318 = 5607214386422 := by decide
theorem cert_e1209167875318 : check e1209167875318 [[],[]] .chain = true := by decide
def e1209167875694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209167875694 : Closed e1209167875694 ∧ code e1209167875694 = 5607214386798 := by decide
theorem cert_e1209167875694 : check e1209167875694 [[],[]] .chain = true := by decide
def e1209167875706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209167875706 : Closed e1209167875706 ∧ code e1209167875706 = 5607214386810 := by decide
theorem cert_e1209167875706 : check e1209167875706 [[],[]] .chain = true := by decide
def e1209167875894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209167875894 : Closed e1209167875894 ∧ code e1209167875894 = 5607214386998 := by decide
theorem cert_e1209167875894 : check e1209167875894 [[],[]] .chain = true := by decide
def e1209167875898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209167875898 : Closed e1209167875898 ∧ code e1209167875898 = 5607214387002 := by decide
theorem cert_e1209167875898 : check e1209167875898 [[],[]] .chain = true := by decide
def e1209167878382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1209167878382 : Closed e1209167878382 ∧ code e1209167878382 = 5607214389486 := by decide
theorem cert_e1209167878382 : check e1209167878382 [[],[]] .chain = true := by decide
def e1209167878390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1209167878390 : Closed e1209167878390 ∧ code e1209167878390 = 5607214389494 := by decide
theorem cert_e1209167878390 : check e1209167878390 [[],[]] .chain = true := by decide
def e1209167878942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1209167878942 : Closed e1209167878942 ∧ code e1209167878942 = 5607214390046 := by decide
theorem cert_e1209167878942 : check e1209167878942 [[],[]] .chain = true := by decide
def e1209167879054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1209167879054 : Closed e1209167879054 ∧ code e1209167879054 = 5607214390158 := by decide
theorem cert_e1209167879054 : check e1209167879054 [[],[]] .chain = true := by decide
def e1209167879278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1209167879278 : Closed e1209167879278 ∧ code e1209167879278 = 5607214390382 := by decide
theorem cert_e1209167879278 : check e1209167879278 [[],[]] .chain = true := by decide
def e1209167879290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1209167879290 : Closed e1209167879290 ∧ code e1209167879290 = 5607214390394 := by decide
theorem cert_e1209167879290 : check e1209167879290 [[],[]] .chain = true := by decide
def e1209167879454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1209167879454 : Closed e1209167879454 ∧ code e1209167879454 = 5607214390558 := by decide
theorem cert_e1209167879454 : check e1209167879454 [[],[]] .chain = true := by decide
def e1209167879622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1209167879622 : Closed e1209167879622 ∧ code e1209167879622 = 5607214390726 := by decide
theorem cert_e1209167879622 : check e1209167879622 [[],[]] .chain = true := by decide
def e1209167879734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1209167879734 : Closed e1209167879734 ∧ code e1209167879734 = 5607214390838 := by decide
theorem cert_e1209167879734 : check e1209167879734 [[],[]] .chain = true := by decide
def e1209167879738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1209167879738 : Closed e1209167879738 ∧ code e1209167879738 = 5607214390842 := by decide
theorem cert_e1209167879738 : check e1209167879738 [[],[]] .chain = true := by decide
def e1209167879822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1209167879822 : Closed e1209167879822 ∧ code e1209167879822 = 5607214390926 := by decide
theorem cert_e1209167879822 : check e1209167879822 [[],[]] .chain = true := by decide
def e1209167879878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1209167879878 : Closed e1209167879878 ∧ code e1209167879878 = 5607214390982 := by decide
theorem cert_e1209167879878 : check e1209167879878 [[],[]] .chain = true := by decide
def e1209167882014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1209167882014 : Closed e1209167882014 ∧ code e1209167882014 = 5607214393118 := by decide
theorem cert_e1209167882014 : check e1209167882014 [[],[]] .chain = true := by decide
def e1209167882126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1209167882126 : Closed e1209167882126 ∧ code e1209167882126 = 5607214393230 := by decide
theorem cert_e1209167882126 : check e1209167882126 [[],[]] .chain = true := by decide
def e1209167885086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1209167885086 : Closed e1209167885086 ∧ code e1209167885086 = 5607214396190 := by decide
theorem cert_e1209167885086 : check e1209167885086 [[],[]] .chain = true := by decide
def e1209167885254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1209167885254 : Closed e1209167885254 ∧ code e1209167885254 = 5607214396358 := by decide
theorem cert_e1209167885254 : check e1209167885254 [[],[]] .chain = true := by decide
def e1209167886734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1209167886734 : Closed e1209167886734 ∧ code e1209167886734 = 5607214397838 := by decide
theorem cert_e1209167886734 : check e1209167886734 [[],[]] .chain = true := by decide
def e1209167886790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1209167886790 : Closed e1209167886790 ∧ code e1209167886790 = 5607214397894 := by decide
theorem cert_e1209167886790 : check e1209167886790 [[],[]] .chain = true := by decide
def e1209167890030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209167890030 : Closed e1209167890030 ∧ code e1209167890030 = 5607214401134 := by decide
theorem cert_e1209167890030 : check e1209167890030 [[],[]] .chain = true := by decide
def e1209167890042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209167890042 : Closed e1209167890042 ∧ code e1209167890042 = 5607214401146 := by decide
theorem cert_e1209167890042 : check e1209167890042 [[],[]] .chain = true := by decide
def e1209167890330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1209167890330 : Closed e1209167890330 ∧ code e1209167890330 = 5607214401434 := by decide
theorem cert_e1209167890330 : check e1209167890330 [[],[]] .chain = true := by decide
def e1209167891566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1209167891566 : Closed e1209167891566 ∧ code e1209167891566 = 5607214402670 := by decide
theorem cert_e1209167891566 : check e1209167891566 [[],[]] .chain = true := by decide
def e1209167891578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1209167891578 : Closed e1209167891578 ∧ code e1209167891578 = 5607214402682 := by decide
theorem cert_e1209167891578 : check e1209167891578 [[],[]] .chain = true := by decide
def e1209167891742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1209167891742 : Closed e1209167891742 ∧ code e1209167891742 = 5607214402846 := by decide
theorem cert_e1209167891742 : check e1209167891742 [[],[]] .chain = true := by decide
def e1209167891910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1209167891910 : Closed e1209167891910 ∧ code e1209167891910 = 5607214403014 := by decide
theorem cert_e1209167891910 : check e1209167891910 [[],[]] .chain = true := by decide
def e1209167892250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1209167892250 : Closed e1209167892250 ∧ code e1209167892250 = 5607214403354 := by decide
theorem cert_e1209167892250 : check e1209167892250 [[],[]] .chain = true := by decide
def e1209167892294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1209167892294 : Closed e1209167892294 ∧ code e1209167892294 = 5607214403398 := by decide
theorem cert_e1209167892294 : check e1209167892294 [[],[]] .chain = true := by decide
def e1209167893278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1209167893278 : Closed e1209167893278 ∧ code e1209167893278 = 5607214404382 := by decide
theorem cert_e1209167893278 : check e1209167893278 [[],[]] .chain = true := by decide
def e1209167893446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1209167893446 : Closed e1209167893446 ∧ code e1209167893446 = 5607214404550 := by decide
theorem cert_e1209167893446 : check e1209167893446 [[],[]] .chain = true := by decide
def e1209167895750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1209167895750 : Closed e1209167895750 ∧ code e1209167895750 = 5607214406854 := by decide
theorem cert_e1209167895750 : check e1209167895750 [[],[]] .chain = true := by decide
def e1209167897398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209167897398 : Closed e1209167897398 ∧ code e1209167897398 = 5607214408502 := by decide
theorem cert_e1209167897398 : check e1209167897398 [[],[]] .chain = true := by decide
def e1209167897402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209167897402 : Closed e1209167897402 ∧ code e1209167897402 = 5607214408506 := by decide
theorem cert_e1209167897402 : check e1209167897402 [[],[]] .chain = true := by decide
def e1209167897498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1209167897498 : Closed e1209167897498 ∧ code e1209167897498 = 5607214408602 := by decide
theorem cert_e1209167897498 : check e1209167897498 [[],[]] .chain = true := by decide
def e1209167898166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1209167898166 : Closed e1209167898166 ∧ code e1209167898166 = 5607214409270 := by decide
theorem cert_e1209167898166 : check e1209167898166 [[],[]] .chain = true := by decide
def e1209167898170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1209167898170 : Closed e1209167898170 ∧ code e1209167898170 = 5607214409274 := by decide
theorem cert_e1209167898170 : check e1209167898170 [[],[]] .chain = true := by decide
def e1209167898254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1209167898254 : Closed e1209167898254 ∧ code e1209167898254 = 5607214409358 := by decide
theorem cert_e1209167898254 : check e1209167898254 [[],[]] .chain = true := by decide
def e1209167898310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1209167898310 : Closed e1209167898310 ∧ code e1209167898310 = 5607214409414 := by decide
theorem cert_e1209167898310 : check e1209167898310 [[],[]] .chain = true := by decide
def e1209167898394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1209167898394 : Closed e1209167898394 ∧ code e1209167898394 = 5607214409498 := by decide
theorem cert_e1209167898394 : check e1209167898394 [[],[]] .chain = true := by decide
def e1209167898438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1209167898438 : Closed e1209167898438 ∧ code e1209167898438 = 5607214409542 := by decide
theorem cert_e1209167898438 : check e1209167898438 [[],[]] .chain = true := by decide
def e1209167899022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1209167899022 : Closed e1209167899022 ∧ code e1209167899022 = 5607214410126 := by decide
theorem cert_e1209167899022 : check e1209167899022 [[],[]] .chain = true := by decide
def e1209167899078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1209167899078 : Closed e1209167899078 ∧ code e1209167899078 = 5607214410182 := by decide
theorem cert_e1209167899078 : check e1209167899078 [[],[]] .chain = true := by decide
def e1209167899846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1209167899846 : Closed e1209167899846 ∧ code e1209167899846 = 5607214410950 := by decide
theorem cert_e1209167899846 : check e1209167899846 [[],[]] .chain = true := by decide
def e1209167910622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1209167910622 : Closed e1209167910622 ∧ code e1209167910622 = 5607214421726 := by decide
theorem cert_e1209167910622 : check e1209167910622 [[],[]] .chain = true := by decide
def e1209167910646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1209167910646 : Closed e1209167910646 ∧ code e1209167910646 = 5607214421750 := by decide
theorem cert_e1209167910646 : check e1209167910646 [[],[]] .chain = true := by decide
def e1209167910750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1209167910750 : Closed e1209167910750 ∧ code e1209167910750 = 5607214421854 := by decide
theorem cert_e1209167910750 : check e1209167910750 [[],[]] .chain = true := by decide
def e1209167910778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1209167910778 : Closed e1209167910778 ∧ code e1209167910778 = 5607214421882 := by decide
theorem cert_e1209167910778 : check e1209167910778 [[],[]] .chain = true := by decide
def e1209167910870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1209167910870 : Closed e1209167910870 ∧ code e1209167910870 = 5607214421974 := by decide
theorem cert_e1209167910870 : check e1209167910870 [[],[]] .chain = true := by decide
def e1209167910874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1209167910874 : Closed e1209167910874 ∧ code e1209167910874 = 5607214421978 := by decide
theorem cert_e1209167910874 : check e1209167910874 [[],[]] .chain = true := by decide
def e1209167911390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209167911390 : Closed e1209167911390 ∧ code e1209167911390 = 5607214422494 := by decide
theorem cert_e1209167911390 : check e1209167911390 [[],[]] .chain = true := by decide
def e1209167911414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209167911414 : Closed e1209167911414 ∧ code e1209167911414 = 5607214422518 := by decide
theorem cert_e1209167911414 : check e1209167911414 [[],[]] .chain = true := by decide
def e1209167912158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209167912158 : Closed e1209167912158 ∧ code e1209167912158 = 5607214423262 := by decide
theorem cert_e1209167912158 : check e1209167912158 [[],[]] .chain = true := by decide
def e1209167912186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209167912186 : Closed e1209167912186 ∧ code e1209167912186 = 5607214423290 := by decide
theorem cert_e1209167912186 : check e1209167912186 [[],[]] .chain = true := by decide
def e1209167912758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209167912758 : Closed e1209167912758 ∧ code e1209167912758 = 5607214423862 := by decide
theorem cert_e1209167912758 : check e1209167912758 [[],[]] .chain = true := by decide
def e1209167912762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209167912762 : Closed e1209167912762 ∧ code e1209167912762 = 5607214423866 := by decide
theorem cert_e1209167912762 : check e1209167912762 [[],[]] .chain = true := by decide
def e1209167927534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1209167927534 : Closed e1209167927534 ∧ code e1209167927534 = 5607214438638 := by decide
theorem cert_e1209167927534 : check e1209167927534 [[],[]] .chain = true := by decide
def e1209167927542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1209167927542 : Closed e1209167927542 ∧ code e1209167927542 = 5607214438646 := by decide
theorem cert_e1209167927542 : check e1209167927542 [[],[]] .chain = true := by decide
def e1209167928094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1209167928094 : Closed e1209167928094 ∧ code e1209167928094 = 5607214439198 := by decide
theorem cert_e1209167928094 : check e1209167928094 [[],[]] .chain = true := by decide
def e1209167928206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1209167928206 : Closed e1209167928206 ∧ code e1209167928206 = 5607214439310 := by decide
theorem cert_e1209167928206 : check e1209167928206 [[],[]] .chain = true := by decide
def e1209167928430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209167928430 : Closed e1209167928430 ∧ code e1209167928430 = 5607214439534 := by decide
theorem cert_e1209167928430 : check e1209167928430 [[],[]] .chain = true := by decide
def e1209167928442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209167928442 : Closed e1209167928442 ∧ code e1209167928442 = 5607214439546 := by decide
theorem cert_e1209167928442 : check e1209167928442 [[],[]] .chain = true := by decide
def e1209167928606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209167928606 : Closed e1209167928606 ∧ code e1209167928606 = 5607214439710 := by decide
theorem cert_e1209167928606 : check e1209167928606 [[],[]] .chain = true := by decide
def e1209167928774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209167928774 : Closed e1209167928774 ∧ code e1209167928774 = 5607214439878 := by decide
theorem cert_e1209167928774 : check e1209167928774 [[],[]] .chain = true := by decide
def e1209167928886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209167928886 : Closed e1209167928886 ∧ code e1209167928886 = 5607214439990 := by decide
theorem cert_e1209167928886 : check e1209167928886 [[],[]] .chain = true := by decide
def e1209167928890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209167928890 : Closed e1209167928890 ∧ code e1209167928890 = 5607214439994 := by decide
theorem cert_e1209167928890 : check e1209167928890 [[],[]] .chain = true := by decide
def e1209167928974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209167928974 : Closed e1209167928974 ∧ code e1209167928974 = 5607214440078 := by decide
theorem cert_e1209167928974 : check e1209167928974 [[],[]] .chain = true := by decide
def e1209167929030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209167929030 : Closed e1209167929030 ∧ code e1209167929030 = 5607214440134 := by decide
theorem cert_e1209167929030 : check e1209167929030 [[],[]] .chain = true := by decide
def e1209167931166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1209167931166 : Closed e1209167931166 ∧ code e1209167931166 = 5607214442270 := by decide
theorem cert_e1209167931166 : check e1209167931166 [[],[]] .chain = true := by decide
def e1209167931278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1209167931278 : Closed e1209167931278 ∧ code e1209167931278 = 5607214442382 := by decide
theorem cert_e1209167931278 : check e1209167931278 [[],[]] .chain = true := by decide
def e1209167934238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209167934238 : Closed e1209167934238 ∧ code e1209167934238 = 5607214445342 := by decide
theorem cert_e1209167934238 : check e1209167934238 [[],[]] .chain = true := by decide
def e1209167934406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209167934406 : Closed e1209167934406 ∧ code e1209167934406 = 5607214445510 := by decide
theorem cert_e1209167934406 : check e1209167934406 [[],[]] .chain = true := by decide
def e1209167935886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209167935886 : Closed e1209167935886 ∧ code e1209167935886 = 5607214446990 := by decide
theorem cert_e1209167935886 : check e1209167935886 [[],[]] .chain = true := by decide
def e1209167935942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209167935942 : Closed e1209167935942 ∧ code e1209167935942 = 5607214447046 := by decide
theorem cert_e1209167935942 : check e1209167935942 [[],[]] .chain = true := by decide
end Blc.Floor42
