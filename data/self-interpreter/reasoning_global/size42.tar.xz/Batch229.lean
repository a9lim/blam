import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211212616454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211212616454 : Closed e1211212616454 ∧ code e1211212616454 = 5609259127558 := by decide
theorem cert_e1211212616454 : check e1211212616454 [[],[]] .chain = true := by decide
def e1211212616478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211212616478 : Closed e1211212616478 ∧ code e1211212616478 = 5609259127582 := by decide
theorem cert_e1211212616478 : check e1211212616478 [[],[],[.under,.under]] .three = true := by decide
def e1211212616502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212616502 : Closed e1211212616502 ∧ code e1211212616502 = 5609259127606 := by decide
theorem cert_e1211212616502 : check e1211212616502 [[],[]] .chain = true := by decide
def e1211212616506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212616506 : Closed e1211212616506 ∧ code e1211212616506 = 5609259127610 := by decide
theorem cert_e1211212616506 : check e1211212616506 [[],[]] .chain = true := by decide
def e1211212616578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211212616578 : Closed e1211212616578 ∧ code e1211212616578 = 5609259127682 := by decide
theorem cert_e1211212616578 : check e1211212616578 [[],[]] .chain = true := by decide
def e1211212616590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211212616590 : Closed e1211212616590 ∧ code e1211212616590 = 5609259127694 := by decide
theorem cert_e1211212616590 : check e1211212616590 [[],[]] .chain = true := by decide
def e1211212616602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212616602 : Closed e1211212616602 ∧ code e1211212616602 = 5609259127706 := by decide
theorem cert_e1211212616602 : check e1211212616602 [[],[]] .chain = true := by decide
def e1211212616646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211212616646 : Closed e1211212616646 ∧ code e1211212616646 = 5609259127750 := by decide
theorem cert_e1211212616646 : check e1211212616646 [[],[],[.under,.under]] .three = true := by decide
def e1211212617846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211212617846 : Closed e1211212617846 ∧ code e1211212617846 = 5609259128950 := by decide
theorem cert_e1211212617846 : check e1211212617846 [[],[]] .chain = true := by decide
def e1211212618090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211212618090 : Closed e1211212618090 ∧ code e1211212618090 = 5609259129194 := by decide
theorem cert_e1211212618090 : check e1211212618090 [[],[]] .chain = true := by decide
def e1211212618114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211212618114 : Closed e1211212618114 ∧ code e1211212618114 = 5609259129218 := by decide
theorem cert_e1211212618114 : check e1211212618114 [[],[]] .chain = true := by decide
def e1211212618126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211212618126 : Closed e1211212618126 ∧ code e1211212618126 = 5609259129230 := by decide
theorem cert_e1211212618126 : check e1211212618126 [[],[]] .chain = true := by decide
def e1211212618138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212618138 : Closed e1211212618138 ∧ code e1211212618138 = 5609259129242 := by decide
theorem cert_e1211212618138 : check e1211212618138 [[],[]] .chain = true := by decide
def e1211212618182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211212618182 : Closed e1211212618182 ∧ code e1211212618182 = 5609259129286 := by decide
theorem cert_e1211212618182 : check e1211212618182 [[],[]] .chain = true := by decide
def e1211212618806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212618806 : Closed e1211212618806 ∧ code e1211212618806 = 5609259129910 := by decide
theorem cert_e1211212618806 : check e1211212618806 [[],[],[.under,.under]] .three = true := by decide
def e1211212618810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212618810 : Closed e1211212618810 ∧ code e1211212618810 = 5609259129914 := by decide
theorem cert_e1211212618810 : check e1211212618810 [[],[],[.under,.under]] .three = true := by decide
def e1211212618950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211212618950 : Closed e1211212618950 ∧ code e1211212618950 = 5609259130054 := by decide
theorem cert_e1211212618950 : check e1211212618950 [[],[],[.under,.under]] .three = true := by decide
def e1211212620214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211212620214 : Closed e1211212620214 ∧ code e1211212620214 = 5609259131318 := by decide
theorem cert_e1211212620214 : check e1211212620214 [[],[],[.under,.under]] .three = true := by decide
def e1211212620218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211212620218 : Closed e1211212620218 ∧ code e1211212620218 = 5609259131322 := by decide
theorem cert_e1211212620218 : check e1211212620218 [[],[],[.under,.under]] .three = true := by decide
def e1211212620246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211212620246 : Closed e1211212620246 ∧ code e1211212620246 = 5609259131350 := by decide
theorem cert_e1211212620246 : check e1211212620246 [[],[],[.under,.under]] .three = true := by decide
def e1211212620266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211212620266 : Closed e1211212620266 ∧ code e1211212620266 = 5609259131370 := by decide
theorem cert_e1211212620266 : check e1211212620266 [[],[],[.under,.under]] .three = true := by decide
def e1211212620598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212620598 : Closed e1211212620598 ∧ code e1211212620598 = 5609259131702 := by decide
theorem cert_e1211212620598 : check e1211212620598 [[],[],[.under,.under]] .three = true := by decide
def e1211212620602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212620602 : Closed e1211212620602 ∧ code e1211212620602 = 5609259131706 := by decide
theorem cert_e1211212620602 : check e1211212620602 [[],[],[.under,.under]] .three = true := by decide
def e1211212620698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212620698 : Closed e1211212620698 ∧ code e1211212620698 = 5609259131802 := by decide
theorem cert_e1211212620698 : check e1211212620698 [[],[],[.under,.under]] .three = true := by decide
def e1211212621366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211212621366 : Closed e1211212621366 ∧ code e1211212621366 = 5609259132470 := by decide
theorem cert_e1211212621366 : check e1211212621366 [[],[],[.under,.under]] .three = true := by decide
def e1211212621370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211212621370 : Closed e1211212621370 ∧ code e1211212621370 = 5609259132474 := by decide
theorem cert_e1211212621370 : check e1211212621370 [[],[],[.under,.under]] .three = true := by decide
def e1211212621454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211212621454 : Closed e1211212621454 ∧ code e1211212621454 = 5609259132558 := by decide
theorem cert_e1211212621454 : check e1211212621454 [[],[],[.under,.under]] .three = true := by decide
def e1211212621510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211212621510 : Closed e1211212621510 ∧ code e1211212621510 = 5609259132614 := by decide
theorem cert_e1211212621510 : check e1211212621510 [[],[],[.under,.under]] .three = true := by decide
def e1211212621594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211212621594 : Closed e1211212621594 ∧ code e1211212621594 = 5609259132698 := by decide
theorem cert_e1211212621594 : check e1211212621594 [[],[],[.under,.under]] .three = true := by decide
def e1211212621638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211212621638 : Closed e1211212621638 ∧ code e1211212621638 = 5609259132742 := by decide
theorem cert_e1211212621638 : check e1211212621638 [[],[],[.under,.under]] .three = true := by decide
def e1211212621934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211212621934 : Closed e1211212621934 ∧ code e1211212621934 = 5609259133038 := by decide
theorem cert_e1211212621934 : check e1211212621934 [[],[],[.under,.under]] .three = true := by decide
def e1211212621946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211212621946 : Closed e1211212621946 ∧ code e1211212621946 = 5609259133050 := by decide
theorem cert_e1211212621946 : check e1211212621946 [[],[],[.under,.under]] .three = true := by decide
def e1211212622222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211212622222 : Closed e1211212622222 ∧ code e1211212622222 = 5609259133326 := by decide
theorem cert_e1211212622222 : check e1211212622222 [[],[],[.under,.under]] .three = true := by decide
def e1211212622278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211212622278 : Closed e1211212622278 ∧ code e1211212622278 = 5609259133382 := by decide
theorem cert_e1211212622278 : check e1211212622278 [[],[],[.under,.under]] .three = true := by decide
def e1211212622902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212622902 : Closed e1211212622902 ∧ code e1211212622902 = 5609259134006 := by decide
theorem cert_e1211212622902 : check e1211212622902 [[],[],[.under,.under]] .three = true := by decide
def e1211212622906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212622906 : Closed e1211212622906 ∧ code e1211212622906 = 5609259134010 := by decide
theorem cert_e1211212622906 : check e1211212622906 [[],[],[.under,.under]] .three = true := by decide
def e1211212623046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211212623046 : Closed e1211212623046 ∧ code e1211212623046 = 5609259134150 := by decide
theorem cert_e1211212623046 : check e1211212623046 [[],[],[.under,.under]] .three = true := by decide
def e1211212629982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e1211212629982 : Closed e1211212629982 ∧ code e1211212629982 = 5609259141086 := by decide
theorem cert_e1211212629982 : check e1211212629982 [[],[]] .chain = true := by decide
def e1211212633822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211212633822 : Closed e1211212633822 ∧ code e1211212633822 = 5609259144926 := by decide
theorem cert_e1211212633822 : check e1211212633822 [[],[],[.under,.under]] .three = true := by decide
def e1211212633838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1211212633838 : Closed e1211212633838 ∧ code e1211212633838 = 5609259144942 := by decide
theorem cert_e1211212633838 : check e1211212633838 [[],[]] .chain = true := by decide
def e1211212633846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211212633846 : Closed e1211212633846 ∧ code e1211212633846 = 5609259144950 := by decide
theorem cert_e1211212633846 : check e1211212633846 [[],[],[.under,.under]] .three = true := by decide
def e1211212633950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211212633950 : Closed e1211212633950 ∧ code e1211212633950 = 5609259145054 := by decide
theorem cert_e1211212633950 : check e1211212633950 [[],[],[.under,.under]] .three = true := by decide
def e1211212633966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211212633966 : Closed e1211212633966 ∧ code e1211212633966 = 5609259145070 := by decide
theorem cert_e1211212633966 : check e1211212633966 [[],[]] .chain = true := by decide
def e1211212633974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211212633974 : Closed e1211212633974 ∧ code e1211212633974 = 5609259145078 := by decide
theorem cert_e1211212633974 : check e1211212633974 [[],[]] .chain = true := by decide
def e1211212633978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211212633978 : Closed e1211212633978 ∧ code e1211212633978 = 5609259145082 := by decide
theorem cert_e1211212633978 : check e1211212633978 [[],[],[.under,.under]] .three = true := by decide
def e1211212634030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1211212634030 : Closed e1211212634030 ∧ code e1211212634030 = 5609259145134 := by decide
theorem cert_e1211212634030 : check e1211212634030 [[],[]] .chain = true := by decide
def e1211212634038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211212634038 : Closed e1211212634038 ∧ code e1211212634038 = 5609259145142 := by decide
theorem cert_e1211212634038 : check e1211212634038 [[],[]] .chain = true := by decide
def e1211212634042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1211212634042 : Closed e1211212634042 ∧ code e1211212634042 = 5609259145146 := by decide
theorem cert_e1211212634042 : check e1211212634042 [[],[]] .chain = true := by decide
def e1211212634070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211212634070 : Closed e1211212634070 ∧ code e1211212634070 = 5609259145174 := by decide
theorem cert_e1211212634070 : check e1211212634070 [[],[],[.under,.under]] .three = true := by decide
def e1211212634074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211212634074 : Closed e1211212634074 ∧ code e1211212634074 = 5609259145178 := by decide
theorem cert_e1211212634074 : check e1211212634074 [[],[],[.under,.under]] .three = true := by decide
def e1211212634590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211212634590 : Closed e1211212634590 ∧ code e1211212634590 = 5609259145694 := by decide
theorem cert_e1211212634590 : check e1211212634590 [[],[],[.under,.under]] .three = true := by decide
def e1211212634606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211212634606 : Closed e1211212634606 ∧ code e1211212634606 = 5609259145710 := by decide
theorem cert_e1211212634606 : check e1211212634606 [[],[]] .chain = true := by decide
def e1211212634614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211212634614 : Closed e1211212634614 ∧ code e1211212634614 = 5609259145718 := by decide
theorem cert_e1211212634614 : check e1211212634614 [[],[],[.under,.under]] .three = true := by decide
def e1211212635358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211212635358 : Closed e1211212635358 ∧ code e1211212635358 = 5609259146462 := by decide
theorem cert_e1211212635358 : check e1211212635358 [[],[],[.under,.under]] .three = true := by decide
def e1211212635374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212635374 : Closed e1211212635374 ∧ code e1211212635374 = 5609259146478 := by decide
theorem cert_e1211212635374 : check e1211212635374 [[],[]] .chain = true := by decide
def e1211212635382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212635382 : Closed e1211212635382 ∧ code e1211212635382 = 5609259146486 := by decide
theorem cert_e1211212635382 : check e1211212635382 [[],[]] .chain = true := by decide
def e1211212635386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211212635386 : Closed e1211212635386 ∧ code e1211212635386 = 5609259146490 := by decide
theorem cert_e1211212635386 : check e1211212635386 [[],[],[.under,.under]] .three = true := by decide
def e1211212635674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211212635674 : Closed e1211212635674 ∧ code e1211212635674 = 5609259146778 := by decide
theorem cert_e1211212635674 : check e1211212635674 [[],[],[.under,.under]] .three = true := by decide
def e1211212635710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211212635710 : Closed e1211212635710 ∧ code e1211212635710 = 5609259146814 := by decide
theorem cert_e1211212635710 : check e1211212635710 [[],[],[.under,.under]] .three = true := by decide
def e1211212635758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211212635758 : Closed e1211212635758 ∧ code e1211212635758 = 5609259146862 := by decide
theorem cert_e1211212635758 : check e1211212635758 [[],[]] .chain = true := by decide
def e1211212635766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211212635766 : Closed e1211212635766 ∧ code e1211212635766 = 5609259146870 := by decide
theorem cert_e1211212635766 : check e1211212635766 [[],[]] .chain = true := by decide
def e1211212635770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211212635770 : Closed e1211212635770 ∧ code e1211212635770 = 5609259146874 := by decide
theorem cert_e1211212635770 : check e1211212635770 [[],[]] .chain = true := by decide
def e1211212635934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211212635934 : Closed e1211212635934 ∧ code e1211212635934 = 5609259147038 := by decide
theorem cert_e1211212635934 : check e1211212635934 [[],[],[.under,.under]] .three = true := by decide
def e1211212635958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212635958 : Closed e1211212635958 ∧ code e1211212635958 = 5609259147062 := by decide
theorem cert_e1211212635958 : check e1211212635958 [[],[],[.under,.under]] .three = true := by decide
def e1211212635962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212635962 : Closed e1211212635962 ∧ code e1211212635962 = 5609259147066 := by decide
theorem cert_e1211212635962 : check e1211212635962 [[],[],[.under,.under]] .three = true := by decide
def e1211212650166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211212650166 : Closed e1211212650166 ∧ code e1211212650166 = 5609259161270 := by decide
theorem cert_e1211212650166 : check e1211212650166 [[],[]] .chain = true := by decide
def e1211212650198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211212650198 : Closed e1211212650198 ∧ code e1211212650198 = 5609259161302 := by decide
theorem cert_e1211212650198 : check e1211212650198 [[],[]] .chain = true := by decide
def e1211212650202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211212650202 : Closed e1211212650202 ∧ code e1211212650202 = 5609259161306 := by decide
theorem cert_e1211212650202 : check e1211212650202 [[],[]] .chain = true := by decide
def e1211212650326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211212650326 : Closed e1211212650326 ∧ code e1211212650326 = 5609259161430 := by decide
theorem cert_e1211212650326 : check e1211212650326 [[],[]] .chain = true := by decide
def e1211212650330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211212650330 : Closed e1211212650330 ∧ code e1211212650330 = 5609259161434 := by decide
theorem cert_e1211212650330 : check e1211212650330 [[],[]] .chain = true := by decide
def e1211212650346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211212650346 : Closed e1211212650346 ∧ code e1211212650346 = 5609259161450 := by decide
theorem cert_e1211212650346 : check e1211212650346 [[],[]] .chain = true := by decide
def e1211212650550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211212650550 : Closed e1211212650550 ∧ code e1211212650550 = 5609259161654 := by decide
theorem cert_e1211212650550 : check e1211212650550 [[],[]] .chain = true := by decide
def e1211212650638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211212650638 : Closed e1211212650638 ∧ code e1211212650638 = 5609259161742 := by decide
theorem cert_e1211212650638 : check e1211212650638 [[],[]] .chain = true := by decide
def e1211212650722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211212650722 : Closed e1211212650722 ∧ code e1211212650722 = 5609259161826 := by decide
theorem cert_e1211212650722 : check e1211212650722 [[],[]] .chain = true := by decide
def e1211212650734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211212650734 : Closed e1211212650734 ∧ code e1211212650734 = 5609259161838 := by decide
theorem cert_e1211212650734 : check e1211212650734 [[],[],[.under,.under]] .three = true := by decide
def e1211212650742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211212650742 : Closed e1211212650742 ∧ code e1211212650742 = 5609259161846 := by decide
theorem cert_e1211212650742 : check e1211212650742 [[],[],[.under,.under]] .three = true := by decide
def e1211212650934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211212650934 : Closed e1211212650934 ∧ code e1211212650934 = 5609259162038 := by decide
theorem cert_e1211212650934 : check e1211212650934 [[],[]] .chain = true := by decide
def e1211212650966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211212650966 : Closed e1211212650966 ∧ code e1211212650966 = 5609259162070 := by decide
theorem cert_e1211212650966 : check e1211212650966 [[],[]] .chain = true := by decide
def e1211212650970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211212650970 : Closed e1211212650970 ∧ code e1211212650970 = 5609259162074 := by decide
theorem cert_e1211212650970 : check e1211212650970 [[],[]] .chain = true := by decide
def e1211212651126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211212651126 : Closed e1211212651126 ∧ code e1211212651126 = 5609259162230 := by decide
theorem cert_e1211212651126 : check e1211212651126 [[],[]] .chain = true := by decide
def e1211212651270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211212651270 : Closed e1211212651270 ∧ code e1211212651270 = 5609259162374 := by decide
theorem cert_e1211212651270 : check e1211212651270 [[],[]] .chain = true := by decide
def e1211212651294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211212651294 : Closed e1211212651294 ∧ code e1211212651294 = 5609259162398 := by decide
theorem cert_e1211212651294 : check e1211212651294 [[],[],[.under,.under]] .three = true := by decide
def e1211212651318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212651318 : Closed e1211212651318 ∧ code e1211212651318 = 5609259162422 := by decide
theorem cert_e1211212651318 : check e1211212651318 [[],[]] .chain = true := by decide
def e1211212651322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212651322 : Closed e1211212651322 ∧ code e1211212651322 = 5609259162426 := by decide
theorem cert_e1211212651322 : check e1211212651322 [[],[]] .chain = true := by decide
def e1211212651406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211212651406 : Closed e1211212651406 ∧ code e1211212651406 = 5609259162510 := by decide
theorem cert_e1211212651406 : check e1211212651406 [[],[],[.under,.under]] .three = true := by decide
def e1211212651542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211212651542 : Closed e1211212651542 ∧ code e1211212651542 = 5609259162646 := by decide
theorem cert_e1211212651542 : check e1211212651542 [[],[]] .chain = true := by decide
def e1211212651546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211212651546 : Closed e1211212651546 ∧ code e1211212651546 = 5609259162650 := by decide
theorem cert_e1211212651546 : check e1211212651546 [[],[]] .chain = true := by decide
def e1211212651590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211212651590 : Closed e1211212651590 ∧ code e1211212651590 = 5609259162694 := by decide
theorem cert_e1211212651590 : check e1211212651590 [[],[]] .chain = true := by decide
def e1211212651618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211212651618 : Closed e1211212651618 ∧ code e1211212651618 = 5609259162722 := by decide
theorem cert_e1211212651618 : check e1211212651618 [[],[]] .chain = true := by decide
def e1211212651630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211212651630 : Closed e1211212651630 ∧ code e1211212651630 = 5609259162734 := by decide
theorem cert_e1211212651630 : check e1211212651630 [[],[],[.under,.under]] .three = true := by decide
def e1211212651638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211212651638 : Closed e1211212651638 ∧ code e1211212651638 = 5609259162742 := by decide
theorem cert_e1211212651638 : check e1211212651638 [[],[]] .chain = true := by decide
def e1211212651642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211212651642 : Closed e1211212651642 ∧ code e1211212651642 = 5609259162746 := by decide
theorem cert_e1211212651642 : check e1211212651642 [[],[],[.under,.under]] .three = true := by decide
def e1211212651734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211212651734 : Closed e1211212651734 ∧ code e1211212651734 = 5609259162838 := by decide
theorem cert_e1211212651734 : check e1211212651734 [[],[]] .chain = true := by decide
def e1211212651738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211212651738 : Closed e1211212651738 ∧ code e1211212651738 = 5609259162842 := by decide
theorem cert_e1211212651738 : check e1211212651738 [[],[]] .chain = true := by decide
def e1211212651754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211212651754 : Closed e1211212651754 ∧ code e1211212651754 = 5609259162858 := by decide
theorem cert_e1211212651754 : check e1211212651754 [[],[]] .chain = true := by decide
def e1211212651782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211212651782 : Closed e1211212651782 ∧ code e1211212651782 = 5609259162886 := by decide
theorem cert_e1211212651782 : check e1211212651782 [[],[]] .chain = true := by decide
def e1211212651806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211212651806 : Closed e1211212651806 ∧ code e1211212651806 = 5609259162910 := by decide
theorem cert_e1211212651806 : check e1211212651806 [[],[],[.under,.under]] .three = true := by decide
def e1211212651830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212651830 : Closed e1211212651830 ∧ code e1211212651830 = 5609259162934 := by decide
theorem cert_e1211212651830 : check e1211212651830 [[],[]] .chain = true := by decide
def e1211212651834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212651834 : Closed e1211212651834 ∧ code e1211212651834 = 5609259162938 := by decide
theorem cert_e1211212651834 : check e1211212651834 [[],[]] .chain = true := by decide
def e1211212651906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211212651906 : Closed e1211212651906 ∧ code e1211212651906 = 5609259163010 := by decide
theorem cert_e1211212651906 : check e1211212651906 [[],[]] .chain = true := by decide
def e1211212651918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211212651918 : Closed e1211212651918 ∧ code e1211212651918 = 5609259163022 := by decide
theorem cert_e1211212651918 : check e1211212651918 [[],[]] .chain = true := by decide
def e1211212651930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212651930 : Closed e1211212651930 ∧ code e1211212651930 = 5609259163034 := by decide
theorem cert_e1211212651930 : check e1211212651930 [[],[]] .chain = true := by decide
def e1211212651974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211212651974 : Closed e1211212651974 ∧ code e1211212651974 = 5609259163078 := by decide
theorem cert_e1211212651974 : check e1211212651974 [[],[],[.under,.under]] .three = true := by decide
def e1211212652086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211212652086 : Closed e1211212652086 ∧ code e1211212652086 = 5609259163190 := by decide
theorem cert_e1211212652086 : check e1211212652086 [[],[],[.under,.under]] .three = true := by decide
def e1211212652090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211212652090 : Closed e1211212652090 ∧ code e1211212652090 = 5609259163194 := by decide
theorem cert_e1211212652090 : check e1211212652090 [[],[],[.under,.under]] .three = true := by decide
def e1211212652174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211212652174 : Closed e1211212652174 ∧ code e1211212652174 = 5609259163278 := by decide
theorem cert_e1211212652174 : check e1211212652174 [[],[],[.under,.under]] .three = true := by decide
def e1211212652230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211212652230 : Closed e1211212652230 ∧ code e1211212652230 = 5609259163334 := by decide
theorem cert_e1211212652230 : check e1211212652230 [[],[],[.under,.under]] .three = true := by decide
def e1211212652606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211212652606 : Closed e1211212652606 ∧ code e1211212652606 = 5609259163710 := by decide
theorem cert_e1211212652606 : check e1211212652606 [[],[]] .chain = true := by decide
def e1211212653026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211212653026 : Closed e1211212653026 ∧ code e1211212653026 = 5609259164130 := by decide
theorem cert_e1211212653026 : check e1211212653026 [[],[]] .chain = true := by decide
def e1211212653038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211212653038 : Closed e1211212653038 ∧ code e1211212653038 = 5609259164142 := by decide
theorem cert_e1211212653038 : check e1211212653038 [[],[]] .chain = true := by decide
def e1211212654006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211212654006 : Closed e1211212654006 ∧ code e1211212654006 = 5609259165110 := by decide
theorem cert_e1211212654006 : check e1211212654006 [[],[]] .chain = true := by decide
def e1211212654038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211212654038 : Closed e1211212654038 ∧ code e1211212654038 = 5609259165142 := by decide
theorem cert_e1211212654038 : check e1211212654038 [[],[]] .chain = true := by decide
def e1211212654042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211212654042 : Closed e1211212654042 ∧ code e1211212654042 = 5609259165146 := by decide
theorem cert_e1211212654042 : check e1211212654042 [[],[]] .chain = true := by decide
def e1211212654198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211212654198 : Closed e1211212654198 ∧ code e1211212654198 = 5609259165302 := by decide
theorem cert_e1211212654198 : check e1211212654198 [[],[]] .chain = true := by decide
def e1211212654342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211212654342 : Closed e1211212654342 ∧ code e1211212654342 = 5609259165446 := by decide
theorem cert_e1211212654342 : check e1211212654342 [[],[]] .chain = true := by decide
def e1211212654366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211212654366 : Closed e1211212654366 ∧ code e1211212654366 = 5609259165470 := by decide
theorem cert_e1211212654366 : check e1211212654366 [[],[],[.under,.under]] .three = true := by decide
def e1211212654390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212654390 : Closed e1211212654390 ∧ code e1211212654390 = 5609259165494 := by decide
theorem cert_e1211212654390 : check e1211212654390 [[],[]] .chain = true := by decide
def e1211212654394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212654394 : Closed e1211212654394 ∧ code e1211212654394 = 5609259165498 := by decide
theorem cert_e1211212654394 : check e1211212654394 [[],[]] .chain = true := by decide
def e1211212654478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211212654478 : Closed e1211212654478 ∧ code e1211212654478 = 5609259165582 := by decide
theorem cert_e1211212654478 : check e1211212654478 [[],[],[.under,.under]] .three = true := by decide
def e1211212656670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211212656670 : Closed e1211212656670 ∧ code e1211212656670 = 5609259167774 := by decide
theorem cert_e1211212656670 : check e1211212656670 [[],[]] .chain = true := by decide
def e1211212656838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211212656838 : Closed e1211212656838 ∧ code e1211212656838 = 5609259167942 := by decide
theorem cert_e1211212656838 : check e1211212656838 [[],[],[.under,.under]] .three = true := by decide
def e1211212656862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211212656862 : Closed e1211212656862 ∧ code e1211212656862 = 5609259167966 := by decide
theorem cert_e1211212656862 : check e1211212656862 [[],[],[.under,.under]] .three = true := by decide
def e1211212656866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211212656866 : Closed e1211212656866 ∧ code e1211212656866 = 5609259167970 := by decide
theorem cert_e1211212656866 : check e1211212656866 [[],[]] .chain = true := by decide
def e1211212656878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212656878 : Closed e1211212656878 ∧ code e1211212656878 = 5609259167982 := by decide
theorem cert_e1211212656878 : check e1211212656878 [[],[]] .chain = true := by decide
def e1211212656886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212656886 : Closed e1211212656886 ∧ code e1211212656886 = 5609259167990 := by decide
theorem cert_e1211212656886 : check e1211212656886 [[],[]] .chain = true := by decide
def e1211212656890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211212656890 : Closed e1211212656890 ∧ code e1211212656890 = 5609259167994 := by decide
theorem cert_e1211212656890 : check e1211212656890 [[],[],[.under,.under]] .three = true := by decide
def e1211212657366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211212657366 : Closed e1211212657366 ∧ code e1211212657366 = 5609259168470 := by decide
theorem cert_e1211212657366 : check e1211212657366 [[],[]] .chain = true := by decide
def e1211212657370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211212657370 : Closed e1211212657370 ∧ code e1211212657370 = 5609259168474 := by decide
theorem cert_e1211212657370 : check e1211212657370 [[],[]] .chain = true := by decide
def e1211212657386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211212657386 : Closed e1211212657386 ∧ code e1211212657386 = 5609259168490 := by decide
theorem cert_e1211212657386 : check e1211212657386 [[],[]] .chain = true := by decide
def e1211212657414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211212657414 : Closed e1211212657414 ∧ code e1211212657414 = 5609259168518 := by decide
theorem cert_e1211212657414 : check e1211212657414 [[],[]] .chain = true := by decide
def e1211212657438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211212657438 : Closed e1211212657438 ∧ code e1211212657438 = 5609259168542 := by decide
theorem cert_e1211212657438 : check e1211212657438 [[],[],[.under,.under]] .three = true := by decide
def e1211212657462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212657462 : Closed e1211212657462 ∧ code e1211212657462 = 5609259168566 := by decide
theorem cert_e1211212657462 : check e1211212657462 [[],[]] .chain = true := by decide
def e1211212657466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212657466 : Closed e1211212657466 ∧ code e1211212657466 = 5609259168570 := by decide
theorem cert_e1211212657466 : check e1211212657466 [[],[]] .chain = true := by decide
def e1211212657538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211212657538 : Closed e1211212657538 ∧ code e1211212657538 = 5609259168642 := by decide
theorem cert_e1211212657538 : check e1211212657538 [[],[]] .chain = true := by decide
def e1211212657550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211212657550 : Closed e1211212657550 ∧ code e1211212657550 = 5609259168654 := by decide
theorem cert_e1211212657550 : check e1211212657550 [[],[]] .chain = true := by decide
def e1211212657562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211212657562 : Closed e1211212657562 ∧ code e1211212657562 = 5609259168666 := by decide
theorem cert_e1211212657562 : check e1211212657562 [[],[]] .chain = true := by decide
def e1211212657606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211212657606 : Closed e1211212657606 ∧ code e1211212657606 = 5609259168710 := by decide
theorem cert_e1211212657606 : check e1211212657606 [[],[],[.under,.under]] .three = true := by decide
def e1211212658798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211212658798 : Closed e1211212658798 ∧ code e1211212658798 = 5609259169902 := by decide
theorem cert_e1211212658798 : check e1211212658798 [[],[],[.under,.under]] .three = true := by decide
def e1211212658810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211212658810 : Closed e1211212658810 ∧ code e1211212658810 = 5609259169914 := by decide
theorem cert_e1211212658810 : check e1211212658810 [[],[],[.under,.under]] .three = true := by decide
def e1211212659086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211212659086 : Closed e1211212659086 ∧ code e1211212659086 = 5609259170190 := by decide
theorem cert_e1211212659086 : check e1211212659086 [[],[],[.under,.under]] .three = true := by decide
def e1211212659142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211212659142 : Closed e1211212659142 ∧ code e1211212659142 = 5609259170246 := by decide
theorem cert_e1211212659142 : check e1211212659142 [[],[],[.under,.under]] .three = true := by decide
def e1211212694494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211212694494 : Closed e1211212694494 ∧ code e1211212694494 = 5609259205598 := by decide
theorem cert_e1211212694494 : check e1211212694494 [[],[]] .chain = true := by decide
def e1211212694510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211212694510 : Closed e1211212694510 ∧ code e1211212694510 = 5609259205614 := by decide
theorem cert_e1211212694510 : check e1211212694510 [[],[]] .chain = true := by decide
def e1211212696430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211212696430 : Closed e1211212696430 ∧ code e1211212696430 = 5609259207534 := by decide
theorem cert_e1211212696430 : check e1211212696430 [[],[]] .chain = true := by decide
def e1211212696438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211212696438 : Closed e1211212696438 ∧ code e1211212696438 = 5609259207542 := by decide
theorem cert_e1211212696438 : check e1211212696438 [[],[]] .chain = true := by decide
def e1211212696494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211212696494 : Closed e1211212696494 ∧ code e1211212696494 = 5609259207598 := by decide
theorem cert_e1211212696494 : check e1211212696494 [[],[]] .chain = true := by decide
def e1211212696502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e1211212696502 : Closed e1211212696502 ∧ code e1211212696502 = 5609259207606 := by decide
theorem cert_e1211212696502 : check e1211212696502 [[],[]] .chain = true := by decide
def e1211212696506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211212696506 : Closed e1211212696506 ∧ code e1211212696506 = 5609259207610 := by decide
theorem cert_e1211212696506 : check e1211212696506 [[],[]] .chain = true := by decide
def e1211212696534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211212696534 : Closed e1211212696534 ∧ code e1211212696534 = 5609259207638 := by decide
theorem cert_e1211212696534 : check e1211212696534 [[],[]] .chain = true := by decide
def e1211212696538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211212696538 : Closed e1211212696538 ∧ code e1211212696538 = 5609259207642 := by decide
theorem cert_e1211212696538 : check e1211212696538 [[],[]] .chain = true := by decide
def e1211212696814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212696814 : Closed e1211212696814 ∧ code e1211212696814 = 5609259207918 := by decide
theorem cert_e1211212696814 : check e1211212696814 [[],[]] .chain = true := by decide
def e1211212696822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212696822 : Closed e1211212696822 ∧ code e1211212696822 = 5609259207926 := by decide
theorem cert_e1211212696822 : check e1211212696822 [[],[]] .chain = true := by decide
def e1211212697114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211212697114 : Closed e1211212697114 ∧ code e1211212697114 = 5609259208218 := by decide
theorem cert_e1211212697114 : check e1211212697114 [[],[],[.under,.under]] .three = true := by decide
def e1211212697150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211212697150 : Closed e1211212697150 ∧ code e1211212697150 = 5609259208254 := by decide
theorem cert_e1211212697150 : check e1211212697150 [[],[],[.under,.under]] .three = true := by decide
def e1211212697198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211212697198 : Closed e1211212697198 ∧ code e1211212697198 = 5609259208302 := by decide
theorem cert_e1211212697198 : check e1211212697198 [[],[]] .chain = true := by decide
def e1211212697206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211212697206 : Closed e1211212697206 ∧ code e1211212697206 = 5609259208310 := by decide
theorem cert_e1211212697206 : check e1211212697206 [[],[]] .chain = true := by decide
def e1211212697210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211212697210 : Closed e1211212697210 ∧ code e1211212697210 = 5609259208314 := by decide
theorem cert_e1211212697210 : check e1211212697210 [[],[]] .chain = true := by decide
def e1211212697398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212697398 : Closed e1211212697398 ∧ code e1211212697398 = 5609259208502 := by decide
theorem cert_e1211212697398 : check e1211212697398 [[],[]] .chain = true := by decide
def e1211212697402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212697402 : Closed e1211212697402 ∧ code e1211212697402 = 5609259208506 := by decide
theorem cert_e1211212697402 : check e1211212697402 [[],[]] .chain = true := by decide
def e1211212697486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211212697486 : Closed e1211212697486 ∧ code e1211212697486 = 5609259208590 := by decide
theorem cert_e1211212697486 : check e1211212697486 [[],[],[.under,.under]] .three = true := by decide
end Blc.Floor42
