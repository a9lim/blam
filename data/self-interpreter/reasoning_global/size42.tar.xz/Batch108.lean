import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205815015034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815015034 : Closed e1205815015034 ∧ code e1205815015034 = 5603861526138 := by decide
theorem cert_e1205815015034 : check e1205815015034 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815015222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815015222 : Closed e1205815015222 ∧ code e1205815015222 = 5603861526326 := by decide
theorem cert_e1205815015222 : check e1205815015222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1205815015226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815015226 : Closed e1205815015226 ∧ code e1205815015226 = 5603861526330 := by decide
theorem cert_e1205815015226 : check e1205815015226 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815020398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205815020398 : Closed e1205815020398 ∧ code e1205815020398 = 5603861531502 := by decide
theorem cert_e1205815020398 : check e1205815020398 [[],[]] .smaller = true := by decide
def e1205815020406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205815020406 : Closed e1205815020406 ∧ code e1205815020406 = 5603861531510 := by decide
theorem cert_e1205815020406 : check e1205815020406 [[],[]] .smaller = true := by decide
def e1205815020462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205815020462 : Closed e1205815020462 ∧ code e1205815020462 = 5603861531566 := by decide
theorem cert_e1205815020462 : check e1205815020462 [[],[]] .smaller = true := by decide
def e1205815020474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205815020474 : Closed e1205815020474 ∧ code e1205815020474 = 5603861531578 := by decide
theorem cert_e1205815020474 : check e1205815020474 [[],[]] .smaller = true := by decide
def e1205815020502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205815020502 : Closed e1205815020502 ∧ code e1205815020502 = 5603861531606 := by decide
theorem cert_e1205815020502 : check e1205815020502 [[],[]] .smaller = true := by decide
def e1205815020506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205815020506 : Closed e1205815020506 ∧ code e1205815020506 = 5603861531610 := by decide
theorem cert_e1205815020506 : check e1205815020506 [[],[]] .smaller = true := by decide
def e1205815020782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815020782 : Closed e1205815020782 ∧ code e1205815020782 = 5603861531886 := by decide
theorem cert_e1205815020782 : check e1205815020782 [[],[]] .smaller = true := by decide
def e1205815020790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815020790 : Closed e1205815020790 ∧ code e1205815020790 = 5603861531894 := by decide
theorem cert_e1205815020790 : check e1205815020790 [[],[]] .smaller = true := by decide
def e1205815021166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815021166 : Closed e1205815021166 ∧ code e1205815021166 = 5603861532270 := by decide
theorem cert_e1205815021166 : check e1205815021166 [[],[]] .smaller = true := by decide
def e1205815021178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815021178 : Closed e1205815021178 ∧ code e1205815021178 = 5603861532282 := by decide
theorem cert_e1205815021178 : check e1205815021178 [[],[]] .smaller = true := by decide
def e1205815021366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205815021366 : Closed e1205815021366 ∧ code e1205815021366 = 5603861532470 := by decide
theorem cert_e1205815021366 : check e1205815021366 [[],[]] .smaller = true := by decide
def e1205815021370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205815021370 : Closed e1205815021370 ∧ code e1205815021370 = 5603861532474 := by decide
theorem cert_e1205815021370 : check e1205815021370 [[],[]] .smaller = true := by decide
def e1205815029294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205815029294 : Closed e1205815029294 ∧ code e1205815029294 = 5603861540398 := by decide
theorem cert_e1205815029294 : check e1205815029294 [[],[]] .chain = true := by decide
def e1205815029474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205815029474 : Closed e1205815029474 ∧ code e1205815029474 = 5603861540578 := by decide
theorem cert_e1205815029474 : check e1205815029474 [[],[]] .chain = true := by decide
def e1205815029486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1205815029486 : Closed e1205815029486 ∧ code e1205815029486 = 5603861540590 := by decide
theorem cert_e1205815029486 : check e1205815029486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815029526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205815029526 : Closed e1205815029526 ∧ code e1205815029526 = 5603861540630 := by decide
theorem cert_e1205815029526 : check e1205815029526 [[],[]] .chain = true := by decide
def e1205815029602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205815029602 : Closed e1205815029602 ∧ code e1205815029602 = 5603861540706 := by decide
theorem cert_e1205815029602 : check e1205815029602 [[],[]] .chain = true := by decide
def e1205815029614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1205815029614 : Closed e1205815029614 ∧ code e1205815029614 = 5603861540718 := by decide
theorem cert_e1205815029614 : check e1205815029614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815029622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1205815029622 : Closed e1205815029622 ∧ code e1205815029622 = 5603861540726 := by decide
theorem cert_e1205815029622 : check e1205815029622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815031870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e1205815031870 : Closed e1205815031870 ∧ code e1205815031870 = 5603861542974 := by decide
theorem cert_e1205815031870 : check e1205815031870 [[],[]] .chain = true := by decide
def e1205815032290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205815032290 : Closed e1205815032290 ∧ code e1205815032290 = 5603861543394 := by decide
theorem cert_e1205815032290 : check e1205815032290 [[],[]] .chain = true := by decide
def e1205815032302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1205815032302 : Closed e1205815032302 ∧ code e1205815032302 = 5603861543406 := by decide
theorem cert_e1205815032302 : check e1205815032302 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815032862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e1205815032862 : Closed e1205815032862 ∧ code e1205815032862 = 5603861543966 := by decide
theorem cert_e1205815032862 : check e1205815032862 [[],[]] .chain = true := by decide
def e1205815033058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205815033058 : Closed e1205815033058 ∧ code e1205815033058 = 5603861544162 := by decide
theorem cert_e1205815033058 : check e1205815033058 [[],[]] .chain = true := by decide
def e1205815033070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815033070 : Closed e1205815033070 ∧ code e1205815033070 = 5603861544174 := by decide
theorem cert_e1205815033070 : check e1205815033070 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815033078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815033078 : Closed e1205815033078 ∧ code e1205815033078 = 5603861544182 := by decide
theorem cert_e1205815033078 : check e1205815033078 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815052254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e1205815052254 : Closed e1205815052254 ∧ code e1205815052254 = 5603861563358 := by decide
theorem cert_e1205815052254 : check e1205815052254 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815055918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205815055918 : Closed e1205815055918 ∧ code e1205815055918 = 5603861567022 := by decide
theorem cert_e1205815055918 : check e1205815055918 [[],[]] .chain = true := by decide
def e1205815056098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205815056098 : Closed e1205815056098 ∧ code e1205815056098 = 5603861567202 := by decide
theorem cert_e1205815056098 : check e1205815056098 [[],[]] .chain = true := by decide
def e1205815056110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1205815056110 : Closed e1205815056110 ∧ code e1205815056110 = 5603861567214 := by decide
theorem cert_e1205815056110 : check e1205815056110 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815056238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1205815056238 : Closed e1205815056238 ∧ code e1205815056238 = 5603861567342 := by decide
theorem cert_e1205815056238 : check e1205815056238 [[],[]] .chain = true := by decide
def e1205815056246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1205815056246 : Closed e1205815056246 ∧ code e1205815056246 = 5603861567350 := by decide
theorem cert_e1205815056246 : check e1205815056246 [[],[]] .chain = true := by decide
def e1205815056266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815056266 : Closed e1205815056266 ∧ code e1205815056266 = 5603861567370 := by decide
theorem cert_e1205815056266 : check e1205815056266 [[],[]] .chain = true := by decide
def e1205815056290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815056290 : Closed e1205815056290 ∧ code e1205815056290 = 5603861567394 := by decide
theorem cert_e1205815056290 : check e1205815056290 [[],[]] .chain = true := by decide
def e1205815056302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1205815056302 : Closed e1205815056302 ∧ code e1205815056302 = 5603861567406 := by decide
theorem cert_e1205815056302 : check e1205815056302 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815056310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1205815056310 : Closed e1205815056310 ∧ code e1205815056310 = 5603861567414 := by decide
theorem cert_e1205815056310 : check e1205815056310 [[],[]] .chain = true := by decide
def e1205815056314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1205815056314 : Closed e1205815056314 ∧ code e1205815056314 = 5603861567418 := by decide
theorem cert_e1205815056314 : check e1205815056314 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815056446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e1205815056446 : Closed e1205815056446 ∧ code e1205815056446 = 5603861567550 := by decide
theorem cert_e1205815056446 : check e1205815056446 [[],[]] .chain = true := by decide
def e1205815056866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1205815056866 : Closed e1205815056866 ∧ code e1205815056866 = 5603861567970 := by decide
theorem cert_e1205815056866 : check e1205815056866 [[],[]] .chain = true := by decide
def e1205815056878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1205815056878 : Closed e1205815056878 ∧ code e1205815056878 = 5603861567982 := by decide
theorem cert_e1205815056878 : check e1205815056878 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815057646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815057646 : Closed e1205815057646 ∧ code e1205815057646 = 5603861568750 := by decide
theorem cert_e1205815057646 : check e1205815057646 [[],[]] .chain = true := by decide
def e1205815057654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815057654 : Closed e1205815057654 ∧ code e1205815057654 = 5603861568758 := by decide
theorem cert_e1205815057654 : check e1205815057654 [[],[]] .chain = true := by decide
def e1205815057934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815057934 : Closed e1205815057934 ∧ code e1205815057934 = 5603861569038 := by decide
theorem cert_e1205815057934 : check e1205815057934 [[],[]] .chain = true := by decide
def e1205815057946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815057946 : Closed e1205815057946 ∧ code e1205815057946 = 5603861569050 := by decide
theorem cert_e1205815057946 : check e1205815057946 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815058018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815058018 : Closed e1205815058018 ∧ code e1205815058018 = 5603861569122 := by decide
theorem cert_e1205815058018 : check e1205815058018 [[],[]] .chain = true := by decide
def e1205815058030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815058030 : Closed e1205815058030 ∧ code e1205815058030 = 5603861569134 := by decide
theorem cert_e1205815058030 : check e1205815058030 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815058038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815058038 : Closed e1205815058038 ∧ code e1205815058038 = 5603861569142 := by decide
theorem cert_e1205815058038 : check e1205815058038 [[],[]] .chain = true := by decide
def e1205815058042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815058042 : Closed e1205815058042 ∧ code e1205815058042 = 5603861569146 := by decide
theorem cert_e1205815058042 : check e1205815058042 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205815067614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1205815067614 : Closed e1205815067614 ∧ code e1205815067614 = 5603861578718 := by decide
theorem cert_e1205815067614 : check e1205815067614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815067630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1205815067630 : Closed e1205815067630 ∧ code e1205815067630 = 5603861578734 := by decide
theorem cert_e1205815067630 : check e1205815067630 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205815069462 : Closed e1205815069462 ∧ code e1205815069462 = 5603861580566 := by decide
theorem cert_e1205815069462 : check e1205815069462 [[],[]] .chain = true := by decide
def e1205815069538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205815069538 : Closed e1205815069538 ∧ code e1205815069538 = 5603861580642 := by decide
theorem cert_e1205815069538 : check e1205815069538 [[],[]] .chain = true := by decide
def e1205815069550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205815069550 : Closed e1205815069550 ∧ code e1205815069550 = 5603861580654 := by decide
theorem cert_e1205815069550 : check e1205815069550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205815069558 : Closed e1205815069558 ∧ code e1205815069558 = 5603861580662 := by decide
theorem cert_e1205815069558 : check e1205815069558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815069578 : Closed e1205815069578 ∧ code e1205815069578 = 5603861580682 := by decide
theorem cert_e1205815069578 : check e1205815069578 [[],[]] .chain = true := by decide
def e1205815069602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815069602 : Closed e1205815069602 ∧ code e1205815069602 = 5603861580706 := by decide
theorem cert_e1205815069602 : check e1205815069602 [[],[]] .chain = true := by decide
def e1205815069614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205815069614 : Closed e1205815069614 ∧ code e1205815069614 = 5603861580718 := by decide
theorem cert_e1205815069614 : check e1205815069614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e1205815069622 : Closed e1205815069622 ∧ code e1205815069622 = 5603861580726 := by decide
theorem cert_e1205815069622 : check e1205815069622 [[],[]] .chain = true := by decide
def e1205815069626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205815069626 : Closed e1205815069626 ∧ code e1205815069626 = 5603861580730 := by decide
theorem cert_e1205815069626 : check e1205815069626 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205815069654 : Closed e1205815069654 ∧ code e1205815069654 = 5603861580758 := by decide
theorem cert_e1205815069654 : check e1205815069654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205815069658 : Closed e1205815069658 ∧ code e1205815069658 = 5603861580762 := by decide
theorem cert_e1205815069658 : check e1205815069658 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e1205815069726 : Closed e1205815069726 ∧ code e1205815069726 = 5603861580830 := by decide
theorem cert_e1205815069726 : check e1205815069726 [[],[]] .chain = true := by decide
def e1205815069922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205815069922 : Closed e1205815069922 ∧ code e1205815069922 = 5603861581026 := by decide
theorem cert_e1205815069922 : check e1205815069922 [[],[]] .chain = true := by decide
def e1205815069934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815069934 : Closed e1205815069934 ∧ code e1205815069934 = 5603861581038 := by decide
theorem cert_e1205815069934 : check e1205815069934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815069942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815069942 : Closed e1205815069942 ∧ code e1205815069942 = 5603861581046 := by decide
theorem cert_e1205815069942 : check e1205815069942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815070222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815070222 : Closed e1205815070222 ∧ code e1205815070222 = 5603861581326 := by decide
theorem cert_e1205815070222 : check e1205815070222 [[],[]] .chain = true := by decide
def e1205815070234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815070234 : Closed e1205815070234 ∧ code e1205815070234 = 5603861581338 := by decide
theorem cert_e1205815070234 : check e1205815070234 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815070306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815070306 : Closed e1205815070306 ∧ code e1205815070306 = 5603861581410 := by decide
theorem cert_e1205815070306 : check e1205815070306 [[],[]] .chain = true := by decide
def e1205815070318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815070318 : Closed e1205815070318 ∧ code e1205815070318 = 5603861581422 := by decide
theorem cert_e1205815070318 : check e1205815070318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815070326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815070326 : Closed e1205815070326 ∧ code e1205815070326 = 5603861581430 := by decide
theorem cert_e1205815070326 : check e1205815070326 [[],[]] .chain = true := by decide
def e1205815070330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815070330 : Closed e1205815070330 ∧ code e1205815070330 = 5603861581434 := by decide
theorem cert_e1205815070330 : check e1205815070330 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815070518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815070518 : Closed e1205815070518 ∧ code e1205815070518 = 5603861581622 := by decide
theorem cert_e1205815070518 : check e1205815070518 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815070522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815070522 : Closed e1205815070522 ∧ code e1205815070522 = 5603861581626 := by decide
theorem cert_e1205815070522 : check e1205815070522 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205815086702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815086702 : Closed e1205815086702 ∧ code e1205815086702 = 5603861597806 := by decide
theorem cert_e1205815086702 : check e1205815086702 [[],[]] .chain = true := by decide
def e1205815086714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815086714 : Closed e1205815086714 ∧ code e1205815086714 = 5603861597818 := by decide
theorem cert_e1205815086714 : check e1205815086714 [[],[]] .chain = true := by decide
def e1205815087002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815087002 : Closed e1205815087002 ∧ code e1205815087002 = 5603861598106 := by decide
theorem cert_e1205815087002 : check e1205815087002 [[],[]] .chain = true := by decide
def e1205815089774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815089774 : Closed e1205815089774 ∧ code e1205815089774 = 5603861600878 := by decide
theorem cert_e1205815089774 : checkPay e1205815089774 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815089786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815089786 : Closed e1205815089786 ∧ code e1205815089786 = 5603861600890 := by decide
theorem cert_e1205815089786 : checkPay e1205815089786 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1205815090670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))
theorem wire_e1205815090670 : Closed e1205815090670 ∧ code e1205815090670 = 5603861601774 := by decide
theorem cert_e1205815090670 : checkPay e1205815090670 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left],[.under]] = true := by decide
def e1205815091054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))
theorem wire_e1205815091054 : Closed e1205815091054 ∧ code e1205815091054 = 5603861602158 := by decide
theorem cert_e1205815091054 : checkPay e1205815091054 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1205815091066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))
theorem wire_e1205815091066 : Closed e1205815091066 ∧ code e1205815091066 = 5603861602170 := by decide
theorem cert_e1205815091066 : checkPay e1205815091066 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1205815092654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1205815092654 : Closed e1205815092654 ∧ code e1205815092654 = 5603861603758 := by decide
theorem cert_e1205815092654 : check e1205815092654 [[],[]] .chain = true := by decide
def e1205815092666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1205815092666 : Closed e1205815092666 ∧ code e1205815092666 = 5603861603770 := by decide
theorem cert_e1205815092666 : check e1205815092666 [[],[]] .chain = true := by decide
def e1205815092714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1205815092714 : Closed e1205815092714 ∧ code e1205815092714 = 5603861603818 := by decide
theorem cert_e1205815092714 : check e1205815092714 [[],[]] .chain = true := by decide
def e1205815092846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815092846 : Closed e1205815092846 ∧ code e1205815092846 = 5603861603950 := by decide
theorem cert_e1205815092846 : check e1205815092846 [[],[]] .chain = true := by decide
def e1205815092858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815092858 : Closed e1205815092858 ∧ code e1205815092858 = 5603861603962 := by decide
theorem cert_e1205815092858 : check e1205815092858 [[],[]] .chain = true := by decide
def e1205815093146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815093146 : Closed e1205815093146 ∧ code e1205815093146 = 5603861604250 := by decide
theorem cert_e1205815093146 : check e1205815093146 [[],[]] .chain = true := by decide
def e1205815096094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1205815096094 : Closed e1205815096094 ∧ code e1205815096094 = 5603861607198 := by decide
theorem cert_e1205815096094 : check e1205815096094 [[],[]] .chain = true := by decide
def e1205815096262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1205815096262 : Closed e1205815096262 ∧ code e1205815096262 = 5603861607366 := by decide
theorem cert_e1205815096262 : check e1205815096262 [[],[]] .chain = true := by decide
def e1205815098566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1205815098566 : Closed e1205815098566 ∧ code e1205815098566 = 5603861609670 := by decide
theorem cert_e1205815098566 : check e1205815098566 [[],[]] .chain = true := by decide
def e1205815105710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e1205815105710 : Closed e1205815105710 ∧ code e1205815105710 = 5603861616814 := by decide
theorem cert_e1205815105710 : check e1205815105710 [[],[]] .chain = true := by decide
def e1205815105722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e1205815105722 : Closed e1205815105722 ∧ code e1205815105722 = 5603861616826 := by decide
theorem cert_e1205815105722 : check e1205815105722 [[],[]] .chain = true := by decide
def e1205815106094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1205815106094 : Closed e1205815106094 ∧ code e1205815106094 = 5603861617198 := by decide
theorem cert_e1205815106094 : check e1205815106094 [[],[]] .chain = true := by decide
def e1205815106274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1205815106274 : Closed e1205815106274 ∧ code e1205815106274 = 5603861617378 := by decide
theorem cert_e1205815106274 : check e1205815106274 [[],[]] .chain = true := by decide
def e1205815106286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e1205815106286 : Closed e1205815106286 ∧ code e1205815106286 = 5603861617390 := by decide
theorem cert_e1205815106286 : checkPay e1205815106286 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1205815106414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1205815106414 : Closed e1205815106414 ∧ code e1205815106414 = 5603861617518 := by decide
theorem cert_e1205815106414 : check e1205815106414 [[],[]] .chain = true := by decide
def e1205815106422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1205815106422 : Closed e1205815106422 ∧ code e1205815106422 = 5603861617526 := by decide
theorem cert_e1205815106422 : check e1205815106422 [[],[]] .chain = true := by decide
def e1205815106442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205815106442 : Closed e1205815106442 ∧ code e1205815106442 = 5603861617546 := by decide
theorem cert_e1205815106442 : check e1205815106442 [[],[]] .chain = true := by decide
def e1205815106466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205815106466 : Closed e1205815106466 ∧ code e1205815106466 = 5603861617570 := by decide
theorem cert_e1205815106466 : check e1205815106466 [[],[]] .chain = true := by decide
def e1205815106478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e1205815106478 : Closed e1205815106478 ∧ code e1205815106478 = 5603861617582 := by decide
theorem cert_e1205815106478 : checkPay e1205815106478 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.under,.left]] = true := by decide
def e1205815106486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1205815106486 : Closed e1205815106486 ∧ code e1205815106486 = 5603861617590 := by decide
theorem cert_e1205815106486 : check e1205815106486 [[],[]] .chain = true := by decide
def e1205815106490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e1205815106490 : Closed e1205815106490 ∧ code e1205815106490 = 5603861617594 := by decide
theorem cert_e1205815106490 : checkPay e1205815106490 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.under,.left],[.under]] = true := by decide
def e1205815106926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1205815106926 : Closed e1205815106926 ∧ code e1205815106926 = 5603861618030 := by decide
theorem cert_e1205815106926 : check e1205815106926 [[],[]] .chain = true := by decide
def e1205815106934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1205815106934 : Closed e1205815106934 ∧ code e1205815106934 = 5603861618038 := by decide
theorem cert_e1205815106934 : check e1205815106934 [[],[]] .chain = true := by decide
def e1205815106990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1205815106990 : Closed e1205815106990 ∧ code e1205815106990 = 5603861618094 := by decide
theorem cert_e1205815106990 : check e1205815106990 [[],[]] .chain = true := by decide
def e1205815107002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1205815107002 : Closed e1205815107002 ∧ code e1205815107002 = 5603861618106 := by decide
theorem cert_e1205815107002 : check e1205815107002 [[],[]] .chain = true := by decide
def e1205815107030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1205815107030 : Closed e1205815107030 ∧ code e1205815107030 = 5603861618134 := by decide
theorem cert_e1205815107030 : check e1205815107030 [[],[]] .chain = true := by decide
def e1205815107034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1205815107034 : Closed e1205815107034 ∧ code e1205815107034 = 5603861618138 := by decide
theorem cert_e1205815107034 : check e1205815107034 [[],[]] .chain = true := by decide
def e1205815107114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e1205815107114 : Closed e1205815107114 ∧ code e1205815107114 = 5603861618218 := by decide
theorem cert_e1205815107114 : check e1205815107114 [[],[]] .chain = true := by decide
def e1205815107210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1205815107210 : Closed e1205815107210 ∧ code e1205815107210 = 5603861618314 := by decide
theorem cert_e1205815107210 : check e1205815107210 [[],[]] .chain = true := by decide
def e1205815107234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1205815107234 : Closed e1205815107234 ∧ code e1205815107234 = 5603861618338 := by decide
theorem cert_e1205815107234 : check e1205815107234 [[],[]] .chain = true := by decide
def e1205815107246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1205815107246 : Closed e1205815107246 ∧ code e1205815107246 = 5603861618350 := by decide
theorem cert_e1205815107246 : checkPay e1205815107246 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left,.right,.left]] = true := by decide
def e1205815107254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1205815107254 : Closed e1205815107254 ∧ code e1205815107254 = 5603861618358 := by decide
theorem cert_e1205815107254 : check e1205815107254 [[],[]] .chain = true := by decide
def e1205815107258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1205815107258 : Closed e1205815107258 ∧ code e1205815107258 = 5603861618362 := by decide
theorem cert_e1205815107258 : checkPay e1205815107258 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1205815107286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1205815107286 : Closed e1205815107286 ∧ code e1205815107286 = 5603861618390 := by decide
theorem cert_e1205815107286 : check e1205815107286 [[],[]] .chain = true := by decide
def e1205815107290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1205815107290 : Closed e1205815107290 ∧ code e1205815107290 = 5603861618394 := by decide
theorem cert_e1205815107290 : check e1205815107290 [[],[]] .chain = true := by decide
def e1205815107306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1205815107306 : Closed e1205815107306 ∧ code e1205815107306 = 5603861618410 := by decide
theorem cert_e1205815107306 : checkPay e1205815107306 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right]] = true := by decide
def e1205815107822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e1205815107822 : Closed e1205815107822 ∧ code e1205815107822 = 5603861618926 := by decide
theorem cert_e1205815107822 : check e1205815107822 [[],[]] .chain = true := by decide
def e1205815107834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e1205815107834 : Closed e1205815107834 ∧ code e1205815107834 = 5603861618938 := by decide
theorem cert_e1205815107834 : check e1205815107834 [[],[]] .chain = true := by decide
def e1205815108014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e1205815108014 : Closed e1205815108014 ∧ code e1205815108014 = 5603861619118 := by decide
theorem cert_e1205815108014 : checkPay e1205815108014 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1205815108206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815108206 : Closed e1205815108206 ∧ code e1205815108206 = 5603861619310 := by decide
theorem cert_e1205815108206 : check e1205815108206 [[],[]] .chain = true := by decide
def e1205815108218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815108218 : Closed e1205815108218 ∧ code e1205815108218 = 5603861619322 := by decide
theorem cert_e1205815108218 : check e1205815108218 [[],[]] .chain = true := by decide
def e1205815108382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1205815108382 : Closed e1205815108382 ∧ code e1205815108382 = 5603861619486 := by decide
theorem cert_e1205815108382 : check e1205815108382 [[],[]] .chain = true := by decide
def e1205815108550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e1205815108550 : Closed e1205815108550 ∧ code e1205815108550 = 5603861619654 := by decide
theorem cert_e1205815108550 : check e1205815108550 [[],[]] .chain = true := by decide
def e1205815109166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e1205815109166 : Closed e1205815109166 ∧ code e1205815109166 = 5603861620270 := by decide
theorem cert_e1205815109166 : check e1205815109166 [[],[]] .chain = true := by decide
def e1205815109346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1205815109346 : Closed e1205815109346 ∧ code e1205815109346 = 5603861620450 := by decide
theorem cert_e1205815109346 : check e1205815109346 [[],[]] .chain = true := by decide
def e1205815109358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e1205815109358 : Closed e1205815109358 ∧ code e1205815109358 = 5603861620462 := by decide
theorem cert_e1205815109358 : checkPay e1205815109358 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1205815109486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1205815109486 : Closed e1205815109486 ∧ code e1205815109486 = 5603861620590 := by decide
theorem cert_e1205815109486 : check e1205815109486 [[],[]] .chain = true := by decide
def e1205815109494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1205815109494 : Closed e1205815109494 ∧ code e1205815109494 = 5603861620598 := by decide
theorem cert_e1205815109494 : check e1205815109494 [[],[]] .chain = true := by decide
def e1205815109514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1205815109514 : Closed e1205815109514 ∧ code e1205815109514 = 5603861620618 := by decide
theorem cert_e1205815109514 : check e1205815109514 [[],[]] .chain = true := by decide
def e1205815109538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e1205815109538 : Closed e1205815109538 ∧ code e1205815109538 = 5603861620642 := by decide
theorem cert_e1205815109538 : check e1205815109538 [[],[]] .chain = true := by decide
def e1205815109550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e1205815109550 : Closed e1205815109550 ∧ code e1205815109550 = 5603861620654 := by decide
theorem cert_e1205815109550 : checkPay e1205815109550 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e1205815109558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1205815109558 : Closed e1205815109558 ∧ code e1205815109558 = 5603861620662 := by decide
theorem cert_e1205815109558 : check e1205815109558 [[],[]] .chain = true := by decide
def e1205815109562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1205815109562 : Closed e1205815109562 ∧ code e1205815109562 = 5603861620666 := by decide
theorem cert_e1205815109562 : checkPay e1205815109562 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e1205815109694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e1205815109694 : Closed e1205815109694 ∧ code e1205815109694 = 5603861620798 := by decide
theorem cert_e1205815109694 : check e1205815109694 [[],[]] .chain = true := by decide
def e1205815110114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1205815110114 : Closed e1205815110114 ∧ code e1205815110114 = 5603861621218 := by decide
theorem cert_e1205815110114 : check e1205815110114 [[],[]] .chain = true := by decide
def e1205815110126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e1205815110126 : Closed e1205815110126 ∧ code e1205815110126 = 5603861621230 := by decide
theorem cert_e1205815110126 : checkPay e1205815110126 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1205815110894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815110894 : Closed e1205815110894 ∧ code e1205815110894 = 5603861621998 := by decide
theorem cert_e1205815110894 : check e1205815110894 [[],[]] .chain = true := by decide
def e1205815110902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815110902 : Closed e1205815110902 ∧ code e1205815110902 = 5603861622006 := by decide
theorem cert_e1205815110902 : check e1205815110902 [[],[]] .chain = true := by decide
def e1205815111182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e1205815111182 : Closed e1205815111182 ∧ code e1205815111182 = 5603861622286 := by decide
theorem cert_e1205815111182 : check e1205815111182 [[],[]] .chain = true := by decide
def e1205815111194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205815111194 : Closed e1205815111194 ∧ code e1205815111194 = 5603861622298 := by decide
theorem cert_e1205815111194 : checkPay e1205815111194 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e1205815111266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205815111266 : Closed e1205815111266 ∧ code e1205815111266 = 5603861622370 := by decide
theorem cert_e1205815111266 : check e1205815111266 [[],[]] .chain = true := by decide
def e1205815111278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815111278 : Closed e1205815111278 ∧ code e1205815111278 = 5603861622382 := by decide
theorem cert_e1205815111278 : checkPay e1205815111278 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e1205815111286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1205815111286 : Closed e1205815111286 ∧ code e1205815111286 = 5603861622390 := by decide
theorem cert_e1205815111286 : check e1205815111286 [[],[]] .chain = true := by decide
def e1205815111290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815111290 : Closed e1205815111290 ∧ code e1205815111290 = 5603861622394 := by decide
theorem cert_e1205815111290 : checkPay e1205815111290 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.under,.right]] = true := by decide
def e1205815112558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1205815112558 : Closed e1205815112558 ∧ code e1205815112558 = 5603861623662 := by decide
theorem cert_e1205815112558 : check e1205815112558 [[],[]] .chain = true := by decide
def e1205815112566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1205815112566 : Closed e1205815112566 ∧ code e1205815112566 = 5603861623670 := by decide
theorem cert_e1205815112566 : check e1205815112566 [[],[]] .chain = true := by decide
def e1205815112622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1205815112622 : Closed e1205815112622 ∧ code e1205815112622 = 5603861623726 := by decide
theorem cert_e1205815112622 : check e1205815112622 [[],[]] .chain = true := by decide
def e1205815112634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1205815112634 : Closed e1205815112634 ∧ code e1205815112634 = 5603861623738 := by decide
theorem cert_e1205815112634 : check e1205815112634 [[],[]] .chain = true := by decide
def e1205815112662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1205815112662 : Closed e1205815112662 ∧ code e1205815112662 = 5603861623766 := by decide
theorem cert_e1205815112662 : check e1205815112662 [[],[]] .chain = true := by decide
def e1205815112666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1205815112666 : Closed e1205815112666 ∧ code e1205815112666 = 5603861623770 := by decide
theorem cert_e1205815112666 : check e1205815112666 [[],[]] .chain = true := by decide
def e1205815112942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1205815112942 : Closed e1205815112942 ∧ code e1205815112942 = 5603861624046 := by decide
theorem cert_e1205815112942 : check e1205815112942 [[],[]] .chain = true := by decide
def e1205815112950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1205815112950 : Closed e1205815112950 ∧ code e1205815112950 = 5603861624054 := by decide
theorem cert_e1205815112950 : check e1205815112950 [[],[]] .chain = true := by decide
def e1205815113326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815113326 : Closed e1205815113326 ∧ code e1205815113326 = 5603861624430 := by decide
theorem cert_e1205815113326 : check e1205815113326 [[],[]] .chain = true := by decide
def e1205815113338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815113338 : Closed e1205815113338 ∧ code e1205815113338 = 5603861624442 := by decide
theorem cert_e1205815113338 : check e1205815113338 [[],[]] .chain = true := by decide
def e1205815113526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815113526 : Closed e1205815113526 ∧ code e1205815113526 = 5603861624630 := by decide
theorem cert_e1205815113526 : check e1205815113526 [[],[]] .chain = true := by decide
def e1205815113530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815113530 : Closed e1205815113530 ∧ code e1205815113530 = 5603861624634 := by decide
theorem cert_e1205815113530 : check e1205815113530 [[],[]] .chain = true := by decide
end Blc.Floor42
