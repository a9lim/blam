import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209167973230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209167973230 : Closed e1209167973230 ∧ code e1209167973230 = 5607214484334 := by decide
theorem cert_e1209167973230 : check e1209167973230 [[],[]] .smaller = true := by decide
def e1209167973238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209167973238 : Closed e1209167973238 ∧ code e1209167973238 = 5607214484342 := by decide
theorem cert_e1209167973238 : check e1209167973238 [[],[]] .smaller = true := by decide
def e1209167973294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209167973294 : Closed e1209167973294 ∧ code e1209167973294 = 5607214484398 := by decide
theorem cert_e1209167973294 : check e1209167973294 [[],[]] .smaller = true := by decide
def e1209167973306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209167973306 : Closed e1209167973306 ∧ code e1209167973306 = 5607214484410 := by decide
theorem cert_e1209167973306 : check e1209167973306 [[],[]] .smaller = true := by decide
def e1209167973334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209167973334 : Closed e1209167973334 ∧ code e1209167973334 = 5607214484438 := by decide
theorem cert_e1209167973334 : check e1209167973334 [[],[]] .smaller = true := by decide
def e1209167973338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209167973338 : Closed e1209167973338 ∧ code e1209167973338 = 5607214484442 := by decide
theorem cert_e1209167973338 : check e1209167973338 [[],[]] .smaller = true := by decide
def e1209167973614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209167973614 : Closed e1209167973614 ∧ code e1209167973614 = 5607214484718 := by decide
theorem cert_e1209167973614 : check e1209167973614 [[],[]] .smaller = true := by decide
def e1209167973622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209167973622 : Closed e1209167973622 ∧ code e1209167973622 = 5607214484726 := by decide
theorem cert_e1209167973622 : check e1209167973622 [[],[]] .smaller = true := by decide
def e1209167973998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209167973998 : Closed e1209167973998 ∧ code e1209167973998 = 5607214485102 := by decide
theorem cert_e1209167973998 : check e1209167973998 [[],[]] .smaller = true := by decide
def e1209167974010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209167974010 : Closed e1209167974010 ∧ code e1209167974010 = 5607214485114 := by decide
theorem cert_e1209167974010 : check e1209167974010 [[],[]] .smaller = true := by decide
def e1209167974198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209167974198 : Closed e1209167974198 ∧ code e1209167974198 = 5607214485302 := by decide
theorem cert_e1209167974198 : check e1209167974198 [[],[]] .smaller = true := by decide
def e1209167974202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209167974202 : Closed e1209167974202 ∧ code e1209167974202 = 5607214485306 := by decide
theorem cert_e1209167974202 : check e1209167974202 [[],[]] .smaller = true := by decide
def e1209167981678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209167981678 : Closed e1209167981678 ∧ code e1209167981678 = 5607214492782 := by decide
theorem cert_e1209167981678 : check e1209167981678 [[],[]] .chain = true := by decide
def e1209167981690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209167981690 : Closed e1209167981690 ∧ code e1209167981690 = 5607214492794 := by decide
theorem cert_e1209167981690 : check e1209167981690 [[],[]] .chain = true := by decide
def e1209167981854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209167981854 : Closed e1209167981854 ∧ code e1209167981854 = 5607214492958 := by decide
theorem cert_e1209167981854 : check e1209167981854 [[],[]] .chain = true := by decide
def e1209167982022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209167982022 : Closed e1209167982022 ∧ code e1209167982022 = 5607214493126 := by decide
theorem cert_e1209167982022 : check e1209167982022 [[],[]] .chain = true := by decide
def e1209167982362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1209167982362 : Closed e1209167982362 ∧ code e1209167982362 = 5607214493466 := by decide
theorem cert_e1209167982362 : check e1209167982362 [[],[]] .chain = true := by decide
def e1209167982406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1209167982406 : Closed e1209167982406 ∧ code e1209167982406 = 5607214493510 := by decide
theorem cert_e1209167982406 : check e1209167982406 [[],[]] .chain = true := by decide
def e1209167983390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209167983390 : Closed e1209167983390 ∧ code e1209167983390 = 5607214494494 := by decide
theorem cert_e1209167983390 : check e1209167983390 [[],[]] .chain = true := by decide
def e1209167983558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209167983558 : Closed e1209167983558 ∧ code e1209167983558 = 5607214494662 := by decide
theorem cert_e1209167983558 : check e1209167983558 [[],[]] .chain = true := by decide
def e1209167985862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1209167985862 : Closed e1209167985862 ∧ code e1209167985862 = 5607214496966 := by decide
theorem cert_e1209167985862 : check e1209167985862 [[],[]] .chain = true := by decide
def e1209168008758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209168008758 : Closed e1209168008758 ∧ code e1209168008758 = 5607214519862 := by decide
theorem cert_e1209168008758 : check e1209168008758 [[],[]] .chain = true := by decide
def e1209168008762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209168008762 : Closed e1209168008762 ∧ code e1209168008762 = 5607214519866 := by decide
theorem cert_e1209168008762 : check e1209168008762 [[],[]] .chain = true := by decide
def e1209168008846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209168008846 : Closed e1209168008846 ∧ code e1209168008846 = 5607214519950 := by decide
theorem cert_e1209168008846 : check e1209168008846 [[],[]] .chain = true := by decide
def e1209168008902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209168008902 : Closed e1209168008902 ∧ code e1209168008902 = 5607214520006 := by decide
theorem cert_e1209168008902 : check e1209168008902 [[],[]] .chain = true := by decide
def e1209168008986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1209168008986 : Closed e1209168008986 ∧ code e1209168008986 = 5607214520090 := by decide
theorem cert_e1209168008986 : check e1209168008986 [[],[]] .chain = true := by decide
def e1209168009030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1209168009030 : Closed e1209168009030 ∧ code e1209168009030 = 5607214520134 := by decide
theorem cert_e1209168009030 : check e1209168009030 [[],[]] .chain = true := by decide
def e1209168009614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209168009614 : Closed e1209168009614 ∧ code e1209168009614 = 5607214520718 := by decide
theorem cert_e1209168009614 : check e1209168009614 [[],[]] .chain = true := by decide
def e1209168009670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209168009670 : Closed e1209168009670 ∧ code e1209168009670 = 5607214520774 := by decide
theorem cert_e1209168009670 : check e1209168009670 [[],[]] .chain = true := by decide
def e1209168010438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1209168010438 : Closed e1209168010438 ∧ code e1209168010438 = 5607214521542 := by decide
theorem cert_e1209168010438 : check e1209168010438 [[],[]] .chain = true := by decide
def e1209169107182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1209169107182 : Closed e1209169107182 ∧ code e1209169107182 = 5607215618286 := by decide
theorem cert_e1209169107182 : check e1209169107182 [[],[]] .chain = true := by decide
def e1209169107190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1209169107190 : Closed e1209169107190 ∧ code e1209169107190 = 5607215618294 := by decide
theorem cert_e1209169107190 : check e1209169107190 [[],[]] .chain = true := by decide
def e1209169107742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1209169107742 : Closed e1209169107742 ∧ code e1209169107742 = 5607215618846 := by decide
theorem cert_e1209169107742 : check e1209169107742 [[],[]] .chain = true := by decide
def e1209169107854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1209169107854 : Closed e1209169107854 ∧ code e1209169107854 = 5607215618958 := by decide
theorem cert_e1209169107854 : check e1209169107854 [[],[]] .chain = true := by decide
def e1209169108078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209169108078 : Closed e1209169108078 ∧ code e1209169108078 = 5607215619182 := by decide
theorem cert_e1209169108078 : check e1209169108078 [[],[]] .chain = true := by decide
def e1209169108090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209169108090 : Closed e1209169108090 ∧ code e1209169108090 = 5607215619194 := by decide
theorem cert_e1209169108090 : check e1209169108090 [[],[]] .chain = true := by decide
def e1209169108254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209169108254 : Closed e1209169108254 ∧ code e1209169108254 = 5607215619358 := by decide
theorem cert_e1209169108254 : check e1209169108254 [[],[]] .chain = true := by decide
def e1209169108422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209169108422 : Closed e1209169108422 ∧ code e1209169108422 = 5607215619526 := by decide
theorem cert_e1209169108422 : check e1209169108422 [[],[]] .chain = true := by decide
def e1209169108534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209169108534 : Closed e1209169108534 ∧ code e1209169108534 = 5607215619638 := by decide
theorem cert_e1209169108534 : check e1209169108534 [[],[]] .chain = true := by decide
def e1209169108538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209169108538 : Closed e1209169108538 ∧ code e1209169108538 = 5607215619642 := by decide
theorem cert_e1209169108538 : check e1209169108538 [[],[]] .chain = true := by decide
def e1209169108622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209169108622 : Closed e1209169108622 ∧ code e1209169108622 = 5607215619726 := by decide
theorem cert_e1209169108622 : check e1209169108622 [[],[]] .chain = true := by decide
def e1209169108678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209169108678 : Closed e1209169108678 ∧ code e1209169108678 = 5607215619782 := by decide
theorem cert_e1209169108678 : check e1209169108678 [[],[]] .chain = true := by decide
def e1209169110814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1209169110814 : Closed e1209169110814 ∧ code e1209169110814 = 5607215621918 := by decide
theorem cert_e1209169110814 : check e1209169110814 [[],[]] .chain = true := by decide
def e1209169110926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1209169110926 : Closed e1209169110926 ∧ code e1209169110926 = 5607215622030 := by decide
theorem cert_e1209169110926 : check e1209169110926 [[],[]] .chain = true := by decide
def e1209169113886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209169113886 : Closed e1209169113886 ∧ code e1209169113886 = 5607215624990 := by decide
theorem cert_e1209169113886 : check e1209169113886 [[],[]] .chain = true := by decide
def e1209169114054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209169114054 : Closed e1209169114054 ∧ code e1209169114054 = 5607215625158 := by decide
theorem cert_e1209169114054 : check e1209169114054 [[],[]] .chain = true := by decide
def e1209169115534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209169115534 : Closed e1209169115534 ∧ code e1209169115534 = 5607215626638 := by decide
theorem cert_e1209169115534 : check e1209169115534 [[],[]] .chain = true := by decide
def e1209169115590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209169115590 : Closed e1209169115590 ∧ code e1209169115590 = 5607215626694 := by decide
theorem cert_e1209169115590 : check e1209169115590 [[],[]] .chain = true := by decide
def e1209173808862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1209173808862 : Closed e1209173808862 ∧ code e1209173808862 = 5607220319966 := by decide
theorem cert_e1209173808862 : check e1209173808862 [[],[],[.left]] .chain = true := by decide
def e1209173808886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1209173808886 : Closed e1209173808886 ∧ code e1209173808886 = 5607220319990 := by decide
theorem cert_e1209173808886 : check e1209173808886 [[],[],[.left]] .chain = true := by decide
def e1209173808990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1209173808990 : Closed e1209173808990 ∧ code e1209173808990 = 5607220320094 := by decide
theorem cert_e1209173808990 : check e1209173808990 [[],[],[.left]] .chain = true := by decide
def e1209173809018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1209173809018 : Closed e1209173809018 ∧ code e1209173809018 = 5607220320122 := by decide
theorem cert_e1209173809018 : check e1209173809018 [[],[],[.left]] .chain = true := by decide
def e1209173809110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1209173809110 : Closed e1209173809110 ∧ code e1209173809110 = 5607220320214 := by decide
theorem cert_e1209173809110 : check e1209173809110 [[],[],[.left]] .chain = true := by decide
def e1209173809114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1209173809114 : Closed e1209173809114 ∧ code e1209173809114 = 5607220320218 := by decide
theorem cert_e1209173809114 : check e1209173809114 [[],[],[.left]] .chain = true := by decide
def e1209173809630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1209173809630 : Closed e1209173809630 ∧ code e1209173809630 = 5607220320734 := by decide
theorem cert_e1209173809630 : check e1209173809630 [[],[],[.left]] .chain = true := by decide
def e1209173809654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1209173809654 : Closed e1209173809654 ∧ code e1209173809654 = 5607220320758 := by decide
theorem cert_e1209173809654 : check e1209173809654 [[],[],[.left]] .chain = true := by decide
def e1209173810398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1209173810398 : Closed e1209173810398 ∧ code e1209173810398 = 5607220321502 := by decide
theorem cert_e1209173810398 : check e1209173810398 [[],[],[.left]] .chain = true := by decide
def e1209173810426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1209173810426 : Closed e1209173810426 ∧ code e1209173810426 = 5607220321530 := by decide
theorem cert_e1209173810426 : check e1209173810426 [[],[],[.left]] .chain = true := by decide
def e1209173810998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209173810998 : Closed e1209173810998 ∧ code e1209173810998 = 5607220322102 := by decide
theorem cert_e1209173810998 : check e1209173810998 [[],[],[.left]] .chain = true := by decide
def e1209173811002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209173811002 : Closed e1209173811002 ∧ code e1209173811002 = 5607220322106 := by decide
theorem cert_e1209173811002 : check e1209173811002 [[],[],[.left]] .chain = true := by decide
def e1209173825774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1209173825774 : Closed e1209173825774 ∧ code e1209173825774 = 5607220336878 := by decide
theorem cert_e1209173825774 : check e1209173825774 [[],[],[.left]] .chain = true := by decide
def e1209173825782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1209173825782 : Closed e1209173825782 ∧ code e1209173825782 = 5607220336886 := by decide
theorem cert_e1209173825782 : check e1209173825782 [[],[],[.left]] .chain = true := by decide
def e1209173826334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1209173826334 : Closed e1209173826334 ∧ code e1209173826334 = 5607220337438 := by decide
theorem cert_e1209173826334 : check e1209173826334 [[],[],[.left]] .chain = true := by decide
def e1209173826446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1209173826446 : Closed e1209173826446 ∧ code e1209173826446 = 5607220337550 := by decide
theorem cert_e1209173826446 : check e1209173826446 [[],[],[.left]] .chain = true := by decide
def e1209173826670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1209173826670 : Closed e1209173826670 ∧ code e1209173826670 = 5607220337774 := by decide
theorem cert_e1209173826670 : check e1209173826670 [[],[],[.left]] .chain = true := by decide
def e1209173826682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1209173826682 : Closed e1209173826682 ∧ code e1209173826682 = 5607220337786 := by decide
theorem cert_e1209173826682 : check e1209173826682 [[],[],[.left]] .chain = true := by decide
def e1209173826846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1209173826846 : Closed e1209173826846 ∧ code e1209173826846 = 5607220337950 := by decide
theorem cert_e1209173826846 : check e1209173826846 [[],[],[.left]] .chain = true := by decide
def e1209173827014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1209173827014 : Closed e1209173827014 ∧ code e1209173827014 = 5607220338118 := by decide
theorem cert_e1209173827014 : check e1209173827014 [[],[],[.left]] .chain = true := by decide
def e1209173827126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1209173827126 : Closed e1209173827126 ∧ code e1209173827126 = 5607220338230 := by decide
theorem cert_e1209173827126 : check e1209173827126 [[],[],[.left]] .chain = true := by decide
def e1209173827130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1209173827130 : Closed e1209173827130 ∧ code e1209173827130 = 5607220338234 := by decide
theorem cert_e1209173827130 : check e1209173827130 [[],[],[.left]] .chain = true := by decide
def e1209173827214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1209173827214 : Closed e1209173827214 ∧ code e1209173827214 = 5607220338318 := by decide
theorem cert_e1209173827214 : check e1209173827214 [[],[],[.left]] .chain = true := by decide
def e1209173827270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1209173827270 : Closed e1209173827270 ∧ code e1209173827270 = 5607220338374 := by decide
theorem cert_e1209173827270 : check e1209173827270 [[],[],[.left]] .chain = true := by decide
def e1209173829406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1209173829406 : Closed e1209173829406 ∧ code e1209173829406 = 5607220340510 := by decide
theorem cert_e1209173829406 : check e1209173829406 [[],[],[.left]] .chain = true := by decide
def e1209173829518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1209173829518 : Closed e1209173829518 ∧ code e1209173829518 = 5607220340622 := by decide
theorem cert_e1209173829518 : check e1209173829518 [[],[],[.left]] .chain = true := by decide
def e1209173832478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1209173832478 : Closed e1209173832478 ∧ code e1209173832478 = 5607220343582 := by decide
theorem cert_e1209173832478 : check e1209173832478 [[],[],[.left]] .chain = true := by decide
def e1209173832646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1209173832646 : Closed e1209173832646 ∧ code e1209173832646 = 5607220343750 := by decide
theorem cert_e1209173832646 : check e1209173832646 [[],[],[.left]] .chain = true := by decide
def e1209173834126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1209173834126 : Closed e1209173834126 ∧ code e1209173834126 = 5607220345230 := by decide
theorem cert_e1209173834126 : check e1209173834126 [[],[],[.left]] .chain = true := by decide
def e1209173834182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1209173834182 : Closed e1209173834182 ∧ code e1209173834182 = 5607220345286 := by decide
theorem cert_e1209173834182 : check e1209173834182 [[],[],[.left]] .chain = true := by decide
def e1209234664814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209234664814 : Closed e1209234664814 ∧ code e1209234664814 = 5607281175918 := by decide
theorem cert_e1209234664814 : check e1209234664814 [[],[]] .smaller = true := by decide
def e1209234664822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209234664822 : Closed e1209234664822 ∧ code e1209234664822 = 5607281175926 := by decide
theorem cert_e1209234664822 : check e1209234664822 [[],[]] .smaller = true := by decide
def e1209234664878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209234664878 : Closed e1209234664878 ∧ code e1209234664878 = 5607281175982 := by decide
theorem cert_e1209234664878 : check e1209234664878 [[],[]] .smaller = true := by decide
def e1209234664890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209234664890 : Closed e1209234664890 ∧ code e1209234664890 = 5607281175994 := by decide
theorem cert_e1209234664890 : check e1209234664890 [[],[]] .smaller = true := by decide
def e1209234664918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209234664918 : Closed e1209234664918 ∧ code e1209234664918 = 5607281176022 := by decide
theorem cert_e1209234664918 : check e1209234664918 [[],[]] .smaller = true := by decide
def e1209234664922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209234664922 : Closed e1209234664922 ∧ code e1209234664922 = 5607281176026 := by decide
theorem cert_e1209234664922 : check e1209234664922 [[],[]] .smaller = true := by decide
def e1209234665134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1209234665134 : Closed e1209234665134 ∧ code e1209234665134 = 5607281176238 := by decide
theorem cert_e1209234665134 : check e1209234665134 [[],[]] .smaller = true := by decide
def e1209234665146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1209234665146 : Closed e1209234665146 ∧ code e1209234665146 = 5607281176250 := by decide
theorem cert_e1209234665146 : check e1209234665146 [[],[]] .smaller = true := by decide
def e1209234665194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1209234665194 : Closed e1209234665194 ∧ code e1209234665194 = 5607281176298 := by decide
theorem cert_e1209234665194 : check e1209234665194 [[],[]] .smaller = true := by decide
def e1209234665302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1209234665302 : Closed e1209234665302 ∧ code e1209234665302 = 5607281176406 := by decide
theorem cert_e1209234665302 : check e1209234665302 [[],[]] .smaller = true := by decide
def e1209234665306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1209234665306 : Closed e1209234665306 ∧ code e1209234665306 = 5607281176410 := by decide
theorem cert_e1209234665306 : check e1209234665306 [[],[]] .smaller = true := by decide
def e1209234665322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1209234665322 : Closed e1209234665322 ∧ code e1209234665322 = 5607281176426 := by decide
theorem cert_e1209234665322 : check e1209234665322 [[],[]] .smaller = true := by decide
def e1209234666350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209234666350 : Closed e1209234666350 ∧ code e1209234666350 = 5607281177454 := by decide
theorem cert_e1209234666350 : check e1209234666350 [[],[]] .smaller = true := by decide
def e1209234666358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209234666358 : Closed e1209234666358 ∧ code e1209234666358 = 5607281177462 := by decide
theorem cert_e1209234666358 : check e1209234666358 [[],[]] .smaller = true := by decide
def e1209234666414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209234666414 : Closed e1209234666414 ∧ code e1209234666414 = 5607281177518 := by decide
theorem cert_e1209234666414 : check e1209234666414 [[],[]] .smaller = true := by decide
def e1209234666426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209234666426 : Closed e1209234666426 ∧ code e1209234666426 = 5607281177530 := by decide
theorem cert_e1209234666426 : check e1209234666426 [[],[]] .smaller = true := by decide
def e1209234666454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209234666454 : Closed e1209234666454 ∧ code e1209234666454 = 5607281177558 := by decide
theorem cert_e1209234666454 : check e1209234666454 [[],[]] .smaller = true := by decide
def e1209234666458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209234666458 : Closed e1209234666458 ∧ code e1209234666458 = 5607281177562 := by decide
theorem cert_e1209234666458 : check e1209234666458 [[],[]] .smaller = true := by decide
def e1209234666734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209234666734 : Closed e1209234666734 ∧ code e1209234666734 = 5607281177838 := by decide
theorem cert_e1209234666734 : check e1209234666734 [[],[]] .smaller = true := by decide
def e1209234666742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209234666742 : Closed e1209234666742 ∧ code e1209234666742 = 5607281177846 := by decide
theorem cert_e1209234666742 : check e1209234666742 [[],[]] .smaller = true := by decide
def e1209234667118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209234667118 : Closed e1209234667118 ∧ code e1209234667118 = 5607281178222 := by decide
theorem cert_e1209234667118 : check e1209234667118 [[],[]] .smaller = true := by decide
def e1209234667130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209234667130 : Closed e1209234667130 ∧ code e1209234667130 = 5607281178234 := by decide
theorem cert_e1209234667130 : check e1209234667130 [[],[]] .smaller = true := by decide
def e1209234667318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209234667318 : Closed e1209234667318 ∧ code e1209234667318 = 5607281178422 := by decide
theorem cert_e1209234667318 : check e1209234667318 [[],[]] .smaller = true := by decide
def e1209234667322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209234667322 : Closed e1209234667322 ∧ code e1209234667322 = 5607281178426 := by decide
theorem cert_e1209234667322 : check e1209234667322 [[],[]] .smaller = true := by decide
def e1209234667950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1209234667950 : Closed e1209234667950 ∧ code e1209234667950 = 5607281179054 := by decide
theorem cert_e1209234667950 : check e1209234667950 [[],[]] .smaller = true := by decide
def e1209234667962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1209234667962 : Closed e1209234667962 ∧ code e1209234667962 = 5607281179066 := by decide
theorem cert_e1209234667962 : check e1209234667962 [[],[]] .smaller = true := by decide
def e1209234668010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1209234668010 : Closed e1209234668010 ∧ code e1209234668010 = 5607281179114 := by decide
theorem cert_e1209234668010 : check e1209234668010 [[],[]] .smaller = true := by decide
def e1209234668142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209234668142 : Closed e1209234668142 ∧ code e1209234668142 = 5607281179246 := by decide
theorem cert_e1209234668142 : check e1209234668142 [[],[]] .smaller = true := by decide
def e1209234668154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209234668154 : Closed e1209234668154 ∧ code e1209234668154 = 5607281179258 := by decide
theorem cert_e1209234668154 : check e1209234668154 [[],[]] .smaller = true := by decide
def e1209234668442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209234668442 : Closed e1209234668442 ∧ code e1209234668442 = 5607281179546 := by decide
theorem cert_e1209234668442 : check e1209234668442 [[],[]] .smaller = true := by decide
def e1209234668758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1209234668758 : Closed e1209234668758 ∧ code e1209234668758 = 5607281179862 := by decide
theorem cert_e1209234668758 : check e1209234668758 [[],[]] .smaller = true := by decide
def e1209234668762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1209234668762 : Closed e1209234668762 ∧ code e1209234668762 = 5607281179866 := by decide
theorem cert_e1209234668762 : check e1209234668762 [[],[]] .smaller = true := by decide
def e1209234668778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1209234668778 : Closed e1209234668778 ∧ code e1209234668778 = 5607281179882 := by decide
theorem cert_e1209234668778 : check e1209234668778 [[],[]] .smaller = true := by decide
def e1209234668854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209234668854 : Closed e1209234668854 ∧ code e1209234668854 = 5607281179958 := by decide
theorem cert_e1209234668854 : check e1209234668854 [[],[]] .smaller = true := by decide
def e1209234668858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209234668858 : Closed e1209234668858 ∧ code e1209234668858 = 5607281179962 := by decide
theorem cert_e1209234668858 : check e1209234668858 [[],[]] .smaller = true := by decide
def e1209234668954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209234668954 : Closed e1209234668954 ∧ code e1209234668954 = 5607281180058 := by decide
theorem cert_e1209234668954 : check e1209234668954 [[],[]] .smaller = true := by decide
def e1209234672494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1209234672494 : Closed e1209234672494 ∧ code e1209234672494 = 5607281183598 := by decide
theorem cert_e1209234672494 : check e1209234672494 [[],[]] .smaller = true := by decide
def e1209234672502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1209234672502 : Closed e1209234672502 ∧ code e1209234672502 = 5607281183606 := by decide
theorem cert_e1209234672502 : check e1209234672502 [[],[]] .smaller = true := by decide
def e1209234672558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1209234672558 : Closed e1209234672558 ∧ code e1209234672558 = 5607281183662 := by decide
theorem cert_e1209234672558 : check e1209234672558 [[],[]] .smaller = true := by decide
def e1209234672570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1209234672570 : Closed e1209234672570 ∧ code e1209234672570 = 5607281183674 := by decide
theorem cert_e1209234672570 : check e1209234672570 [[],[]] .smaller = true := by decide
def e1209234672598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1209234672598 : Closed e1209234672598 ∧ code e1209234672598 = 5607281183702 := by decide
theorem cert_e1209234672598 : check e1209234672598 [[],[]] .smaller = true := by decide
def e1209234672602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1209234672602 : Closed e1209234672602 ∧ code e1209234672602 = 5607281183706 := by decide
theorem cert_e1209234672602 : check e1209234672602 [[],[]] .smaller = true := by decide
def e1209234672878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1209234672878 : Closed e1209234672878 ∧ code e1209234672878 = 5607281183982 := by decide
theorem cert_e1209234672878 : check e1209234672878 [[],[]] .smaller = true := by decide
def e1209234672886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1209234672886 : Closed e1209234672886 ∧ code e1209234672886 = 5607281183990 := by decide
theorem cert_e1209234672886 : check e1209234672886 [[],[]] .smaller = true := by decide
def e1209234673262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209234673262 : Closed e1209234673262 ∧ code e1209234673262 = 5607281184366 := by decide
theorem cert_e1209234673262 : check e1209234673262 [[],[]] .smaller = true := by decide
def e1209234673274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209234673274 : Closed e1209234673274 ∧ code e1209234673274 = 5607281184378 := by decide
theorem cert_e1209234673274 : check e1209234673274 [[],[]] .smaller = true := by decide
def e1209234673462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209234673462 : Closed e1209234673462 ∧ code e1209234673462 = 5607281184566 := by decide
theorem cert_e1209234673462 : check e1209234673462 [[],[]] .smaller = true := by decide
def e1209234673466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209234673466 : Closed e1209234673466 ∧ code e1209234673466 = 5607281184570 := by decide
theorem cert_e1209234673466 : check e1209234673466 [[],[]] .smaller = true := by decide
def e1209234679214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1209234679214 : Closed e1209234679214 ∧ code e1209234679214 = 5607281190318 := by decide
theorem cert_e1209234679214 : check e1209234679214 [[],[]] .smaller = true := by decide
def e1209234679226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1209234679226 : Closed e1209234679226 ∧ code e1209234679226 = 5607281190330 := by decide
theorem cert_e1209234679226 : check e1209234679226 [[],[]] .smaller = true := by decide
def e1209234679274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1209234679274 : Closed e1209234679274 ∧ code e1209234679274 = 5607281190378 := by decide
theorem cert_e1209234679274 : check e1209234679274 [[],[]] .smaller = true := by decide
def e1209234679406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1209234679406 : Closed e1209234679406 ∧ code e1209234679406 = 5607281190510 := by decide
theorem cert_e1209234679406 : check e1209234679406 [[],[]] .smaller = true := by decide
def e1209234679418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1209234679418 : Closed e1209234679418 ∧ code e1209234679418 = 5607281190522 := by decide
theorem cert_e1209234679418 : check e1209234679418 [[],[]] .smaller = true := by decide
def e1209234679706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209234679706 : Closed e1209234679706 ∧ code e1209234679706 = 5607281190810 := by decide
theorem cert_e1209234679706 : check e1209234679706 [[],[]] .smaller = true := by decide
def e1209234682582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1209234682582 : Closed e1209234682582 ∧ code e1209234682582 = 5607281193686 := by decide
theorem cert_e1209234682582 : check e1209234682582 [[],[]] .smaller = true := by decide
def e1209234682586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1209234682586 : Closed e1209234682586 ∧ code e1209234682586 = 5607281193690 := by decide
theorem cert_e1209234682586 : check e1209234682586 [[],[]] .smaller = true := by decide
def e1209234682602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1209234682602 : Closed e1209234682602 ∧ code e1209234682602 = 5607281193706 := by decide
theorem cert_e1209234682602 : check e1209234682602 [[],[]] .smaller = true := by decide
def e1209234682678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1209234682678 : Closed e1209234682678 ∧ code e1209234682678 = 5607281193782 := by decide
theorem cert_e1209234682678 : check e1209234682678 [[],[]] .smaller = true := by decide
def e1209234682682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1209234682682 : Closed e1209234682682 ∧ code e1209234682682 = 5607281193786 := by decide
theorem cert_e1209234682682 : check e1209234682682 [[],[]] .smaller = true := by decide
def e1209234682778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1209234682778 : Closed e1209234682778 ∧ code e1209234682778 = 5607281193882 := by decide
theorem cert_e1209234682778 : check e1209234682778 [[],[]] .smaller = true := by decide
def e1209234798318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1209234798318 : Closed e1209234798318 ∧ code e1209234798318 = 5607281309422 := by decide
theorem cert_e1209234798318 : check e1209234798318 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209234798446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1209234798446 : Closed e1209234798446 ∧ code e1209234798446 = 5607281309550 := by decide
theorem cert_e1209234798446 : check e1209234798446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209234798454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1209234798454 : Closed e1209234798454 ∧ code e1209234798454 = 5607281309558 := by decide
theorem cert_e1209234798454 : check e1209234798454 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209234799342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1209234799342 : Closed e1209234799342 ∧ code e1209234799342 = 5607281310446 := by decide
theorem cert_e1209234799342 : check e1209234799342 [[],[]] .sourceHead = true := by decide
def e1209234799534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1209234799534 : Closed e1209234799534 ∧ code e1209234799534 = 5607281310638 := by decide
theorem cert_e1209234799534 : check e1209234799534 [[],[]] .sourceHead = true := by decide
def e1209234799546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1209234799546 : Closed e1209234799546 ∧ code e1209234799546 = 5607281310650 := by decide
theorem cert_e1209234799546 : check e1209234799546 [[],[]] .sourceHead = true := by decide
def e1209234799982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1209234799982 : Closed e1209234799982 ∧ code e1209234799982 = 5607281311086 := by decide
theorem cert_e1209234799982 : check e1209234799982 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under,.left,.left]] .identityHead = true := by decide
def e1209234799990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1209234799990 : Closed e1209234799990 ∧ code e1209234799990 = 5607281311094 := by decide
theorem cert_e1209234799990 : check e1209234799990 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234800046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1209234800046 : Closed e1209234800046 ∧ code e1209234800046 = 5607281311150 := by decide
theorem cert_e1209234800046 : check e1209234800046 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209234800058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1209234800058 : Closed e1209234800058 ∧ code e1209234800058 = 5607281311162 := by decide
theorem cert_e1209234800058 : check e1209234800058 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209234800086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1209234800086 : Closed e1209234800086 ∧ code e1209234800086 = 5607281311190 := by decide
theorem cert_e1209234800086 : check e1209234800086 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .identityHead = true := by decide
def e1209234800090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1209234800090 : Closed e1209234800090 ∧ code e1209234800090 = 5607281311194 := by decide
def e1209234804462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1209234804462 : Closed e1209234804462 ∧ code e1209234804462 = 5607281315566 := by decide
theorem cert_e1209234804462 : check e1209234804462 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209234804590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1209234804590 : Closed e1209234804590 ∧ code e1209234804590 = 5607281315694 := by decide
theorem cert_e1209234804590 : check e1209234804590 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209234804598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1209234804598 : Closed e1209234804598 ∧ code e1209234804598 = 5607281315702 := by decide
theorem cert_e1209234804598 : check e1209234804598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209234807278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1209234807278 : Closed e1209234807278 ∧ code e1209234807278 = 5607281318382 := by decide
theorem cert_e1209234807278 : check e1209234807278 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209234808046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209234808046 : Closed e1209234808046 ∧ code e1209234808046 = 5607281319150 := by decide
theorem cert_e1209234808046 : check e1209234808046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209234808054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209234808054 : Closed e1209234808054 ∧ code e1209234808054 = 5607281319158 := by decide
theorem cert_e1209234808054 : check e1209234808054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209234810606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1209234810606 : Closed e1209234810606 ∧ code e1209234810606 = 5607281321710 := by decide
theorem cert_e1209234810606 : checkPay e1209234810606 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e1209234810798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1209234810798 : Closed e1209234810798 ∧ code e1209234810798 = 5607281321902 := by decide
theorem cert_e1209234810798 : checkPay e1209234810798 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.under,.left,.right]] = true := by decide
def e1209234810810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1209234810810 : Closed e1209234810810 ∧ code e1209234810810 = 5607281321914 := by decide
theorem cert_e1209234810810 : checkPay e1209234810810 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1209234811374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1209234811374 : Closed e1209234811374 ∧ code e1209234811374 = 5607281322478 := by decide
theorem cert_e1209234811374 : checkPay e1209234811374 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
end Blc.Floor42
