import Indexed
import CodeBridge
namespace Certgen.FloorIndex
open Blc Blc.SelfintRegularSoundness
def forward (n : Nat) (P : Nat → Code) (i : Nat) : Bool := match P i with
  | .lam b => decide (i < b ∧ b < n)
  | .app f a => decide (i < f ∧ f < n ∧ i < a ∧ a < n)
  | _ => true
def localRank (n : Nat) (P : Nat → Code) (h : ∀ i, forward n P i = true) : CodeRank P where
  height p := n-p
  lam_lt := by intro p b hp; have hq := h p; simp [forward,hp] at hq; omega
  app_left_lt := by intro p f a hp; have hq := h p; simp [forward,hp] at hq; omega
  app_right_lt := by intro p f a hp; have hq := h p; simp [forward,hp] at hq; omega
end Certgen.FloorIndex
