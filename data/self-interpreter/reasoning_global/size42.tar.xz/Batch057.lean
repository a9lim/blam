import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131188447470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1131188447470 : Closed e1131188447470 ∧ code e1131188447470 = 5529234958574 := by decide
theorem cert_e1131188447470 : check e1131188447470 [[],[.under]] .three = true := by decide
def e1131188447478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1131188447478 : Closed e1131188447478 ∧ code e1131188447478 = 5529234958582 := by decide
theorem cert_e1131188447478 : check e1131188447478 [[],[.under]] .three = true := by decide
def e1131188447670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1131188447670 : Closed e1131188447670 ∧ code e1131188447670 = 5529234958774 := by decide
theorem cert_e1131188447670 : check e1131188447670 [[],[.under]] .three = true := by decide
def e1131188447702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1131188447702 : Closed e1131188447702 ∧ code e1131188447702 = 5529234958806 := by decide
theorem cert_e1131188447702 : check e1131188447702 [[],[.under]] .three = true := by decide
def e1131188447706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1131188447706 : Closed e1131188447706 ∧ code e1131188447706 = 5529234958810 := by decide
theorem cert_e1131188447706 : check e1131188447706 [[],[.under]] .three = true := by decide
def e1131188447862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1131188447862 : Closed e1131188447862 ∧ code e1131188447862 = 5529234958966 := by decide
theorem cert_e1131188447862 : check e1131188447862 [[],[.under]] .three = true := by decide
def e1131188448030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1131188448030 : Closed e1131188448030 ∧ code e1131188448030 = 5529234959134 := by decide
theorem cert_e1131188448030 : check e1131188448030 [[],[.under]] .three = true := by decide
def e1131188448054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188448054 : Closed e1131188448054 ∧ code e1131188448054 = 5529234959158 := by decide
theorem cert_e1131188448054 : check e1131188448054 [[],[.under]] .three = true := by decide
def e1131188448058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188448058 : Closed e1131188448058 ∧ code e1131188448058 = 5529234959162 := by decide
theorem cert_e1131188448058 : check e1131188448058 [[],[.under]] .three = true := by decide
def e1131188448142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1131188448142 : Closed e1131188448142 ∧ code e1131188448142 = 5529234959246 := by decide
theorem cert_e1131188448142 : check e1131188448142 [[],[.under]] .three = true := by decide
def e1131188448366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1131188448366 : Closed e1131188448366 ∧ code e1131188448366 = 5529234959470 := by decide
theorem cert_e1131188448366 : check e1131188448366 [[],[.under]] .three = true := by decide
def e1131188448378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1131188448378 : Closed e1131188448378 ∧ code e1131188448378 = 5529234959482 := by decide
theorem cert_e1131188448378 : check e1131188448378 [[],[.under]] .three = true := by decide
def e1131188448470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1131188448470 : Closed e1131188448470 ∧ code e1131188448470 = 5529234959574 := by decide
theorem cert_e1131188448470 : check e1131188448470 [[],[.under]] .three = true := by decide
def e1131188448474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1131188448474 : Closed e1131188448474 ∧ code e1131188448474 = 5529234959578 := by decide
theorem cert_e1131188448474 : check e1131188448474 [[],[.under]] .three = true := by decide
def e1131188448490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1131188448490 : Closed e1131188448490 ∧ code e1131188448490 = 5529234959594 := by decide
theorem cert_e1131188448490 : check e1131188448490 [[],[.under]] .three = true := by decide
def e1131188448542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1131188448542 : Closed e1131188448542 ∧ code e1131188448542 = 5529234959646 := by decide
theorem cert_e1131188448542 : check e1131188448542 [[],[.under]] .three = true := by decide
def e1131188448566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188448566 : Closed e1131188448566 ∧ code e1131188448566 = 5529234959670 := by decide
theorem cert_e1131188448566 : check e1131188448566 [[],[.under]] .three = true := by decide
def e1131188448570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188448570 : Closed e1131188448570 ∧ code e1131188448570 = 5529234959674 := by decide
theorem cert_e1131188448570 : check e1131188448570 [[],[.under]] .three = true := by decide
def e1131188448666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1131188448666 : Closed e1131188448666 ∧ code e1131188448666 = 5529234959770 := by decide
theorem cert_e1131188448666 : check e1131188448666 [[],[.under]] .three = true := by decide
def e1131188448710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1131188448710 : Closed e1131188448710 ∧ code e1131188448710 = 5529234959814 := by decide
theorem cert_e1131188448710 : check e1131188448710 [[],[.under]] .three = true := by decide
def e1131188448822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1131188448822 : Closed e1131188448822 ∧ code e1131188448822 = 5529234959926 := by decide
private def t_e1131188448822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem cert_e1131188448822 : ¬ IsSelfInterpreter e1131188448822 :=
  wSource (t := t_e1131188448822) (replay_sound (ps := []) (t := e1131188448822) (by decide)) (by decide)
def e1131188448826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1131188448826 : Closed e1131188448826 ∧ code e1131188448826 = 5529234959930 := by decide
private def t_e1131188448826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem cert_e1131188448826 : ¬ IsSelfInterpreter e1131188448826 :=
  wSource (t := t_e1131188448826) (replay_sound (ps := []) (t := e1131188448826) (by decide)) (by decide)
def e1131188448910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1131188448910 : Closed e1131188448910 ∧ code e1131188448910 = 5529234960014 := by decide
private def t_e1131188448910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem cert_e1131188448910 : ¬ IsSelfInterpreter e1131188448910 :=
  wSource (t := t_e1131188448910) (replay_sound (ps := []) (t := e1131188448910) (by decide)) (by decide)
def e1131188448966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1131188448966 : Closed e1131188448966 ∧ code e1131188448966 = 5529234960070 := by decide
private def t_e1131188448966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem cert_e1131188448966 : ¬ IsSelfInterpreter e1131188448966 :=
  wSource (t := t_e1131188448966) (replay_sound (ps := []) (t := e1131188448966) (by decide)) (by decide)
def e1131188461294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e1131188461294 : Closed e1131188461294 ∧ code e1131188461294 = 5529234972398 := by decide
theorem cert_e1131188461294 : check e1131188461294 [[],[.under]] .three = true := by decide
def e1131188461302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e1131188461302 : Closed e1131188461302 ∧ code e1131188461302 = 5529234972406 := by decide
theorem cert_e1131188461302 : check e1131188461302 [[],[.under]] .three = true := by decide
def e1131188461430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e1131188461430 : Closed e1131188461430 ∧ code e1131188461430 = 5529234972534 := by decide
theorem cert_e1131188461430 : check e1131188461430 [[],[.under]] .three = true := by decide
def e1131188468206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e1131188468206 : Closed e1131188468206 ∧ code e1131188468206 = 5529234979310 := by decide
theorem cert_e1131188468206 : check e1131188468206 [[],[.under]] .three = true := by decide
def e1131188468974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188468974 : Closed e1131188468974 ∧ code e1131188468974 = 5529234980078 := by decide
theorem cert_e1131188468974 : check e1131188468974 [[],[.under]] .three = true := by decide
def e1131188468982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188468982 : Closed e1131188468982 ∧ code e1131188468982 = 5529234980086 := by decide
theorem cert_e1131188468982 : check e1131188468982 [[],[.under]] .three = true := by decide
def e1131188476782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1131188476782 : Closed e1131188476782 ∧ code e1131188476782 = 5529234987886 := by decide
theorem cert_e1131188476782 : check e1131188476782 [[],[.under]] .three = true := by decide
def e1131188476790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1131188476790 : Closed e1131188476790 ∧ code e1131188476790 = 5529234987894 := by decide
theorem cert_e1131188476790 : check e1131188476790 [[],[.under]] .three = true := by decide
def e1131188476854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1131188476854 : Closed e1131188476854 ∧ code e1131188476854 = 5529234987958 := by decide
theorem cert_e1131188476854 : check e1131188476854 [[],[.under]] .three = true := by decide
def e1131188477294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1131188477294 : Closed e1131188477294 ∧ code e1131188477294 = 5529234988398 := by decide
theorem cert_e1131188477294 : check e1131188477294 [[],[.under]] .three = true := by decide
def e1131188477302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1131188477302 : Closed e1131188477302 ∧ code e1131188477302 = 5529234988406 := by decide
theorem cert_e1131188477302 : check e1131188477302 [[],[.under]] .three = true := by decide
def e1131188477358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1131188477358 : Closed e1131188477358 ∧ code e1131188477358 = 5529234988462 := by decide
theorem cert_e1131188477358 : check e1131188477358 [[],[.under]] .three = true := by decide
def e1131188477370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1131188477370 : Closed e1131188477370 ∧ code e1131188477370 = 5529234988474 := by decide
theorem cert_e1131188477370 : check e1131188477370 [[],[.under]] .three = true := by decide
def e1131188477398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1131188477398 : Closed e1131188477398 ∧ code e1131188477398 = 5529234988502 := by decide
theorem cert_e1131188477398 : check e1131188477398 [[],[.under]] .three = true := by decide
def e1131188477402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1131188477402 : Closed e1131188477402 ∧ code e1131188477402 = 5529234988506 := by decide
theorem cert_e1131188477402 : check e1131188477402 [[],[.under]] .three = true := by decide
def e1131188477622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1131188477622 : Closed e1131188477622 ∧ code e1131188477622 = 5529234988726 := by decide
theorem cert_e1131188477622 : check e1131188477622 [[],[.under]] .three = true := by decide
def e1131188477654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1131188477654 : Closed e1131188477654 ∧ code e1131188477654 = 5529234988758 := by decide
theorem cert_e1131188477654 : check e1131188477654 [[],[.under]] .three = true := by decide
def e1131188477658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1131188477658 : Closed e1131188477658 ∧ code e1131188477658 = 5529234988762 := by decide
theorem cert_e1131188477658 : check e1131188477658 [[],[.under]] .three = true := by decide
def e1131188479854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1131188479854 : Closed e1131188479854 ∧ code e1131188479854 = 5529234990958 := by decide
theorem cert_e1131188479854 : check e1131188479854 [[],[.under]] .three = true := by decide
def e1131188479862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1131188479862 : Closed e1131188479862 ∧ code e1131188479862 = 5529234990966 := by decide
theorem cert_e1131188479862 : check e1131188479862 [[],[.under]] .three = true := by decide
def e1131188479926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1131188479926 : Closed e1131188479926 ∧ code e1131188479926 = 5529234991030 := by decide
theorem cert_e1131188479926 : check e1131188479926 [[],[.under]] .three = true := by decide
def e1131188481262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188481262 : Closed e1131188481262 ∧ code e1131188481262 = 5529234992366 := by decide
theorem cert_e1131188481262 : check e1131188481262 [[],[.under]] .three = true := by decide
def e1131188481270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188481270 : Closed e1131188481270 ∧ code e1131188481270 = 5529234992374 := by decide
theorem cert_e1131188481270 : check e1131188481270 [[],[.under]] .three = true := by decide
def e1131188481654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1131188481654 : Closed e1131188481654 ∧ code e1131188481654 = 5529234992758 := by decide
theorem cert_e1131188481654 : check e1131188481654 [[],[.under]] .three = true := by decide
def e1131188482542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1131188482542 : Closed e1131188482542 ∧ code e1131188482542 = 5529234993646 := by decide
theorem cert_e1131188482542 : check e1131188482542 [[],[.under]] .three = true := by decide
def e1131188482926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1131188482926 : Closed e1131188482926 ∧ code e1131188482926 = 5529234994030 := by decide
theorem cert_e1131188482926 : check e1131188482926 [[],[.under]] .three = true := by decide
def e1131188482934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1131188482934 : Closed e1131188482934 ∧ code e1131188482934 = 5529234994038 := by decide
theorem cert_e1131188482934 : check e1131188482934 [[],[.under]] .three = true := by decide
def e1131188482990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1131188482990 : Closed e1131188482990 ∧ code e1131188482990 = 5529234994094 := by decide
theorem cert_e1131188482990 : check e1131188482990 [[],[.under]] .three = true := by decide
def e1131188483002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1131188483002 : Closed e1131188483002 ∧ code e1131188483002 = 5529234994106 := by decide
theorem cert_e1131188483002 : check e1131188483002 [[],[.under]] .three = true := by decide
def e1131188483030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1131188483030 : Closed e1131188483030 ∧ code e1131188483030 = 5529234994134 := by decide
theorem cert_e1131188483030 : check e1131188483030 [[],[.under]] .three = true := by decide
def e1131188483034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1131188483034 : Closed e1131188483034 ∧ code e1131188483034 = 5529234994138 := by decide
theorem cert_e1131188483034 : check e1131188483034 [[],[.under]] .three = true := by decide
def e1131188483310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188483310 : Closed e1131188483310 ∧ code e1131188483310 = 5529234994414 := by decide
theorem cert_e1131188483310 : check e1131188483310 [[],[.under]] .three = true := by decide
def e1131188483318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188483318 : Closed e1131188483318 ∧ code e1131188483318 = 5529234994422 := by decide
theorem cert_e1131188483318 : check e1131188483318 [[],[.under]] .three = true := by decide
def e1131188483694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188483694 : Closed e1131188483694 ∧ code e1131188483694 = 5529234994798 := by decide
theorem cert_e1131188483694 : check e1131188483694 [[],[.under]] .three = true := by decide
def e1131188483706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188483706 : Closed e1131188483706 ∧ code e1131188483706 = 5529234994810 := by decide
theorem cert_e1131188483706 : check e1131188483706 [[],[.under]] .three = true := by decide
def e1131188483870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1131188483870 : Closed e1131188483870 ∧ code e1131188483870 = 5529234994974 := by decide
theorem cert_e1131188483870 : check e1131188483870 [[],[.under]] .three = true := by decide
def e1131188483894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188483894 : Closed e1131188483894 ∧ code e1131188483894 = 5529234994998 := by decide
theorem cert_e1131188483894 : check e1131188483894 [[],[.under]] .three = true := by decide
def e1131188483898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188483898 : Closed e1131188483898 ∧ code e1131188483898 = 5529234995002 := by decide
theorem cert_e1131188483898 : check e1131188483898 [[],[.under]] .three = true := by decide
def e1131188484334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1131188484334 : Closed e1131188484334 ∧ code e1131188484334 = 5529234995438 := by decide
theorem cert_e1131188484334 : check e1131188484334 [[],[.under]] .three = true := by decide
def e1131188484342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1131188484342 : Closed e1131188484342 ∧ code e1131188484342 = 5529234995446 := by decide
theorem cert_e1131188484342 : check e1131188484342 [[],[.under]] .three = true := by decide
def e1131188484534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1131188484534 : Closed e1131188484534 ∧ code e1131188484534 = 5529234995638 := by decide
theorem cert_e1131188484534 : check e1131188484534 [[],[.under]] .three = true := by decide
def e1131188484566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1131188484566 : Closed e1131188484566 ∧ code e1131188484566 = 5529234995670 := by decide
theorem cert_e1131188484566 : check e1131188484566 [[],[.under]] .three = true := by decide
def e1131188484570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1131188484570 : Closed e1131188484570 ∧ code e1131188484570 = 5529234995674 := by decide
theorem cert_e1131188484570 : check e1131188484570 [[],[.under]] .three = true := by decide
def e1131188484726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1131188484726 : Closed e1131188484726 ∧ code e1131188484726 = 5529234995830 := by decide
theorem cert_e1131188484726 : check e1131188484726 [[],[.under]] .three = true := by decide
def e1131188484894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1131188484894 : Closed e1131188484894 ∧ code e1131188484894 = 5529234995998 := by decide
theorem cert_e1131188484894 : check e1131188484894 [[],[.under]] .three = true := by decide
def e1131188484918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188484918 : Closed e1131188484918 ∧ code e1131188484918 = 5529234996022 := by decide
theorem cert_e1131188484918 : check e1131188484918 [[],[.under]] .three = true := by decide
def e1131188484922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188484922 : Closed e1131188484922 ∧ code e1131188484922 = 5529234996026 := by decide
theorem cert_e1131188484922 : check e1131188484922 [[],[.under]] .three = true := by decide
def e1131188485006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1131188485006 : Closed e1131188485006 ∧ code e1131188485006 = 5529234996110 := by decide
theorem cert_e1131188485006 : check e1131188485006 [[],[.under]] .three = true := by decide
def e1131188492142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1131188492142 : Closed e1131188492142 ∧ code e1131188492142 = 5529235003246 := by decide
theorem cert_e1131188492142 : check e1131188492142 [[],[.under]] .three = true := by decide
def e1131188492150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1131188492150 : Closed e1131188492150 ∧ code e1131188492150 = 5529235003254 := by decide
theorem cert_e1131188492150 : check e1131188492150 [[],[.under]] .three = true := by decide
def e1131188492214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1131188492214 : Closed e1131188492214 ∧ code e1131188492214 = 5529235003318 := by decide
theorem cert_e1131188492214 : check e1131188492214 [[],[.under]] .three = true := by decide
def e1131188493550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1131188493550 : Closed e1131188493550 ∧ code e1131188493550 = 5529235004654 := by decide
theorem cert_e1131188493550 : check e1131188493550 [[],[.under]] .three = true := by decide
def e1131188493558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1131188493558 : Closed e1131188493558 ∧ code e1131188493558 = 5529235004662 := by decide
theorem cert_e1131188493558 : check e1131188493558 [[],[.under]] .three = true := by decide
def e1131188493942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1131188493942 : Closed e1131188493942 ∧ code e1131188493942 = 5529235005046 := by decide
theorem cert_e1131188493942 : check e1131188493942 [[],[.under]] .three = true := by decide
def e1131188503518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1131188503518 : Closed e1131188503518 ∧ code e1131188503518 = 5529235014622 := by decide
theorem cert_e1131188503518 : check e1131188503518 [[],[.under]] .three = true := by decide
def e1131188503534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1131188503534 : Closed e1131188503534 ∧ code e1131188503534 = 5529235014638 := by decide
theorem cert_e1131188503534 : check e1131188503534 [[],[.under]] .three = true := by decide
def e1131188505454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1131188505454 : Closed e1131188505454 ∧ code e1131188505454 = 5529235016558 := by decide
theorem cert_e1131188505454 : check e1131188505454 [[],[.under]] .three = true := by decide
def e1131188505462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1131188505462 : Closed e1131188505462 ∧ code e1131188505462 = 5529235016566 := by decide
theorem cert_e1131188505462 : check e1131188505462 [[],[.under]] .three = true := by decide
def e1131188505518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1131188505518 : Closed e1131188505518 ∧ code e1131188505518 = 5529235016622 := by decide
theorem cert_e1131188505518 : check e1131188505518 [[],[.under]] .three = true := by decide
def e1131188505530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1131188505530 : Closed e1131188505530 ∧ code e1131188505530 = 5529235016634 := by decide
theorem cert_e1131188505530 : check e1131188505530 [[],[.under]] .three = true := by decide
def e1131188505558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1131188505558 : Closed e1131188505558 ∧ code e1131188505558 = 5529235016662 := by decide
theorem cert_e1131188505558 : check e1131188505558 [[],[.under]] .three = true := by decide
def e1131188505562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1131188505562 : Closed e1131188505562 ∧ code e1131188505562 = 5529235016666 := by decide
theorem cert_e1131188505562 : check e1131188505562 [[],[.under]] .three = true := by decide
def e1131188505838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1131188505838 : Closed e1131188505838 ∧ code e1131188505838 = 5529235016942 := by decide
theorem cert_e1131188505838 : check e1131188505838 [[],[.under]] .three = true := by decide
def e1131188505846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1131188505846 : Closed e1131188505846 ∧ code e1131188505846 = 5529235016950 := by decide
theorem cert_e1131188505846 : check e1131188505846 [[],[.under]] .three = true := by decide
def e1131188506222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1131188506222 : Closed e1131188506222 ∧ code e1131188506222 = 5529235017326 := by decide
theorem cert_e1131188506222 : check e1131188506222 [[],[.under]] .three = true := by decide
def e1131188506234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1131188506234 : Closed e1131188506234 ∧ code e1131188506234 = 5529235017338 := by decide
theorem cert_e1131188506234 : check e1131188506234 [[],[.under]] .three = true := by decide
def e1131188506398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1131188506398 : Closed e1131188506398 ∧ code e1131188506398 = 5529235017502 := by decide
theorem cert_e1131188506398 : check e1131188506398 [[],[.under]] .three = true := by decide
def e1131188506422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188506422 : Closed e1131188506422 ∧ code e1131188506422 = 5529235017526 := by decide
theorem cert_e1131188506422 : check e1131188506422 [[],[.under]] .three = true := by decide
def e1131188506426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188506426 : Closed e1131188506426 ∧ code e1131188506426 = 5529235017530 := by decide
theorem cert_e1131188506426 : check e1131188506426 [[],[.under]] .three = true := by decide
def e1131188511214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1131188511214 : Closed e1131188511214 ∧ code e1131188511214 = 5529235022318 := by decide
theorem cert_e1131188511214 : check e1131188511214 [[],[.under]] .three = true := by decide
def e1131188512182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1131188512182 : Closed e1131188512182 ∧ code e1131188512182 = 5529235023286 := by decide
theorem cert_e1131188512182 : check e1131188512182 [[],[.under]] .three = true := by decide
def e1131188512214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1131188512214 : Closed e1131188512214 ∧ code e1131188512214 = 5529235023318 := by decide
theorem cert_e1131188512214 : check e1131188512214 [[],[.under]] .three = true := by decide
def e1131188512218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1131188512218 : Closed e1131188512218 ∧ code e1131188512218 = 5529235023322 := by decide
theorem cert_e1131188512218 : check e1131188512218 [[],[.under]] .three = true := by decide
def e1131188512374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1131188512374 : Closed e1131188512374 ∧ code e1131188512374 = 5529235023478 := by decide
theorem cert_e1131188512374 : check e1131188512374 [[],[.under]] .three = true := by decide
def e1131188512542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1131188512542 : Closed e1131188512542 ∧ code e1131188512542 = 5529235023646 := by decide
theorem cert_e1131188512542 : check e1131188512542 [[],[.under]] .three = true := by decide
def e1131188512566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1131188512566 : Closed e1131188512566 ∧ code e1131188512566 = 5529235023670 := by decide
theorem cert_e1131188512566 : check e1131188512566 [[],[.under]] .three = true := by decide
def e1131188512570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1131188512570 : Closed e1131188512570 ∧ code e1131188512570 = 5529235023674 := by decide
theorem cert_e1131188512570 : check e1131188512570 [[],[.under]] .three = true := by decide
def e1131188512654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1131188512654 : Closed e1131188512654 ∧ code e1131188512654 = 5529235023758 := by decide
theorem cert_e1131188512654 : check e1131188512654 [[],[.under]] .three = true := by decide
def e1131188522734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1131188522734 : Closed e1131188522734 ∧ code e1131188522734 = 5529235033838 := by decide
theorem cert_e1131188522734 : check e1131188522734 [[],[.under]] .three = true := by decide
def e1131188522742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e1131188522742 : Closed e1131188522742 ∧ code e1131188522742 = 5529235033846 := by decide
theorem cert_e1131188522742 : check e1131188522742 [[],[.under]] .three = true := by decide
def e1131188522862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1131188522862 : Closed e1131188522862 ∧ code e1131188522862 = 5529235033966 := by decide
theorem cert_e1131188522862 : check e1131188522862 [[],[.under]] .three = true := by decide
def e1131188522874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e1131188522874 : Closed e1131188522874 ∧ code e1131188522874 = 5529235033978 := by decide
theorem cert_e1131188522874 : check e1131188522874 [[],[.under]] .three = true := by decide
def e1131188522934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e1131188522934 : Closed e1131188522934 ∧ code e1131188522934 = 5529235034038 := by decide
theorem cert_e1131188522934 : check e1131188522934 [[],[.under]] .three = true := by decide
def e1131188522938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e1131188522938 : Closed e1131188522938 ∧ code e1131188522938 = 5529235034042 := by decide
theorem cert_e1131188522938 : check e1131188522938 [[],[.under]] .three = true := by decide
def e1131188525550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e1131188525550 : Closed e1131188525550 ∧ code e1131188525550 = 5529235036654 := by decide
theorem cert_e1131188525550 : check e1131188525550 [[],[.under]] .three = true := by decide
def e1131188526702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188526702 : Closed e1131188526702 ∧ code e1131188526702 = 5529235037806 := by decide
theorem cert_e1131188526702 : check e1131188526702 [[],[.under]] .three = true := by decide
def e1131188526714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188526714 : Closed e1131188526714 ∧ code e1131188526714 = 5529235037818 := by decide
theorem cert_e1131188526714 : check e1131188526714 [[],[.under]] .three = true := by decide
def e1131188530542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1131188530542 : Closed e1131188530542 ∧ code e1131188530542 = 5529235041646 := by decide
theorem cert_e1131188530542 : check e1131188530542 [[],[.under]] .three = true := by decide
def e1131188530550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1131188530550 : Closed e1131188530550 ∧ code e1131188530550 = 5529235041654 := by decide
theorem cert_e1131188530550 : check e1131188530550 [[],[.under]] .three = true := by decide
def e1131188530606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1131188530606 : Closed e1131188530606 ∧ code e1131188530606 = 5529235041710 := by decide
theorem cert_e1131188530606 : check e1131188530606 [[],[.under]] .three = true := by decide
def e1131188530618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1131188530618 : Closed e1131188530618 ∧ code e1131188530618 = 5529235041722 := by decide
theorem cert_e1131188530618 : check e1131188530618 [[],[.under]] .three = true := by decide
def e1131188530646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1131188530646 : Closed e1131188530646 ∧ code e1131188530646 = 5529235041750 := by decide
theorem cert_e1131188530646 : check e1131188530646 [[],[.under]] .three = true := by decide
def e1131188530650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1131188530650 : Closed e1131188530650 ∧ code e1131188530650 = 5529235041754 := by decide
theorem cert_e1131188530650 : check e1131188530650 [[],[.under]] .three = true := by decide
def e1131188530862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1131188530862 : Closed e1131188530862 ∧ code e1131188530862 = 5529235041966 := by decide
theorem cert_e1131188530862 : check e1131188530862 [[],[.under]] .three = true := by decide
def e1131188530874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1131188530874 : Closed e1131188530874 ∧ code e1131188530874 = 5529235041978 := by decide
theorem cert_e1131188530874 : check e1131188530874 [[],[.under]] .three = true := by decide
def e1131188530922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1131188530922 : Closed e1131188530922 ∧ code e1131188530922 = 5529235042026 := by decide
theorem cert_e1131188530922 : check e1131188530922 [[],[.under]] .three = true := by decide
def e1131188531030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1131188531030 : Closed e1131188531030 ∧ code e1131188531030 = 5529235042134 := by decide
theorem cert_e1131188531030 : check e1131188531030 [[],[.under]] .three = true := by decide
def e1131188531034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1131188531034 : Closed e1131188531034 ∧ code e1131188531034 = 5529235042138 := by decide
theorem cert_e1131188531034 : check e1131188531034 [[],[.under]] .three = true := by decide
def e1131188531050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1131188531050 : Closed e1131188531050 ∧ code e1131188531050 = 5529235042154 := by decide
theorem cert_e1131188531050 : check e1131188531050 [[],[.under]] .three = true := by decide
def e1131188531694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1131188531694 : Closed e1131188531694 ∧ code e1131188531694 = 5529235042798 := by decide
theorem cert_e1131188531694 : check e1131188531694 [[],[.under]] .three = true := by decide
def e1131188532078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1131188532078 : Closed e1131188532078 ∧ code e1131188532078 = 5529235043182 := by decide
theorem cert_e1131188532078 : check e1131188532078 [[],[.under]] .three = true := by decide
def e1131188532086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1131188532086 : Closed e1131188532086 ∧ code e1131188532086 = 5529235043190 := by decide
theorem cert_e1131188532086 : check e1131188532086 [[],[.under]] .three = true := by decide
def e1131188532142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1131188532142 : Closed e1131188532142 ∧ code e1131188532142 = 5529235043246 := by decide
theorem cert_e1131188532142 : check e1131188532142 [[],[.under]] .three = true := by decide
def e1131188532154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1131188532154 : Closed e1131188532154 ∧ code e1131188532154 = 5529235043258 := by decide
theorem cert_e1131188532154 : check e1131188532154 [[],[.under]] .three = true := by decide
def e1131188532182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1131188532182 : Closed e1131188532182 ∧ code e1131188532182 = 5529235043286 := by decide
theorem cert_e1131188532182 : check e1131188532182 [[],[.under]] .three = true := by decide
def e1131188532186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1131188532186 : Closed e1131188532186 ∧ code e1131188532186 = 5529235043290 := by decide
theorem cert_e1131188532186 : check e1131188532186 [[],[.under]] .three = true := by decide
def e1131188532462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188532462 : Closed e1131188532462 ∧ code e1131188532462 = 5529235043566 := by decide
theorem cert_e1131188532462 : check e1131188532462 [[],[.under]] .three = true := by decide
def e1131188532470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188532470 : Closed e1131188532470 ∧ code e1131188532470 = 5529235043574 := by decide
theorem cert_e1131188532470 : check e1131188532470 [[],[.under]] .three = true := by decide
def e1131188532846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188532846 : Closed e1131188532846 ∧ code e1131188532846 = 5529235043950 := by decide
theorem cert_e1131188532846 : check e1131188532846 [[],[.under]] .three = true := by decide
def e1131188532858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188532858 : Closed e1131188532858 ∧ code e1131188532858 = 5529235043962 := by decide
theorem cert_e1131188532858 : check e1131188532858 [[],[.under]] .three = true := by decide
def e1131188533022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1131188533022 : Closed e1131188533022 ∧ code e1131188533022 = 5529235044126 := by decide
theorem cert_e1131188533022 : check e1131188533022 [[],[.under]] .three = true := by decide
def e1131188533046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188533046 : Closed e1131188533046 ∧ code e1131188533046 = 5529235044150 := by decide
theorem cert_e1131188533046 : check e1131188533046 [[],[.under]] .three = true := by decide
def e1131188533050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188533050 : Closed e1131188533050 ∧ code e1131188533050 = 5529235044154 := by decide
theorem cert_e1131188533050 : check e1131188533050 [[],[.under]] .three = true := by decide
def e1131188533678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1131188533678 : Closed e1131188533678 ∧ code e1131188533678 = 5529235044782 := by decide
theorem cert_e1131188533678 : check e1131188533678 [[],[.under]] .three = true := by decide
def e1131188533690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1131188533690 : Closed e1131188533690 ∧ code e1131188533690 = 5529235044794 := by decide
theorem cert_e1131188533690 : check e1131188533690 [[],[.under]] .three = true := by decide
def e1131188533738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1131188533738 : Closed e1131188533738 ∧ code e1131188533738 = 5529235044842 := by decide
theorem cert_e1131188533738 : check e1131188533738 [[],[.under]] .three = true := by decide
def e1131188533870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188533870 : Closed e1131188533870 ∧ code e1131188533870 = 5529235044974 := by decide
theorem cert_e1131188533870 : check e1131188533870 [[],[.under]] .three = true := by decide
def e1131188533882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188533882 : Closed e1131188533882 ∧ code e1131188533882 = 5529235044986 := by decide
theorem cert_e1131188533882 : check e1131188533882 [[],[.under]] .three = true := by decide
def e1131188534170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1131188534170 : Closed e1131188534170 ∧ code e1131188534170 = 5529235045274 := by decide
theorem cert_e1131188534170 : check e1131188534170 [[],[.under]] .three = true := by decide
def e1131188534382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1131188534382 : Closed e1131188534382 ∧ code e1131188534382 = 5529235045486 := by decide
theorem cert_e1131188534382 : check e1131188534382 [[],[.under]] .three = true := by decide
def e1131188534394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1131188534394 : Closed e1131188534394 ∧ code e1131188534394 = 5529235045498 := by decide
theorem cert_e1131188534394 : check e1131188534394 [[],[.under]] .three = true := by decide
def e1131188534486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1131188534486 : Closed e1131188534486 ∧ code e1131188534486 = 5529235045590 := by decide
theorem cert_e1131188534486 : check e1131188534486 [[],[.under]] .three = true := by decide
def e1131188534490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1131188534490 : Closed e1131188534490 ∧ code e1131188534490 = 5529235045594 := by decide
theorem cert_e1131188534490 : check e1131188534490 [[],[.under]] .three = true := by decide
def e1131188534506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1131188534506 : Closed e1131188534506 ∧ code e1131188534506 = 5529235045610 := by decide
theorem cert_e1131188534506 : check e1131188534506 [[],[.under]] .three = true := by decide
def e1131188534558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1131188534558 : Closed e1131188534558 ∧ code e1131188534558 = 5529235045662 := by decide
theorem cert_e1131188534558 : check e1131188534558 [[],[.under]] .three = true := by decide
def e1131188534582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188534582 : Closed e1131188534582 ∧ code e1131188534582 = 5529235045686 := by decide
theorem cert_e1131188534582 : check e1131188534582 [[],[.under]] .three = true := by decide
def e1131188534586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188534586 : Closed e1131188534586 ∧ code e1131188534586 = 5529235045690 := by decide
theorem cert_e1131188534586 : check e1131188534586 [[],[.under]] .three = true := by decide
def e1131188534682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1131188534682 : Closed e1131188534682 ∧ code e1131188534682 = 5529235045786 := by decide
theorem cert_e1131188534682 : check e1131188534682 [[],[.under]] .three = true := by decide
def e1131188534726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1131188534726 : Closed e1131188534726 ∧ code e1131188534726 = 5529235045830 := by decide
theorem cert_e1131188534726 : check e1131188534726 [[],[.under]] .three = true := by decide
def e1131188536286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1131188536286 : Closed e1131188536286 ∧ code e1131188536286 = 5529235047390 := by decide
theorem cert_e1131188536286 : check e1131188536286 [[],[.under]] .three = true := by decide
def e1131188536302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1131188536302 : Closed e1131188536302 ∧ code e1131188536302 = 5529235047406 := by decide
theorem cert_e1131188536302 : check e1131188536302 [[],[.under]] .three = true := by decide
def e1131188538222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1131188538222 : Closed e1131188538222 ∧ code e1131188538222 = 5529235049326 := by decide
theorem cert_e1131188538222 : check e1131188538222 [[],[.under]] .three = true := by decide
def e1131188538230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1131188538230 : Closed e1131188538230 ∧ code e1131188538230 = 5529235049334 := by decide
theorem cert_e1131188538230 : check e1131188538230 [[],[.under]] .three = true := by decide
def e1131188538286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1131188538286 : Closed e1131188538286 ∧ code e1131188538286 = 5529235049390 := by decide
theorem cert_e1131188538286 : check e1131188538286 [[],[.under]] .three = true := by decide
def e1131188538298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1131188538298 : Closed e1131188538298 ∧ code e1131188538298 = 5529235049402 := by decide
theorem cert_e1131188538298 : check e1131188538298 [[],[.under]] .three = true := by decide
def e1131188538326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1131188538326 : Closed e1131188538326 ∧ code e1131188538326 = 5529235049430 := by decide
theorem cert_e1131188538326 : check e1131188538326 [[],[.under]] .three = true := by decide
end Blc.Floor42
