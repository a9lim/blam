import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211210873742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211210873742 : Closed e1211210873742 ∧ code e1211210873742 = 5609257384846 := by decide
theorem cert_e1211210873742 : check e1211210873742 [[],[]] .chain = true := by decide
def e1211210873754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210873754 : Closed e1211210873754 ∧ code e1211210873754 = 5609257384858 := by decide
theorem cert_e1211210873754 : check e1211210873754 [[],[]] .chain = true := by decide
def e1211210873878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211210873878 : Closed e1211210873878 ∧ code e1211210873878 = 5609257384982 := by decide
theorem cert_e1211210873878 : check e1211210873878 [[],[]] .chain = true := by decide
def e1211210873882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211210873882 : Closed e1211210873882 ∧ code e1211210873882 = 5609257384986 := by decide
theorem cert_e1211210873882 : check e1211210873882 [[],[]] .chain = true := by decide
def e1211210873926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211210873926 : Closed e1211210873926 ∧ code e1211210873926 = 5609257385030 := by decide
theorem cert_e1211210873926 : check e1211210873926 [[],[]] .chain = true := by decide
def e1211210873954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211210873954 : Closed e1211210873954 ∧ code e1211210873954 = 5609257385058 := by decide
theorem cert_e1211210873954 : check e1211210873954 [[],[]] .chain = true := by decide
def e1211210873966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211210873966 : Closed e1211210873966 ∧ code e1211210873966 = 5609257385070 := by decide
theorem cert_e1211210873966 : check e1211210873966 [[],[]] .sourceHead = true := by decide
def e1211210873974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211210873974 : Closed e1211210873974 ∧ code e1211210873974 = 5609257385078 := by decide
theorem cert_e1211210873974 : check e1211210873974 [[],[]] .chain = true := by decide
def e1211210873978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211210873978 : Closed e1211210873978 ∧ code e1211210873978 = 5609257385082 := by decide
theorem cert_e1211210873978 : check e1211210873978 [[],[]] .sourceHead = true := by decide
def e1211210874070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211210874070 : Closed e1211210874070 ∧ code e1211210874070 = 5609257385174 := by decide
theorem cert_e1211210874070 : check e1211210874070 [[],[]] .chain = true := by decide
def e1211210874074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211210874074 : Closed e1211210874074 ∧ code e1211210874074 = 5609257385178 := by decide
theorem cert_e1211210874074 : check e1211210874074 [[],[]] .chain = true := by decide
def e1211210874090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211210874090 : Closed e1211210874090 ∧ code e1211210874090 = 5609257385194 := by decide
theorem cert_e1211210874090 : check e1211210874090 [[],[]] .chain = true := by decide
def e1211210874118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211210874118 : Closed e1211210874118 ∧ code e1211210874118 = 5609257385222 := by decide
theorem cert_e1211210874118 : check e1211210874118 [[],[]] .chain = true := by decide
def e1211210874142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211210874142 : Closed e1211210874142 ∧ code e1211210874142 = 5609257385246 := by decide
theorem cert_e1211210874142 : check e1211210874142 [[],[]] .sourceHead = true := by decide
def e1211210874166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210874166 : Closed e1211210874166 ∧ code e1211210874166 = 5609257385270 := by decide
theorem cert_e1211210874166 : check e1211210874166 [[],[]] .chain = true := by decide
def e1211210874170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210874170 : Closed e1211210874170 ∧ code e1211210874170 = 5609257385274 := by decide
theorem cert_e1211210874170 : check e1211210874170 [[],[]] .chain = true := by decide
def e1211210874242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210874242 : Closed e1211210874242 ∧ code e1211210874242 = 5609257385346 := by decide
theorem cert_e1211210874242 : check e1211210874242 [[],[]] .chain = true := by decide
def e1211210874254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211210874254 : Closed e1211210874254 ∧ code e1211210874254 = 5609257385358 := by decide
theorem cert_e1211210874254 : check e1211210874254 [[],[]] .chain = true := by decide
def e1211210874266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210874266 : Closed e1211210874266 ∧ code e1211210874266 = 5609257385370 := by decide
theorem cert_e1211210874266 : check e1211210874266 [[],[]] .chain = true := by decide
def e1211210874310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211210874310 : Closed e1211210874310 ∧ code e1211210874310 = 5609257385414 := by decide
theorem cert_e1211210874310 : check e1211210874310 [[],[]] .sourceHead = true := by decide
def e1211210875006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211210875006 : Closed e1211210875006 ∧ code e1211210875006 = 5609257386110 := by decide
theorem cert_e1211210875006 : check e1211210875006 [[],[]] .chain = true := by decide
def e1211210875870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211210875870 : Closed e1211210875870 ∧ code e1211210875870 = 5609257386974 := by decide
theorem cert_e1211210875870 : check e1211210875870 [[],[]] .chain = true := by decide
def e1211210875874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211210875874 : Closed e1211210875874 ∧ code e1211210875874 = 5609257386978 := by decide
theorem cert_e1211210875874 : check e1211210875874 [[],[]] .chain = true := by decide
def e1211210875886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211210875886 : Closed e1211210875886 ∧ code e1211210875886 = 5609257386990 := by decide
theorem cert_e1211210875886 : check e1211210875886 [[],[]] .chain = true := by decide
def e1211210877806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211210877806 : Closed e1211210877806 ∧ code e1211210877806 = 5609257388910 := by decide
theorem cert_e1211210877806 : check e1211210877806 [[],[]] .chain = true := by decide
def e1211210877814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211210877814 : Closed e1211210877814 ∧ code e1211210877814 = 5609257388918 := by decide
theorem cert_e1211210877814 : check e1211210877814 [[],[]] .chain = true := by decide
def e1211210877870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211210877870 : Closed e1211210877870 ∧ code e1211210877870 = 5609257388974 := by decide
theorem cert_e1211210877870 : check e1211210877870 [[],[]] .chain = true := by decide
def e1211210877882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211210877882 : Closed e1211210877882 ∧ code e1211210877882 = 5609257388986 := by decide
theorem cert_e1211210877882 : check e1211210877882 [[],[]] .chain = true := by decide
def e1211210877910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211210877910 : Closed e1211210877910 ∧ code e1211210877910 = 5609257389014 := by decide
theorem cert_e1211210877910 : check e1211210877910 [[],[]] .chain = true := by decide
def e1211210877914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211210877914 : Closed e1211210877914 ∧ code e1211210877914 = 5609257389018 := by decide
theorem cert_e1211210877914 : check e1211210877914 [[],[]] .chain = true := by decide
def e1211210878190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210878190 : Closed e1211210878190 ∧ code e1211210878190 = 5609257389294 := by decide
theorem cert_e1211210878190 : check e1211210878190 [[],[]] .chain = true := by decide
def e1211210878198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210878198 : Closed e1211210878198 ∧ code e1211210878198 = 5609257389302 := by decide
theorem cert_e1211210878198 : check e1211210878198 [[],[]] .chain = true := by decide
def e1211210878574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210878574 : Closed e1211210878574 ∧ code e1211210878574 = 5609257389678 := by decide
theorem cert_e1211210878574 : check e1211210878574 [[],[]] .chain = true := by decide
def e1211210878586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210878586 : Closed e1211210878586 ∧ code e1211210878586 = 5609257389690 := by decide
theorem cert_e1211210878586 : check e1211210878586 [[],[]] .chain = true := by decide
def e1211210878726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211210878726 : Closed e1211210878726 ∧ code e1211210878726 = 5609257389830 := by decide
theorem cert_e1211210878726 : check e1211210878726 [[],[]] .chain = true := by decide
def e1211210878750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211210878750 : Closed e1211210878750 ∧ code e1211210878750 = 5609257389854 := by decide
theorem cert_e1211210878750 : check e1211210878750 [[],[]] .sourceHead = true := by decide
def e1211210878774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210878774 : Closed e1211210878774 ∧ code e1211210878774 = 5609257389878 := by decide
theorem cert_e1211210878774 : check e1211210878774 [[],[]] .chain = true := by decide
def e1211210878778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210878778 : Closed e1211210878778 ∧ code e1211210878778 = 5609257389882 := by decide
theorem cert_e1211210878778 : check e1211210878778 [[],[]] .chain = true := by decide
def e1211210883550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211210883550 : Closed e1211210883550 ∧ code e1211210883550 = 5609257394654 := by decide
theorem cert_e1211210883550 : check e1211210883550 [[],[]] .chain = true := by decide
def e1211210883574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211210883574 : Closed e1211210883574 ∧ code e1211210883574 = 5609257394678 := by decide
theorem cert_e1211210883574 : check e1211210883574 [[],[]] .chain = true := by decide
def e1211210884526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211210884526 : Closed e1211210884526 ∧ code e1211210884526 = 5609257395630 := by decide
theorem cert_e1211210884526 : check e1211210884526 [[],[]] .chain = true := by decide
def e1211210884538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211210884538 : Closed e1211210884538 ∧ code e1211210884538 = 5609257395642 := by decide
theorem cert_e1211210884538 : check e1211210884538 [[],[]] .chain = true := by decide
def e1211210884586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211210884586 : Closed e1211210884586 ∧ code e1211210884586 = 5609257395690 := by decide
theorem cert_e1211210884586 : check e1211210884586 [[],[]] .chain = true := by decide
def e1211210884718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210884718 : Closed e1211210884718 ∧ code e1211210884718 = 5609257395822 := by decide
theorem cert_e1211210884718 : check e1211210884718 [[],[]] .chain = true := by decide
def e1211210884730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210884730 : Closed e1211210884730 ∧ code e1211210884730 = 5609257395834 := by decide
theorem cert_e1211210884730 : check e1211210884730 [[],[]] .chain = true := by decide
def e1211210884894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211210884894 : Closed e1211210884894 ∧ code e1211210884894 = 5609257395998 := by decide
theorem cert_e1211210884894 : check e1211210884894 [[],[]] .chain = true := by decide
def e1211210884994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210884994 : Closed e1211210884994 ∧ code e1211210884994 = 5609257396098 := by decide
theorem cert_e1211210884994 : check e1211210884994 [[],[]] .chain = true := by decide
def e1211210885006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211210885006 : Closed e1211210885006 ∧ code e1211210885006 = 5609257396110 := by decide
theorem cert_e1211210885006 : check e1211210885006 [[],[]] .chain = true := by decide
def e1211210885018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210885018 : Closed e1211210885018 ∧ code e1211210885018 = 5609257396122 := by decide
theorem cert_e1211210885018 : check e1211210885018 [[],[]] .chain = true := by decide
def e1211210887198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211210887198 : Closed e1211210887198 ∧ code e1211210887198 = 5609257398302 := by decide
theorem cert_e1211210887198 : check e1211210887198 [[],[]] .chain = true := by decide
def e1211210887366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211210887366 : Closed e1211210887366 ∧ code e1211210887366 = 5609257398470 := by decide
theorem cert_e1211210887366 : check e1211210887366 [[],[]] .sourceHead = true := by decide
def e1211210887390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211210887390 : Closed e1211210887390 ∧ code e1211210887390 = 5609257398494 := by decide
theorem cert_e1211210887390 : check e1211210887390 [[],[]] .sourceHead = true := by decide
def e1211210887394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211210887394 : Closed e1211210887394 ∧ code e1211210887394 = 5609257398498 := by decide
theorem cert_e1211210887394 : check e1211210887394 [[],[]] .chain = true := by decide
def e1211210887406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211210887406 : Closed e1211210887406 ∧ code e1211210887406 = 5609257398510 := by decide
theorem cert_e1211210887406 : check e1211210887406 [[],[]] .chain = true := by decide
def e1211210887414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211210887414 : Closed e1211210887414 ∧ code e1211210887414 = 5609257398518 := by decide
theorem cert_e1211210887414 : check e1211210887414 [[],[]] .chain = true := by decide
def e1211210887418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211210887418 : Closed e1211210887418 ∧ code e1211210887418 = 5609257398522 := by decide
theorem cert_e1211210887418 : check e1211210887418 [[],[]] .sourceHead = true := by decide
def e1211210887894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211210887894 : Closed e1211210887894 ∧ code e1211210887894 = 5609257398998 := by decide
theorem cert_e1211210887894 : check e1211210887894 [[],[]] .chain = true := by decide
def e1211210887898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211210887898 : Closed e1211210887898 ∧ code e1211210887898 = 5609257399002 := by decide
theorem cert_e1211210887898 : check e1211210887898 [[],[]] .chain = true := by decide
def e1211210887914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211210887914 : Closed e1211210887914 ∧ code e1211210887914 = 5609257399018 := by decide
theorem cert_e1211210887914 : check e1211210887914 [[],[]] .chain = true := by decide
def e1211210887942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211210887942 : Closed e1211210887942 ∧ code e1211210887942 = 5609257399046 := by decide
theorem cert_e1211210887942 : check e1211210887942 [[],[]] .chain = true := by decide
def e1211210887966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211210887966 : Closed e1211210887966 ∧ code e1211210887966 = 5609257399070 := by decide
theorem cert_e1211210887966 : check e1211210887966 [[],[]] .sourceHead = true := by decide
def e1211210887990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211210887990 : Closed e1211210887990 ∧ code e1211210887990 = 5609257399094 := by decide
theorem cert_e1211210887990 : check e1211210887990 [[],[]] .chain = true := by decide
def e1211210887994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211210887994 : Closed e1211210887994 ∧ code e1211210887994 = 5609257399098 := by decide
theorem cert_e1211210887994 : check e1211210887994 [[],[]] .chain = true := by decide
def e1211210888066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210888066 : Closed e1211210888066 ∧ code e1211210888066 = 5609257399170 := by decide
theorem cert_e1211210888066 : check e1211210888066 [[],[]] .chain = true := by decide
def e1211210888078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211210888078 : Closed e1211210888078 ∧ code e1211210888078 = 5609257399182 := by decide
theorem cert_e1211210888078 : check e1211210888078 [[],[]] .chain = true := by decide
def e1211210888090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210888090 : Closed e1211210888090 ∧ code e1211210888090 = 5609257399194 := by decide
theorem cert_e1211210888090 : check e1211210888090 [[],[]] .chain = true := by decide
def e1211210888134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211210888134 : Closed e1211210888134 ∧ code e1211210888134 = 5609257399238 := by decide
theorem cert_e1211210888134 : check e1211210888134 [[],[]] .sourceHead = true := by decide
def e1211210891886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210891886 : Closed e1211210891886 ∧ code e1211210891886 = 5609257402990 := by decide
theorem cert_e1211210891886 : check e1211210891886 [[],[]] .chain = true := by decide
def e1211210891898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210891898 : Closed e1211210891898 ∧ code e1211210891898 = 5609257403002 := by decide
theorem cert_e1211210891898 : check e1211210891898 [[],[]] .chain = true := by decide
def e1211210893166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211210893166 : Closed e1211210893166 ∧ code e1211210893166 = 5609257404270 := by decide
theorem cert_e1211210893166 : check e1211210893166 [[],[]] .chain = true := by decide
def e1211210893178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e1211210893178 : Closed e1211210893178 ∧ code e1211210893178 = 5609257404282 := by decide
theorem cert_e1211210893178 : check e1211210893178 [[],[]] .chain = true := by decide
def e1211210893274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e1211210893274 : Closed e1211210893274 ∧ code e1211210893274 = 5609257404378 := by decide
theorem cert_e1211210893274 : check e1211210893274 [[],[]] .chain = true := by decide
def e1211210894574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211210894574 : Closed e1211210894574 ∧ code e1211210894574 = 5609257405678 := by decide
theorem cert_e1211210894574 : check e1211210894574 [[],[]] .chain = true := by decide
def e1211210894582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211210894582 : Closed e1211210894582 ∧ code e1211210894582 = 5609257405686 := by decide
theorem cert_e1211210894582 : check e1211210894582 [[],[]] .chain = true := by decide
def e1211210894958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210894958 : Closed e1211210894958 ∧ code e1211210894958 = 5609257406062 := by decide
theorem cert_e1211210894958 : check e1211210894958 [[],[]] .chain = true := by decide
def e1211210894970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210894970 : Closed e1211210894970 ∧ code e1211210894970 = 5609257406074 := by decide
theorem cert_e1211210894970 : check e1211210894970 [[],[]] .chain = true := by decide
def e1211210895158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210895158 : Closed e1211210895158 ∧ code e1211210895158 = 5609257406262 := by decide
theorem cert_e1211210895158 : check e1211210895158 [[],[]] .chain = true := by decide
def e1211210895162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210895162 : Closed e1211210895162 ∧ code e1211210895162 = 5609257406266 := by decide
theorem cert_e1211210895162 : check e1211210895162 [[],[]] .chain = true := by decide
def e1211210897070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211210897070 : Closed e1211210897070 ∧ code e1211210897070 = 5609257408174 := by decide
theorem cert_e1211210897070 : check e1211210897070 [[],[]] .chain = true := by decide
def e1211210897082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211210897082 : Closed e1211210897082 ∧ code e1211210897082 = 5609257408186 := by decide
theorem cert_e1211210897082 : check e1211210897082 [[],[]] .chain = true := by decide
def e1211210897130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211210897130 : Closed e1211210897130 ∧ code e1211210897130 = 5609257408234 := by decide
theorem cert_e1211210897130 : check e1211210897130 [[],[]] .chain = true := by decide
def e1211210897322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1211210897322 : Closed e1211210897322 ∧ code e1211210897322 = 5609257408426 := by decide
theorem cert_e1211210897322 : check e1211210897322 [[],[]] .chain = true := by decide
def e1211210897454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211210897454 : Closed e1211210897454 ∧ code e1211210897454 = 5609257408558 := by decide
theorem cert_e1211210897454 : check e1211210897454 [[],[]] .chain = true := by decide
def e1211210897646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211210897646 : Closed e1211210897646 ∧ code e1211210897646 = 5609257408750 := by decide
theorem cert_e1211210897646 : check e1211210897646 [[],[]] .chain = true := by decide
def e1211210897654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211210897654 : Closed e1211210897654 ∧ code e1211210897654 = 5609257408758 := by decide
theorem cert_e1211210897654 : check e1211210897654 [[],[]] .chain = true := by decide
def e1211210897838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211210897838 : Closed e1211210897838 ∧ code e1211210897838 = 5609257408942 := by decide
theorem cert_e1211210897838 : check e1211210897838 [[],[]] .chain = true := by decide
def e1211210897850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211210897850 : Closed e1211210897850 ∧ code e1211210897850 = 5609257408954 := by decide
theorem cert_e1211210897850 : check e1211210897850 [[],[]] .chain = true := by decide
def e1211210897898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211210897898 : Closed e1211210897898 ∧ code e1211210897898 = 5609257409002 := by decide
theorem cert_e1211210897898 : check e1211210897898 [[],[]] .chain = true := by decide
def e1211210898030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210898030 : Closed e1211210898030 ∧ code e1211210898030 = 5609257409134 := by decide
theorem cert_e1211210898030 : check e1211210898030 [[],[]] .chain = true := by decide
def e1211210898042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210898042 : Closed e1211210898042 ∧ code e1211210898042 = 5609257409146 := by decide
theorem cert_e1211210898042 : check e1211210898042 [[],[]] .chain = true := by decide
def e1211210898206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211210898206 : Closed e1211210898206 ∧ code e1211210898206 = 5609257409310 := by decide
theorem cert_e1211210898206 : check e1211210898206 [[],[]] .chain = true := by decide
def e1211210898306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210898306 : Closed e1211210898306 ∧ code e1211210898306 = 5609257409410 := by decide
theorem cert_e1211210898306 : check e1211210898306 [[],[]] .chain = true := by decide
def e1211210898318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211210898318 : Closed e1211210898318 ∧ code e1211210898318 = 5609257409422 := by decide
theorem cert_e1211210898318 : check e1211210898318 [[],[]] .chain = true := by decide
def e1211210898330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210898330 : Closed e1211210898330 ∧ code e1211210898330 = 5609257409434 := by decide
theorem cert_e1211210898330 : check e1211210898330 [[],[]] .chain = true := by decide
def e1211210898542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211210898542 : Closed e1211210898542 ∧ code e1211210898542 = 5609257409646 := by decide
theorem cert_e1211210898542 : check e1211210898542 [[],[]] .chain = true := by decide
def e1211210898554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211210898554 : Closed e1211210898554 ∧ code e1211210898554 = 5609257409658 := by decide
theorem cert_e1211210898554 : check e1211210898554 [[],[]] .chain = true := by decide
def e1211210898718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211210898718 : Closed e1211210898718 ∧ code e1211210898718 = 5609257409822 := by decide
theorem cert_e1211210898718 : check e1211210898718 [[],[]] .chain = true := by decide
def e1211210898886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211210898886 : Closed e1211210898886 ∧ code e1211210898886 = 5609257409990 := by decide
theorem cert_e1211210898886 : check e1211210898886 [[],[]] .chain = true := by decide
def e1211210898954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211210898954 : Closed e1211210898954 ∧ code e1211210898954 = 5609257410058 := by decide
theorem cert_e1211210898954 : check e1211210898954 [[],[]] .chain = true := by decide
def e1211210898998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211210898998 : Closed e1211210898998 ∧ code e1211210898998 = 5609257410102 := by decide
theorem cert_e1211210898998 : check e1211210898998 [[],[]] .chain = true := by decide
def e1211210899002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211210899002 : Closed e1211210899002 ∧ code e1211210899002 = 5609257410106 := by decide
theorem cert_e1211210899002 : check e1211210899002 [[],[]] .chain = true := by decide
def e1211210899050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211210899050 : Closed e1211210899050 ∧ code e1211210899050 = 5609257410154 := by decide
theorem cert_e1211210899050 : check e1211210899050 [[],[]] .chain = true := by decide
def e1211210899074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211210899074 : Closed e1211210899074 ∧ code e1211210899074 = 5609257410178 := by decide
theorem cert_e1211210899074 : check e1211210899074 [[],[]] .chain = true := by decide
def e1211210899086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211210899086 : Closed e1211210899086 ∧ code e1211210899086 = 5609257410190 := by decide
theorem cert_e1211210899086 : check e1211210899086 [[],[]] .chain = true := by decide
def e1211210899098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210899098 : Closed e1211210899098 ∧ code e1211210899098 = 5609257410202 := by decide
theorem cert_e1211210899098 : check e1211210899098 [[],[]] .chain = true := by decide
def e1211210899142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211210899142 : Closed e1211210899142 ∧ code e1211210899142 = 5609257410246 := by decide
theorem cert_e1211210899142 : check e1211210899142 [[],[]] .chain = true := by decide
def e1211210899934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211210899934 : Closed e1211210899934 ∧ code e1211210899934 = 5609257411038 := by decide
theorem cert_e1211210899934 : check e1211210899934 [[],[]] .chain = true := by decide
def e1211210899958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211210899958 : Closed e1211210899958 ∧ code e1211210899958 = 5609257411062 := by decide
theorem cert_e1211210899958 : check e1211210899958 [[],[]] .chain = true := by decide
def e1211210900910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211210900910 : Closed e1211210900910 ∧ code e1211210900910 = 5609257412014 := by decide
theorem cert_e1211210900910 : check e1211210900910 [[],[]] .chain = true := by decide
def e1211210900922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211210900922 : Closed e1211210900922 ∧ code e1211210900922 = 5609257412026 := by decide
theorem cert_e1211210900922 : check e1211210900922 [[],[]] .chain = true := by decide
def e1211210900970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211210900970 : Closed e1211210900970 ∧ code e1211210900970 = 5609257412074 := by decide
theorem cert_e1211210900970 : check e1211210900970 [[],[]] .chain = true := by decide
def e1211210901102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211210901102 : Closed e1211210901102 ∧ code e1211210901102 = 5609257412206 := by decide
theorem cert_e1211210901102 : check e1211210901102 [[],[]] .chain = true := by decide
def e1211210901114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211210901114 : Closed e1211210901114 ∧ code e1211210901114 = 5609257412218 := by decide
theorem cert_e1211210901114 : check e1211210901114 [[],[]] .chain = true := by decide
def e1211210901278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211210901278 : Closed e1211210901278 ∧ code e1211210901278 = 5609257412382 := by decide
theorem cert_e1211210901278 : check e1211210901278 [[],[]] .chain = true := by decide
def e1211210901378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210901378 : Closed e1211210901378 ∧ code e1211210901378 = 5609257412482 := by decide
theorem cert_e1211210901378 : check e1211210901378 [[],[]] .chain = true := by decide
def e1211210901390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211210901390 : Closed e1211210901390 ∧ code e1211210901390 = 5609257412494 := by decide
theorem cert_e1211210901390 : check e1211210901390 [[],[]] .chain = true := by decide
def e1211210901402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210901402 : Closed e1211210901402 ∧ code e1211210901402 = 5609257412506 := by decide
theorem cert_e1211210901402 : check e1211210901402 [[],[]] .chain = true := by decide
def e1211210904350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211210904350 : Closed e1211210904350 ∧ code e1211210904350 = 5609257415454 := by decide
theorem cert_e1211210904350 : check e1211210904350 [[],[]] .chain = true := by decide
def e1211210904518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211210904518 : Closed e1211210904518 ∧ code e1211210904518 = 5609257415622 := by decide
theorem cert_e1211210904518 : check e1211210904518 [[],[]] .chain = true := by decide
def e1211210905718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e1211210905718 : Closed e1211210905718 ∧ code e1211210905718 = 5609257416822 := by decide
theorem cert_e1211210905718 : check e1211210905718 [[],[]] .chain = true := by decide
def e1211210905962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e1211210905962 : Closed e1211210905962 ∧ code e1211210905962 = 5609257417066 := by decide
theorem cert_e1211210905962 : check e1211210905962 [[],[]] .chain = true := by decide
def e1211210905986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e1211210905986 : Closed e1211210905986 ∧ code e1211210905986 = 5609257417090 := by decide
theorem cert_e1211210905986 : check e1211210905986 [[],[]] .chain = true := by decide
def e1211210905998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211210905998 : Closed e1211210905998 ∧ code e1211210905998 = 5609257417102 := by decide
theorem cert_e1211210905998 : check e1211210905998 [[],[]] .chain = true := by decide
def e1211210906010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210906010 : Closed e1211210906010 ∧ code e1211210906010 = 5609257417114 := by decide
theorem cert_e1211210906010 : check e1211210906010 [[],[]] .chain = true := by decide
def e1211210906054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211210906054 : Closed e1211210906054 ∧ code e1211210906054 = 5609257417158 := by decide
theorem cert_e1211210906054 : check e1211210906054 [[],[]] .chain = true := by decide
def e1211210907770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211210907770 : Closed e1211210907770 ∧ code e1211210907770 = 5609257418874 := by decide
theorem cert_e1211210907770 : check e1211210907770 [[],[]] .chain = true := by decide
def e1211210907958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210907958 : Closed e1211210907958 ∧ code e1211210907958 = 5609257419062 := by decide
theorem cert_e1211210907958 : check e1211210907958 [[],[]] .chain = true := by decide
def e1211210907962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210907962 : Closed e1211210907962 ∧ code e1211210907962 = 5609257419066 := by decide
theorem cert_e1211210907962 : check e1211210907962 [[],[]] .chain = true := by decide
def e1211210908058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210908058 : Closed e1211210908058 ∧ code e1211210908058 = 5609257419162 := by decide
theorem cert_e1211210908058 : check e1211210908058 [[],[]] .chain = true := by decide
def e1211210908102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211210908102 : Closed e1211210908102 ∧ code e1211210908102 = 5609257419206 := by decide
theorem cert_e1211210908102 : check e1211210908102 [[],[]] .chain = true := by decide
def e1211210908442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211210908442 : Closed e1211210908442 ∧ code e1211210908442 = 5609257419546 := by decide
theorem cert_e1211210908442 : check e1211210908442 [[],[]] .sourceHead = true := by decide
def e1211210908486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211210908486 : Closed e1211210908486 ∧ code e1211210908486 = 5609257419590 := by decide
theorem cert_e1211210908486 : check e1211210908486 [[],[]] .sourceHead = true := by decide
def e1211210908526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211210908526 : Closed e1211210908526 ∧ code e1211210908526 = 5609257419630 := by decide
theorem cert_e1211210908526 : check e1211210908526 [[],[]] .sourceHead = true := by decide
def e1211210908538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e1211210908538 : Closed e1211210908538 ∧ code e1211210908538 = 5609257419642 := by decide
theorem cert_e1211210908538 : check e1211210908538 [[],[]] .sourceHead = true := by decide
def e1211210908554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211210908554 : Closed e1211210908554 ∧ code e1211210908554 = 5609257419658 := by decide
theorem cert_e1211210908554 : check e1211210908554 [[],[]] .chain = true := by decide
def e1211210908590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211210908590 : Closed e1211210908590 ∧ code e1211210908590 = 5609257419694 := by decide
theorem cert_e1211210908590 : check e1211210908590 [[],[]] .sourceHead = true := by decide
def e1211210908598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e1211210908598 : Closed e1211210908598 ∧ code e1211210908598 = 5609257419702 := by decide
theorem cert_e1211210908598 : check e1211210908598 [[],[]] .chain = true := by decide
def e1211210908602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211210908602 : Closed e1211210908602 ∧ code e1211210908602 = 5609257419706 := by decide
theorem cert_e1211210908602 : check e1211210908602 [[],[]] .chain = true := by decide
def e1211210908634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211210908634 : Closed e1211210908634 ∧ code e1211210908634 = 5609257419738 := by decide
theorem cert_e1211210908634 : check e1211210908634 [[],[]] .chain = true := by decide
def e1211210908650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e1211210908650 : Closed e1211210908650 ∧ code e1211210908650 = 5609257419754 := by decide
theorem cert_e1211210908650 : check e1211210908650 [[],[]] .sourceHead = true := by decide
def e1211210908870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211210908870 : Closed e1211210908870 ∧ code e1211210908870 = 5609257419974 := by decide
theorem cert_e1211210908870 : check e1211210908870 [[],[]] .chain = true := by decide
def e1211210909198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211210909198 : Closed e1211210909198 ∧ code e1211210909198 = 5609257420302 := by decide
theorem cert_e1211210909198 : check e1211210909198 [[],[]] .chain = true := by decide
def e1211210909210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211210909210 : Closed e1211210909210 ∧ code e1211210909210 = 5609257420314 := by decide
theorem cert_e1211210909210 : check e1211210909210 [[],[]] .sourceHead = true := by decide
def e1211210909282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211210909282 : Closed e1211210909282 ∧ code e1211210909282 = 5609257420386 := by decide
theorem cert_e1211210909282 : check e1211210909282 [[],[]] .chain = true := by decide
def e1211210909294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211210909294 : Closed e1211210909294 ∧ code e1211210909294 = 5609257420398 := by decide
theorem cert_e1211210909294 : check e1211210909294 [[],[]] .sourceHead = true := by decide
def e1211210909302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211210909302 : Closed e1211210909302 ∧ code e1211210909302 = 5609257420406 := by decide
theorem cert_e1211210909302 : check e1211210909302 [[],[]] .chain = true := by decide
def e1211210909306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211210909306 : Closed e1211210909306 ∧ code e1211210909306 = 5609257420410 := by decide
theorem cert_e1211210909306 : check e1211210909306 [[],[]] .sourceHead = true := by decide
def e1211210909494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211210909494 : Closed e1211210909494 ∧ code e1211210909494 = 5609257420598 := by decide
theorem cert_e1211210909494 : check e1211210909494 [[],[]] .chain = true := by decide
def e1211210909498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211210909498 : Closed e1211210909498 ∧ code e1211210909498 = 5609257420602 := by decide
theorem cert_e1211210909498 : check e1211210909498 [[],[]] .chain = true := by decide
def e1211210909594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211210909594 : Closed e1211210909594 ∧ code e1211210909594 = 5609257420698 := by decide
theorem cert_e1211210909594 : check e1211210909594 [[],[]] .sourceHead = true := by decide
def e1211210910550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211210910550 : Closed e1211210910550 ∧ code e1211210910550 = 5609257421654 := by decide
theorem cert_e1211210910550 : check e1211210910550 [[],[]] .chain = true := by decide
def e1211210910554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211210910554 : Closed e1211210910554 ∧ code e1211210910554 = 5609257421658 := by decide
theorem cert_e1211210910554 : check e1211210910554 [[],[]] .chain = true := by decide
def e1211210910570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211210910570 : Closed e1211210910570 ∧ code e1211210910570 = 5609257421674 := by decide
theorem cert_e1211210910570 : check e1211210910570 [[],[]] .chain = true := by decide
def e1211210910634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1211210910634 : Closed e1211210910634 ∧ code e1211210910634 = 5609257421738 := by decide
theorem cert_e1211210910634 : check e1211210910634 [[],[]] .chain = true := by decide
def e1211210910742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211210910742 : Closed e1211210910742 ∧ code e1211210910742 = 5609257421846 := by decide
theorem cert_e1211210910742 : check e1211210910742 [[],[]] .chain = true := by decide
def e1211210910746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211210910746 : Closed e1211210910746 ∧ code e1211210910746 = 5609257421850 := by decide
theorem cert_e1211210910746 : check e1211210910746 [[],[]] .chain = true := by decide
def e1211210910790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211210910790 : Closed e1211210910790 ∧ code e1211210910790 = 5609257421894 := by decide
theorem cert_e1211210910790 : check e1211210910790 [[],[]] .chain = true := by decide
def e1211210910818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211210910818 : Closed e1211210910818 ∧ code e1211210910818 = 5609257421922 := by decide
theorem cert_e1211210910818 : check e1211210910818 [[],[]] .chain = true := by decide
def e1211210910830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211210910830 : Closed e1211210910830 ∧ code e1211210910830 = 5609257421934 := by decide
theorem cert_e1211210910830 : check e1211210910830 [[],[]] .sourceHead = true := by decide
def e1211210910838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211210910838 : Closed e1211210910838 ∧ code e1211210910838 = 5609257421942 := by decide
theorem cert_e1211210910838 : check e1211210910838 [[],[]] .chain = true := by decide
end Blc.Floor42
