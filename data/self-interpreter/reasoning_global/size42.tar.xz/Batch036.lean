import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1105380969670 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105380969670 : Closed e1105380969670 ∧ code e1105380969670 = 5503427480774 := by decide
theorem cert_e1105380969670 : check e1105380969670 [[]] .width = true := by decide
def e1105381318682 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105381318682 : Closed e1105381318682 ∧ code e1105381318682 = 5503427829786 := by decide
theorem cert_e1105381318682 : check e1105381318682 [[]] .width = true := by decide
def e1105381318774 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105381318774 : Closed e1105381318774 ∧ code e1105381318774 = 5503427829878 := by decide
theorem cert_e1105381318774 : check e1105381318774 [[]] .width = true := by decide
def e1105381319018 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105381319018 : Closed e1105381319018 ∧ code e1105381319018 = 5503427830122 := by decide
theorem cert_e1105381319018 : check e1105381319018 [[]] .width = true := by decide
def e1105381319066 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105381319066 : Closed e1105381319066 ∧ code e1105381319066 = 5503427830170 := by decide
theorem cert_e1105381319066 : check e1105381319066 [[]] .width = true := by decide
def e1105381359814 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105381359814 : Closed e1105381359814 ∧ code e1105381359814 = 5503427870918 := by decide
theorem cert_e1105381359814 : check e1105381359814 [[]] .width = true := by decide
def e1105381360342 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105381360342 : Closed e1105381360342 ∧ code e1105381360342 = 5503427871446 := by decide
theorem cert_e1105381360342 : check e1105381360342 [[]] .width = true := by decide
def e1105381360346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105381360346 : Closed e1105381360346 ∧ code e1105381360346 = 5503427871450 := by decide
theorem cert_e1105381360346 : check e1105381360346 [[]] .width = true := by decide
def e1105381360362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105381360362 : Closed e1105381360362 ∧ code e1105381360362 = 5503427871466 := by decide
theorem cert_e1105381360362 : check e1105381360362 [[]] .width = true := by decide
def e1105381360438 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105381360438 : Closed e1105381360438 ∧ code e1105381360438 = 5503427871542 := by decide
theorem cert_e1105381360438 : check e1105381360438 [[]] .width = true := by decide
def e1105381360442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105381360442 : Closed e1105381360442 ∧ code e1105381360442 = 5503427871546 := by decide
theorem cert_e1105381360442 : check e1105381360442 [[]] .width = true := by decide
def e1105381360526 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105381360526 : Closed e1105381360526 ∧ code e1105381360526 = 5503427871630 := by decide
theorem cert_e1105381360526 : check e1105381360526 [[]] .width = true := by decide
def e1105381360538 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105381360538 : Closed e1105381360538 ∧ code e1105381360538 = 5503427871642 := by decide
theorem cert_e1105381360538 : check e1105381360538 [[]] .width = true := by decide
def e1105381362458 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105381362458 : Closed e1105381362458 ∧ code e1105381362458 = 5503427873562 := by decide
theorem cert_e1105381362458 : check e1105381362458 [[]] .width = true := by decide
def e1105381362502 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105381362502 : Closed e1105381362502 ∧ code e1105381362502 = 5503427873606 := by decide
theorem cert_e1105381362502 : check e1105381362502 [[]] .width = true := by decide
def e1105381362742 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105381362742 : Closed e1105381362742 ∧ code e1105381362742 = 5503427873846 := by decide
theorem cert_e1105381362742 : check e1105381362742 [[]] .width = true := by decide
def e1105381362746 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105381362746 : Closed e1105381362746 ∧ code e1105381362746 = 5503427873850 := by decide
theorem cert_e1105381362746 : check e1105381362746 [[]] .width = true := by decide
def e1105381362886 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105381362886 : Closed e1105381362886 ∧ code e1105381362886 = 5503427873990 := by decide
theorem cert_e1105381362886 : check e1105381362886 [[]] .width = true := by decide
def e1105387249690 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105387249690 : Closed e1105387249690 ∧ code e1105387249690 = 5503433760794 := by decide
theorem cert_e1105387249690 : check e1105387249690 [[]] .width = true := by decide
def e1105387249782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105387249782 : Closed e1105387249782 ∧ code e1105387249782 = 5503433760886 := by decide
theorem cert_e1105387249782 : check e1105387249782 [[]] .width = true := by decide
def e1105387250026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105387250026 : Closed e1105387250026 ∧ code e1105387250026 = 5503433761130 := by decide
theorem cert_e1105387250026 : check e1105387250026 [[]] .width = true := by decide
def e1105387250074 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105387250074 : Closed e1105387250074 ∧ code e1105387250074 = 5503433761178 := by decide
theorem cert_e1105387250074 : check e1105387250074 [[]] .width = true := by decide
def e1105387282458 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105387282458 : Closed e1105387282458 ∧ code e1105387282458 = 5503433793562 := by decide
theorem cert_e1105387282458 : check e1105387282458 [[]] .width = true := by decide
def e1105387282550 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105387282550 : Closed e1105387282550 ∧ code e1105387282550 = 5503433793654 := by decide
theorem cert_e1105387282550 : check e1105387282550 [[]] .width = true := by decide
def e1105387282794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105387282794 : Closed e1105387282794 ∧ code e1105387282794 = 5503433793898 := by decide
theorem cert_e1105387282794 : check e1105387282794 [[]] .width = true := by decide
def e1105387282842 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105387282842 : Closed e1105387282842 ∧ code e1105387282842 = 5503433793946 := by decide
theorem cert_e1105387282842 : check e1105387282842 [[]] .width = true := by decide
def e1105387511834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105387511834 : Closed e1105387511834 ∧ code e1105387511834 = 5503434022938 := by decide
theorem cert_e1105387511834 : check e1105387511834 [[]] .width = true := by decide
def e1105387511926 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105387511926 : Closed e1105387511926 ∧ code e1105387511926 = 5503434023030 := by decide
theorem cert_e1105387511926 : check e1105387511926 [[]] .width = true := by decide
def e1105387512170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105387512170 : Closed e1105387512170 ∧ code e1105387512170 = 5503434023274 := by decide
theorem cert_e1105387512170 : check e1105387512170 [[]] .width = true := by decide
def e1105387512218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105387512218 : Closed e1105387512218 ∧ code e1105387512218 = 5503434023322 := by decide
theorem cert_e1105387512218 : check e1105387512218 [[]] .width = true := by decide
def e1105387560986 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105387560986 : Closed e1105387560986 ∧ code e1105387560986 = 5503434072090 := by decide
theorem cert_e1105387560986 : check e1105387560986 [[]] .width = true := by decide
def e1105387561078 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105387561078 : Closed e1105387561078 ∧ code e1105387561078 = 5503434072182 := by decide
theorem cert_e1105387561078 : check e1105387561078 [[]] .width = true := by decide
def e1105387561322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105387561322 : Closed e1105387561322 ∧ code e1105387561322 = 5503434072426 := by decide
theorem cert_e1105387561322 : check e1105387561322 [[]] .width = true := by decide
def e1105387561370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105387561370 : Closed e1105387561370 ∧ code e1105387561370 = 5503434072474 := by decide
theorem cert_e1105387561370 : check e1105387561370 [[]] .width = true := by decide
def e1105393016858 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105393016858 : Closed e1105393016858 ∧ code e1105393016858 = 5503439527962 := by decide
theorem cert_e1105393016858 : check e1105393016858 [[]] .width = true := by decide
def e1105393016950 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105393016950 : Closed e1105393016950 ∧ code e1105393016950 = 5503439528054 := by decide
theorem cert_e1105393016950 : check e1105393016950 [[]] .width = true := by decide
def e1105393017194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105393017194 : Closed e1105393017194 ∧ code e1105393017194 = 5503439528298 := by decide
theorem cert_e1105393017194 : check e1105393017194 [[]] .width = true := by decide
def e1105393017242 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105393017242 : Closed e1105393017242 ∧ code e1105393017242 = 5503439528346 := by decide
theorem cert_e1105393017242 : check e1105393017242 [[]] .width = true := by decide
def e1105395646662 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105395646662 : Closed e1105395646662 ∧ code e1105395646662 = 5503442157766 := by decide
theorem cert_e1105395646662 : check e1105395646662 [[]] .width = true := by decide
def e1105395647190 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105395647190 : Closed e1105395647190 ∧ code e1105395647190 = 5503442158294 := by decide
theorem cert_e1105395647190 : check e1105395647190 [[]] .width = true := by decide
def e1105395647194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105395647194 : Closed e1105395647194 ∧ code e1105395647194 = 5503442158298 := by decide
theorem cert_e1105395647194 : check e1105395647194 [[]] .width = true := by decide
def e1105395647210 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105395647210 : Closed e1105395647210 ∧ code e1105395647210 = 5503442158314 := by decide
theorem cert_e1105395647210 : check e1105395647210 [[]] .width = true := by decide
def e1105395647286 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105395647286 : Closed e1105395647286 ∧ code e1105395647286 = 5503442158390 := by decide
theorem cert_e1105395647286 : check e1105395647286 [[]] .width = true := by decide
def e1105395647290 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105395647290 : Closed e1105395647290 ∧ code e1105395647290 = 5503442158394 := by decide
theorem cert_e1105395647290 : check e1105395647290 [[]] .width = true := by decide
def e1105395647374 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105395647374 : Closed e1105395647374 ∧ code e1105395647374 = 5503442158478 := by decide
theorem cert_e1105395647374 : check e1105395647374 [[]] .width = true := by decide
def e1105395647386 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105395647386 : Closed e1105395647386 ∧ code e1105395647386 = 5503442158490 := by decide
theorem cert_e1105395647386 : check e1105395647386 [[]] .width = true := by decide
def e1105395649306 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105395649306 : Closed e1105395649306 ∧ code e1105395649306 = 5503442160410 := by decide
theorem cert_e1105395649306 : check e1105395649306 [[]] .width = true := by decide
def e1105395649350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105395649350 : Closed e1105395649350 ∧ code e1105395649350 = 5503442160454 := by decide
theorem cert_e1105395649350 : check e1105395649350 [[]] .width = true := by decide
def e1105395649590 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105395649590 : Closed e1105395649590 ∧ code e1105395649590 = 5503442160694 := by decide
theorem cert_e1105395649590 : check e1105395649590 [[]] .width = true := by decide
def e1105395649594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105395649594 : Closed e1105395649594 ∧ code e1105395649594 = 5503442160698 := by decide
theorem cert_e1105395649594 : check e1105395649594 [[]] .width = true := by decide
def e1105395649734 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105395649734 : Closed e1105395649734 ∧ code e1105395649734 = 5503442160838 := by decide
theorem cert_e1105395649734 : check e1105395649734 [[]] .width = true := by decide
def e1105395769370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105395769370 : Closed e1105395769370 ∧ code e1105395769370 = 5503442280474 := by decide
theorem cert_e1105395769370 : check e1105395769370 [[]] .width = true := by decide
def e1105395769462 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105395769462 : Closed e1105395769462 ∧ code e1105395769462 = 5503442280566 := by decide
theorem cert_e1105395769462 : check e1105395769462 [[]] .width = true := by decide
def e1105395769706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105395769706 : Closed e1105395769706 ∧ code e1105395769706 = 5503442280810 := by decide
theorem cert_e1105395769706 : check e1105395769706 [[]] .width = true := by decide
def e1105395769754 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105395769754 : Closed e1105395769754 ∧ code e1105395769754 = 5503442280858 := by decide
theorem cert_e1105395769754 : check e1105395769754 [[]] .width = true := by decide
def e1105395908806 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105395908806 : Closed e1105395908806 ∧ code e1105395908806 = 5503442419910 := by decide
theorem cert_e1105395908806 : check e1105395908806 [[]] .width = true := by decide
def e1105395909334 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105395909334 : Closed e1105395909334 ∧ code e1105395909334 = 5503442420438 := by decide
theorem cert_e1105395909334 : check e1105395909334 [[]] .width = true := by decide
def e1105395909338 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105395909338 : Closed e1105395909338 ∧ code e1105395909338 = 5503442420442 := by decide
theorem cert_e1105395909338 : check e1105395909338 [[]] .width = true := by decide
def e1105395909354 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105395909354 : Closed e1105395909354 ∧ code e1105395909354 = 5503442420458 := by decide
theorem cert_e1105395909354 : check e1105395909354 [[]] .width = true := by decide
def e1105395909430 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105395909430 : Closed e1105395909430 ∧ code e1105395909430 = 5503442420534 := by decide
theorem cert_e1105395909430 : check e1105395909430 [[]] .width = true := by decide
def e1105395909434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105395909434 : Closed e1105395909434 ∧ code e1105395909434 = 5503442420538 := by decide
theorem cert_e1105395909434 : check e1105395909434 [[]] .width = true := by decide
def e1105395909518 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105395909518 : Closed e1105395909518 ∧ code e1105395909518 = 5503442420622 := by decide
theorem cert_e1105395909518 : check e1105395909518 [[]] .width = true := by decide
def e1105395909530 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105395909530 : Closed e1105395909530 ∧ code e1105395909530 = 5503442420634 := by decide
theorem cert_e1105395909530 : check e1105395909530 [[]] .width = true := by decide
def e1105395911450 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105395911450 : Closed e1105395911450 ∧ code e1105395911450 = 5503442422554 := by decide
theorem cert_e1105395911450 : check e1105395911450 [[]] .width = true := by decide
def e1105395911494 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105395911494 : Closed e1105395911494 ∧ code e1105395911494 = 5503442422598 := by decide
theorem cert_e1105395911494 : check e1105395911494 [[]] .width = true := by decide
def e1105395911734 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105395911734 : Closed e1105395911734 ∧ code e1105395911734 = 5503442422838 := by decide
theorem cert_e1105395911734 : check e1105395911734 [[]] .width = true := by decide
def e1105395911738 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105395911738 : Closed e1105395911738 ∧ code e1105395911738 = 5503442422842 := by decide
theorem cert_e1105395911738 : check e1105395911738 [[]] .width = true := by decide
def e1105395911878 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105395911878 : Closed e1105395911878 ∧ code e1105395911878 = 5503442422982 := by decide
theorem cert_e1105395911878 : check e1105395911878 [[]] .width = true := by decide
def e1105396686874 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105396686874 : Closed e1105396686874 ∧ code e1105396686874 = 5503443197978 := by decide
theorem cert_e1105396686874 : check e1105396686874 [[]] .width = true := by decide
def e1105396686966 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105396686966 : Closed e1105396686966 ∧ code e1105396686966 = 5503443198070 := by decide
theorem cert_e1105396686966 : check e1105396686966 [[]] .width = true := by decide
def e1105396687210 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105396687210 : Closed e1105396687210 ∧ code e1105396687210 = 5503443198314 := by decide
theorem cert_e1105396687210 : check e1105396687210 [[]] .width = true := by decide
def e1105396687258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105396687258 : Closed e1105396687258 ∧ code e1105396687258 = 5503443198362 := by decide
theorem cert_e1105396687258 : check e1105396687258 [[]] .width = true := by decide
def e1105397743814 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105397743814 : Closed e1105397743814 ∧ code e1105397743814 = 5503444254918 := by decide
theorem cert_e1105397743814 : check e1105397743814 [[]] .width = true := by decide
def e1105397744342 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105397744342 : Closed e1105397744342 ∧ code e1105397744342 = 5503444255446 := by decide
theorem cert_e1105397744342 : check e1105397744342 [[]] .width = true := by decide
def e1105397744346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105397744346 : Closed e1105397744346 ∧ code e1105397744346 = 5503444255450 := by decide
theorem cert_e1105397744346 : check e1105397744346 [[]] .width = true := by decide
def e1105397744362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105397744362 : Closed e1105397744362 ∧ code e1105397744362 = 5503444255466 := by decide
theorem cert_e1105397744362 : check e1105397744362 [[]] .width = true := by decide
def e1105397744438 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105397744438 : Closed e1105397744438 ∧ code e1105397744438 = 5503444255542 := by decide
theorem cert_e1105397744438 : check e1105397744438 [[]] .width = true := by decide
def e1105397744442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105397744442 : Closed e1105397744442 ∧ code e1105397744442 = 5503444255546 := by decide
theorem cert_e1105397744442 : check e1105397744442 [[]] .width = true := by decide
def e1105397744526 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105397744526 : Closed e1105397744526 ∧ code e1105397744526 = 5503444255630 := by decide
theorem cert_e1105397744526 : check e1105397744526 [[]] .width = true := by decide
def e1105397744538 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105397744538 : Closed e1105397744538 ∧ code e1105397744538 = 5503444255642 := by decide
theorem cert_e1105397744538 : check e1105397744538 [[]] .width = true := by decide
def e1105397746458 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105397746458 : Closed e1105397746458 ∧ code e1105397746458 = 5503444257562 := by decide
theorem cert_e1105397746458 : check e1105397746458 [[]] .width = true := by decide
def e1105397746502 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105397746502 : Closed e1105397746502 ∧ code e1105397746502 = 5503444257606 := by decide
theorem cert_e1105397746502 : check e1105397746502 [[]] .width = true := by decide
def e1105397746742 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105397746742 : Closed e1105397746742 ∧ code e1105397746742 = 5503444257846 := by decide
theorem cert_e1105397746742 : check e1105397746742 [[]] .width = true := by decide
def e1105397746746 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105397746746 : Closed e1105397746746 ∧ code e1105397746746 = 5503444257850 := by decide
theorem cert_e1105397746746 : check e1105397746746 [[]] .width = true := by decide
def e1105397746886 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105397746886 : Closed e1105397746886 ∧ code e1105397746886 = 5503444257990 := by decide
theorem cert_e1105397746886 : check e1105397746886 [[]] .width = true := by decide
def e1105398095898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105398095898 : Closed e1105398095898 ∧ code e1105398095898 = 5503444607002 := by decide
theorem cert_e1105398095898 : check e1105398095898 [[]] .width = true := by decide
def e1105398095990 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105398095990 : Closed e1105398095990 ∧ code e1105398095990 = 5503444607094 := by decide
theorem cert_e1105398095990 : check e1105398095990 [[]] .width = true := by decide
def e1105398096234 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105398096234 : Closed e1105398096234 ∧ code e1105398096234 = 5503444607338 := by decide
theorem cert_e1105398096234 : check e1105398096234 [[]] .width = true := by decide
def e1105398096282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105398096282 : Closed e1105398096282 ∧ code e1105398096282 = 5503444607386 := by decide
theorem cert_e1105398096282 : check e1105398096282 [[]] .width = true := by decide
def e1105398137030 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105398137030 : Closed e1105398137030 ∧ code e1105398137030 = 5503444648134 := by decide
theorem cert_e1105398137030 : check e1105398137030 [[]] .width = true := by decide
def e1105398137558 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105398137558 : Closed e1105398137558 ∧ code e1105398137558 = 5503444648662 := by decide
theorem cert_e1105398137558 : check e1105398137558 [[]] .width = true := by decide
def e1105398137562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105398137562 : Closed e1105398137562 ∧ code e1105398137562 = 5503444648666 := by decide
theorem cert_e1105398137562 : check e1105398137562 [[]] .width = true := by decide
def e1105398137578 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105398137578 : Closed e1105398137578 ∧ code e1105398137578 = 5503444648682 := by decide
theorem cert_e1105398137578 : check e1105398137578 [[]] .width = true := by decide
def e1105398137654 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105398137654 : Closed e1105398137654 ∧ code e1105398137654 = 5503444648758 := by decide
theorem cert_e1105398137654 : check e1105398137654 [[]] .width = true := by decide
def e1105398137658 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105398137658 : Closed e1105398137658 ∧ code e1105398137658 = 5503444648762 := by decide
theorem cert_e1105398137658 : check e1105398137658 [[]] .width = true := by decide
def e1105398137742 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105398137742 : Closed e1105398137742 ∧ code e1105398137742 = 5503444648846 := by decide
theorem cert_e1105398137742 : check e1105398137742 [[]] .width = true := by decide
def e1105398137754 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105398137754 : Closed e1105398137754 ∧ code e1105398137754 = 5503444648858 := by decide
theorem cert_e1105398137754 : check e1105398137754 [[]] .width = true := by decide
def e1105398139674 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105398139674 : Closed e1105398139674 ∧ code e1105398139674 = 5503444650778 := by decide
theorem cert_e1105398139674 : check e1105398139674 [[]] .width = true := by decide
def e1105398139718 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105398139718 : Closed e1105398139718 ∧ code e1105398139718 = 5503444650822 := by decide
theorem cert_e1105398139718 : check e1105398139718 [[]] .width = true := by decide
def e1105398139958 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105398139958 : Closed e1105398139958 ∧ code e1105398139958 = 5503444651062 := by decide
theorem cert_e1105398139958 : check e1105398139958 [[]] .width = true := by decide
def e1105398139962 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105398139962 : Closed e1105398139962 ∧ code e1105398139962 = 5503444651066 := by decide
theorem cert_e1105398139962 : check e1105398139962 [[]] .width = true := by decide
def e1105398140102 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105398140102 : Closed e1105398140102 ∧ code e1105398140102 = 5503444651206 := by decide
theorem cert_e1105398140102 : check e1105398140102 [[]] .width = true := by decide
def e1105398554650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105398554650 : Closed e1105398554650 ∧ code e1105398554650 = 5503445065754 := by decide
theorem cert_e1105398554650 : check e1105398554650 [[]] .width = true := by decide
def e1105398554742 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105398554742 : Closed e1105398554742 ∧ code e1105398554742 = 5503445065846 := by decide
private def t_e1105398554742 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1105398554742 : ¬ IsSelfInterpreter e1105398554742 :=
  wSource (t := t_e1105398554742) (replay_sound (ps := []) (t := e1105398554742) (by decide)) (by decide)
def e1105398554986 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105398554986 : Closed e1105398554986 ∧ code e1105398554986 = 5503445066090 := by decide
private def t_e1105398554986 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1105398554986 : ¬ IsSelfInterpreter e1105398554986 :=
  wSource (t := t_e1105398554986) (replay_sound (ps := []) (t := e1105398554986) (by decide)) (by decide)
def e1105398555034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105398555034 : Closed e1105398555034 ∧ code e1105398555034 = 5503445066138 := by decide
private def t_e1105398555034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1105398555034 : ¬ IsSelfInterpreter e1105398555034 :=
  wSource (t := t_e1105398555034) (replay_sound (ps := []) (t := e1105398555034) (by decide)) (by decide)
def e1105398571034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105398571034 : Closed e1105398571034 ∧ code e1105398571034 = 5503445082138 := by decide
theorem cert_e1105398571034 : check e1105398571034 [[]] .width = true := by decide
def e1105398571126 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105398571126 : Closed e1105398571126 ∧ code e1105398571126 = 5503445082230 := by decide
private def t_e1105398571126 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1105398571126 : ¬ IsSelfInterpreter e1105398571126 :=
  wSource (t := t_e1105398571126) (replay_sound (ps := []) (t := e1105398571126) (by decide)) (by decide)
def e1105398571370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105398571370 : Closed e1105398571370 ∧ code e1105398571370 = 5503445082474 := by decide
private def t_e1105398571370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1105398571370 : ¬ IsSelfInterpreter e1105398571370 :=
  wSource (t := t_e1105398571370) (replay_sound (ps := []) (t := e1105398571370) (by decide)) (by decide)
def e1105398571418 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105398571418 : Closed e1105398571418 ∧ code e1105398571418 = 5503445082522 := by decide
private def t_e1105398571418 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1105398571418 : ¬ IsSelfInterpreter e1105398571418 :=
  wSource (t := t_e1105398571418) (replay_sound (ps := []) (t := e1105398571418) (by decide)) (by decide)
def e1105398915098 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105398915098 : Closed e1105398915098 ∧ code e1105398915098 = 5503445426202 := by decide
theorem cert_e1105398915098 : check e1105398915098 [[]] .width = true := by decide
def e1105398915190 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105398915190 : Closed e1105398915190 ∧ code e1105398915190 = 5503445426294 := by decide
private def t_e1105398915190 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1105398915190 : ¬ IsSelfInterpreter e1105398915190 :=
  wSource (t := t_e1105398915190) (replay_sound (ps := []) (t := e1105398915190) (by decide)) (by decide)
def e1105398915434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105398915434 : Closed e1105398915434 ∧ code e1105398915434 = 5503445426538 := by decide
private def t_e1105398915434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1105398915434 : ¬ IsSelfInterpreter e1105398915434 :=
  wSource (t := t_e1105398915434) (replay_sound (ps := []) (t := e1105398915434) (by decide)) (by decide)
def e1105398915482 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105398915482 : Closed e1105398915482 ∧ code e1105398915482 = 5503445426586 := by decide
private def t_e1105398915482 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1105398915482 : ¬ IsSelfInterpreter e1105398915482 :=
  wSource (t := t_e1105398915482) (replay_sound (ps := []) (t := e1105398915482) (by decide)) (by decide)
def e1105399054534 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105399054534 : Closed e1105399054534 ∧ code e1105399054534 = 5503445565638 := by decide
theorem cert_e1105399054534 : check e1105399054534 [[]] .width = true := by decide
def e1105399055062 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105399055062 : Closed e1105399055062 ∧ code e1105399055062 = 5503445566166 := by decide
theorem cert_e1105399055062 : check e1105399055062 [[]] .width = true := by decide
def e1105399055066 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105399055066 : Closed e1105399055066 ∧ code e1105399055066 = 5503445566170 := by decide
theorem cert_e1105399055066 : check e1105399055066 [[]] .width = true := by decide
def e1105399055082 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105399055082 : Closed e1105399055082 ∧ code e1105399055082 = 5503445566186 := by decide
theorem cert_e1105399055082 : check e1105399055082 [[]] .width = true := by decide
def e1105399055158 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105399055158 : Closed e1105399055158 ∧ code e1105399055158 = 5503445566262 := by decide
theorem cert_e1105399055158 : check e1105399055158 [[]] .width = true := by decide
def e1105399055162 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105399055162 : Closed e1105399055162 ∧ code e1105399055162 = 5503445566266 := by decide
theorem cert_e1105399055162 : check e1105399055162 [[]] .width = true := by decide
def e1105399055246 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105399055246 : Closed e1105399055246 ∧ code e1105399055246 = 5503445566350 := by decide
theorem cert_e1105399055246 : check e1105399055246 [[]] .width = true := by decide
def e1105399055258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105399055258 : Closed e1105399055258 ∧ code e1105399055258 = 5503445566362 := by decide
theorem cert_e1105399055258 : check e1105399055258 [[]] .width = true := by decide
def e1105399057178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105399057178 : Closed e1105399057178 ∧ code e1105399057178 = 5503445568282 := by decide
theorem cert_e1105399057178 : check e1105399057178 [[]] .width = true := by decide
def e1105399057222 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105399057222 : Closed e1105399057222 ∧ code e1105399057222 = 5503445568326 := by decide
private def t_e1105399057222 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e1105399057222 : ¬ IsSelfInterpreter e1105399057222 :=
  wSource (t := t_e1105399057222) (replay_sound (ps := []) (t := e1105399057222) (by decide)) (by decide)
def e1105399057462 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105399057462 : Closed e1105399057462 ∧ code e1105399057462 = 5503445568566 := by decide
private def t_e1105399057462 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e1105399057462 : ¬ IsSelfInterpreter e1105399057462 :=
  wSource (t := t_e1105399057462) (replay_sound (ps := []) (t := e1105399057462) (by decide)) (by decide)
def e1105399057466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105399057466 : Closed e1105399057466 ∧ code e1105399057466 = 5503445568570 := by decide
private def t_e1105399057466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e1105399057466 : ¬ IsSelfInterpreter e1105399057466 :=
  wSource (t := t_e1105399057466) (replay_sound (ps := []) (t := e1105399057466) (by decide)) (by decide)
def e1105399057606 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105399057606 : Closed e1105399057606 ∧ code e1105399057606 = 5503445568710 := by decide
theorem cert_e1105399057606 : check e1105399057606 [[]] .width = true := by decide
def e1105399144474 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105399144474 : Closed e1105399144474 ∧ code e1105399144474 = 5503445655578 := by decide
theorem cert_e1105399144474 : check e1105399144474 [[]] .width = true := by decide
def e1105399144566 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105399144566 : Closed e1105399144566 ∧ code e1105399144566 = 5503445655670 := by decide
private def t_e1105399144566 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1105399144566 : ¬ IsSelfInterpreter e1105399144566 :=
  wSource (t := t_e1105399144566) (replay_sound (ps := []) (t := e1105399144566) (by decide)) (by decide)
def e1105399144810 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105399144810 : Closed e1105399144810 ∧ code e1105399144810 = 5503445655914 := by decide
private def t_e1105399144810 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1105399144810 : ¬ IsSelfInterpreter e1105399144810 :=
  wSource (t := t_e1105399144810) (replay_sound (ps := []) (t := e1105399144810) (by decide)) (by decide)
def e1105399144858 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105399144858 : Closed e1105399144858 ∧ code e1105399144858 = 5503445655962 := by decide
private def t_e1105399144858 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1105399144858 : ¬ IsSelfInterpreter e1105399144858 :=
  wSource (t := t_e1105399144858) (replay_sound (ps := []) (t := e1105399144858) (by decide)) (by decide)
def e1105399185606 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105399185606 : Closed e1105399185606 ∧ code e1105399185606 = 5503445696710 := by decide
theorem cert_e1105399185606 : check e1105399185606 [[]] .width = true := by decide
def e1105399186134 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105399186134 : Closed e1105399186134 ∧ code e1105399186134 = 5503445697238 := by decide
theorem cert_e1105399186134 : check e1105399186134 [[]] .width = true := by decide
def e1105399186138 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105399186138 : Closed e1105399186138 ∧ code e1105399186138 = 5503445697242 := by decide
theorem cert_e1105399186138 : check e1105399186138 [[]] .width = true := by decide
def e1105399186154 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105399186154 : Closed e1105399186154 ∧ code e1105399186154 = 5503445697258 := by decide
theorem cert_e1105399186154 : check e1105399186154 [[]] .width = true := by decide
def e1105399186230 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105399186230 : Closed e1105399186230 ∧ code e1105399186230 = 5503445697334 := by decide
theorem cert_e1105399186230 : check e1105399186230 [[]] .width = true := by decide
def e1105399186234 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105399186234 : Closed e1105399186234 ∧ code e1105399186234 = 5503445697338 := by decide
theorem cert_e1105399186234 : check e1105399186234 [[]] .width = true := by decide
def e1105399186318 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105399186318 : Closed e1105399186318 ∧ code e1105399186318 = 5503445697422 := by decide
theorem cert_e1105399186318 : check e1105399186318 [[]] .width = true := by decide
def e1105399186330 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105399186330 : Closed e1105399186330 ∧ code e1105399186330 = 5503445697434 := by decide
theorem cert_e1105399186330 : check e1105399186330 [[]] .width = true := by decide
def e1105399188250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105399188250 : Closed e1105399188250 ∧ code e1105399188250 = 5503445699354 := by decide
theorem cert_e1105399188250 : check e1105399188250 [[]] .width = true := by decide
def e1105399188294 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105399188294 : Closed e1105399188294 ∧ code e1105399188294 = 5503445699398 := by decide
private def t_e1105399188294 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e1105399188294 : ¬ IsSelfInterpreter e1105399188294 :=
  wSource (t := t_e1105399188294) (replay_sound (ps := []) (t := e1105399188294) (by decide)) (by decide)
def e1105399188534 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105399188534 : Closed e1105399188534 ∧ code e1105399188534 = 5503445699638 := by decide
private def t_e1105399188534 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e1105399188534 : ¬ IsSelfInterpreter e1105399188534 :=
  wSource (t := t_e1105399188534) (replay_sound (ps := []) (t := e1105399188534) (by decide)) (by decide)
def e1105399188538 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105399188538 : Closed e1105399188538 ∧ code e1105399188538 = 5503445699642 := by decide
private def t_e1105399188538 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e1105399188538 : ¬ IsSelfInterpreter e1105399188538 :=
  wSource (t := t_e1105399188538) (replay_sound (ps := []) (t := e1105399188538) (by decide)) (by decide)
def e1105399188678 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105399188678 : Closed e1105399188678 ∧ code e1105399188678 = 5503445699782 := by decide
theorem cert_e1105399188678 : check e1105399188678 [[]] .width = true := by decide
def e1105477951514 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105477951514 : Closed e1105477951514 ∧ code e1105477951514 = 5503524462618 := by decide
theorem cert_e1105477951514 : check e1105477951514 [[]] .width = true := by decide
def e1105477951606 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105477951606 : Closed e1105477951606 ∧ code e1105477951606 = 5503524462710 := by decide
theorem cert_e1105477951606 : check e1105477951606 [[]] .width = true := by decide
def e1105477951850 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105477951850 : Closed e1105477951850 ∧ code e1105477951850 = 5503524462954 := by decide
theorem cert_e1105477951850 : check e1105477951850 [[]] .width = true := by decide
def e1105477951898 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105477951898 : Closed e1105477951898 ∧ code e1105477951898 = 5503524463002 := by decide
theorem cert_e1105477951898 : check e1105477951898 [[]] .width = true := by decide
def e1105542447302 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105542447302 : Closed e1105542447302 ∧ code e1105542447302 = 5503588958406 := by decide
theorem cert_e1105542447302 : check e1105542447302 [[]] .width = true := by decide
def e1105542447830 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105542447830 : Closed e1105542447830 ∧ code e1105542447830 = 5503588958934 := by decide
theorem cert_e1105542447830 : check e1105542447830 [[]] .width = true := by decide
def e1105542447834 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105542447834 : Closed e1105542447834 ∧ code e1105542447834 = 5503588958938 := by decide
theorem cert_e1105542447834 : check e1105542447834 [[]] .width = true := by decide
def e1105542447850 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105542447850 : Closed e1105542447850 ∧ code e1105542447850 = 5503588958954 := by decide
theorem cert_e1105542447850 : check e1105542447850 [[]] .width = true := by decide
def e1105542447926 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105542447926 : Closed e1105542447926 ∧ code e1105542447926 = 5503588959030 := by decide
theorem cert_e1105542447926 : check e1105542447926 [[]] .width = true := by decide
def e1105542447930 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105542447930 : Closed e1105542447930 ∧ code e1105542447930 = 5503588959034 := by decide
theorem cert_e1105542447930 : check e1105542447930 [[]] .width = true := by decide
def e1105542448014 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105542448014 : Closed e1105542448014 ∧ code e1105542448014 = 5503588959118 := by decide
theorem cert_e1105542448014 : check e1105542448014 [[]] .width = true := by decide
def e1105542448026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105542448026 : Closed e1105542448026 ∧ code e1105542448026 = 5503588959130 := by decide
theorem cert_e1105542448026 : check e1105542448026 [[]] .width = true := by decide
def e1105542449946 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105542449946 : Closed e1105542449946 ∧ code e1105542449946 = 5503588961050 := by decide
theorem cert_e1105542449946 : check e1105542449946 [[]] .width = true := by decide
def e1105542449990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105542449990 : Closed e1105542449990 ∧ code e1105542449990 = 5503588961094 := by decide
theorem cert_e1105542449990 : check e1105542449990 [[]] .width = true := by decide
def e1105542450230 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105542450230 : Closed e1105542450230 ∧ code e1105542450230 = 5503588961334 := by decide
theorem cert_e1105542450230 : check e1105542450230 [[]] .width = true := by decide
def e1105542450234 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105542450234 : Closed e1105542450234 ∧ code e1105542450234 = 5503588961338 := by decide
theorem cert_e1105542450234 : check e1105542450234 [[]] .width = true := by decide
end Blc.Floor42
