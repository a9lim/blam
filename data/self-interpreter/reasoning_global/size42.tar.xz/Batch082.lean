import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196710453102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e1196710453102 : Closed e1196710453102 ∧ code e1196710453102 = 5594756964206 := by decide
theorem cert_e1196710453102 : check e1196710453102 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196710453110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e1196710453110 : Closed e1196710453110 ∧ code e1196710453110 = 5594756964214 := by decide
private def t_e1196710453110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem cert_e1196710453110 : ¬ IsSelfInterpreter e1196710453110 :=
  wSource (t := t_e1196710453110) (replay_sound (ps := []) (t := e1196710453110) (by decide)) (by decide)
def e1196710458334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e1196710458334 : Closed e1196710458334 ∧ code e1196710458334 = 5594756969438 := by decide
theorem cert_e1196710458334 : check e1196710458334 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1196710458350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e1196710458350 : Closed e1196710458350 ∧ code e1196710458350 = 5594756969454 := by decide
theorem cert_e1196710458350 : check e1196710458350 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1196710459870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196710459870 : Closed e1196710459870 ∧ code e1196710459870 = 5594756970974 := by decide
theorem cert_e1196710459870 : check e1196710459870 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e1196710459894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196710459894 : Closed e1196710459894 ∧ code e1196710459894 = 5594756970998 := by decide
theorem cert_e1196710459894 : check e1196710459894 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e1196710460654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196710460654 : Closed e1196710460654 ∧ code e1196710460654 = 5594756971758 := by decide
theorem cert_e1196710460654 : check e1196710460654 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1196710460662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196710460662 : Closed e1196710460662 ∧ code e1196710460662 = 5594756971766 := by decide
theorem cert_e1196710460662 : check e1196710460662 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e1196710517614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1196710517614 : Closed e1196710517614 ∧ code e1196710517614 = 5594757028718 := by decide
def e1196710517622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1196710517622 : Closed e1196710517622 ∧ code e1196710517622 = 5594757028726 := by decide
def e1196710517686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1196710517686 : Closed e1196710517686 ∧ code e1196710517686 = 5594757028790 := by decide
def e1196710518126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1196710518126 : Closed e1196710518126 ∧ code e1196710518126 = 5594757029230 := by decide
def e1196710518134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1196710518134 : Closed e1196710518134 ∧ code e1196710518134 = 5594757029238 := by decide
def e1196710518190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1196710518190 : Closed e1196710518190 ∧ code e1196710518190 = 5594757029294 := by decide
private def t_e1196710518190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e1196710518190 : ¬ IsSelfInterpreter e1196710518190 :=
  wSource (t := t_e1196710518190) (replay_sound (ps := []) (t := e1196710518190) (by decide)) (by decide)
def e1196710518202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1196710518202 : Closed e1196710518202 ∧ code e1196710518202 = 5594757029306 := by decide
private def t_e1196710518202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e1196710518202 : ¬ IsSelfInterpreter e1196710518202 :=
  wSource (t := t_e1196710518202) (replay_sound (ps := []) (t := e1196710518202) (by decide)) (by decide)
def e1196710518230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1196710518230 : Closed e1196710518230 ∧ code e1196710518230 = 5594757029334 := by decide
private def t_e1196710518230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e1196710518230 : ¬ IsSelfInterpreter e1196710518230 :=
  wSource (t := t_e1196710518230) (replay_sound (ps := []) (t := e1196710518230) (by decide)) (by decide)
def e1196710518234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1196710518234 : Closed e1196710518234 ∧ code e1196710518234 = 5594757029338 := by decide
private def t_e1196710518234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e1196710518234 : ¬ IsSelfInterpreter e1196710518234 :=
  wSource (t := t_e1196710518234) (replay_sound (ps := []) (t := e1196710518234) (by decide)) (by decide)
def e1196710518454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1196710518454 : Closed e1196710518454 ∧ code e1196710518454 = 5594757029558 := by decide
def e1196710518486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1196710518486 : Closed e1196710518486 ∧ code e1196710518486 = 5594757029590 := by decide
private def t_e1196710518486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem cert_e1196710518486 : ¬ IsSelfInterpreter e1196710518486 :=
  wSource (t := t_e1196710518486) (replay_sound (ps := []) (t := e1196710518486) (by decide)) (by decide)
def e1196710518490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1196710518490 : Closed e1196710518490 ∧ code e1196710518490 = 5594757029594 := by decide
private def t_e1196710518490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem cert_e1196710518490 : ¬ IsSelfInterpreter e1196710518490 :=
  wSource (t := t_e1196710518490) (replay_sound (ps := []) (t := e1196710518490) (by decide)) (by decide)
def e1196710520686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1196710520686 : Closed e1196710520686 ∧ code e1196710520686 = 5594757031790 := by decide
def e1196710520694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1196710520694 : Closed e1196710520694 ∧ code e1196710520694 = 5594757031798 := by decide
def e1196710520758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1196710520758 : Closed e1196710520758 ∧ code e1196710520758 = 5594757031862 := by decide
def e1196710522094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196710522094 : Closed e1196710522094 ∧ code e1196710522094 = 5594757033198 := by decide
def e1196710522102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196710522102 : Closed e1196710522102 ∧ code e1196710522102 = 5594757033206 := by decide
def e1196710522486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196710522486 : Closed e1196710522486 ∧ code e1196710522486 = 5594757033590 := by decide
def e1196710523758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1196710523758 : Closed e1196710523758 ∧ code e1196710523758 = 5594757034862 := by decide
def e1196710523766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1196710523766 : Closed e1196710523766 ∧ code e1196710523766 = 5594757034870 := by decide
def e1196710523822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1196710523822 : Closed e1196710523822 ∧ code e1196710523822 = 5594757034926 := by decide
def e1196710523834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1196710523834 : Closed e1196710523834 ∧ code e1196710523834 = 5594757034938 := by decide
private def t_e1196710523834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e1196710523834 : ¬ IsSelfInterpreter e1196710523834 :=
  wSource (t := t_e1196710523834) (replay_sound (ps := []) (t := e1196710523834) (by decide)) (by decide)
def e1196710523862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1196710523862 : Closed e1196710523862 ∧ code e1196710523862 = 5594757034966 := by decide
def e1196710523866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1196710523866 : Closed e1196710523866 ∧ code e1196710523866 = 5594757034970 := by decide
private def t_e1196710523866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e1196710523866 : ¬ IsSelfInterpreter e1196710523866 :=
  wSource (t := t_e1196710523866) (replay_sound (ps := []) (t := e1196710523866) (by decide)) (by decide)
def e1196710524142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1196710524142 : Closed e1196710524142 ∧ code e1196710524142 = 5594757035246 := by decide
def e1196710524150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1196710524150 : Closed e1196710524150 ∧ code e1196710524150 = 5594757035254 := by decide
def e1196710524526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1196710524526 : Closed e1196710524526 ∧ code e1196710524526 = 5594757035630 := by decide
private def t_e1196710524526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e1196710524526 : ¬ IsSelfInterpreter e1196710524526 :=
  wSource (t := t_e1196710524526) (replay_sound (ps := []) (t := e1196710524526) (by decide)) (by decide)
def e1196710524538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1196710524538 : Closed e1196710524538 ∧ code e1196710524538 = 5594757035642 := by decide
private def t_e1196710524538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e1196710524538 : ¬ IsSelfInterpreter e1196710524538 :=
  wSource (t := t_e1196710524538) (replay_sound (ps := []) (t := e1196710524538) (by decide)) (by decide)
def e1196710524726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196710524726 : Closed e1196710524726 ∧ code e1196710524726 = 5594757035830 := by decide
private def t_e1196710524726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e1196710524726 : ¬ IsSelfInterpreter e1196710524726 :=
  wSource (t := t_e1196710524726) (replay_sound (ps := []) (t := e1196710524726) (by decide)) (by decide)
def e1196710524730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196710524730 : Closed e1196710524730 ∧ code e1196710524730 = 5594757035834 := by decide
private def t_e1196710524730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e1196710524730 : ¬ IsSelfInterpreter e1196710524730 :=
  wSource (t := t_e1196710524730) (replay_sound (ps := []) (t := e1196710524730) (by decide)) (by decide)
def e1196710525366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1196710525366 : Closed e1196710525366 ∧ code e1196710525366 = 5594757036470 := by decide
def e1196710525398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1196710525398 : Closed e1196710525398 ∧ code e1196710525398 = 5594757036502 := by decide
def e1196710525402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1196710525402 : Closed e1196710525402 ∧ code e1196710525402 = 5594757036506 := by decide
private def t_e1196710525402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem cert_e1196710525402 : ¬ IsSelfInterpreter e1196710525402 :=
  wSource (t := t_e1196710525402) (replay_sound (ps := []) (t := e1196710525402) (by decide)) (by decide)
def e1196710525558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1196710525558 : Closed e1196710525558 ∧ code e1196710525558 = 5594757036662 := by decide
def e1196710525750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1196710525750 : Closed e1196710525750 ∧ code e1196710525750 = 5594757036854 := by decide
private def t_e1196710525750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem cert_e1196710525750 : ¬ IsSelfInterpreter e1196710525750 :=
  wSource (t := t_e1196710525750) (replay_sound (ps := []) (t := e1196710525750) (by decide)) (by decide)
def e1196710525754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1196710525754 : Closed e1196710525754 ∧ code e1196710525754 = 5594757036858 := by decide
private def t_e1196710525754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem cert_e1196710525754 : ¬ IsSelfInterpreter e1196710525754 :=
  wSource (t := t_e1196710525754) (replay_sound (ps := []) (t := e1196710525754) (by decide)) (by decide)
def e1196710532974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1196710532974 : Closed e1196710532974 ∧ code e1196710532974 = 5594757044078 := by decide
def e1196710532982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1196710532982 : Closed e1196710532982 ∧ code e1196710532982 = 5594757044086 := by decide
theorem cert_e1196710532982 : check e1196710532982 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e1196710533046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1196710533046 : Closed e1196710533046 ∧ code e1196710533046 = 5594757044150 := by decide
def e1196710534382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196710534382 : Closed e1196710534382 ∧ code e1196710534382 = 5594757045486 := by decide
theorem cert_e1196710534382 : check e1196710534382 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e1196710534390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196710534390 : Closed e1196710534390 ∧ code e1196710534390 = 5594757045494 := by decide
theorem cert_e1196710534390 : check e1196710534390 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e1196710534774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196710534774 : Closed e1196710534774 ∧ code e1196710534774 = 5594757045878 := by decide
def e1196710546286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196710546286 : Closed e1196710546286 ∧ code e1196710546286 = 5594757057390 := by decide
def e1196710546294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196710546294 : Closed e1196710546294 ∧ code e1196710546294 = 5594757057398 := by decide
def e1196710546350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196710546350 : Closed e1196710546350 ∧ code e1196710546350 = 5594757057454 := by decide
def e1196710546362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196710546362 : Closed e1196710546362 ∧ code e1196710546362 = 5594757057466 := by decide
private def t_e1196710546362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1196710546362 : ¬ IsSelfInterpreter e1196710546362 :=
  wSource (t := t_e1196710546362) (replay_sound (ps := []) (t := e1196710546362) (by decide)) (by decide)
def e1196710546390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196710546390 : Closed e1196710546390 ∧ code e1196710546390 = 5594757057494 := by decide
def e1196710546394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196710546394 : Closed e1196710546394 ∧ code e1196710546394 = 5594757057498 := by decide
private def t_e1196710546394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1196710546394 : ¬ IsSelfInterpreter e1196710546394 :=
  wSource (t := t_e1196710546394) (replay_sound (ps := []) (t := e1196710546394) (by decide)) (by decide)
def e1196710546670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196710546670 : Closed e1196710546670 ∧ code e1196710546670 = 5594757057774 := by decide
def e1196710546678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196710546678 : Closed e1196710546678 ∧ code e1196710546678 = 5594757057782 := by decide
def e1196710547054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196710547054 : Closed e1196710547054 ∧ code e1196710547054 = 5594757058158 := by decide
def e1196710547066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196710547066 : Closed e1196710547066 ∧ code e1196710547066 = 5594757058170 := by decide
def e1196710547254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196710547254 : Closed e1196710547254 ∧ code e1196710547254 = 5594757058358 := by decide
def e1196710547258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196710547258 : Closed e1196710547258 ∧ code e1196710547258 = 5594757058362 := by decide
def e1196710553014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1196710553014 : Closed e1196710553014 ∧ code e1196710553014 = 5594757064118 := by decide
def e1196710553046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1196710553046 : Closed e1196710553046 ∧ code e1196710553046 = 5594757064150 := by decide
def e1196710553050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1196710553050 : Closed e1196710553050 ∧ code e1196710553050 = 5594757064154 := by decide
private def t_e1196710553050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem cert_e1196710553050 : ¬ IsSelfInterpreter e1196710553050 :=
  wSource (t := t_e1196710553050) (replay_sound (ps := []) (t := e1196710553050) (by decide)) (by decide)
def e1196710553206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196710553206 : Closed e1196710553206 ∧ code e1196710553206 = 5594757064310 := by decide
def e1196710553398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196710553398 : Closed e1196710553398 ∧ code e1196710553398 = 5594757064502 := by decide
def e1196710553402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196710553402 : Closed e1196710553402 ∧ code e1196710553402 = 5594757064506 := by decide
def e1196710890350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196710890350 : Closed e1196710890350 ∧ code e1196710890350 = 5594757401454 := by decide
private def t_e1196710890350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e1196710890350 : ¬ IsSelfInterpreter e1196710890350 :=
  wSource (t := t_e1196710890350) (replay_sound (ps := []) (t := e1196710890350) (by decide)) (by decide)
def e1196710890358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196710890358 : Closed e1196710890358 ∧ code e1196710890358 = 5594757401462 := by decide
private def t_e1196710890358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e1196710890358 : ¬ IsSelfInterpreter e1196710890358 :=
  wSource (t := t_e1196710890358) (replay_sound (ps := []) (t := e1196710890358) (by decide)) (by decide)
def e1196710890414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196710890414 : Closed e1196710890414 ∧ code e1196710890414 = 5594757401518 := by decide
private def t_e1196710890414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e1196710890414 : ¬ IsSelfInterpreter e1196710890414 :=
  wSource (t := t_e1196710890414) (replay_sound (ps := []) (t := e1196710890414) (by decide)) (by decide)
def e1196710890426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196710890426 : Closed e1196710890426 ∧ code e1196710890426 = 5594757401530 := by decide
private def t_e1196710890426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e1196710890426 : ¬ IsSelfInterpreter e1196710890426 :=
  wSource (t := t_e1196710890426) (replay_sound (ps := []) (t := e1196710890426) (by decide)) (by decide)
def e1196710890454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196710890454 : Closed e1196710890454 ∧ code e1196710890454 = 5594757401558 := by decide
private def t_e1196710890454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e1196710890454 : ¬ IsSelfInterpreter e1196710890454 :=
  wSource (t := t_e1196710890454) (replay_sound (ps := []) (t := e1196710890454) (by decide)) (by decide)
def e1196710890458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196710890458 : Closed e1196710890458 ∧ code e1196710890458 = 5594757401562 := by decide
private def t_e1196710890458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e1196710890458 : ¬ IsSelfInterpreter e1196710890458 :=
  wSource (t := t_e1196710890458) (replay_sound (ps := []) (t := e1196710890458) (by decide)) (by decide)
def e1196710890734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196710890734 : Closed e1196710890734 ∧ code e1196710890734 = 5594757401838 := by decide
private def t_e1196710890734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e1196710890734 : ¬ IsSelfInterpreter e1196710890734 :=
  wSource (t := t_e1196710890734) (replay_sound (ps := []) (t := e1196710890734) (by decide)) (by decide)
def e1196710890742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196710890742 : Closed e1196710890742 ∧ code e1196710890742 = 5594757401846 := by decide
private def t_e1196710890742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e1196710890742 : ¬ IsSelfInterpreter e1196710890742 :=
  wSource (t := t_e1196710890742) (replay_sound (ps := []) (t := e1196710890742) (by decide)) (by decide)
def e1196710891118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196710891118 : Closed e1196710891118 ∧ code e1196710891118 = 5594757402222 := by decide
private def t_e1196710891118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e1196710891118 : ¬ IsSelfInterpreter e1196710891118 :=
  wSource (t := t_e1196710891118) (replay_sound (ps := []) (t := e1196710891118) (by decide)) (by decide)
def e1196710891130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196710891130 : Closed e1196710891130 ∧ code e1196710891130 = 5594757402234 := by decide
private def t_e1196710891130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e1196710891130 : ¬ IsSelfInterpreter e1196710891130 :=
  wSource (t := t_e1196710891130) (replay_sound (ps := []) (t := e1196710891130) (by decide)) (by decide)
def e1196710891318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196710891318 : Closed e1196710891318 ∧ code e1196710891318 = 5594757402422 := by decide
private def t_e1196710891318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e1196710891318 : ¬ IsSelfInterpreter e1196710891318 :=
  wSource (t := t_e1196710891318) (replay_sound (ps := []) (t := e1196710891318) (by decide)) (by decide)
def e1196710891322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196710891322 : Closed e1196710891322 ∧ code e1196710891322 = 5594757402426 := by decide
private def t_e1196710891322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e1196710891322 : ¬ IsSelfInterpreter e1196710891322 :=
  wSource (t := t_e1196710891322) (replay_sound (ps := []) (t := e1196710891322) (by decide)) (by decide)
def e1202684096710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202684096710 : Closed e1202684096710 ∧ code e1202684096710 = 5600730607814 := by decide
theorem cert_e1202684096710 : check e1202684096710 [[]] .width = true := by decide
def e1202686754842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202686754842 : Closed e1202686754842 ∧ code e1202686754842 = 5600733265946 := by decide
theorem cert_e1202686754842 : check e1202686754842 [[]] .width = true := by decide
def e1202686754934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202686754934 : Closed e1202686754934 ∧ code e1202686754934 = 5600733266038 := by decide
theorem cert_e1202686754934 : check e1202686754934 [[]] .width = true := by decide
def e1202686755178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202686755178 : Closed e1202686755178 ∧ code e1202686755178 = 5600733266282 := by decide
theorem cert_e1202686755178 : check e1202686755178 [[]] .width = true := by decide
def e1202686755226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202686755226 : Closed e1202686755226 ∧ code e1202686755226 = 5600733266330 := by decide
theorem cert_e1202686755226 : check e1202686755226 [[]] .width = true := by decide
def e1202686756234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202686756234 : Closed e1202686756234 ∧ code e1202686756234 = 5600733267338 := by decide
theorem cert_e1202686756234 : check e1202686756234 [[]] .width = true := by decide
def e1202686756258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202686756258 : Closed e1202686756258 ∧ code e1202686756258 = 5600733267362 := by decide
theorem cert_e1202686756258 : check e1202686756258 [[]] .width = true := by decide
def e1202686756366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202686756366 : Closed e1202686756366 ∧ code e1202686756366 = 5600733267470 := by decide
theorem cert_e1202686756366 : check e1202686756366 [[]] .width = true := by decide
def e1202686756378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202686756378 : Closed e1202686756378 ∧ code e1202686756378 = 5600733267482 := by decide
theorem cert_e1202686756378 : check e1202686756378 [[]] .width = true := by decide
def e1202686756450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202686756450 : Closed e1202686756450 ∧ code e1202686756450 = 5600733267554 := by decide
theorem cert_e1202686756450 : check e1202686756450 [[]] .width = true := by decide
def e1202687033542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202687033542 : Closed e1202687033542 ∧ code e1202687033542 = 5600733544646 := by decide
theorem cert_e1202687033542 : check e1202687033542 [[]] .width = true := by decide
def e1202687078598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202687078598 : Closed e1202687078598 ∧ code e1202687078598 = 5600733589702 := by decide
theorem cert_e1202687078598 : check e1202687078598 [[]] .width = true := by decide
def e1202687148058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202687148058 : Closed e1202687148058 ∧ code e1202687148058 = 5600733659162 := by decide
theorem cert_e1202687148058 : check e1202687148058 [[]] .width = true := by decide
def e1202687148150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202687148150 : Closed e1202687148150 ∧ code e1202687148150 = 5600733659254 := by decide
theorem cert_e1202687148150 : check e1202687148150 [[]] .width = true := by decide
def e1202687148394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202687148394 : Closed e1202687148394 ∧ code e1202687148394 = 5600733659498 := by decide
theorem cert_e1202687148394 : check e1202687148394 [[]] .width = true := by decide
def e1202687148442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202687148442 : Closed e1202687148442 ∧ code e1202687148442 = 5600733659546 := by decide
theorem cert_e1202687148442 : check e1202687148442 [[]] .width = true := by decide
def e1202687149450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202687149450 : Closed e1202687149450 ∧ code e1202687149450 = 5600733660554 := by decide
theorem cert_e1202687149450 : check e1202687149450 [[]] .width = true := by decide
def e1202687149474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202687149474 : Closed e1202687149474 ∧ code e1202687149474 = 5600733660578 := by decide
theorem cert_e1202687149474 : check e1202687149474 [[]] .width = true := by decide
def e1202687149582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202687149582 : Closed e1202687149582 ∧ code e1202687149582 = 5600733660686 := by decide
theorem cert_e1202687149582 : check e1202687149582 [[]] .width = true := by decide
def e1202687149594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202687149594 : Closed e1202687149594 ∧ code e1202687149594 = 5600733660698 := by decide
theorem cert_e1202687149594 : check e1202687149594 [[]] .width = true := by decide
def e1202687149666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202687149666 : Closed e1202687149666 ∧ code e1202687149666 = 5600733660770 := by decide
theorem cert_e1202687149666 : check e1202687149666 [[]] .width = true := by decide
def e1202687164614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202687164614 : Closed e1202687164614 ∧ code e1202687164614 = 5600733675718 := by decide
theorem cert_e1202687164614 : check e1202687164614 [[]] .width = true := by decide
def e1202687766726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202687766726 : Closed e1202687766726 ∧ code e1202687766726 = 5600734277830 := by decide
theorem cert_e1202687766726 : check e1202687766726 [[]] .width = true := by decide
def e1202688851994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202688851994 : Closed e1202688851994 ∧ code e1202688851994 = 5600735363098 := by decide
theorem cert_e1202688851994 : check e1202688851994 [[]] .width = true := by decide
def e1202688852086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202688852086 : Closed e1202688852086 ∧ code e1202688852086 = 5600735363190 := by decide
theorem cert_e1202688852086 : check e1202688852086 [[]] .width = true := by decide
def e1202688852330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202688852330 : Closed e1202688852330 ∧ code e1202688852330 = 5600735363434 := by decide
theorem cert_e1202688852330 : check e1202688852330 [[]] .width = true := by decide
def e1202688852378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202688852378 : Closed e1202688852378 ∧ code e1202688852378 = 5600735363482 := by decide
theorem cert_e1202688852378 : check e1202688852378 [[]] .width = true := by decide
def e1202688853386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202688853386 : Closed e1202688853386 ∧ code e1202688853386 = 5600735364490 := by decide
theorem cert_e1202688853386 : check e1202688853386 [[]] .width = true := by decide
def e1202688853410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202688853410 : Closed e1202688853410 ∧ code e1202688853410 = 5600735364514 := by decide
theorem cert_e1202688853410 : check e1202688853410 [[]] .width = true := by decide
def e1202688853518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202688853518 : Closed e1202688853518 ∧ code e1202688853518 = 5600735364622 := by decide
theorem cert_e1202688853518 : check e1202688853518 [[]] .width = true := by decide
def e1202688853530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202688853530 : Closed e1202688853530 ∧ code e1202688853530 = 5600735364634 := by decide
theorem cert_e1202688853530 : check e1202688853530 [[]] .width = true := by decide
def e1202688853602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202688853602 : Closed e1202688853602 ∧ code e1202688853602 = 5600735364706 := by decide
theorem cert_e1202688853602 : check e1202688853602 [[]] .width = true := by decide
def e1202689269786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202689269786 : Closed e1202689269786 ∧ code e1202689269786 = 5600735780890 := by decide
theorem cert_e1202689269786 : check e1202689269786 [[]] .width = true := by decide
def e1202689269878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202689269878 : Closed e1202689269878 ∧ code e1202689269878 = 5600735780982 := by decide
theorem cert_e1202689269878 : check e1202689269878 [[]] .width = true := by decide
def e1202689270122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202689270122 : Closed e1202689270122 ∧ code e1202689270122 = 5600735781226 := by decide
theorem cert_e1202689270122 : check e1202689270122 [[]] .width = true := by decide
def e1202689270170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202689270170 : Closed e1202689270170 ∧ code e1202689270170 = 5600735781274 := by decide
theorem cert_e1202689270170 : check e1202689270170 [[]] .width = true := by decide
def e1202689290438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202689290438 : Closed e1202689290438 ∧ code e1202689290438 = 5600735801542 := by decide
theorem cert_e1202689290438 : check e1202689290438 [[]] .width = true := by decide
def e1202689310746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202689310746 : Closed e1202689310746 ∧ code e1202689310746 = 5600735821850 := by decide
theorem cert_e1202689310746 : check e1202689310746 [[]] .width = true := by decide
def e1202689310838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202689310838 : Closed e1202689310838 ∧ code e1202689310838 = 5600735821942 := by decide
theorem cert_e1202689310838 : check e1202689310838 [[]] .width = true := by decide
def e1202689311082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202689311082 : Closed e1202689311082 ∧ code e1202689311082 = 5600735822186 := by decide
theorem cert_e1202689311082 : check e1202689311082 [[]] .width = true := by decide
def e1202689311130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202689311130 : Closed e1202689311130 ∧ code e1202689311130 = 5600735822234 := by decide
theorem cert_e1202689311130 : check e1202689311130 [[]] .width = true := by decide
def e1202689312138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202689312138 : Closed e1202689312138 ∧ code e1202689312138 = 5600735823242 := by decide
theorem cert_e1202689312138 : check e1202689312138 [[]] .width = true := by decide
def e1202689312162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202689312162 : Closed e1202689312162 ∧ code e1202689312162 = 5600735823266 := by decide
theorem cert_e1202689312162 : check e1202689312162 [[]] .width = true := by decide
def e1202689312270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202689312270 : Closed e1202689312270 ∧ code e1202689312270 = 5600735823374 := by decide
theorem cert_e1202689312270 : check e1202689312270 [[]] .width = true := by decide
def e1202689312282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202689312282 : Closed e1202689312282 ∧ code e1202689312282 = 5600735823386 := by decide
theorem cert_e1202689312282 : check e1202689312282 [[]] .width = true := by decide
def e1202689312354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202689312354 : Closed e1202689312354 ∧ code e1202689312354 = 5600735823458 := by decide
theorem cert_e1202689312354 : check e1202689312354 [[]] .width = true := by decide
def e1202689335322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202689335322 : Closed e1202689335322 ∧ code e1202689335322 = 5600735846426 := by decide
theorem cert_e1202689335322 : check e1202689335322 [[]] .width = true := by decide
def e1202689335414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202689335414 : Closed e1202689335414 ∧ code e1202689335414 = 5600735846518 := by decide
theorem cert_e1202689335414 : check e1202689335414 [[]] .width = true := by decide
def e1202689335658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202689335658 : Closed e1202689335658 ∧ code e1202689335658 = 5600735846762 := by decide
theorem cert_e1202689335658 : check e1202689335658 [[]] .width = true := by decide
def e1202689335706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202689335706 : Closed e1202689335706 ∧ code e1202689335706 = 5600735846810 := by decide
theorem cert_e1202689335706 : check e1202689335706 [[]] .width = true := by decide
def e1202690179270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202690179270 : Closed e1202690179270 ∧ code e1202690179270 = 5600736690374 := by decide
theorem cert_e1202690179270 : check e1202690179270 [[]] .width = true := by decide
def e1202690318362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202690318362 : Closed e1202690318362 ∧ code e1202690318362 = 5600736829466 := by decide
theorem cert_e1202690318362 : check e1202690318362 [[]] .width = true := by decide
def e1202690318454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202690318454 : Closed e1202690318454 ∧ code e1202690318454 = 5600736829558 := by decide
theorem cert_e1202690318454 : check e1202690318454 [[]] .width = true := by decide
def e1202690318698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202690318698 : Closed e1202690318698 ∧ code e1202690318698 = 5600736829802 := by decide
theorem cert_e1202690318698 : check e1202690318698 [[]] .width = true := by decide
def e1202690318746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202690318746 : Closed e1202690318746 ∧ code e1202690318746 = 5600736829850 := by decide
theorem cert_e1202690318746 : check e1202690318746 [[]] .width = true := by decide
def e1202690408646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202690408646 : Closed e1202690408646 ∧ code e1202690408646 = 5600736919750 := by decide
theorem cert_e1202690408646 : check e1202690408646 [[]] .width = true := by decide
def e1202690416666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202690416666 : Closed e1202690416666 ∧ code e1202690416666 = 5600736927770 := by decide
theorem cert_e1202690416666 : check e1202690416666 [[]] .width = true := by decide
def e1202690416758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202690416758 : Closed e1202690416758 ∧ code e1202690416758 = 5600736927862 := by decide
private def t_e1202690416758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202690416758 : ¬ IsSelfInterpreter e1202690416758 :=
  wSource (t := t_e1202690416758) (replay_sound (ps := []) (t := e1202690416758) (by decide)) (by decide)
def e1202690417002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202690417002 : Closed e1202690417002 ∧ code e1202690417002 = 5600736928106 := by decide
private def t_e1202690417002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202690417002 : ¬ IsSelfInterpreter e1202690417002 :=
  wSource (t := t_e1202690417002) (replay_sound (ps := []) (t := e1202690417002) (by decide)) (by decide)
def e1202690417050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202690417050 : Closed e1202690417050 ∧ code e1202690417050 = 5600736928154 := by decide
private def t_e1202690417050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202690417050 : ¬ IsSelfInterpreter e1202690417050 :=
  wSource (t := t_e1202690417050) (replay_sound (ps := []) (t := e1202690417050) (by decide)) (by decide)
def e1202690568390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202690568390 : Closed e1202690568390 ∧ code e1202690568390 = 5600737079494 := by decide
theorem cert_e1202690568390 : check e1202690568390 [[]] .width = true := by decide
def e1202690576582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202690576582 : Closed e1202690576582 ∧ code e1202690576582 = 5600737087686 := by decide
theorem cert_e1202690576582 : check e1202690576582 [[]] .width = true := by decide
def e1202690748614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202690748614 : Closed e1202690748614 ∧ code e1202690748614 = 5600737259718 := by decide
theorem cert_e1202690748614 : check e1202690748614 [[]] .width = true := by decide
def e1202690818074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202690818074 : Closed e1202690818074 ∧ code e1202690818074 = 5600737329178 := by decide
theorem cert_e1202690818074 : check e1202690818074 [[]] .width = true := by decide
def e1202690818166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202690818166 : Closed e1202690818166 ∧ code e1202690818166 = 5600737329270 := by decide
theorem cert_e1202690818166 : check e1202690818166 [[]] .width = true := by decide
def e1202690818410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202690818410 : Closed e1202690818410 ∧ code e1202690818410 = 5600737329514 := by decide
theorem cert_e1202690818410 : check e1202690818410 [[]] .width = true := by decide
def e1202690818458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202690818458 : Closed e1202690818458 ∧ code e1202690818458 = 5600737329562 := by decide
theorem cert_e1202690818458 : check e1202690818458 [[]] .width = true := by decide
def e1202690819466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202690819466 : Closed e1202690819466 ∧ code e1202690819466 = 5600737330570 := by decide
theorem cert_e1202690819466 : check e1202690819466 [[]] .width = true := by decide
def e1202690819490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202690819490 : Closed e1202690819490 ∧ code e1202690819490 = 5600737330594 := by decide
theorem cert_e1202690819490 : check e1202690819490 [[]] .width = true := by decide
def e1202690819598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202690819598 : Closed e1202690819598 ∧ code e1202690819598 = 5600737330702 := by decide
theorem cert_e1202690819598 : check e1202690819598 [[]] .width = true := by decide
def e1202690819610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202690819610 : Closed e1202690819610 ∧ code e1202690819610 = 5600737330714 := by decide
theorem cert_e1202690819610 : check e1202690819610 [[]] .width = true := by decide
def e1202690819682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202690819682 : Closed e1202690819682 ∧ code e1202690819682 = 5600737330786 := by decide
theorem cert_e1202690819682 : check e1202690819682 [[]] .width = true := by decide
def e1202690834630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202690834630 : Closed e1202690834630 ∧ code e1202690834630 = 5600737345734 := by decide
theorem cert_e1202690834630 : check e1202690834630 [[]] .width = true := by decide
def e1202690863302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202690863302 : Closed e1202690863302 ∧ code e1202690863302 = 5600737374406 := by decide
theorem cert_e1202690863302 : check e1202690863302 [[]] .width = true := by decide
def e1202690883610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202690883610 : Closed e1202690883610 ∧ code e1202690883610 = 5600737394714 := by decide
theorem cert_e1202690883610 : check e1202690883610 [[]] .width = true := by decide
def e1202690883702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202690883702 : Closed e1202690883702 ∧ code e1202690883702 = 5600737394806 := by decide
theorem cert_e1202690883702 : check e1202690883702 [[]] .width = true := by decide
def e1202690883946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202690883946 : Closed e1202690883946 ∧ code e1202690883946 = 5600737395050 := by decide
theorem cert_e1202690883946 : check e1202690883946 [[]] .width = true := by decide
def e1202690883994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202690883994 : Closed e1202690883994 ∧ code e1202690883994 = 5600737395098 := by decide
theorem cert_e1202690883994 : check e1202690883994 [[]] .width = true := by decide
def e1202690885002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202690885002 : Closed e1202690885002 ∧ code e1202690885002 = 5600737396106 := by decide
theorem cert_e1202690885002 : check e1202690885002 [[]] .width = true := by decide
def e1202690885026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202690885026 : Closed e1202690885026 ∧ code e1202690885026 = 5600737396130 := by decide
theorem cert_e1202690885026 : check e1202690885026 [[]] .width = true := by decide
end Blc.Floor42
