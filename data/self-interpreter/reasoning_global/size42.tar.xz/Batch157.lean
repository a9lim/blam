import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186744182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211186744182 : Closed e1211186744182 ∧ code e1211186744182 = 5609233255286 := by decide
theorem cert_e1211186744182 : check e1211186744182 [[],[]] .smaller = true := by decide
def e1211186744186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211186744186 : Closed e1211186744186 ∧ code e1211186744186 = 5609233255290 := by decide
theorem cert_e1211186744186 : check e1211186744186 [[],[]] .smaller = true := by decide
def e1211186744238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211186744238 : Closed e1211186744238 ∧ code e1211186744238 = 5609233255342 := by decide
theorem cert_e1211186744238 : check e1211186744238 [[],[]] .smaller = true := by decide
def e1211186744250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211186744250 : Closed e1211186744250 ∧ code e1211186744250 = 5609233255354 := by decide
theorem cert_e1211186744250 : check e1211186744250 [[],[]] .smaller = true := by decide
def e1211186744278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211186744278 : Closed e1211186744278 ∧ code e1211186744278 = 5609233255382 := by decide
theorem cert_e1211186744278 : check e1211186744278 [[],[]] .smaller = true := by decide
def e1211186744282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211186744282 : Closed e1211186744282 ∧ code e1211186744282 = 5609233255386 := by decide
theorem cert_e1211186744282 : check e1211186744282 [[],[]] .smaller = true := by decide
def e1211186744298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211186744298 : Closed e1211186744298 ∧ code e1211186744298 = 5609233255402 := by decide
theorem cert_e1211186744298 : check e1211186744298 [[],[]] .smaller = true := by decide
def e1211186744542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211186744542 : Closed e1211186744542 ∧ code e1211186744542 = 5609233255646 := by decide
theorem cert_e1211186744542 : check e1211186744542 [[],[]] .smaller = true := by decide
def e1211186744558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211186744558 : Closed e1211186744558 ∧ code e1211186744558 = 5609233255662 := by decide
theorem cert_e1211186744558 : check e1211186744558 [[],[]] .smaller = true := by decide
def e1211186744566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211186744566 : Closed e1211186744566 ∧ code e1211186744566 = 5609233255670 := by decide
theorem cert_e1211186744566 : check e1211186744566 [[],[]] .smaller = true := by decide
def e1211186744570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211186744570 : Closed e1211186744570 ∧ code e1211186744570 = 5609233255674 := by decide
theorem cert_e1211186744570 : check e1211186744570 [[],[]] .smaller = true := by decide
def e1211186744894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211186744894 : Closed e1211186744894 ∧ code e1211186744894 = 5609233255998 := by decide
theorem cert_e1211186744894 : check e1211186744894 [[],[]] .smaller = true := by decide
def e1211186744942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186744942 : Closed e1211186744942 ∧ code e1211186744942 = 5609233256046 := by decide
theorem cert_e1211186744942 : check e1211186744942 [[],[]] .smaller = true := by decide
def e1211186744954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186744954 : Closed e1211186744954 ∧ code e1211186744954 = 5609233256058 := by decide
theorem cert_e1211186744954 : check e1211186744954 [[],[]] .smaller = true := by decide
def e1211186745142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186745142 : Closed e1211186745142 ∧ code e1211186745142 = 5609233256246 := by decide
theorem cert_e1211186745142 : check e1211186745142 [[],[]] .smaller = true := by decide
def e1211186745146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186745146 : Closed e1211186745146 ∧ code e1211186745146 = 5609233256250 := by decide
theorem cert_e1211186745146 : check e1211186745146 [[],[]] .smaller = true := by decide
def e1211186745230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211186745230 : Closed e1211186745230 ∧ code e1211186745230 = 5609233256334 := by decide
theorem cert_e1211186745230 : check e1211186745230 [[],[]] .smaller = true := by decide
def e1211186745242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186745242 : Closed e1211186745242 ∧ code e1211186745242 = 5609233256346 := by decide
theorem cert_e1211186745242 : check e1211186745242 [[],[]] .smaller = true := by decide
def e1211186752606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211186752606 : Closed e1211186752606 ∧ code e1211186752606 = 5609233263710 := by decide
theorem cert_e1211186752606 : check e1211186752606 [[],[]] .three = true := by decide
def e1211186752622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211186752622 : Closed e1211186752622 ∧ code e1211186752622 = 5609233263726 := by decide
theorem cert_e1211186752622 : check e1211186752622 [[],[]] .smaller = true := by decide
def e1211186752634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211186752634 : Closed e1211186752634 ∧ code e1211186752634 = 5609233263738 := by decide
theorem cert_e1211186752634 : check e1211186752634 [[],[]] .smaller = true := by decide
def e1211186752798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211186752798 : Closed e1211186752798 ∧ code e1211186752798 = 5609233263902 := by decide
theorem cert_e1211186752798 : check e1211186752798 [[],[]] .smaller = true := by decide
def e1211186752966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211186752966 : Closed e1211186752966 ∧ code e1211186752966 = 5609233264070 := by decide
theorem cert_e1211186752966 : check e1211186752966 [[],[]] .smaller = true := by decide
def e1211186752990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1211186752990 : Closed e1211186752990 ∧ code e1211186752990 = 5609233264094 := by decide
theorem cert_e1211186752990 : check e1211186752990 [[],[]] .three = true := by decide
def e1211186752994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211186752994 : Closed e1211186752994 ∧ code e1211186752994 = 5609233264098 := by decide
theorem cert_e1211186752994 : check e1211186752994 [[],[]] .three = true := by decide
def e1211186753006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1211186753006 : Closed e1211186753006 ∧ code e1211186753006 = 5609233264110 := by decide
theorem cert_e1211186753006 : check e1211186753006 [[],[]] .three = true := by decide
def e1211186753070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211186753070 : Closed e1211186753070 ∧ code e1211186753070 = 5609233264174 := by decide
theorem cert_e1211186753070 : check e1211186753070 [[],[]] .smaller = true := by decide
def e1211186753246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1211186753246 : Closed e1211186753246 ∧ code e1211186753246 = 5609233264350 := by decide
theorem cert_e1211186753246 : check e1211186753246 [[],[]] .three = true := by decide
def e1211186753250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211186753250 : Closed e1211186753250 ∧ code e1211186753250 = 5609233264354 := by decide
theorem cert_e1211186753250 : check e1211186753250 [[],[]] .smaller = true := by decide
def e1211186753262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e1211186753262 : Closed e1211186753262 ∧ code e1211186753262 = 5609233264366 := by decide
theorem cert_e1211186753262 : check e1211186753262 [[],[]] .smaller = true := by decide
def e1211186753270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1211186753270 : Closed e1211186753270 ∧ code e1211186753270 = 5609233264374 := by decide
theorem cert_e1211186753270 : check e1211186753270 [[],[]] .three = true := by decide
def e1211186753302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186753302 : Closed e1211186753302 ∧ code e1211186753302 = 5609233264406 := by decide
theorem cert_e1211186753302 : check e1211186753302 [[],[]] .smaller = true := by decide
def e1211186753306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211186753306 : Closed e1211186753306 ∧ code e1211186753306 = 5609233264410 := by decide
theorem cert_e1211186753306 : check e1211186753306 [[],[]] .smaller = true := by decide
def e1211186753350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211186753350 : Closed e1211186753350 ∧ code e1211186753350 = 5609233264454 := by decide
theorem cert_e1211186753350 : check e1211186753350 [[],[]] .smaller = true := by decide
def e1211186753374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1211186753374 : Closed e1211186753374 ∧ code e1211186753374 = 5609233264478 := by decide
theorem cert_e1211186753374 : check e1211186753374 [[],[]] .three = true := by decide
def e1211186753378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186753378 : Closed e1211186753378 ∧ code e1211186753378 = 5609233264482 := by decide
theorem cert_e1211186753378 : check e1211186753378 [[],[]] .smaller = true := by decide
def e1211186753390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e1211186753390 : Closed e1211186753390 ∧ code e1211186753390 = 5609233264494 := by decide
theorem cert_e1211186753390 : check e1211186753390 [[],[]] .smaller = true := by decide
def e1211186753398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e1211186753398 : Closed e1211186753398 ∧ code e1211186753398 = 5609233264502 := by decide
theorem cert_e1211186753398 : check e1211186753398 [[],[]] .smaller = true := by decide
def e1211186753402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1211186753402 : Closed e1211186753402 ∧ code e1211186753402 = 5609233264506 := by decide
theorem cert_e1211186753402 : check e1211186753402 [[],[]] .three = true := by decide
def e1211186753418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186753418 : Closed e1211186753418 ∧ code e1211186753418 = 5609233264522 := by decide
theorem cert_e1211186753418 : check e1211186753418 [[],[]] .three = true := by decide
def e1211186753442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186753442 : Closed e1211186753442 ∧ code e1211186753442 = 5609233264546 := by decide
theorem cert_e1211186753442 : check e1211186753442 [[],[]] .three = true := by decide
def e1211186753454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1211186753454 : Closed e1211186753454 ∧ code e1211186753454 = 5609233264558 := by decide
theorem cert_e1211186753454 : check e1211186753454 [[],[]] .three = true := by decide
def e1211186753462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1211186753462 : Closed e1211186753462 ∧ code e1211186753462 = 5609233264566 := by decide
theorem cert_e1211186753462 : check e1211186753462 [[],[]] .three = true := by decide
def e1211186753466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1211186753466 : Closed e1211186753466 ∧ code e1211186753466 = 5609233264570 := by decide
theorem cert_e1211186753466 : check e1211186753466 [[],[]] .three = true := by decide
def e1211186753662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 5))))))))))
theorem wire_e1211186753662 : Closed e1211186753662 ∧ code e1211186753662 = 5609233264766 := by decide
theorem cert_e1211186753662 : check e1211186753662 [[],[]] .three = true := by decide
def e1211186753758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211186753758 : Closed e1211186753758 ∧ code e1211186753758 = 5609233264862 := by decide
theorem cert_e1211186753758 : check e1211186753758 [[],[]] .smaller = true := by decide
def e1211186753786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211186753786 : Closed e1211186753786 ∧ code e1211186753786 = 5609233264890 := by decide
theorem cert_e1211186753786 : check e1211186753786 [[],[]] .smaller = true := by decide
def e1211186754334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211186754334 : Closed e1211186754334 ∧ code e1211186754334 = 5609233265438 := by decide
theorem cert_e1211186754334 : check e1211186754334 [[],[]] .smaller = true := by decide
def e1211186754502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211186754502 : Closed e1211186754502 ∧ code e1211186754502 = 5609233265606 := by decide
theorem cert_e1211186754502 : check e1211186754502 [[],[]] .smaller = true := by decide
def e1211186754526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211186754526 : Closed e1211186754526 ∧ code e1211186754526 = 5609233265630 := by decide
theorem cert_e1211186754526 : check e1211186754526 [[],[]] .three = true := by decide
def e1211186754530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211186754530 : Closed e1211186754530 ∧ code e1211186754530 = 5609233265634 := by decide
theorem cert_e1211186754530 : check e1211186754530 [[],[]] .three = true := by decide
def e1211186754542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211186754542 : Closed e1211186754542 ∧ code e1211186754542 = 5609233265646 := by decide
theorem cert_e1211186754542 : check e1211186754542 [[],[]] .three = true := by decide
def e1211186755646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e1211186755646 : Closed e1211186755646 ∧ code e1211186755646 = 5609233266750 := by decide
theorem cert_e1211186755646 : check e1211186755646 [[],[]] .smaller = true := by decide
def e1211186756062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186756062 : Closed e1211186756062 ∧ code e1211186756062 = 5609233267166 := by decide
theorem cert_e1211186756062 : check e1211186756062 [[],[]] .three = true := by decide
def e1211186756066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211186756066 : Closed e1211186756066 ∧ code e1211186756066 = 5609233267170 := by decide
theorem cert_e1211186756066 : check e1211186756066 [[],[]] .smaller = true := by decide
def e1211186756078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211186756078 : Closed e1211186756078 ∧ code e1211186756078 = 5609233267182 := by decide
theorem cert_e1211186756078 : check e1211186756078 [[],[]] .smaller = true := by decide
def e1211186756086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186756086 : Closed e1211186756086 ∧ code e1211186756086 = 5609233267190 := by decide
theorem cert_e1211186756086 : check e1211186756086 [[],[]] .three = true := by decide
def e1211186756638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186756638 : Closed e1211186756638 ∧ code e1211186756638 = 5609233267742 := by decide
theorem cert_e1211186756638 : check e1211186756638 [[],[]] .smaller = true := by decide
def e1211186756662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186756662 : Closed e1211186756662 ∧ code e1211186756662 = 5609233267766 := by decide
theorem cert_e1211186756662 : check e1211186756662 [[],[]] .smaller = true := by decide
def e1211186756666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186756666 : Closed e1211186756666 ∧ code e1211186756666 = 5609233267770 := by decide
theorem cert_e1211186756666 : check e1211186756666 [[],[]] .smaller = true := by decide
def e1211186756806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211186756806 : Closed e1211186756806 ∧ code e1211186756806 = 5609233267910 := by decide
theorem cert_e1211186756806 : check e1211186756806 [[],[]] .smaller = true := by decide
def e1211186756830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186756830 : Closed e1211186756830 ∧ code e1211186756830 = 5609233267934 := by decide
theorem cert_e1211186756830 : check e1211186756830 [[],[]] .three = true := by decide
def e1211186756834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186756834 : Closed e1211186756834 ∧ code e1211186756834 = 5609233267938 := by decide
theorem cert_e1211186756834 : check e1211186756834 [[],[]] .smaller = true := by decide
def e1211186756846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186756846 : Closed e1211186756846 ∧ code e1211186756846 = 5609233267950 := by decide
theorem cert_e1211186756846 : check e1211186756846 [[],[]] .smaller = true := by decide
def e1211186756854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186756854 : Closed e1211186756854 ∧ code e1211186756854 = 5609233267958 := by decide
theorem cert_e1211186756854 : check e1211186756854 [[],[]] .smaller = true := by decide
def e1211186756858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186756858 : Closed e1211186756858 ∧ code e1211186756858 = 5609233267962 := by decide
theorem cert_e1211186756858 : check e1211186756858 [[],[]] .three = true := by decide
def e1211186757134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186757134 : Closed e1211186757134 ∧ code e1211186757134 = 5609233268238 := by decide
theorem cert_e1211186757134 : check e1211186757134 [[],[]] .three = true := by decide
def e1211186757146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186757146 : Closed e1211186757146 ∧ code e1211186757146 = 5609233268250 := by decide
theorem cert_e1211186757146 : check e1211186757146 [[],[]] .three = true := by decide
def e1211186757182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 4)))))))))
theorem wire_e1211186757182 : Closed e1211186757182 ∧ code e1211186757182 = 5609233268286 := by decide
theorem cert_e1211186757182 : check e1211186757182 [[],[]] .three = true := by decide
def e1211186757218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186757218 : Closed e1211186757218 ∧ code e1211186757218 = 5609233268322 := by decide
theorem cert_e1211186757218 : check e1211186757218 [[],[]] .three = true := by decide
def e1211186757230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186757230 : Closed e1211186757230 ∧ code e1211186757230 = 5609233268334 := by decide
theorem cert_e1211186757230 : check e1211186757230 [[],[]] .three = true := by decide
def e1211186757238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186757238 : Closed e1211186757238 ∧ code e1211186757238 = 5609233268342 := by decide
theorem cert_e1211186757238 : check e1211186757238 [[],[]] .three = true := by decide
def e1211186757242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186757242 : Closed e1211186757242 ∧ code e1211186757242 = 5609233268346 := by decide
theorem cert_e1211186757242 : check e1211186757242 [[],[]] .three = true := by decide
def e1211186775470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211186775470 : Closed e1211186775470 ∧ code e1211186775470 = 5609233286574 := by decide
theorem cert_e1211186775470 : check e1211186775470 [[],[]] .smaller = true := by decide
def e1211186775482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211186775482 : Closed e1211186775482 ∧ code e1211186775482 = 5609233286586 := by decide
theorem cert_e1211186775482 : check e1211186775482 [[],[]] .smaller = true := by decide
def e1211186775530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211186775530 : Closed e1211186775530 ∧ code e1211186775530 = 5609233286634 := by decide
theorem cert_e1211186775530 : check e1211186775530 [[],[]] .smaller = true := by decide
def e1211186775662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186775662 : Closed e1211186775662 ∧ code e1211186775662 = 5609233286766 := by decide
theorem cert_e1211186775662 : check e1211186775662 [[],[]] .smaller = true := by decide
def e1211186775674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186775674 : Closed e1211186775674 ∧ code e1211186775674 = 5609233286778 := by decide
theorem cert_e1211186775674 : check e1211186775674 [[],[]] .smaller = true := by decide
def e1211186775838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211186775838 : Closed e1211186775838 ∧ code e1211186775838 = 5609233286942 := by decide
theorem cert_e1211186775838 : check e1211186775838 [[],[]] .smaller = true := by decide
def e1211186775950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211186775950 : Closed e1211186775950 ∧ code e1211186775950 = 5609233287054 := by decide
theorem cert_e1211186775950 : check e1211186775950 [[],[]] .smaller = true := by decide
def e1211186775962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186775962 : Closed e1211186775962 ∧ code e1211186775962 = 5609233287066 := by decide
theorem cert_e1211186775962 : check e1211186775962 [[],[]] .smaller = true := by decide
def e1211186779702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211186779702 : Closed e1211186779702 ∧ code e1211186779702 = 5609233290806 := by decide
theorem cert_e1211186779702 : check e1211186779702 [[],[]] .smaller = true := by decide
def e1211186779706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211186779706 : Closed e1211186779706 ∧ code e1211186779706 = 5609233290810 := by decide
theorem cert_e1211186779706 : check e1211186779706 [[],[]] .smaller = true := by decide
def e1211186779790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211186779790 : Closed e1211186779790 ∧ code e1211186779790 = 5609233290894 := by decide
theorem cert_e1211186779790 : check e1211186779790 [[],[]] .smaller = true := by decide
def e1211186779846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211186779846 : Closed e1211186779846 ∧ code e1211186779846 = 5609233290950 := by decide
theorem cert_e1211186779846 : check e1211186779846 [[],[]] .smaller = true := by decide
def e1211186779870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211186779870 : Closed e1211186779870 ∧ code e1211186779870 = 5609233290974 := by decide
theorem cert_e1211186779870 : check e1211186779870 [[],[]] .three = true := by decide
def e1211186779894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211186779894 : Closed e1211186779894 ∧ code e1211186779894 = 5609233290998 := by decide
theorem cert_e1211186779894 : check e1211186779894 [[],[]] .three = true := by decide
def e1211186779926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186779926 : Closed e1211186779926 ∧ code e1211186779926 = 5609233291030 := by decide
theorem cert_e1211186779926 : check e1211186779926 [[],[]] .smaller = true := by decide
def e1211186779930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211186779930 : Closed e1211186779930 ∧ code e1211186779930 = 5609233291034 := by decide
theorem cert_e1211186779930 : check e1211186779930 [[],[]] .smaller = true := by decide
def e1211186779974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211186779974 : Closed e1211186779974 ∧ code e1211186779974 = 5609233291078 := by decide
theorem cert_e1211186779974 : check e1211186779974 [[],[]] .smaller = true := by decide
def e1211186779998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211186779998 : Closed e1211186779998 ∧ code e1211186779998 = 5609233291102 := by decide
theorem cert_e1211186779998 : check e1211186779998 [[],[]] .three = true := by decide
def e1211186780002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186780002 : Closed e1211186780002 ∧ code e1211186780002 = 5609233291106 := by decide
theorem cert_e1211186780002 : check e1211186780002 [[],[]] .smaller = true := by decide
def e1211186780014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211186780014 : Closed e1211186780014 ∧ code e1211186780014 = 5609233291118 := by decide
theorem cert_e1211186780014 : check e1211186780014 [[],[]] .smaller = true := by decide
def e1211186780022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211186780022 : Closed e1211186780022 ∧ code e1211186780022 = 5609233291126 := by decide
theorem cert_e1211186780022 : check e1211186780022 [[],[]] .smaller = true := by decide
def e1211186780026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211186780026 : Closed e1211186780026 ∧ code e1211186780026 = 5609233291130 := by decide
theorem cert_e1211186780026 : check e1211186780026 [[],[]] .three = true := by decide
def e1211186780086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211186780086 : Closed e1211186780086 ∧ code e1211186780086 = 5609233291190 := by decide
theorem cert_e1211186780086 : check e1211186780086 [[],[]] .smaller = true := by decide
def e1211186780118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211186780118 : Closed e1211186780118 ∧ code e1211186780118 = 5609233291222 := by decide
theorem cert_e1211186780118 : check e1211186780118 [[],[]] .three = true := by decide
def e1211186780122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211186780122 : Closed e1211186780122 ∧ code e1211186780122 = 5609233291226 := by decide
theorem cert_e1211186780122 : check e1211186780122 [[],[]] .three = true := by decide
def e1211186780270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186780270 : Closed e1211186780270 ∧ code e1211186780270 = 5609233291374 := by decide
theorem cert_e1211186780270 : check e1211186780270 [[],[]] .smaller = true := by decide
def e1211186780282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186780282 : Closed e1211186780282 ∧ code e1211186780282 = 5609233291386 := by decide
theorem cert_e1211186780282 : check e1211186780282 [[],[]] .smaller = true := by decide
def e1211186780558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211186780558 : Closed e1211186780558 ∧ code e1211186780558 = 5609233291662 := by decide
theorem cert_e1211186780558 : check e1211186780558 [[],[]] .smaller = true := by decide
def e1211186780614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211186780614 : Closed e1211186780614 ∧ code e1211186780614 = 5609233291718 := by decide
theorem cert_e1211186780614 : check e1211186780614 [[],[]] .smaller = true := by decide
def e1211186780638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186780638 : Closed e1211186780638 ∧ code e1211186780638 = 5609233291742 := by decide
theorem cert_e1211186780638 : check e1211186780638 [[],[]] .three = true := by decide
def e1211186780662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186780662 : Closed e1211186780662 ∧ code e1211186780662 = 5609233291766 := by decide
theorem cert_e1211186780662 : check e1211186780662 [[],[]] .three = true := by decide
def e1211186781214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186781214 : Closed e1211186781214 ∧ code e1211186781214 = 5609233292318 := by decide
theorem cert_e1211186781214 : check e1211186781214 [[],[]] .smaller = true := by decide
def e1211186781238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186781238 : Closed e1211186781238 ∧ code e1211186781238 = 5609233292342 := by decide
theorem cert_e1211186781238 : check e1211186781238 [[],[]] .smaller = true := by decide
def e1211186781242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186781242 : Closed e1211186781242 ∧ code e1211186781242 = 5609233292346 := by decide
theorem cert_e1211186781242 : check e1211186781242 [[],[]] .smaller = true := by decide
def e1211186781382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211186781382 : Closed e1211186781382 ∧ code e1211186781382 = 5609233292486 := by decide
theorem cert_e1211186781382 : check e1211186781382 [[],[]] .smaller = true := by decide
def e1211186781406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186781406 : Closed e1211186781406 ∧ code e1211186781406 = 5609233292510 := by decide
theorem cert_e1211186781406 : check e1211186781406 [[],[]] .three = true := by decide
def e1211186781410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186781410 : Closed e1211186781410 ∧ code e1211186781410 = 5609233292514 := by decide
theorem cert_e1211186781410 : check e1211186781410 [[],[]] .smaller = true := by decide
def e1211186781422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186781422 : Closed e1211186781422 ∧ code e1211186781422 = 5609233292526 := by decide
theorem cert_e1211186781422 : check e1211186781422 [[],[]] .smaller = true := by decide
def e1211186781430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186781430 : Closed e1211186781430 ∧ code e1211186781430 = 5609233292534 := by decide
theorem cert_e1211186781430 : check e1211186781430 [[],[]] .smaller = true := by decide
def e1211186781434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186781434 : Closed e1211186781434 ∧ code e1211186781434 = 5609233292538 := by decide
theorem cert_e1211186781434 : check e1211186781434 [[],[]] .three = true := by decide
def e1211186781758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e1211186781758 : Closed e1211186781758 ∧ code e1211186781758 = 5609233292862 := by decide
theorem cert_e1211186781758 : check e1211186781758 [[],[]] .three = true := by decide
def e1211186781814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186781814 : Closed e1211186781814 ∧ code e1211186781814 = 5609233292918 := by decide
theorem cert_e1211186781814 : check e1211186781814 [[],[]] .smaller = true := by decide
def e1211186781982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e1211186781982 : Closed e1211186781982 ∧ code e1211186781982 = 5609233293086 := by decide
theorem cert_e1211186781982 : check e1211186781982 [[],[]] .three = true := by decide
def e1211186782006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186782006 : Closed e1211186782006 ∧ code e1211186782006 = 5609233293110 := by decide
theorem cert_e1211186782006 : check e1211186782006 [[],[]] .three = true := by decide
def e1211186782010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186782010 : Closed e1211186782010 ∧ code e1211186782010 = 5609233293114 := by decide
theorem cert_e1211186782010 : check e1211186782010 [[],[]] .three = true := by decide
def e1211186793238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186793238 : Closed e1211186793238 ∧ code e1211186793238 = 5609233304342 := by decide
theorem cert_e1211186793238 : check e1211186793238 [[],[]] .three = true := by decide
def e1211186793314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186793314 : Closed e1211186793314 ∧ code e1211186793314 = 5609233304418 := by decide
theorem cert_e1211186793314 : check e1211186793314 [[],[]] .three = true := by decide
def e1211186793326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211186793326 : Closed e1211186793326 ∧ code e1211186793326 = 5609233304430 := by decide
theorem cert_e1211186793326 : check e1211186793326 [[],[]] .three = true := by decide
def e1211186793334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211186793334 : Closed e1211186793334 ∧ code e1211186793334 = 5609233304438 := by decide
theorem cert_e1211186793334 : check e1211186793334 [[],[]] .three = true := by decide
def e1211186793354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186793354 : Closed e1211186793354 ∧ code e1211186793354 = 5609233304458 := by decide
theorem cert_e1211186793354 : check e1211186793354 [[],[]] .three = true := by decide
def e1211186793378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186793378 : Closed e1211186793378 ∧ code e1211186793378 = 5609233304482 := by decide
theorem cert_e1211186793378 : check e1211186793378 [[],[]] .three = true := by decide
def e1211186793390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211186793390 : Closed e1211186793390 ∧ code e1211186793390 = 5609233304494 := by decide
theorem cert_e1211186793390 : check e1211186793390 [[],[]] .three = true := by decide
def e1211186793398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e1211186793398 : Closed e1211186793398 ∧ code e1211186793398 = 5609233304502 := by decide
theorem cert_e1211186793398 : check e1211186793398 [[],[]] .three = true := by decide
def e1211186793402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211186793402 : Closed e1211186793402 ∧ code e1211186793402 = 5609233304506 := by decide
theorem cert_e1211186793402 : check e1211186793402 [[],[]] .three = true := by decide
def e1211186793430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211186793430 : Closed e1211186793430 ∧ code e1211186793430 = 5609233304534 := by decide
theorem cert_e1211186793430 : check e1211186793430 [[],[]] .three = true := by decide
def e1211186793434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211186793434 : Closed e1211186793434 ∧ code e1211186793434 = 5609233304538 := by decide
theorem cert_e1211186793434 : check e1211186793434 [[],[]] .three = true := by decide
def e1211186793502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186793502 : Closed e1211186793502 ∧ code e1211186793502 = 5609233304606 := by decide
theorem cert_e1211186793502 : check e1211186793502 [[],[]] .three = true := by decide
def e1211186793698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186793698 : Closed e1211186793698 ∧ code e1211186793698 = 5609233304802 := by decide
theorem cert_e1211186793698 : check e1211186793698 [[],[]] .three = true := by decide
def e1211186793710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186793710 : Closed e1211186793710 ∧ code e1211186793710 = 5609233304814 := by decide
theorem cert_e1211186793710 : check e1211186793710 [[],[]] .three = true := by decide
def e1211186793718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186793718 : Closed e1211186793718 ∧ code e1211186793718 = 5609233304822 := by decide
theorem cert_e1211186793718 : check e1211186793718 [[],[]] .three = true := by decide
def e1211186793998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186793998 : Closed e1211186793998 ∧ code e1211186793998 = 5609233305102 := by decide
theorem cert_e1211186793998 : check e1211186793998 [[],[]] .three = true := by decide
def e1211186794010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186794010 : Closed e1211186794010 ∧ code e1211186794010 = 5609233305114 := by decide
theorem cert_e1211186794010 : check e1211186794010 [[],[]] .three = true := by decide
def e1211186794046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211186794046 : Closed e1211186794046 ∧ code e1211186794046 = 5609233305150 := by decide
theorem cert_e1211186794046 : check e1211186794046 [[],[]] .three = true := by decide
def e1211186794082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186794082 : Closed e1211186794082 ∧ code e1211186794082 = 5609233305186 := by decide
theorem cert_e1211186794082 : check e1211186794082 [[],[]] .three = true := by decide
def e1211186794094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186794094 : Closed e1211186794094 ∧ code e1211186794094 = 5609233305198 := by decide
theorem cert_e1211186794094 : check e1211186794094 [[],[]] .three = true := by decide
def e1211186794102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186794102 : Closed e1211186794102 ∧ code e1211186794102 = 5609233305206 := by decide
theorem cert_e1211186794102 : check e1211186794102 [[],[]] .three = true := by decide
def e1211186794106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186794106 : Closed e1211186794106 ∧ code e1211186794106 = 5609233305210 := by decide
theorem cert_e1211186794106 : check e1211186794106 [[],[]] .three = true := by decide
def e1211186794270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211186794270 : Closed e1211186794270 ∧ code e1211186794270 = 5609233305374 := by decide
theorem cert_e1211186794270 : check e1211186794270 [[],[]] .three = true := by decide
def e1211186794294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186794294 : Closed e1211186794294 ∧ code e1211186794294 = 5609233305398 := by decide
theorem cert_e1211186794294 : check e1211186794294 [[],[]] .three = true := by decide
def e1211186794298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186794298 : Closed e1211186794298 ∧ code e1211186794298 = 5609233305402 := by decide
theorem cert_e1211186794298 : check e1211186794298 [[],[]] .three = true := by decide
def e1211186794382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211186794382 : Closed e1211186794382 ∧ code e1211186794382 = 5609233305486 := by decide
theorem cert_e1211186794382 : check e1211186794382 [[],[]] .three = true := by decide
def e1211186814174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186814174 : Closed e1211186814174 ∧ code e1211186814174 = 5609233325278 := by decide
theorem cert_e1211186814174 : check e1211186814174 [[],[]] .three = true := by decide
def e1211186814190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186814190 : Closed e1211186814190 ∧ code e1211186814190 = 5609233325294 := by decide
theorem cert_e1211186814190 : check e1211186814190 [[],[]] .smaller = true := by decide
def e1211186814198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186814198 : Closed e1211186814198 ∧ code e1211186814198 = 5609233325302 := by decide
theorem cert_e1211186814198 : check e1211186814198 [[],[]] .smaller = true := by decide
def e1211186814202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186814202 : Closed e1211186814202 ∧ code e1211186814202 = 5609233325306 := by decide
theorem cert_e1211186814202 : check e1211186814202 [[],[]] .three = true := by decide
def e1211186814574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186814574 : Closed e1211186814574 ∧ code e1211186814574 = 5609233325678 := by decide
theorem cert_e1211186814574 : check e1211186814574 [[],[]] .smaller = true := by decide
def e1211186814586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186814586 : Closed e1211186814586 ∧ code e1211186814586 = 5609233325690 := by decide
theorem cert_e1211186814586 : check e1211186814586 [[],[]] .smaller = true := by decide
def e1211186814774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186814774 : Closed e1211186814774 ∧ code e1211186814774 = 5609233325878 := by decide
theorem cert_e1211186814774 : check e1211186814774 [[],[]] .smaller = true := by decide
def e1211186814778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186814778 : Closed e1211186814778 ∧ code e1211186814778 = 5609233325882 := by decide
theorem cert_e1211186814778 : check e1211186814778 [[],[]] .smaller = true := by decide
def e1211186814874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186814874 : Closed e1211186814874 ∧ code e1211186814874 = 5609233325978 := by decide
theorem cert_e1211186814874 : check e1211186814874 [[],[]] .three = true := by decide
def e1211186818414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2)))))))
theorem wire_e1211186818414 : Closed e1211186818414 ∧ code e1211186818414 = 5609233329518 := by decide
theorem cert_e1211186818414 : check e1211186818414 [[],[]] .smaller = true := by decide
def e1211186818426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 0)))))))
theorem wire_e1211186818426 : Closed e1211186818426 ∧ code e1211186818426 = 5609233329530 := by decide
theorem cert_e1211186818426 : check e1211186818426 [[],[]] .smaller = true := by decide
def e1211186818478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2)))))))
theorem wire_e1211186818478 : Closed e1211186818478 ∧ code e1211186818478 = 5609233329582 := by decide
theorem cert_e1211186818478 : check e1211186818478 [[],[]] .smaller = true := by decide
def e1211186818490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e1211186818490 : Closed e1211186818490 ∧ code e1211186818490 = 5609233329594 := by decide
theorem cert_e1211186818490 : check e1211186818490 [[],[]] .smaller = true := by decide
def e1211186818522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e1211186818522 : Closed e1211186818522 ∧ code e1211186818522 = 5609233329626 := by decide
theorem cert_e1211186818522 : check e1211186818522 [[],[]] .smaller = true := by decide
def e1211186818538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.var 0)))))))
theorem wire_e1211186818538 : Closed e1211186818538 ∧ code e1211186818538 = 5609233329642 := by decide
theorem cert_e1211186818538 : check e1211186818538 [[],[]] .smaller = true := by decide
def e1211186818734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2)))))))
theorem wire_e1211186818734 : Closed e1211186818734 ∧ code e1211186818734 = 5609233329838 := by decide
theorem cert_e1211186818734 : check e1211186818734 [[],[]] .smaller = true := by decide
end Blc.Floor42
