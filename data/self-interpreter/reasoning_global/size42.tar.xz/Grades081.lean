import Tables
import Batch081
namespace Blc.Floor42.Grades081
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1196692651242 : ¬ IsSelfInterpreter e1196692651242 := cutM0_2 (by decide)
#print axioms ex_e1196692651242
theorem ex_e1196692661738 : ¬ IsSelfInterpreter e1196692661738 := cutM1_2 (by decide)
#print axioms ex_e1196692661738
theorem ex_e1196692661870 : ¬ IsSelfInterpreter e1196692661870 := cutM1_2 (by decide)
#print axioms ex_e1196692661870
theorem ex_e1196692661882 : ¬ IsSelfInterpreter e1196692661882 := cutM1_2 (by decide)
#print axioms ex_e1196692661882
theorem ex_e1196692662170 : ¬ IsSelfInterpreter e1196692662170 := cutM1_2 (by decide)
#print axioms ex_e1196692662170
theorem ex_e1196692665242 : ¬ IsSelfInterpreter e1196692665242 := cutM1_2 (by decide)
#print axioms ex_e1196692665242
theorem ex_e1196692803194 : ¬ IsSelfInterpreter e1196692803194 := cutM1_2 (by decide)
#print axioms ex_e1196692803194
theorem ex_e1196692665066 : ¬ IsSelfInterpreter e1196692665066 := cutM8_1 (by decide)
#print axioms ex_e1196692665066
theorem ex_e1196692665142 : ¬ IsSelfInterpreter e1196692665142 := cutM10_0 (by decide)
#print axioms ex_e1196692665142
theorem ex_e1196692665146 : ¬ IsSelfInterpreter e1196692665146 := cutM10_0 (by decide)
#print axioms ex_e1196692665146
end Blc.Floor42.Grades081
