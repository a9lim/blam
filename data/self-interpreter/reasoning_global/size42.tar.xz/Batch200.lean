import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211204963290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211204963290 : Closed e1211204963290 ∧ code e1211204963290 = 5609251474394 := by decide
theorem cert_e1211204963290 : check e1211204963290 [[],[]] .smaller = true := by decide
def e1211204963566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211204963566 : Closed e1211204963566 ∧ code e1211204963566 = 5609251474670 := by decide
theorem cert_e1211204963566 : check e1211204963566 [[],[]] .smaller = true := by decide
def e1211204963574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211204963574 : Closed e1211204963574 ∧ code e1211204963574 = 5609251474678 := by decide
theorem cert_e1211204963574 : check e1211204963574 [[],[]] .smaller = true := by decide
def e1211204963950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211204963950 : Closed e1211204963950 ∧ code e1211204963950 = 5609251475054 := by decide
theorem cert_e1211204963950 : check e1211204963950 [[],[]] .smaller = true := by decide
def e1211204963962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211204963962 : Closed e1211204963962 ∧ code e1211204963962 = 5609251475066 := by decide
theorem cert_e1211204963962 : check e1211204963962 [[],[]] .smaller = true := by decide
def e1211204964150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211204964150 : Closed e1211204964150 ∧ code e1211204964150 = 5609251475254 := by decide
theorem cert_e1211204964150 : check e1211204964150 [[],[]] .smaller = true := by decide
def e1211204964154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211204964154 : Closed e1211204964154 ∧ code e1211204964154 = 5609251475258 := by decide
theorem cert_e1211204964154 : check e1211204964154 [[],[]] .smaller = true := by decide
def e1211204971630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211204971630 : Closed e1211204971630 ∧ code e1211204971630 = 5609251482734 := by decide
theorem cert_e1211204971630 : check e1211204971630 [[],[]] .chain = true := by decide
def e1211204971642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211204971642 : Closed e1211204971642 ∧ code e1211204971642 = 5609251482746 := by decide
theorem cert_e1211204971642 : check e1211204971642 [[],[]] .chain = true := by decide
def e1211204971806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211204971806 : Closed e1211204971806 ∧ code e1211204971806 = 5609251482910 := by decide
theorem cert_e1211204971806 : check e1211204971806 [[],[]] .chain = true := by decide
def e1211204971974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211204971974 : Closed e1211204971974 ∧ code e1211204971974 = 5609251483078 := by decide
theorem cert_e1211204971974 : check e1211204971974 [[],[]] .chain = true := by decide
def e1211204972314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211204972314 : Closed e1211204972314 ∧ code e1211204972314 = 5609251483418 := by decide
theorem cert_e1211204972314 : check e1211204972314 [[],[]] .chain = true := by decide
def e1211204972358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211204972358 : Closed e1211204972358 ∧ code e1211204972358 = 5609251483462 := by decide
theorem cert_e1211204972358 : check e1211204972358 [[],[]] .chain = true := by decide
def e1211204973342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211204973342 : Closed e1211204973342 ∧ code e1211204973342 = 5609251484446 := by decide
theorem cert_e1211204973342 : check e1211204973342 [[],[]] .chain = true := by decide
def e1211204973510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211204973510 : Closed e1211204973510 ∧ code e1211204973510 = 5609251484614 := by decide
theorem cert_e1211204973510 : check e1211204973510 [[],[]] .chain = true := by decide
def e1211204975814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211204975814 : Closed e1211204975814 ∧ code e1211204975814 = 5609251486918 := by decide
theorem cert_e1211204975814 : check e1211204975814 [[],[]] .chain = true := by decide
def e1211204995038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e1211204995038 : Closed e1211204995038 ∧ code e1211204995038 = 5609251506142 := by decide
theorem cert_e1211204995038 : checkPay e1211204995038 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204998702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211204998702 : Closed e1211204998702 ∧ code e1211204998702 = 5609251509806 := by decide
theorem cert_e1211204998702 : check e1211204998702 [[],[]] .chain = true := by decide
def e1211204998882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211204998882 : Closed e1211204998882 ∧ code e1211204998882 = 5609251509986 := by decide
theorem cert_e1211204998882 : check e1211204998882 [[],[]] .chain = true := by decide
def e1211204998894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1211204998894 : Closed e1211204998894 ∧ code e1211204998894 = 5609251509998 := by decide
theorem cert_e1211204998894 : checkPay e1211204998894 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204999022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1211204999022 : Closed e1211204999022 ∧ code e1211204999022 = 5609251510126 := by decide
theorem cert_e1211204999022 : check e1211204999022 [[],[]] .chain = true := by decide
def e1211204999030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1211204999030 : Closed e1211204999030 ∧ code e1211204999030 = 5609251510134 := by decide
theorem cert_e1211204999030 : check e1211204999030 [[],[]] .chain = true := by decide
def e1211204999050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211204999050 : Closed e1211204999050 ∧ code e1211204999050 = 5609251510154 := by decide
theorem cert_e1211204999050 : check e1211204999050 [[],[]] .chain = true := by decide
def e1211204999074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211204999074 : Closed e1211204999074 ∧ code e1211204999074 = 5609251510178 := by decide
theorem cert_e1211204999074 : check e1211204999074 [[],[]] .chain = true := by decide
def e1211204999086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1211204999086 : Closed e1211204999086 ∧ code e1211204999086 = 5609251510190 := by decide
theorem cert_e1211204999086 : checkPay e1211204999086 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204999094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1211204999094 : Closed e1211204999094 ∧ code e1211204999094 = 5609251510198 := by decide
theorem cert_e1211204999094 : check e1211204999094 [[],[]] .chain = true := by decide
def e1211204999098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1211204999098 : Closed e1211204999098 ∧ code e1211204999098 = 5609251510202 := by decide
theorem cert_e1211204999098 : checkPay e1211204999098 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211204999230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e1211204999230 : Closed e1211204999230 ∧ code e1211204999230 = 5609251510334 := by decide
theorem cert_e1211204999230 : check e1211204999230 [[],[]] .chain = true := by decide
def e1211204999650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211204999650 : Closed e1211204999650 ∧ code e1211204999650 = 5609251510754 := by decide
theorem cert_e1211204999650 : check e1211204999650 [[],[]] .chain = true := by decide
def e1211204999662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1211204999662 : Closed e1211204999662 ∧ code e1211204999662 = 5609251510766 := by decide
theorem cert_e1211204999662 : checkPay e1211204999662 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205000430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1211205000430 : Closed e1211205000430 ∧ code e1211205000430 = 5609251511534 := by decide
theorem cert_e1211205000430 : check e1211205000430 [[],[]] .chain = true := by decide
def e1211205000438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1211205000438 : Closed e1211205000438 ∧ code e1211205000438 = 5609251511542 := by decide
theorem cert_e1211205000438 : check e1211205000438 [[],[]] .chain = true := by decide
def e1211205000718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e1211205000718 : Closed e1211205000718 ∧ code e1211205000718 = 5609251511822 := by decide
theorem cert_e1211205000718 : check e1211205000718 [[],[]] .chain = true := by decide
def e1211205000730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205000730 : Closed e1211205000730 ∧ code e1211205000730 = 5609251511834 := by decide
theorem cert_e1211205000730 : checkPay e1211205000730 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205000802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211205000802 : Closed e1211205000802 ∧ code e1211205000802 = 5609251511906 := by decide
theorem cert_e1211205000802 : check e1211205000802 [[],[]] .chain = true := by decide
def e1211205000814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205000814 : Closed e1211205000814 ∧ code e1211205000814 = 5609251511918 := by decide
theorem cert_e1211205000814 : checkPay e1211205000814 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205000822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205000822 : Closed e1211205000822 ∧ code e1211205000822 = 5609251511926 := by decide
theorem cert_e1211205000822 : check e1211205000822 [[],[]] .chain = true := by decide
def e1211205000826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205000826 : Closed e1211205000826 ∧ code e1211205000826 = 5609251511930 := by decide
theorem cert_e1211205000826 : checkPay e1211205000826 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205012334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211205012334 : Closed e1211205012334 ∧ code e1211205012334 = 5609251523438 := by decide
theorem cert_e1211205012334 : check e1211205012334 [[],[]] .chain = true := by decide
def e1211205012342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211205012342 : Closed e1211205012342 ∧ code e1211205012342 = 5609251523446 := by decide
theorem cert_e1211205012342 : check e1211205012342 [[],[]] .chain = true := by decide
def e1211205012398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211205012398 : Closed e1211205012398 ∧ code e1211205012398 = 5609251523502 := by decide
theorem cert_e1211205012398 : check e1211205012398 [[],[]] .chain = true := by decide
def e1211205012410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211205012410 : Closed e1211205012410 ∧ code e1211205012410 = 5609251523514 := by decide
theorem cert_e1211205012410 : check e1211205012410 [[],[]] .chain = true := by decide
def e1211205012438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211205012438 : Closed e1211205012438 ∧ code e1211205012438 = 5609251523542 := by decide
theorem cert_e1211205012438 : check e1211205012438 [[],[]] .chain = true := by decide
def e1211205012442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211205012442 : Closed e1211205012442 ∧ code e1211205012442 = 5609251523546 := by decide
theorem cert_e1211205012442 : check e1211205012442 [[],[]] .chain = true := by decide
def e1211205012718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211205012718 : Closed e1211205012718 ∧ code e1211205012718 = 5609251523822 := by decide
theorem cert_e1211205012718 : check e1211205012718 [[],[]] .chain = true := by decide
def e1211205012726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211205012726 : Closed e1211205012726 ∧ code e1211205012726 = 5609251523830 := by decide
theorem cert_e1211205012726 : check e1211205012726 [[],[]] .chain = true := by decide
def e1211205013102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205013102 : Closed e1211205013102 ∧ code e1211205013102 = 5609251524206 := by decide
theorem cert_e1211205013102 : check e1211205013102 [[],[]] .chain = true := by decide
def e1211205013114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205013114 : Closed e1211205013114 ∧ code e1211205013114 = 5609251524218 := by decide
theorem cert_e1211205013114 : check e1211205013114 [[],[]] .chain = true := by decide
def e1211205013302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205013302 : Closed e1211205013302 ∧ code e1211205013302 = 5609251524406 := by decide
theorem cert_e1211205013302 : check e1211205013302 [[],[]] .chain = true := by decide
def e1211205013306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205013306 : Closed e1211205013306 ∧ code e1211205013306 = 5609251524410 := by decide
theorem cert_e1211205013306 : check e1211205013306 [[],[]] .chain = true := by decide
def e1211205018078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211205018078 : Closed e1211205018078 ∧ code e1211205018078 = 5609251529182 := by decide
theorem cert_e1211205018078 : checkPay e1211205018078 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205018102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211205018102 : Closed e1211205018102 ∧ code e1211205018102 = 5609251529206 := by decide
theorem cert_e1211205018102 : checkPay e1211205018102 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211205019018 : Closed e1211205019018 ∧ code e1211205019018 = 5609251530122 := by decide
theorem cert_e1211205019018 : check e1211205019018 [[],[]] .chain = true := by decide
def e1211205019042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211205019042 : Closed e1211205019042 ∧ code e1211205019042 = 5609251530146 := by decide
theorem cert_e1211205019042 : check e1211205019042 [[],[]] .chain = true := by decide
def e1211205019054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211205019054 : Closed e1211205019054 ∧ code e1211205019054 = 5609251530158 := by decide
theorem cert_e1211205019054 : checkPay e1211205019054 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211205019062 : Closed e1211205019062 ∧ code e1211205019062 = 5609251530166 := by decide
theorem cert_e1211205019062 : check e1211205019062 [[],[]] .chain = true := by decide
def e1211205019066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211205019066 : Closed e1211205019066 ∧ code e1211205019066 = 5609251530170 := by decide
theorem cert_e1211205019066 : checkPay e1211205019066 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211205019094 : Closed e1211205019094 ∧ code e1211205019094 = 5609251530198 := by decide
theorem cert_e1211205019094 : check e1211205019094 [[],[]] .chain = true := by decide
def e1211205019098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211205019098 : Closed e1211205019098 ∧ code e1211205019098 = 5609251530202 := by decide
theorem cert_e1211205019098 : check e1211205019098 [[],[]] .chain = true := by decide
def e1211205019114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211205019114 : Closed e1211205019114 ∧ code e1211205019114 = 5609251530218 := by decide
theorem cert_e1211205019114 : checkPay e1211205019114 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e1211205019150 : Closed e1211205019150 ∧ code e1211205019150 = 5609251530254 := by decide
theorem cert_e1211205019150 : check e1211205019150 [[],[]] .chain = true := by decide
def e1211205019162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205019162 : Closed e1211205019162 ∧ code e1211205019162 = 5609251530266 := by decide
theorem cert_e1211205019162 : checkPay e1211205019162 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211205019234 : Closed e1211205019234 ∧ code e1211205019234 = 5609251530338 := by decide
theorem cert_e1211205019234 : check e1211205019234 [[],[]] .chain = true := by decide
def e1211205019246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205019246 : Closed e1211205019246 ∧ code e1211205019246 = 5609251530350 := by decide
theorem cert_e1211205019246 : checkPay e1211205019246 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205019254 : Closed e1211205019254 ∧ code e1211205019254 = 5609251530358 := by decide
theorem cert_e1211205019254 : check e1211205019254 [[],[]] .chain = true := by decide
def e1211205019258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205019258 : Closed e1211205019258 ∧ code e1211205019258 = 5609251530362 := by decide
theorem cert_e1211205019258 : checkPay e1211205019258 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205019446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205019446 : Closed e1211205019446 ∧ code e1211205019446 = 5609251530550 := by decide
theorem cert_e1211205019446 : check e1211205019446 [[],[]] .chain = true := by decide
def e1211205019450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205019450 : Closed e1211205019450 ∧ code e1211205019450 = 5609251530554 := by decide
theorem cert_e1211205019450 : check e1211205019450 [[],[]] .chain = true := by decide
def e1211205019546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205019546 : Closed e1211205019546 ∧ code e1211205019546 = 5609251530650 := by decide
theorem cert_e1211205019546 : checkPay e1211205019546 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211205072238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1211205072238 : Closed e1211205072238 ∧ code e1211205072238 = 5609251583342 := by decide
theorem cert_e1211205072238 : check e1211205072238 [[],[]] .chain = true := by decide
def e1211205072246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1211205072246 : Closed e1211205072246 ∧ code e1211205072246 = 5609251583350 := by decide
theorem cert_e1211205072246 : check e1211205072246 [[],[]] .chain = true := by decide
def e1211205072302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1211205072302 : Closed e1211205072302 ∧ code e1211205072302 = 5609251583406 := by decide
theorem cert_e1211205072302 : check e1211205072302 [[],[]] .chain = true := by decide
def e1211205072314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1211205072314 : Closed e1211205072314 ∧ code e1211205072314 = 5609251583418 := by decide
theorem cert_e1211205072314 : check e1211205072314 [[],[]] .chain = true := by decide
def e1211205072342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1211205072342 : Closed e1211205072342 ∧ code e1211205072342 = 5609251583446 := by decide
theorem cert_e1211205072342 : check e1211205072342 [[],[]] .chain = true := by decide
def e1211205072346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1211205072346 : Closed e1211205072346 ∧ code e1211205072346 = 5609251583450 := by decide
theorem cert_e1211205072346 : check e1211205072346 [[],[]] .chain = true := by decide
def e1211205072558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1211205072558 : Closed e1211205072558 ∧ code e1211205072558 = 5609251583662 := by decide
theorem cert_e1211205072558 : check e1211205072558 [[],[]] .chain = true := by decide
def e1211205072570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1211205072570 : Closed e1211205072570 ∧ code e1211205072570 = 5609251583674 := by decide
theorem cert_e1211205072570 : check e1211205072570 [[],[]] .chain = true := by decide
def e1211205072618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1211205072618 : Closed e1211205072618 ∧ code e1211205072618 = 5609251583722 := by decide
theorem cert_e1211205072618 : check e1211205072618 [[],[]] .chain = true := by decide
def e1211205072726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211205072726 : Closed e1211205072726 ∧ code e1211205072726 = 5609251583830 := by decide
theorem cert_e1211205072726 : check e1211205072726 [[],[]] .chain = true := by decide
def e1211205072730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211205072730 : Closed e1211205072730 ∧ code e1211205072730 = 5609251583834 := by decide
theorem cert_e1211205072730 : check e1211205072730 [[],[]] .chain = true := by decide
def e1211205072746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211205072746 : Closed e1211205072746 ∧ code e1211205072746 = 5609251583850 := by decide
theorem cert_e1211205072746 : check e1211205072746 [[],[]] .chain = true := by decide
def e1211205073582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1211205073582 : Closed e1211205073582 ∧ code e1211205073582 = 5609251584686 := by decide
theorem cert_e1211205073582 : check e1211205073582 [[],[]] .chain = true := by decide
def e1211205073594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1211205073594 : Closed e1211205073594 ∧ code e1211205073594 = 5609251584698 := by decide
theorem cert_e1211205073594 : check e1211205073594 [[],[]] .chain = true := by decide
def e1211205073642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1211205073642 : Closed e1211205073642 ∧ code e1211205073642 = 5609251584746 := by decide
theorem cert_e1211205073642 : check e1211205073642 [[],[]] .chain = true := by decide
def e1211205073834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e1211205073834 : Closed e1211205073834 ∧ code e1211205073834 = 5609251584938 := by decide
theorem cert_e1211205073834 : check e1211205073834 [[],[]] .chain = true := by decide
def e1211205074262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211205074262 : Closed e1211205074262 ∧ code e1211205074262 = 5609251585366 := by decide
theorem cert_e1211205074262 : check e1211205074262 [[],[]] .chain = true := by decide
def e1211205074266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211205074266 : Closed e1211205074266 ∧ code e1211205074266 = 5609251585370 := by decide
theorem cert_e1211205074266 : check e1211205074266 [[],[]] .chain = true := by decide
def e1211205074282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211205074282 : Closed e1211205074282 ∧ code e1211205074282 = 5609251585386 := by decide
theorem cert_e1211205074282 : check e1211205074282 [[],[]] .chain = true := by decide
def e1211205074346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e1211205074346 : Closed e1211205074346 ∧ code e1211205074346 = 5609251585450 := by decide
theorem cert_e1211205074346 : check e1211205074346 [[],[]] .chain = true := by decide
def e1211205075310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))) (.var 2))))))
theorem wire_e1211205075310 : Closed e1211205075310 ∧ code e1211205075310 = 5609251586414 := by decide
theorem cert_e1211205075310 : check e1211205075310 [[],[]] .chain = true := by decide
def e1211205075318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))) (.var 1))))))
theorem wire_e1211205075318 : Closed e1211205075318 ∧ code e1211205075318 = 5609251586422 := by decide
theorem cert_e1211205075318 : check e1211205075318 [[],[]] .chain = true := by decide
def e1211205075374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.var 2))))))
theorem wire_e1211205075374 : Closed e1211205075374 ∧ code e1211205075374 = 5609251586478 := by decide
theorem cert_e1211205075374 : check e1211205075374 [[],[]] .chain = true := by decide
def e1211205075386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))) (.var 0))))))
theorem wire_e1211205075386 : Closed e1211205075386 ∧ code e1211205075386 = 5609251586490 := by decide
theorem cert_e1211205075386 : check e1211205075386 [[],[]] .chain = true := by decide
def e1211205076078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211205076078 : Closed e1211205076078 ∧ code e1211205076078 = 5609251587182 := by decide
theorem cert_e1211205076078 : check e1211205076078 [[],[]] .chain = true := by decide
def e1211205076090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211205076090 : Closed e1211205076090 ∧ code e1211205076090 = 5609251587194 := by decide
theorem cert_e1211205076090 : check e1211205076090 [[],[]] .chain = true := by decide
def e1211205076254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211205076254 : Closed e1211205076254 ∧ code e1211205076254 = 5609251587358 := by decide
theorem cert_e1211205076254 : check e1211205076254 [[],[]] .chain = true := by decide
def e1211205076422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211205076422 : Closed e1211205076422 ∧ code e1211205076422 = 5609251587526 := by decide
theorem cert_e1211205076422 : check e1211205076422 [[],[]] .chain = true := by decide
def e1211205076526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211205076526 : Closed e1211205076526 ∧ code e1211205076526 = 5609251587630 := by decide
theorem cert_e1211205076526 : check e1211205076526 [[],[]] .chain = true := by decide
def e1211205076706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211205076706 : Closed e1211205076706 ∧ code e1211205076706 = 5609251587810 := by decide
theorem cert_e1211205076706 : check e1211205076706 [[],[]] .chain = true := by decide
def e1211205076718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 2))))))
theorem wire_e1211205076718 : Closed e1211205076718 ∧ code e1211205076718 = 5609251587822 := by decide
theorem cert_e1211205076718 : checkPay e1211205076718 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205076846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (.var 2))))))
theorem wire_e1211205076846 : Closed e1211205076846 ∧ code e1211205076846 = 5609251587950 := by decide
theorem cert_e1211205076846 : check e1211205076846 [[],[]] .chain = true := by decide
def e1211205076854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 1))))))
theorem wire_e1211205076854 : Closed e1211205076854 ∧ code e1211205076854 = 5609251587958 := by decide
theorem cert_e1211205076854 : check e1211205076854 [[],[]] .chain = true := by decide
def e1211205076874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211205076874 : Closed e1211205076874 ∧ code e1211205076874 = 5609251587978 := by decide
theorem cert_e1211205076874 : check e1211205076874 [[],[]] .chain = true := by decide
def e1211205076898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211205076898 : Closed e1211205076898 ∧ code e1211205076898 = 5609251588002 := by decide
theorem cert_e1211205076898 : check e1211205076898 [[],[]] .chain = true := by decide
def e1211205076910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 2))))))
theorem wire_e1211205076910 : Closed e1211205076910 ∧ code e1211205076910 = 5609251588014 := by decide
theorem cert_e1211205076910 : checkPay e1211205076910 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.under,.left]] = true := by decide
def e1211205076918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 1))))))
theorem wire_e1211205076918 : Closed e1211205076918 ∧ code e1211205076918 = 5609251588022 := by decide
theorem cert_e1211205076918 : check e1211205076918 [[],[]] .chain = true := by decide
def e1211205076922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))) (.var 0))))))
theorem wire_e1211205076922 : Closed e1211205076922 ∧ code e1211205076922 = 5609251588026 := by decide
theorem cert_e1211205076922 : checkPay e1211205076922 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.under,.left],[.under]] = true := by decide
def e1211205078382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e1211205078382 : Closed e1211205078382 ∧ code e1211205078382 = 5609251589486 := by decide
theorem cert_e1211205078382 : check e1211205078382 [[],[]] .chain = true := by decide
def e1211205078390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e1211205078390 : Closed e1211205078390 ∧ code e1211205078390 = 5609251589494 := by decide
theorem cert_e1211205078390 : check e1211205078390 [[],[]] .chain = true := by decide
def e1211205078446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e1211205078446 : Closed e1211205078446 ∧ code e1211205078446 = 5609251589550 := by decide
theorem cert_e1211205078446 : check e1211205078446 [[],[]] .chain = true := by decide
def e1211205078458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e1211205078458 : Closed e1211205078458 ∧ code e1211205078458 = 5609251589562 := by decide
theorem cert_e1211205078458 : check e1211205078458 [[],[]] .chain = true := by decide
def e1211205078486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e1211205078486 : Closed e1211205078486 ∧ code e1211205078486 = 5609251589590 := by decide
theorem cert_e1211205078486 : check e1211205078486 [[],[]] .chain = true := by decide
def e1211205078490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e1211205078490 : Closed e1211205078490 ∧ code e1211205078490 = 5609251589594 := by decide
theorem cert_e1211205078490 : check e1211205078490 [[],[]] .chain = true := by decide
def e1211205078702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e1211205078702 : Closed e1211205078702 ∧ code e1211205078702 = 5609251589806 := by decide
theorem cert_e1211205078702 : check e1211205078702 [[],[]] .chain = true := by decide
def e1211205078714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e1211205078714 : Closed e1211205078714 ∧ code e1211205078714 = 5609251589818 := by decide
theorem cert_e1211205078714 : check e1211205078714 [[],[]] .chain = true := by decide
def e1211205078762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e1211205078762 : Closed e1211205078762 ∧ code e1211205078762 = 5609251589866 := by decide
theorem cert_e1211205078762 : check e1211205078762 [[],[]] .chain = true := by decide
def e1211205078870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1211205078870 : Closed e1211205078870 ∧ code e1211205078870 = 5609251589974 := by decide
theorem cert_e1211205078870 : check e1211205078870 [[],[]] .chain = true := by decide
def e1211205078874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1211205078874 : Closed e1211205078874 ∧ code e1211205078874 = 5609251589978 := by decide
theorem cert_e1211205078874 : check e1211205078874 [[],[]] .chain = true := by decide
def e1211205078890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e1211205078890 : Closed e1211205078890 ∧ code e1211205078890 = 5609251589994 := by decide
theorem cert_e1211205078890 : check e1211205078890 [[],[]] .chain = true := by decide
def e1211205079150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211205079150 : Closed e1211205079150 ∧ code e1211205079150 = 5609251590254 := by decide
theorem cert_e1211205079150 : check e1211205079150 [[],[]] .chain = true := by decide
def e1211205079326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211205079326 : Closed e1211205079326 ∧ code e1211205079326 = 5609251590430 := by decide
theorem cert_e1211205079326 : check e1211205079326 [[],[]] .chain = true := by decide
def e1211205079522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e1211205079522 : Closed e1211205079522 ∧ code e1211205079522 = 5609251590626 := by decide
theorem cert_e1211205079522 : check e1211205079522 [[],[]] .chain = true := by decide
def e1211205079534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1211205079534 : Closed e1211205079534 ∧ code e1211205079534 = 5609251590638 := by decide
theorem cert_e1211205079534 : checkPay e1211205079534 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205079918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211205079918 : Closed e1211205079918 ∧ code e1211205079918 = 5609251591022 := by decide
theorem cert_e1211205079918 : check e1211205079918 [[],[]] .chain = true := by decide
def e1211205079926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1211205079926 : Closed e1211205079926 ∧ code e1211205079926 = 5609251591030 := by decide
theorem cert_e1211205079926 : check e1211205079926 [[],[]] .chain = true := by decide
def e1211205079982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211205079982 : Closed e1211205079982 ∧ code e1211205079982 = 5609251591086 := by decide
theorem cert_e1211205079982 : check e1211205079982 [[],[]] .chain = true := by decide
def e1211205079994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211205079994 : Closed e1211205079994 ∧ code e1211205079994 = 5609251591098 := by decide
theorem cert_e1211205079994 : check e1211205079994 [[],[]] .chain = true := by decide
def e1211205080022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1211205080022 : Closed e1211205080022 ∧ code e1211205080022 = 5609251591126 := by decide
theorem cert_e1211205080022 : check e1211205080022 [[],[]] .chain = true := by decide
def e1211205080026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211205080026 : Closed e1211205080026 ∧ code e1211205080026 = 5609251591130 := by decide
theorem cert_e1211205080026 : check e1211205080026 [[],[]] .chain = true := by decide
def e1211205080302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205080302 : Closed e1211205080302 ∧ code e1211205080302 = 5609251591406 := by decide
theorem cert_e1211205080302 : check e1211205080302 [[],[]] .chain = true := by decide
def e1211205080310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205080310 : Closed e1211205080310 ∧ code e1211205080310 = 5609251591414 := by decide
theorem cert_e1211205080310 : check e1211205080310 [[],[]] .chain = true := by decide
def e1211205080686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205080686 : Closed e1211205080686 ∧ code e1211205080686 = 5609251591790 := by decide
theorem cert_e1211205080686 : check e1211205080686 [[],[]] .chain = true := by decide
def e1211205080698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205080698 : Closed e1211205080698 ∧ code e1211205080698 = 5609251591802 := by decide
theorem cert_e1211205080698 : check e1211205080698 [[],[]] .chain = true := by decide
def e1211205080838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205080838 : Closed e1211205080838 ∧ code e1211205080838 = 5609251591942 := by decide
theorem cert_e1211205080838 : check e1211205080838 [[],[]] .chain = true := by decide
def e1211205080862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1211205080862 : Closed e1211205080862 ∧ code e1211205080862 = 5609251591966 := by decide
theorem cert_e1211205080862 : checkPay e1211205080862 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205080886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205080886 : Closed e1211205080886 ∧ code e1211205080886 = 5609251591990 := by decide
theorem cert_e1211205080886 : check e1211205080886 [[],[]] .chain = true := by decide
def e1211205080890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205080890 : Closed e1211205080890 ∧ code e1211205080890 = 5609251591994 := by decide
theorem cert_e1211205080890 : check e1211205080890 [[],[]] .chain = true := by decide
def e1211205081134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211205081134 : Closed e1211205081134 ∧ code e1211205081134 = 5609251592238 := by decide
theorem cert_e1211205081134 : check e1211205081134 [[],[]] .chain = true := by decide
def e1211205081326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211205081326 : Closed e1211205081326 ∧ code e1211205081326 = 5609251592430 := by decide
theorem cert_e1211205081326 : check e1211205081326 [[],[]] .chain = true := by decide
def e1211205081334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211205081334 : Closed e1211205081334 ∧ code e1211205081334 = 5609251592438 := by decide
theorem cert_e1211205081334 : check e1211205081334 [[],[]] .chain = true := by decide
def e1211205081518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211205081518 : Closed e1211205081518 ∧ code e1211205081518 = 5609251592622 := by decide
theorem cert_e1211205081518 : check e1211205081518 [[],[]] .chain = true := by decide
def e1211205081530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211205081530 : Closed e1211205081530 ∧ code e1211205081530 = 5609251592634 := by decide
theorem cert_e1211205081530 : check e1211205081530 [[],[]] .chain = true := by decide
def e1211205081578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211205081578 : Closed e1211205081578 ∧ code e1211205081578 = 5609251592682 := by decide
theorem cert_e1211205081578 : check e1211205081578 [[],[]] .chain = true := by decide
def e1211205081710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205081710 : Closed e1211205081710 ∧ code e1211205081710 = 5609251592814 := by decide
theorem cert_e1211205081710 : check e1211205081710 [[],[]] .chain = true := by decide
def e1211205081722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205081722 : Closed e1211205081722 ∧ code e1211205081722 = 5609251592826 := by decide
theorem cert_e1211205081722 : check e1211205081722 [[],[]] .chain = true := by decide
def e1211205081886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211205081886 : Closed e1211205081886 ∧ code e1211205081886 = 5609251592990 := by decide
theorem cert_e1211205081886 : check e1211205081886 [[],[]] .chain = true := by decide
def e1211205081986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205081986 : Closed e1211205081986 ∧ code e1211205081986 = 5609251593090 := by decide
theorem cert_e1211205081986 : check e1211205081986 [[],[]] .chain = true := by decide
def e1211205081998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211205081998 : Closed e1211205081998 ∧ code e1211205081998 = 5609251593102 := by decide
theorem cert_e1211205081998 : check e1211205081998 [[],[]] .chain = true := by decide
def e1211205082010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205082010 : Closed e1211205082010 ∧ code e1211205082010 = 5609251593114 := by decide
theorem cert_e1211205082010 : check e1211205082010 [[],[]] .chain = true := by decide
def e1211205082134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211205082134 : Closed e1211205082134 ∧ code e1211205082134 = 5609251593238 := by decide
theorem cert_e1211205082134 : check e1211205082134 [[],[]] .chain = true := by decide
def e1211205082138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205082138 : Closed e1211205082138 ∧ code e1211205082138 = 5609251593242 := by decide
theorem cert_e1211205082138 : check e1211205082138 [[],[]] .chain = true := by decide
def e1211205082182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205082182 : Closed e1211205082182 ∧ code e1211205082182 = 5609251593286 := by decide
theorem cert_e1211205082182 : check e1211205082182 [[],[]] .chain = true := by decide
def e1211205082210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211205082210 : Closed e1211205082210 ∧ code e1211205082210 = 5609251593314 := by decide
theorem cert_e1211205082210 : check e1211205082210 [[],[]] .chain = true := by decide
def e1211205082222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211205082222 : Closed e1211205082222 ∧ code e1211205082222 = 5609251593326 := by decide
theorem cert_e1211205082222 : checkPay e1211205082222 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205082230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211205082230 : Closed e1211205082230 ∧ code e1211205082230 = 5609251593334 := by decide
theorem cert_e1211205082230 : check e1211205082230 [[],[]] .chain = true := by decide
def e1211205082234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211205082234 : Closed e1211205082234 ∧ code e1211205082234 = 5609251593338 := by decide
theorem cert_e1211205082234 : checkPay e1211205082234 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e1211205082326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211205082326 : Closed e1211205082326 ∧ code e1211205082326 = 5609251593430 := by decide
theorem cert_e1211205082326 : check e1211205082326 [[],[]] .chain = true := by decide
def e1211205082330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211205082330 : Closed e1211205082330 ∧ code e1211205082330 = 5609251593434 := by decide
theorem cert_e1211205082330 : check e1211205082330 [[],[]] .chain = true := by decide
def e1211205082346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211205082346 : Closed e1211205082346 ∧ code e1211205082346 = 5609251593450 := by decide
theorem cert_e1211205082346 : check e1211205082346 [[],[]] .chain = true := by decide
def e1211205082374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205082374 : Closed e1211205082374 ∧ code e1211205082374 = 5609251593478 := by decide
theorem cert_e1211205082374 : check e1211205082374 [[],[]] .chain = true := by decide
end Blc.Floor42
