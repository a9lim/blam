import Tables
import Batch104
namespace Blc.Floor42.Grades104
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1205814877558 : ¬ IsSelfInterpreter e1205814877558 := cutM5_2 (by decide)
#print axioms ex_e1205814877558
theorem ex_e1205814877626 : ¬ IsSelfInterpreter e1205814877626 := cutM5_2 (by decide)
#print axioms ex_e1205814877626
theorem ex_e1205814883802 : ¬ IsSelfInterpreter e1205814883802 := cutM5_2 (by decide)
#print axioms ex_e1205814883802
theorem ex_e1205814883798 : ¬ IsSelfInterpreter e1205814883798 := cutM6_2 (by decide)
#print axioms ex_e1205814883798
end Blc.Floor42.Grades104
