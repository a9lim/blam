import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211273411254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e1211273411254 : Closed e1211273411254 ∧ code e1211273411254 = 5609319922358 := by decide
theorem cert_e1211273411254 : check e1211273411254 [[],[]] .sourceHead = true := by decide
def e1211273411286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e1211273411286 : Closed e1211273411286 ∧ code e1211273411286 = 5609319922390 := by decide
theorem cert_e1211273411286 : check e1211273411286 [[],[]] .sourceHead = true := by decide
def e1211273411290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))) (.var 0)))))
theorem wire_e1211273411290 : Closed e1211273411290 ∧ code e1211273411290 = 5609319922394 := by decide
theorem cert_e1211273411290 : check e1211273411290 [[],[]] .chain = true := by decide
def e1211273411414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.var 1)))))
theorem wire_e1211273411414 : Closed e1211273411414 ∧ code e1211273411414 = 5609319922518 := by decide
theorem cert_e1211273411414 : check e1211273411414 [[],[]] .sourceHead = true := by decide
def e1211273411418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1211273411418 : Closed e1211273411418 ∧ code e1211273411418 = 5609319922522 := by decide
theorem cert_e1211273411418 : check e1211273411418 [[],[]] .chain = true := by decide
def e1211273411434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1211273411434 : Closed e1211273411434 ∧ code e1211273411434 = 5609319922538 := by decide
theorem cert_e1211273411434 : check e1211273411434 [[],[]] .chain = true := by decide
def e1211273416418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.lam (.var 0))))))
theorem wire_e1211273416418 : Closed e1211273416418 ∧ code e1211273416418 = 5609319927522 := by decide
theorem cert_e1211273416418 : check e1211273416418 [[],[]] .chain = true := by decide
def e1211273416546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.lam (.var 0))))))
theorem wire_e1211273416546 : Closed e1211273416546 ∧ code e1211273416546 = 5609319927650 := by decide
theorem cert_e1211273416546 : check e1211273416546 [[],[]] .chain = true := by decide
def e1211273419638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.var 1)))))
theorem wire_e1211273419638 : Closed e1211273419638 ∧ code e1211273419638 = 5609319930742 := by decide
theorem cert_e1211273419638 : check e1211273419638 [[],[]] .sourceHead = true := by decide
def e1211273419702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 1)))))
theorem wire_e1211273419702 : Closed e1211273419702 ∧ code e1211273419702 = 5609319930806 := by decide
theorem cert_e1211273419702 : check e1211273419702 [[],[]] .sourceHead = true := by decide
def e1211273420150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.var 1)))))
theorem wire_e1211273420150 : Closed e1211273420150 ∧ code e1211273420150 = 5609319931254 := by decide
theorem cert_e1211273420150 : check e1211273420150 [[],[]] .sourceHead = true := by decide
def e1211273420218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e1211273420218 : Closed e1211273420218 ∧ code e1211273420218 = 5609319931322 := by decide
theorem cert_e1211273420218 : check e1211273420218 [[],[]] .chain = true := by decide
def e1211273420246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.var 1)))))
theorem wire_e1211273420246 : Closed e1211273420246 ∧ code e1211273420246 = 5609319931350 := by decide
theorem cert_e1211273420246 : check e1211273420246 [[],[]] .sourceHead = true := by decide
def e1211273420250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))) (.var 0)))))
theorem wire_e1211273420250 : Closed e1211273420250 ∧ code e1211273420250 = 5609319931354 := by decide
theorem cert_e1211273420250 : check e1211273420250 [[],[]] .chain = true := by decide
def e1211273420470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 1)))))
theorem wire_e1211273420470 : Closed e1211273420470 ∧ code e1211273420470 = 5609319931574 := by decide
theorem cert_e1211273420470 : check e1211273420470 [[],[]] .sourceHead = true := by decide
def e1211273420502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.var 1)))))
theorem wire_e1211273420502 : Closed e1211273420502 ∧ code e1211273420502 = 5609319931606 := by decide
theorem cert_e1211273420502 : check e1211273420502 [[],[]] .sourceHead = true := by decide
def e1211273420506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))) (.var 0)))))
theorem wire_e1211273420506 : Closed e1211273420506 ∧ code e1211273420506 = 5609319931610 := by decide
theorem cert_e1211273420506 : check e1211273420506 [[],[]] .chain = true := by decide
def e1211273422710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e1211273422710 : Closed e1211273422710 ∧ code e1211273422710 = 5609319933814 := by decide
theorem cert_e1211273422710 : check e1211273422710 [[],[]] .sourceHead = true := by decide
def e1211273422774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e1211273422774 : Closed e1211273422774 ∧ code e1211273422774 = 5609319933878 := by decide
theorem cert_e1211273422774 : check e1211273422774 [[],[]] .sourceHead = true := by decide
def e1211273425378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.lam (.var 0))))))
theorem wire_e1211273425378 : Closed e1211273425378 ∧ code e1211273425378 = 5609319936482 := by decide
theorem cert_e1211273425378 : check e1211273425378 [[],[]] .chain = true := by decide
def e1211273425782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1211273425782 : Closed e1211273425782 ∧ code e1211273425782 = 5609319936886 := by decide
theorem cert_e1211273425782 : check e1211273425782 [[],[]] .sourceHead = true := by decide
def e1211273425850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1211273425850 : Closed e1211273425850 ∧ code e1211273425850 = 5609319936954 := by decide
theorem cert_e1211273425850 : check e1211273425850 [[],[]] .chain = true := by decide
def e1211273425878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1211273425878 : Closed e1211273425878 ∧ code e1211273425878 = 5609319936982 := by decide
theorem cert_e1211273425878 : check e1211273425878 [[],[]] .sourceHead = true := by decide
def e1211273425882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1211273425882 : Closed e1211273425882 ∧ code e1211273425882 = 5609319936986 := by decide
theorem cert_e1211273425882 : check e1211273425882 [[],[]] .chain = true := by decide
def e1211273426694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273426694 : Closed e1211273426694 ∧ code e1211273426694 = 5609319937798 := by decide
theorem cert_e1211273426694 : check e1211273426694 [[],[]] .chain = true := by decide
def e1211273426742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273426742 : Closed e1211273426742 ∧ code e1211273426742 = 5609319937846 := by decide
theorem cert_e1211273426742 : check e1211273426742 [[],[]] .sourceHead = true := by decide
def e1211273426746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273426746 : Closed e1211273426746 ∧ code e1211273426746 = 5609319937850 := by decide
theorem cert_e1211273426746 : check e1211273426746 [[],[]] .sourceHead = true := by decide
def e1211273427170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.lam (.var 0))))))
theorem wire_e1211273427170 : Closed e1211273427170 ∧ code e1211273427170 = 5609319938274 := by decide
theorem cert_e1211273427170 : check e1211273427170 [[],[]] .chain = true := by decide
def e1211273427382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1211273427382 : Closed e1211273427382 ∧ code e1211273427382 = 5609319938486 := by decide
theorem cert_e1211273427382 : check e1211273427382 [[],[]] .sourceHead = true := by decide
def e1211273427414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1211273427414 : Closed e1211273427414 ∧ code e1211273427414 = 5609319938518 := by decide
theorem cert_e1211273427414 : check e1211273427414 [[],[]] .sourceHead = true := by decide
def e1211273427418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))) (.var 0)))))
theorem wire_e1211273427418 : Closed e1211273427418 ∧ code e1211273427418 = 5609319938522 := by decide
theorem cert_e1211273427418 : check e1211273427418 [[],[]] .chain = true := by decide
def e1211273427718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273427718 : Closed e1211273427718 ∧ code e1211273427718 = 5609319938822 := by decide
theorem cert_e1211273427718 : check e1211273427718 [[],[]] .chain = true := by decide
def e1211273427766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273427766 : Closed e1211273427766 ∧ code e1211273427766 = 5609319938870 := by decide
theorem cert_e1211273427766 : check e1211273427766 [[],[]] .sourceHead = true := by decide
def e1211273427770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273427770 : Closed e1211273427770 ∧ code e1211273427770 = 5609319938874 := by decide
theorem cert_e1211273427770 : check e1211273427770 [[],[]] .sourceHead = true := by decide
def e1211273430754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.lam (.var 0))))))
theorem wire_e1211273430754 : Closed e1211273430754 ∧ code e1211273430754 = 5609319941858 := by decide
theorem cert_e1211273430754 : check e1211273430754 [[],[]] .chain = true := by decide
def e1211273430946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.lam (.var 0))))))
theorem wire_e1211273430946 : Closed e1211273430946 ∧ code e1211273430946 = 5609319942050 := by decide
theorem cert_e1211273430946 : check e1211273430946 [[],[]] .chain = true := by decide
def e1211273432438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.var 1)))))
theorem wire_e1211273432438 : Closed e1211273432438 ∧ code e1211273432438 = 5609319943542 := by decide
theorem cert_e1211273432438 : check e1211273432438 [[],[]] .sourceHead = true := by decide
def e1211273432506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e1211273432506 : Closed e1211273432506 ∧ code e1211273432506 = 5609319943610 := by decide
theorem cert_e1211273432506 : check e1211273432506 [[],[]] .chain = true := by decide
def e1211273432534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.var 1)))))
theorem wire_e1211273432534 : Closed e1211273432534 ∧ code e1211273432534 = 5609319943638 := by decide
theorem cert_e1211273432534 : check e1211273432534 [[],[]] .sourceHead = true := by decide
def e1211273432538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)))))
theorem wire_e1211273432538 : Closed e1211273432538 ∧ code e1211273432538 = 5609319943642 := by decide
theorem cert_e1211273432538 : check e1211273432538 [[],[]] .chain = true := by decide
def e1211273432762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))) (.var 0)))))
theorem wire_e1211273432762 : Closed e1211273432762 ∧ code e1211273432762 = 5609319943866 := by decide
theorem cert_e1211273432762 : check e1211273432762 [[],[]] .chain = true := by decide
def e1211273432810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e1211273432810 : Closed e1211273432810 ∧ code e1211273432810 = 5609319943914 := by decide
theorem cert_e1211273432810 : check e1211273432810 [[],[]] .chain = true := by decide
def e1211273432918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.var 1)))))
theorem wire_e1211273432918 : Closed e1211273432918 ∧ code e1211273432918 = 5609319944022 := by decide
theorem cert_e1211273432918 : check e1211273432918 [[],[]] .sourceHead = true := by decide
def e1211273432922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))) (.var 0)))))
theorem wire_e1211273432922 : Closed e1211273432922 ∧ code e1211273432922 = 5609319944026 := by decide
theorem cert_e1211273432922 : check e1211273432922 [[],[]] .chain = true := by decide
def e1211273432938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))) (.var 0)))))
theorem wire_e1211273432938 : Closed e1211273432938 ∧ code e1211273432938 = 5609319944042 := by decide
theorem cert_e1211273432938 : check e1211273432938 [[],[]] .chain = true := by decide
def e1211273433570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.lam (.var 0))))))
theorem wire_e1211273433570 : Closed e1211273433570 ∧ code e1211273433570 = 5609319944674 := by decide
theorem cert_e1211273433570 : check e1211273433570 [[],[]] .chain = true := by decide
def e1211273433974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e1211273433974 : Closed e1211273433974 ∧ code e1211273433974 = 5609319945078 := by decide
theorem cert_e1211273433974 : check e1211273433974 [[],[]] .sourceHead = true := by decide
def e1211273434042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1211273434042 : Closed e1211273434042 ∧ code e1211273434042 = 5609319945146 := by decide
theorem cert_e1211273434042 : check e1211273434042 [[],[]] .chain = true := by decide
def e1211273434070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e1211273434070 : Closed e1211273434070 ∧ code e1211273434070 = 5609319945174 := by decide
theorem cert_e1211273434070 : check e1211273434070 [[],[]] .sourceHead = true := by decide
def e1211273434074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1211273434074 : Closed e1211273434074 ∧ code e1211273434074 = 5609319945178 := by decide
theorem cert_e1211273434074 : check e1211273434074 [[],[]] .chain = true := by decide
def e1211273434886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273434886 : Closed e1211273434886 ∧ code e1211273434886 = 5609319945990 := by decide
theorem cert_e1211273434886 : check e1211273434886 [[],[]] .chain = true := by decide
def e1211273434934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273434934 : Closed e1211273434934 ∧ code e1211273434934 = 5609319946038 := by decide
theorem cert_e1211273434934 : check e1211273434934 [[],[]] .sourceHead = true := by decide
def e1211273434938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273434938 : Closed e1211273434938 ∧ code e1211273434938 = 5609319946042 := by decide
theorem cert_e1211273434938 : check e1211273434938 [[],[]] .sourceHead = true := by decide
def e1211273435578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1211273435578 : Closed e1211273435578 ∧ code e1211273435578 = 5609319946682 := by decide
theorem cert_e1211273435578 : check e1211273435578 [[],[]] .chain = true := by decide
def e1211273435626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1211273435626 : Closed e1211273435626 ∧ code e1211273435626 = 5609319946730 := by decide
theorem cert_e1211273435626 : check e1211273435626 [[],[]] .chain = true := by decide
def e1211273436258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.lam (.var 0))))))
theorem wire_e1211273436258 : Closed e1211273436258 ∧ code e1211273436258 = 5609319947362 := by decide
theorem cert_e1211273436258 : check e1211273436258 [[],[]] .chain = true := by decide
def e1211273436374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.var 1)))))
theorem wire_e1211273436374 : Closed e1211273436374 ∧ code e1211273436374 = 5609319947478 := by decide
theorem cert_e1211273436374 : check e1211273436374 [[],[]] .sourceHead = true := by decide
def e1211273436378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1211273436378 : Closed e1211273436378 ∧ code e1211273436378 = 5609319947482 := by decide
theorem cert_e1211273436378 : check e1211273436378 [[],[]] .chain = true := by decide
def e1211273436394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1211273436394 : Closed e1211273436394 ∧ code e1211273436394 = 5609319947498 := by decide
theorem cert_e1211273436394 : check e1211273436394 [[],[]] .chain = true := by decide
def e1211273436422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273436422 : Closed e1211273436422 ∧ code e1211273436422 = 5609319947526 := by decide
theorem cert_e1211273436422 : check e1211273436422 [[],[]] .chain = true := by decide
def e1211273436470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273436470 : Closed e1211273436470 ∧ code e1211273436470 = 5609319947574 := by decide
theorem cert_e1211273436470 : check e1211273436470 [[],[]] .sourceHead = true := by decide
def e1211273436474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273436474 : Closed e1211273436474 ∧ code e1211273436474 = 5609319947578 := by decide
theorem cert_e1211273436474 : check e1211273436474 [[],[]] .sourceHead = true := by decide
def e1211273438050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.lam (.var 0))))))
theorem wire_e1211273438050 : Closed e1211273438050 ∧ code e1211273438050 = 5609319949154 := by decide
theorem cert_e1211273438050 : check e1211273438050 [[],[]] .chain = true := by decide
def e1211273438114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.lam (.var 0))))))
theorem wire_e1211273438114 : Closed e1211273438114 ∧ code e1211273438114 = 5609319949218 := by decide
theorem cert_e1211273438114 : check e1211273438114 [[],[]] .chain = true := by decide
def e1211273438902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 1)))))
theorem wire_e1211273438902 : Closed e1211273438902 ∧ code e1211273438902 = 5609319950006 := by decide
theorem cert_e1211273438902 : check e1211273438902 [[],[]] .sourceHead = true := by decide
def e1211273438934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.var 1)))))
theorem wire_e1211273438934 : Closed e1211273438934 ∧ code e1211273438934 = 5609319950038 := by decide
theorem cert_e1211273438934 : check e1211273438934 [[],[]] .sourceHead = true := by decide
def e1211273438938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))) (.var 0)))))
theorem wire_e1211273438938 : Closed e1211273438938 ∧ code e1211273438938 = 5609319950042 := by decide
theorem cert_e1211273438938 : check e1211273438938 [[],[]] .chain = true := by decide
def e1211273439062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.var 1)))))
theorem wire_e1211273439062 : Closed e1211273439062 ∧ code e1211273439062 = 5609319950166 := by decide
theorem cert_e1211273439062 : check e1211273439062 [[],[]] .sourceHead = true := by decide
def e1211273439066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))) (.var 0)))))
theorem wire_e1211273439066 : Closed e1211273439066 ∧ code e1211273439066 = 5609319950170 := by decide
theorem cert_e1211273439066 : check e1211273439066 [[],[]] .chain = true := by decide
def e1211273439082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))) (.var 0)))))
theorem wire_e1211273439082 : Closed e1211273439082 ∧ code e1211273439082 = 5609319950186 := by decide
theorem cert_e1211273439082 : check e1211273439082 [[],[]] .chain = true := by decide
def e1211273439458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.lam (.var 0))))))
theorem wire_e1211273439458 : Closed e1211273439458 ∧ code e1211273439458 = 5609319950562 := by decide
theorem cert_e1211273439458 : check e1211273439458 [[],[]] .chain = true := by decide
def e1211273439670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e1211273439670 : Closed e1211273439670 ∧ code e1211273439670 = 5609319950774 := by decide
theorem cert_e1211273439670 : check e1211273439670 [[],[]] .sourceHead = true := by decide
def e1211273439702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e1211273439702 : Closed e1211273439702 ∧ code e1211273439702 = 5609319950806 := by decide
theorem cert_e1211273439702 : check e1211273439702 [[],[]] .sourceHead = true := by decide
def e1211273439706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))) (.var 0)))))
theorem wire_e1211273439706 : Closed e1211273439706 ∧ code e1211273439706 = 5609319950810 := by decide
theorem cert_e1211273439706 : check e1211273439706 [[],[]] .chain = true := by decide
def e1211273440006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273440006 : Closed e1211273440006 ∧ code e1211273440006 = 5609319951110 := by decide
theorem cert_e1211273440006 : check e1211273440006 [[],[]] .chain = true := by decide
def e1211273440054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273440054 : Closed e1211273440054 ∧ code e1211273440054 = 5609319951158 := by decide
theorem cert_e1211273440054 : check e1211273440054 [[],[]] .sourceHead = true := by decide
def e1211273440058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273440058 : Closed e1211273440058 ∧ code e1211273440058 = 5609319951162 := by decide
theorem cert_e1211273440058 : check e1211273440058 [[],[]] .sourceHead = true := by decide
def e1211273440354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.lam (.var 0))))))
theorem wire_e1211273440354 : Closed e1211273440354 ∧ code e1211273440354 = 5609319951458 := by decide
theorem cert_e1211273440354 : check e1211273440354 [[],[]] .chain = true := by decide
def e1211273440470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.var 1)))))
theorem wire_e1211273440470 : Closed e1211273440470 ∧ code e1211273440470 = 5609319951574 := by decide
theorem cert_e1211273440470 : check e1211273440470 [[],[]] .sourceHead = true := by decide
def e1211273440474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1211273440474 : Closed e1211273440474 ∧ code e1211273440474 = 5609319951578 := by decide
theorem cert_e1211273440474 : check e1211273440474 [[],[]] .chain = true := by decide
def e1211273440490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1211273440490 : Closed e1211273440490 ∧ code e1211273440490 = 5609319951594 := by decide
theorem cert_e1211273440490 : check e1211273440490 [[],[]] .chain = true := by decide
def e1211273440518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273440518 : Closed e1211273440518 ∧ code e1211273440518 = 5609319951622 := by decide
theorem cert_e1211273440518 : check e1211273440518 [[],[]] .chain = true := by decide
def e1211273440566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273440566 : Closed e1211273440566 ∧ code e1211273440566 = 5609319951670 := by decide
theorem cert_e1211273440566 : check e1211273440566 [[],[]] .sourceHead = true := by decide
def e1211273440570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273440570 : Closed e1211273440570 ∧ code e1211273440570 = 5609319951674 := by decide
theorem cert_e1211273440570 : check e1211273440570 [[],[]] .sourceHead = true := by decide
def e1211273453302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))) (.var 1)))))
theorem wire_e1211273453302 : Closed e1211273453302 ∧ code e1211273453302 = 5609319964406 := by decide
theorem cert_e1211273453302 : check e1211273453302 [[],[]] .sourceHead = true := by decide
def e1211273453430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))) (.var 1)))))
theorem wire_e1211273453430 : Closed e1211273453430 ∧ code e1211273453430 = 5609319964534 := by decide
theorem cert_e1211273453430 : check e1211273453430 [[],[]] .sourceHead = true := by decide
def e1211273468790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e1211273468790 : Closed e1211273468790 ∧ code e1211273468790 = 5609319979894 := by decide
theorem cert_e1211273468790 : check e1211273468790 [[],[]] .sourceHead = true := by decide
def e1211273468854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e1211273468854 : Closed e1211273468854 ∧ code e1211273468854 = 5609319979958 := by decide
theorem cert_e1211273468854 : check e1211273468854 [[],[]] .sourceHead = true := by decide
def e1211273469302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e1211273469302 : Closed e1211273469302 ∧ code e1211273469302 = 5609319980406 := by decide
theorem cert_e1211273469302 : check e1211273469302 [[],[]] .sourceHead = true := by decide
def e1211273469370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1211273469370 : Closed e1211273469370 ∧ code e1211273469370 = 5609319980474 := by decide
theorem cert_e1211273469370 : check e1211273469370 [[],[]] .chain = true := by decide
def e1211273469398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e1211273469398 : Closed e1211273469398 ∧ code e1211273469398 = 5609319980502 := by decide
theorem cert_e1211273469398 : check e1211273469398 [[],[]] .sourceHead = true := by decide
def e1211273469402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1211273469402 : Closed e1211273469402 ∧ code e1211273469402 = 5609319980506 := by decide
theorem cert_e1211273469402 : check e1211273469402 [[],[]] .chain = true := by decide
def e1211273469622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e1211273469622 : Closed e1211273469622 ∧ code e1211273469622 = 5609319980726 := by decide
theorem cert_e1211273469622 : check e1211273469622 [[],[]] .sourceHead = true := by decide
def e1211273469654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e1211273469654 : Closed e1211273469654 ∧ code e1211273469654 = 5609319980758 := by decide
theorem cert_e1211273469654 : check e1211273469654 [[],[]] .sourceHead = true := by decide
def e1211273469658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))) (.var 0)))))
theorem wire_e1211273469658 : Closed e1211273469658 ∧ code e1211273469658 = 5609319980762 := by decide
theorem cert_e1211273469658 : check e1211273469658 [[],[]] .chain = true := by decide
def e1211273471862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e1211273471862 : Closed e1211273471862 ∧ code e1211273471862 = 5609319982966 := by decide
theorem cert_e1211273471862 : check e1211273471862 [[],[]] .sourceHead = true := by decide
def e1211273471926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e1211273471926 : Closed e1211273471926 ∧ code e1211273471926 = 5609319983030 := by decide
theorem cert_e1211273471926 : check e1211273471926 [[],[]] .sourceHead = true := by decide
def e1211273474530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.lam (.var 0))))))
theorem wire_e1211273474530 : Closed e1211273474530 ∧ code e1211273474530 = 5609319985634 := by decide
theorem cert_e1211273474530 : check e1211273474530 [[],[]] .chain = true := by decide
def e1211273474934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e1211273474934 : Closed e1211273474934 ∧ code e1211273474934 = 5609319986038 := by decide
theorem cert_e1211273474934 : check e1211273474934 [[],[]] .sourceHead = true := by decide
def e1211273475002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211273475002 : Closed e1211273475002 ∧ code e1211273475002 = 5609319986106 := by decide
theorem cert_e1211273475002 : check e1211273475002 [[],[]] .chain = true := by decide
def e1211273475030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e1211273475030 : Closed e1211273475030 ∧ code e1211273475030 = 5609319986134 := by decide
theorem cert_e1211273475030 : check e1211273475030 [[],[]] .sourceHead = true := by decide
def e1211273475034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211273475034 : Closed e1211273475034 ∧ code e1211273475034 = 5609319986138 := by decide
theorem cert_e1211273475034 : check e1211273475034 [[],[]] .chain = true := by decide
def e1211273475846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273475846 : Closed e1211273475846 ∧ code e1211273475846 = 5609319986950 := by decide
theorem cert_e1211273475846 : check e1211273475846 [[],[]] .chain = true := by decide
def e1211273475894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273475894 : Closed e1211273475894 ∧ code e1211273475894 = 5609319986998 := by decide
theorem cert_e1211273475894 : check e1211273475894 [[],[]] .sourceHead = true := by decide
def e1211273475898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273475898 : Closed e1211273475898 ∧ code e1211273475898 = 5609319987002 := by decide
theorem cert_e1211273475898 : check e1211273475898 [[],[]] .sourceHead = true := by decide
def e1211273476322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.lam (.var 0))))))
theorem wire_e1211273476322 : Closed e1211273476322 ∧ code e1211273476322 = 5609319987426 := by decide
theorem cert_e1211273476322 : check e1211273476322 [[],[]] .chain = true := by decide
def e1211273476534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e1211273476534 : Closed e1211273476534 ∧ code e1211273476534 = 5609319987638 := by decide
theorem cert_e1211273476534 : check e1211273476534 [[],[]] .sourceHead = true := by decide
def e1211273476566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e1211273476566 : Closed e1211273476566 ∧ code e1211273476566 = 5609319987670 := by decide
theorem cert_e1211273476566 : check e1211273476566 [[],[]] .sourceHead = true := by decide
def e1211273476570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))) (.var 0)))))
theorem wire_e1211273476570 : Closed e1211273476570 ∧ code e1211273476570 = 5609319987674 := by decide
theorem cert_e1211273476570 : check e1211273476570 [[],[]] .chain = true := by decide
def e1211273476870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273476870 : Closed e1211273476870 ∧ code e1211273476870 = 5609319987974 := by decide
theorem cert_e1211273476870 : check e1211273476870 [[],[]] .chain = true := by decide
def e1211273476918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273476918 : Closed e1211273476918 ∧ code e1211273476918 = 5609319988022 := by decide
theorem cert_e1211273476918 : check e1211273476918 [[],[]] .sourceHead = true := by decide
def e1211273476922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273476922 : Closed e1211273476922 ∧ code e1211273476922 = 5609319988026 := by decide
theorem cert_e1211273476922 : check e1211273476922 [[],[]] .sourceHead = true := by decide
def e1211273514742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))) (.var 1)))))
theorem wire_e1211273514742 : Closed e1211273514742 ∧ code e1211273514742 = 5609320025846 := by decide
theorem cert_e1211273514742 : check e1211273514742 [[],[]] .sourceHead = true := by decide
def e1211273514934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))) (.var 1)))))
theorem wire_e1211273514934 : Closed e1211273514934 ∧ code e1211273514934 = 5609320026038 := by decide
theorem cert_e1211273514934 : check e1211273514934 [[],[]] .sourceHead = true := by decide
def e1211273522550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e1211273522550 : Closed e1211273522550 ∧ code e1211273522550 = 5609320033654 := by decide
theorem cert_e1211273522550 : check e1211273522550 [[],[]] .sourceHead = true := by decide
def e1211273522618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1211273522618 : Closed e1211273522618 ∧ code e1211273522618 = 5609320033722 := by decide
theorem cert_e1211273522618 : check e1211273522618 [[],[]] .chain = true := by decide
def e1211273522646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e1211273522646 : Closed e1211273522646 ∧ code e1211273522646 = 5609320033750 := by decide
theorem cert_e1211273522646 : check e1211273522646 [[],[]] .sourceHead = true := by decide
def e1211273522650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1211273522650 : Closed e1211273522650 ∧ code e1211273522650 = 5609320033754 := by decide
theorem cert_e1211273522650 : check e1211273522650 [[],[]] .chain = true := by decide
def e1211273522874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1211273522874 : Closed e1211273522874 ∧ code e1211273522874 = 5609320033978 := by decide
theorem cert_e1211273522874 : check e1211273522874 [[],[]] .chain = true := by decide
def e1211273522922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1211273522922 : Closed e1211273522922 ∧ code e1211273522922 = 5609320034026 := by decide
theorem cert_e1211273522922 : check e1211273522922 [[],[]] .chain = true := by decide
def e1211273523030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.var 1)))))
theorem wire_e1211273523030 : Closed e1211273523030 ∧ code e1211273523030 = 5609320034134 := by decide
theorem cert_e1211273523030 : check e1211273523030 [[],[]] .sourceHead = true := by decide
def e1211273523034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1211273523034 : Closed e1211273523034 ∧ code e1211273523034 = 5609320034138 := by decide
theorem cert_e1211273523034 : check e1211273523034 [[],[]] .chain = true := by decide
def e1211273523050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1211273523050 : Closed e1211273523050 ∧ code e1211273523050 = 5609320034154 := by decide
theorem cert_e1211273523050 : check e1211273523050 [[],[]] .chain = true := by decide
def e1211273523682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.lam (.var 0))))))
theorem wire_e1211273523682 : Closed e1211273523682 ∧ code e1211273523682 = 5609320034786 := by decide
theorem cert_e1211273523682 : check e1211273523682 [[],[]] .chain = true := by decide
def e1211273524086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e1211273524086 : Closed e1211273524086 ∧ code e1211273524086 = 5609320035190 := by decide
theorem cert_e1211273524086 : check e1211273524086 [[],[]] .sourceHead = true := by decide
def e1211273524154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211273524154 : Closed e1211273524154 ∧ code e1211273524154 = 5609320035258 := by decide
theorem cert_e1211273524154 : check e1211273524154 [[],[]] .chain = true := by decide
def e1211273524182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e1211273524182 : Closed e1211273524182 ∧ code e1211273524182 = 5609320035286 := by decide
theorem cert_e1211273524182 : check e1211273524182 [[],[]] .sourceHead = true := by decide
def e1211273524186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211273524186 : Closed e1211273524186 ∧ code e1211273524186 = 5609320035290 := by decide
theorem cert_e1211273524186 : check e1211273524186 [[],[]] .chain = true := by decide
def e1211273524998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273524998 : Closed e1211273524998 ∧ code e1211273524998 = 5609320036102 := by decide
theorem cert_e1211273524998 : check e1211273524998 [[],[]] .chain = true := by decide
def e1211273525046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273525046 : Closed e1211273525046 ∧ code e1211273525046 = 5609320036150 := by decide
theorem cert_e1211273525046 : check e1211273525046 [[],[]] .sourceHead = true := by decide
def e1211273525050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273525050 : Closed e1211273525050 ∧ code e1211273525050 = 5609320036154 := by decide
theorem cert_e1211273525050 : check e1211273525050 [[],[]] .sourceHead = true := by decide
def e1211273525690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1211273525690 : Closed e1211273525690 ∧ code e1211273525690 = 5609320036794 := by decide
theorem cert_e1211273525690 : check e1211273525690 [[],[]] .chain = true := by decide
def e1211273525738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1211273525738 : Closed e1211273525738 ∧ code e1211273525738 = 5609320036842 := by decide
theorem cert_e1211273525738 : check e1211273525738 [[],[]] .chain = true := by decide
def e1211273526370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.lam (.var 0))))))
theorem wire_e1211273526370 : Closed e1211273526370 ∧ code e1211273526370 = 5609320037474 := by decide
theorem cert_e1211273526370 : check e1211273526370 [[],[]] .chain = true := by decide
def e1211273526486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.var 1)))))
theorem wire_e1211273526486 : Closed e1211273526486 ∧ code e1211273526486 = 5609320037590 := by decide
theorem cert_e1211273526486 : check e1211273526486 [[],[]] .sourceHead = true := by decide
def e1211273526490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1211273526490 : Closed e1211273526490 ∧ code e1211273526490 = 5609320037594 := by decide
theorem cert_e1211273526490 : check e1211273526490 [[],[]] .chain = true := by decide
def e1211273526506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1211273526506 : Closed e1211273526506 ∧ code e1211273526506 = 5609320037610 := by decide
theorem cert_e1211273526506 : check e1211273526506 [[],[]] .chain = true := by decide
def e1211273526534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273526534 : Closed e1211273526534 ∧ code e1211273526534 = 5609320037638 := by decide
theorem cert_e1211273526534 : check e1211273526534 [[],[]] .chain = true := by decide
def e1211273526582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273526582 : Closed e1211273526582 ∧ code e1211273526582 = 5609320037686 := by decide
theorem cert_e1211273526582 : check e1211273526582 [[],[]] .sourceHead = true := by decide
def e1211273526586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273526586 : Closed e1211273526586 ∧ code e1211273526586 = 5609320037690 := by decide
theorem cert_e1211273526586 : check e1211273526586 [[],[]] .sourceHead = true := by decide
def e1211273545590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e1211273545590 : Closed e1211273545590 ∧ code e1211273545590 = 5609320056694 := by decide
theorem cert_e1211273545590 : check e1211273545590 [[],[]] .sourceHead = true := by decide
def e1211273545654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e1211273545654 : Closed e1211273545654 ∧ code e1211273545654 = 5609320056758 := by decide
theorem cert_e1211273545654 : check e1211273545654 [[],[]] .sourceHead = true := by decide
def e1211273549494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e1211273549494 : Closed e1211273549494 ∧ code e1211273549494 = 5609320060598 := by decide
theorem cert_e1211273549494 : check e1211273549494 [[],[]] .sourceHead = true := by decide
def e1211273549526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e1211273549526 : Closed e1211273549526 ∧ code e1211273549526 = 5609320060630 := by decide
theorem cert_e1211273549526 : check e1211273549526 [[],[]] .sourceHead = true := by decide
def e1211273549530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))) (.var 0)))))
theorem wire_e1211273549530 : Closed e1211273549530 ∧ code e1211273549530 = 5609320060634 := by decide
theorem cert_e1211273549530 : check e1211273549530 [[],[]] .chain = true := by decide
def e1211273549654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.var 1)))))
theorem wire_e1211273549654 : Closed e1211273549654 ∧ code e1211273549654 = 5609320060758 := by decide
theorem cert_e1211273549654 : check e1211273549654 [[],[]] .sourceHead = true := by decide
def e1211273549658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1211273549658 : Closed e1211273549658 ∧ code e1211273549658 = 5609320060762 := by decide
theorem cert_e1211273549658 : check e1211273549658 [[],[]] .chain = true := by decide
def e1211273549674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1211273549674 : Closed e1211273549674 ∧ code e1211273549674 = 5609320060778 := by decide
theorem cert_e1211273549674 : check e1211273549674 [[],[]] .chain = true := by decide
def e1211273550050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.lam (.var 0))))))
theorem wire_e1211273550050 : Closed e1211273550050 ∧ code e1211273550050 = 5609320061154 := by decide
theorem cert_e1211273550050 : check e1211273550050 [[],[]] .chain = true := by decide
def e1211273550262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e1211273550262 : Closed e1211273550262 ∧ code e1211273550262 = 5609320061366 := by decide
theorem cert_e1211273550262 : check e1211273550262 [[],[]] .sourceHead = true := by decide
def e1211273550294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e1211273550294 : Closed e1211273550294 ∧ code e1211273550294 = 5609320061398 := by decide
theorem cert_e1211273550294 : check e1211273550294 [[],[]] .sourceHead = true := by decide
def e1211273550298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.var 0)))))
theorem wire_e1211273550298 : Closed e1211273550298 ∧ code e1211273550298 = 5609320061402 := by decide
theorem cert_e1211273550298 : check e1211273550298 [[],[]] .chain = true := by decide
def e1211273550598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273550598 : Closed e1211273550598 ∧ code e1211273550598 = 5609320061702 := by decide
theorem cert_e1211273550598 : check e1211273550598 [[],[]] .chain = true := by decide
def e1211273550646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 0) (.var 1))))))
theorem wire_e1211273550646 : Closed e1211273550646 ∧ code e1211273550646 = 5609320061750 := by decide
theorem cert_e1211273550646 : check e1211273550646 [[],[]] .sourceHead = true := by decide
def e1211273550650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 1) (.var 0))))))
theorem wire_e1211273550650 : Closed e1211273550650 ∧ code e1211273550650 = 5609320061754 := by decide
theorem cert_e1211273550650 : check e1211273550650 [[],[]] .sourceHead = true := by decide
def e1211273550946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.lam (.var 0))))))
theorem wire_e1211273550946 : Closed e1211273550946 ∧ code e1211273550946 = 5609320062050 := by decide
theorem cert_e1211273550946 : check e1211273550946 [[],[]] .chain = true := by decide
def e1211273551062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.var 1)))))
theorem wire_e1211273551062 : Closed e1211273551062 ∧ code e1211273551062 = 5609320062166 := by decide
theorem cert_e1211273551062 : check e1211273551062 [[],[]] .sourceHead = true := by decide
def e1211273551066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1211273551066 : Closed e1211273551066 ∧ code e1211273551066 = 5609320062170 := by decide
theorem cert_e1211273551066 : check e1211273551066 [[],[]] .chain = true := by decide
def e1211273551082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1211273551082 : Closed e1211273551082 ∧ code e1211273551082 = 5609320062186 := by decide
theorem cert_e1211273551082 : check e1211273551082 [[],[]] .chain = true := by decide
def e1211273551110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.var 1)))))))
theorem wire_e1211273551110 : Closed e1211273551110 ∧ code e1211273551110 = 5609320062214 := by decide
theorem cert_e1211273551110 : check e1211273551110 [[],[]] .chain = true := by decide
end Blc.Floor42
