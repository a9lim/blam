import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800948910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e302800948910 : Closed e302800948910 ∧ code e302800948910 = 4700847460014 := by decide
theorem cert_e302800948910 : check e302800948910 [[.under],[.under]] .three = true := by decide
def e302800948922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e302800948922 : Closed e302800948922 ∧ code e302800948922 = 4700847460026 := by decide
theorem cert_e302800948922 : check e302800948922 [[.under],[.under]] .three = true := by decide
def e302800948970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302800948970 : Closed e302800948970 ∧ code e302800948970 = 4700847460074 := by decide
theorem cert_e302800948970 : check e302800948970 [[.under],[.under]] .three = true := by decide
def e302800949078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302800949078 : Closed e302800949078 ∧ code e302800949078 = 4700847460182 := by decide
theorem cert_e302800949078 : check e302800949078 [[.under],[.under]] .three = true := by decide
def e302800949082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302800949082 : Closed e302800949082 ∧ code e302800949082 = 4700847460186 := by decide
theorem cert_e302800949082 : check e302800949082 [[.under],[.under]] .three = true := by decide
def e302800949098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302800949098 : Closed e302800949098 ∧ code e302800949098 = 4700847460202 := by decide
theorem cert_e302800949098 : check e302800949098 [[.under],[.under]] .three = true := by decide
def e302800950126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302800950126 : Closed e302800950126 ∧ code e302800950126 = 4700847461230 := by decide
theorem cert_e302800950126 : check e302800950126 [[.under],[.under]] .three = true := by decide
def e302800950134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302800950134 : Closed e302800950134 ∧ code e302800950134 = 4700847461238 := by decide
theorem cert_e302800950134 : check e302800950134 [[.under],[.under]] .three = true := by decide
def e302800950190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302800950190 : Closed e302800950190 ∧ code e302800950190 = 4700847461294 := by decide
theorem cert_e302800950190 : check e302800950190 [[.under],[.under]] .three = true := by decide
def e302800950202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302800950202 : Closed e302800950202 ∧ code e302800950202 = 4700847461306 := by decide
theorem cert_e302800950202 : check e302800950202 [[.under],[.under]] .three = true := by decide
def e302800950230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302800950230 : Closed e302800950230 ∧ code e302800950230 = 4700847461334 := by decide
theorem cert_e302800950230 : check e302800950230 [[.under],[.under]] .three = true := by decide
def e302800950234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302800950234 : Closed e302800950234 ∧ code e302800950234 = 4700847461338 := by decide
theorem cert_e302800950234 : check e302800950234 [[.under],[.under]] .three = true := by decide
def e302800950510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302800950510 : Closed e302800950510 ∧ code e302800950510 = 4700847461614 := by decide
theorem cert_e302800950510 : check e302800950510 [[.under],[.under]] .three = true := by decide
def e302800950518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302800950518 : Closed e302800950518 ∧ code e302800950518 = 4700847461622 := by decide
theorem cert_e302800950518 : check e302800950518 [[.under],[.under]] .three = true := by decide
def e302800950894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302800950894 : Closed e302800950894 ∧ code e302800950894 = 4700847461998 := by decide
theorem cert_e302800950894 : check e302800950894 [[.under],[.under]] .three = true := by decide
def e302800950906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302800950906 : Closed e302800950906 ∧ code e302800950906 = 4700847462010 := by decide
theorem cert_e302800950906 : check e302800950906 [[.under],[.under]] .three = true := by decide
def e302800951094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302800951094 : Closed e302800951094 ∧ code e302800951094 = 4700847462198 := by decide
theorem cert_e302800951094 : check e302800951094 [[.under],[.under]] .three = true := by decide
def e302800951098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302800951098 : Closed e302800951098 ∧ code e302800951098 = 4700847462202 := by decide
theorem cert_e302800951098 : check e302800951098 [[.under],[.under]] .three = true := by decide
def e302800951726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e302800951726 : Closed e302800951726 ∧ code e302800951726 = 4700847462830 := by decide
theorem cert_e302800951726 : check e302800951726 [[.under],[.under]] .three = true := by decide
def e302800951738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e302800951738 : Closed e302800951738 ∧ code e302800951738 = 4700847462842 := by decide
theorem cert_e302800951738 : check e302800951738 [[.under],[.under]] .three = true := by decide
def e302800951786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e302800951786 : Closed e302800951786 ∧ code e302800951786 = 4700847462890 := by decide
theorem cert_e302800951786 : check e302800951786 [[.under],[.under]] .three = true := by decide
def e302800951918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e302800951918 : Closed e302800951918 ∧ code e302800951918 = 4700847463022 := by decide
theorem cert_e302800951918 : check e302800951918 [[.under],[.under]] .three = true := by decide
def e302800951930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e302800951930 : Closed e302800951930 ∧ code e302800951930 = 4700847463034 := by decide
theorem cert_e302800951930 : check e302800951930 [[.under],[.under]] .three = true := by decide
def e302800952218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e302800952218 : Closed e302800952218 ∧ code e302800952218 = 4700847463322 := by decide
theorem cert_e302800952218 : check e302800952218 [[.under],[.under]] .three = true := by decide
def e302800952534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302800952534 : Closed e302800952534 ∧ code e302800952534 = 4700847463638 := by decide
theorem cert_e302800952534 : check e302800952534 [[.under],[.under]] .three = true := by decide
def e302800952538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302800952538 : Closed e302800952538 ∧ code e302800952538 = 4700847463642 := by decide
theorem cert_e302800952538 : check e302800952538 [[.under],[.under]] .three = true := by decide
def e302800952554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302800952554 : Closed e302800952554 ∧ code e302800952554 = 4700847463658 := by decide
theorem cert_e302800952554 : check e302800952554 [[.under],[.under]] .three = true := by decide
def e302800952630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302800952630 : Closed e302800952630 ∧ code e302800952630 = 4700847463734 := by decide
theorem cert_e302800952630 : check e302800952630 [[.under],[.under]] .three = true := by decide
def e302800952634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302800952634 : Closed e302800952634 ∧ code e302800952634 = 4700847463738 := by decide
theorem cert_e302800952634 : check e302800952634 [[.under],[.under]] .three = true := by decide
def e302800952730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302800952730 : Closed e302800952730 ∧ code e302800952730 = 4700847463834 := by decide
theorem cert_e302800952730 : check e302800952730 [[.under],[.under]] .three = true := by decide
def e302801055198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 3)))))))
theorem wire_e302801055198 : Closed e302801055198 ∧ code e302801055198 = 4700847566302 := by decide
theorem cert_e302801055198 : check e302801055198 [[.under],[.under]] .three = true := by decide
def e302801055214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 2)))))))
theorem wire_e302801055214 : Closed e302801055214 ∧ code e302801055214 = 4700847566318 := by decide
theorem cert_e302801055214 : check e302801055214 [[.under],[.under]] .three = true := by decide
def e302801055454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 3)))))))
theorem wire_e302801055454 : Closed e302801055454 ∧ code e302801055454 = 4700847566558 := by decide
theorem cert_e302801055454 : check e302801055454 [[.under],[.under]] .three = true := by decide
def e302801055478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 1)))))))
theorem wire_e302801055478 : Closed e302801055478 ∧ code e302801055478 = 4700847566582 := by decide
theorem cert_e302801055478 : check e302801055478 [[.under],[.under]] .three = true := by decide
def e302801055598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 2)))))))
theorem wire_e302801055598 : Closed e302801055598 ∧ code e302801055598 = 4700847566702 := by decide
theorem cert_e302801055598 : check e302801055598 [[.under],[.under]] .three = true := by decide
def e302801055606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 1)))))))
theorem wire_e302801055606 : Closed e302801055606 ∧ code e302801055606 = 4700847566710 := by decide
theorem cert_e302801055606 : check e302801055606 [[.under],[.under]] .three = true := by decide
def e302801057246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e302801057246 : Closed e302801057246 ∧ code e302801057246 = 4700847568350 := by decide
theorem cert_e302801057246 : check e302801057246 [[.under],[.under]] .three = true := by decide
def e302801057262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e302801057262 : Closed e302801057262 ∧ code e302801057262 = 4700847568366 := by decide
theorem cert_e302801057262 : check e302801057262 [[.under],[.under]] .three = true := by decide
def e302801057630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e302801057630 : Closed e302801057630 ∧ code e302801057630 = 4700847568734 := by decide
theorem cert_e302801057630 : check e302801057630 [[.under],[.under]] .three = true := by decide
def e302801057658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e302801057658 : Closed e302801057658 ∧ code e302801057658 = 4700847568762 := by decide
theorem cert_e302801057658 : check e302801057658 [[.under],[.under]] .three = true := by decide
def e302801057710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e302801057710 : Closed e302801057710 ∧ code e302801057710 = 4700847568814 := by decide
theorem cert_e302801057710 : check e302801057710 [[.under],[.under]] .three = true := by decide
def e302801057722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e302801057722 : Closed e302801057722 ∧ code e302801057722 = 4700847568826 := by decide
theorem cert_e302801057722 : check e302801057722 [[.under],[.under]] .three = true := by decide
def e302801058526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e302801058526 : Closed e302801058526 ∧ code e302801058526 = 4700847569630 := by decide
theorem cert_e302801058526 : check e302801058526 [[.under],[.under]] .three = true := by decide
def e302801058550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e302801058550 : Closed e302801058550 ∧ code e302801058550 = 4700847569654 := by decide
theorem cert_e302801058550 : check e302801058550 [[.under],[.under]] .three = true := by decide
def e302801058654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e302801058654 : Closed e302801058654 ∧ code e302801058654 = 4700847569758 := by decide
theorem cert_e302801058654 : check e302801058654 [[.under],[.under]] .three = true := by decide
def e302801058682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e302801058682 : Closed e302801058682 ∧ code e302801058682 = 4700847569786 := by decide
theorem cert_e302801058682 : check e302801058682 [[.under],[.under]] .three = true := by decide
def e302801058774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e302801058774 : Closed e302801058774 ∧ code e302801058774 = 4700847569878 := by decide
theorem cert_e302801058774 : check e302801058774 [[.under],[.under]] .three = true := by decide
def e302801058778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e302801058778 : Closed e302801058778 ∧ code e302801058778 = 4700847569882 := by decide
theorem cert_e302801058778 : check e302801058778 [[.under],[.under]] .three = true := by decide
def e302801059182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e302801059182 : Closed e302801059182 ∧ code e302801059182 = 4700847570286 := by decide
theorem cert_e302801059182 : check e302801059182 [[.under],[.under]] .three = true := by decide
def e302801059190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e302801059190 : Closed e302801059190 ∧ code e302801059190 = 4700847570294 := by decide
theorem cert_e302801059190 : check e302801059190 [[.under],[.under]] .three = true := by decide
def e302801059246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e302801059246 : Closed e302801059246 ∧ code e302801059246 = 4700847570350 := by decide
theorem cert_e302801059246 : check e302801059246 [[.under],[.under]] .three = true := by decide
def e302801059258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e302801059258 : Closed e302801059258 ∧ code e302801059258 = 4700847570362 := by decide
theorem cert_e302801059258 : check e302801059258 [[.under],[.under]] .three = true := by decide
def e302801059286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e302801059286 : Closed e302801059286 ∧ code e302801059286 = 4700847570390 := by decide
theorem cert_e302801059286 : check e302801059286 [[.under],[.under]] .three = true := by decide
def e302801059290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e302801059290 : Closed e302801059290 ∧ code e302801059290 = 4700847570394 := by decide
theorem cert_e302801059290 : check e302801059290 [[.under],[.under]] .three = true := by decide
def e302801067486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e302801067486 : Closed e302801067486 ∧ code e302801067486 = 4700847578590 := by decide
theorem cert_e302801067486 : check e302801067486 [[.under],[.under]] .three = true := by decide
def e302801067502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e302801067502 : Closed e302801067502 ∧ code e302801067502 = 4700847578606 := by decide
theorem cert_e302801067502 : check e302801067502 [[.under],[.under]] .three = true := by decide
def e302801067742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e302801067742 : Closed e302801067742 ∧ code e302801067742 = 4700847578846 := by decide
theorem cert_e302801067742 : check e302801067742 [[.under],[.under]] .three = true := by decide
def e302801067766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e302801067766 : Closed e302801067766 ∧ code e302801067766 = 4700847578870 := by decide
theorem cert_e302801067766 : check e302801067766 [[.under],[.under]] .three = true := by decide
def e302801067886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e302801067886 : Closed e302801067886 ∧ code e302801067886 = 4700847578990 := by decide
theorem cert_e302801067886 : check e302801067886 [[.under],[.under]] .three = true := by decide
def e302801067894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e302801067894 : Closed e302801067894 ∧ code e302801067894 = 4700847578998 := by decide
theorem cert_e302801067894 : check e302801067894 [[.under],[.under]] .three = true := by decide
def e302801073118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e302801073118 : Closed e302801073118 ∧ code e302801073118 = 4700847584222 := by decide
theorem cert_e302801073118 : check e302801073118 [[.under],[.under]] .three = true := by decide
def e302801073134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e302801073134 : Closed e302801073134 ∧ code e302801073134 = 4700847584238 := by decide
theorem cert_e302801073134 : check e302801073134 [[.under],[.under]] .three = true := by decide
def e302801074654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e302801074654 : Closed e302801074654 ∧ code e302801074654 = 4700847585758 := by decide
theorem cert_e302801074654 : check e302801074654 [[.under],[.under]] .three = true := by decide
def e302801074678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e302801074678 : Closed e302801074678 ∧ code e302801074678 = 4700847585782 := by decide
theorem cert_e302801074678 : check e302801074678 [[.under],[.under]] .three = true := by decide
def e302801075438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e302801075438 : Closed e302801075438 ∧ code e302801075438 = 4700847586542 := by decide
theorem cert_e302801075438 : check e302801075438 [[.under],[.under]] .three = true := by decide
def e302801075446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e302801075446 : Closed e302801075446 ∧ code e302801075446 = 4700847586550 := by decide
theorem cert_e302801075446 : check e302801075446 [[.under],[.under]] .three = true := by decide
def e302801079774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e302801079774 : Closed e302801079774 ∧ code e302801079774 = 4700847590878 := by decide
theorem cert_e302801079774 : check e302801079774 [[.under],[.under]] .three = true := by decide
def e302801079790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e302801079790 : Closed e302801079790 ∧ code e302801079790 = 4700847590894 := by decide
theorem cert_e302801079790 : check e302801079790 [[.under],[.under]] .three = true := by decide
def e302801080158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e302801080158 : Closed e302801080158 ∧ code e302801080158 = 4700847591262 := by decide
theorem cert_e302801080158 : check e302801080158 [[.under],[.under]] .three = true := by decide
def e302801080186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e302801080186 : Closed e302801080186 ∧ code e302801080186 = 4700847591290 := by decide
theorem cert_e302801080186 : check e302801080186 [[.under],[.under]] .three = true := by decide
def e302801080238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e302801080238 : Closed e302801080238 ∧ code e302801080238 = 4700847591342 := by decide
theorem cert_e302801080238 : check e302801080238 [[.under],[.under]] .three = true := by decide
def e302801080250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e302801080250 : Closed e302801080250 ∧ code e302801080250 = 4700847591354 := by decide
theorem cert_e302801080250 : check e302801080250 [[.under],[.under]] .three = true := by decide
def e302801081310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e302801081310 : Closed e302801081310 ∧ code e302801081310 = 4700847592414 := by decide
theorem cert_e302801081310 : check e302801081310 [[.under],[.under]] .three = true := by decide
def e302801081326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e302801081326 : Closed e302801081326 ∧ code e302801081326 = 4700847592430 := by decide
theorem cert_e302801081326 : check e302801081326 [[.under],[.under]] .three = true := by decide
def e302801083614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e302801083614 : Closed e302801083614 ∧ code e302801083614 = 4700847594718 := by decide
theorem cert_e302801083614 : check e302801083614 [[.under],[.under]] .three = true := by decide
def e302801083642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e302801083642 : Closed e302801083642 ∧ code e302801083642 = 4700847594746 := by decide
theorem cert_e302801083642 : check e302801083642 [[.under],[.under]] .three = true := by decide
def e302801084014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801084014 : Closed e302801084014 ∧ code e302801084014 = 4700847595118 := by decide
theorem cert_e302801084014 : check e302801084014 [[.under],[.under]] .three = true := by decide
def e302801084026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801084026 : Closed e302801084026 ∧ code e302801084026 = 4700847595130 := by decide
theorem cert_e302801084026 : check e302801084026 [[.under],[.under]] .three = true := by decide
def e302801086174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e302801086174 : Closed e302801086174 ∧ code e302801086174 = 4700847597278 := by decide
theorem cert_e302801086174 : check e302801086174 [[.under],[.under]] .three = true := by decide
def e302801086198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e302801086198 : Closed e302801086198 ∧ code e302801086198 = 4700847597302 := by decide
theorem cert_e302801086198 : check e302801086198 [[.under],[.under]] .three = true := by decide
def e302801086302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e302801086302 : Closed e302801086302 ∧ code e302801086302 = 4700847597406 := by decide
theorem cert_e302801086302 : check e302801086302 [[.under],[.under]] .three = true := by decide
def e302801086330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e302801086330 : Closed e302801086330 ∧ code e302801086330 = 4700847597434 := by decide
theorem cert_e302801086330 : check e302801086330 [[.under],[.under]] .three = true := by decide
def e302801086422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e302801086422 : Closed e302801086422 ∧ code e302801086422 = 4700847597526 := by decide
theorem cert_e302801086422 : check e302801086422 [[.under],[.under]] .three = true := by decide
def e302801086426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e302801086426 : Closed e302801086426 ∧ code e302801086426 = 4700847597530 := by decide
theorem cert_e302801086426 : check e302801086426 [[.under],[.under]] .three = true := by decide
def e302801086942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e302801086942 : Closed e302801086942 ∧ code e302801086942 = 4700847598046 := by decide
theorem cert_e302801086942 : check e302801086942 [[.under],[.under]] .three = true := by decide
def e302801086966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e302801086966 : Closed e302801086966 ∧ code e302801086966 = 4700847598070 := by decide
theorem cert_e302801086966 : check e302801086966 [[.under],[.under]] .three = true := by decide
def e302801087710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e302801087710 : Closed e302801087710 ∧ code e302801087710 = 4700847598814 := by decide
theorem cert_e302801087710 : check e302801087710 [[.under],[.under]] .three = true := by decide
def e302801087738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e302801087738 : Closed e302801087738 ∧ code e302801087738 = 4700847598842 := by decide
theorem cert_e302801087738 : check e302801087738 [[.under],[.under]] .three = true := by decide
def e302801088310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801088310 : Closed e302801088310 ∧ code e302801088310 = 4700847599414 := by decide
theorem cert_e302801088310 : check e302801088310 [[.under],[.under]] .three = true := by decide
def e302801088314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801088314 : Closed e302801088314 ∧ code e302801088314 = 4700847599418 := by decide
theorem cert_e302801088314 : check e302801088314 [[.under],[.under]] .three = true := by decide
def e302801089390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302801089390 : Closed e302801089390 ∧ code e302801089390 = 4700847600494 := by decide
theorem cert_e302801089390 : check e302801089390 [[.under],[.under]] .three = true := by decide
def e302801089398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e302801089398 : Closed e302801089398 ∧ code e302801089398 = 4700847600502 := by decide
theorem cert_e302801089398 : check e302801089398 [[.under],[.under]] .three = true := by decide
def e302801089454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302801089454 : Closed e302801089454 ∧ code e302801089454 = 4700847600558 := by decide
theorem cert_e302801089454 : check e302801089454 [[.under],[.under]] .three = true := by decide
def e302801089466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e302801089466 : Closed e302801089466 ∧ code e302801089466 = 4700847600570 := by decide
theorem cert_e302801089466 : check e302801089466 [[.under],[.under]] .three = true := by decide
def e302801089494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e302801089494 : Closed e302801089494 ∧ code e302801089494 = 4700847600598 := by decide
theorem cert_e302801089494 : check e302801089494 [[.under],[.under]] .three = true := by decide
def e302801089498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e302801089498 : Closed e302801089498 ∧ code e302801089498 = 4700847600602 := by decide
theorem cert_e302801089498 : check e302801089498 [[.under],[.under]] .three = true := by decide
def e302801089774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302801089774 : Closed e302801089774 ∧ code e302801089774 = 4700847600878 := by decide
theorem cert_e302801089774 : check e302801089774 [[.under],[.under]] .three = true := by decide
def e302801089782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302801089782 : Closed e302801089782 ∧ code e302801089782 = 4700847600886 := by decide
theorem cert_e302801089782 : check e302801089782 [[.under],[.under]] .three = true := by decide
def e302801090158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801090158 : Closed e302801090158 ∧ code e302801090158 = 4700847601262 := by decide
theorem cert_e302801090158 : check e302801090158 [[.under],[.under]] .three = true := by decide
def e302801090170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801090170 : Closed e302801090170 ∧ code e302801090170 = 4700847601274 := by decide
theorem cert_e302801090170 : check e302801090170 [[.under],[.under]] .three = true := by decide
def e302801090358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801090358 : Closed e302801090358 ∧ code e302801090358 = 4700847601462 := by decide
theorem cert_e302801090358 : check e302801090358 [[.under],[.under]] .three = true := by decide
def e302801090362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801090362 : Closed e302801090362 ∧ code e302801090362 = 4700847601466 := by decide
theorem cert_e302801090362 : check e302801090362 [[.under],[.under]] .three = true := by decide
def e302801116638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e302801116638 : Closed e302801116638 ∧ code e302801116638 = 4700847627742 := by decide
theorem cert_e302801116638 : check e302801116638 [[.under],[.under]] .three = true := by decide
def e302801116654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e302801116654 : Closed e302801116654 ∧ code e302801116654 = 4700847627758 := by decide
theorem cert_e302801116654 : check e302801116654 [[.under],[.under]] .three = true := by decide
def e302801116894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e302801116894 : Closed e302801116894 ∧ code e302801116894 = 4700847627998 := by decide
theorem cert_e302801116894 : check e302801116894 [[.under],[.under]] .three = true := by decide
def e302801116918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e302801116918 : Closed e302801116918 ∧ code e302801116918 = 4700847628022 := by decide
theorem cert_e302801116918 : check e302801116918 [[.under],[.under]] .three = true := by decide
def e302801117038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e302801117038 : Closed e302801117038 ∧ code e302801117038 = 4700847628142 := by decide
theorem cert_e302801117038 : check e302801117038 [[.under],[.under]] .three = true := by decide
def e302801117046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e302801117046 : Closed e302801117046 ∧ code e302801117046 = 4700847628150 := by decide
theorem cert_e302801117046 : check e302801117046 [[.under],[.under]] .three = true := by decide
def e302801122270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e302801122270 : Closed e302801122270 ∧ code e302801122270 = 4700847633374 := by decide
theorem cert_e302801122270 : check e302801122270 [[.under],[.under]] .three = true := by decide
def e302801122286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e302801122286 : Closed e302801122286 ∧ code e302801122286 = 4700847633390 := by decide
theorem cert_e302801122286 : check e302801122286 [[.under],[.under]] .three = true := by decide
def e302801123806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801123806 : Closed e302801123806 ∧ code e302801123806 = 4700847634910 := by decide
theorem cert_e302801123806 : check e302801123806 [[.under],[.under]] .three = true := by decide
def e302801123830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801123830 : Closed e302801123830 ∧ code e302801123830 = 4700847634934 := by decide
theorem cert_e302801123830 : check e302801123830 [[.under],[.under]] .three = true := by decide
def e302801124590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801124590 : Closed e302801124590 ∧ code e302801124590 = 4700847635694 := by decide
theorem cert_e302801124590 : check e302801124590 [[.under],[.under]] .three = true := by decide
def e302801124598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801124598 : Closed e302801124598 ∧ code e302801124598 = 4700847635702 := by decide
theorem cert_e302801124598 : check e302801124598 [[.under],[.under]] .three = true := by decide
def e302801169886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e302801169886 : Closed e302801169886 ∧ code e302801169886 = 4700847680990 := by decide
theorem cert_e302801169886 : check e302801169886 [[.under],[.under]] .three = true := by decide
def e302801169902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e302801169902 : Closed e302801169902 ∧ code e302801169902 = 4700847681006 := by decide
theorem cert_e302801169902 : check e302801169902 [[.under],[.under]] .three = true := by decide
def e302801170270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e302801170270 : Closed e302801170270 ∧ code e302801170270 = 4700847681374 := by decide
theorem cert_e302801170270 : check e302801170270 [[.under],[.under]] .three = true := by decide
def e302801170298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e302801170298 : Closed e302801170298 ∧ code e302801170298 = 4700847681402 := by decide
theorem cert_e302801170298 : check e302801170298 [[.under],[.under]] .three = true := by decide
def e302801170350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e302801170350 : Closed e302801170350 ∧ code e302801170350 = 4700847681454 := by decide
theorem cert_e302801170350 : check e302801170350 [[.under],[.under]] .three = true := by decide
def e302801170362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e302801170362 : Closed e302801170362 ∧ code e302801170362 = 4700847681466 := by decide
theorem cert_e302801170362 : check e302801170362 [[.under],[.under]] .three = true := by decide
def e302801171422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e302801171422 : Closed e302801171422 ∧ code e302801171422 = 4700847682526 := by decide
theorem cert_e302801171422 : check e302801171422 [[.under],[.under]] .three = true := by decide
def e302801171438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e302801171438 : Closed e302801171438 ∧ code e302801171438 = 4700847682542 := by decide
theorem cert_e302801171438 : check e302801171438 [[.under],[.under]] .three = true := by decide
def e302801173726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801173726 : Closed e302801173726 ∧ code e302801173726 = 4700847684830 := by decide
theorem cert_e302801173726 : check e302801173726 [[.under],[.under]] .three = true := by decide
def e302801173754 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801173754 : Closed e302801173754 ∧ code e302801173754 = 4700847684858 := by decide
theorem cert_e302801173754 : check e302801173754 [[.under],[.under]] .three = true := by decide
def e302801174126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801174126 : Closed e302801174126 ∧ code e302801174126 = 4700847685230 := by decide
theorem cert_e302801174126 : check e302801174126 [[.under],[.under]] .three = true := by decide
def e302801174138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801174138 : Closed e302801174138 ∧ code e302801174138 = 4700847685242 := by decide
theorem cert_e302801174138 : check e302801174138 [[.under],[.under]] .three = true := by decide
def e302801196766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302801196766 : Closed e302801196766 ∧ code e302801196766 = 4700847707870 := by decide
theorem cert_e302801196766 : check e302801196766 [[.under],[.under]] .three = true := by decide
def e302801196790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302801196790 : Closed e302801196790 ∧ code e302801196790 = 4700847707894 := by decide
theorem cert_e302801196790 : check e302801196790 [[.under],[.under]] .three = true := by decide
def e302801196894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302801196894 : Closed e302801196894 ∧ code e302801196894 = 4700847707998 := by decide
theorem cert_e302801196894 : check e302801196894 [[.under],[.under]] .three = true := by decide
def e302801196922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302801196922 : Closed e302801196922 ∧ code e302801196922 = 4700847708026 := by decide
theorem cert_e302801196922 : check e302801196922 [[.under],[.under]] .three = true := by decide
def e302801197014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302801197014 : Closed e302801197014 ∧ code e302801197014 = 4700847708118 := by decide
theorem cert_e302801197014 : check e302801197014 [[.under],[.under]] .three = true := by decide
def e302801197018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302801197018 : Closed e302801197018 ∧ code e302801197018 = 4700847708122 := by decide
theorem cert_e302801197018 : check e302801197018 [[.under],[.under]] .three = true := by decide
def e302801197534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801197534 : Closed e302801197534 ∧ code e302801197534 = 4700847708638 := by decide
theorem cert_e302801197534 : check e302801197534 [[.under],[.under]] .three = true := by decide
def e302801197558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801197558 : Closed e302801197558 ∧ code e302801197558 = 4700847708662 := by decide
theorem cert_e302801197558 : check e302801197558 [[.under],[.under]] .three = true := by decide
def e302801198302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801198302 : Closed e302801198302 ∧ code e302801198302 = 4700847709406 := by decide
theorem cert_e302801198302 : check e302801198302 [[.under],[.under]] .three = true := by decide
def e302801198330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801198330 : Closed e302801198330 ∧ code e302801198330 = 4700847709434 := by decide
theorem cert_e302801198330 : check e302801198330 [[.under],[.under]] .three = true := by decide
def e302801198902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801198902 : Closed e302801198902 ∧ code e302801198902 = 4700847710006 := by decide
theorem cert_e302801198902 : check e302801198902 [[.under],[.under]] .three = true := by decide
def e302801198906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801198906 : Closed e302801198906 ∧ code e302801198906 = 4700847710010 := by decide
theorem cert_e302801198906 : check e302801198906 [[.under],[.under]] .three = true := by decide
def e302801210222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302801210222 : Closed e302801210222 ∧ code e302801210222 = 4700847721326 := by decide
theorem cert_e302801210222 : check e302801210222 [[.under],[.under]] .three = true := by decide
def e302801210230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302801210230 : Closed e302801210230 ∧ code e302801210230 = 4700847721334 := by decide
theorem cert_e302801210230 : check e302801210230 [[.under],[.under]] .three = true := by decide
def e302801210286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302801210286 : Closed e302801210286 ∧ code e302801210286 = 4700847721390 := by decide
theorem cert_e302801210286 : check e302801210286 [[.under],[.under]] .three = true := by decide
def e302801210298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302801210298 : Closed e302801210298 ∧ code e302801210298 = 4700847721402 := by decide
theorem cert_e302801210298 : check e302801210298 [[.under],[.under]] .three = true := by decide
def e302801210326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302801210326 : Closed e302801210326 ∧ code e302801210326 = 4700847721430 := by decide
theorem cert_e302801210326 : check e302801210326 [[.under],[.under]] .three = true := by decide
def e302801210330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302801210330 : Closed e302801210330 ∧ code e302801210330 = 4700847721434 := by decide
theorem cert_e302801210330 : check e302801210330 [[.under],[.under]] .three = true := by decide
def e302801210606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801210606 : Closed e302801210606 ∧ code e302801210606 = 4700847721710 := by decide
theorem cert_e302801210606 : check e302801210606 [[.under],[.under]] .three = true := by decide
def e302801210614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801210614 : Closed e302801210614 ∧ code e302801210614 = 4700847721718 := by decide
theorem cert_e302801210614 : check e302801210614 [[.under],[.under]] .three = true := by decide
def e302801210990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801210990 : Closed e302801210990 ∧ code e302801210990 = 4700847722094 := by decide
theorem cert_e302801210990 : check e302801210990 [[.under],[.under]] .three = true := by decide
def e302801211002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801211002 : Closed e302801211002 ∧ code e302801211002 = 4700847722106 := by decide
theorem cert_e302801211002 : check e302801211002 [[.under],[.under]] .three = true := by decide
def e302801211190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801211190 : Closed e302801211190 ∧ code e302801211190 = 4700847722294 := by decide
theorem cert_e302801211190 : check e302801211190 [[.under],[.under]] .three = true := by decide
def e302801211194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801211194 : Closed e302801211194 ∧ code e302801211194 = 4700847722298 := by decide
theorem cert_e302801211194 : check e302801211194 [[.under],[.under]] .three = true := by decide
def e302801270238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e302801270238 : Closed e302801270238 ∧ code e302801270238 = 4700847781342 := by decide
theorem cert_e302801270238 : check e302801270238 [[.under],[.under]] .three = true := by decide
def e302801270254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e302801270254 : Closed e302801270254 ∧ code e302801270254 = 4700847781358 := by decide
theorem cert_e302801270254 : check e302801270254 [[.under],[.under]] .three = true := by decide
def e302801270622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e302801270622 : Closed e302801270622 ∧ code e302801270622 = 4700847781726 := by decide
theorem cert_e302801270622 : check e302801270622 [[.under],[.under]] .three = true := by decide
def e302801270650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e302801270650 : Closed e302801270650 ∧ code e302801270650 = 4700847781754 := by decide
theorem cert_e302801270650 : check e302801270650 [[.under],[.under]] .three = true := by decide
def e302801270702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e302801270702 : Closed e302801270702 ∧ code e302801270702 = 4700847781806 := by decide
theorem cert_e302801270702 : check e302801270702 [[.under],[.under]] .three = true := by decide
def e302801270714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e302801270714 : Closed e302801270714 ∧ code e302801270714 = 4700847781818 := by decide
theorem cert_e302801270714 : check e302801270714 [[.under],[.under]] .three = true := by decide
def e302801272158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e302801272158 : Closed e302801272158 ∧ code e302801272158 = 4700847783262 := by decide
theorem cert_e302801272158 : check e302801272158 [[.under],[.under]] .three = true := by decide
def e302801272186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e302801272186 : Closed e302801272186 ∧ code e302801272186 = 4700847783290 := by decide
theorem cert_e302801272186 : check e302801272186 [[.under],[.under]] .three = true := by decide
def e302801272298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e302801272298 : Closed e302801272298 ∧ code e302801272298 = 4700847783402 := by decide
theorem cert_e302801272298 : check e302801272298 [[.under],[.under]] .three = true := by decide
def e302801272494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e302801272494 : Closed e302801272494 ∧ code e302801272494 = 4700847783598 := by decide
theorem cert_e302801272494 : check e302801272494 [[.under],[.under]] .three = true := by decide
end Blc.Floor42
