import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196686693622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686693622 : Closed e1196686693622 ∧ code e1196686693622 = 5594733204726 := by decide
theorem cert_e1196686693622 : check e1196686693622 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686693998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686693998 : Closed e1196686693998 ∧ code e1196686693998 = 5594733205102 := by decide
def e1196686694010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686694010 : Closed e1196686694010 ∧ code e1196686694010 = 5594733205114 := by decide
def e1196686694174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1196686694174 : Closed e1196686694174 ∧ code e1196686694174 = 5594733205278 := by decide
theorem cert_e1196686694174 : check e1196686694174 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686694198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686694198 : Closed e1196686694198 ∧ code e1196686694198 = 5594733205302 := by decide
theorem cert_e1196686694198 : check e1196686694198 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686694202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686694202 : Closed e1196686694202 ∧ code e1196686694202 = 5594733205306 := by decide
theorem cert_e1196686694202 : check e1196686694202 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686694830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1196686694830 : Closed e1196686694830 ∧ code e1196686694830 = 5594733205934 := by decide
theorem cert_e1196686694830 : check e1196686694830 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686694842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1196686694842 : Closed e1196686694842 ∧ code e1196686694842 = 5594733205946 := by decide
theorem cert_e1196686694842 : check e1196686694842 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686694890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1196686694890 : Closed e1196686694890 ∧ code e1196686694890 = 5594733205994 := by decide
def e1196686695022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686695022 : Closed e1196686695022 ∧ code e1196686695022 = 5594733206126 := by decide
theorem cert_e1196686695022 : check e1196686695022 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686695034 : Closed e1196686695034 ∧ code e1196686695034 = 5594733206138 := by decide
theorem cert_e1196686695034 : check e1196686695034 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1196686695322 : Closed e1196686695322 ∧ code e1196686695322 = 5594733206426 := by decide
def e1196686695534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1196686695534 : Closed e1196686695534 ∧ code e1196686695534 = 5594733206638 := by decide
theorem cert_e1196686695534 : check e1196686695534 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686695546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1196686695546 : Closed e1196686695546 ∧ code e1196686695546 = 5594733206650 := by decide
theorem cert_e1196686695546 : check e1196686695546 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1196686695638 : Closed e1196686695638 ∧ code e1196686695638 = 5594733206742 := by decide
theorem cert_e1196686695638 : check e1196686695638 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1196686695642 : Closed e1196686695642 ∧ code e1196686695642 = 5594733206746 := by decide
theorem cert_e1196686695642 : check e1196686695642 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1196686695658 : Closed e1196686695658 ∧ code e1196686695658 = 5594733206762 := by decide
theorem cert_e1196686695658 : check e1196686695658 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686695710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1196686695710 : Closed e1196686695710 ∧ code e1196686695710 = 5594733206814 := by decide
theorem cert_e1196686695710 : check e1196686695710 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686695734 : Closed e1196686695734 ∧ code e1196686695734 = 5594733206838 := by decide
theorem cert_e1196686695734 : check e1196686695734 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686695738 : Closed e1196686695738 ∧ code e1196686695738 = 5594733206842 := by decide
theorem cert_e1196686695738 : check e1196686695738 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686695834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1196686695834 : Closed e1196686695834 ∧ code e1196686695834 = 5594733206938 := by decide
def e1196686695878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1196686695878 : Closed e1196686695878 ∧ code e1196686695878 = 5594733206982 := by decide
def e1196686697326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1196686697326 : Closed e1196686697326 ∧ code e1196686697326 = 5594733208430 := by decide
theorem cert_e1196686697326 : check e1196686697326 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e1196686697334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1196686697334 : Closed e1196686697334 ∧ code e1196686697334 = 5594733208438 := by decide
theorem cert_e1196686697334 : check e1196686697334 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e1196686697390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1196686697390 : Closed e1196686697390 ∧ code e1196686697390 = 5594733208494 := by decide
theorem cert_e1196686697390 : check e1196686697390 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686697402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1196686697402 : Closed e1196686697402 ∧ code e1196686697402 = 5594733208506 := by decide
theorem cert_e1196686697402 : check e1196686697402 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686697430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1196686697430 : Closed e1196686697430 ∧ code e1196686697430 = 5594733208534 := by decide
theorem cert_e1196686697430 : check e1196686697430 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .smaller = true := by decide
def e1196686697434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1196686697434 : Closed e1196686697434 ∧ code e1196686697434 = 5594733208538 := by decide
theorem cert_e1196686697434 : check e1196686697434 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .smaller = true := by decide
def e1196686698166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1196686698166 : Closed e1196686698166 ∧ code e1196686698166 = 5594733209270 := by decide
theorem cert_e1196686698166 : check e1196686698166 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1196686698198 : Closed e1196686698198 ∧ code e1196686698198 = 5594733209302 := by decide
theorem cert_e1196686698198 : check e1196686698198 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1196686698202 : Closed e1196686698202 ∧ code e1196686698202 = 5594733209306 := by decide
theorem cert_e1196686698202 : check e1196686698202 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1196686698326 : Closed e1196686698326 ∧ code e1196686698326 = 5594733209430 := by decide
theorem cert_e1196686698326 : check e1196686698326 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686698330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1196686698330 : Closed e1196686698330 ∧ code e1196686698330 = 5594733209434 := by decide
theorem cert_e1196686698330 : check e1196686698330 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686698346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1196686698346 : Closed e1196686698346 ∧ code e1196686698346 = 5594733209450 := by decide
theorem cert_e1196686698346 : check e1196686698346 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left]] .chain = true := by decide
def e1196686698734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1196686698734 : Closed e1196686698734 ∧ code e1196686698734 = 5594733209838 := by decide
theorem cert_e1196686698734 : check e1196686698734 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1196686698742 : Closed e1196686698742 ∧ code e1196686698742 = 5594733209846 := by decide
theorem cert_e1196686698742 : check e1196686698742 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1196686698934 : Closed e1196686698934 ∧ code e1196686698934 = 5594733210038 := by decide
theorem cert_e1196686698934 : check e1196686698934 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1196686698966 : Closed e1196686698966 ∧ code e1196686698966 = 5594733210070 := by decide
theorem cert_e1196686698966 : check e1196686698966 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686698970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1196686698970 : Closed e1196686698970 ∧ code e1196686698970 = 5594733210074 := by decide
theorem cert_e1196686698970 : check e1196686698970 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196686699126 : Closed e1196686699126 ∧ code e1196686699126 = 5594733210230 := by decide
theorem cert_e1196686699126 : check e1196686699126 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1196686699294 : Closed e1196686699294 ∧ code e1196686699294 = 5594733210398 := by decide
theorem cert_e1196686699294 : check e1196686699294 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686699318 : Closed e1196686699318 ∧ code e1196686699318 = 5594733210422 := by decide
theorem cert_e1196686699318 : check e1196686699318 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686699322 : Closed e1196686699322 ∧ code e1196686699322 = 5594733210426 := by decide
theorem cert_e1196686699322 : check e1196686699322 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1196686699406 : Closed e1196686699406 ∧ code e1196686699406 = 5594733210510 := by decide
theorem cert_e1196686699406 : check e1196686699406 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1196686699630 : Closed e1196686699630 ∧ code e1196686699630 = 5594733210734 := by decide
theorem cert_e1196686699630 : check e1196686699630 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e1196686699642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1196686699642 : Closed e1196686699642 ∧ code e1196686699642 = 5594733210746 := by decide
theorem cert_e1196686699642 : check e1196686699642 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e1196686699734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1196686699734 : Closed e1196686699734 ∧ code e1196686699734 = 5594733210838 := by decide
theorem cert_e1196686699734 : check e1196686699734 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1196686699738 : Closed e1196686699738 ∧ code e1196686699738 = 5594733210842 := by decide
theorem cert_e1196686699738 : check e1196686699738 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1196686699754 : Closed e1196686699754 ∧ code e1196686699754 = 5594733210858 := by decide
theorem cert_e1196686699754 : check e1196686699754 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686699806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1196686699806 : Closed e1196686699806 ∧ code e1196686699806 = 5594733210910 := by decide
theorem cert_e1196686699806 : check e1196686699806 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686699830 : Closed e1196686699830 ∧ code e1196686699830 = 5594733210934 := by decide
theorem cert_e1196686699830 : check e1196686699830 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686699834 : Closed e1196686699834 ∧ code e1196686699834 = 5594733210938 := by decide
theorem cert_e1196686699834 : check e1196686699834 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686699930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1196686699930 : Closed e1196686699930 ∧ code e1196686699930 = 5594733211034 := by decide
def e1196686699974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1196686699974 : Closed e1196686699974 ∧ code e1196686699974 = 5594733211078 := by decide
def e1196686700086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1196686700086 : Closed e1196686700086 ∧ code e1196686700086 = 5594733211190 := by decide
private def t_e1196686700086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem cert_e1196686700086 : ¬ IsSelfInterpreter e1196686700086 :=
  wSource (t := t_e1196686700086) (replay_sound (ps := []) (t := e1196686700086) (by decide)) (by decide)
def e1196686700090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1196686700090 : Closed e1196686700090 ∧ code e1196686700090 = 5594733211194 := by decide
private def t_e1196686700090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem cert_e1196686700090 : ¬ IsSelfInterpreter e1196686700090 :=
  wSource (t := t_e1196686700090) (replay_sound (ps := []) (t := e1196686700090) (by decide)) (by decide)
def e1196686700174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1196686700174 : Closed e1196686700174 ∧ code e1196686700174 = 5594733211278 := by decide
private def t_e1196686700174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem cert_e1196686700174 : ¬ IsSelfInterpreter e1196686700174 :=
  wSource (t := t_e1196686700174) (replay_sound (ps := []) (t := e1196686700174) (by decide)) (by decide)
def e1196686700230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1196686700230 : Closed e1196686700230 ∧ code e1196686700230 = 5594733211334 := by decide
private def t_e1196686700230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem cert_e1196686700230 : ¬ IsSelfInterpreter e1196686700230 :=
  wSource (t := t_e1196686700230) (replay_sound (ps := []) (t := e1196686700230) (by decide)) (by decide)
def e1196686712558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e1196686712558 : Closed e1196686712558 ∧ code e1196686712558 = 5594733223662 := by decide
theorem cert_e1196686712558 : check e1196686712558 [[],[.left],[]] .sourceHead = true := by decide
def e1196686712566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e1196686712566 : Closed e1196686712566 ∧ code e1196686712566 = 5594733223670 := by decide
theorem cert_e1196686712566 : check e1196686712566 [[],[.left],[]] .sourceHead = true := by decide
def e1196686712694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e1196686712694 : Closed e1196686712694 ∧ code e1196686712694 = 5594733223798 := by decide
theorem cert_e1196686712694 : check e1196686712694 [[],[.left],[]] .sourceHead = true := by decide
def e1196686719470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e1196686719470 : Closed e1196686719470 ∧ code e1196686719470 = 5594733230574 := by decide
theorem cert_e1196686719470 : check e1196686719470 [[],[.left],[]] .sourceHead = true := by decide
def e1196686720238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686720238 : Closed e1196686720238 ∧ code e1196686720238 = 5594733231342 := by decide
theorem cert_e1196686720238 : check e1196686720238 [[],[.left],[]] .sourceHead = true := by decide
def e1196686720246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686720246 : Closed e1196686720246 ∧ code e1196686720246 = 5594733231350 := by decide
theorem cert_e1196686720246 : check e1196686720246 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1196686728046 : Closed e1196686728046 ∧ code e1196686728046 = 5594733239150 := by decide
theorem cert_e1196686728046 : check e1196686728046 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1196686728054 : Closed e1196686728054 ∧ code e1196686728054 = 5594733239158 := by decide
theorem cert_e1196686728054 : check e1196686728054 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1196686728118 : Closed e1196686728118 ∧ code e1196686728118 = 5594733239222 := by decide
theorem cert_e1196686728118 : check e1196686728118 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1196686728558 : Closed e1196686728558 ∧ code e1196686728558 = 5594733239662 := by decide
theorem cert_e1196686728558 : check e1196686728558 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1196686728566 : Closed e1196686728566 ∧ code e1196686728566 = 5594733239670 := by decide
theorem cert_e1196686728566 : check e1196686728566 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1196686728622 : Closed e1196686728622 ∧ code e1196686728622 = 5594733239726 := by decide
theorem cert_e1196686728622 : check e1196686728622 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1196686728634 : Closed e1196686728634 ∧ code e1196686728634 = 5594733239738 := by decide
theorem cert_e1196686728634 : check e1196686728634 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1196686728662 : Closed e1196686728662 ∧ code e1196686728662 = 5594733239766 := by decide
theorem cert_e1196686728662 : check e1196686728662 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1196686728666 : Closed e1196686728666 ∧ code e1196686728666 = 5594733239770 := by decide
theorem cert_e1196686728666 : check e1196686728666 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1196686728886 : Closed e1196686728886 ∧ code e1196686728886 = 5594733239990 := by decide
theorem cert_e1196686728886 : check e1196686728886 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1196686728918 : Closed e1196686728918 ∧ code e1196686728918 = 5594733240022 := by decide
theorem cert_e1196686728918 : check e1196686728918 [[],[.left],[]] .sourceHead = true := by decide
def e1196686728922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1196686728922 : Closed e1196686728922 ∧ code e1196686728922 = 5594733240026 := by decide
theorem cert_e1196686728922 : check e1196686728922 [[],[.left],[]] .sourceHead = true := by decide
def e1196686731118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1196686731118 : Closed e1196686731118 ∧ code e1196686731118 = 5594733242222 := by decide
theorem cert_e1196686731118 : check e1196686731118 [[],[.left],[]] .sourceHead = true := by decide
def e1196686731126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1196686731126 : Closed e1196686731126 ∧ code e1196686731126 = 5594733242230 := by decide
theorem cert_e1196686731126 : check e1196686731126 [[],[.left],[]] .sourceHead = true := by decide
def e1196686731190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1196686731190 : Closed e1196686731190 ∧ code e1196686731190 = 5594733242294 := by decide
theorem cert_e1196686731190 : check e1196686731190 [[],[.left],[]] .sourceHead = true := by decide
def e1196686732526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686732526 : Closed e1196686732526 ∧ code e1196686732526 = 5594733243630 := by decide
theorem cert_e1196686732526 : check e1196686732526 [[],[.left],[]] .sourceHead = true := by decide
def e1196686732534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686732534 : Closed e1196686732534 ∧ code e1196686732534 = 5594733243638 := by decide
theorem cert_e1196686732534 : check e1196686732534 [[],[.left],[]] .sourceHead = true := by decide
def e1196686732918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1196686732918 : Closed e1196686732918 ∧ code e1196686732918 = 5594733244022 := by decide
theorem cert_e1196686732918 : check e1196686732918 [[],[.left],[]] .sourceHead = true := by decide
def e1196686733806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1196686733806 : Closed e1196686733806 ∧ code e1196686733806 = 5594733244910 := by decide
theorem cert_e1196686733806 : check e1196686733806 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1196686734190 : Closed e1196686734190 ∧ code e1196686734190 = 5594733245294 := by decide
theorem cert_e1196686734190 : check e1196686734190 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1196686734198 : Closed e1196686734198 ∧ code e1196686734198 = 5594733245302 := by decide
theorem cert_e1196686734198 : check e1196686734198 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1196686734254 : Closed e1196686734254 ∧ code e1196686734254 = 5594733245358 := by decide
theorem cert_e1196686734254 : check e1196686734254 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1196686734266 : Closed e1196686734266 ∧ code e1196686734266 = 5594733245370 := by decide
theorem cert_e1196686734266 : check e1196686734266 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1196686734294 : Closed e1196686734294 ∧ code e1196686734294 = 5594733245398 := by decide
theorem cert_e1196686734294 : check e1196686734294 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1196686734298 : Closed e1196686734298 ∧ code e1196686734298 = 5594733245402 := by decide
theorem cert_e1196686734298 : check e1196686734298 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686734574 : Closed e1196686734574 ∧ code e1196686734574 = 5594733245678 := by decide
theorem cert_e1196686734574 : check e1196686734574 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686734582 : Closed e1196686734582 ∧ code e1196686734582 = 5594733245686 := by decide
theorem cert_e1196686734582 : check e1196686734582 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686734958 : Closed e1196686734958 ∧ code e1196686734958 = 5594733246062 := by decide
theorem cert_e1196686734958 : check e1196686734958 [[],[.left],[]] .sourceHead = true := by decide
def e1196686734970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686734970 : Closed e1196686734970 ∧ code e1196686734970 = 5594733246074 := by decide
theorem cert_e1196686734970 : check e1196686734970 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1196686735134 : Closed e1196686735134 ∧ code e1196686735134 = 5594733246238 := by decide
theorem cert_e1196686735134 : check e1196686735134 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686735158 : Closed e1196686735158 ∧ code e1196686735158 = 5594733246262 := by decide
theorem cert_e1196686735158 : check e1196686735158 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686735162 : Closed e1196686735162 ∧ code e1196686735162 = 5594733246266 := by decide
theorem cert_e1196686735162 : check e1196686735162 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1196686735598 : Closed e1196686735598 ∧ code e1196686735598 = 5594733246702 := by decide
theorem cert_e1196686735598 : check e1196686735598 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1196686735606 : Closed e1196686735606 ∧ code e1196686735606 = 5594733246710 := by decide
theorem cert_e1196686735606 : check e1196686735606 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1196686735798 : Closed e1196686735798 ∧ code e1196686735798 = 5594733246902 := by decide
theorem cert_e1196686735798 : check e1196686735798 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1196686735830 : Closed e1196686735830 ∧ code e1196686735830 = 5594733246934 := by decide
theorem cert_e1196686735830 : check e1196686735830 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1196686735834 : Closed e1196686735834 ∧ code e1196686735834 = 5594733246938 := by decide
theorem cert_e1196686735834 : check e1196686735834 [[],[.left],[]] .sourceHead = true := by decide
def e1196686735990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1196686735990 : Closed e1196686735990 ∧ code e1196686735990 = 5594733247094 := by decide
theorem cert_e1196686735990 : check e1196686735990 [[],[.left],[]] .sourceHead = true := by decide
def e1196686736158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1196686736158 : Closed e1196686736158 ∧ code e1196686736158 = 5594733247262 := by decide
theorem cert_e1196686736158 : check e1196686736158 [[],[.left],[]] .sourceHead = true := by decide
def e1196686736182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686736182 : Closed e1196686736182 ∧ code e1196686736182 = 5594733247286 := by decide
theorem cert_e1196686736182 : check e1196686736182 [[],[.left],[]] .sourceHead = true := by decide
def e1196686736186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686736186 : Closed e1196686736186 ∧ code e1196686736186 = 5594733247290 := by decide
theorem cert_e1196686736186 : check e1196686736186 [[],[.left],[]] .sourceHead = true := by decide
def e1196686736270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1196686736270 : Closed e1196686736270 ∧ code e1196686736270 = 5594733247374 := by decide
theorem cert_e1196686736270 : check e1196686736270 [[],[.left],[]] .sourceHead = true := by decide
def e1196686743406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1196686743406 : Closed e1196686743406 ∧ code e1196686743406 = 5594733254510 := by decide
theorem cert_e1196686743406 : check e1196686743406 [[],[.left],[]] .sourceHead = true := by decide
def e1196686743414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1196686743414 : Closed e1196686743414 ∧ code e1196686743414 = 5594733254518 := by decide
theorem cert_e1196686743414 : check e1196686743414 [[],[.left],[]] .sourceHead = true := by decide
def e1196686743478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1196686743478 : Closed e1196686743478 ∧ code e1196686743478 = 5594733254582 := by decide
theorem cert_e1196686743478 : check e1196686743478 [[],[.left],[]] .sourceHead = true := by decide
def e1196686744814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1196686744814 : Closed e1196686744814 ∧ code e1196686744814 = 5594733255918 := by decide
theorem cert_e1196686744814 : check e1196686744814 [[],[.left],[]] .sourceHead = true := by decide
def e1196686744822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1196686744822 : Closed e1196686744822 ∧ code e1196686744822 = 5594733255926 := by decide
theorem cert_e1196686744822 : check e1196686744822 [[],[.left],[]] .sourceHead = true := by decide
def e1196686745206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1196686745206 : Closed e1196686745206 ∧ code e1196686745206 = 5594733256310 := by decide
theorem cert_e1196686745206 : check e1196686745206 [[],[.left],[]] .sourceHead = true := by decide
def e1196686754782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1196686754782 : Closed e1196686754782 ∧ code e1196686754782 = 5594733265886 := by decide
theorem cert_e1196686754782 : check e1196686754782 [[],[.left],[]] .sourceHead = true := by decide
def e1196686754798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1196686754798 : Closed e1196686754798 ∧ code e1196686754798 = 5594733265902 := by decide
theorem cert_e1196686754798 : check e1196686754798 [[],[.left],[]] .sourceHead = true := by decide
def e1196686756718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196686756718 : Closed e1196686756718 ∧ code e1196686756718 = 5594733267822 := by decide
theorem cert_e1196686756718 : check e1196686756718 [[],[.left],[]] .sourceHead = true := by decide
def e1196686756726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196686756726 : Closed e1196686756726 ∧ code e1196686756726 = 5594733267830 := by decide
theorem cert_e1196686756726 : check e1196686756726 [[],[.left],[]] .sourceHead = true := by decide
def e1196686756782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196686756782 : Closed e1196686756782 ∧ code e1196686756782 = 5594733267886 := by decide
theorem cert_e1196686756782 : check e1196686756782 [[],[.left],[]] .sourceHead = true := by decide
def e1196686756794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196686756794 : Closed e1196686756794 ∧ code e1196686756794 = 5594733267898 := by decide
theorem cert_e1196686756794 : check e1196686756794 [[],[.left],[]] .sourceHead = true := by decide
def e1196686756822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196686756822 : Closed e1196686756822 ∧ code e1196686756822 = 5594733267926 := by decide
theorem cert_e1196686756822 : check e1196686756822 [[],[.left],[]] .sourceHead = true := by decide
def e1196686756826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196686756826 : Closed e1196686756826 ∧ code e1196686756826 = 5594733267930 := by decide
theorem cert_e1196686756826 : check e1196686756826 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196686757102 : Closed e1196686757102 ∧ code e1196686757102 = 5594733268206 := by decide
theorem cert_e1196686757102 : check e1196686757102 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196686757110 : Closed e1196686757110 ∧ code e1196686757110 = 5594733268214 := by decide
theorem cert_e1196686757110 : check e1196686757110 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196686757486 : Closed e1196686757486 ∧ code e1196686757486 = 5594733268590 := by decide
theorem cert_e1196686757486 : check e1196686757486 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196686757498 : Closed e1196686757498 ∧ code e1196686757498 = 5594733268602 := by decide
theorem cert_e1196686757498 : check e1196686757498 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1196686757662 : Closed e1196686757662 ∧ code e1196686757662 = 5594733268766 := by decide
theorem cert_e1196686757662 : check e1196686757662 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686757686 : Closed e1196686757686 ∧ code e1196686757686 = 5594733268790 := by decide
theorem cert_e1196686757686 : check e1196686757686 [[],[.left],[]] .sourceHead = true := by decide
def e1196686757690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686757690 : Closed e1196686757690 ∧ code e1196686757690 = 5594733268794 := by decide
theorem cert_e1196686757690 : check e1196686757690 [[],[.left],[]] .sourceHead = true := by decide
def e1196686762478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1196686762478 : Closed e1196686762478 ∧ code e1196686762478 = 5594733273582 := by decide
theorem cert_e1196686762478 : check e1196686762478 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1196686763446 : Closed e1196686763446 ∧ code e1196686763446 = 5594733274550 := by decide
theorem cert_e1196686763446 : check e1196686763446 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1196686763478 : Closed e1196686763478 ∧ code e1196686763478 = 5594733274582 := by decide
theorem cert_e1196686763478 : check e1196686763478 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1196686763482 : Closed e1196686763482 ∧ code e1196686763482 = 5594733274586 := by decide
theorem cert_e1196686763482 : check e1196686763482 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1196686763638 : Closed e1196686763638 ∧ code e1196686763638 = 5594733274742 := by decide
theorem cert_e1196686763638 : check e1196686763638 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1196686763806 : Closed e1196686763806 ∧ code e1196686763806 = 5594733274910 := by decide
theorem cert_e1196686763806 : check e1196686763806 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1196686763830 : Closed e1196686763830 ∧ code e1196686763830 = 5594733274934 := by decide
theorem cert_e1196686763830 : check e1196686763830 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1196686763834 : Closed e1196686763834 ∧ code e1196686763834 = 5594733274938 := by decide
theorem cert_e1196686763834 : check e1196686763834 [[],[.left],[]] .sourceHead = true := by decide
def e1196686763918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1196686763918 : Closed e1196686763918 ∧ code e1196686763918 = 5594733275022 := by decide
theorem cert_e1196686763918 : check e1196686763918 [[],[.left],[]] .sourceHead = true := by decide
def e1196686773998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1196686773998 : Closed e1196686773998 ∧ code e1196686773998 = 5594733285102 := by decide
theorem cert_e1196686773998 : check e1196686773998 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686774006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e1196686774006 : Closed e1196686774006 ∧ code e1196686774006 = 5594733285110 := by decide
theorem cert_e1196686774006 : check e1196686774006 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686774126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1196686774126 : Closed e1196686774126 ∧ code e1196686774126 = 5594733285230 := by decide
theorem cert_e1196686774126 : check e1196686774126 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686774138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e1196686774138 : Closed e1196686774138 ∧ code e1196686774138 = 5594733285242 := by decide
theorem cert_e1196686774138 : checkPay e1196686774138 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.under,.right,.under]] = true := by decide
def e1196686774198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e1196686774198 : Closed e1196686774198 ∧ code e1196686774198 = 5594733285302 := by decide
theorem cert_e1196686774198 : check e1196686774198 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686774202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e1196686774202 : Closed e1196686774202 ∧ code e1196686774202 = 5594733285306 := by decide
theorem cert_e1196686774202 : checkPay e1196686774202 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.under],[.under],[.under,.under,.under,.left,.right,.under]] = true := by decide
def e1196686776814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e1196686776814 : Closed e1196686776814 ∧ code e1196686776814 = 5594733287918 := by decide
theorem cert_e1196686776814 : check e1196686776814 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1196686777966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686777966 : Closed e1196686777966 ∧ code e1196686777966 = 5594733289070 := by decide
theorem cert_e1196686777966 : check e1196686777966 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686777978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686777978 : Closed e1196686777978 ∧ code e1196686777978 = 5594733289082 := by decide
theorem cert_e1196686777978 : check e1196686777978 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1196686781806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1196686781806 : Closed e1196686781806 ∧ code e1196686781806 = 5594733292910 := by decide
theorem cert_e1196686781806 : check e1196686781806 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686781814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1196686781814 : Closed e1196686781814 ∧ code e1196686781814 = 5594733292918 := by decide
theorem cert_e1196686781814 : check e1196686781814 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686781870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1196686781870 : Closed e1196686781870 ∧ code e1196686781870 = 5594733292974 := by decide
theorem cert_e1196686781870 : check e1196686781870 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686781882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1196686781882 : Closed e1196686781882 ∧ code e1196686781882 = 5594733292986 := by decide
theorem cert_e1196686781882 : checkPay e1196686781882 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e1196686781910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1196686781910 : Closed e1196686781910 ∧ code e1196686781910 = 5594733293014 := by decide
theorem cert_e1196686781910 : check e1196686781910 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686781914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1196686781914 : Closed e1196686781914 ∧ code e1196686781914 = 5594733293018 := by decide
theorem cert_e1196686781914 : checkPay e1196686781914 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e1196686782126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e1196686782126 : Closed e1196686782126 ∧ code e1196686782126 = 5594733293230 := by decide
theorem cert_e1196686782126 : check e1196686782126 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686782138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e1196686782138 : Closed e1196686782138 ∧ code e1196686782138 = 5594733293242 := by decide
theorem cert_e1196686782138 : checkPay e1196686782138 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left],[.right,.under],[.right,.under,.under,.left,.right,.right,.left],[.right,.under,.under,.left,.right,.right]] = true := by decide
def e1196686782186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e1196686782186 : Closed e1196686782186 ∧ code e1196686782186 = 5594733293290 := by decide
theorem cert_e1196686782186 : checkPay e1196686782186 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.right,.left],[.left,.right]] = true := by decide
def e1196686782294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1196686782294 : Closed e1196686782294 ∧ code e1196686782294 = 5594733293398 := by decide
theorem cert_e1196686782294 : check e1196686782294 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686782298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1196686782298 : Closed e1196686782298 ∧ code e1196686782298 = 5594733293402 := by decide
theorem cert_e1196686782298 : checkPay e1196686782298 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] = true := by decide
def e1196686782314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1196686782314 : Closed e1196686782314 ∧ code e1196686782314 = 5594733293418 := by decide
theorem cert_e1196686782314 : checkPay e1196686782314 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left,.left],[.left,.left],[.left],[.left,.left,.right,.left],[.left,.left,.right]] = true := by decide
def e1196686782958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1196686782958 : Closed e1196686782958 ∧ code e1196686782958 = 5594733294062 := by decide
theorem cert_e1196686782958 : check e1196686782958 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686783342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1196686783342 : Closed e1196686783342 ∧ code e1196686783342 = 5594733294446 := by decide
theorem cert_e1196686783342 : check e1196686783342 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196686783350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1196686783350 : Closed e1196686783350 ∧ code e1196686783350 = 5594733294454 := by decide
theorem cert_e1196686783350 : check e1196686783350 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
end Blc.Floor42
