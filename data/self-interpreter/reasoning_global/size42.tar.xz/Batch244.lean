import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211283320666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211283320666 : Closed e1211283320666 ∧ code e1211283320666 = 5609329831770 := by decide
theorem cert_e1211283320666 : check e1211283320666 [[],[]] .chain = true := by decide
def e1211283320682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211283320682 : Closed e1211283320682 ∧ code e1211283320682 = 5609329831786 := by decide
theorem cert_e1211283320682 : check e1211283320682 [[],[]] .chain = true := by decide
def e1211283320942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211283320942 : Closed e1211283320942 ∧ code e1211283320942 = 5609329832046 := by decide
theorem cert_e1211283320942 : check e1211283320942 [[],[]] .chain = true := by decide
def e1211283321118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211283321118 : Closed e1211283321118 ∧ code e1211283321118 = 5609329832222 := by decide
theorem cert_e1211283321118 : check e1211283321118 [[],[]] .chain = true := by decide
def e1211283321314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0)))))))))
theorem wire_e1211283321314 : Closed e1211283321314 ∧ code e1211283321314 = 5609329832418 := by decide
theorem cert_e1211283321314 : check e1211283321314 [[],[]] .chain = true := by decide
def e1211283321326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211283321326 : Closed e1211283321326 ∧ code e1211283321326 = 5609329832430 := by decide
theorem cert_e1211283321326 : check e1211283321326 [[],[]] .sourceHead = true := by decide
def e1211283321710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211283321710 : Closed e1211283321710 ∧ code e1211283321710 = 5609329832814 := by decide
theorem cert_e1211283321710 : check e1211283321710 [[],[]] .chain = true := by decide
def e1211283321718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211283321718 : Closed e1211283321718 ∧ code e1211283321718 = 5609329832822 := by decide
theorem cert_e1211283321718 : check e1211283321718 [[],[]] .chain = true := by decide
def e1211283321774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211283321774 : Closed e1211283321774 ∧ code e1211283321774 = 5609329832878 := by decide
theorem cert_e1211283321774 : check e1211283321774 [[],[]] .chain = true := by decide
def e1211283321786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211283321786 : Closed e1211283321786 ∧ code e1211283321786 = 5609329832890 := by decide
theorem cert_e1211283321786 : check e1211283321786 [[],[]] .chain = true := by decide
def e1211283321814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211283321814 : Closed e1211283321814 ∧ code e1211283321814 = 5609329832918 := by decide
theorem cert_e1211283321814 : check e1211283321814 [[],[]] .chain = true := by decide
def e1211283321818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211283321818 : Closed e1211283321818 ∧ code e1211283321818 = 5609329832922 := by decide
theorem cert_e1211283321818 : check e1211283321818 [[],[]] .chain = true := by decide
def e1211283322094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211283322094 : Closed e1211283322094 ∧ code e1211283322094 = 5609329833198 := by decide
theorem cert_e1211283322094 : check e1211283322094 [[],[]] .chain = true := by decide
def e1211283322102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211283322102 : Closed e1211283322102 ∧ code e1211283322102 = 5609329833206 := by decide
theorem cert_e1211283322102 : check e1211283322102 [[],[]] .chain = true := by decide
def e1211283322478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211283322478 : Closed e1211283322478 ∧ code e1211283322478 = 5609329833582 := by decide
theorem cert_e1211283322478 : check e1211283322478 [[],[]] .chain = true := by decide
def e1211283322490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211283322490 : Closed e1211283322490 ∧ code e1211283322490 = 5609329833594 := by decide
theorem cert_e1211283322490 : check e1211283322490 [[],[]] .chain = true := by decide
def e1211283322630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211283322630 : Closed e1211283322630 ∧ code e1211283322630 = 5609329833734 := by decide
theorem cert_e1211283322630 : check e1211283322630 [[],[]] .chain = true := by decide
def e1211283322654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211283322654 : Closed e1211283322654 ∧ code e1211283322654 = 5609329833758 := by decide
theorem cert_e1211283322654 : check e1211283322654 [[],[]] .sourceHead = true := by decide
def e1211283322678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211283322678 : Closed e1211283322678 ∧ code e1211283322678 = 5609329833782 := by decide
theorem cert_e1211283322678 : check e1211283322678 [[],[]] .chain = true := by decide
def e1211283322682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211283322682 : Closed e1211283322682 ∧ code e1211283322682 = 5609329833786 := by decide
theorem cert_e1211283322682 : check e1211283322682 [[],[]] .chain = true := by decide
def e1211283323310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211283323310 : Closed e1211283323310 ∧ code e1211283323310 = 5609329834414 := by decide
theorem cert_e1211283323310 : check e1211283323310 [[],[]] .chain = true := by decide
def e1211283323322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211283323322 : Closed e1211283323322 ∧ code e1211283323322 = 5609329834426 := by decide
theorem cert_e1211283323322 : check e1211283323322 [[],[]] .chain = true := by decide
def e1211283323370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211283323370 : Closed e1211283323370 ∧ code e1211283323370 = 5609329834474 := by decide
theorem cert_e1211283323370 : check e1211283323370 [[],[]] .chain = true := by decide
def e1211283323502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211283323502 : Closed e1211283323502 ∧ code e1211283323502 = 5609329834606 := by decide
theorem cert_e1211283323502 : check e1211283323502 [[],[]] .chain = true := by decide
def e1211283323514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211283323514 : Closed e1211283323514 ∧ code e1211283323514 = 5609329834618 := by decide
theorem cert_e1211283323514 : check e1211283323514 [[],[]] .chain = true := by decide
def e1211283323802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211283323802 : Closed e1211283323802 ∧ code e1211283323802 = 5609329834906 := by decide
theorem cert_e1211283323802 : check e1211283323802 [[],[]] .chain = true := by decide
def e1211283323930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211283323930 : Closed e1211283323930 ∧ code e1211283323930 = 5609329835034 := by decide
theorem cert_e1211283323930 : check e1211283323930 [[],[]] .chain = true := by decide
def e1211283323974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211283323974 : Closed e1211283323974 ∧ code e1211283323974 = 5609329835078 := by decide
theorem cert_e1211283323974 : check e1211283323974 [[],[]] .chain = true := by decide
def e1211283324002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211283324002 : Closed e1211283324002 ∧ code e1211283324002 = 5609329835106 := by decide
theorem cert_e1211283324002 : check e1211283324002 [[],[]] .chain = true := by decide
def e1211283324014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211283324014 : Closed e1211283324014 ∧ code e1211283324014 = 5609329835118 := by decide
theorem cert_e1211283324014 : check e1211283324014 [[],[]] .sourceHead = true := by decide
def e1211283324026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211283324026 : Closed e1211283324026 ∧ code e1211283324026 = 5609329835130 := by decide
theorem cert_e1211283324026 : check e1211283324026 [[],[]] .sourceHead = true := by decide
def e1211283324118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211283324118 : Closed e1211283324118 ∧ code e1211283324118 = 5609329835222 := by decide
theorem cert_e1211283324118 : check e1211283324118 [[],[]] .chain = true := by decide
def e1211283324122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211283324122 : Closed e1211283324122 ∧ code e1211283324122 = 5609329835226 := by decide
theorem cert_e1211283324122 : check e1211283324122 [[],[]] .chain = true := by decide
def e1211283324138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211283324138 : Closed e1211283324138 ∧ code e1211283324138 = 5609329835242 := by decide
theorem cert_e1211283324138 : check e1211283324138 [[],[]] .chain = true := by decide
def e1211283324166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211283324166 : Closed e1211283324166 ∧ code e1211283324166 = 5609329835270 := by decide
theorem cert_e1211283324166 : check e1211283324166 [[],[]] .chain = true := by decide
def e1211283324190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211283324190 : Closed e1211283324190 ∧ code e1211283324190 = 5609329835294 := by decide
theorem cert_e1211283324190 : check e1211283324190 [[],[]] .sourceHead = true := by decide
def e1211283324214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211283324214 : Closed e1211283324214 ∧ code e1211283324214 = 5609329835318 := by decide
theorem cert_e1211283324214 : check e1211283324214 [[],[]] .chain = true := by decide
def e1211283324218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211283324218 : Closed e1211283324218 ∧ code e1211283324218 = 5609329835322 := by decide
theorem cert_e1211283324218 : check e1211283324218 [[],[]] .chain = true := by decide
def e1211283324314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211283324314 : Closed e1211283324314 ∧ code e1211283324314 = 5609329835418 := by decide
theorem cert_e1211283324314 : check e1211283324314 [[],[]] .chain = true := by decide
def e1211283324358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211283324358 : Closed e1211283324358 ∧ code e1211283324358 = 5609329835462 := by decide
theorem cert_e1211283324358 : check e1211283324358 [[],[]] .sourceHead = true := by decide
def e1211283325054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 5)))))))))))
theorem wire_e1211283325054 : Closed e1211283325054 ∧ code e1211283325054 = 5609329836158 := by decide
theorem cert_e1211283325054 : check e1211283325054 [[],[]] .chain = true := by decide
def e1211283325918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211283325918 : Closed e1211283325918 ∧ code e1211283325918 = 5609329837022 := by decide
theorem cert_e1211283325918 : check e1211283325918 [[],[]] .chain = true := by decide
def e1211283325922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e1211283325922 : Closed e1211283325922 ∧ code e1211283325922 = 5609329837026 := by decide
theorem cert_e1211283325922 : check e1211283325922 [[],[]] .chain = true := by decide
def e1211283325934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211283325934 : Closed e1211283325934 ∧ code e1211283325934 = 5609329837038 := by decide
theorem cert_e1211283325934 : check e1211283325934 [[],[]] .chain = true := by decide
def e1211283327854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211283327854 : Closed e1211283327854 ∧ code e1211283327854 = 5609329838958 := by decide
theorem cert_e1211283327854 : check e1211283327854 [[],[]] .chain = true := by decide
def e1211283327862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211283327862 : Closed e1211283327862 ∧ code e1211283327862 = 5609329838966 := by decide
theorem cert_e1211283327862 : check e1211283327862 [[],[]] .chain = true := by decide
def e1211283327918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211283327918 : Closed e1211283327918 ∧ code e1211283327918 = 5609329839022 := by decide
theorem cert_e1211283327918 : check e1211283327918 [[],[]] .chain = true := by decide
def e1211283327930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211283327930 : Closed e1211283327930 ∧ code e1211283327930 = 5609329839034 := by decide
theorem cert_e1211283327930 : check e1211283327930 [[],[]] .chain = true := by decide
def e1211283327958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211283327958 : Closed e1211283327958 ∧ code e1211283327958 = 5609329839062 := by decide
theorem cert_e1211283327958 : check e1211283327958 [[],[]] .chain = true := by decide
def e1211283327962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211283327962 : Closed e1211283327962 ∧ code e1211283327962 = 5609329839066 := by decide
theorem cert_e1211283327962 : check e1211283327962 [[],[]] .chain = true := by decide
def e1211283328238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283328238 : Closed e1211283328238 ∧ code e1211283328238 = 5609329839342 := by decide
theorem cert_e1211283328238 : check e1211283328238 [[],[]] .chain = true := by decide
def e1211283328246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283328246 : Closed e1211283328246 ∧ code e1211283328246 = 5609329839350 := by decide
theorem cert_e1211283328246 : check e1211283328246 [[],[]] .chain = true := by decide
def e1211283328622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211283328622 : Closed e1211283328622 ∧ code e1211283328622 = 5609329839726 := by decide
theorem cert_e1211283328622 : check e1211283328622 [[],[]] .chain = true := by decide
def e1211283328634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211283328634 : Closed e1211283328634 ∧ code e1211283328634 = 5609329839738 := by decide
theorem cert_e1211283328634 : check e1211283328634 [[],[]] .chain = true := by decide
def e1211283328774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211283328774 : Closed e1211283328774 ∧ code e1211283328774 = 5609329839878 := by decide
theorem cert_e1211283328774 : check e1211283328774 [[],[]] .chain = true := by decide
def e1211283328798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211283328798 : Closed e1211283328798 ∧ code e1211283328798 = 5609329839902 := by decide
theorem cert_e1211283328798 : check e1211283328798 [[],[]] .sourceHead = true := by decide
def e1211283328822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283328822 : Closed e1211283328822 ∧ code e1211283328822 = 5609329839926 := by decide
theorem cert_e1211283328822 : check e1211283328822 [[],[]] .chain = true := by decide
def e1211283328826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283328826 : Closed e1211283328826 ∧ code e1211283328826 = 5609329839930 := by decide
theorem cert_e1211283328826 : check e1211283328826 [[],[]] .chain = true := by decide
def e1211283333598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211283333598 : Closed e1211283333598 ∧ code e1211283333598 = 5609329844702 := by decide
theorem cert_e1211283333598 : check e1211283333598 [[],[]] .chain = true := by decide
def e1211283333622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211283333622 : Closed e1211283333622 ∧ code e1211283333622 = 5609329844726 := by decide
theorem cert_e1211283333622 : check e1211283333622 [[],[]] .chain = true := by decide
def e1211283334574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211283334574 : Closed e1211283334574 ∧ code e1211283334574 = 5609329845678 := by decide
theorem cert_e1211283334574 : check e1211283334574 [[],[]] .chain = true := by decide
def e1211283334586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211283334586 : Closed e1211283334586 ∧ code e1211283334586 = 5609329845690 := by decide
theorem cert_e1211283334586 : check e1211283334586 [[],[]] .chain = true := by decide
def e1211283334634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211283334634 : Closed e1211283334634 ∧ code e1211283334634 = 5609329845738 := by decide
theorem cert_e1211283334634 : check e1211283334634 [[],[]] .chain = true := by decide
def e1211283334766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211283334766 : Closed e1211283334766 ∧ code e1211283334766 = 5609329845870 := by decide
theorem cert_e1211283334766 : check e1211283334766 [[],[]] .chain = true := by decide
def e1211283334778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211283334778 : Closed e1211283334778 ∧ code e1211283334778 = 5609329845882 := by decide
theorem cert_e1211283334778 : check e1211283334778 [[],[]] .chain = true := by decide
def e1211283335066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211283335066 : Closed e1211283335066 ∧ code e1211283335066 = 5609329846170 := by decide
theorem cert_e1211283335066 : check e1211283335066 [[],[]] .chain = true := by decide
def e1211283337246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211283337246 : Closed e1211283337246 ∧ code e1211283337246 = 5609329848350 := by decide
theorem cert_e1211283337246 : check e1211283337246 [[],[]] .chain = true := by decide
def e1211283337442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211283337442 : Closed e1211283337442 ∧ code e1211283337442 = 5609329848546 := by decide
theorem cert_e1211283337442 : check e1211283337442 [[],[]] .chain = true := by decide
def e1211283337454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283337454 : Closed e1211283337454 ∧ code e1211283337454 = 5609329848558 := by decide
theorem cert_e1211283337454 : check e1211283337454 [[],[]] .chain = true := by decide
def e1211283337462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283337462 : Closed e1211283337462 ∧ code e1211283337462 = 5609329848566 := by decide
theorem cert_e1211283337462 : check e1211283337462 [[],[]] .chain = true := by decide
def e1211283337942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211283337942 : Closed e1211283337942 ∧ code e1211283337942 = 5609329849046 := by decide
theorem cert_e1211283337942 : check e1211283337942 [[],[]] .chain = true := by decide
def e1211283337946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211283337946 : Closed e1211283337946 ∧ code e1211283337946 = 5609329849050 := by decide
theorem cert_e1211283337946 : check e1211283337946 [[],[]] .chain = true := by decide
def e1211283337962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211283337962 : Closed e1211283337962 ∧ code e1211283337962 = 5609329849066 := by decide
theorem cert_e1211283337962 : check e1211283337962 [[],[]] .chain = true := by decide
def e1211283337990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211283337990 : Closed e1211283337990 ∧ code e1211283337990 = 5609329849094 := by decide
theorem cert_e1211283337990 : check e1211283337990 [[],[]] .chain = true := by decide
def e1211283338014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211283338014 : Closed e1211283338014 ∧ code e1211283338014 = 5609329849118 := by decide
theorem cert_e1211283338014 : check e1211283338014 [[],[]] .sourceHead = true := by decide
def e1211283338038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283338038 : Closed e1211283338038 ∧ code e1211283338038 = 5609329849142 := by decide
theorem cert_e1211283338038 : check e1211283338038 [[],[]] .chain = true := by decide
def e1211283338042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283338042 : Closed e1211283338042 ∧ code e1211283338042 = 5609329849146 := by decide
theorem cert_e1211283338042 : check e1211283338042 [[],[]] .chain = true := by decide
def e1211283338138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211283338138 : Closed e1211283338138 ∧ code e1211283338138 = 5609329849242 := by decide
theorem cert_e1211283338138 : check e1211283338138 [[],[]] .chain = true := by decide
def e1211283338182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211283338182 : Closed e1211283338182 ∧ code e1211283338182 = 5609329849286 := by decide
theorem cert_e1211283338182 : check e1211283338182 [[],[]] .sourceHead = true := by decide
def e1211283412702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211283412702 : Closed e1211283412702 ∧ code e1211283412702 = 5609329923806 := by decide
theorem cert_e1211283412702 : check e1211283412702 [[],[]] .sourceHead = true := by decide
def e1211283412726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211283412726 : Closed e1211283412726 ∧ code e1211283412726 = 5609329923830 := by decide
theorem cert_e1211283412726 : check e1211283412726 [[],[]] .sourceHead = true := by decide
def e1211283412830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211283412830 : Closed e1211283412830 ∧ code e1211283412830 = 5609329923934 := by decide
theorem cert_e1211283412830 : check e1211283412830 [[],[]] .sourceHead = true := by decide
def e1211283412846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211283412846 : Closed e1211283412846 ∧ code e1211283412846 = 5609329923950 := by decide
theorem cert_e1211283412846 : check e1211283412846 [[],[]] .chain = true := by decide
def e1211283412854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211283412854 : Closed e1211283412854 ∧ code e1211283412854 = 5609329923958 := by decide
theorem cert_e1211283412854 : check e1211283412854 [[],[]] .chain = true := by decide
def e1211283412858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211283412858 : Closed e1211283412858 ∧ code e1211283412858 = 5609329923962 := by decide
theorem cert_e1211283412858 : check e1211283412858 [[],[]] .sourceHead = true := by decide
def e1211283412918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211283412918 : Closed e1211283412918 ∧ code e1211283412918 = 5609329924022 := by decide
theorem cert_e1211283412918 : check e1211283412918 [[],[]] .chain = true := by decide
def e1211283412950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211283412950 : Closed e1211283412950 ∧ code e1211283412950 = 5609329924054 := by decide
theorem cert_e1211283412950 : check e1211283412950 [[],[]] .sourceHead = true := by decide
def e1211283412954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211283412954 : Closed e1211283412954 ∧ code e1211283412954 = 5609329924058 := by decide
theorem cert_e1211283412954 : check e1211283412954 [[],[]] .sourceHead = true := by decide
def e1211283413470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211283413470 : Closed e1211283413470 ∧ code e1211283413470 = 5609329924574 := by decide
theorem cert_e1211283413470 : check e1211283413470 [[],[]] .sourceHead = true := by decide
def e1211283413494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211283413494 : Closed e1211283413494 ∧ code e1211283413494 = 5609329924598 := by decide
theorem cert_e1211283413494 : check e1211283413494 [[],[]] .sourceHead = true := by decide
def e1211283414238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211283414238 : Closed e1211283414238 ∧ code e1211283414238 = 5609329925342 := by decide
theorem cert_e1211283414238 : check e1211283414238 [[],[]] .sourceHead = true := by decide
def e1211283414254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283414254 : Closed e1211283414254 ∧ code e1211283414254 = 5609329925358 := by decide
theorem cert_e1211283414254 : check e1211283414254 [[],[]] .chain = true := by decide
def e1211283414262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283414262 : Closed e1211283414262 ∧ code e1211283414262 = 5609329925366 := by decide
theorem cert_e1211283414262 : check e1211283414262 [[],[]] .chain = true := by decide
def e1211283414266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211283414266 : Closed e1211283414266 ∧ code e1211283414266 = 5609329925370 := by decide
theorem cert_e1211283414266 : check e1211283414266 [[],[]] .sourceHead = true := by decide
def e1211283414646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211283414646 : Closed e1211283414646 ∧ code e1211283414646 = 5609329925750 := by decide
theorem cert_e1211283414646 : check e1211283414646 [[],[]] .chain = true := by decide
def e1211283414838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283414838 : Closed e1211283414838 ∧ code e1211283414838 = 5609329925942 := by decide
theorem cert_e1211283414838 : check e1211283414838 [[],[]] .sourceHead = true := by decide
def e1211283414842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283414842 : Closed e1211283414842 ∧ code e1211283414842 = 5609329925946 := by decide
theorem cert_e1211283414842 : check e1211283414842 [[],[]] .sourceHead = true := by decide
def e1211283429046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211283429046 : Closed e1211283429046 ∧ code e1211283429046 = 5609329940150 := by decide
theorem cert_e1211283429046 : check e1211283429046 [[],[]] .chain = true := by decide
def e1211283429078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211283429078 : Closed e1211283429078 ∧ code e1211283429078 = 5609329940182 := by decide
theorem cert_e1211283429078 : check e1211283429078 [[],[]] .chain = true := by decide
def e1211283429082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211283429082 : Closed e1211283429082 ∧ code e1211283429082 = 5609329940186 := by decide
theorem cert_e1211283429082 : check e1211283429082 [[],[]] .chain = true := by decide
def e1211283429206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211283429206 : Closed e1211283429206 ∧ code e1211283429206 = 5609329940310 := by decide
theorem cert_e1211283429206 : check e1211283429206 [[],[]] .chain = true := by decide
def e1211283429210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211283429210 : Closed e1211283429210 ∧ code e1211283429210 = 5609329940314 := by decide
theorem cert_e1211283429210 : check e1211283429210 [[],[]] .chain = true := by decide
def e1211283429226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211283429226 : Closed e1211283429226 ∧ code e1211283429226 = 5609329940330 := by decide
theorem cert_e1211283429226 : check e1211283429226 [[],[]] .chain = true := by decide
def e1211283429430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211283429430 : Closed e1211283429430 ∧ code e1211283429430 = 5609329940534 := by decide
theorem cert_e1211283429430 : check e1211283429430 [[],[]] .chain = true := by decide
def e1211283429518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211283429518 : Closed e1211283429518 ∧ code e1211283429518 = 5609329940622 := by decide
theorem cert_e1211283429518 : check e1211283429518 [[],[]] .chain = true := by decide
def e1211283429602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211283429602 : Closed e1211283429602 ∧ code e1211283429602 = 5609329940706 := by decide
theorem cert_e1211283429602 : check e1211283429602 [[],[]] .chain = true := by decide
def e1211283429614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211283429614 : Closed e1211283429614 ∧ code e1211283429614 = 5609329940718 := by decide
theorem cert_e1211283429614 : check e1211283429614 [[],[]] .sourceHead = true := by decide
def e1211283429622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211283429622 : Closed e1211283429622 ∧ code e1211283429622 = 5609329940726 := by decide
theorem cert_e1211283429622 : check e1211283429622 [[],[]] .sourceHead = true := by decide
def e1211283429814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211283429814 : Closed e1211283429814 ∧ code e1211283429814 = 5609329940918 := by decide
theorem cert_e1211283429814 : check e1211283429814 [[],[]] .chain = true := by decide
def e1211283429846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211283429846 : Closed e1211283429846 ∧ code e1211283429846 = 5609329940950 := by decide
theorem cert_e1211283429846 : check e1211283429846 [[],[]] .chain = true := by decide
def e1211283429850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211283429850 : Closed e1211283429850 ∧ code e1211283429850 = 5609329940954 := by decide
theorem cert_e1211283429850 : check e1211283429850 [[],[]] .chain = true := by decide
def e1211283430006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211283430006 : Closed e1211283430006 ∧ code e1211283430006 = 5609329941110 := by decide
theorem cert_e1211283430006 : check e1211283430006 [[],[]] .chain = true := by decide
def e1211283430150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211283430150 : Closed e1211283430150 ∧ code e1211283430150 = 5609329941254 := by decide
theorem cert_e1211283430150 : check e1211283430150 [[],[]] .chain = true := by decide
def e1211283430174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211283430174 : Closed e1211283430174 ∧ code e1211283430174 = 5609329941278 := by decide
theorem cert_e1211283430174 : check e1211283430174 [[],[]] .sourceHead = true := by decide
def e1211283430198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211283430198 : Closed e1211283430198 ∧ code e1211283430198 = 5609329941302 := by decide
theorem cert_e1211283430198 : check e1211283430198 [[],[]] .chain = true := by decide
def e1211283430202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211283430202 : Closed e1211283430202 ∧ code e1211283430202 = 5609329941306 := by decide
theorem cert_e1211283430202 : check e1211283430202 [[],[]] .chain = true := by decide
def e1211283430286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211283430286 : Closed e1211283430286 ∧ code e1211283430286 = 5609329941390 := by decide
theorem cert_e1211283430286 : check e1211283430286 [[],[]] .sourceHead = true := by decide
def e1211283430426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211283430426 : Closed e1211283430426 ∧ code e1211283430426 = 5609329941530 := by decide
theorem cert_e1211283430426 : check e1211283430426 [[],[]] .chain = true := by decide
def e1211283430470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211283430470 : Closed e1211283430470 ∧ code e1211283430470 = 5609329941574 := by decide
theorem cert_e1211283430470 : check e1211283430470 [[],[]] .chain = true := by decide
def e1211283430498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211283430498 : Closed e1211283430498 ∧ code e1211283430498 = 5609329941602 := by decide
theorem cert_e1211283430498 : check e1211283430498 [[],[]] .chain = true := by decide
def e1211283430510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211283430510 : Closed e1211283430510 ∧ code e1211283430510 = 5609329941614 := by decide
theorem cert_e1211283430510 : check e1211283430510 [[],[]] .sourceHead = true := by decide
def e1211283430522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211283430522 : Closed e1211283430522 ∧ code e1211283430522 = 5609329941626 := by decide
theorem cert_e1211283430522 : check e1211283430522 [[],[]] .sourceHead = true := by decide
def e1211283430614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211283430614 : Closed e1211283430614 ∧ code e1211283430614 = 5609329941718 := by decide
theorem cert_e1211283430614 : check e1211283430614 [[],[]] .chain = true := by decide
def e1211283430618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211283430618 : Closed e1211283430618 ∧ code e1211283430618 = 5609329941722 := by decide
theorem cert_e1211283430618 : check e1211283430618 [[],[]] .chain = true := by decide
def e1211283430634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211283430634 : Closed e1211283430634 ∧ code e1211283430634 = 5609329941738 := by decide
theorem cert_e1211283430634 : check e1211283430634 [[],[]] .chain = true := by decide
def e1211283430662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211283430662 : Closed e1211283430662 ∧ code e1211283430662 = 5609329941766 := by decide
theorem cert_e1211283430662 : check e1211283430662 [[],[]] .chain = true := by decide
def e1211283430686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211283430686 : Closed e1211283430686 ∧ code e1211283430686 = 5609329941790 := by decide
theorem cert_e1211283430686 : check e1211283430686 [[],[]] .sourceHead = true := by decide
def e1211283430710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211283430710 : Closed e1211283430710 ∧ code e1211283430710 = 5609329941814 := by decide
theorem cert_e1211283430710 : check e1211283430710 [[],[]] .chain = true := by decide
def e1211283430714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211283430714 : Closed e1211283430714 ∧ code e1211283430714 = 5609329941818 := by decide
theorem cert_e1211283430714 : check e1211283430714 [[],[]] .chain = true := by decide
def e1211283430810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211283430810 : Closed e1211283430810 ∧ code e1211283430810 = 5609329941914 := by decide
theorem cert_e1211283430810 : check e1211283430810 [[],[]] .chain = true := by decide
def e1211283430854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211283430854 : Closed e1211283430854 ∧ code e1211283430854 = 5609329941958 := by decide
theorem cert_e1211283430854 : check e1211283430854 [[],[]] .sourceHead = true := by decide
def e1211283430966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211283430966 : Closed e1211283430966 ∧ code e1211283430966 = 5609329942070 := by decide
theorem cert_e1211283430966 : check e1211283430966 [[],[]] .sourceHead = true := by decide
def e1211283430970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211283430970 : Closed e1211283430970 ∧ code e1211283430970 = 5609329942074 := by decide
theorem cert_e1211283430970 : check e1211283430970 [[],[]] .sourceHead = true := by decide
def e1211283431054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211283431054 : Closed e1211283431054 ∧ code e1211283431054 = 5609329942158 := by decide
theorem cert_e1211283431054 : check e1211283431054 [[],[]] .sourceHead = true := by decide
def e1211283431110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211283431110 : Closed e1211283431110 ∧ code e1211283431110 = 5609329942214 := by decide
theorem cert_e1211283431110 : check e1211283431110 [[],[]] .sourceHead = true := by decide
def e1211283431486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211283431486 : Closed e1211283431486 ∧ code e1211283431486 = 5609329942590 := by decide
theorem cert_e1211283431486 : check e1211283431486 [[],[]] .chain = true := by decide
def e1211283431906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211283431906 : Closed e1211283431906 ∧ code e1211283431906 = 5609329943010 := by decide
theorem cert_e1211283431906 : check e1211283431906 [[],[]] .chain = true := by decide
def e1211283431918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211283431918 : Closed e1211283431918 ∧ code e1211283431918 = 5609329943022 := by decide
theorem cert_e1211283431918 : check e1211283431918 [[],[]] .chain = true := by decide
def e1211283432886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211283432886 : Closed e1211283432886 ∧ code e1211283432886 = 5609329943990 := by decide
theorem cert_e1211283432886 : check e1211283432886 [[],[]] .chain = true := by decide
def e1211283432918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211283432918 : Closed e1211283432918 ∧ code e1211283432918 = 5609329944022 := by decide
theorem cert_e1211283432918 : check e1211283432918 [[],[]] .chain = true := by decide
def e1211283432922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211283432922 : Closed e1211283432922 ∧ code e1211283432922 = 5609329944026 := by decide
theorem cert_e1211283432922 : check e1211283432922 [[],[]] .chain = true := by decide
def e1211283433078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211283433078 : Closed e1211283433078 ∧ code e1211283433078 = 5609329944182 := by decide
theorem cert_e1211283433078 : check e1211283433078 [[],[]] .chain = true := by decide
def e1211283433222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211283433222 : Closed e1211283433222 ∧ code e1211283433222 = 5609329944326 := by decide
theorem cert_e1211283433222 : check e1211283433222 [[],[]] .chain = true := by decide
def e1211283433246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211283433246 : Closed e1211283433246 ∧ code e1211283433246 = 5609329944350 := by decide
theorem cert_e1211283433246 : check e1211283433246 [[],[]] .sourceHead = true := by decide
def e1211283433270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283433270 : Closed e1211283433270 ∧ code e1211283433270 = 5609329944374 := by decide
theorem cert_e1211283433270 : check e1211283433270 [[],[]] .chain = true := by decide
def e1211283433274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283433274 : Closed e1211283433274 ∧ code e1211283433274 = 5609329944378 := by decide
theorem cert_e1211283433274 : check e1211283433274 [[],[]] .chain = true := by decide
def e1211283433358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211283433358 : Closed e1211283433358 ∧ code e1211283433358 = 5609329944462 := by decide
theorem cert_e1211283433358 : check e1211283433358 [[],[]] .sourceHead = true := by decide
def e1211283435550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211283435550 : Closed e1211283435550 ∧ code e1211283435550 = 5609329946654 := by decide
theorem cert_e1211283435550 : check e1211283435550 [[],[]] .chain = true := by decide
def e1211283435746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211283435746 : Closed e1211283435746 ∧ code e1211283435746 = 5609329946850 := by decide
theorem cert_e1211283435746 : check e1211283435746 [[],[]] .chain = true := by decide
def e1211283435758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211283435758 : Closed e1211283435758 ∧ code e1211283435758 = 5609329946862 := by decide
theorem cert_e1211283435758 : check e1211283435758 [[],[]] .chain = true := by decide
def e1211283435766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211283435766 : Closed e1211283435766 ∧ code e1211283435766 = 5609329946870 := by decide
theorem cert_e1211283435766 : check e1211283435766 [[],[]] .chain = true := by decide
def e1211283436246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211283436246 : Closed e1211283436246 ∧ code e1211283436246 = 5609329947350 := by decide
theorem cert_e1211283436246 : check e1211283436246 [[],[]] .chain = true := by decide
def e1211283436250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211283436250 : Closed e1211283436250 ∧ code e1211283436250 = 5609329947354 := by decide
theorem cert_e1211283436250 : check e1211283436250 [[],[]] .chain = true := by decide
def e1211283436266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211283436266 : Closed e1211283436266 ∧ code e1211283436266 = 5609329947370 := by decide
theorem cert_e1211283436266 : check e1211283436266 [[],[]] .chain = true := by decide
def e1211283436294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211283436294 : Closed e1211283436294 ∧ code e1211283436294 = 5609329947398 := by decide
theorem cert_e1211283436294 : check e1211283436294 [[],[]] .chain = true := by decide
def e1211283436318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211283436318 : Closed e1211283436318 ∧ code e1211283436318 = 5609329947422 := by decide
theorem cert_e1211283436318 : check e1211283436318 [[],[]] .sourceHead = true := by decide
def e1211283436342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211283436342 : Closed e1211283436342 ∧ code e1211283436342 = 5609329947446 := by decide
theorem cert_e1211283436342 : check e1211283436342 [[],[]] .chain = true := by decide
def e1211283436346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211283436346 : Closed e1211283436346 ∧ code e1211283436346 = 5609329947450 := by decide
theorem cert_e1211283436346 : check e1211283436346 [[],[]] .chain = true := by decide
def e1211283436442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211283436442 : Closed e1211283436442 ∧ code e1211283436442 = 5609329947546 := by decide
theorem cert_e1211283436442 : check e1211283436442 [[],[]] .chain = true := by decide
def e1211283436486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211283436486 : Closed e1211283436486 ∧ code e1211283436486 = 5609329947590 := by decide
theorem cert_e1211283436486 : check e1211283436486 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
