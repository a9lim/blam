import Batch076
import ExtraBase
namespace Blc.Floor42.Extra076
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1196686669546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem ex_e1196686669546 : ¬ IsSelfInterpreter e1196686669546 := by
  intro he
  have hp := replay_sound (t := e1196686669546) (u := t_e1196686669546) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.var 0))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2)) (SO.var 0)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686669546
private def t_e1196686669674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem ex_e1196686669674 : ¬ IsSelfInterpreter e1196686669674 := by
  intro he
  have hp := replay_sound (t := e1196686669674) (u := t_e1196686669674) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.var 0))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1)) (SO.var 0)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686669674
private def t_e1196686670698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem ex_e1196686670698 : ¬ IsSelfInterpreter e1196686670698 := by
  intro he
  have hp := replay_sound (t := e1196686670698) (u := t_e1196686670698) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.var 0))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1)) (SO.var 0)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196686670698
end Blc.Floor42.Extra076
