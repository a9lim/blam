import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205813090030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1205813090030 : Closed e1205813090030 ∧ code e1205813090030 = 5603859601134 := by decide
theorem cert_e1205813090030 : check e1205813090030 [[],[]] .three = true := by decide
def e1205813090038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1205813090038 : Closed e1205813090038 ∧ code e1205813090038 = 5603859601142 := by decide
theorem cert_e1205813090038 : check e1205813090038 [[],[]] .three = true := by decide
def e1205813090074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1205813090074 : Closed e1205813090074 ∧ code e1205813090074 = 5603859601178 := by decide
theorem cert_e1205813090074 : check e1205813090074 [[],[]] .three = true := by decide
def e1205813090118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1205813090118 : Closed e1205813090118 ∧ code e1205813090118 = 5603859601222 := by decide
theorem cert_e1205813090118 : check e1205813090118 [[],[]] .three = true := by decide
def e1205813090142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1205813090142 : Closed e1205813090142 ∧ code e1205813090142 = 5603859601246 := by decide
theorem cert_e1205813090142 : check e1205813090142 [[],[]] .three = true := by decide
def e1205813090158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1205813090158 : Closed e1205813090158 ∧ code e1205813090158 = 5603859601262 := by decide
theorem cert_e1205813090158 : check e1205813090158 [[],[]] .three = true := by decide
def e1205813090166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1205813090166 : Closed e1205813090166 ∧ code e1205813090166 = 5603859601270 := by decide
theorem cert_e1205813090166 : check e1205813090166 [[],[]] .three = true := by decide
def e1205813090170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1205813090170 : Closed e1205813090170 ∧ code e1205813090170 = 5603859601274 := by decide
theorem cert_e1205813090170 : check e1205813090170 [[],[]] .three = true := by decide
def e1205813090222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1205813090222 : Closed e1205813090222 ∧ code e1205813090222 = 5603859601326 := by decide
theorem cert_e1205813090222 : check e1205813090222 [[],[]] .three = true := by decide
def e1205813090230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1205813090230 : Closed e1205813090230 ∧ code e1205813090230 = 5603859601334 := by decide
theorem cert_e1205813090230 : check e1205813090230 [[],[]] .three = true := by decide
def e1205813090234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1205813090234 : Closed e1205813090234 ∧ code e1205813090234 = 5603859601338 := by decide
theorem cert_e1205813090234 : check e1205813090234 [[],[]] .three = true := by decide
def e1205813090262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1205813090262 : Closed e1205813090262 ∧ code e1205813090262 = 5603859601366 := by decide
theorem cert_e1205813090262 : check e1205813090262 [[],[]] .three = true := by decide
def e1205813090266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1205813090266 : Closed e1205813090266 ∧ code e1205813090266 = 5603859601370 := by decide
theorem cert_e1205813090266 : check e1205813090266 [[],[]] .three = true := by decide
def e1205813090702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205813090702 : Closed e1205813090702 ∧ code e1205813090702 = 5603859601806 := by decide
theorem cert_e1205813090702 : check e1205813090702 [[],[]] .three = true := by decide
def e1205813090758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205813090758 : Closed e1205813090758 ∧ code e1205813090758 = 5603859601862 := by decide
theorem cert_e1205813090758 : check e1205813090758 [[],[]] .three = true := by decide
def e1205813090782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205813090782 : Closed e1205813090782 ∧ code e1205813090782 = 5603859601886 := by decide
theorem cert_e1205813090782 : check e1205813090782 [[],[]] .three = true := by decide
def e1205813090798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205813090798 : Closed e1205813090798 ∧ code e1205813090798 = 5603859601902 := by decide
theorem cert_e1205813090798 : check e1205813090798 [[],[]] .three = true := by decide
def e1205813090806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205813090806 : Closed e1205813090806 ∧ code e1205813090806 = 5603859601910 := by decide
theorem cert_e1205813090806 : check e1205813090806 [[],[]] .three = true := by decide
def e1205813091526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1205813091526 : Closed e1205813091526 ∧ code e1205813091526 = 5603859602630 := by decide
theorem cert_e1205813091526 : check e1205813091526 [[],[]] .three = true := by decide
def e1205813091550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205813091550 : Closed e1205813091550 ∧ code e1205813091550 = 5603859602654 := by decide
theorem cert_e1205813091550 : check e1205813091550 [[],[]] .three = true := by decide
def e1205813091566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205813091566 : Closed e1205813091566 ∧ code e1205813091566 = 5603859602670 := by decide
theorem cert_e1205813091566 : check e1205813091566 [[],[]] .three = true := by decide
def e1205813091574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205813091574 : Closed e1205813091574 ∧ code e1205813091574 = 5603859602678 := by decide
theorem cert_e1205813091574 : check e1205813091574 [[],[]] .three = true := by decide
def e1205813091578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205813091578 : Closed e1205813091578 ∧ code e1205813091578 = 5603859602682 := by decide
theorem cert_e1205813091578 : check e1205813091578 [[],[]] .three = true := by decide
def e1205813091950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205813091950 : Closed e1205813091950 ∧ code e1205813091950 = 5603859603054 := by decide
theorem cert_e1205813091950 : check e1205813091950 [[],[]] .three = true := by decide
def e1205813091958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205813091958 : Closed e1205813091958 ∧ code e1205813091958 = 5603859603062 := by decide
theorem cert_e1205813091958 : check e1205813091958 [[],[]] .three = true := by decide
def e1205813091962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205813091962 : Closed e1205813091962 ∧ code e1205813091962 = 5603859603066 := by decide
theorem cert_e1205813091962 : check e1205813091962 [[],[]] .three = true := by decide
def e1205813092150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205813092150 : Closed e1205813092150 ∧ code e1205813092150 = 5603859603254 := by decide
theorem cert_e1205813092150 : check e1205813092150 [[],[]] .three = true := by decide
def e1205813092154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205813092154 : Closed e1205813092154 ∧ code e1205813092154 = 5603859603258 := by decide
theorem cert_e1205813092154 : check e1205813092154 [[],[]] .three = true := by decide
def e1205814381422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205814381422 : Closed e1205814381422 ∧ code e1205814381422 = 5603860892526 := by decide
theorem cert_e1205814381422 : check e1205814381422 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1205814381430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205814381430 : Closed e1205814381430 ∧ code e1205814381430 = 5603860892534 := by decide
theorem cert_e1205814381430 : check e1205814381430 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814381486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205814381486 : Closed e1205814381486 ∧ code e1205814381486 = 5603860892590 := by decide
theorem cert_e1205814381486 : check e1205814381486 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1205814381498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205814381498 : Closed e1205814381498 ∧ code e1205814381498 = 5603860892602 := by decide
theorem cert_e1205814381498 : check e1205814381498 [[],[],[.under,.under]] .sourceHead = true := by decide
def e1205814381526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205814381526 : Closed e1205814381526 ∧ code e1205814381526 = 5603860892630 := by decide
theorem cert_e1205814381526 : check e1205814381526 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814381530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205814381530 : Closed e1205814381530 ∧ code e1205814381530 = 5603860892634 := by decide
theorem cert_e1205814381530 : check e1205814381530 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814381806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205814381806 : Closed e1205814381806 ∧ code e1205814381806 = 5603860892910 := by decide
theorem cert_e1205814381806 : check e1205814381806 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e1205814381814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205814381814 : Closed e1205814381814 ∧ code e1205814381814 = 5603860892918 := by decide
theorem cert_e1205814381814 : check e1205814381814 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814382190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205814382190 : Closed e1205814382190 ∧ code e1205814382190 = 5603860893294 := by decide
theorem cert_e1205814382190 : checkPay e1205814382190 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under,.under]] = true := by decide
def e1205814382202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205814382202 : Closed e1205814382202 ∧ code e1205814382202 = 5603860893306 := by decide
theorem cert_e1205814382202 : checkPay e1205814382202 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under,.under]] = true := by decide
def e1205814382390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205814382390 : Closed e1205814382390 ∧ code e1205814382390 = 5603860893494 := by decide
theorem cert_e1205814382390 : check e1205814382390 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814382394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205814382394 : Closed e1205814382394 ∧ code e1205814382394 = 5603860893498 := by decide
theorem cert_e1205814382394 : check e1205814382394 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814743926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1205814743926 : Closed e1205814743926 ∧ code e1205814743926 = 5603861255030 := by decide
theorem cert_e1205814743926 : check e1205814743926 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1205814743994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1205814743994 : Closed e1205814743994 ∧ code e1205814743994 = 5603861255098 := by decide
theorem cert_e1205814743994 : check e1205814743994 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e1205814744022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1205814744022 : Closed e1205814744022 ∧ code e1205814744022 = 5603861255126 := by decide
theorem cert_e1205814744022 : check e1205814744022 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814744026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1205814744026 : Closed e1205814744026 ∧ code e1205814744026 = 5603861255130 := by decide
theorem cert_e1205814744026 : check e1205814744026 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205814871406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1205814871406 : Closed e1205814871406 ∧ code e1205814871406 = 5603861382510 := by decide
theorem cert_e1205814871406 : check e1205814871406 [[],[]] .chain = true := by decide
def e1205814871414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1205814871414 : Closed e1205814871414 ∧ code e1205814871414 = 5603861382518 := by decide
theorem cert_e1205814871414 : check e1205814871414 [[],[]] .chain = true := by decide
def e1205814871470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1205814871470 : Closed e1205814871470 ∧ code e1205814871470 = 5603861382574 := by decide
theorem cert_e1205814871470 : check e1205814871470 [[],[]] .chain = true := by decide
def e1205814871482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1205814871482 : Closed e1205814871482 ∧ code e1205814871482 = 5603861382586 := by decide
theorem cert_e1205814871482 : check e1205814871482 [[],[]] .chain = true := by decide
def e1205814871510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1205814871510 : Closed e1205814871510 ∧ code e1205814871510 = 5603861382614 := by decide
theorem cert_e1205814871510 : check e1205814871510 [[],[]] .chain = true := by decide
def e1205814871514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1205814871514 : Closed e1205814871514 ∧ code e1205814871514 = 5603861382618 := by decide
theorem cert_e1205814871514 : check e1205814871514 [[],[]] .chain = true := by decide
def e1205814874478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1205814874478 : Closed e1205814874478 ∧ code e1205814874478 = 5603861385582 := by decide
theorem cert_e1205814874478 : check e1205814874478 [[],[]] .chain = true := by decide
def e1205814874486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1205814874486 : Closed e1205814874486 ∧ code e1205814874486 = 5603861385590 := by decide
theorem cert_e1205814874486 : check e1205814874486 [[],[]] .chain = true := by decide
def e1205814875694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e1205814875694 : Closed e1205814875694 ∧ code e1205814875694 = 5603861386798 := by decide
theorem cert_e1205814875694 : check e1205814875694 [[],[]] .chain = true := by decide
def e1205814875874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1205814875874 : Closed e1205814875874 ∧ code e1205814875874 = 5603861386978 := by decide
theorem cert_e1205814875874 : check e1205814875874 [[],[]] .chain = true := by decide
def e1205814875886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1205814875886 : Closed e1205814875886 ∧ code e1205814875886 = 5603861386990 := by decide
theorem cert_e1205814875886 : check e1205814875886 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814875926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e1205814875926 : Closed e1205814875926 ∧ code e1205814875926 = 5603861387030 := by decide
theorem cert_e1205814875926 : check e1205814875926 [[],[]] .chain = true := by decide
def e1205814876002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1205814876002 : Closed e1205814876002 ∧ code e1205814876002 = 5603861387106 := by decide
theorem cert_e1205814876002 : check e1205814876002 [[],[]] .chain = true := by decide
def e1205814876014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1205814876014 : Closed e1205814876014 ∧ code e1205814876014 = 5603861387118 := by decide
theorem cert_e1205814876014 : check e1205814876014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814876022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1205814876022 : Closed e1205814876022 ∧ code e1205814876022 = 5603861387126 := by decide
theorem cert_e1205814876022 : check e1205814876022 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814876334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1205814876334 : Closed e1205814876334 ∧ code e1205814876334 = 5603861387438 := by decide
theorem cert_e1205814876334 : check e1205814876334 [[],[]] .chain = true := by decide
def e1205814876346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1205814876346 : Closed e1205814876346 ∧ code e1205814876346 = 5603861387450 := by decide
theorem cert_e1205814876346 : check e1205814876346 [[],[]] .chain = true := by decide
def e1205814876718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e1205814876718 : Closed e1205814876718 ∧ code e1205814876718 = 5603861387822 := by decide
theorem cert_e1205814876718 : check e1205814876718 [[],[]] .chain = true := by decide
def e1205814876898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1205814876898 : Closed e1205814876898 ∧ code e1205814876898 = 5603861388002 := by decide
theorem cert_e1205814876898 : check e1205814876898 [[],[]] .chain = true := by decide
def e1205814876910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1205814876910 : Closed e1205814876910 ∧ code e1205814876910 = 5603861388014 := by decide
theorem cert_e1205814876910 : check e1205814876910 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1205814877038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1205814877038 : Closed e1205814877038 ∧ code e1205814877038 = 5603861388142 := by decide
theorem cert_e1205814877038 : check e1205814877038 [[],[]] .chain = true := by decide
def e1205814877046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1205814877046 : Closed e1205814877046 ∧ code e1205814877046 = 5603861388150 := by decide
theorem cert_e1205814877046 : check e1205814877046 [[],[]] .chain = true := by decide
def e1205814877066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814877066 : Closed e1205814877066 ∧ code e1205814877066 = 5603861388170 := by decide
theorem cert_e1205814877066 : check e1205814877066 [[],[]] .chain = true := by decide
def e1205814877090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814877090 : Closed e1205814877090 ∧ code e1205814877090 = 5603861388194 := by decide
theorem cert_e1205814877090 : check e1205814877090 [[],[]] .chain = true := by decide
def e1205814877102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1205814877102 : Closed e1205814877102 ∧ code e1205814877102 = 5603861388206 := by decide
theorem cert_e1205814877102 : check e1205814877102 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1205814877110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1205814877110 : Closed e1205814877110 ∧ code e1205814877110 = 5603861388214 := by decide
theorem cert_e1205814877110 : check e1205814877110 [[],[]] .chain = true := by decide
def e1205814877114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1205814877114 : Closed e1205814877114 ∧ code e1205814877114 = 5603861388218 := by decide
theorem cert_e1205814877114 : check e1205814877114 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1205814877270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1205814877270 : Closed e1205814877270 ∧ code e1205814877270 = 5603861388374 := by decide
theorem cert_e1205814877270 : check e1205814877270 [[],[]] .chain = true := by decide
def e1205814877274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1205814877274 : Closed e1205814877274 ∧ code e1205814877274 = 5603861388378 := by decide
theorem cert_e1205814877274 : check e1205814877274 [[],[]] .chain = true := by decide
def e1205814877462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e1205814877462 : Closed e1205814877462 ∧ code e1205814877462 = 5603861388566 := by decide
theorem cert_e1205814877462 : check e1205814877462 [[],[]] .chain = true := by decide
def e1205814877538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1205814877538 : Closed e1205814877538 ∧ code e1205814877538 = 5603861388642 := by decide
theorem cert_e1205814877538 : check e1205814877538 [[],[]] .chain = true := by decide
def e1205814877550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1205814877550 : Closed e1205814877550 ∧ code e1205814877550 = 5603861388654 := by decide
theorem cert_e1205814877550 : check e1205814877550 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814877558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1205814877558 : Closed e1205814877558 ∧ code e1205814877558 = 5603861388662 := by decide
def e1205814877578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814877578 : Closed e1205814877578 ∧ code e1205814877578 = 5603861388682 := by decide
theorem cert_e1205814877578 : check e1205814877578 [[],[]] .chain = true := by decide
def e1205814877602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814877602 : Closed e1205814877602 ∧ code e1205814877602 = 5603861388706 := by decide
theorem cert_e1205814877602 : check e1205814877602 [[],[]] .chain = true := by decide
def e1205814877614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1205814877614 : Closed e1205814877614 ∧ code e1205814877614 = 5603861388718 := by decide
theorem cert_e1205814877614 : check e1205814877614 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1205814877622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e1205814877622 : Closed e1205814877622 ∧ code e1205814877622 = 5603861388726 := by decide
theorem cert_e1205814877622 : check e1205814877622 [[],[]] .chain = true := by decide
def e1205814877626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1205814877626 : Closed e1205814877626 ∧ code e1205814877626 = 5603861388730 := by decide
def e1205814877654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1205814877654 : Closed e1205814877654 ∧ code e1205814877654 = 5603861388758 := by decide
theorem cert_e1205814877654 : checkPay e1205814877654 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1205814877658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1205814877658 : Closed e1205814877658 ∧ code e1205814877658 = 5603861388762 := by decide
theorem cert_e1205814877658 : check e1205814877658 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1205814878894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1205814878894 : Closed e1205814878894 ∧ code e1205814878894 = 5603861389998 := by decide
theorem cert_e1205814878894 : check e1205814878894 [[],[]] .chain = true := by decide
def e1205814878906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1205814878906 : Closed e1205814878906 ∧ code e1205814878906 = 5603861390010 := by decide
theorem cert_e1205814878906 : check e1205814878906 [[],[]] .chain = true := by decide
def e1205814878954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1205814878954 : Closed e1205814878954 ∧ code e1205814878954 = 5603861390058 := by decide
theorem cert_e1205814878954 : check e1205814878954 [[],[]] .chain = true := by decide
def e1205814880430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1205814880430 : Closed e1205814880430 ∧ code e1205814880430 = 5603861391534 := by decide
theorem cert_e1205814880430 : check e1205814880430 [[],[]] .chain = true := by decide
def e1205814880442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1205814880442 : Closed e1205814880442 ∧ code e1205814880442 = 5603861391546 := by decide
theorem cert_e1205814880442 : check e1205814880442 [[],[]] .chain = true := by decide
def e1205814880814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e1205814880814 : Closed e1205814880814 ∧ code e1205814880814 = 5603861391918 := by decide
theorem cert_e1205814880814 : check e1205814880814 [[],[]] .chain = true := by decide
def e1205814880994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1205814880994 : Closed e1205814880994 ∧ code e1205814880994 = 5603861392098 := by decide
theorem cert_e1205814880994 : check e1205814880994 [[],[]] .chain = true := by decide
def e1205814881006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1205814881006 : Closed e1205814881006 ∧ code e1205814881006 = 5603861392110 := by decide
theorem cert_e1205814881006 : check e1205814881006 [[],[]] .sourceHead = true := by decide
def e1205814881134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1205814881134 : Closed e1205814881134 ∧ code e1205814881134 = 5603861392238 := by decide
theorem cert_e1205814881134 : check e1205814881134 [[],[]] .chain = true := by decide
def e1205814881142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1205814881142 : Closed e1205814881142 ∧ code e1205814881142 = 5603861392246 := by decide
theorem cert_e1205814881142 : check e1205814881142 [[],[]] .chain = true := by decide
def e1205814881162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814881162 : Closed e1205814881162 ∧ code e1205814881162 = 5603861392266 := by decide
theorem cert_e1205814881162 : check e1205814881162 [[],[]] .chain = true := by decide
def e1205814881186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814881186 : Closed e1205814881186 ∧ code e1205814881186 = 5603861392290 := by decide
theorem cert_e1205814881186 : check e1205814881186 [[],[]] .chain = true := by decide
def e1205814881198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1205814881198 : Closed e1205814881198 ∧ code e1205814881198 = 5603861392302 := by decide
theorem cert_e1205814881198 : check e1205814881198 [[],[]] .sourceHead = true := by decide
def e1205814881206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1205814881206 : Closed e1205814881206 ∧ code e1205814881206 = 5603861392310 := by decide
theorem cert_e1205814881206 : check e1205814881206 [[],[]] .chain = true := by decide
def e1205814881210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1205814881210 : Closed e1205814881210 ∧ code e1205814881210 = 5603861392314 := by decide
theorem cert_e1205814881210 : check e1205814881210 [[],[]] .sourceHead = true := by decide
def e1205814881646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1205814881646 : Closed e1205814881646 ∧ code e1205814881646 = 5603861392750 := by decide
theorem cert_e1205814881646 : check e1205814881646 [[],[]] .chain = true := by decide
def e1205814881654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1205814881654 : Closed e1205814881654 ∧ code e1205814881654 = 5603861392758 := by decide
theorem cert_e1205814881654 : check e1205814881654 [[],[]] .chain = true := by decide
def e1205814881710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1205814881710 : Closed e1205814881710 ∧ code e1205814881710 = 5603861392814 := by decide
theorem cert_e1205814881710 : check e1205814881710 [[],[]] .chain = true := by decide
def e1205814881722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1205814881722 : Closed e1205814881722 ∧ code e1205814881722 = 5603861392826 := by decide
theorem cert_e1205814881722 : check e1205814881722 [[],[]] .chain = true := by decide
def e1205814881750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1205814881750 : Closed e1205814881750 ∧ code e1205814881750 = 5603861392854 := by decide
theorem cert_e1205814881750 : check e1205814881750 [[],[]] .chain = true := by decide
def e1205814881754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1205814881754 : Closed e1205814881754 ∧ code e1205814881754 = 5603861392858 := by decide
theorem cert_e1205814881754 : check e1205814881754 [[],[]] .chain = true := by decide
def e1205814881834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1205814881834 : Closed e1205814881834 ∧ code e1205814881834 = 5603861392938 := by decide
theorem cert_e1205814881834 : check e1205814881834 [[],[]] .chain = true := by decide
def e1205814881930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814881930 : Closed e1205814881930 ∧ code e1205814881930 = 5603861393034 := by decide
theorem cert_e1205814881930 : check e1205814881930 [[],[]] .chain = true := by decide
def e1205814881954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814881954 : Closed e1205814881954 ∧ code e1205814881954 = 5603861393058 := by decide
theorem cert_e1205814881954 : check e1205814881954 [[],[]] .chain = true := by decide
def e1205814881966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1205814881966 : Closed e1205814881966 ∧ code e1205814881966 = 5603861393070 := by decide
theorem cert_e1205814881966 : check e1205814881966 [[],[]] .sourceHead = true := by decide
def e1205814881974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1205814881974 : Closed e1205814881974 ∧ code e1205814881974 = 5603861393078 := by decide
theorem cert_e1205814881974 : check e1205814881974 [[],[]] .chain = true := by decide
def e1205814881978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1205814881978 : Closed e1205814881978 ∧ code e1205814881978 = 5603861393082 := by decide
theorem cert_e1205814881978 : check e1205814881978 [[],[]] .sourceHead = true := by decide
def e1205814882006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1205814882006 : Closed e1205814882006 ∧ code e1205814882006 = 5603861393110 := by decide
theorem cert_e1205814882006 : check e1205814882006 [[],[]] .chain = true := by decide
def e1205814882010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1205814882010 : Closed e1205814882010 ∧ code e1205814882010 = 5603861393114 := by decide
theorem cert_e1205814882010 : check e1205814882010 [[],[]] .chain = true := by decide
def e1205814882026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1205814882026 : Closed e1205814882026 ∧ code e1205814882026 = 5603861393130 := by decide
theorem cert_e1205814882026 : check e1205814882026 [[],[]] .sourceHead = true := by decide
def e1205814882646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1205814882646 : Closed e1205814882646 ∧ code e1205814882646 = 5603861393750 := by decide
theorem cert_e1205814882646 : check e1205814882646 [[],[]] .chain = true := by decide
def e1205814882650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1205814882650 : Closed e1205814882650 ∧ code e1205814882650 = 5603861393754 := by decide
theorem cert_e1205814882650 : check e1205814882650 [[],[]] .chain = true := by decide
def e1205814882666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1205814882666 : Closed e1205814882666 ∧ code e1205814882666 = 5603861393770 := by decide
theorem cert_e1205814882666 : check e1205814882666 [[],[]] .chain = true := by decide
def e1205814883414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1205814883414 : Closed e1205814883414 ∧ code e1205814883414 = 5603861394518 := by decide
theorem cert_e1205814883414 : check e1205814883414 [[],[]] .chain = true := by decide
def e1205814883418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1205814883418 : Closed e1205814883418 ∧ code e1205814883418 = 5603861394522 := by decide
theorem cert_e1205814883418 : check e1205814883418 [[],[]] .chain = true := by decide
def e1205814883606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e1205814883606 : Closed e1205814883606 ∧ code e1205814883606 = 5603861394710 := by decide
theorem cert_e1205814883606 : check e1205814883606 [[],[]] .chain = true := by decide
def e1205814883682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1205814883682 : Closed e1205814883682 ∧ code e1205814883682 = 5603861394786 := by decide
theorem cert_e1205814883682 : check e1205814883682 [[],[]] .chain = true := by decide
def e1205814883694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1205814883694 : Closed e1205814883694 ∧ code e1205814883694 = 5603861394798 := by decide
theorem cert_e1205814883694 : check e1205814883694 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1205814883702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1205814883702 : Closed e1205814883702 ∧ code e1205814883702 = 5603861394806 := by decide
theorem cert_e1205814883702 : check e1205814883702 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1205814883722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814883722 : Closed e1205814883722 ∧ code e1205814883722 = 5603861394826 := by decide
theorem cert_e1205814883722 : check e1205814883722 [[],[]] .chain = true := by decide
def e1205814883746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814883746 : Closed e1205814883746 ∧ code e1205814883746 = 5603861394850 := by decide
theorem cert_e1205814883746 : check e1205814883746 [[],[]] .chain = true := by decide
def e1205814883758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1205814883758 : Closed e1205814883758 ∧ code e1205814883758 = 5603861394862 := by decide
theorem cert_e1205814883758 : check e1205814883758 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1205814883766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e1205814883766 : Closed e1205814883766 ∧ code e1205814883766 = 5603861394870 := by decide
theorem cert_e1205814883766 : check e1205814883766 [[],[]] .chain = true := by decide
def e1205814883770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1205814883770 : Closed e1205814883770 ∧ code e1205814883770 = 5603861394874 := by decide
theorem cert_e1205814883770 : check e1205814883770 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1205814883798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1205814883798 : Closed e1205814883798 ∧ code e1205814883798 = 5603861394902 := by decide
def e1205814883802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1205814883802 : Closed e1205814883802 ∧ code e1205814883802 = 5603861394906 := by decide
def e1205814883882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1205814883882 : Closed e1205814883882 ∧ code e1205814883882 = 5603861394986 := by decide
theorem cert_e1205814883882 : check e1205814883882 [[],[]] .chain = true := by decide
def e1205814883978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1205814883978 : Closed e1205814883978 ∧ code e1205814883978 = 5603861395082 := by decide
theorem cert_e1205814883978 : check e1205814883978 [[],[]] .chain = true := by decide
def e1205814884002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1205814884002 : Closed e1205814884002 ∧ code e1205814884002 = 5603861395106 := by decide
theorem cert_e1205814884002 : check e1205814884002 [[],[]] .chain = true := by decide
def e1205814884014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1205814884014 : Closed e1205814884014 ∧ code e1205814884014 = 5603861395118 := by decide
theorem cert_e1205814884014 : check e1205814884014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .identityHead = true := by decide
def e1205814884022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1205814884022 : Closed e1205814884022 ∧ code e1205814884022 = 5603861395126 := by decide
theorem cert_e1205814884022 : check e1205814884022 [[],[]] .chain = true := by decide
def e1205814884026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1205814884026 : Closed e1205814884026 ∧ code e1205814884026 = 5603861395130 := by decide
theorem cert_e1205814884026 : check e1205814884026 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1205814884054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1205814884054 : Closed e1205814884054 ∧ code e1205814884054 = 5603861395158 := by decide
theorem cert_e1205814884054 : check e1205814884054 [[],[]] .chain = true := by decide
def e1205814884058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1205814884058 : Closed e1205814884058 ∧ code e1205814884058 = 5603861395162 := by decide
theorem cert_e1205814884058 : check e1205814884058 [[],[]] .chain = true := by decide
def e1205814884074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1205814884074 : Closed e1205814884074 ∧ code e1205814884074 = 5603861395178 := by decide
def e1205814884182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1205814884182 : Closed e1205814884182 ∧ code e1205814884182 = 5603861395286 := by decide
theorem cert_e1205814884182 : check e1205814884182 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1205814884186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1205814884186 : Closed e1205814884186 ∧ code e1205814884186 = 5603861395290 := by decide
theorem cert_e1205814884186 : check e1205814884186 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1205814884202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1205814884202 : Closed e1205814884202 ∧ code e1205814884202 = 5603861395306 := by decide
theorem cert_e1205814884202 : check e1205814884202 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1205814888302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e1205814888302 : Closed e1205814888302 ∧ code e1205814888302 = 5603861399406 := by decide
theorem cert_e1205814888302 : check e1205814888302 [[],[]] .chain = true := by decide
def e1205814888310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e1205814888310 : Closed e1205814888310 ∧ code e1205814888310 = 5603861399414 := by decide
theorem cert_e1205814888310 : check e1205814888310 [[],[]] .chain = true := by decide
def e1205814888366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e1205814888366 : Closed e1205814888366 ∧ code e1205814888366 = 5603861399470 := by decide
theorem cert_e1205814888366 : check e1205814888366 [[],[]] .chain = true := by decide
def e1205814888378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e1205814888378 : Closed e1205814888378 ∧ code e1205814888378 = 5603861399482 := by decide
theorem cert_e1205814888378 : check e1205814888378 [[],[]] .chain = true := by decide
def e1205814888406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e1205814888406 : Closed e1205814888406 ∧ code e1205814888406 = 5603861399510 := by decide
theorem cert_e1205814888406 : check e1205814888406 [[],[]] .chain = true := by decide
def e1205814888410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e1205814888410 : Closed e1205814888410 ∧ code e1205814888410 = 5603861399514 := by decide
theorem cert_e1205814888410 : check e1205814888410 [[],[]] .chain = true := by decide
def e1205814889838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1205814889838 : Closed e1205814889838 ∧ code e1205814889838 = 5603861400942 := by decide
theorem cert_e1205814889838 : check e1205814889838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814889846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1205814889846 : Closed e1205814889846 ∧ code e1205814889846 = 5603861400950 := by decide
theorem cert_e1205814889846 : check e1205814889846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1205814891374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1205814891374 : Closed e1205814891374 ∧ code e1205814891374 = 5603861402478 := by decide
theorem cert_e1205814891374 : check e1205814891374 [[],[]] .chain = true := by decide
def e1205814891382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1205814891382 : Closed e1205814891382 ∧ code e1205814891382 = 5603861402486 := by decide
theorem cert_e1205814891382 : check e1205814891382 [[],[]] .chain = true := by decide
def e1205814891438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1205814891438 : Closed e1205814891438 ∧ code e1205814891438 = 5603861402542 := by decide
theorem cert_e1205814891438 : check e1205814891438 [[],[]] .chain = true := by decide
def e1205814891450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1205814891450 : Closed e1205814891450 ∧ code e1205814891450 = 5603861402554 := by decide
theorem cert_e1205814891450 : check e1205814891450 [[],[]] .chain = true := by decide
def e1205814891478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1205814891478 : Closed e1205814891478 ∧ code e1205814891478 = 5603861402582 := by decide
theorem cert_e1205814891478 : check e1205814891478 [[],[]] .chain = true := by decide
def e1205814891482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1205814891482 : Closed e1205814891482 ∧ code e1205814891482 = 5603861402586 := by decide
theorem cert_e1205814891482 : check e1205814891482 [[],[]] .chain = true := by decide
def e1205814891758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1205814891758 : Closed e1205814891758 ∧ code e1205814891758 = 5603861402862 := by decide
theorem cert_e1205814891758 : check e1205814891758 [[],[]] .chain = true := by decide
def e1205814891766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1205814891766 : Closed e1205814891766 ∧ code e1205814891766 = 5603861402870 := by decide
theorem cert_e1205814891766 : check e1205814891766 [[],[]] .chain = true := by decide
def e1205814892142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1205814892142 : Closed e1205814892142 ∧ code e1205814892142 = 5603861403246 := by decide
theorem cert_e1205814892142 : check e1205814892142 [[],[]] .chain = true := by decide
def e1205814892154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1205814892154 : Closed e1205814892154 ∧ code e1205814892154 = 5603861403258 := by decide
theorem cert_e1205814892154 : check e1205814892154 [[],[]] .chain = true := by decide
end Blc.Floor42
