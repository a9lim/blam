import Tables
import Batch252
namespace Blc.Floor42.Grades252
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211301919174 : ¬ IsSelfInterpreter e1211301919174 := cutM9_0 (by decide)
#print axioms ex_e1211301919174
end Blc.Floor42.Grades252
