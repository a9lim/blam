import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211212597174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211212597174 : Closed e1211212597174 ∧ code e1211212597174 = 5609259108278 := by decide
theorem cert_e1211212597174 : check e1211212597174 [[],[]] .chain = true := by decide
def e1211212597178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e1211212597178 : Closed e1211212597178 ∧ code e1211212597178 = 5609259108282 := by decide
theorem cert_e1211212597178 : check e1211212597178 [[],[]] .chain = true := by decide
def e1211212597206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e1211212597206 : Closed e1211212597206 ∧ code e1211212597206 = 5609259108310 := by decide
theorem cert_e1211212597206 : check e1211212597206 [[],[],[.under,.under]] .three = true := by decide
def e1211212597646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211212597646 : Closed e1211212597646 ∧ code e1211212597646 = 5609259108750 := by decide
theorem cert_e1211212597646 : check e1211212597646 [[],[]] .chain = true := by decide
def e1211212597702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211212597702 : Closed e1211212597702 ∧ code e1211212597702 = 5609259108806 := by decide
theorem cert_e1211212597702 : check e1211212597702 [[],[]] .chain = true := by decide
def e1211212598302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211212598302 : Closed e1211212598302 ∧ code e1211212598302 = 5609259109406 := by decide
theorem cert_e1211212598302 : check e1211212598302 [[],[]] .chain = true := by decide
def e1211212598498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211212598498 : Closed e1211212598498 ∧ code e1211212598498 = 5609259109602 := by decide
theorem cert_e1211212598498 : check e1211212598498 [[],[]] .chain = true := by decide
def e1211212598510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211212598510 : Closed e1211212598510 ∧ code e1211212598510 = 5609259109614 := by decide
theorem cert_e1211212598510 : check e1211212598510 [[],[],[.under,.under]] .three = true := by decide
def e1211212598518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211212598518 : Closed e1211212598518 ∧ code e1211212598518 = 5609259109622 := by decide
theorem cert_e1211212598518 : check e1211212598518 [[],[],[.under,.under]] .three = true := by decide
def e1211212598798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211212598798 : Closed e1211212598798 ∧ code e1211212598798 = 5609259109902 := by decide
theorem cert_e1211212598798 : check e1211212598798 [[],[]] .chain = true := by decide
def e1211212598810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212598810 : Closed e1211212598810 ∧ code e1211212598810 = 5609259109914 := by decide
theorem cert_e1211212598810 : check e1211212598810 [[],[],[.under,.under]] .three = true := by decide
def e1211212598882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211212598882 : Closed e1211212598882 ∧ code e1211212598882 = 5609259109986 := by decide
theorem cert_e1211212598882 : check e1211212598882 [[],[]] .chain = true := by decide
def e1211212598894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211212598894 : Closed e1211212598894 ∧ code e1211212598894 = 5609259109998 := by decide
theorem cert_e1211212598894 : check e1211212598894 [[],[],[.under,.under]] .three = true := by decide
def e1211212598902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211212598902 : Closed e1211212598902 ∧ code e1211212598902 = 5609259110006 := by decide
theorem cert_e1211212598902 : check e1211212598902 [[],[]] .chain = true := by decide
def e1211212598906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211212598906 : Closed e1211212598906 ∧ code e1211212598906 = 5609259110010 := by decide
theorem cert_e1211212598906 : check e1211212598906 [[],[],[.under,.under]] .three = true := by decide
def e1211212599094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212599094 : Closed e1211212599094 ∧ code e1211212599094 = 5609259110198 := by decide
theorem cert_e1211212599094 : check e1211212599094 [[],[],[.under,.under]] .three = true := by decide
def e1211212599098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212599098 : Closed e1211212599098 ∧ code e1211212599098 = 5609259110202 := by decide
theorem cert_e1211212599098 : check e1211212599098 [[],[],[.under,.under]] .three = true := by decide
def e1211212601014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211212601014 : Closed e1211212601014 ∧ code e1211212601014 = 5609259112118 := by decide
theorem cert_e1211212601014 : check e1211212601014 [[],[]] .chain = true := by decide
def e1211212601046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211212601046 : Closed e1211212601046 ∧ code e1211212601046 = 5609259112150 := by decide
theorem cert_e1211212601046 : check e1211212601046 [[],[]] .chain = true := by decide
def e1211212601050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211212601050 : Closed e1211212601050 ∧ code e1211212601050 = 5609259112154 := by decide
theorem cert_e1211212601050 : check e1211212601050 [[],[]] .chain = true := by decide
def e1211212601174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211212601174 : Closed e1211212601174 ∧ code e1211212601174 = 5609259112278 := by decide
theorem cert_e1211212601174 : check e1211212601174 [[],[]] .chain = true := by decide
def e1211212601178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211212601178 : Closed e1211212601178 ∧ code e1211212601178 = 5609259112282 := by decide
theorem cert_e1211212601178 : check e1211212601178 [[],[]] .chain = true := by decide
def e1211212601194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211212601194 : Closed e1211212601194 ∧ code e1211212601194 = 5609259112298 := by decide
theorem cert_e1211212601194 : check e1211212601194 [[],[]] .chain = true := by decide
def e1211212601398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211212601398 : Closed e1211212601398 ∧ code e1211212601398 = 5609259112502 := by decide
theorem cert_e1211212601398 : check e1211212601398 [[],[]] .chain = true := by decide
def e1211212601486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211212601486 : Closed e1211212601486 ∧ code e1211212601486 = 5609259112590 := by decide
theorem cert_e1211212601486 : check e1211212601486 [[],[]] .chain = true := by decide
def e1211212601570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211212601570 : Closed e1211212601570 ∧ code e1211212601570 = 5609259112674 := by decide
theorem cert_e1211212601570 : check e1211212601570 [[],[]] .chain = true := by decide
def e1211212601582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211212601582 : Closed e1211212601582 ∧ code e1211212601582 = 5609259112686 := by decide
theorem cert_e1211212601582 : check e1211212601582 [[],[],[.under,.under]] .three = true := by decide
def e1211212601590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211212601590 : Closed e1211212601590 ∧ code e1211212601590 = 5609259112694 := by decide
theorem cert_e1211212601590 : check e1211212601590 [[],[],[.under,.under]] .three = true := by decide
def e1211212601782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211212601782 : Closed e1211212601782 ∧ code e1211212601782 = 5609259112886 := by decide
theorem cert_e1211212601782 : check e1211212601782 [[],[]] .chain = true := by decide
def e1211212601814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211212601814 : Closed e1211212601814 ∧ code e1211212601814 = 5609259112918 := by decide
theorem cert_e1211212601814 : check e1211212601814 [[],[]] .chain = true := by decide
def e1211212601818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211212601818 : Closed e1211212601818 ∧ code e1211212601818 = 5609259112922 := by decide
theorem cert_e1211212601818 : check e1211212601818 [[],[]] .chain = true := by decide
def e1211212601974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211212601974 : Closed e1211212601974 ∧ code e1211212601974 = 5609259113078 := by decide
theorem cert_e1211212601974 : check e1211212601974 [[],[]] .chain = true := by decide
def e1211212602118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211212602118 : Closed e1211212602118 ∧ code e1211212602118 = 5609259113222 := by decide
theorem cert_e1211212602118 : check e1211212602118 [[],[]] .chain = true := by decide
def e1211212602142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211212602142 : Closed e1211212602142 ∧ code e1211212602142 = 5609259113246 := by decide
theorem cert_e1211212602142 : check e1211212602142 [[],[],[.under,.under]] .three = true := by decide
def e1211212602166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212602166 : Closed e1211212602166 ∧ code e1211212602166 = 5609259113270 := by decide
theorem cert_e1211212602166 : check e1211212602166 [[],[]] .chain = true := by decide
def e1211212602170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212602170 : Closed e1211212602170 ∧ code e1211212602170 = 5609259113274 := by decide
theorem cert_e1211212602170 : check e1211212602170 [[],[]] .chain = true := by decide
def e1211212602254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211212602254 : Closed e1211212602254 ∧ code e1211212602254 = 5609259113358 := by decide
theorem cert_e1211212602254 : check e1211212602254 [[],[],[.under,.under]] .three = true := by decide
def e1211212602390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211212602390 : Closed e1211212602390 ∧ code e1211212602390 = 5609259113494 := by decide
theorem cert_e1211212602390 : check e1211212602390 [[],[]] .chain = true := by decide
def e1211212602394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211212602394 : Closed e1211212602394 ∧ code e1211212602394 = 5609259113498 := by decide
theorem cert_e1211212602394 : check e1211212602394 [[],[]] .chain = true := by decide
def e1211212602438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211212602438 : Closed e1211212602438 ∧ code e1211212602438 = 5609259113542 := by decide
theorem cert_e1211212602438 : check e1211212602438 [[],[]] .chain = true := by decide
def e1211212602466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211212602466 : Closed e1211212602466 ∧ code e1211212602466 = 5609259113570 := by decide
theorem cert_e1211212602466 : check e1211212602466 [[],[]] .chain = true := by decide
def e1211212602478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211212602478 : Closed e1211212602478 ∧ code e1211212602478 = 5609259113582 := by decide
theorem cert_e1211212602478 : check e1211212602478 [[],[],[.under,.under]] .three = true := by decide
def e1211212602486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211212602486 : Closed e1211212602486 ∧ code e1211212602486 = 5609259113590 := by decide
theorem cert_e1211212602486 : check e1211212602486 [[],[]] .chain = true := by decide
def e1211212602490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211212602490 : Closed e1211212602490 ∧ code e1211212602490 = 5609259113594 := by decide
theorem cert_e1211212602490 : check e1211212602490 [[],[],[.under,.under]] .three = true := by decide
def e1211212602582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211212602582 : Closed e1211212602582 ∧ code e1211212602582 = 5609259113686 := by decide
theorem cert_e1211212602582 : check e1211212602582 [[],[]] .chain = true := by decide
def e1211212602586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211212602586 : Closed e1211212602586 ∧ code e1211212602586 = 5609259113690 := by decide
theorem cert_e1211212602586 : check e1211212602586 [[],[]] .chain = true := by decide
def e1211212602602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211212602602 : Closed e1211212602602 ∧ code e1211212602602 = 5609259113706 := by decide
theorem cert_e1211212602602 : check e1211212602602 [[],[]] .chain = true := by decide
def e1211212602630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211212602630 : Closed e1211212602630 ∧ code e1211212602630 = 5609259113734 := by decide
theorem cert_e1211212602630 : check e1211212602630 [[],[]] .chain = true := by decide
def e1211212602654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211212602654 : Closed e1211212602654 ∧ code e1211212602654 = 5609259113758 := by decide
theorem cert_e1211212602654 : check e1211212602654 [[],[],[.under,.under]] .three = true := by decide
def e1211212602678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212602678 : Closed e1211212602678 ∧ code e1211212602678 = 5609259113782 := by decide
theorem cert_e1211212602678 : check e1211212602678 [[],[]] .chain = true := by decide
def e1211212602682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212602682 : Closed e1211212602682 ∧ code e1211212602682 = 5609259113786 := by decide
theorem cert_e1211212602682 : check e1211212602682 [[],[]] .chain = true := by decide
def e1211212602754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211212602754 : Closed e1211212602754 ∧ code e1211212602754 = 5609259113858 := by decide
theorem cert_e1211212602754 : check e1211212602754 [[],[]] .chain = true := by decide
def e1211212602766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211212602766 : Closed e1211212602766 ∧ code e1211212602766 = 5609259113870 := by decide
theorem cert_e1211212602766 : check e1211212602766 [[],[]] .chain = true := by decide
def e1211212602778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212602778 : Closed e1211212602778 ∧ code e1211212602778 = 5609259113882 := by decide
theorem cert_e1211212602778 : check e1211212602778 [[],[]] .chain = true := by decide
def e1211212602822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211212602822 : Closed e1211212602822 ∧ code e1211212602822 = 5609259113926 := by decide
theorem cert_e1211212602822 : check e1211212602822 [[],[],[.under,.under]] .three = true := by decide
def e1211212602934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211212602934 : Closed e1211212602934 ∧ code e1211212602934 = 5609259114038 := by decide
theorem cert_e1211212602934 : check e1211212602934 [[],[],[.under,.under]] .three = true := by decide
def e1211212602938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211212602938 : Closed e1211212602938 ∧ code e1211212602938 = 5609259114042 := by decide
theorem cert_e1211212602938 : check e1211212602938 [[],[],[.under,.under]] .three = true := by decide
def e1211212603022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211212603022 : Closed e1211212603022 ∧ code e1211212603022 = 5609259114126 := by decide
theorem cert_e1211212603022 : check e1211212603022 [[],[],[.under,.under]] .three = true := by decide
def e1211212603078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211212603078 : Closed e1211212603078 ∧ code e1211212603078 = 5609259114182 := by decide
theorem cert_e1211212603078 : check e1211212603078 [[],[],[.under,.under]] .three = true := by decide
def e1211212603454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211212603454 : Closed e1211212603454 ∧ code e1211212603454 = 5609259114558 := by decide
theorem cert_e1211212603454 : check e1211212603454 [[],[]] .chain = true := by decide
def e1211212603874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211212603874 : Closed e1211212603874 ∧ code e1211212603874 = 5609259114978 := by decide
theorem cert_e1211212603874 : check e1211212603874 [[],[]] .chain = true := by decide
def e1211212603886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211212603886 : Closed e1211212603886 ∧ code e1211212603886 = 5609259114990 := by decide
theorem cert_e1211212603886 : check e1211212603886 [[],[]] .chain = true := by decide
def e1211212604854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211212604854 : Closed e1211212604854 ∧ code e1211212604854 = 5609259115958 := by decide
theorem cert_e1211212604854 : check e1211212604854 [[],[]] .chain = true := by decide
def e1211212604886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211212604886 : Closed e1211212604886 ∧ code e1211212604886 = 5609259115990 := by decide
theorem cert_e1211212604886 : check e1211212604886 [[],[]] .chain = true := by decide
def e1211212604890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211212604890 : Closed e1211212604890 ∧ code e1211212604890 = 5609259115994 := by decide
theorem cert_e1211212604890 : check e1211212604890 [[],[]] .chain = true := by decide
def e1211212605046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211212605046 : Closed e1211212605046 ∧ code e1211212605046 = 5609259116150 := by decide
theorem cert_e1211212605046 : check e1211212605046 [[],[]] .chain = true := by decide
def e1211212605190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211212605190 : Closed e1211212605190 ∧ code e1211212605190 = 5609259116294 := by decide
theorem cert_e1211212605190 : check e1211212605190 [[],[]] .chain = true := by decide
def e1211212605214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211212605214 : Closed e1211212605214 ∧ code e1211212605214 = 5609259116318 := by decide
theorem cert_e1211212605214 : check e1211212605214 [[],[],[.under,.under]] .three = true := by decide
def e1211212605238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212605238 : Closed e1211212605238 ∧ code e1211212605238 = 5609259116342 := by decide
theorem cert_e1211212605238 : check e1211212605238 [[],[]] .chain = true := by decide
def e1211212605242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212605242 : Closed e1211212605242 ∧ code e1211212605242 = 5609259116346 := by decide
theorem cert_e1211212605242 : check e1211212605242 [[],[]] .chain = true := by decide
def e1211212605326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211212605326 : Closed e1211212605326 ∧ code e1211212605326 = 5609259116430 := by decide
theorem cert_e1211212605326 : check e1211212605326 [[],[],[.under,.under]] .three = true := by decide
def e1211212607518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211212607518 : Closed e1211212607518 ∧ code e1211212607518 = 5609259118622 := by decide
theorem cert_e1211212607518 : check e1211212607518 [[],[]] .chain = true := by decide
def e1211212607686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211212607686 : Closed e1211212607686 ∧ code e1211212607686 = 5609259118790 := by decide
theorem cert_e1211212607686 : check e1211212607686 [[],[],[.under,.under]] .three = true := by decide
def e1211212607710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211212607710 : Closed e1211212607710 ∧ code e1211212607710 = 5609259118814 := by decide
theorem cert_e1211212607710 : check e1211212607710 [[],[],[.under,.under]] .three = true := by decide
def e1211212607714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211212607714 : Closed e1211212607714 ∧ code e1211212607714 = 5609259118818 := by decide
theorem cert_e1211212607714 : check e1211212607714 [[],[]] .chain = true := by decide
def e1211212607726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211212607726 : Closed e1211212607726 ∧ code e1211212607726 = 5609259118830 := by decide
theorem cert_e1211212607726 : check e1211212607726 [[],[]] .chain = true := by decide
def e1211212607734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211212607734 : Closed e1211212607734 ∧ code e1211212607734 = 5609259118838 := by decide
theorem cert_e1211212607734 : check e1211212607734 [[],[]] .chain = true := by decide
def e1211212607738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211212607738 : Closed e1211212607738 ∧ code e1211212607738 = 5609259118842 := by decide
theorem cert_e1211212607738 : check e1211212607738 [[],[],[.under,.under]] .three = true := by decide
def e1211212608214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211212608214 : Closed e1211212608214 ∧ code e1211212608214 = 5609259119318 := by decide
theorem cert_e1211212608214 : check e1211212608214 [[],[]] .chain = true := by decide
def e1211212608218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211212608218 : Closed e1211212608218 ∧ code e1211212608218 = 5609259119322 := by decide
theorem cert_e1211212608218 : check e1211212608218 [[],[]] .chain = true := by decide
def e1211212608234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211212608234 : Closed e1211212608234 ∧ code e1211212608234 = 5609259119338 := by decide
theorem cert_e1211212608234 : check e1211212608234 [[],[]] .chain = true := by decide
def e1211212608262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211212608262 : Closed e1211212608262 ∧ code e1211212608262 = 5609259119366 := by decide
theorem cert_e1211212608262 : check e1211212608262 [[],[]] .chain = true := by decide
def e1211212608286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211212608286 : Closed e1211212608286 ∧ code e1211212608286 = 5609259119390 := by decide
theorem cert_e1211212608286 : check e1211212608286 [[],[],[.under,.under]] .three = true := by decide
def e1211212608310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212608310 : Closed e1211212608310 ∧ code e1211212608310 = 5609259119414 := by decide
theorem cert_e1211212608310 : check e1211212608310 [[],[]] .chain = true := by decide
def e1211212608314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212608314 : Closed e1211212608314 ∧ code e1211212608314 = 5609259119418 := by decide
theorem cert_e1211212608314 : check e1211212608314 [[],[]] .chain = true := by decide
def e1211212608386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211212608386 : Closed e1211212608386 ∧ code e1211212608386 = 5609259119490 := by decide
theorem cert_e1211212608386 : check e1211212608386 [[],[]] .chain = true := by decide
def e1211212608398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211212608398 : Closed e1211212608398 ∧ code e1211212608398 = 5609259119502 := by decide
theorem cert_e1211212608398 : check e1211212608398 [[],[]] .chain = true := by decide
def e1211212608410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212608410 : Closed e1211212608410 ∧ code e1211212608410 = 5609259119514 := by decide
theorem cert_e1211212608410 : check e1211212608410 [[],[]] .chain = true := by decide
def e1211212608454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211212608454 : Closed e1211212608454 ∧ code e1211212608454 = 5609259119558 := by decide
theorem cert_e1211212608454 : check e1211212608454 [[],[],[.under,.under]] .three = true := by decide
def e1211212609646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211212609646 : Closed e1211212609646 ∧ code e1211212609646 = 5609259120750 := by decide
theorem cert_e1211212609646 : check e1211212609646 [[],[],[.under,.under]] .three = true := by decide
def e1211212609658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211212609658 : Closed e1211212609658 ∧ code e1211212609658 = 5609259120762 := by decide
theorem cert_e1211212609658 : check e1211212609658 [[],[],[.under,.under]] .three = true := by decide
def e1211212609934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211212609934 : Closed e1211212609934 ∧ code e1211212609934 = 5609259121038 := by decide
theorem cert_e1211212609934 : check e1211212609934 [[],[],[.under,.under]] .three = true := by decide
def e1211212609990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211212609990 : Closed e1211212609990 ∧ code e1211212609990 = 5609259121094 := by decide
theorem cert_e1211212609990 : check e1211212609990 [[],[],[.under,.under]] .three = true := by decide
def e1211212611706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e1211212611706 : Closed e1211212611706 ∧ code e1211212611706 = 5609259122810 := by decide
theorem cert_e1211212611706 : check e1211212611706 [[],[]] .chain = true := by decide
def e1211212611894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212611894 : Closed e1211212611894 ∧ code e1211212611894 = 5609259122998 := by decide
theorem cert_e1211212611894 : check e1211212611894 [[],[]] .chain = true := by decide
def e1211212611898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212611898 : Closed e1211212611898 ∧ code e1211212611898 = 5609259123002 := by decide
theorem cert_e1211212611898 : check e1211212611898 [[],[]] .chain = true := by decide
def e1211212611994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212611994 : Closed e1211212611994 ∧ code e1211212611994 = 5609259123098 := by decide
theorem cert_e1211212611994 : check e1211212611994 [[],[]] .chain = true := by decide
def e1211212612038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e1211212612038 : Closed e1211212612038 ∧ code e1211212612038 = 5609259123142 := by decide
theorem cert_e1211212612038 : check e1211212612038 [[],[]] .chain = true := by decide
def e1211212612378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211212612378 : Closed e1211212612378 ∧ code e1211212612378 = 5609259123482 := by decide
theorem cert_e1211212612378 : check e1211212612378 [[],[],[.under,.under]] .three = true := by decide
def e1211212612422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211212612422 : Closed e1211212612422 ∧ code e1211212612422 = 5609259123526 := by decide
theorem cert_e1211212612422 : check e1211212612422 [[],[],[.under,.under]] .three = true := by decide
def e1211212612462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211212612462 : Closed e1211212612462 ∧ code e1211212612462 = 5609259123566 := by decide
theorem cert_e1211212612462 : check e1211212612462 [[],[],[.under,.under]] .three = true := by decide
def e1211212612474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e1211212612474 : Closed e1211212612474 ∧ code e1211212612474 = 5609259123578 := by decide
theorem cert_e1211212612474 : check e1211212612474 [[],[],[.under,.under]] .three = true := by decide
def e1211212612490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211212612490 : Closed e1211212612490 ∧ code e1211212612490 = 5609259123594 := by decide
theorem cert_e1211212612490 : check e1211212612490 [[],[]] .chain = true := by decide
def e1211212612526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211212612526 : Closed e1211212612526 ∧ code e1211212612526 = 5609259123630 := by decide
theorem cert_e1211212612526 : check e1211212612526 [[],[],[.under,.under]] .three = true := by decide
def e1211212612534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e1211212612534 : Closed e1211212612534 ∧ code e1211212612534 = 5609259123638 := by decide
theorem cert_e1211212612534 : check e1211212612534 [[],[]] .chain = true := by decide
def e1211212612538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211212612538 : Closed e1211212612538 ∧ code e1211212612538 = 5609259123642 := by decide
theorem cert_e1211212612538 : check e1211212612538 [[],[]] .chain = true := by decide
def e1211212612570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211212612570 : Closed e1211212612570 ∧ code e1211212612570 = 5609259123674 := by decide
theorem cert_e1211212612570 : check e1211212612570 [[],[]] .chain = true := by decide
def e1211212612586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e1211212612586 : Closed e1211212612586 ∧ code e1211212612586 = 5609259123690 := by decide
theorem cert_e1211212612586 : check e1211212612586 [[],[],[.under,.under]] .three = true := by decide
def e1211212612806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211212612806 : Closed e1211212612806 ∧ code e1211212612806 = 5609259123910 := by decide
theorem cert_e1211212612806 : check e1211212612806 [[],[]] .chain = true := by decide
def e1211212613134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211212613134 : Closed e1211212613134 ∧ code e1211212613134 = 5609259124238 := by decide
theorem cert_e1211212613134 : check e1211212613134 [[],[]] .chain = true := by decide
def e1211212613146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212613146 : Closed e1211212613146 ∧ code e1211212613146 = 5609259124250 := by decide
theorem cert_e1211212613146 : check e1211212613146 [[],[],[.under,.under]] .three = true := by decide
def e1211212613218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211212613218 : Closed e1211212613218 ∧ code e1211212613218 = 5609259124322 := by decide
theorem cert_e1211212613218 : check e1211212613218 [[],[]] .chain = true := by decide
def e1211212613230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211212613230 : Closed e1211212613230 ∧ code e1211212613230 = 5609259124334 := by decide
theorem cert_e1211212613230 : check e1211212613230 [[],[],[.under,.under]] .three = true := by decide
def e1211212613238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211212613238 : Closed e1211212613238 ∧ code e1211212613238 = 5609259124342 := by decide
theorem cert_e1211212613238 : check e1211212613238 [[],[]] .chain = true := by decide
def e1211212613242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211212613242 : Closed e1211212613242 ∧ code e1211212613242 = 5609259124346 := by decide
theorem cert_e1211212613242 : check e1211212613242 [[],[],[.under,.under]] .three = true := by decide
def e1211212613430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212613430 : Closed e1211212613430 ∧ code e1211212613430 = 5609259124534 := by decide
theorem cert_e1211212613430 : check e1211212613430 [[],[]] .chain = true := by decide
def e1211212613434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212613434 : Closed e1211212613434 ∧ code e1211212613434 = 5609259124538 := by decide
theorem cert_e1211212613434 : check e1211212613434 [[],[]] .chain = true := by decide
def e1211212613530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212613530 : Closed e1211212613530 ∧ code e1211212613530 = 5609259124634 := by decide
theorem cert_e1211212613530 : check e1211212613530 [[],[],[.under,.under]] .three = true := by decide
def e1211212614486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211212614486 : Closed e1211212614486 ∧ code e1211212614486 = 5609259125590 := by decide
theorem cert_e1211212614486 : check e1211212614486 [[],[]] .chain = true := by decide
def e1211212614490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211212614490 : Closed e1211212614490 ∧ code e1211212614490 = 5609259125594 := by decide
theorem cert_e1211212614490 : check e1211212614490 [[],[]] .chain = true := by decide
def e1211212614506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211212614506 : Closed e1211212614506 ∧ code e1211212614506 = 5609259125610 := by decide
theorem cert_e1211212614506 : check e1211212614506 [[],[]] .chain = true := by decide
def e1211212614570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e1211212614570 : Closed e1211212614570 ∧ code e1211212614570 = 5609259125674 := by decide
theorem cert_e1211212614570 : check e1211212614570 [[],[]] .chain = true := by decide
def e1211212614678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211212614678 : Closed e1211212614678 ∧ code e1211212614678 = 5609259125782 := by decide
theorem cert_e1211212614678 : check e1211212614678 [[],[]] .chain = true := by decide
def e1211212614682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211212614682 : Closed e1211212614682 ∧ code e1211212614682 = 5609259125786 := by decide
theorem cert_e1211212614682 : check e1211212614682 [[],[]] .chain = true := by decide
def e1211212614726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211212614726 : Closed e1211212614726 ∧ code e1211212614726 = 5609259125830 := by decide
theorem cert_e1211212614726 : check e1211212614726 [[],[]] .chain = true := by decide
def e1211212614754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211212614754 : Closed e1211212614754 ∧ code e1211212614754 = 5609259125858 := by decide
theorem cert_e1211212614754 : check e1211212614754 [[],[]] .chain = true := by decide
def e1211212614766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211212614766 : Closed e1211212614766 ∧ code e1211212614766 = 5609259125870 := by decide
theorem cert_e1211212614766 : check e1211212614766 [[],[],[.under,.under]] .three = true := by decide
def e1211212614774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1211212614774 : Closed e1211212614774 ∧ code e1211212614774 = 5609259125878 := by decide
theorem cert_e1211212614774 : check e1211212614774 [[],[]] .chain = true := by decide
def e1211212614778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211212614778 : Closed e1211212614778 ∧ code e1211212614778 = 5609259125882 := by decide
theorem cert_e1211212614778 : check e1211212614778 [[],[],[.under,.under]] .three = true := by decide
def e1211212614870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211212614870 : Closed e1211212614870 ∧ code e1211212614870 = 5609259125974 := by decide
theorem cert_e1211212614870 : check e1211212614870 [[],[]] .chain = true := by decide
def e1211212614874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211212614874 : Closed e1211212614874 ∧ code e1211212614874 = 5609259125978 := by decide
theorem cert_e1211212614874 : check e1211212614874 [[],[]] .chain = true := by decide
def e1211212614890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211212614890 : Closed e1211212614890 ∧ code e1211212614890 = 5609259125994 := by decide
theorem cert_e1211212614890 : check e1211212614890 [[],[]] .chain = true := by decide
def e1211212614918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211212614918 : Closed e1211212614918 ∧ code e1211212614918 = 5609259126022 := by decide
theorem cert_e1211212614918 : check e1211212614918 [[],[]] .chain = true := by decide
def e1211212614942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211212614942 : Closed e1211212614942 ∧ code e1211212614942 = 5609259126046 := by decide
theorem cert_e1211212614942 : check e1211212614942 [[],[],[.under,.under]] .three = true := by decide
def e1211212614966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211212614966 : Closed e1211212614966 ∧ code e1211212614966 = 5609259126070 := by decide
theorem cert_e1211212614966 : check e1211212614966 [[],[]] .chain = true := by decide
def e1211212614970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211212614970 : Closed e1211212614970 ∧ code e1211212614970 = 5609259126074 := by decide
theorem cert_e1211212614970 : check e1211212614970 [[],[]] .chain = true := by decide
def e1211212615042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211212615042 : Closed e1211212615042 ∧ code e1211212615042 = 5609259126146 := by decide
theorem cert_e1211212615042 : check e1211212615042 [[],[]] .chain = true := by decide
def e1211212615054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e1211212615054 : Closed e1211212615054 ∧ code e1211212615054 = 5609259126158 := by decide
theorem cert_e1211212615054 : check e1211212615054 [[],[]] .chain = true := by decide
def e1211212615066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212615066 : Closed e1211212615066 ∧ code e1211212615066 = 5609259126170 := by decide
theorem cert_e1211212615066 : check e1211212615066 [[],[]] .chain = true := by decide
def e1211212615110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211212615110 : Closed e1211212615110 ∧ code e1211212615110 = 5609259126214 := by decide
theorem cert_e1211212615110 : check e1211212615110 [[],[],[.under,.under]] .three = true := by decide
def e1211212615178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211212615178 : Closed e1211212615178 ∧ code e1211212615178 = 5609259126282 := by decide
theorem cert_e1211212615178 : check e1211212615178 [[],[]] .chain = true := by decide
def e1211212615222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211212615222 : Closed e1211212615222 ∧ code e1211212615222 = 5609259126326 := by decide
theorem cert_e1211212615222 : check e1211212615222 [[],[]] .chain = true := by decide
def e1211212615226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1211212615226 : Closed e1211212615226 ∧ code e1211212615226 = 5609259126330 := by decide
theorem cert_e1211212615226 : check e1211212615226 [[],[]] .chain = true := by decide
def e1211212615274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1211212615274 : Closed e1211212615274 ∧ code e1211212615274 = 5609259126378 := by decide
theorem cert_e1211212615274 : check e1211212615274 [[],[]] .chain = true := by decide
def e1211212615298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e1211212615298 : Closed e1211212615298 ∧ code e1211212615298 = 5609259126402 := by decide
theorem cert_e1211212615298 : check e1211212615298 [[],[]] .chain = true := by decide
def e1211212615310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211212615310 : Closed e1211212615310 ∧ code e1211212615310 = 5609259126414 := by decide
theorem cert_e1211212615310 : check e1211212615310 [[],[]] .chain = true := by decide
def e1211212615322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211212615322 : Closed e1211212615322 ∧ code e1211212615322 = 5609259126426 := by decide
theorem cert_e1211212615322 : check e1211212615322 [[],[]] .chain = true := by decide
def e1211212615366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e1211212615366 : Closed e1211212615366 ∧ code e1211212615366 = 5609259126470 := by decide
theorem cert_e1211212615366 : check e1211212615366 [[],[]] .chain = true := by decide
def e1211212615450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211212615450 : Closed e1211212615450 ∧ code e1211212615450 = 5609259126554 := by decide
theorem cert_e1211212615450 : check e1211212615450 [[],[],[.under,.under]] .three = true := by decide
def e1211212615494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211212615494 : Closed e1211212615494 ∧ code e1211212615494 = 5609259126598 := by decide
theorem cert_e1211212615494 : check e1211212615494 [[],[],[.under,.under]] .three = true := by decide
def e1211212615710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211212615710 : Closed e1211212615710 ∧ code e1211212615710 = 5609259126814 := by decide
theorem cert_e1211212615710 : check e1211212615710 [[],[]] .chain = true := by decide
def e1211212615878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211212615878 : Closed e1211212615878 ∧ code e1211212615878 = 5609259126982 := by decide
theorem cert_e1211212615878 : check e1211212615878 [[],[],[.under,.under]] .three = true := by decide
def e1211212615902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211212615902 : Closed e1211212615902 ∧ code e1211212615902 = 5609259127006 := by decide
theorem cert_e1211212615902 : check e1211212615902 [[],[],[.under,.under]] .three = true := by decide
def e1211212615906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211212615906 : Closed e1211212615906 ∧ code e1211212615906 = 5609259127010 := by decide
theorem cert_e1211212615906 : check e1211212615906 [[],[]] .chain = true := by decide
def e1211212615918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211212615918 : Closed e1211212615918 ∧ code e1211212615918 = 5609259127022 := by decide
theorem cert_e1211212615918 : check e1211212615918 [[],[]] .chain = true := by decide
def e1211212615926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211212615926 : Closed e1211212615926 ∧ code e1211212615926 = 5609259127030 := by decide
theorem cert_e1211212615926 : check e1211212615926 [[],[]] .chain = true := by decide
def e1211212615930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211212615930 : Closed e1211212615930 ∧ code e1211212615930 = 5609259127034 := by decide
theorem cert_e1211212615930 : check e1211212615930 [[],[],[.under,.under]] .three = true := by decide
def e1211212616406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211212616406 : Closed e1211212616406 ∧ code e1211212616406 = 5609259127510 := by decide
theorem cert_e1211212616406 : check e1211212616406 [[],[]] .chain = true := by decide
def e1211212616410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211212616410 : Closed e1211212616410 ∧ code e1211212616410 = 5609259127514 := by decide
theorem cert_e1211212616410 : check e1211212616410 [[],[]] .chain = true := by decide
def e1211212616426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211212616426 : Closed e1211212616426 ∧ code e1211212616426 = 5609259127530 := by decide
theorem cert_e1211212616426 : check e1211212616426 [[],[]] .chain = true := by decide
end Blc.Floor42
