import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205815835150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815835150 : Closed e1205815835150 ∧ code e1205815835150 = 5603862346254 := by decide
theorem cert_e1205815835150 : check e1205815835150 [[],[]] .chain = true := by decide
def e1205815835162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815835162 : Closed e1205815835162 ∧ code e1205815835162 = 5603862346266 := by decide
theorem cert_e1205815835162 : check e1205815835162 [[],[]] .sourceHead = true := by decide
def e1205815835234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815835234 : Closed e1205815835234 ∧ code e1205815835234 = 5603862346338 := by decide
theorem cert_e1205815835234 : check e1205815835234 [[],[]] .chain = true := by decide
def e1205815835246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815835246 : Closed e1205815835246 ∧ code e1205815835246 = 5603862346350 := by decide
theorem cert_e1205815835246 : check e1205815835246 [[],[]] .sourceHead = true := by decide
def e1205815835254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815835254 : Closed e1205815835254 ∧ code e1205815835254 = 5603862346358 := by decide
theorem cert_e1205815835254 : check e1205815835254 [[],[]] .chain = true := by decide
def e1205815835258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815835258 : Closed e1205815835258 ∧ code e1205815835258 = 5603862346362 := by decide
theorem cert_e1205815835258 : check e1205815835258 [[],[]] .sourceHead = true := by decide
def e1205815835446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815835446 : Closed e1205815835446 ∧ code e1205815835446 = 5603862346550 := by decide
theorem cert_e1205815835446 : check e1205815835446 [[],[]] .chain = true := by decide
def e1205815835450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815835450 : Closed e1205815835450 ∧ code e1205815835450 = 5603862346554 := by decide
theorem cert_e1205815835450 : check e1205815835450 [[],[]] .chain = true := by decide
def e1205815835546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815835546 : Closed e1205815835546 ∧ code e1205815835546 = 5603862346650 := by decide
theorem cert_e1205815835546 : check e1205815835546 [[],[]] .sourceHead = true := by decide
def e1205815838686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e1205815838686 : Closed e1205815838686 ∧ code e1205815838686 = 5603862349790 := by decide
theorem cert_e1205815838686 : check e1205815838686 [[],[]] .sourceHead = true := by decide
def e1205815842350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1205815842350 : Closed e1205815842350 ∧ code e1205815842350 = 5603862353454 := by decide
theorem cert_e1205815842350 : check e1205815842350 [[],[]] .chain = true := by decide
def e1205815842530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1205815842530 : Closed e1205815842530 ∧ code e1205815842530 = 5603862353634 := by decide
theorem cert_e1205815842530 : check e1205815842530 [[],[]] .chain = true := by decide
def e1205815842542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1205815842542 : Closed e1205815842542 ∧ code e1205815842542 = 5603862353646 := by decide
theorem cert_e1205815842542 : check e1205815842542 [[],[]] .sourceHead = true := by decide
def e1205815842670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1205815842670 : Closed e1205815842670 ∧ code e1205815842670 = 5603862353774 := by decide
theorem cert_e1205815842670 : check e1205815842670 [[],[]] .chain = true := by decide
def e1205815842678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1205815842678 : Closed e1205815842678 ∧ code e1205815842678 = 5603862353782 := by decide
theorem cert_e1205815842678 : check e1205815842678 [[],[]] .chain = true := by decide
def e1205815842698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205815842698 : Closed e1205815842698 ∧ code e1205815842698 = 5603862353802 := by decide
theorem cert_e1205815842698 : check e1205815842698 [[],[]] .chain = true := by decide
def e1205815842722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205815842722 : Closed e1205815842722 ∧ code e1205815842722 = 5603862353826 := by decide
theorem cert_e1205815842722 : check e1205815842722 [[],[]] .chain = true := by decide
def e1205815842734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1205815842734 : Closed e1205815842734 ∧ code e1205815842734 = 5603862353838 := by decide
theorem cert_e1205815842734 : check e1205815842734 [[],[]] .sourceHead = true := by decide
def e1205815842742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1205815842742 : Closed e1205815842742 ∧ code e1205815842742 = 5603862353846 := by decide
theorem cert_e1205815842742 : check e1205815842742 [[],[]] .chain = true := by decide
def e1205815842746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1205815842746 : Closed e1205815842746 ∧ code e1205815842746 = 5603862353850 := by decide
theorem cert_e1205815842746 : check e1205815842746 [[],[]] .sourceHead = true := by decide
def e1205815842878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e1205815842878 : Closed e1205815842878 ∧ code e1205815842878 = 5603862353982 := by decide
theorem cert_e1205815842878 : check e1205815842878 [[],[]] .chain = true := by decide
def e1205815843298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1205815843298 : Closed e1205815843298 ∧ code e1205815843298 = 5603862354402 := by decide
theorem cert_e1205815843298 : check e1205815843298 [[],[]] .chain = true := by decide
def e1205815843310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205815843310 : Closed e1205815843310 ∧ code e1205815843310 = 5603862354414 := by decide
theorem cert_e1205815843310 : check e1205815843310 [[],[]] .sourceHead = true := by decide
def e1205815844078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815844078 : Closed e1205815844078 ∧ code e1205815844078 = 5603862355182 := by decide
theorem cert_e1205815844078 : check e1205815844078 [[],[]] .chain = true := by decide
def e1205815844086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815844086 : Closed e1205815844086 ∧ code e1205815844086 = 5603862355190 := by decide
theorem cert_e1205815844086 : check e1205815844086 [[],[]] .chain = true := by decide
def e1205815844366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e1205815844366 : Closed e1205815844366 ∧ code e1205815844366 = 5603862355470 := by decide
theorem cert_e1205815844366 : check e1205815844366 [[],[]] .chain = true := by decide
def e1205815844378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1205815844378 : Closed e1205815844378 ∧ code e1205815844378 = 5603862355482 := by decide
theorem cert_e1205815844378 : check e1205815844378 [[],[]] .sourceHead = true := by decide
def e1205815844450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205815844450 : Closed e1205815844450 ∧ code e1205815844450 = 5603862355554 := by decide
theorem cert_e1205815844450 : check e1205815844450 [[],[]] .chain = true := by decide
def e1205815844462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815844462 : Closed e1205815844462 ∧ code e1205815844462 = 5603862355566 := by decide
theorem cert_e1205815844462 : check e1205815844462 [[],[]] .sourceHead = true := by decide
def e1205815844470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205815844470 : Closed e1205815844470 ∧ code e1205815844470 = 5603862355574 := by decide
theorem cert_e1205815844470 : check e1205815844470 [[],[]] .chain = true := by decide
def e1205815844474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815844474 : Closed e1205815844474 ∧ code e1205815844474 = 5603862355578 := by decide
theorem cert_e1205815844474 : check e1205815844474 [[],[]] .sourceHead = true := by decide
def e1205815855982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205815855982 : Closed e1205815855982 ∧ code e1205815855982 = 5603862367086 := by decide
theorem cert_e1205815855982 : check e1205815855982 [[],[]] .chain = true := by decide
def e1205815855990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205815855990 : Closed e1205815855990 ∧ code e1205815855990 = 5603862367094 := by decide
theorem cert_e1205815855990 : check e1205815855990 [[],[]] .chain = true := by decide
def e1205815856046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205815856046 : Closed e1205815856046 ∧ code e1205815856046 = 5603862367150 := by decide
theorem cert_e1205815856046 : check e1205815856046 [[],[]] .chain = true := by decide
def e1205815856058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205815856058 : Closed e1205815856058 ∧ code e1205815856058 = 5603862367162 := by decide
theorem cert_e1205815856058 : check e1205815856058 [[],[]] .chain = true := by decide
def e1205815856086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205815856086 : Closed e1205815856086 ∧ code e1205815856086 = 5603862367190 := by decide
theorem cert_e1205815856086 : check e1205815856086 [[],[]] .chain = true := by decide
def e1205815856090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205815856090 : Closed e1205815856090 ∧ code e1205815856090 = 5603862367194 := by decide
theorem cert_e1205815856090 : check e1205815856090 [[],[]] .chain = true := by decide
def e1205815856366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815856366 : Closed e1205815856366 ∧ code e1205815856366 = 5603862367470 := by decide
theorem cert_e1205815856366 : check e1205815856366 [[],[]] .chain = true := by decide
def e1205815856374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815856374 : Closed e1205815856374 ∧ code e1205815856374 = 5603862367478 := by decide
theorem cert_e1205815856374 : check e1205815856374 [[],[]] .chain = true := by decide
def e1205815856750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815856750 : Closed e1205815856750 ∧ code e1205815856750 = 5603862367854 := by decide
theorem cert_e1205815856750 : check e1205815856750 [[],[]] .chain = true := by decide
def e1205815856762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815856762 : Closed e1205815856762 ∧ code e1205815856762 = 5603862367866 := by decide
theorem cert_e1205815856762 : check e1205815856762 [[],[]] .chain = true := by decide
def e1205815856950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205815856950 : Closed e1205815856950 ∧ code e1205815856950 = 5603862368054 := by decide
theorem cert_e1205815856950 : check e1205815856950 [[],[]] .chain = true := by decide
def e1205815856954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205815856954 : Closed e1205815856954 ∧ code e1205815856954 = 5603862368058 := by decide
theorem cert_e1205815856954 : check e1205815856954 [[],[]] .chain = true := by decide
def e1205815861726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1205815861726 : Closed e1205815861726 ∧ code e1205815861726 = 5603862372830 := by decide
theorem cert_e1205815861726 : check e1205815861726 [[],[]] .sourceHead = true := by decide
def e1205815861750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1205815861750 : Closed e1205815861750 ∧ code e1205815861750 = 5603862372854 := by decide
theorem cert_e1205815861750 : check e1205815861750 [[],[]] .sourceHead = true := by decide
def e1205815862666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1205815862666 : Closed e1205815862666 ∧ code e1205815862666 = 5603862373770 := by decide
theorem cert_e1205815862666 : check e1205815862666 [[],[]] .chain = true := by decide
def e1205815862690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1205815862690 : Closed e1205815862690 ∧ code e1205815862690 = 5603862373794 := by decide
theorem cert_e1205815862690 : check e1205815862690 [[],[]] .chain = true := by decide
def e1205815862702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1205815862702 : Closed e1205815862702 ∧ code e1205815862702 = 5603862373806 := by decide
theorem cert_e1205815862702 : check e1205815862702 [[],[]] .sourceHead = true := by decide
def e1205815862710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1205815862710 : Closed e1205815862710 ∧ code e1205815862710 = 5603862373814 := by decide
theorem cert_e1205815862710 : check e1205815862710 [[],[]] .chain = true := by decide
def e1205815862714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1205815862714 : Closed e1205815862714 ∧ code e1205815862714 = 5603862373818 := by decide
theorem cert_e1205815862714 : check e1205815862714 [[],[]] .sourceHead = true := by decide
def e1205815862742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1205815862742 : Closed e1205815862742 ∧ code e1205815862742 = 5603862373846 := by decide
theorem cert_e1205815862742 : check e1205815862742 [[],[]] .chain = true := by decide
def e1205815862746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1205815862746 : Closed e1205815862746 ∧ code e1205815862746 = 5603862373850 := by decide
theorem cert_e1205815862746 : check e1205815862746 [[],[]] .chain = true := by decide
def e1205815862762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1205815862762 : Closed e1205815862762 ∧ code e1205815862762 = 5603862373866 := by decide
theorem cert_e1205815862762 : check e1205815862762 [[],[]] .sourceHead = true := by decide
def e1205815862798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e1205815862798 : Closed e1205815862798 ∧ code e1205815862798 = 5603862373902 := by decide
theorem cert_e1205815862798 : check e1205815862798 [[],[]] .chain = true := by decide
def e1205815862810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1205815862810 : Closed e1205815862810 ∧ code e1205815862810 = 5603862373914 := by decide
theorem cert_e1205815862810 : check e1205815862810 [[],[]] .sourceHead = true := by decide
def e1205815862882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1205815862882 : Closed e1205815862882 ∧ code e1205815862882 = 5603862373986 := by decide
theorem cert_e1205815862882 : check e1205815862882 [[],[]] .chain = true := by decide
def e1205815862894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815862894 : Closed e1205815862894 ∧ code e1205815862894 = 5603862373998 := by decide
theorem cert_e1205815862894 : check e1205815862894 [[],[]] .sourceHead = true := by decide
def e1205815862902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205815862902 : Closed e1205815862902 ∧ code e1205815862902 = 5603862374006 := by decide
theorem cert_e1205815862902 : check e1205815862902 [[],[]] .chain = true := by decide
def e1205815862906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815862906 : Closed e1205815862906 ∧ code e1205815862906 = 5603862374010 := by decide
theorem cert_e1205815862906 : check e1205815862906 [[],[]] .sourceHead = true := by decide
def e1205815863094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205815863094 : Closed e1205815863094 ∧ code e1205815863094 = 5603862374198 := by decide
theorem cert_e1205815863094 : check e1205815863094 [[],[]] .chain = true := by decide
def e1205815863098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205815863098 : Closed e1205815863098 ∧ code e1205815863098 = 5603862374202 := by decide
theorem cert_e1205815863098 : check e1205815863098 [[],[]] .chain = true := by decide
def e1205815863194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815863194 : Closed e1205815863194 ∧ code e1205815863194 = 5603862374298 := by decide
theorem cert_e1205815863194 : check e1205815863194 [[],[]] .sourceHead = true := by decide
def e1205816012254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1205816012254 : Closed e1205816012254 ∧ code e1205816012254 = 5603862523358 := by decide
theorem cert_e1205816012254 : check e1205816012254 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816012270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1205816012270 : Closed e1205816012270 ∧ code e1205816012270 = 5603862523374 := by decide
theorem cert_e1205816012270 : check e1205816012270 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816012526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e1205816012526 : Closed e1205816012526 ∧ code e1205816012526 = 5603862523630 := by decide
theorem cert_e1205816012526 : check e1205816012526 [[],[]] .chain = true := by decide
def e1205816012638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1205816012638 : Closed e1205816012638 ∧ code e1205816012638 = 5603862523742 := by decide
theorem cert_e1205816012638 : check e1205816012638 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816012654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e1205816012654 : Closed e1205816012654 ∧ code e1205816012654 = 5603862523758 := by decide
theorem cert_e1205816012654 : check e1205816012654 [[],[]] .chain = true := by decide
def e1205816012662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e1205816012662 : Closed e1205816012662 ∧ code e1205816012662 = 5603862523766 := by decide
theorem cert_e1205816012662 : check e1205816012662 [[],[]] .chain = true := by decide
def e1205816012666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1205816012666 : Closed e1205816012666 ∧ code e1205816012666 = 5603862523770 := by decide
theorem cert_e1205816012666 : check e1205816012666 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816012718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1205816012718 : Closed e1205816012718 ∧ code e1205816012718 = 5603862523822 := by decide
theorem cert_e1205816012718 : check e1205816012718 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816012730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1205816012730 : Closed e1205816012730 ∧ code e1205816012730 = 5603862523834 := by decide
theorem cert_e1205816012730 : check e1205816012730 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816013790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205816013790 : Closed e1205816013790 ∧ code e1205816013790 = 5603862524894 := by decide
theorem cert_e1205816013790 : check e1205816013790 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816013806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205816013806 : Closed e1205816013806 ∧ code e1205816013806 = 5603862524910 := by decide
theorem cert_e1205816013806 : check e1205816013806 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816015342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205816015342 : Closed e1205816015342 ∧ code e1205816015342 = 5603862526446 := by decide
theorem cert_e1205816015342 : check e1205816015342 [[],[]] .chain = true := by decide
def e1205816016094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205816016094 : Closed e1205816016094 ∧ code e1205816016094 = 5603862527198 := by decide
theorem cert_e1205816016094 : check e1205816016094 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816016110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205816016110 : Closed e1205816016110 ∧ code e1205816016110 = 5603862527214 := by decide
theorem cert_e1205816016110 : check e1205816016110 [[],[]] .chain = true := by decide
def e1205816016118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205816016118 : Closed e1205816016118 ∧ code e1205816016118 = 5603862527222 := by decide
theorem cert_e1205816016118 : check e1205816016118 [[],[]] .chain = true := by decide
def e1205816016122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205816016122 : Closed e1205816016122 ∧ code e1205816016122 = 5603862527226 := by decide
theorem cert_e1205816016122 : check e1205816016122 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816016494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205816016494 : Closed e1205816016494 ∧ code e1205816016494 = 5603862527598 := by decide
theorem cert_e1205816016494 : check e1205816016494 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816016506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205816016506 : Closed e1205816016506 ∧ code e1205816016506 = 5603862527610 := by decide
theorem cert_e1205816016506 : check e1205816016506 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816044630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1205816044630 : Closed e1205816044630 ∧ code e1205816044630 = 5603862555734 := by decide
theorem cert_e1205816044630 : check e1205816044630 [[],[]] .chain = true := by decide
def e1205816044634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1205816044634 : Closed e1205816044634 ∧ code e1205816044634 = 5603862555738 := by decide
theorem cert_e1205816044634 : check e1205816044634 [[],[]] .chain = true := by decide
def e1205816044822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205816044822 : Closed e1205816044822 ∧ code e1205816044822 = 5603862555926 := by decide
theorem cert_e1205816044822 : check e1205816044822 [[],[]] .chain = true := by decide
def e1205816044898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205816044898 : Closed e1205816044898 ∧ code e1205816044898 = 5603862556002 := by decide
theorem cert_e1205816044898 : check e1205816044898 [[],[]] .chain = true := by decide
def e1205816044910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1205816044910 : Closed e1205816044910 ∧ code e1205816044910 = 5603862556014 := by decide
theorem cert_e1205816044910 : check e1205816044910 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816044918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1205816044918 : Closed e1205816044918 ∧ code e1205816044918 = 5603862556022 := by decide
theorem cert_e1205816044918 : check e1205816044918 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816044938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205816044938 : Closed e1205816044938 ∧ code e1205816044938 = 5603862556042 := by decide
theorem cert_e1205816044938 : check e1205816044938 [[],[]] .chain = true := by decide
def e1205816044962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205816044962 : Closed e1205816044962 ∧ code e1205816044962 = 5603862556066 := by decide
theorem cert_e1205816044962 : check e1205816044962 [[],[]] .chain = true := by decide
def e1205816044974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1205816044974 : Closed e1205816044974 ∧ code e1205816044974 = 5603862556078 := by decide
theorem cert_e1205816044974 : check e1205816044974 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816044982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e1205816044982 : Closed e1205816044982 ∧ code e1205816044982 = 5603862556086 := by decide
theorem cert_e1205816044982 : check e1205816044982 [[],[]] .chain = true := by decide
def e1205816044986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1205816044986 : Closed e1205816044986 ∧ code e1205816044986 = 5603862556090 := by decide
theorem cert_e1205816044986 : check e1205816044986 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1205816045014 : Closed e1205816045014 ∧ code e1205816045014 = 5603862556118 := by decide
theorem cert_e1205816045014 : check e1205816045014 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1205816045018 : Closed e1205816045018 ∧ code e1205816045018 = 5603862556122 := by decide
theorem cert_e1205816045018 : check e1205816045018 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1205816045098 : Closed e1205816045098 ∧ code e1205816045098 = 5603862556202 := by decide
theorem cert_e1205816045098 : check e1205816045098 [[],[]] .chain = true := by decide
def e1205816045194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205816045194 : Closed e1205816045194 ∧ code e1205816045194 = 5603862556298 := by decide
theorem cert_e1205816045194 : check e1205816045194 [[],[]] .chain = true := by decide
def e1205816045218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205816045218 : Closed e1205816045218 ∧ code e1205816045218 = 5603862556322 := by decide
theorem cert_e1205816045218 : check e1205816045218 [[],[]] .chain = true := by decide
def e1205816045230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1205816045230 : Closed e1205816045230 ∧ code e1205816045230 = 5603862556334 := by decide
theorem cert_e1205816045230 : check e1205816045230 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1205816045238 : Closed e1205816045238 ∧ code e1205816045238 = 5603862556342 := by decide
theorem cert_e1205816045238 : check e1205816045238 [[],[]] .chain = true := by decide
def e1205816045242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1205816045242 : Closed e1205816045242 ∧ code e1205816045242 = 5603862556346 := by decide
theorem cert_e1205816045242 : check e1205816045242 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1205816045270 : Closed e1205816045270 ∧ code e1205816045270 = 5603862556374 := by decide
theorem cert_e1205816045270 : check e1205816045270 [[],[]] .chain = true := by decide
def e1205816045274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1205816045274 : Closed e1205816045274 ∧ code e1205816045274 = 5603862556378 := by decide
theorem cert_e1205816045274 : check e1205816045274 [[],[]] .chain = true := by decide
def e1205816045290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1205816045290 : Closed e1205816045290 ∧ code e1205816045290 = 5603862556394 := by decide
theorem cert_e1205816045290 : check e1205816045290 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1205816045398 : Closed e1205816045398 ∧ code e1205816045398 = 5603862556502 := by decide
theorem cert_e1205816045398 : check e1205816045398 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1205816045402 : Closed e1205816045402 ∧ code e1205816045402 = 5603862556506 := by decide
theorem cert_e1205816045402 : check e1205816045402 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1205816045418 : Closed e1205816045418 ∧ code e1205816045418 = 5603862556522 := by decide
theorem cert_e1205816045418 : check e1205816045418 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e1205816045686 : Closed e1205816045686 ∧ code e1205816045686 = 5603862556790 := by decide
theorem cert_e1205816045686 : check e1205816045686 [[],[]] .chain = true := by decide
def e1205816045690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1205816045690 : Closed e1205816045690 ∧ code e1205816045690 = 5603862556794 := by decide
theorem cert_e1205816045690 : check e1205816045690 [[],[]] .chain = true := by decide
def e1205816045782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1205816045782 : Closed e1205816045782 ∧ code e1205816045782 = 5603862556886 := by decide
theorem cert_e1205816045782 : check e1205816045782 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816045878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1205816045878 : Closed e1205816045878 ∧ code e1205816045878 = 5603862556982 := by decide
theorem cert_e1205816045878 : check e1205816045878 [[],[]] .chain = true := by decide
def e1205816045882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1205816045882 : Closed e1205816045882 ∧ code e1205816045882 = 5603862556986 := by decide
theorem cert_e1205816045882 : check e1205816045882 [[],[]] .chain = true := by decide
def e1205816045966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e1205816045966 : Closed e1205816045966 ∧ code e1205816045966 = 5603862557070 := by decide
theorem cert_e1205816045966 : check e1205816045966 [[],[]] .chain = true := by decide
def e1205816046022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e1205816046022 : Closed e1205816046022 ∧ code e1205816046022 = 5603862557126 := by decide
theorem cert_e1205816046022 : check e1205816046022 [[],[]] .chain = true := by decide
def e1205816046358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1205816046358 : Closed e1205816046358 ∧ code e1205816046358 = 5603862557462 := by decide
theorem cert_e1205816046358 : check e1205816046358 [[],[]] .chain = true := by decide
def e1205816046434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1205816046434 : Closed e1205816046434 ∧ code e1205816046434 = 5603862557538 := by decide
theorem cert_e1205816046434 : check e1205816046434 [[],[]] .chain = true := by decide
def e1205816046446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1205816046446 : Closed e1205816046446 ∧ code e1205816046446 = 5603862557550 := by decide
theorem cert_e1205816046446 : check e1205816046446 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1205816046454 : Closed e1205816046454 ∧ code e1205816046454 = 5603862557558 := by decide
theorem cert_e1205816046454 : check e1205816046454 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205816046474 : Closed e1205816046474 ∧ code e1205816046474 = 5603862557578 := by decide
theorem cert_e1205816046474 : check e1205816046474 [[],[]] .chain = true := by decide
def e1205816046498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205816046498 : Closed e1205816046498 ∧ code e1205816046498 = 5603862557602 := by decide
theorem cert_e1205816046498 : check e1205816046498 [[],[]] .chain = true := by decide
def e1205816046510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1205816046510 : Closed e1205816046510 ∧ code e1205816046510 = 5603862557614 := by decide
theorem cert_e1205816046510 : check e1205816046510 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e1205816046518 : Closed e1205816046518 ∧ code e1205816046518 = 5603862557622 := by decide
theorem cert_e1205816046518 : check e1205816046518 [[],[]] .chain = true := by decide
def e1205816046522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1205816046522 : Closed e1205816046522 ∧ code e1205816046522 = 5603862557626 := by decide
theorem cert_e1205816046522 : check e1205816046522 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1205816046550 : Closed e1205816046550 ∧ code e1205816046550 = 5603862557654 := by decide
theorem cert_e1205816046550 : check e1205816046550 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1205816046554 : Closed e1205816046554 ∧ code e1205816046554 = 5603862557658 := by decide
theorem cert_e1205816046554 : check e1205816046554 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e1205816046622 : Closed e1205816046622 ∧ code e1205816046622 = 5603862557726 := by decide
theorem cert_e1205816046622 : check e1205816046622 [[],[]] .chain = true := by decide
def e1205816046818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205816046818 : Closed e1205816046818 ∧ code e1205816046818 = 5603862557922 := by decide
theorem cert_e1205816046818 : check e1205816046818 [[],[]] .chain = true := by decide
def e1205816046830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1205816046830 : Closed e1205816046830 ∧ code e1205816046830 = 5603862557934 := by decide
theorem cert_e1205816046830 : check e1205816046830 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816046838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1205816046838 : Closed e1205816046838 ∧ code e1205816046838 = 5603862557942 := by decide
theorem cert_e1205816046838 : check e1205816046838 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205816047118 : Closed e1205816047118 ∧ code e1205816047118 = 5603862558222 := by decide
theorem cert_e1205816047118 : check e1205816047118 [[],[]] .chain = true := by decide
def e1205816047130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205816047130 : Closed e1205816047130 ∧ code e1205816047130 = 5603862558234 := by decide
theorem cert_e1205816047130 : check e1205816047130 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205816047202 : Closed e1205816047202 ∧ code e1205816047202 = 5603862558306 := by decide
theorem cert_e1205816047202 : check e1205816047202 [[],[]] .chain = true := by decide
def e1205816047214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205816047214 : Closed e1205816047214 ∧ code e1205816047214 = 5603862558318 := by decide
theorem cert_e1205816047214 : check e1205816047214 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205816047222 : Closed e1205816047222 ∧ code e1205816047222 = 5603862558326 := by decide
theorem cert_e1205816047222 : check e1205816047222 [[],[]] .chain = true := by decide
def e1205816047226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205816047226 : Closed e1205816047226 ∧ code e1205816047226 = 5603862558330 := by decide
theorem cert_e1205816047226 : check e1205816047226 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205816047414 : Closed e1205816047414 ∧ code e1205816047414 = 5603862558518 := by decide
theorem cert_e1205816047414 : check e1205816047414 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205816047418 : Closed e1205816047418 ∧ code e1205816047418 = 5603862558522 := by decide
theorem cert_e1205816047418 : check e1205816047418 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e1205816047674 : Closed e1205816047674 ∧ code e1205816047674 = 5603862558778 := by decide
theorem cert_e1205816047674 : check e1205816047674 [[],[]] .chain = true := by decide
def e1205816047722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e1205816047722 : Closed e1205816047722 ∧ code e1205816047722 = 5603862558826 := by decide
theorem cert_e1205816047722 : check e1205816047722 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816047770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e1205816047770 : Closed e1205816047770 ∧ code e1205816047770 = 5603862558874 := by decide
theorem cert_e1205816047770 : check e1205816047770 [[],[]] .chain = true := by decide
def e1205816047814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e1205816047814 : Closed e1205816047814 ∧ code e1205816047814 = 5603862558918 := by decide
theorem cert_e1205816047814 : check e1205816047814 [[],[]] .chain = true := by decide
def e1205816048010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1205816048010 : Closed e1205816048010 ∧ code e1205816048010 = 5603862559114 := by decide
theorem cert_e1205816048010 : check e1205816048010 [[],[]] .chain = true := by decide
def e1205816048034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1205816048034 : Closed e1205816048034 ∧ code e1205816048034 = 5603862559138 := by decide
theorem cert_e1205816048034 : check e1205816048034 [[],[]] .chain = true := by decide
def e1205816048046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1205816048046 : Closed e1205816048046 ∧ code e1205816048046 = 5603862559150 := by decide
theorem cert_e1205816048046 : check e1205816048046 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1205816048054 : Closed e1205816048054 ∧ code e1205816048054 = 5603862559158 := by decide
theorem cert_e1205816048054 : check e1205816048054 [[],[]] .chain = true := by decide
def e1205816048058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1205816048058 : Closed e1205816048058 ∧ code e1205816048058 = 5603862559162 := by decide
theorem cert_e1205816048058 : check e1205816048058 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1205816048086 : Closed e1205816048086 ∧ code e1205816048086 = 5603862559190 := by decide
theorem cert_e1205816048086 : check e1205816048086 [[],[]] .chain = true := by decide
def e1205816048090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1205816048090 : Closed e1205816048090 ∧ code e1205816048090 = 5603862559194 := by decide
theorem cert_e1205816048090 : check e1205816048090 [[],[]] .chain = true := by decide
def e1205816048106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1205816048106 : Closed e1205816048106 ∧ code e1205816048106 = 5603862559210 := by decide
theorem cert_e1205816048106 : check e1205816048106 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e1205816048142 : Closed e1205816048142 ∧ code e1205816048142 = 5603862559246 := by decide
theorem cert_e1205816048142 : check e1205816048142 [[],[]] .chain = true := by decide
def e1205816048154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205816048154 : Closed e1205816048154 ∧ code e1205816048154 = 5603862559258 := by decide
theorem cert_e1205816048154 : check e1205816048154 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205816048226 : Closed e1205816048226 ∧ code e1205816048226 = 5603862559330 := by decide
theorem cert_e1205816048226 : check e1205816048226 [[],[]] .chain = true := by decide
def e1205816048238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1205816048238 : Closed e1205816048238 ∧ code e1205816048238 = 5603862559342 := by decide
theorem cert_e1205816048238 : check e1205816048238 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1205816048246 : Closed e1205816048246 ∧ code e1205816048246 = 5603862559350 := by decide
theorem cert_e1205816048246 : check e1205816048246 [[],[]] .chain = true := by decide
def e1205816048250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1205816048250 : Closed e1205816048250 ∧ code e1205816048250 = 5603862559354 := by decide
theorem cert_e1205816048250 : check e1205816048250 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205816048438 : Closed e1205816048438 ∧ code e1205816048438 = 5603862559542 := by decide
theorem cert_e1205816048438 : check e1205816048438 [[],[]] .chain = true := by decide
def e1205816048442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1205816048442 : Closed e1205816048442 ∧ code e1205816048442 = 5603862559546 := by decide
theorem cert_e1205816048442 : check e1205816048442 [[],[]] .chain = true := by decide
def e1205816048538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1205816048538 : Closed e1205816048538 ∧ code e1205816048538 = 5603862559642 := by decide
theorem cert_e1205816048538 : check e1205816048538 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1205816048854 : Closed e1205816048854 ∧ code e1205816048854 = 5603862559958 := by decide
theorem cert_e1205816048854 : check e1205816048854 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1205816048858 : Closed e1205816048858 ∧ code e1205816048858 = 5603862559962 := by decide
theorem cert_e1205816048858 : check e1205816048858 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1205816048874 : Closed e1205816048874 ∧ code e1205816048874 = 5603862559978 := by decide
theorem cert_e1205816048874 : check e1205816048874 [[],[],[.under,.under]] .smaller = true := by decide
def e1205816048950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1205816048950 : Closed e1205816048950 ∧ code e1205816048950 = 5603862560054 := by decide
theorem cert_e1205816048950 : check e1205816048950 [[],[],[.under,.under]] .smaller = true := by decide
end Blc.Floor42
