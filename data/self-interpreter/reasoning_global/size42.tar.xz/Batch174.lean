import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211188915962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e1211188915962 : Closed e1211188915962 ∧ code e1211188915962 = 5609235427066 := by decide
theorem cert_e1211188915962 : check e1211188915962 [[],[]] .three = true := by decide
def e1211188916078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1211188916078 : Closed e1211188916078 ∧ code e1211188916078 = 5609235427182 := by decide
theorem cert_e1211188916078 : check e1211188916078 [[],[]] .three = true := by decide
def e1211188916086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1211188916086 : Closed e1211188916086 ∧ code e1211188916086 = 5609235427190 := by decide
theorem cert_e1211188916086 : check e1211188916086 [[],[]] .three = true := by decide
def e1211188916150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1211188916150 : Closed e1211188916150 ∧ code e1211188916150 = 5609235427254 := by decide
theorem cert_e1211188916150 : check e1211188916150 [[],[]] .three = true := by decide
def e1211188916182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e1211188916182 : Closed e1211188916182 ∧ code e1211188916182 = 5609235427286 := by decide
private def t_e1211188916182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem cert_e1211188916182 : ¬ IsSelfInterpreter e1211188916182 :=
  wSource (t := t_e1211188916182) (replay_sound (ps := []) (t := e1211188916182) (by decide)) (by decide)
def e1211188916186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e1211188916186 : Closed e1211188916186 ∧ code e1211188916186 = 5609235427290 := by decide
theorem cert_e1211188916186 : check e1211188916186 [[],[]] .three = true := by decide
def e1211188917182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211188917182 : Closed e1211188917182 ∧ code e1211188917182 = 5609235428286 := by decide
theorem cert_e1211188917182 : check e1211188917182 [[],[]] .three = true := by decide
def e1211188917238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211188917238 : Closed e1211188917238 ∧ code e1211188917238 = 5609235428342 := by decide
theorem cert_e1211188917238 : check e1211188917238 [[],[]] .three = true := by decide
def e1211188918718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211188918718 : Closed e1211188918718 ∧ code e1211188918718 = 5609235429822 := by decide
theorem cert_e1211188918718 : check e1211188918718 [[],[]] .three = true := by decide
def e1211188918750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211188918750 : Closed e1211188918750 ∧ code e1211188918750 = 5609235429854 := by decide
theorem cert_e1211188918750 : check e1211188918750 [[],[]] .three = true := by decide
def e1211188918766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211188918766 : Closed e1211188918766 ∧ code e1211188918766 = 5609235429870 := by decide
theorem cert_e1211188918766 : check e1211188918766 [[],[]] .three = true := by decide
def e1211188918774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211188918774 : Closed e1211188918774 ∧ code e1211188918774 = 5609235429878 := by decide
theorem cert_e1211188918774 : check e1211188918774 [[],[]] .three = true := by decide
def e1211188918778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211188918778 : Closed e1211188918778 ∧ code e1211188918778 = 5609235429882 := by decide
theorem cert_e1211188918778 : check e1211188918778 [[],[]] .three = true := by decide
def e1211188919534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188919534 : Closed e1211188919534 ∧ code e1211188919534 = 5609235430638 := by decide
theorem cert_e1211188919534 : check e1211188919534 [[],[]] .three = true := by decide
def e1211188919542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188919542 : Closed e1211188919542 ∧ code e1211188919542 = 5609235430646 := by decide
theorem cert_e1211188919542 : check e1211188919542 [[],[]] .three = true := by decide
def e1211188919926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188919926 : Closed e1211188919926 ∧ code e1211188919926 = 5609235431030 := by decide
theorem cert_e1211188919926 : check e1211188919926 [[],[]] .three = true := by decide
def e1211188920118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188920118 : Closed e1211188920118 ∧ code e1211188920118 = 5609235431222 := by decide
theorem cert_e1211188920118 : check e1211188920118 [[],[]] .three = true := by decide
def e1211188920122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188920122 : Closed e1211188920122 ∧ code e1211188920122 = 5609235431226 := by decide
theorem cert_e1211188920122 : check e1211188920122 [[],[]] .three = true := by decide
def e1211188948054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e1211188948054 : Closed e1211188948054 ∧ code e1211188948054 = 5609235459158 := by decide
theorem cert_e1211188948054 : check e1211188948054 [[],[]] .three = true := by decide
def e1211188948058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e1211188948058 : Closed e1211188948058 ∧ code e1211188948058 = 5609235459162 := by decide
theorem cert_e1211188948058 : check e1211188948058 [[],[]] .three = true := by decide
def e1211188948246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211188948246 : Closed e1211188948246 ∧ code e1211188948246 = 5609235459350 := by decide
theorem cert_e1211188948246 : check e1211188948246 [[],[]] .three = true := by decide
def e1211188948322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211188948322 : Closed e1211188948322 ∧ code e1211188948322 = 5609235459426 := by decide
theorem cert_e1211188948322 : check e1211188948322 [[],[]] .three = true := by decide
def e1211188948334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211188948334 : Closed e1211188948334 ∧ code e1211188948334 = 5609235459438 := by decide
theorem cert_e1211188948334 : check e1211188948334 [[],[]] .three = true := by decide
def e1211188948342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211188948342 : Closed e1211188948342 ∧ code e1211188948342 = 5609235459446 := by decide
theorem cert_e1211188948342 : check e1211188948342 [[],[]] .three = true := by decide
def e1211188948362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188948362 : Closed e1211188948362 ∧ code e1211188948362 = 5609235459466 := by decide
theorem cert_e1211188948362 : check e1211188948362 [[],[]] .three = true := by decide
def e1211188948386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188948386 : Closed e1211188948386 ∧ code e1211188948386 = 5609235459490 := by decide
theorem cert_e1211188948386 : check e1211188948386 [[],[]] .three = true := by decide
def e1211188948398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211188948398 : Closed e1211188948398 ∧ code e1211188948398 = 5609235459502 := by decide
theorem cert_e1211188948398 : check e1211188948398 [[],[]] .three = true := by decide
def e1211188948406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))))))
theorem wire_e1211188948406 : Closed e1211188948406 ∧ code e1211188948406 = 5609235459510 := by decide
theorem cert_e1211188948406 : check e1211188948406 [[],[]] .three = true := by decide
def e1211188948410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211188948410 : Closed e1211188948410 ∧ code e1211188948410 = 5609235459514 := by decide
theorem cert_e1211188948410 : check e1211188948410 [[],[]] .three = true := by decide
def e1211188948438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211188948438 : Closed e1211188948438 ∧ code e1211188948438 = 5609235459542 := by decide
theorem cert_e1211188948438 : check e1211188948438 [[],[]] .three = true := by decide
def e1211188948442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211188948442 : Closed e1211188948442 ∧ code e1211188948442 = 5609235459546 := by decide
theorem cert_e1211188948442 : check e1211188948442 [[],[]] .three = true := by decide
def e1211188948522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e1211188948522 : Closed e1211188948522 ∧ code e1211188948522 = 5609235459626 := by decide
theorem cert_e1211188948522 : check e1211188948522 [[],[]] .three = true := by decide
def e1211188948618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211188948618 : Closed e1211188948618 ∧ code e1211188948618 = 5609235459722 := by decide
theorem cert_e1211188948618 : check e1211188948618 [[],[]] .three = true := by decide
def e1211188948642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211188948642 : Closed e1211188948642 ∧ code e1211188948642 = 5609235459746 := by decide
theorem cert_e1211188948642 : check e1211188948642 [[],[]] .three = true := by decide
def e1211188948654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211188948654 : Closed e1211188948654 ∧ code e1211188948654 = 5609235459758 := by decide
theorem cert_e1211188948654 : check e1211188948654 [[],[]] .three = true := by decide
def e1211188948662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211188948662 : Closed e1211188948662 ∧ code e1211188948662 = 5609235459766 := by decide
theorem cert_e1211188948662 : check e1211188948662 [[],[]] .three = true := by decide
def e1211188948666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211188948666 : Closed e1211188948666 ∧ code e1211188948666 = 5609235459770 := by decide
theorem cert_e1211188948666 : check e1211188948666 [[],[]] .three = true := by decide
def e1211188948694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211188948694 : Closed e1211188948694 ∧ code e1211188948694 = 5609235459798 := by decide
theorem cert_e1211188948694 : check e1211188948694 [[],[]] .three = true := by decide
def e1211188948698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211188948698 : Closed e1211188948698 ∧ code e1211188948698 = 5609235459802 := by decide
theorem cert_e1211188948698 : check e1211188948698 [[],[]] .three = true := by decide
def e1211188948714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211188948714 : Closed e1211188948714 ∧ code e1211188948714 = 5609235459818 := by decide
theorem cert_e1211188948714 : check e1211188948714 [[],[]] .three = true := by decide
def e1211188948822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211188948822 : Closed e1211188948822 ∧ code e1211188948822 = 5609235459926 := by decide
theorem cert_e1211188948822 : check e1211188948822 [[],[]] .three = true := by decide
def e1211188948826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211188948826 : Closed e1211188948826 ∧ code e1211188948826 = 5609235459930 := by decide
theorem cert_e1211188948826 : check e1211188948826 [[],[]] .three = true := by decide
def e1211188948842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211188948842 : Closed e1211188948842 ∧ code e1211188948842 = 5609235459946 := by decide
theorem cert_e1211188948842 : check e1211188948842 [[],[]] .three = true := by decide
def e1211188949110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e1211188949110 : Closed e1211188949110 ∧ code e1211188949110 = 5609235460214 := by decide
theorem cert_e1211188949110 : check e1211188949110 [[],[]] .three = true := by decide
def e1211188949114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211188949114 : Closed e1211188949114 ∧ code e1211188949114 = 5609235460218 := by decide
theorem cert_e1211188949114 : check e1211188949114 [[],[]] .three = true := by decide
def e1211188949206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e1211188949206 : Closed e1211188949206 ∧ code e1211188949206 = 5609235460310 := by decide
theorem cert_e1211188949206 : check e1211188949206 [[],[]] .three = true := by decide
def e1211188949302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188949302 : Closed e1211188949302 ∧ code e1211188949302 = 5609235460406 := by decide
theorem cert_e1211188949302 : check e1211188949302 [[],[]] .three = true := by decide
def e1211188949306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188949306 : Closed e1211188949306 ∧ code e1211188949306 = 5609235460410 := by decide
theorem cert_e1211188949306 : check e1211188949306 [[],[]] .three = true := by decide
def e1211188949390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e1211188949390 : Closed e1211188949390 ∧ code e1211188949390 = 5609235460494 := by decide
theorem cert_e1211188949390 : check e1211188949390 [[],[]] .three = true := by decide
def e1211188949446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211188949446 : Closed e1211188949446 ∧ code e1211188949446 = 5609235460550 := by decide
theorem cert_e1211188949446 : check e1211188949446 [[],[]] .three = true := by decide
def e1211188949470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211188949470 : Closed e1211188949470 ∧ code e1211188949470 = 5609235460574 := by decide
theorem cert_e1211188949470 : check e1211188949470 [[],[]] .three = true := by decide
def e1211188949486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211188949486 : Closed e1211188949486 ∧ code e1211188949486 = 5609235460590 := by decide
theorem cert_e1211188949486 : check e1211188949486 [[],[]] .three = true := by decide
def e1211188949494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211188949494 : Closed e1211188949494 ∧ code e1211188949494 = 5609235460598 := by decide
theorem cert_e1211188949494 : check e1211188949494 [[],[]] .three = true := by decide
def e1211188949782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211188949782 : Closed e1211188949782 ∧ code e1211188949782 = 5609235460886 := by decide
theorem cert_e1211188949782 : check e1211188949782 [[],[]] .three = true := by decide
def e1211188949858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211188949858 : Closed e1211188949858 ∧ code e1211188949858 = 5609235460962 := by decide
theorem cert_e1211188949858 : check e1211188949858 [[],[]] .three = true := by decide
def e1211188949870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211188949870 : Closed e1211188949870 ∧ code e1211188949870 = 5609235460974 := by decide
theorem cert_e1211188949870 : check e1211188949870 [[],[]] .three = true := by decide
def e1211188949878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211188949878 : Closed e1211188949878 ∧ code e1211188949878 = 5609235460982 := by decide
theorem cert_e1211188949878 : check e1211188949878 [[],[]] .three = true := by decide
def e1211188949898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188949898 : Closed e1211188949898 ∧ code e1211188949898 = 5609235461002 := by decide
theorem cert_e1211188949898 : check e1211188949898 [[],[]] .three = true := by decide
def e1211188949922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188949922 : Closed e1211188949922 ∧ code e1211188949922 = 5609235461026 := by decide
theorem cert_e1211188949922 : check e1211188949922 [[],[]] .three = true := by decide
def e1211188949934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211188949934 : Closed e1211188949934 ∧ code e1211188949934 = 5609235461038 := by decide
theorem cert_e1211188949934 : check e1211188949934 [[],[]] .three = true := by decide
def e1211188949942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))))))
theorem wire_e1211188949942 : Closed e1211188949942 ∧ code e1211188949942 = 5609235461046 := by decide
theorem cert_e1211188949942 : check e1211188949942 [[],[]] .three = true := by decide
def e1211188949946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211188949946 : Closed e1211188949946 ∧ code e1211188949946 = 5609235461050 := by decide
theorem cert_e1211188949946 : check e1211188949946 [[],[]] .three = true := by decide
def e1211188949974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211188949974 : Closed e1211188949974 ∧ code e1211188949974 = 5609235461078 := by decide
theorem cert_e1211188949974 : check e1211188949974 [[],[]] .three = true := by decide
def e1211188949978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211188949978 : Closed e1211188949978 ∧ code e1211188949978 = 5609235461082 := by decide
theorem cert_e1211188949978 : check e1211188949978 [[],[]] .three = true := by decide
def e1211188950046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e1211188950046 : Closed e1211188950046 ∧ code e1211188950046 = 5609235461150 := by decide
theorem cert_e1211188950046 : check e1211188950046 [[],[]] .three = true := by decide
def e1211188950242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211188950242 : Closed e1211188950242 ∧ code e1211188950242 = 5609235461346 := by decide
theorem cert_e1211188950242 : check e1211188950242 [[],[]] .three = true := by decide
def e1211188950254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211188950254 : Closed e1211188950254 ∧ code e1211188950254 = 5609235461358 := by decide
theorem cert_e1211188950254 : check e1211188950254 [[],[]] .three = true := by decide
def e1211188950262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211188950262 : Closed e1211188950262 ∧ code e1211188950262 = 5609235461366 := by decide
theorem cert_e1211188950262 : check e1211188950262 [[],[]] .three = true := by decide
def e1211188950542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188950542 : Closed e1211188950542 ∧ code e1211188950542 = 5609235461646 := by decide
theorem cert_e1211188950542 : check e1211188950542 [[],[]] .three = true := by decide
def e1211188950554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188950554 : Closed e1211188950554 ∧ code e1211188950554 = 5609235461658 := by decide
theorem cert_e1211188950554 : check e1211188950554 [[],[]] .three = true := by decide
def e1211188950590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211188950590 : Closed e1211188950590 ∧ code e1211188950590 = 5609235461694 := by decide
theorem cert_e1211188950590 : check e1211188950590 [[],[]] .three = true := by decide
def e1211188950626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188950626 : Closed e1211188950626 ∧ code e1211188950626 = 5609235461730 := by decide
theorem cert_e1211188950626 : check e1211188950626 [[],[]] .three = true := by decide
def e1211188950638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188950638 : Closed e1211188950638 ∧ code e1211188950638 = 5609235461742 := by decide
theorem cert_e1211188950638 : check e1211188950638 [[],[]] .three = true := by decide
def e1211188950646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188950646 : Closed e1211188950646 ∧ code e1211188950646 = 5609235461750 := by decide
theorem cert_e1211188950646 : check e1211188950646 [[],[]] .three = true := by decide
def e1211188950650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188950650 : Closed e1211188950650 ∧ code e1211188950650 = 5609235461754 := by decide
theorem cert_e1211188950650 : check e1211188950650 [[],[]] .three = true := by decide
def e1211188950814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211188950814 : Closed e1211188950814 ∧ code e1211188950814 = 5609235461918 := by decide
theorem cert_e1211188950814 : check e1211188950814 [[],[]] .three = true := by decide
def e1211188950838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188950838 : Closed e1211188950838 ∧ code e1211188950838 = 5609235461942 := by decide
theorem cert_e1211188950838 : check e1211188950838 [[],[]] .three = true := by decide
def e1211188950842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188950842 : Closed e1211188950842 ∧ code e1211188950842 = 5609235461946 := by decide
theorem cert_e1211188950842 : check e1211188950842 [[],[]] .three = true := by decide
def e1211188950926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211188950926 : Closed e1211188950926 ∧ code e1211188950926 = 5609235462030 := by decide
theorem cert_e1211188950926 : check e1211188950926 [[],[]] .three = true := by decide
def e1211188951098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211188951098 : Closed e1211188951098 ∧ code e1211188951098 = 5609235462202 := by decide
theorem cert_e1211188951098 : check e1211188951098 [[],[]] .three = true := by decide
def e1211188951146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e1211188951146 : Closed e1211188951146 ∧ code e1211188951146 = 5609235462250 := by decide
theorem cert_e1211188951146 : check e1211188951146 [[],[]] .three = true := by decide
def e1211188951194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188951194 : Closed e1211188951194 ∧ code e1211188951194 = 5609235462298 := by decide
theorem cert_e1211188951194 : check e1211188951194 [[],[]] .three = true := by decide
def e1211188951238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211188951238 : Closed e1211188951238 ∧ code e1211188951238 = 5609235462342 := by decide
theorem cert_e1211188951238 : check e1211188951238 [[],[]] .three = true := by decide
def e1211188951262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211188951262 : Closed e1211188951262 ∧ code e1211188951262 = 5609235462366 := by decide
theorem cert_e1211188951262 : check e1211188951262 [[],[]] .three = true := by decide
def e1211188951278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211188951278 : Closed e1211188951278 ∧ code e1211188951278 = 5609235462382 := by decide
theorem cert_e1211188951278 : check e1211188951278 [[],[]] .three = true := by decide
def e1211188951286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211188951286 : Closed e1211188951286 ∧ code e1211188951286 = 5609235462390 := by decide
theorem cert_e1211188951286 : check e1211188951286 [[],[]] .three = true := by decide
def e1211188951290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211188951290 : Closed e1211188951290 ∧ code e1211188951290 = 5609235462394 := by decide
theorem cert_e1211188951290 : check e1211188951290 [[],[]] .three = true := by decide
def e1211188951434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e1211188951434 : Closed e1211188951434 ∧ code e1211188951434 = 5609235462538 := by decide
theorem cert_e1211188951434 : check e1211188951434 [[],[]] .three = true := by decide
def e1211188951458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e1211188951458 : Closed e1211188951458 ∧ code e1211188951458 = 5609235462562 := by decide
theorem cert_e1211188951458 : check e1211188951458 [[],[]] .three = true := by decide
def e1211188951470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211188951470 : Closed e1211188951470 ∧ code e1211188951470 = 5609235462574 := by decide
theorem cert_e1211188951470 : check e1211188951470 [[],[]] .three = true := by decide
def e1211188951478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211188951478 : Closed e1211188951478 ∧ code e1211188951478 = 5609235462582 := by decide
theorem cert_e1211188951478 : check e1211188951478 [[],[]] .three = true := by decide
def e1211188951482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211188951482 : Closed e1211188951482 ∧ code e1211188951482 = 5609235462586 := by decide
theorem cert_e1211188951482 : check e1211188951482 [[],[]] .three = true := by decide
def e1211188951510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211188951510 : Closed e1211188951510 ∧ code e1211188951510 = 5609235462614 := by decide
theorem cert_e1211188951510 : check e1211188951510 [[],[]] .three = true := by decide
def e1211188951514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211188951514 : Closed e1211188951514 ∧ code e1211188951514 = 5609235462618 := by decide
theorem cert_e1211188951514 : check e1211188951514 [[],[]] .three = true := by decide
def e1211188951530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211188951530 : Closed e1211188951530 ∧ code e1211188951530 = 5609235462634 := by decide
theorem cert_e1211188951530 : check e1211188951530 [[],[]] .three = true := by decide
def e1211188951566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e1211188951566 : Closed e1211188951566 ∧ code e1211188951566 = 5609235462670 := by decide
theorem cert_e1211188951566 : check e1211188951566 [[],[]] .three = true := by decide
def e1211188951578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211188951578 : Closed e1211188951578 ∧ code e1211188951578 = 5609235462682 := by decide
theorem cert_e1211188951578 : check e1211188951578 [[],[]] .three = true := by decide
def e1211188951614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211188951614 : Closed e1211188951614 ∧ code e1211188951614 = 5609235462718 := by decide
theorem cert_e1211188951614 : check e1211188951614 [[],[]] .three = true := by decide
def e1211188951650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211188951650 : Closed e1211188951650 ∧ code e1211188951650 = 5609235462754 := by decide
theorem cert_e1211188951650 : check e1211188951650 [[],[]] .three = true := by decide
def e1211188951662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211188951662 : Closed e1211188951662 ∧ code e1211188951662 = 5609235462766 := by decide
theorem cert_e1211188951662 : check e1211188951662 [[],[]] .three = true := by decide
def e1211188951670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211188951670 : Closed e1211188951670 ∧ code e1211188951670 = 5609235462774 := by decide
theorem cert_e1211188951670 : check e1211188951670 [[],[]] .three = true := by decide
def e1211188951674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211188951674 : Closed e1211188951674 ∧ code e1211188951674 = 5609235462778 := by decide
theorem cert_e1211188951674 : check e1211188951674 [[],[]] .three = true := by decide
def e1211188951838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211188951838 : Closed e1211188951838 ∧ code e1211188951838 = 5609235462942 := by decide
theorem cert_e1211188951838 : check e1211188951838 [[],[]] .three = true := by decide
def e1211188951862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188951862 : Closed e1211188951862 ∧ code e1211188951862 = 5609235462966 := by decide
theorem cert_e1211188951862 : check e1211188951862 [[],[]] .three = true := by decide
def e1211188951866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188951866 : Closed e1211188951866 ∧ code e1211188951866 = 5609235462970 := by decide
theorem cert_e1211188951866 : check e1211188951866 [[],[]] .three = true := by decide
def e1211188951950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211188951950 : Closed e1211188951950 ∧ code e1211188951950 = 5609235463054 := by decide
theorem cert_e1211188951950 : check e1211188951950 [[],[]] .three = true := by decide
def e1211188951962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188951962 : Closed e1211188951962 ∧ code e1211188951962 = 5609235463066 := by decide
theorem cert_e1211188951962 : check e1211188951962 [[],[]] .three = true := by decide
def e1211188952006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211188952006 : Closed e1211188952006 ∧ code e1211188952006 = 5609235463110 := by decide
theorem cert_e1211188952006 : check e1211188952006 [[],[]] .three = true := by decide
def e1211188952174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211188952174 : Closed e1211188952174 ∧ code e1211188952174 = 5609235463278 := by decide
theorem cert_e1211188952174 : check e1211188952174 [[],[]] .three = true := by decide
def e1211188952182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211188952182 : Closed e1211188952182 ∧ code e1211188952182 = 5609235463286 := by decide
theorem cert_e1211188952182 : check e1211188952182 [[],[]] .three = true := by decide
def e1211188952186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211188952186 : Closed e1211188952186 ∧ code e1211188952186 = 5609235463290 := by decide
theorem cert_e1211188952186 : check e1211188952186 [[],[]] .three = true := by decide
def e1211188952278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211188952278 : Closed e1211188952278 ∧ code e1211188952278 = 5609235463382 := by decide
theorem cert_e1211188952278 : check e1211188952278 [[],[]] .three = true := by decide
def e1211188952282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211188952282 : Closed e1211188952282 ∧ code e1211188952282 = 5609235463386 := by decide
theorem cert_e1211188952282 : check e1211188952282 [[],[]] .three = true := by decide
def e1211188952298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211188952298 : Closed e1211188952298 ∧ code e1211188952298 = 5609235463402 := by decide
theorem cert_e1211188952298 : check e1211188952298 [[],[]] .three = true := by decide
def e1211188952350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211188952350 : Closed e1211188952350 ∧ code e1211188952350 = 5609235463454 := by decide
theorem cert_e1211188952350 : check e1211188952350 [[],[]] .three = true := by decide
def e1211188952374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211188952374 : Closed e1211188952374 ∧ code e1211188952374 = 5609235463478 := by decide
theorem cert_e1211188952374 : check e1211188952374 [[],[]] .three = true := by decide
def e1211188952378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211188952378 : Closed e1211188952378 ∧ code e1211188952378 = 5609235463482 := by decide
theorem cert_e1211188952378 : check e1211188952378 [[],[]] .three = true := by decide
def e1211188952462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211188952462 : Closed e1211188952462 ∧ code e1211188952462 = 5609235463566 := by decide
theorem cert_e1211188952462 : check e1211188952462 [[],[]] .three = true := by decide
def e1211188952474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211188952474 : Closed e1211188952474 ∧ code e1211188952474 = 5609235463578 := by decide
theorem cert_e1211188952474 : check e1211188952474 [[],[]] .three = true := by decide
def e1211188952518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211188952518 : Closed e1211188952518 ∧ code e1211188952518 = 5609235463622 := by decide
theorem cert_e1211188952518 : check e1211188952518 [[],[]] .three = true := by decide
def e1211188952630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211188952630 : Closed e1211188952630 ∧ code e1211188952630 = 5609235463734 := by decide
theorem cert_e1211188952630 : check e1211188952630 [[],[]] .three = true := by decide
def e1211188952634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211188952634 : Closed e1211188952634 ∧ code e1211188952634 = 5609235463738 := by decide
theorem cert_e1211188952634 : check e1211188952634 [[],[]] .three = true := by decide
def e1211188952718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211188952718 : Closed e1211188952718 ∧ code e1211188952718 = 5609235463822 := by decide
theorem cert_e1211188952718 : check e1211188952718 [[],[]] .three = true := by decide
def e1211188952774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211188952774 : Closed e1211188952774 ∧ code e1211188952774 = 5609235463878 := by decide
theorem cert_e1211188952774 : check e1211188952774 [[],[]] .three = true := by decide
def e1211188955926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e1211188955926 : Closed e1211188955926 ∧ code e1211188955926 = 5609235467030 := by decide
theorem cert_e1211188955926 : check e1211188955926 [[],[]] .three = true := by decide
def e1211188956002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e1211188956002 : Closed e1211188956002 ∧ code e1211188956002 = 5609235467106 := by decide
theorem cert_e1211188956002 : check e1211188956002 [[],[]] .three = true := by decide
def e1211188956014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211188956014 : Closed e1211188956014 ∧ code e1211188956014 = 5609235467118 := by decide
theorem cert_e1211188956014 : check e1211188956014 [[],[]] .three = true := by decide
def e1211188956022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211188956022 : Closed e1211188956022 ∧ code e1211188956022 = 5609235467126 := by decide
theorem cert_e1211188956022 : check e1211188956022 [[],[]] .three = true := by decide
def e1211188956042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188956042 : Closed e1211188956042 ∧ code e1211188956042 = 5609235467146 := by decide
theorem cert_e1211188956042 : check e1211188956042 [[],[]] .three = true := by decide
def e1211188956066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188956066 : Closed e1211188956066 ∧ code e1211188956066 = 5609235467170 := by decide
theorem cert_e1211188956066 : check e1211188956066 [[],[]] .three = true := by decide
def e1211188956078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211188956078 : Closed e1211188956078 ∧ code e1211188956078 = 5609235467182 := by decide
theorem cert_e1211188956078 : check e1211188956078 [[],[]] .three = true := by decide
def e1211188956086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e1211188956086 : Closed e1211188956086 ∧ code e1211188956086 = 5609235467190 := by decide
theorem cert_e1211188956086 : check e1211188956086 [[],[]] .three = true := by decide
def e1211188956090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211188956090 : Closed e1211188956090 ∧ code e1211188956090 = 5609235467194 := by decide
theorem cert_e1211188956090 : check e1211188956090 [[],[]] .three = true := by decide
def e1211188956118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211188956118 : Closed e1211188956118 ∧ code e1211188956118 = 5609235467222 := by decide
theorem cert_e1211188956118 : check e1211188956118 [[],[]] .three = true := by decide
def e1211188956122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211188956122 : Closed e1211188956122 ∧ code e1211188956122 = 5609235467226 := by decide
theorem cert_e1211188956122 : check e1211188956122 [[],[]] .three = true := by decide
def e1211188956190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e1211188956190 : Closed e1211188956190 ∧ code e1211188956190 = 5609235467294 := by decide
theorem cert_e1211188956190 : check e1211188956190 [[],[]] .three = true := by decide
def e1211188956386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211188956386 : Closed e1211188956386 ∧ code e1211188956386 = 5609235467490 := by decide
theorem cert_e1211188956386 : check e1211188956386 [[],[]] .three = true := by decide
def e1211188956398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211188956398 : Closed e1211188956398 ∧ code e1211188956398 = 5609235467502 := by decide
theorem cert_e1211188956398 : check e1211188956398 [[],[]] .three = true := by decide
def e1211188956406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211188956406 : Closed e1211188956406 ∧ code e1211188956406 = 5609235467510 := by decide
theorem cert_e1211188956406 : check e1211188956406 [[],[]] .three = true := by decide
def e1211188956686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188956686 : Closed e1211188956686 ∧ code e1211188956686 = 5609235467790 := by decide
theorem cert_e1211188956686 : check e1211188956686 [[],[]] .three = true := by decide
def e1211188956698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188956698 : Closed e1211188956698 ∧ code e1211188956698 = 5609235467802 := by decide
theorem cert_e1211188956698 : check e1211188956698 [[],[]] .three = true := by decide
def e1211188956734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211188956734 : Closed e1211188956734 ∧ code e1211188956734 = 5609235467838 := by decide
theorem cert_e1211188956734 : check e1211188956734 [[],[]] .three = true := by decide
def e1211188956770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e1211188956770 : Closed e1211188956770 ∧ code e1211188956770 = 5609235467874 := by decide
theorem cert_e1211188956770 : check e1211188956770 [[],[]] .three = true := by decide
def e1211188956782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211188956782 : Closed e1211188956782 ∧ code e1211188956782 = 5609235467886 := by decide
theorem cert_e1211188956782 : check e1211188956782 [[],[]] .three = true := by decide
def e1211188956790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211188956790 : Closed e1211188956790 ∧ code e1211188956790 = 5609235467894 := by decide
theorem cert_e1211188956790 : check e1211188956790 [[],[]] .three = true := by decide
def e1211188956794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211188956794 : Closed e1211188956794 ∧ code e1211188956794 = 5609235467898 := by decide
theorem cert_e1211188956794 : check e1211188956794 [[],[]] .three = true := by decide
def e1211188956958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211188956958 : Closed e1211188956958 ∧ code e1211188956958 = 5609235468062 := by decide
theorem cert_e1211188956958 : check e1211188956958 [[],[]] .three = true := by decide
def e1211188956982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211188956982 : Closed e1211188956982 ∧ code e1211188956982 = 5609235468086 := by decide
theorem cert_e1211188956982 : check e1211188956982 [[],[]] .three = true := by decide
def e1211188956986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211188956986 : Closed e1211188956986 ∧ code e1211188956986 = 5609235468090 := by decide
theorem cert_e1211188956986 : check e1211188956986 [[],[]] .three = true := by decide
def e1211188957070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211188957070 : Closed e1211188957070 ∧ code e1211188957070 = 5609235468174 := by decide
theorem cert_e1211188957070 : check e1211188957070 [[],[]] .three = true := by decide
def e1211188962698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e1211188962698 : Closed e1211188962698 ∧ code e1211188962698 = 5609235473802 := by decide
theorem cert_e1211188962698 : check e1211188962698 [[],[]] .three = true := by decide
def e1211188962722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e1211188962722 : Closed e1211188962722 ∧ code e1211188962722 = 5609235473826 := by decide
theorem cert_e1211188962722 : check e1211188962722 [[],[]] .three = true := by decide
def e1211188962734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211188962734 : Closed e1211188962734 ∧ code e1211188962734 = 5609235473838 := by decide
theorem cert_e1211188962734 : check e1211188962734 [[],[]] .three = true := by decide
def e1211188962742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211188962742 : Closed e1211188962742 ∧ code e1211188962742 = 5609235473846 := by decide
theorem cert_e1211188962742 : check e1211188962742 [[],[]] .three = true := by decide
def e1211188962746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211188962746 : Closed e1211188962746 ∧ code e1211188962746 = 5609235473850 := by decide
theorem cert_e1211188962746 : check e1211188962746 [[],[]] .three = true := by decide
def e1211188962774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211188962774 : Closed e1211188962774 ∧ code e1211188962774 = 5609235473878 := by decide
theorem cert_e1211188962774 : check e1211188962774 [[],[]] .three = true := by decide
def e1211188962778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211188962778 : Closed e1211188962778 ∧ code e1211188962778 = 5609235473882 := by decide
theorem cert_e1211188962778 : check e1211188962778 [[],[]] .three = true := by decide
def e1211188962794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211188962794 : Closed e1211188962794 ∧ code e1211188962794 = 5609235473898 := by decide
theorem cert_e1211188962794 : check e1211188962794 [[],[]] .three = true := by decide
def e1211188962830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e1211188962830 : Closed e1211188962830 ∧ code e1211188962830 = 5609235473934 := by decide
theorem cert_e1211188962830 : check e1211188962830 [[],[]] .three = true := by decide
def e1211188962842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211188962842 : Closed e1211188962842 ∧ code e1211188962842 = 5609235473946 := by decide
theorem cert_e1211188962842 : check e1211188962842 [[],[]] .three = true := by decide
end Blc.Floor42
