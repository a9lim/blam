import Tables
import Batch077
namespace Blc.Floor42.Grades077
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1196686693998 : ¬ IsSelfInterpreter e1196686693998 := cutM7_1 (by decide)
#print axioms ex_e1196686693998
end Blc.Floor42.Grades077
