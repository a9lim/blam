import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1131187473326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1131187473326 : Closed e1131187473326 ∧ code e1131187473326 = 5529233984430 := by decide
theorem cert_e1131187473326 : check e1131187473326 [[],[.under]] .smaller = true := by decide
def e1131187473338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1131187473338 : Closed e1131187473338 ∧ code e1131187473338 = 5529233984442 := by decide
theorem cert_e1131187473338 : check e1131187473338 [[],[.under]] .smaller = true := by decide
def e1131187473366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1131187473366 : Closed e1131187473366 ∧ code e1131187473366 = 5529233984470 := by decide
theorem cert_e1131187473366 : check e1131187473366 [[],[.under]] .smaller = true := by decide
def e1131187473370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1131187473370 : Closed e1131187473370 ∧ code e1131187473370 = 5529233984474 := by decide
theorem cert_e1131187473370 : check e1131187473370 [[],[.under]] .smaller = true := by decide
def e1131187473646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1131187473646 : Closed e1131187473646 ∧ code e1131187473646 = 5529233984750 := by decide
theorem cert_e1131187473646 : check e1131187473646 [[],[.under]] .smaller = true := by decide
def e1131187473654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1131187473654 : Closed e1131187473654 ∧ code e1131187473654 = 5529233984758 := by decide
theorem cert_e1131187473654 : check e1131187473654 [[],[.under]] .smaller = true := by decide
def e1131187474030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1131187474030 : Closed e1131187474030 ∧ code e1131187474030 = 5529233985134 := by decide
theorem cert_e1131187474030 : check e1131187474030 [[],[.under]] .smaller = true := by decide
def e1131187474042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1131187474042 : Closed e1131187474042 ∧ code e1131187474042 = 5529233985146 := by decide
theorem cert_e1131187474042 : check e1131187474042 [[],[.under]] .smaller = true := by decide
def e1131187474230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1131187474230 : Closed e1131187474230 ∧ code e1131187474230 = 5529233985334 := by decide
theorem cert_e1131187474230 : check e1131187474230 [[],[.under]] .smaller = true := by decide
def e1131187474234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1131187474234 : Closed e1131187474234 ∧ code e1131187474234 = 5529233985338 := by decide
theorem cert_e1131187474234 : check e1131187474234 [[],[.under]] .smaller = true := by decide
def e1131187481710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1131187481710 : Closed e1131187481710 ∧ code e1131187481710 = 5529233992814 := by decide
theorem cert_e1131187481710 : check e1131187481710 [[],[.under]] .smaller = true := by decide
def e1131187481722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1131187481722 : Closed e1131187481722 ∧ code e1131187481722 = 5529233992826 := by decide
theorem cert_e1131187481722 : check e1131187481722 [[],[.under]] .smaller = true := by decide
def e1131187481886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1131187481886 : Closed e1131187481886 ∧ code e1131187481886 = 5529233992990 := by decide
theorem cert_e1131187481886 : check e1131187481886 [[],[.under]] .smaller = true := by decide
def e1131187482054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1131187482054 : Closed e1131187482054 ∧ code e1131187482054 = 5529233993158 := by decide
theorem cert_e1131187482054 : check e1131187482054 [[],[.under]] .smaller = true := by decide
def e1131187482394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1131187482394 : Closed e1131187482394 ∧ code e1131187482394 = 5529233993498 := by decide
theorem cert_e1131187482394 : check e1131187482394 [[],[.under]] .smaller = true := by decide
def e1131187482438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1131187482438 : Closed e1131187482438 ∧ code e1131187482438 = 5529233993542 := by decide
theorem cert_e1131187482438 : check e1131187482438 [[],[.under]] .smaller = true := by decide
def e1131187483422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1131187483422 : Closed e1131187483422 ∧ code e1131187483422 = 5529233994526 := by decide
theorem cert_e1131187483422 : check e1131187483422 [[],[.under]] .smaller = true := by decide
def e1131187483590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1131187483590 : Closed e1131187483590 ∧ code e1131187483590 = 5529233994694 := by decide
theorem cert_e1131187483590 : check e1131187483590 [[],[.under]] .smaller = true := by decide
def e1131187485894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1131187485894 : Closed e1131187485894 ∧ code e1131187485894 = 5529233996998 := by decide
theorem cert_e1131187485894 : check e1131187485894 [[],[.under]] .smaller = true := by decide
def e1131187508790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1131187508790 : Closed e1131187508790 ∧ code e1131187508790 = 5529234019894 := by decide
theorem cert_e1131187508790 : check e1131187508790 [[],[.under]] .smaller = true := by decide
def e1131187508794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1131187508794 : Closed e1131187508794 ∧ code e1131187508794 = 5529234019898 := by decide
theorem cert_e1131187508794 : check e1131187508794 [[],[.under]] .smaller = true := by decide
def e1131187508878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1131187508878 : Closed e1131187508878 ∧ code e1131187508878 = 5529234019982 := by decide
theorem cert_e1131187508878 : check e1131187508878 [[],[.under]] .smaller = true := by decide
def e1131187508934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1131187508934 : Closed e1131187508934 ∧ code e1131187508934 = 5529234020038 := by decide
theorem cert_e1131187508934 : check e1131187508934 [[],[.under]] .smaller = true := by decide
def e1131187509018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1131187509018 : Closed e1131187509018 ∧ code e1131187509018 = 5529234020122 := by decide
theorem cert_e1131187509018 : check e1131187509018 [[],[.under]] .smaller = true := by decide
def e1131187509062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1131187509062 : Closed e1131187509062 ∧ code e1131187509062 = 5529234020166 := by decide
theorem cert_e1131187509062 : check e1131187509062 [[],[.under]] .smaller = true := by decide
def e1131187509646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1131187509646 : Closed e1131187509646 ∧ code e1131187509646 = 5529234020750 := by decide
theorem cert_e1131187509646 : check e1131187509646 [[],[.under]] .smaller = true := by decide
def e1131187509702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1131187509702 : Closed e1131187509702 ∧ code e1131187509702 = 5529234020806 := by decide
theorem cert_e1131187509702 : check e1131187509702 [[],[.under]] .smaller = true := by decide
def e1131187510470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1131187510470 : Closed e1131187510470 ∧ code e1131187510470 = 5529234021574 := by decide
theorem cert_e1131187510470 : check e1131187510470 [[],[.under]] .smaller = true := by decide
def e1131188415342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1131188415342 : Closed e1131188415342 ∧ code e1131188415342 = 5529234926446 := by decide
theorem cert_e1131188415342 : check e1131188415342 [[],[.under]] .three = true := by decide
def e1131188415350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1131188415350 : Closed e1131188415350 ∧ code e1131188415350 = 5529234926454 := by decide
theorem cert_e1131188415350 : check e1131188415350 [[],[.under]] .three = true := by decide
def e1131188415414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1131188415414 : Closed e1131188415414 ∧ code e1131188415414 = 5529234926518 := by decide
theorem cert_e1131188415414 : check e1131188415414 [[],[.under]] .three = true := by decide
def e1131188415854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1131188415854 : Closed e1131188415854 ∧ code e1131188415854 = 5529234926958 := by decide
theorem cert_e1131188415854 : check e1131188415854 [[],[.under]] .three = true := by decide
def e1131188415862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1131188415862 : Closed e1131188415862 ∧ code e1131188415862 = 5529234926966 := by decide
theorem cert_e1131188415862 : check e1131188415862 [[],[.under]] .three = true := by decide
def e1131188415918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1131188415918 : Closed e1131188415918 ∧ code e1131188415918 = 5529234927022 := by decide
theorem cert_e1131188415918 : check e1131188415918 [[],[.under]] .three = true := by decide
def e1131188415930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1131188415930 : Closed e1131188415930 ∧ code e1131188415930 = 5529234927034 := by decide
theorem cert_e1131188415930 : check e1131188415930 [[],[.under]] .three = true := by decide
def e1131188415958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1131188415958 : Closed e1131188415958 ∧ code e1131188415958 = 5529234927062 := by decide
theorem cert_e1131188415958 : check e1131188415958 [[],[.under]] .three = true := by decide
def e1131188415962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1131188415962 : Closed e1131188415962 ∧ code e1131188415962 = 5529234927066 := by decide
theorem cert_e1131188415962 : check e1131188415962 [[],[.under]] .three = true := by decide
def e1131188416182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1131188416182 : Closed e1131188416182 ∧ code e1131188416182 = 5529234927286 := by decide
theorem cert_e1131188416182 : check e1131188416182 [[],[.under]] .three = true := by decide
def e1131188416214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1131188416214 : Closed e1131188416214 ∧ code e1131188416214 = 5529234927318 := by decide
theorem cert_e1131188416214 : check e1131188416214 [[],[.under]] .three = true := by decide
def e1131188416218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1131188416218 : Closed e1131188416218 ∧ code e1131188416218 = 5529234927322 := by decide
theorem cert_e1131188416218 : check e1131188416218 [[],[.under]] .three = true := by decide
def e1131188417902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1131188417902 : Closed e1131188417902 ∧ code e1131188417902 = 5529234929006 := by decide
theorem cert_e1131188417902 : check e1131188417902 [[],[.under]] .three = true := by decide
def e1131188417910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1131188417910 : Closed e1131188417910 ∧ code e1131188417910 = 5529234929014 := by decide
theorem cert_e1131188417910 : check e1131188417910 [[],[.under]] .three = true := by decide
def e1131188417966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1131188417966 : Closed e1131188417966 ∧ code e1131188417966 = 5529234929070 := by decide
theorem cert_e1131188417966 : check e1131188417966 [[],[.under]] .three = true := by decide
def e1131188417978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1131188417978 : Closed e1131188417978 ∧ code e1131188417978 = 5529234929082 := by decide
theorem cert_e1131188417978 : check e1131188417978 [[],[.under]] .three = true := by decide
def e1131188418006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1131188418006 : Closed e1131188418006 ∧ code e1131188418006 = 5529234929110 := by decide
theorem cert_e1131188418006 : check e1131188418006 [[],[.under]] .three = true := by decide
def e1131188418010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1131188418010 : Closed e1131188418010 ∧ code e1131188418010 = 5529234929114 := by decide
theorem cert_e1131188418010 : check e1131188418010 [[],[.under]] .three = true := by decide
def e1131188418222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1131188418222 : Closed e1131188418222 ∧ code e1131188418222 = 5529234929326 := by decide
theorem cert_e1131188418222 : check e1131188418222 [[],[.under]] .three = true := by decide
def e1131188418234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1131188418234 : Closed e1131188418234 ∧ code e1131188418234 = 5529234929338 := by decide
theorem cert_e1131188418234 : check e1131188418234 [[],[.under]] .three = true := by decide
def e1131188418282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1131188418282 : Closed e1131188418282 ∧ code e1131188418282 = 5529234929386 := by decide
theorem cert_e1131188418282 : check e1131188418282 [[],[.under]] .three = true := by decide
def e1131188418390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1131188418390 : Closed e1131188418390 ∧ code e1131188418390 = 5529234929494 := by decide
theorem cert_e1131188418390 : check e1131188418390 [[],[.under]] .three = true := by decide
def e1131188418394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1131188418394 : Closed e1131188418394 ∧ code e1131188418394 = 5529234929498 := by decide
theorem cert_e1131188418394 : check e1131188418394 [[],[.under]] .three = true := by decide
def e1131188418410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1131188418410 : Closed e1131188418410 ∧ code e1131188418410 = 5529234929514 := by decide
theorem cert_e1131188418410 : check e1131188418410 [[],[.under]] .three = true := by decide
def e1131188419254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1131188419254 : Closed e1131188419254 ∧ code e1131188419254 = 5529234930358 := by decide
theorem cert_e1131188419254 : check e1131188419254 [[],[.under]] .three = true := by decide
def e1131188419286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1131188419286 : Closed e1131188419286 ∧ code e1131188419286 = 5529234930390 := by decide
theorem cert_e1131188419286 : check e1131188419286 [[],[.under]] .three = true := by decide
def e1131188419290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1131188419290 : Closed e1131188419290 ∧ code e1131188419290 = 5529234930394 := by decide
theorem cert_e1131188419290 : check e1131188419290 [[],[.under]] .three = true := by decide
def e1131188419414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1131188419414 : Closed e1131188419414 ∧ code e1131188419414 = 5529234930518 := by decide
theorem cert_e1131188419414 : check e1131188419414 [[],[.under]] .three = true := by decide
def e1131188419418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1131188419418 : Closed e1131188419418 ∧ code e1131188419418 = 5529234930522 := by decide
theorem cert_e1131188419418 : check e1131188419418 [[],[.under]] .three = true := by decide
def e1131188419434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1131188419434 : Closed e1131188419434 ∧ code e1131188419434 = 5529234930538 := by decide
theorem cert_e1131188419434 : check e1131188419434 [[],[.under]] .three = true := by decide
def e1131188424430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e1131188424430 : Closed e1131188424430 ∧ code e1131188424430 = 5529234935534 := by decide
theorem cert_e1131188424430 : check e1131188424430 [[],[.under]] .three = true := by decide
def e1131188424558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e1131188424558 : Closed e1131188424558 ∧ code e1131188424558 = 5529234935662 := by decide
theorem cert_e1131188424558 : check e1131188424558 [[],[.under]] .three = true := by decide
def e1131188424566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e1131188424566 : Closed e1131188424566 ∧ code e1131188424566 = 5529234935670 := by decide
theorem cert_e1131188424566 : check e1131188424566 [[],[.under]] .three = true := by decide
def e1131188427630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1131188427630 : Closed e1131188427630 ∧ code e1131188427630 = 5529234938734 := by decide
theorem cert_e1131188427630 : check e1131188427630 [[],[.under]] .three = true := by decide
def e1131188427638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1131188427638 : Closed e1131188427638 ∧ code e1131188427638 = 5529234938742 := by decide
theorem cert_e1131188427638 : check e1131188427638 [[],[.under]] .three = true := by decide
def e1131188427702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1131188427702 : Closed e1131188427702 ∧ code e1131188427702 = 5529234938806 := by decide
theorem cert_e1131188427702 : check e1131188427702 [[],[.under]] .three = true := by decide
def e1131188428142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1131188428142 : Closed e1131188428142 ∧ code e1131188428142 = 5529234939246 := by decide
theorem cert_e1131188428142 : check e1131188428142 [[],[.under]] .three = true := by decide
def e1131188428150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1131188428150 : Closed e1131188428150 ∧ code e1131188428150 = 5529234939254 := by decide
theorem cert_e1131188428150 : check e1131188428150 [[],[.under]] .three = true := by decide
def e1131188428206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1131188428206 : Closed e1131188428206 ∧ code e1131188428206 = 5529234939310 := by decide
theorem cert_e1131188428206 : check e1131188428206 [[],[.under]] .three = true := by decide
def e1131188428218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1131188428218 : Closed e1131188428218 ∧ code e1131188428218 = 5529234939322 := by decide
theorem cert_e1131188428218 : check e1131188428218 [[],[.under]] .three = true := by decide
def e1131188428246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1131188428246 : Closed e1131188428246 ∧ code e1131188428246 = 5529234939350 := by decide
theorem cert_e1131188428246 : check e1131188428246 [[],[.under]] .three = true := by decide
def e1131188428250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1131188428250 : Closed e1131188428250 ∧ code e1131188428250 = 5529234939354 := by decide
theorem cert_e1131188428250 : check e1131188428250 [[],[.under]] .three = true := by decide
def e1131188428470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1131188428470 : Closed e1131188428470 ∧ code e1131188428470 = 5529234939574 := by decide
theorem cert_e1131188428470 : check e1131188428470 [[],[.under]] .three = true := by decide
def e1131188428502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1131188428502 : Closed e1131188428502 ∧ code e1131188428502 = 5529234939606 := by decide
theorem cert_e1131188428502 : check e1131188428502 [[],[.under]] .three = true := by decide
def e1131188428506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1131188428506 : Closed e1131188428506 ∧ code e1131188428506 = 5529234939610 := by decide
theorem cert_e1131188428506 : check e1131188428506 [[],[.under]] .three = true := by decide
def e1131188430702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1131188430702 : Closed e1131188430702 ∧ code e1131188430702 = 5529234941806 := by decide
theorem cert_e1131188430702 : check e1131188430702 [[],[.under]] .three = true := by decide
def e1131188430710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1131188430710 : Closed e1131188430710 ∧ code e1131188430710 = 5529234941814 := by decide
theorem cert_e1131188430710 : check e1131188430710 [[],[.under]] .three = true := by decide
def e1131188430774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1131188430774 : Closed e1131188430774 ∧ code e1131188430774 = 5529234941878 := by decide
theorem cert_e1131188430774 : check e1131188430774 [[],[.under]] .three = true := by decide
def e1131188432110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188432110 : Closed e1131188432110 ∧ code e1131188432110 = 5529234943214 := by decide
theorem cert_e1131188432110 : check e1131188432110 [[],[.under]] .three = true := by decide
def e1131188432118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188432118 : Closed e1131188432118 ∧ code e1131188432118 = 5529234943222 := by decide
theorem cert_e1131188432118 : check e1131188432118 [[],[.under]] .three = true := by decide
def e1131188432502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1131188432502 : Closed e1131188432502 ∧ code e1131188432502 = 5529234943606 := by decide
theorem cert_e1131188432502 : check e1131188432502 [[],[.under]] .three = true := by decide
def e1131188433390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1131188433390 : Closed e1131188433390 ∧ code e1131188433390 = 5529234944494 := by decide
theorem cert_e1131188433390 : check e1131188433390 [[],[.under]] .three = true := by decide
def e1131188433774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1131188433774 : Closed e1131188433774 ∧ code e1131188433774 = 5529234944878 := by decide
theorem cert_e1131188433774 : check e1131188433774 [[],[.under]] .three = true := by decide
def e1131188433782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1131188433782 : Closed e1131188433782 ∧ code e1131188433782 = 5529234944886 := by decide
theorem cert_e1131188433782 : check e1131188433782 [[],[.under]] .three = true := by decide
def e1131188433838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1131188433838 : Closed e1131188433838 ∧ code e1131188433838 = 5529234944942 := by decide
theorem cert_e1131188433838 : check e1131188433838 [[],[.under]] .three = true := by decide
def e1131188433850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1131188433850 : Closed e1131188433850 ∧ code e1131188433850 = 5529234944954 := by decide
theorem cert_e1131188433850 : check e1131188433850 [[],[.under]] .three = true := by decide
def e1131188433878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1131188433878 : Closed e1131188433878 ∧ code e1131188433878 = 5529234944982 := by decide
theorem cert_e1131188433878 : check e1131188433878 [[],[.under]] .three = true := by decide
def e1131188433882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1131188433882 : Closed e1131188433882 ∧ code e1131188433882 = 5529234944986 := by decide
theorem cert_e1131188433882 : check e1131188433882 [[],[.under]] .three = true := by decide
def e1131188434158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188434158 : Closed e1131188434158 ∧ code e1131188434158 = 5529234945262 := by decide
theorem cert_e1131188434158 : check e1131188434158 [[],[.under]] .three = true := by decide
def e1131188434166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188434166 : Closed e1131188434166 ∧ code e1131188434166 = 5529234945270 := by decide
theorem cert_e1131188434166 : check e1131188434166 [[],[.under]] .three = true := by decide
def e1131188434542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188434542 : Closed e1131188434542 ∧ code e1131188434542 = 5529234945646 := by decide
theorem cert_e1131188434542 : check e1131188434542 [[],[.under]] .three = true := by decide
def e1131188434554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188434554 : Closed e1131188434554 ∧ code e1131188434554 = 5529234945658 := by decide
theorem cert_e1131188434554 : check e1131188434554 [[],[.under]] .three = true := by decide
def e1131188434718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1131188434718 : Closed e1131188434718 ∧ code e1131188434718 = 5529234945822 := by decide
theorem cert_e1131188434718 : check e1131188434718 [[],[.under]] .three = true := by decide
def e1131188434742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188434742 : Closed e1131188434742 ∧ code e1131188434742 = 5529234945846 := by decide
theorem cert_e1131188434742 : check e1131188434742 [[],[.under]] .three = true := by decide
def e1131188434746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188434746 : Closed e1131188434746 ∧ code e1131188434746 = 5529234945850 := by decide
theorem cert_e1131188434746 : check e1131188434746 [[],[.under]] .three = true := by decide
def e1131188435182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1131188435182 : Closed e1131188435182 ∧ code e1131188435182 = 5529234946286 := by decide
theorem cert_e1131188435182 : check e1131188435182 [[],[.under]] .three = true := by decide
def e1131188435190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1131188435190 : Closed e1131188435190 ∧ code e1131188435190 = 5529234946294 := by decide
theorem cert_e1131188435190 : check e1131188435190 [[],[.under]] .three = true := by decide
def e1131188435382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1131188435382 : Closed e1131188435382 ∧ code e1131188435382 = 5529234946486 := by decide
theorem cert_e1131188435382 : check e1131188435382 [[],[.under]] .three = true := by decide
def e1131188435414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1131188435414 : Closed e1131188435414 ∧ code e1131188435414 = 5529234946518 := by decide
theorem cert_e1131188435414 : check e1131188435414 [[],[.under]] .three = true := by decide
def e1131188435418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1131188435418 : Closed e1131188435418 ∧ code e1131188435418 = 5529234946522 := by decide
theorem cert_e1131188435418 : check e1131188435418 [[],[.under]] .three = true := by decide
def e1131188435574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1131188435574 : Closed e1131188435574 ∧ code e1131188435574 = 5529234946678 := by decide
theorem cert_e1131188435574 : check e1131188435574 [[],[.under]] .three = true := by decide
def e1131188435742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1131188435742 : Closed e1131188435742 ∧ code e1131188435742 = 5529234946846 := by decide
theorem cert_e1131188435742 : check e1131188435742 [[],[.under]] .three = true := by decide
def e1131188435766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188435766 : Closed e1131188435766 ∧ code e1131188435766 = 5529234946870 := by decide
theorem cert_e1131188435766 : check e1131188435766 [[],[.under]] .three = true := by decide
def e1131188435770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188435770 : Closed e1131188435770 ∧ code e1131188435770 = 5529234946874 := by decide
theorem cert_e1131188435770 : check e1131188435770 [[],[.under]] .three = true := by decide
def e1131188435854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1131188435854 : Closed e1131188435854 ∧ code e1131188435854 = 5529234946958 := by decide
theorem cert_e1131188435854 : check e1131188435854 [[],[.under]] .three = true := by decide
def e1131188438766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e1131188438766 : Closed e1131188438766 ∧ code e1131188438766 = 5529234949870 := by decide
theorem cert_e1131188438766 : check e1131188438766 [[],[.under]] .three = true := by decide
def e1131188438958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e1131188438958 : Closed e1131188438958 ∧ code e1131188438958 = 5529234950062 := by decide
theorem cert_e1131188438958 : check e1131188438958 [[],[.under]] .three = true := by decide
def e1131188438970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e1131188438970 : Closed e1131188438970 ∧ code e1131188438970 = 5529234950074 := by decide
theorem cert_e1131188438970 : check e1131188438970 [[],[.under]] .three = true := by decide
def e1131188440430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1131188440430 : Closed e1131188440430 ∧ code e1131188440430 = 5529234951534 := by decide
theorem cert_e1131188440430 : check e1131188440430 [[],[.under]] .three = true := by decide
def e1131188440438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1131188440438 : Closed e1131188440438 ∧ code e1131188440438 = 5529234951542 := by decide
theorem cert_e1131188440438 : check e1131188440438 [[],[.under]] .three = true := by decide
def e1131188440494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1131188440494 : Closed e1131188440494 ∧ code e1131188440494 = 5529234951598 := by decide
theorem cert_e1131188440494 : check e1131188440494 [[],[.under]] .three = true := by decide
def e1131188440506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1131188440506 : Closed e1131188440506 ∧ code e1131188440506 = 5529234951610 := by decide
theorem cert_e1131188440506 : check e1131188440506 [[],[.under]] .three = true := by decide
def e1131188440534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1131188440534 : Closed e1131188440534 ∧ code e1131188440534 = 5529234951638 := by decide
theorem cert_e1131188440534 : check e1131188440534 [[],[.under]] .three = true := by decide
def e1131188440538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1131188440538 : Closed e1131188440538 ∧ code e1131188440538 = 5529234951642 := by decide
theorem cert_e1131188440538 : check e1131188440538 [[],[.under]] .three = true := by decide
def e1131188440750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1131188440750 : Closed e1131188440750 ∧ code e1131188440750 = 5529234951854 := by decide
theorem cert_e1131188440750 : check e1131188440750 [[],[.under]] .three = true := by decide
def e1131188440762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1131188440762 : Closed e1131188440762 ∧ code e1131188440762 = 5529234951866 := by decide
theorem cert_e1131188440762 : check e1131188440762 [[],[.under]] .three = true := by decide
def e1131188440810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1131188440810 : Closed e1131188440810 ∧ code e1131188440810 = 5529234951914 := by decide
theorem cert_e1131188440810 : check e1131188440810 [[],[.under]] .three = true := by decide
def e1131188440918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1131188440918 : Closed e1131188440918 ∧ code e1131188440918 = 5529234952022 := by decide
theorem cert_e1131188440918 : check e1131188440918 [[],[.under]] .three = true := by decide
def e1131188440922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1131188440922 : Closed e1131188440922 ∧ code e1131188440922 = 5529234952026 := by decide
theorem cert_e1131188440922 : check e1131188440922 [[],[.under]] .three = true := by decide
def e1131188440938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1131188440938 : Closed e1131188440938 ∧ code e1131188440938 = 5529234952042 := by decide
theorem cert_e1131188440938 : check e1131188440938 [[],[.under]] .three = true := by decide
def e1131188441582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1131188441582 : Closed e1131188441582 ∧ code e1131188441582 = 5529234952686 := by decide
theorem cert_e1131188441582 : check e1131188441582 [[],[.under]] .three = true := by decide
def e1131188441966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1131188441966 : Closed e1131188441966 ∧ code e1131188441966 = 5529234953070 := by decide
theorem cert_e1131188441966 : check e1131188441966 [[],[.under]] .three = true := by decide
def e1131188441974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1131188441974 : Closed e1131188441974 ∧ code e1131188441974 = 5529234953078 := by decide
theorem cert_e1131188441974 : check e1131188441974 [[],[.under]] .three = true := by decide
def e1131188442030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1131188442030 : Closed e1131188442030 ∧ code e1131188442030 = 5529234953134 := by decide
theorem cert_e1131188442030 : check e1131188442030 [[],[.under]] .three = true := by decide
def e1131188442042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1131188442042 : Closed e1131188442042 ∧ code e1131188442042 = 5529234953146 := by decide
theorem cert_e1131188442042 : check e1131188442042 [[],[.under]] .three = true := by decide
def e1131188442070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1131188442070 : Closed e1131188442070 ∧ code e1131188442070 = 5529234953174 := by decide
theorem cert_e1131188442070 : check e1131188442070 [[],[.under]] .three = true := by decide
def e1131188442074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1131188442074 : Closed e1131188442074 ∧ code e1131188442074 = 5529234953178 := by decide
theorem cert_e1131188442074 : check e1131188442074 [[],[.under]] .three = true := by decide
def e1131188442350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1131188442350 : Closed e1131188442350 ∧ code e1131188442350 = 5529234953454 := by decide
theorem cert_e1131188442350 : check e1131188442350 [[],[.under]] .three = true := by decide
def e1131188442358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1131188442358 : Closed e1131188442358 ∧ code e1131188442358 = 5529234953462 := by decide
theorem cert_e1131188442358 : check e1131188442358 [[],[.under]] .three = true := by decide
def e1131188442734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188442734 : Closed e1131188442734 ∧ code e1131188442734 = 5529234953838 := by decide
theorem cert_e1131188442734 : check e1131188442734 [[],[.under]] .three = true := by decide
def e1131188442746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188442746 : Closed e1131188442746 ∧ code e1131188442746 = 5529234953850 := by decide
theorem cert_e1131188442746 : check e1131188442746 [[],[.under]] .three = true := by decide
def e1131188442910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1131188442910 : Closed e1131188442910 ∧ code e1131188442910 = 5529234954014 := by decide
theorem cert_e1131188442910 : check e1131188442910 [[],[.under]] .three = true := by decide
def e1131188442934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188442934 : Closed e1131188442934 ∧ code e1131188442934 = 5529234954038 := by decide
theorem cert_e1131188442934 : check e1131188442934 [[],[.under]] .three = true := by decide
def e1131188442938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188442938 : Closed e1131188442938 ∧ code e1131188442938 = 5529234954042 := by decide
theorem cert_e1131188442938 : check e1131188442938 [[],[.under]] .three = true := by decide
def e1131188443566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1131188443566 : Closed e1131188443566 ∧ code e1131188443566 = 5529234954670 := by decide
theorem cert_e1131188443566 : check e1131188443566 [[],[.under]] .three = true := by decide
def e1131188443578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1131188443578 : Closed e1131188443578 ∧ code e1131188443578 = 5529234954682 := by decide
theorem cert_e1131188443578 : check e1131188443578 [[],[.under]] .three = true := by decide
def e1131188443626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1131188443626 : Closed e1131188443626 ∧ code e1131188443626 = 5529234954730 := by decide
theorem cert_e1131188443626 : check e1131188443626 [[],[.under]] .three = true := by decide
def e1131188443758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1131188443758 : Closed e1131188443758 ∧ code e1131188443758 = 5529234954862 := by decide
theorem cert_e1131188443758 : check e1131188443758 [[],[.under]] .three = true := by decide
def e1131188443770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1131188443770 : Closed e1131188443770 ∧ code e1131188443770 = 5529234954874 := by decide
theorem cert_e1131188443770 : check e1131188443770 [[],[.under]] .three = true := by decide
def e1131188444058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1131188444058 : Closed e1131188444058 ∧ code e1131188444058 = 5529234955162 := by decide
theorem cert_e1131188444058 : check e1131188444058 [[],[.under]] .three = true := by decide
def e1131188444270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1131188444270 : Closed e1131188444270 ∧ code e1131188444270 = 5529234955374 := by decide
theorem cert_e1131188444270 : check e1131188444270 [[],[.under]] .three = true := by decide
def e1131188444282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1131188444282 : Closed e1131188444282 ∧ code e1131188444282 = 5529234955386 := by decide
theorem cert_e1131188444282 : check e1131188444282 [[],[.under]] .three = true := by decide
def e1131188444374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1131188444374 : Closed e1131188444374 ∧ code e1131188444374 = 5529234955478 := by decide
theorem cert_e1131188444374 : check e1131188444374 [[],[.under]] .three = true := by decide
def e1131188444378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1131188444378 : Closed e1131188444378 ∧ code e1131188444378 = 5529234955482 := by decide
theorem cert_e1131188444378 : check e1131188444378 [[],[.under]] .three = true := by decide
def e1131188444394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1131188444394 : Closed e1131188444394 ∧ code e1131188444394 = 5529234955498 := by decide
theorem cert_e1131188444394 : check e1131188444394 [[],[.under]] .three = true := by decide
def e1131188444446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1131188444446 : Closed e1131188444446 ∧ code e1131188444446 = 5529234955550 := by decide
theorem cert_e1131188444446 : check e1131188444446 [[],[.under]] .three = true := by decide
def e1131188444470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1131188444470 : Closed e1131188444470 ∧ code e1131188444470 = 5529234955574 := by decide
theorem cert_e1131188444470 : check e1131188444470 [[],[.under]] .three = true := by decide
def e1131188444474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1131188444474 : Closed e1131188444474 ∧ code e1131188444474 = 5529234955578 := by decide
theorem cert_e1131188444474 : check e1131188444474 [[],[.under]] .three = true := by decide
def e1131188444570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1131188444570 : Closed e1131188444570 ∧ code e1131188444570 = 5529234955674 := by decide
theorem cert_e1131188444570 : check e1131188444570 [[],[.under]] .three = true := by decide
def e1131188444614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1131188444614 : Closed e1131188444614 ∧ code e1131188444614 = 5529234955718 := by decide
theorem cert_e1131188444614 : check e1131188444614 [[],[.under]] .three = true := by decide
def e1131188446062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1131188446062 : Closed e1131188446062 ∧ code e1131188446062 = 5529234957166 := by decide
theorem cert_e1131188446062 : check e1131188446062 [[],[.under]] .three = true := by decide
def e1131188446070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1131188446070 : Closed e1131188446070 ∧ code e1131188446070 = 5529234957174 := by decide
theorem cert_e1131188446070 : check e1131188446070 [[],[.under]] .three = true := by decide
def e1131188446126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1131188446126 : Closed e1131188446126 ∧ code e1131188446126 = 5529234957230 := by decide
theorem cert_e1131188446126 : check e1131188446126 [[],[.under]] .three = true := by decide
def e1131188446138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1131188446138 : Closed e1131188446138 ∧ code e1131188446138 = 5529234957242 := by decide
theorem cert_e1131188446138 : check e1131188446138 [[],[.under]] .three = true := by decide
def e1131188446166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1131188446166 : Closed e1131188446166 ∧ code e1131188446166 = 5529234957270 := by decide
theorem cert_e1131188446166 : check e1131188446166 [[],[.under]] .three = true := by decide
def e1131188446170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1131188446170 : Closed e1131188446170 ∧ code e1131188446170 = 5529234957274 := by decide
theorem cert_e1131188446170 : check e1131188446170 [[],[.under]] .three = true := by decide
def e1131188446902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1131188446902 : Closed e1131188446902 ∧ code e1131188446902 = 5529234958006 := by decide
theorem cert_e1131188446902 : check e1131188446902 [[],[.under]] .three = true := by decide
def e1131188446934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1131188446934 : Closed e1131188446934 ∧ code e1131188446934 = 5529234958038 := by decide
theorem cert_e1131188446934 : check e1131188446934 [[],[.under]] .three = true := by decide
def e1131188446938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1131188446938 : Closed e1131188446938 ∧ code e1131188446938 = 5529234958042 := by decide
theorem cert_e1131188446938 : check e1131188446938 [[],[.under]] .three = true := by decide
def e1131188447062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1131188447062 : Closed e1131188447062 ∧ code e1131188447062 = 5529234958166 := by decide
theorem cert_e1131188447062 : check e1131188447062 [[],[.under]] .three = true := by decide
def e1131188447066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1131188447066 : Closed e1131188447066 ∧ code e1131188447066 = 5529234958170 := by decide
theorem cert_e1131188447066 : check e1131188447066 [[],[.under]] .three = true := by decide
def e1131188447082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1131188447082 : Closed e1131188447082 ∧ code e1131188447082 = 5529234958186 := by decide
theorem cert_e1131188447082 : check e1131188447082 [[],[.under]] .three = true := by decide
end Blc.Floor42
