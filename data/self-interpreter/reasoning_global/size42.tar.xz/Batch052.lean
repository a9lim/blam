import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1130046223162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1130046223162 : Closed e1130046223162 ∧ code e1130046223162 = 5528092734266 := by decide
theorem cert_e1130046223162 : check e1130046223162 [[],[.under]] .smaller = true := by decide
def e1130046223258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1130046223258 : Closed e1130046223258 ∧ code e1130046223258 = 5528092734362 := by decide
theorem cert_e1130046223258 : check e1130046223258 [[],[.under]] .smaller = true := by decide
def e1130046338798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e1130046338798 : Closed e1130046338798 ∧ code e1130046338798 = 5528092849902 := by decide
theorem cert_e1130046338798 : check e1130046338798 [[],[.under]] .three = true := by decide
def e1130046338926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e1130046338926 : Closed e1130046338926 ∧ code e1130046338926 = 5528092850030 := by decide
theorem cert_e1130046338926 : check e1130046338926 [[],[.under]] .three = true := by decide
def e1130046338934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e1130046338934 : Closed e1130046338934 ∧ code e1130046338934 = 5528092850038 := by decide
theorem cert_e1130046338934 : check e1130046338934 [[],[.under]] .three = true := by decide
def e1130046339822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1130046339822 : Closed e1130046339822 ∧ code e1130046339822 = 5528092850926 := by decide
theorem cert_e1130046339822 : check e1130046339822 [[],[.under]] .three = true := by decide
def e1130046340014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1130046340014 : Closed e1130046340014 ∧ code e1130046340014 = 5528092851118 := by decide
theorem cert_e1130046340014 : check e1130046340014 [[],[.under]] .three = true := by decide
def e1130046340026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1130046340026 : Closed e1130046340026 ∧ code e1130046340026 = 5528092851130 := by decide
theorem cert_e1130046340026 : check e1130046340026 [[],[.under]] .three = true := by decide
def e1130046340462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1130046340462 : Closed e1130046340462 ∧ code e1130046340462 = 5528092851566 := by decide
theorem cert_e1130046340462 : check e1130046340462 [[],[.under]] .three = true := by decide
def e1130046340470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1130046340470 : Closed e1130046340470 ∧ code e1130046340470 = 5528092851574 := by decide
theorem cert_e1130046340470 : check e1130046340470 [[],[.under]] .three = true := by decide
def e1130046340526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1130046340526 : Closed e1130046340526 ∧ code e1130046340526 = 5528092851630 := by decide
theorem cert_e1130046340526 : check e1130046340526 [[],[.under]] .three = true := by decide
def e1130046340538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1130046340538 : Closed e1130046340538 ∧ code e1130046340538 = 5528092851642 := by decide
theorem cert_e1130046340538 : check e1130046340538 [[],[.under]] .three = true := by decide
def e1130046340566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1130046340566 : Closed e1130046340566 ∧ code e1130046340566 = 5528092851670 := by decide
theorem cert_e1130046340566 : check e1130046340566 [[],[.under]] .three = true := by decide
def e1130046340570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1130046340570 : Closed e1130046340570 ∧ code e1130046340570 = 5528092851674 := by decide
theorem cert_e1130046340570 : check e1130046340570 [[],[.under]] .three = true := by decide
def e1130046344942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e1130046344942 : Closed e1130046344942 ∧ code e1130046344942 = 5528092856046 := by decide
theorem cert_e1130046344942 : check e1130046344942 [[],[.under]] .three = true := by decide
def e1130046345070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e1130046345070 : Closed e1130046345070 ∧ code e1130046345070 = 5528092856174 := by decide
theorem cert_e1130046345070 : check e1130046345070 [[],[.under]] .three = true := by decide
def e1130046345078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e1130046345078 : Closed e1130046345078 ∧ code e1130046345078 = 5528092856182 := by decide
theorem cert_e1130046345078 : check e1130046345078 [[],[.under]] .three = true := by decide
def e1130046347758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e1130046347758 : Closed e1130046347758 ∧ code e1130046347758 = 5528092858862 := by decide
theorem cert_e1130046347758 : check e1130046347758 [[],[.under]] .three = true := by decide
def e1130046348526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130046348526 : Closed e1130046348526 ∧ code e1130046348526 = 5528092859630 := by decide
theorem cert_e1130046348526 : check e1130046348526 [[],[.under]] .three = true := by decide
def e1130046348534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130046348534 : Closed e1130046348534 ∧ code e1130046348534 = 5528092859638 := by decide
theorem cert_e1130046348534 : check e1130046348534 [[],[.under]] .three = true := by decide
def e1130046351086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1130046351086 : Closed e1130046351086 ∧ code e1130046351086 = 5528092862190 := by decide
theorem cert_e1130046351086 : check e1130046351086 [[],[.under]] .three = true := by decide
def e1130046351278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1130046351278 : Closed e1130046351278 ∧ code e1130046351278 = 5528092862382 := by decide
theorem cert_e1130046351278 : check e1130046351278 [[],[.under]] .three = true := by decide
def e1130046351290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1130046351290 : Closed e1130046351290 ∧ code e1130046351290 = 5528092862394 := by decide
theorem cert_e1130046351290 : check e1130046351290 [[],[.under]] .three = true := by decide
def e1130046351854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1130046351854 : Closed e1130046351854 ∧ code e1130046351854 = 5528092862958 := by decide
theorem cert_e1130046351854 : check e1130046351854 [[],[.under]] .three = true := by decide
def e1130046353006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1130046353006 : Closed e1130046353006 ∧ code e1130046353006 = 5528092864110 := by decide
theorem cert_e1130046353006 : check e1130046353006 [[],[.under]] .three = true := by decide
def e1130046353018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1130046353018 : Closed e1130046353018 ∧ code e1130046353018 = 5528092864122 := by decide
theorem cert_e1130046353018 : check e1130046353018 [[],[.under]] .three = true := by decide
def e1130046354286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1130046354286 : Closed e1130046354286 ∧ code e1130046354286 = 5528092865390 := by decide
theorem cert_e1130046354286 : check e1130046354286 [[],[.under]] .three = true := by decide
def e1130046354294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1130046354294 : Closed e1130046354294 ∧ code e1130046354294 = 5528092865398 := by decide
theorem cert_e1130046354294 : check e1130046354294 [[],[.under]] .three = true := by decide
def e1130046354350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1130046354350 : Closed e1130046354350 ∧ code e1130046354350 = 5528092865454 := by decide
theorem cert_e1130046354350 : check e1130046354350 [[],[.under]] .three = true := by decide
def e1130046354362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1130046354362 : Closed e1130046354362 ∧ code e1130046354362 = 5528092865466 := by decide
theorem cert_e1130046354362 : check e1130046354362 [[],[.under]] .three = true := by decide
def e1130046354390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1130046354390 : Closed e1130046354390 ∧ code e1130046354390 = 5528092865494 := by decide
theorem cert_e1130046354390 : check e1130046354390 [[],[.under]] .three = true := by decide
def e1130046354394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1130046354394 : Closed e1130046354394 ∧ code e1130046354394 = 5528092865498 := by decide
theorem cert_e1130046354394 : check e1130046354394 [[],[.under]] .three = true := by decide
def e1130046354670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130046354670 : Closed e1130046354670 ∧ code e1130046354670 = 5528092865774 := by decide
theorem cert_e1130046354670 : check e1130046354670 [[],[.under]] .three = true := by decide
def e1130046354678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130046354678 : Closed e1130046354678 ∧ code e1130046354678 = 5528092865782 := by decide
theorem cert_e1130046354678 : check e1130046354678 [[],[.under]] .three = true := by decide
def e1130046355054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1130046355054 : Closed e1130046355054 ∧ code e1130046355054 = 5528092866158 := by decide
theorem cert_e1130046355054 : check e1130046355054 [[],[.under]] .three = true := by decide
def e1130046355066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1130046355066 : Closed e1130046355066 ∧ code e1130046355066 = 5528092866170 := by decide
theorem cert_e1130046355066 : check e1130046355066 [[],[.under]] .three = true := by decide
def e1130046355254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1130046355254 : Closed e1130046355254 ∧ code e1130046355254 = 5528092866358 := by decide
theorem cert_e1130046355254 : check e1130046355254 [[],[.under]] .three = true := by decide
def e1130046355258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1130046355258 : Closed e1130046355258 ∧ code e1130046355258 = 5528092866362 := by decide
theorem cert_e1130046355258 : check e1130046355258 [[],[.under]] .three = true := by decide
def e1130046360430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1130046360430 : Closed e1130046360430 ∧ code e1130046360430 = 5528092871534 := by decide
theorem cert_e1130046360430 : check e1130046360430 [[],[.under]] .smaller = true := by decide
def e1130046360438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1130046360438 : Closed e1130046360438 ∧ code e1130046360438 = 5528092871542 := by decide
theorem cert_e1130046360438 : check e1130046360438 [[],[.under]] .smaller = true := by decide
def e1130046360494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1130046360494 : Closed e1130046360494 ∧ code e1130046360494 = 5528092871598 := by decide
theorem cert_e1130046360494 : check e1130046360494 [[],[.under]] .smaller = true := by decide
def e1130046360506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1130046360506 : Closed e1130046360506 ∧ code e1130046360506 = 5528092871610 := by decide
theorem cert_e1130046360506 : check e1130046360506 [[],[.under]] .smaller = true := by decide
def e1130046360534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1130046360534 : Closed e1130046360534 ∧ code e1130046360534 = 5528092871638 := by decide
theorem cert_e1130046360534 : check e1130046360534 [[],[.under]] .smaller = true := by decide
def e1130046360538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1130046360538 : Closed e1130046360538 ∧ code e1130046360538 = 5528092871642 := by decide
theorem cert_e1130046360538 : check e1130046360538 [[],[.under]] .smaller = true := by decide
def e1130046360814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1130046360814 : Closed e1130046360814 ∧ code e1130046360814 = 5528092871918 := by decide
theorem cert_e1130046360814 : check e1130046360814 [[],[.under]] .smaller = true := by decide
def e1130046360822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1130046360822 : Closed e1130046360822 ∧ code e1130046360822 = 5528092871926 := by decide
theorem cert_e1130046360822 : check e1130046360822 [[],[.under]] .smaller = true := by decide
def e1130046361198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1130046361198 : Closed e1130046361198 ∧ code e1130046361198 = 5528092872302 := by decide
theorem cert_e1130046361198 : check e1130046361198 [[],[.under]] .smaller = true := by decide
def e1130046361210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1130046361210 : Closed e1130046361210 ∧ code e1130046361210 = 5528092872314 := by decide
theorem cert_e1130046361210 : check e1130046361210 [[],[.under]] .smaller = true := by decide
def e1130046361398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1130046361398 : Closed e1130046361398 ∧ code e1130046361398 = 5528092872502 := by decide
theorem cert_e1130046361398 : check e1130046361398 [[],[.under]] .smaller = true := by decide
def e1130046361402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1130046361402 : Closed e1130046361402 ∧ code e1130046361402 = 5528092872506 := by decide
theorem cert_e1130046361402 : check e1130046361402 [[],[.under]] .smaller = true := by decide
def e1130046369518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1130046369518 : Closed e1130046369518 ∧ code e1130046369518 = 5528092880622 := by decide
theorem cert_e1130046369518 : check e1130046369518 [[],[.under]] .three = true := by decide
def e1130046369646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1130046369646 : Closed e1130046369646 ∧ code e1130046369646 = 5528092880750 := by decide
theorem cert_e1130046369646 : check e1130046369646 [[],[.under]] .three = true := by decide
def e1130046369654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1130046369654 : Closed e1130046369654 ∧ code e1130046369654 = 5528092880758 := by decide
theorem cert_e1130046369654 : check e1130046369654 [[],[.under]] .three = true := by decide
def e1130046372334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1130046372334 : Closed e1130046372334 ∧ code e1130046372334 = 5528092883438 := by decide
theorem cert_e1130046372334 : check e1130046372334 [[],[.under]] .three = true := by decide
def e1130046373102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1130046373102 : Closed e1130046373102 ∧ code e1130046373102 = 5528092884206 := by decide
theorem cert_e1130046373102 : check e1130046373102 [[],[.under]] .three = true := by decide
def e1130046373110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1130046373110 : Closed e1130046373110 ∧ code e1130046373110 = 5528092884214 := by decide
theorem cert_e1130046373110 : check e1130046373110 [[],[.under]] .three = true := by decide
def e1130046396142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1130046396142 : Closed e1130046396142 ∧ code e1130046396142 = 5528092907246 := by decide
theorem cert_e1130046396142 : check e1130046396142 [[],[.under]] .three = true := by decide
def e1130046396334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1130046396334 : Closed e1130046396334 ∧ code e1130046396334 = 5528092907438 := by decide
theorem cert_e1130046396334 : check e1130046396334 [[],[.under]] .three = true := by decide
def e1130046396346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1130046396346 : Closed e1130046396346 ∧ code e1130046396346 = 5528092907450 := by decide
theorem cert_e1130046396346 : check e1130046396346 [[],[.under]] .three = true := by decide
def e1130046396910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1130046396910 : Closed e1130046396910 ∧ code e1130046396910 = 5528092908014 := by decide
theorem cert_e1130046396910 : check e1130046396910 [[],[.under]] .three = true := by decide
def e1130046398062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1130046398062 : Closed e1130046398062 ∧ code e1130046398062 = 5528092909166 := by decide
theorem cert_e1130046398062 : check e1130046398062 [[],[.under]] .three = true := by decide
def e1130046398074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1130046398074 : Closed e1130046398074 ∧ code e1130046398074 = 5528092909178 := by decide
theorem cert_e1130046398074 : check e1130046398074 [[],[.under]] .three = true := by decide
def e1130046409582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1130046409582 : Closed e1130046409582 ∧ code e1130046409582 = 5528092920686 := by decide
theorem cert_e1130046409582 : check e1130046409582 [[],[.under]] .three = true := by decide
def e1130046409590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1130046409590 : Closed e1130046409590 ∧ code e1130046409590 = 5528092920694 := by decide
theorem cert_e1130046409590 : check e1130046409590 [[],[.under]] .three = true := by decide
def e1130046409646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1130046409646 : Closed e1130046409646 ∧ code e1130046409646 = 5528092920750 := by decide
theorem cert_e1130046409646 : check e1130046409646 [[],[.under]] .three = true := by decide
def e1130046409658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1130046409658 : Closed e1130046409658 ∧ code e1130046409658 = 5528092920762 := by decide
theorem cert_e1130046409658 : check e1130046409658 [[],[.under]] .three = true := by decide
def e1130046409686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1130046409686 : Closed e1130046409686 ∧ code e1130046409686 = 5528092920790 := by decide
theorem cert_e1130046409686 : check e1130046409686 [[],[.under]] .three = true := by decide
def e1130046409690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1130046409690 : Closed e1130046409690 ∧ code e1130046409690 = 5528092920794 := by decide
theorem cert_e1130046409690 : check e1130046409690 [[],[.under]] .three = true := by decide
def e1130046409966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1130046409966 : Closed e1130046409966 ∧ code e1130046409966 = 5528092921070 := by decide
theorem cert_e1130046409966 : check e1130046409966 [[],[.under]] .three = true := by decide
def e1130046409974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1130046409974 : Closed e1130046409974 ∧ code e1130046409974 = 5528092921078 := by decide
theorem cert_e1130046409974 : check e1130046409974 [[],[.under]] .three = true := by decide
def e1130046410350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1130046410350 : Closed e1130046410350 ∧ code e1130046410350 = 5528092921454 := by decide
theorem cert_e1130046410350 : check e1130046410350 [[],[.under]] .three = true := by decide
def e1130046410362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1130046410362 : Closed e1130046410362 ∧ code e1130046410362 = 5528092921466 := by decide
theorem cert_e1130046410362 : check e1130046410362 [[],[.under]] .three = true := by decide
def e1130046410550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1130046410550 : Closed e1130046410550 ∧ code e1130046410550 = 5528092921654 := by decide
theorem cert_e1130046410550 : check e1130046410550 [[],[.under]] .three = true := by decide
def e1130046410554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1130046410554 : Closed e1130046410554 ∧ code e1130046410554 = 5528092921658 := by decide
theorem cert_e1130046410554 : check e1130046410554 [[],[.under]] .three = true := by decide
def e1130046950254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1130046950254 : Closed e1130046950254 ∧ code e1130046950254 = 5528093461358 := by decide
theorem cert_e1130046950254 : check e1130046950254 [[],[.under]] .smaller = true := by decide
def e1130046950262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1130046950262 : Closed e1130046950262 ∧ code e1130046950262 = 5528093461366 := by decide
theorem cert_e1130046950262 : check e1130046950262 [[],[.under]] .smaller = true := by decide
def e1130046950318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1130046950318 : Closed e1130046950318 ∧ code e1130046950318 = 5528093461422 := by decide
theorem cert_e1130046950318 : check e1130046950318 [[],[.under]] .smaller = true := by decide
def e1130046950330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1130046950330 : Closed e1130046950330 ∧ code e1130046950330 = 5528093461434 := by decide
theorem cert_e1130046950330 : check e1130046950330 [[],[.under]] .smaller = true := by decide
def e1130046950358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1130046950358 : Closed e1130046950358 ∧ code e1130046950358 = 5528093461462 := by decide
theorem cert_e1130046950358 : check e1130046950358 [[],[.under]] .smaller = true := by decide
def e1130046950362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1130046950362 : Closed e1130046950362 ∧ code e1130046950362 = 5528093461466 := by decide
theorem cert_e1130046950362 : check e1130046950362 [[],[.under]] .smaller = true := by decide
def e1130046950638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1130046950638 : Closed e1130046950638 ∧ code e1130046950638 = 5528093461742 := by decide
theorem cert_e1130046950638 : check e1130046950638 [[],[.under]] .smaller = true := by decide
def e1130046950646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1130046950646 : Closed e1130046950646 ∧ code e1130046950646 = 5528093461750 := by decide
theorem cert_e1130046950646 : check e1130046950646 [[],[.under]] .smaller = true := by decide
def e1130046951022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1130046951022 : Closed e1130046951022 ∧ code e1130046951022 = 5528093462126 := by decide
theorem cert_e1130046951022 : check e1130046951022 [[],[.under]] .smaller = true := by decide
def e1130046951034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1130046951034 : Closed e1130046951034 ∧ code e1130046951034 = 5528093462138 := by decide
theorem cert_e1130046951034 : check e1130046951034 [[],[.under]] .smaller = true := by decide
def e1130046951222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1130046951222 : Closed e1130046951222 ∧ code e1130046951222 = 5528093462326 := by decide
theorem cert_e1130046951222 : check e1130046951222 [[],[.under]] .smaller = true := by decide
def e1130046951226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1130046951226 : Closed e1130046951226 ∧ code e1130046951226 = 5528093462330 := by decide
theorem cert_e1130046951226 : check e1130046951226 [[],[.under]] .smaller = true := by decide
def e1130393690138 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130393690138 : Closed e1130393690138 ∧ code e1130393690138 = 5528440201242 := by decide
theorem cert_e1130393690138 : check e1130393690138 [[]] .width = true := by decide
def e1130393690230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130393690230 : Closed e1130393690230 ∧ code e1130393690230 = 5528440201334 := by decide
theorem cert_e1130393690230 : check e1130393690230 [[]] .width = true := by decide
def e1130393690474 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130393690474 : Closed e1130393690474 ∧ code e1130393690474 = 5528440201578 := by decide
theorem cert_e1130393690474 : check e1130393690474 [[]] .width = true := by decide
def e1130393690522 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130393690522 : Closed e1130393690522 ∧ code e1130393690522 = 5528440201626 := by decide
theorem cert_e1130393690522 : check e1130393690522 [[]] .width = true := by decide
def e1130393722906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130393722906 : Closed e1130393722906 ∧ code e1130393722906 = 5528440234010 := by decide
theorem cert_e1130393722906 : check e1130393722906 [[]] .width = true := by decide
def e1130393722998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130393722998 : Closed e1130393722998 ∧ code e1130393722998 = 5528440234102 := by decide
theorem cert_e1130393722998 : check e1130393722998 [[]] .width = true := by decide
def e1130393723242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130393723242 : Closed e1130393723242 ∧ code e1130393723242 = 5528440234346 := by decide
theorem cert_e1130393723242 : check e1130393723242 [[]] .width = true := by decide
def e1130393723290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130393723290 : Closed e1130393723290 ∧ code e1130393723290 = 5528440234394 := by decide
theorem cert_e1130393723290 : check e1130393723290 [[]] .width = true := by decide
def e1130393952282 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130393952282 : Closed e1130393952282 ∧ code e1130393952282 = 5528440463386 := by decide
theorem cert_e1130393952282 : check e1130393952282 [[]] .width = true := by decide
def e1130393952374 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130393952374 : Closed e1130393952374 ∧ code e1130393952374 = 5528440463478 := by decide
theorem cert_e1130393952374 : check e1130393952374 [[]] .width = true := by decide
def e1130393952618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130393952618 : Closed e1130393952618 ∧ code e1130393952618 = 5528440463722 := by decide
theorem cert_e1130393952618 : check e1130393952618 [[]] .width = true := by decide
def e1130393952666 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130393952666 : Closed e1130393952666 ∧ code e1130393952666 = 5528440463770 := by decide
theorem cert_e1130393952666 : check e1130393952666 [[]] .width = true := by decide
def e1130394001434 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130394001434 : Closed e1130394001434 ∧ code e1130394001434 = 5528440512538 := by decide
theorem cert_e1130394001434 : check e1130394001434 [[]] .width = true := by decide
def e1130394001526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130394001526 : Closed e1130394001526 ∧ code e1130394001526 = 5528440512630 := by decide
theorem cert_e1130394001526 : check e1130394001526 [[]] .width = true := by decide
def e1130394001770 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130394001770 : Closed e1130394001770 ∧ code e1130394001770 = 5528440512874 := by decide
theorem cert_e1130394001770 : check e1130394001770 [[]] .width = true := by decide
def e1130394001818 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130394001818 : Closed e1130394001818 ∧ code e1130394001818 = 5528440512922 := by decide
theorem cert_e1130394001818 : check e1130394001818 [[]] .width = true := by decide
def e1130394116122 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130394116122 : Closed e1130394116122 ∧ code e1130394116122 = 5528440627226 := by decide
theorem cert_e1130394116122 : check e1130394116122 [[]] .width = true := by decide
def e1130394116214 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130394116214 : Closed e1130394116214 ∧ code e1130394116214 = 5528440627318 := by decide
theorem cert_e1130394116214 : check e1130394116214 [[]] .width = true := by decide
def e1130394116458 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130394116458 : Closed e1130394116458 ∧ code e1130394116458 = 5528440627562 := by decide
theorem cert_e1130394116458 : check e1130394116458 [[]] .width = true := by decide
def e1130394116506 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130394116506 : Closed e1130394116506 ∧ code e1130394116506 = 5528440627610 := by decide
theorem cert_e1130394116506 : check e1130394116506 [[]] .width = true := by decide
def e1130394132506 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130394132506 : Closed e1130394132506 ∧ code e1130394132506 = 5528440643610 := by decide
theorem cert_e1130394132506 : check e1130394132506 [[]] .width = true := by decide
def e1130394132598 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130394132598 : Closed e1130394132598 ∧ code e1130394132598 = 5528440643702 := by decide
theorem cert_e1130394132598 : check e1130394132598 [[]] .width = true := by decide
def e1130394132842 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130394132842 : Closed e1130394132842 ∧ code e1130394132842 = 5528440643946 := by decide
theorem cert_e1130394132842 : check e1130394132842 [[]] .width = true := by decide
def e1130394132890 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130394132890 : Closed e1130394132890 ∧ code e1130394132890 = 5528440643994 := by decide
theorem cert_e1130394132890 : check e1130394132890 [[]] .width = true := by decide
def e1130395263002 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130395263002 : Closed e1130395263002 ∧ code e1130395263002 = 5528441774106 := by decide
theorem cert_e1130395263002 : check e1130395263002 [[]] .width = true := by decide
def e1130395263094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130395263094 : Closed e1130395263094 ∧ code e1130395263094 = 5528441774198 := by decide
theorem cert_e1130395263094 : check e1130395263094 [[]] .width = true := by decide
def e1130395263338 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130395263338 : Closed e1130395263338 ∧ code e1130395263338 = 5528441774442 := by decide
theorem cert_e1130395263338 : check e1130395263338 [[]] .width = true := by decide
def e1130395263386 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130395263386 : Closed e1130395263386 ∧ code e1130395263386 = 5528441774490 := by decide
theorem cert_e1130395263386 : check e1130395263386 [[]] .width = true := by decide
def e1130395295770 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130395295770 : Closed e1130395295770 ∧ code e1130395295770 = 5528441806874 := by decide
theorem cert_e1130395295770 : check e1130395295770 [[]] .width = true := by decide
def e1130395295862 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130395295862 : Closed e1130395295862 ∧ code e1130395295862 = 5528441806966 := by decide
theorem cert_e1130395295862 : check e1130395295862 [[]] .width = true := by decide
def e1130395296106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130395296106 : Closed e1130395296106 ∧ code e1130395296106 = 5528441807210 := by decide
theorem cert_e1130395296106 : check e1130395296106 [[]] .width = true := by decide
def e1130395296154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130395296154 : Closed e1130395296154 ∧ code e1130395296154 = 5528441807258 := by decide
theorem cert_e1130395296154 : check e1130395296154 [[]] .width = true := by decide
def e1130396835866 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130396835866 : Closed e1130396835866 ∧ code e1130396835866 = 5528443346970 := by decide
theorem cert_e1130396835866 : check e1130396835866 [[]] .width = true := by decide
def e1130396835958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130396835958 : Closed e1130396835958 ∧ code e1130396835958 = 5528443347062 := by decide
theorem cert_e1130396835958 : check e1130396835958 [[]] .width = true := by decide
def e1130396836202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130396836202 : Closed e1130396836202 ∧ code e1130396836202 = 5528443347306 := by decide
theorem cert_e1130396836202 : check e1130396836202 [[]] .width = true := by decide
def e1130396836250 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130396836250 : Closed e1130396836250 ∧ code e1130396836250 = 5528443347354 := by decide
theorem cert_e1130396836250 : check e1130396836250 [[]] .width = true := by decide
def e1130396885018 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130396885018 : Closed e1130396885018 ∧ code e1130396885018 = 5528443396122 := by decide
theorem cert_e1130396885018 : check e1130396885018 [[]] .width = true := by decide
def e1130396885110 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130396885110 : Closed e1130396885110 ∧ code e1130396885110 = 5528443396214 := by decide
theorem cert_e1130396885110 : check e1130396885110 [[]] .width = true := by decide
def e1130396885354 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130396885354 : Closed e1130396885354 ∧ code e1130396885354 = 5528443396458 := by decide
theorem cert_e1130396885354 : check e1130396885354 [[]] .width = true := by decide
def e1130396885402 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130396885402 : Closed e1130396885402 ∧ code e1130396885402 = 5528443396506 := by decide
theorem cert_e1130396885402 : check e1130396885402 [[]] .width = true := by decide
def e1130397655066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130397655066 : Closed e1130397655066 ∧ code e1130397655066 = 5528444166170 := by decide
theorem cert_e1130397655066 : check e1130397655066 [[]] .width = true := by decide
def e1130397655158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130397655158 : Closed e1130397655158 ∧ code e1130397655158 = 5528444166262 := by decide
theorem cert_e1130397655158 : check e1130397655158 [[]] .width = true := by decide
def e1130397655402 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130397655402 : Closed e1130397655402 ∧ code e1130397655402 = 5528444166506 := by decide
theorem cert_e1130397655402 : check e1130397655402 [[]] .width = true := by decide
def e1130397655450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130397655450 : Closed e1130397655450 ∧ code e1130397655450 = 5528444166554 := by decide
theorem cert_e1130397655450 : check e1130397655450 [[]] .width = true := by decide
def e1130397671450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1130397671450 : Closed e1130397671450 ∧ code e1130397671450 = 5528444182554 := by decide
theorem cert_e1130397671450 : check e1130397671450 [[]] .width = true := by decide
def e1130397671542 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1130397671542 : Closed e1130397671542 ∧ code e1130397671542 = 5528444182646 := by decide
theorem cert_e1130397671542 : check e1130397671542 [[]] .width = true := by decide
def e1130397671786 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1130397671786 : Closed e1130397671786 ∧ code e1130397671786 = 5528444182890 := by decide
theorem cert_e1130397671786 : check e1130397671786 [[]] .width = true := by decide
def e1130397671834 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1130397671834 : Closed e1130397671834 ∧ code e1130397671834 = 5528444182938 := by decide
theorem cert_e1130397671834 : check e1130397671834 [[]] .width = true := by decide
def e1130482457454 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1130482457454 : Closed e1130482457454 ∧ code e1130482457454 = 5528528968558 := by decide
theorem cert_e1130482457454 : check e1130482457454 [[],[.under]] .three = true := by decide
def e1130482457462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1130482457462 : Closed e1130482457462 ∧ code e1130482457462 = 5528528968566 := by decide
theorem cert_e1130482457462 : check e1130482457462 [[],[.under]] .three = true := by decide
def e1130482457526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1130482457526 : Closed e1130482457526 ∧ code e1130482457526 = 5528528968630 := by decide
theorem cert_e1130482457526 : check e1130482457526 [[],[.under]] .three = true := by decide
def e1130482457966 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1130482457966 : Closed e1130482457966 ∧ code e1130482457966 = 5528528969070 := by decide
theorem cert_e1130482457966 : check e1130482457966 [[],[.under]] .three = true := by decide
def e1130482457974 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1130482457974 : Closed e1130482457974 ∧ code e1130482457974 = 5528528969078 := by decide
theorem cert_e1130482457974 : check e1130482457974 [[],[.under]] .three = true := by decide
def e1130482458030 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1130482458030 : Closed e1130482458030 ∧ code e1130482458030 = 5528528969134 := by decide
theorem cert_e1130482458030 : check e1130482458030 [[],[.under]] .three = true := by decide
def e1130482458042 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1130482458042 : Closed e1130482458042 ∧ code e1130482458042 = 5528528969146 := by decide
theorem cert_e1130482458042 : check e1130482458042 [[],[.under]] .three = true := by decide
def e1130482458070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1130482458070 : Closed e1130482458070 ∧ code e1130482458070 = 5528528969174 := by decide
theorem cert_e1130482458070 : check e1130482458070 [[],[.under]] .three = true := by decide
def e1130482458074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1130482458074 : Closed e1130482458074 ∧ code e1130482458074 = 5528528969178 := by decide
theorem cert_e1130482458074 : check e1130482458074 [[],[.under]] .three = true := by decide
def e1130482458294 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1130482458294 : Closed e1130482458294 ∧ code e1130482458294 = 5528528969398 := by decide
theorem cert_e1130482458294 : check e1130482458294 [[],[.under]] .three = true := by decide
def e1130482458326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1130482458326 : Closed e1130482458326 ∧ code e1130482458326 = 5528528969430 := by decide
theorem cert_e1130482458326 : check e1130482458326 [[],[.under]] .three = true := by decide
def e1130482458330 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1130482458330 : Closed e1130482458330 ∧ code e1130482458330 = 5528528969434 := by decide
theorem cert_e1130482458330 : check e1130482458330 [[],[.under]] .three = true := by decide
def e1130482460526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1130482460526 : Closed e1130482460526 ∧ code e1130482460526 = 5528528971630 := by decide
theorem cert_e1130482460526 : check e1130482460526 [[],[.under]] .three = true := by decide
def e1130482460534 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1130482460534 : Closed e1130482460534 ∧ code e1130482460534 = 5528528971638 := by decide
theorem cert_e1130482460534 : check e1130482460534 [[],[.under]] .three = true := by decide
def e1130482460598 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1130482460598 : Closed e1130482460598 ∧ code e1130482460598 = 5528528971702 := by decide
theorem cert_e1130482460598 : check e1130482460598 [[],[.under]] .three = true := by decide
def e1130482461934 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130482461934 : Closed e1130482461934 ∧ code e1130482461934 = 5528528973038 := by decide
theorem cert_e1130482461934 : check e1130482461934 [[],[.under]] .three = true := by decide
def e1130482461942 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130482461942 : Closed e1130482461942 ∧ code e1130482461942 = 5528528973046 := by decide
theorem cert_e1130482461942 : check e1130482461942 [[],[.under]] .three = true := by decide
def e1130482462326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1130482462326 : Closed e1130482462326 ∧ code e1130482462326 = 5528528973430 := by decide
theorem cert_e1130482462326 : check e1130482462326 [[],[.under]] .three = true := by decide
def e1130482463598 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1130482463598 : Closed e1130482463598 ∧ code e1130482463598 = 5528528974702 := by decide
theorem cert_e1130482463598 : check e1130482463598 [[],[.under]] .three = true := by decide
def e1130482463606 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1130482463606 : Closed e1130482463606 ∧ code e1130482463606 = 5528528974710 := by decide
theorem cert_e1130482463606 : check e1130482463606 [[],[.under]] .three = true := by decide
def e1130482463662 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1130482463662 : Closed e1130482463662 ∧ code e1130482463662 = 5528528974766 := by decide
theorem cert_e1130482463662 : check e1130482463662 [[],[.under]] .three = true := by decide
def e1130482463674 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1130482463674 : Closed e1130482463674 ∧ code e1130482463674 = 5528528974778 := by decide
theorem cert_e1130482463674 : check e1130482463674 [[],[.under]] .three = true := by decide
def e1130482463702 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1130482463702 : Closed e1130482463702 ∧ code e1130482463702 = 5528528974806 := by decide
theorem cert_e1130482463702 : check e1130482463702 [[],[.under]] .three = true := by decide
def e1130482463706 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1130482463706 : Closed e1130482463706 ∧ code e1130482463706 = 5528528974810 := by decide
theorem cert_e1130482463706 : check e1130482463706 [[],[.under]] .three = true := by decide
def e1130482463982 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1130482463982 : Closed e1130482463982 ∧ code e1130482463982 = 5528528975086 := by decide
theorem cert_e1130482463982 : check e1130482463982 [[],[.under]] .three = true := by decide
def e1130482463990 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1130482463990 : Closed e1130482463990 ∧ code e1130482463990 = 5528528975094 := by decide
theorem cert_e1130482463990 : check e1130482463990 [[],[.under]] .three = true := by decide
end Blc.Floor42
