import Tables
import Batch062
namespace Blc.Floor42.Grades062
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1192558530158 : ¬ IsSelfInterpreter e1192558530158 := cutM1_2 (by decide)
#print axioms ex_e1192558530158
theorem ex_e1192558530170 : ¬ IsSelfInterpreter e1192558530170 := cutM1_2 (by decide)
#print axioms ex_e1192558530170
theorem ex_e1192558157230 : ¬ IsSelfInterpreter e1192558157230 := cutM4_1 (by decide)
#print axioms ex_e1192558157230
theorem ex_e1192558163566 : ¬ IsSelfInterpreter e1192558163566 := cutM4_1 (by decide)
#print axioms ex_e1192558163566
theorem ex_e1192558163578 : ¬ IsSelfInterpreter e1192558163578 := cutM4_1 (by decide)
#print axioms ex_e1192558163578
theorem ex_e1192558156654 : ¬ IsSelfInterpreter e1192558156654 := cutM5_2 (by decide)
#print axioms ex_e1192558156654
theorem ex_e1192558156662 : ¬ IsSelfInterpreter e1192558156662 := cutM5_2 (by decide)
#print axioms ex_e1192558156662
theorem ex_e1192558156726 : ¬ IsSelfInterpreter e1192558156726 := cutM5_2 (by decide)
#print axioms ex_e1192558156726
theorem ex_e1192558157166 : ¬ IsSelfInterpreter e1192558157166 := cutM6_2 (by decide)
#print axioms ex_e1192558157166
theorem ex_e1192558157174 : ¬ IsSelfInterpreter e1192558157174 := cutM6_2 (by decide)
#print axioms ex_e1192558157174
theorem ex_e1192558157270 : ¬ IsSelfInterpreter e1192558157270 := cutM6_2 (by decide)
#print axioms ex_e1192558157270
theorem ex_e1192558157494 : ¬ IsSelfInterpreter e1192558157494 := cutM6_2 (by decide)
#print axioms ex_e1192558157494
theorem ex_e1192558157526 : ¬ IsSelfInterpreter e1192558157526 := cutM6_2 (by decide)
#print axioms ex_e1192558157526
theorem ex_e1192558529390 : ¬ IsSelfInterpreter e1192558529390 := cutM6_2 (by decide)
#print axioms ex_e1192558529390
theorem ex_e1192558530358 : ¬ IsSelfInterpreter e1192558530358 := cutM10_0 (by decide)
#print axioms ex_e1192558530358
theorem ex_e1131212301750 : ¬ IsSelfInterpreter e1131212301750 := cutM13_0 (by decide)
#print axioms ex_e1131212301750
theorem ex_e1131212301942 : ¬ IsSelfInterpreter e1131212301942 := cutM13_0 (by decide)
#print axioms ex_e1131212301942
end Blc.Floor42.Grades062
