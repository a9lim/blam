import Batch081
import ExtraBase
namespace Blc.Floor42.Extra081
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1196692647786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem ex_e1196692647786 : ¬ IsSelfInterpreter e1196692647786 := by
  intro he
  have hp := replay_sound (t := e1196692647786) (u := t_e1196692647786) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692647786
private def t_e1196692651418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem ex_e1196692651418 : ¬ IsSelfInterpreter e1196692651418 := by
  intro he
  have hp := replay_sound (t := e1196692651418) (u := t_e1196692651418) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.app (.var 0) (.var 0)))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.app (SO.var 0) (SO.var 0))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692651418
private def t_e1196692655034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem ex_e1196692655034 : ¬ IsSelfInterpreter e1196692655034 := by
  intro he
  have hp := replay_sound (t := e1196692655034) (u := t_e1196692655034) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 1) (.var 0)))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692655034
private def t_e1196692655066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem ex_e1196692655066 : ¬ IsSelfInterpreter e1196692655066 := by
  intro he
  have hp := replay_sound (t := e1196692655066) (u := t_e1196692655066) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 1) (.var 0)))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692655066
private def t_e1196692655342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem ex_e1196692655342 : ¬ IsSelfInterpreter e1196692655342 := by
  intro he
  have hp := replay_sound (t := e1196692655342) (u := t_e1196692655342) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.var 1)))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2)))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692655342
private def t_e1196692655350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem ex_e1196692655350 : ¬ IsSelfInterpreter e1196692655350 := by
  intro he
  have hp := replay_sound (t := e1196692655350) (u := t_e1196692655350) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.app (.var 0) (.var 1)))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1)))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692655350
private def t_e1196692802490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem ex_e1196692802490 : ¬ IsSelfInterpreter e1196692802490 := by
  intro he
  have hp := replay_sound (t := e1196692802490) (u := t_e1196692802490) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl)))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692802490
private def t_e1196692802522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem ex_e1196692802522 : ¬ IsSelfInterpreter e1196692802522 := by
  intro he
  have hp := replay_sound (t := e1196692802522) (u := t_e1196692802522) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl)))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1196692802522
private def t_e1196692803386 : Term := (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))) (.var 0))))
theorem ex_e1196692803386 : ¬ IsSelfInterpreter e1196692803386 := by
  intro he
  have hp := replay_sound (t := (call e1196692803386 (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := t_e1196692803386) (ps := [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.right,.right,.under,.right],[.left,.left],[.left],[.left,.right],[.left,.left],[.left],[.left,.right],[.left],[.left,.right,.under],[.left,.right,.under,.right,.under],[.left],[],[.right],[.right,.left],[.right,.left,.right],[.right,.left,.right,.left],[.right,.left,.right],[],[.left,.left],[.left,.left],[.left],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := (.lam (.var 0))) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := Layouts.mismatch_sound 12 hr (by decide)
  exact (by decide : ¬ Layouts.mismatch 12 t_e1196692803386 (.lam (.var 0)) = false) hz
#print axioms ex_e1196692803386
end Blc.Floor42.Extra081
