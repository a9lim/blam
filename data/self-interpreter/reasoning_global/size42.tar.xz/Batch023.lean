import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e378048272410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048272410 : Closed e378048272410 ∧ code e378048272410 = 4776094783514 := by decide
theorem cert_e378048272410 : check e378048272410 [] .sourceHead = true := by decide
def e378048458266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048458266 : Closed e378048458266 ∧ code e378048458266 = 4776094969370 := by decide
theorem cert_e378048458266 : check e378048458266 [] .sourceHead = true := by decide
def e378048461338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048461338 : Closed e378048461338 ∧ code e378048461338 = 4776094972442 := by decide
theorem cert_e378048461338 : check e378048461338 [] .sourceHead = true := by decide
def e378048473626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048473626 : Closed e378048473626 ∧ code e378048473626 = 4776094984730 := by decide
theorem cert_e378048473626 : check e378048473626 [] .sourceHead = true := by decide
def e378048638490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048638490 : Closed e378048638490 ∧ code e378048638490 = 4776095149594 := by decide
theorem cert_e378048638490 : check e378048638490 [] .sourceHead = true := by decide
def e378048641562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048641562 : Closed e378048641562 ∧ code e378048641562 = 4776095152666 := by decide
theorem cert_e378048641562 : check e378048641562 [] .sourceHead = true := by decide
def e378048683546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048683546 : Closed e378048683546 ∧ code e378048683546 = 4776095194650 := by decide
theorem cert_e378048683546 : check e378048683546 [] .sourceHead = true := by decide
def e378048704710 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048704710 : Closed e378048704710 ∧ code e378048704710 = 4776095215814 := by decide
theorem cert_e378048704710 : check e378048704710 [] .sourceHead = true := by decide
def e378048722970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048722970 : Closed e378048722970 ∧ code e378048722970 = 4776095234074 := by decide
theorem cert_e378048722970 : check e378048722970 [] .sourceHead = true := by decide
def e378048726554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048726554 : Closed e378048726554 ∧ code e378048726554 = 4776095237658 := by decide
theorem cert_e378048726554 : check e378048726554 [] .sourceHead = true := by decide
def e378048729286 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048729286 : Closed e378048729286 ∧ code e378048729286 = 4776095240390 := by decide
theorem cert_e378048729286 : check e378048729286 [] .sourceHead = true := by decide
def e378048731162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048731162 : Closed e378048731162 ∧ code e378048731162 = 4776095242266 := by decide
theorem cert_e378048731162 : check e378048731162 [] .sourceHead = true := by decide
def e378048788506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048788506 : Closed e378048788506 ∧ code e378048788506 = 4776095299610 := by decide
theorem cert_e378048788506 : check e378048788506 [] .sourceHead = true := by decide
def e378048800794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048800794 : Closed e378048800794 ∧ code e378048800794 = 4776095311898 := by decide
theorem cert_e378048800794 : check e378048800794 [] .sourceHead = true := by decide
def e378048813594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048813594 : Closed e378048813594 ∧ code e378048813594 = 4776095324698 := by decide
theorem cert_e378048813594 : check e378048813594 [] .sourceHead = true := by decide
def e378048824858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048824858 : Closed e378048824858 ∧ code e378048824858 = 4776095335962 := by decide
theorem cert_e378048824858 : check e378048824858 [] .sourceHead = true := by decide
def e378048827590 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048827590 : Closed e378048827590 ∧ code e378048827590 = 4776095338694 := by decide
theorem cert_e378048827590 : check e378048827590 [] .sourceHead = true := by decide
def e378048829466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048829466 : Closed e378048829466 ∧ code e378048829466 = 4776095340570 := by decide
theorem cert_e378048829466 : check e378048829466 [] .sourceHead = true := by decide
def e378048833562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048833562 : Closed e378048833562 ∧ code e378048833562 = 4776095344666 := by decide
theorem cert_e378048833562 : check e378048833562 [] .sourceHead = true := by decide
def e378048927258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048927258 : Closed e378048927258 ∧ code e378048927258 = 4776095438362 := by decide
theorem cert_e378048927258 : check e378048927258 [] .sourceHead = true := by decide
def e378048928282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048928282 : Closed e378048928282 ∧ code e378048928282 = 4776095439386 := by decide
theorem cert_e378048928282 : check e378048928282 [] .sourceHead = true := by decide
def e378048932378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048932378 : Closed e378048932378 ∧ code e378048932378 = 4776095443482 := by decide
theorem cert_e378048932378 : check e378048932378 [] .sourceHead = true := by decide
def e378049017370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378049017370 : Closed e378049017370 ∧ code e378049017370 = 4776095528474 := by decide
theorem cert_e378049017370 : check e378049017370 [] .sourceHead = true := by decide
def e378049018394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378049018394 : Closed e378049018394 ∧ code e378049018394 = 4776095529498 := by decide
theorem cert_e378049018394 : check e378049018394 [] .sourceHead = true := by decide
def e378049039898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378049039898 : Closed e378049039898 ∧ code e378049039898 = 4776095551002 := by decide
theorem cert_e378049039898 : check e378049039898 [] .sourceHead = true := by decide
def e378049048774 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378049048774 : Closed e378049048774 ∧ code e378049048774 = 4776095559878 := by decide
theorem cert_e378049048774 : check e378049048774 [] .sourceHead = true := by decide
def e378049054234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378049054234 : Closed e378049054234 ∧ code e378049054234 = 4776095565338 := by decide
theorem cert_e378049054234 : check e378049054234 [] .sourceHead = true := by decide
def e378049056966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378049056966 : Closed e378049056966 ∧ code e378049056966 = 4776095568070 := by decide
theorem cert_e378049056966 : check e378049056966 [] .sourceHead = true := by decide
def e378049058842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378049058842 : Closed e378049058842 ∧ code e378049058842 = 4776095569946 := by decide
theorem cert_e378049058842 : check e378049058842 [] .sourceHead = true := by decide
def e378049075738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378049075738 : Closed e378049075738 ∧ code e378049075738 = 4776095586842 := by decide
theorem cert_e378049075738 : check e378049075738 [] .sourceHead = true := by decide
def e378049087002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378049087002 : Closed e378049087002 ∧ code e378049087002 = 4776095598106 := by decide
theorem cert_e378049087002 : check e378049087002 [] .sourceHead = true := by decide
def e378049089734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378049089734 : Closed e378049089734 ∧ code e378049089734 = 4776095600838 := by decide
theorem cert_e378049089734 : check e378049089734 [] .sourceHead = true := by decide
def e378049091610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378049091610 : Closed e378049091610 ∧ code e378049091610 = 4776095602714 := by decide
theorem cert_e378049091610 : check e378049091610 [] .sourceHead = true := by decide
def e378049095706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378049095706 : Closed e378049095706 ∧ code e378049095706 = 4776095606810 := by decide
theorem cert_e378049095706 : check e378049095706 [] .sourceHead = true := by decide
def e378050244122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378050244122 : Closed e378050244122 ∧ code e378050244122 = 4776096755226 := by decide
theorem cert_e378050244122 : check e378050244122 [] .sourceHead = true := by decide
def e378050246170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378050246170 : Closed e378050246170 ∧ code e378050246170 = 4776096757274 := by decide
theorem cert_e378050246170 : check e378050246170 [] .sourceHead = true := by decide
def e378050342426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378050342426 : Closed e378050342426 ∧ code e378050342426 = 4776096853530 := by decide
theorem cert_e378050342426 : check e378050342426 [] .sourceHead = true := by decide
def e378050345498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378050345498 : Closed e378050345498 ∧ code e378050345498 = 4776096856602 := by decide
theorem cert_e378050345498 : check e378050345498 [] .sourceHead = true := by decide
def e378050393626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378050393626 : Closed e378050393626 ∧ code e378050393626 = 4776096904730 := by decide
theorem cert_e378050393626 : check e378050393626 [] .sourceHead = true := by decide
def e378050394650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378050394650 : Closed e378050394650 ∧ code e378050394650 = 4776096905754 := by decide
theorem cert_e378050394650 : check e378050394650 [] .sourceHead = true := by decide
def e378051030554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051030554 : Closed e378051030554 ∧ code e378051030554 = 4776097541658 := by decide
theorem cert_e378051030554 : check e378051030554 [] .sourceHead = true := by decide
def e378051032602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051032602 : Closed e378051032602 ∧ code e378051032602 = 4776097543706 := by decide
theorem cert_e378051032602 : check e378051032602 [] .sourceHead = true := by decide
def e378051173914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051173914 : Closed e378051173914 ∧ code e378051173914 = 4776097685018 := by decide
theorem cert_e378051173914 : check e378051173914 [] .sourceHead = true := by decide
def e378051195078 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051195078 : Closed e378051195078 ∧ code e378051195078 = 4776097706182 := by decide
theorem cert_e378051195078 : check e378051195078 [] .sourceHead = true := by decide
def e378051202586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051202586 : Closed e378051202586 ∧ code e378051202586 = 4776097713690 := by decide
theorem cert_e378051202586 : check e378051202586 [] .sourceHead = true := by decide
def e378051211462 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051211462 : Closed e378051211462 ∧ code e378051211462 = 4776097722566 := by decide
theorem cert_e378051211462 : check e378051211462 [] .sourceHead = true := by decide
def e378051259930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051259930 : Closed e378051259930 ∧ code e378051259930 = 4776097771034 := by decide
theorem cert_e378051259930 : check e378051259930 [] .sourceHead = true := by decide
def e378051263002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051263002 : Closed e378051263002 ∧ code e378051263002 = 4776097774106 := by decide
theorem cert_e378051263002 : check e378051263002 [] .sourceHead = true := by decide
def e378051304986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051304986 : Closed e378051304986 ∧ code e378051304986 = 4776097816090 := by decide
theorem cert_e378051304986 : check e378051304986 [] .sourceHead = true := by decide
def e378051326150 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051326150 : Closed e378051326150 ∧ code e378051326150 = 4776097837254 := by decide
theorem cert_e378051326150 : check e378051326150 [] .sourceHead = true := by decide
def e378051344410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378051344410 : Closed e378051344410 ∧ code e378051344410 = 4776097855514 := by decide
theorem cert_e378051344410 : check e378051344410 [] .sourceHead = true := by decide
def e378051347994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051347994 : Closed e378051347994 ∧ code e378051347994 = 4776097859098 := by decide
theorem cert_e378051347994 : check e378051347994 [] .sourceHead = true := by decide
def e378051350726 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051350726 : Closed e378051350726 ∧ code e378051350726 = 4776097861830 := by decide
theorem cert_e378051350726 : check e378051350726 [] .sourceHead = true := by decide
def e378051352602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378051352602 : Closed e378051352602 ∧ code e378051352602 = 4776097863706 := by decide
theorem cert_e378051352602 : check e378051352602 [] .sourceHead = true := by decide
def e378051376666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051376666 : Closed e378051376666 ∧ code e378051376666 = 4776097887770 := by decide
theorem cert_e378051376666 : check e378051376666 [] .sourceHead = true := by decide
def e378051377690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051377690 : Closed e378051377690 ∧ code e378051377690 = 4776097888794 := by decide
theorem cert_e378051377690 : check e378051377690 [] .sourceHead = true := by decide
def e378051399194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051399194 : Closed e378051399194 ∧ code e378051399194 = 4776097910298 := by decide
theorem cert_e378051399194 : check e378051399194 [] .sourceHead = true := by decide
def e378051408070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051408070 : Closed e378051408070 ∧ code e378051408070 = 4776097919174 := by decide
theorem cert_e378051408070 : check e378051408070 [] .sourceHead = true := by decide
def e378051413530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051413530 : Closed e378051413530 ∧ code e378051413530 = 4776097924634 := by decide
theorem cert_e378051413530 : check e378051413530 [] .sourceHead = true := by decide
def e378051416262 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051416262 : Closed e378051416262 ∧ code e378051416262 = 4776097927366 := by decide
theorem cert_e378051416262 : check e378051416262 [] .sourceHead = true := by decide
def e378051418138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378051418138 : Closed e378051418138 ∧ code e378051418138 = 4776097929242 := by decide
theorem cert_e378051418138 : check e378051418138 [] .sourceHead = true := by decide
def e378051960346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051960346 : Closed e378051960346 ∧ code e378051960346 = 4776098471450 := by decide
theorem cert_e378051960346 : check e378051960346 [] .sourceHead = true := by decide
def e378051981510 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051981510 : Closed e378051981510 ∧ code e378051981510 = 4776098492614 := by decide
theorem cert_e378051981510 : check e378051981510 [] .sourceHead = true := by decide
def e378051989018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378051989018 : Closed e378051989018 ∧ code e378051989018 = 4776098500122 := by decide
theorem cert_e378051989018 : check e378051989018 [] .sourceHead = true := by decide
def e378051997894 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378051997894 : Closed e378051997894 ∧ code e378051997894 = 4776098508998 := by decide
theorem cert_e378051997894 : check e378051997894 [] .sourceHead = true := by decide
def e378052746778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378052746778 : Closed e378052746778 ∧ code e378052746778 = 4776099257882 := by decide
theorem cert_e378052746778 : check e378052746778 [] .sourceHead = true := by decide
def e378052767942 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378052767942 : Closed e378052767942 ∧ code e378052767942 = 4776099279046 := by decide
theorem cert_e378052767942 : check e378052767942 [] .sourceHead = true := by decide
def e378052786202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378052786202 : Closed e378052786202 ∧ code e378052786202 = 4776099297306 := by decide
theorem cert_e378052786202 : check e378052786202 [] .sourceHead = true := by decide
def e378052789786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378052789786 : Closed e378052789786 ∧ code e378052789786 = 4776099300890 := by decide
theorem cert_e378052789786 : check e378052789786 [] .sourceHead = true := by decide
def e378052792518 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378052792518 : Closed e378052792518 ∧ code e378052792518 = 4776099303622 := by decide
theorem cert_e378052792518 : check e378052792518 [] .sourceHead = true := by decide
def e378052794394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378052794394 : Closed e378052794394 ∧ code e378052794394 = 4776099305498 := by decide
theorem cert_e378052794394 : check e378052794394 [] .sourceHead = true := by decide
def e378053168666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378053168666 : Closed e378053168666 ∧ code e378053168666 = 4776099679770 := by decide
theorem cert_e378053168666 : check e378053168666 [] .sourceHead = true := by decide
def e378053177542 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378053177542 : Closed e378053177542 ∧ code e378053177542 = 4776099688646 := by decide
theorem cert_e378053177542 : check e378053177542 [] .sourceHead = true := by decide
def e378053183002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378053183002 : Closed e378053183002 ∧ code e378053183002 = 4776099694106 := by decide
theorem cert_e378053183002 : check e378053183002 [] .sourceHead = true := by decide
def e378053185734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378053185734 : Closed e378053185734 ∧ code e378053185734 = 4776099696838 := by decide
theorem cert_e378053185734 : check e378053185734 [] .sourceHead = true := by decide
def e378053187610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378053187610 : Closed e378053187610 ∧ code e378053187610 = 4776099698714 := by decide
theorem cert_e378053187610 : check e378053187610 [] .sourceHead = true := by decide
def e378054012442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054012442 : Closed e378054012442 ∧ code e378054012442 = 4776100523546 := by decide
theorem cert_e378054012442 : check e378054012442 [] .sourceHead = true := by decide
def e378054015514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054015514 : Closed e378054015514 ∧ code e378054015514 = 4776100526618 := by decide
theorem cert_e378054015514 : check e378054015514 [] .sourceHead = true := by decide
def e378054089242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054089242 : Closed e378054089242 ∧ code e378054089242 = 4776100600346 := by decide
theorem cert_e378054089242 : check e378054089242 [] .sourceHead = true := by decide
def e378054405658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054405658 : Closed e378054405658 ∧ code e378054405658 = 4776100916762 := by decide
theorem cert_e378054405658 : check e378054405658 [] .sourceHead = true := by decide
def e378054408730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054408730 : Closed e378054408730 ∧ code e378054408730 = 4776100919834 := by decide
theorem cert_e378054408730 : check e378054408730 [] .sourceHead = true := by decide
def e378054450714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054450714 : Closed e378054450714 ∧ code e378054450714 = 4776100961818 := by decide
theorem cert_e378054450714 : check e378054450714 [] .sourceHead = true := by decide
def e378054471878 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378054471878 : Closed e378054471878 ∧ code e378054471878 = 4776100982982 := by decide
theorem cert_e378054471878 : check e378054471878 [] .sourceHead = true := by decide
def e378054490138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054490138 : Closed e378054490138 ∧ code e378054490138 = 4776101001242 := by decide
theorem cert_e378054490138 : check e378054490138 [] .sourceHead = true := by decide
def e378054493722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054493722 : Closed e378054493722 ∧ code e378054493722 = 4776101004826 := by decide
theorem cert_e378054493722 : check e378054493722 [] .sourceHead = true := by decide
def e378054496454 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378054496454 : Closed e378054496454 ∧ code e378054496454 = 4776101007558 := by decide
theorem cert_e378054496454 : check e378054496454 [] .sourceHead = true := by decide
def e378054498330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054498330 : Closed e378054498330 ∧ code e378054498330 = 4776101009434 := by decide
theorem cert_e378054498330 : check e378054498330 [] .sourceHead = true := by decide
def e378054555674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054555674 : Closed e378054555674 ∧ code e378054555674 = 4776101066778 := by decide
theorem cert_e378054555674 : check e378054555674 [] .sourceHead = true := by decide
def e378054567962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054567962 : Closed e378054567962 ∧ code e378054567962 = 4776101079066 := by decide
theorem cert_e378054567962 : check e378054567962 [] .sourceHead = true := by decide
def e378054580762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054580762 : Closed e378054580762 ∧ code e378054580762 = 4776101091866 := by decide
theorem cert_e378054580762 : check e378054580762 [] .sourceHead = true := by decide
def e378054592026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054592026 : Closed e378054592026 ∧ code e378054592026 = 4776101103130 := by decide
theorem cert_e378054592026 : check e378054592026 [] .sourceHead = true := by decide
def e378054594758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378054594758 : Closed e378054594758 ∧ code e378054594758 = 4776101105862 := by decide
theorem cert_e378054594758 : check e378054594758 [] .sourceHead = true := by decide
def e378054596634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054596634 : Closed e378054596634 ∧ code e378054596634 = 4776101107738 := by decide
theorem cert_e378054596634 : check e378054596634 [] .sourceHead = true := by decide
def e378054600730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054600730 : Closed e378054600730 ∧ code e378054600730 = 4776101111834 := by decide
theorem cert_e378054600730 : check e378054600730 [] .sourceHead = true := by decide
def e378054843930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054843930 : Closed e378054843930 ∧ code e378054843930 = 4776101355034 := by decide
theorem cert_e378054843930 : check e378054843930 [] .sourceHead = true := by decide
def e378054865094 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378054865094 : Closed e378054865094 ∧ code e378054865094 = 4776101376198 := by decide
theorem cert_e378054865094 : check e378054865094 [] .sourceHead = true := by decide
def e378054883354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054883354 : Closed e378054883354 ∧ code e378054883354 = 4776101394458 := by decide
theorem cert_e378054883354 : check e378054883354 [] .sourceHead = true := by decide
def e378054886938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378054886938 : Closed e378054886938 ∧ code e378054886938 = 4776101398042 := by decide
theorem cert_e378054886938 : check e378054886938 [] .sourceHead = true := by decide
def e378054889670 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378054889670 : Closed e378054889670 ∧ code e378054889670 = 4776101400774 := by decide
theorem cert_e378054889670 : check e378054889670 [] .sourceHead = true := by decide
def e378054891546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378054891546 : Closed e378054891546 ∧ code e378054891546 = 4776101402650 := by decide
theorem cert_e378054891546 : check e378054891546 [] .sourceHead = true := by decide
def e378055276570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378055276570 : Closed e378055276570 ∧ code e378055276570 = 4776101787674 := by decide
theorem cert_e378055276570 : check e378055276570 [] .sourceHead = true := by decide
def e378055288858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378055288858 : Closed e378055288858 ∧ code e378055288858 = 4776101799962 := by decide
theorem cert_e378055288858 : check e378055288858 [] .sourceHead = true := by decide
def e378055476762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378055476762 : Closed e378055476762 ∧ code e378055476762 = 4776101987866 := by decide
theorem cert_e378055476762 : check e378055476762 [] .sourceHead = true := by decide
def e378055479494 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378055479494 : Closed e378055479494 ∧ code e378055479494 = 4776101990598 := by decide
theorem cert_e378055479494 : check e378055479494 [] .sourceHead = true := by decide
def e378055481370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378055481370 : Closed e378055481370 ∧ code e378055481370 = 4776101992474 := by decide
theorem cert_e378055481370 : check e378055481370 [] .sourceHead = true := by decide
def e378055485466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378055485466 : Closed e378055485466 ∧ code e378055485466 = 4776101996570 := by decide
theorem cert_e378055485466 : check e378055485466 [] .sourceHead = true := by decide
def e378055898650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378055898650 : Closed e378055898650 ∧ code e378055898650 = 4776102409754 := by decide
theorem cert_e378055898650 : check e378055898650 [] .sourceHead = true := by decide
def e378055899674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378055899674 : Closed e378055899674 ∧ code e378055899674 = 4776102410778 := by decide
theorem cert_e378055899674 : check e378055899674 [] .sourceHead = true := by decide
def e378055924250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378055924250 : Closed e378055924250 ∧ code e378055924250 = 4776102435354 := by decide
theorem cert_e378055924250 : check e378055924250 [] .sourceHead = true := by decide
def e378056095258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056095258 : Closed e378056095258 ∧ code e378056095258 = 4776102606362 := by decide
theorem cert_e378056095258 : check e378056095258 [] .sourceHead = true := by decide
def e378056096282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056096282 : Closed e378056096282 ∧ code e378056096282 = 4776102607386 := by decide
theorem cert_e378056096282 : check e378056096282 [] .sourceHead = true := by decide
def e378056117786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056117786 : Closed e378056117786 ∧ code e378056117786 = 4776102628890 := by decide
theorem cert_e378056117786 : check e378056117786 [] .sourceHead = true := by decide
def e378056126662 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378056126662 : Closed e378056126662 ∧ code e378056126662 = 4776102637766 := by decide
theorem cert_e378056126662 : check e378056126662 [] .sourceHead = true := by decide
def e378056132122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056132122 : Closed e378056132122 ∧ code e378056132122 = 4776102643226 := by decide
theorem cert_e378056132122 : check e378056132122 [] .sourceHead = true := by decide
def e378056134854 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378056134854 : Closed e378056134854 ∧ code e378056134854 = 4776102645958 := by decide
theorem cert_e378056134854 : check e378056134854 [] .sourceHead = true := by decide
def e378056136730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378056136730 : Closed e378056136730 ∧ code e378056136730 = 4776102647834 := by decide
theorem cert_e378056136730 : check e378056136730 [] .sourceHead = true := by decide
def e378056153626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056153626 : Closed e378056153626 ∧ code e378056153626 = 4776102664730 := by decide
theorem cert_e378056153626 : check e378056153626 [] .sourceHead = true := by decide
def e378056164890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056164890 : Closed e378056164890 ∧ code e378056164890 = 4776102675994 := by decide
theorem cert_e378056164890 : check e378056164890 [] .sourceHead = true := by decide
def e378056167622 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378056167622 : Closed e378056167622 ∧ code e378056167622 = 4776102678726 := by decide
theorem cert_e378056167622 : check e378056167622 [] .sourceHead = true := by decide
def e378056169498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378056169498 : Closed e378056169498 ∧ code e378056169498 = 4776102680602 := by decide
theorem cert_e378056169498 : check e378056169498 [] .sourceHead = true := by decide
def e378056173594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378056173594 : Closed e378056173594 ∧ code e378056173594 = 4776102684698 := by decide
theorem cert_e378056173594 : check e378056173594 [] .sourceHead = true := by decide
def e378056314394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056314394 : Closed e378056314394 ∧ code e378056314394 = 4776102825498 := by decide
theorem cert_e378056314394 : check e378056314394 [] .sourceHead = true := by decide
def e378056323270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378056323270 : Closed e378056323270 ∧ code e378056323270 = 4776102834374 := by decide
theorem cert_e378056323270 : check e378056323270 [] .sourceHead = true := by decide
def e378056328730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056328730 : Closed e378056328730 ∧ code e378056328730 = 4776102839834 := by decide
theorem cert_e378056328730 : check e378056328730 [] .sourceHead = true := by decide
def e378056331462 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378056331462 : Closed e378056331462 ∧ code e378056331462 = 4776102842566 := by decide
theorem cert_e378056331462 : check e378056331462 [] .sourceHead = true := by decide
def e378056333338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378056333338 : Closed e378056333338 ∧ code e378056333338 = 4776102844442 := by decide
theorem cert_e378056333338 : check e378056333338 [] .sourceHead = true := by decide
def e378056525338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378056525338 : Closed e378056525338 ∧ code e378056525338 = 4776103036442 := by decide
theorem cert_e378056525338 : check e378056525338 [] .sourceHead = true := by decide
def e378056528070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378056528070 : Closed e378056528070 ∧ code e378056528070 = 4776103039174 := by decide
theorem cert_e378056528070 : check e378056528070 [] .sourceHead = true := by decide
def e378056529946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378056529946 : Closed e378056529946 ∧ code e378056529946 = 4776103041050 := by decide
theorem cert_e378056529946 : check e378056529946 [] .sourceHead = true := by decide
def e378056534042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378056534042 : Closed e378056534042 ∧ code e378056534042 = 4776103045146 := by decide
theorem cert_e378056534042 : check e378056534042 [] .sourceHead = true := by decide
def e378059283994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059283994 : Closed e378059283994 ∧ code e378059283994 = 4776105795098 := by decide
theorem cert_e378059283994 : check e378059283994 [] .sourceHead = true := by decide
def e378059290138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059290138 : Closed e378059290138 ∧ code e378059290138 = 4776105801242 := by decide
theorem cert_e378059290138 : check e378059290138 [] .sourceHead = true := by decide
def e378059316762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059316762 : Closed e378059316762 ∧ code e378059316762 = 4776105827866 := by decide
theorem cert_e378059316762 : check e378059316762 [] .sourceHead = true := by decide
def e378059323930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059323930 : Closed e378059323930 ∧ code e378059323930 = 4776105835034 := by decide
theorem cert_e378059323930 : check e378059323930 [] .sourceHead = true := by decide
def e378059347482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059347482 : Closed e378059347482 ∧ code e378059347482 = 4776105858586 := by decide
theorem cert_e378059347482 : check e378059347482 [] .sourceHead = true := by decide
def e378059348506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059348506 : Closed e378059348506 ∧ code e378059348506 = 4776105859610 := by decide
theorem cert_e378059348506 : check e378059348506 [] .sourceHead = true := by decide
def e378059480602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059480602 : Closed e378059480602 ∧ code e378059480602 = 4776105991706 := by decide
theorem cert_e378059480602 : check e378059480602 [] .sourceHead = true := by decide
def e378059486746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059486746 : Closed e378059486746 ∧ code e378059486746 = 4776105997850 := by decide
theorem cert_e378059486746 : check e378059486746 [] .sourceHead = true := by decide
def e378059677210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059677210 : Closed e378059677210 ∧ code e378059677210 = 4776106188314 := by decide
theorem cert_e378059677210 : check e378059677210 [] .sourceHead = true := by decide
def e378059684378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059684378 : Closed e378059684378 ∧ code e378059684378 = 4776106195482 := by decide
theorem cert_e378059684378 : check e378059684378 [] .sourceHead = true := by decide
def e378059830810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059830810 : Closed e378059830810 ∧ code e378059830810 = 4776106341914 := by decide
theorem cert_e378059830810 : check e378059830810 [] .sourceHead = true := by decide
def e378059831834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378059831834 : Closed e378059831834 ∧ code e378059831834 = 4776106342938 := by decide
theorem cert_e378059831834 : check e378059831834 [] .sourceHead = true := by decide
def e378063613466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063613466 : Closed e378063613466 ∧ code e378063613466 = 4776110124570 := by decide
theorem cert_e378063613466 : check e378063613466 [] .sourceHead = true := by decide
def e378063615514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063615514 : Closed e378063615514 ∧ code e378063615514 = 4776110126618 := by decide
theorem cert_e378063615514 : check e378063615514 [] .sourceHead = true := by decide
def e378063756826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063756826 : Closed e378063756826 ∧ code e378063756826 = 4776110267930 := by decide
theorem cert_e378063756826 : check e378063756826 [] .sourceHead = true := by decide
def e378063777990 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378063777990 : Closed e378063777990 ∧ code e378063777990 = 4776110289094 := by decide
theorem cert_e378063777990 : check e378063777990 [] .sourceHead = true := by decide
def e378063785498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063785498 : Closed e378063785498 ∧ code e378063785498 = 4776110296602 := by decide
theorem cert_e378063785498 : check e378063785498 [] .sourceHead = true := by decide
def e378063794374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378063794374 : Closed e378063794374 ∧ code e378063794374 = 4776110305478 := by decide
theorem cert_e378063794374 : check e378063794374 [] .sourceHead = true := by decide
def e378063842842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063842842 : Closed e378063842842 ∧ code e378063842842 = 4776110353946 := by decide
theorem cert_e378063842842 : check e378063842842 [] .sourceHead = true := by decide
def e378063845914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063845914 : Closed e378063845914 ∧ code e378063845914 = 4776110357018 := by decide
theorem cert_e378063845914 : check e378063845914 [] .sourceHead = true := by decide
def e378063887898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063887898 : Closed e378063887898 ∧ code e378063887898 = 4776110399002 := by decide
theorem cert_e378063887898 : check e378063887898 [] .sourceHead = true := by decide
def e378063909062 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378063909062 : Closed e378063909062 ∧ code e378063909062 = 4776110420166 := by decide
theorem cert_e378063909062 : check e378063909062 [] .sourceHead = true := by decide
def e378063927322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378063927322 : Closed e378063927322 ∧ code e378063927322 = 4776110438426 := by decide
theorem cert_e378063927322 : check e378063927322 [] .sourceHead = true := by decide
def e378063930906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063930906 : Closed e378063930906 ∧ code e378063930906 = 4776110442010 := by decide
theorem cert_e378063930906 : check e378063930906 [] .sourceHead = true := by decide
def e378063933638 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378063933638 : Closed e378063933638 ∧ code e378063933638 = 4776110444742 := by decide
theorem cert_e378063933638 : check e378063933638 [] .sourceHead = true := by decide
def e378063935514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378063935514 : Closed e378063935514 ∧ code e378063935514 = 4776110446618 := by decide
theorem cert_e378063935514 : check e378063935514 [] .sourceHead = true := by decide
def e378063959578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063959578 : Closed e378063959578 ∧ code e378063959578 = 4776110470682 := by decide
theorem cert_e378063959578 : check e378063959578 [] .sourceHead = true := by decide
def e378063960602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063960602 : Closed e378063960602 ∧ code e378063960602 = 4776110471706 := by decide
theorem cert_e378063960602 : check e378063960602 [] .sourceHead = true := by decide
def e378063982106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063982106 : Closed e378063982106 ∧ code e378063982106 = 4776110493210 := by decide
theorem cert_e378063982106 : check e378063982106 [] .sourceHead = true := by decide
def e378063990982 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378063990982 : Closed e378063990982 ∧ code e378063990982 = 4776110502086 := by decide
theorem cert_e378063990982 : check e378063990982 [] .sourceHead = true := by decide
end Blc.Floor42
