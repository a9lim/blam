import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203243754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203243754 : Closed e1211203243754 ∧ code e1211203243754 = 5609249754858 := by decide
theorem cert_e1211203243754 : check e1211203243754 [[],[]] .chain = true := by decide
def e1211203243862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203243862 : Closed e1211203243862 ∧ code e1211203243862 = 5609249754966 := by decide
theorem cert_e1211203243862 : check e1211203243862 [[],[]] .chain = true := by decide
def e1211203243866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203243866 : Closed e1211203243866 ∧ code e1211203243866 = 5609249754970 := by decide
theorem cert_e1211203243866 : check e1211203243866 [[],[]] .chain = true := by decide
def e1211203243882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203243882 : Closed e1211203243882 ∧ code e1211203243882 = 5609249754986 := by decide
theorem cert_e1211203243882 : check e1211203243882 [[],[]] .chain = true := by decide
def e1211203244142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203244142 : Closed e1211203244142 ∧ code e1211203244142 = 5609249755246 := by decide
theorem cert_e1211203244142 : check e1211203244142 [[],[]] .chain = true := by decide
def e1211203244318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203244318 : Closed e1211203244318 ∧ code e1211203244318 = 5609249755422 := by decide
theorem cert_e1211203244318 : check e1211203244318 [[],[]] .chain = true := by decide
def e1211203244514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e1211203244514 : Closed e1211203244514 ∧ code e1211203244514 = 5609249755618 := by decide
theorem cert_e1211203244514 : check e1211203244514 [[],[]] .chain = true := by decide
def e1211203244526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1211203244526 : Closed e1211203244526 ∧ code e1211203244526 = 5609249755630 := by decide
theorem cert_e1211203244526 : check e1211203244526 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203244910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203244910 : Closed e1211203244910 ∧ code e1211203244910 = 5609249756014 := by decide
theorem cert_e1211203244910 : check e1211203244910 [[],[]] .chain = true := by decide
def e1211203244918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203244918 : Closed e1211203244918 ∧ code e1211203244918 = 5609249756022 := by decide
theorem cert_e1211203244918 : check e1211203244918 [[],[]] .chain = true := by decide
def e1211203244974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203244974 : Closed e1211203244974 ∧ code e1211203244974 = 5609249756078 := by decide
theorem cert_e1211203244974 : check e1211203244974 [[],[]] .chain = true := by decide
def e1211203244986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203244986 : Closed e1211203244986 ∧ code e1211203244986 = 5609249756090 := by decide
theorem cert_e1211203244986 : check e1211203244986 [[],[]] .chain = true := by decide
def e1211203245014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203245014 : Closed e1211203245014 ∧ code e1211203245014 = 5609249756118 := by decide
theorem cert_e1211203245014 : check e1211203245014 [[],[]] .chain = true := by decide
def e1211203245018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203245018 : Closed e1211203245018 ∧ code e1211203245018 = 5609249756122 := by decide
theorem cert_e1211203245018 : check e1211203245018 [[],[]] .chain = true := by decide
def e1211203245294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203245294 : Closed e1211203245294 ∧ code e1211203245294 = 5609249756398 := by decide
theorem cert_e1211203245294 : check e1211203245294 [[],[]] .chain = true := by decide
def e1211203245302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203245302 : Closed e1211203245302 ∧ code e1211203245302 = 5609249756406 := by decide
theorem cert_e1211203245302 : check e1211203245302 [[],[]] .chain = true := by decide
def e1211203245678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203245678 : Closed e1211203245678 ∧ code e1211203245678 = 5609249756782 := by decide
theorem cert_e1211203245678 : check e1211203245678 [[],[]] .chain = true := by decide
def e1211203245690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203245690 : Closed e1211203245690 ∧ code e1211203245690 = 5609249756794 := by decide
theorem cert_e1211203245690 : check e1211203245690 [[],[]] .chain = true := by decide
def e1211203245830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203245830 : Closed e1211203245830 ∧ code e1211203245830 = 5609249756934 := by decide
theorem cert_e1211203245830 : check e1211203245830 [[],[]] .chain = true := by decide
def e1211203245854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1211203245854 : Closed e1211203245854 ∧ code e1211203245854 = 5609249756958 := by decide
theorem cert_e1211203245854 : check e1211203245854 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203245878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203245878 : Closed e1211203245878 ∧ code e1211203245878 = 5609249756982 := by decide
theorem cert_e1211203245878 : check e1211203245878 [[],[]] .chain = true := by decide
def e1211203245882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203245882 : Closed e1211203245882 ∧ code e1211203245882 = 5609249756986 := by decide
theorem cert_e1211203245882 : check e1211203245882 [[],[]] .chain = true := by decide
def e1211203246126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203246126 : Closed e1211203246126 ∧ code e1211203246126 = 5609249757230 := by decide
theorem cert_e1211203246126 : check e1211203246126 [[],[]] .chain = true := by decide
def e1211203246318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203246318 : Closed e1211203246318 ∧ code e1211203246318 = 5609249757422 := by decide
theorem cert_e1211203246318 : check e1211203246318 [[],[]] .chain = true := by decide
def e1211203246326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203246326 : Closed e1211203246326 ∧ code e1211203246326 = 5609249757430 := by decide
theorem cert_e1211203246326 : check e1211203246326 [[],[]] .chain = true := by decide
def e1211203246510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203246510 : Closed e1211203246510 ∧ code e1211203246510 = 5609249757614 := by decide
theorem cert_e1211203246510 : check e1211203246510 [[],[]] .chain = true := by decide
def e1211203246522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203246522 : Closed e1211203246522 ∧ code e1211203246522 = 5609249757626 := by decide
theorem cert_e1211203246522 : check e1211203246522 [[],[]] .chain = true := by decide
def e1211203246570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203246570 : Closed e1211203246570 ∧ code e1211203246570 = 5609249757674 := by decide
theorem cert_e1211203246570 : check e1211203246570 [[],[]] .chain = true := by decide
def e1211203246702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203246702 : Closed e1211203246702 ∧ code e1211203246702 = 5609249757806 := by decide
theorem cert_e1211203246702 : check e1211203246702 [[],[]] .chain = true := by decide
def e1211203246714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203246714 : Closed e1211203246714 ∧ code e1211203246714 = 5609249757818 := by decide
theorem cert_e1211203246714 : check e1211203246714 [[],[]] .chain = true := by decide
def e1211203246878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203246878 : Closed e1211203246878 ∧ code e1211203246878 = 5609249757982 := by decide
theorem cert_e1211203246878 : check e1211203246878 [[],[]] .chain = true := by decide
def e1211203246978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203246978 : Closed e1211203246978 ∧ code e1211203246978 = 5609249758082 := by decide
theorem cert_e1211203246978 : check e1211203246978 [[],[]] .chain = true := by decide
def e1211203246990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203246990 : Closed e1211203246990 ∧ code e1211203246990 = 5609249758094 := by decide
theorem cert_e1211203246990 : check e1211203246990 [[],[]] .chain = true := by decide
def e1211203247002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203247002 : Closed e1211203247002 ∧ code e1211203247002 = 5609249758106 := by decide
theorem cert_e1211203247002 : check e1211203247002 [[],[]] .chain = true := by decide
def e1211203247126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203247126 : Closed e1211203247126 ∧ code e1211203247126 = 5609249758230 := by decide
theorem cert_e1211203247126 : check e1211203247126 [[],[]] .chain = true := by decide
def e1211203247130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203247130 : Closed e1211203247130 ∧ code e1211203247130 = 5609249758234 := by decide
theorem cert_e1211203247130 : check e1211203247130 [[],[]] .chain = true := by decide
def e1211203247174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203247174 : Closed e1211203247174 ∧ code e1211203247174 = 5609249758278 := by decide
theorem cert_e1211203247174 : check e1211203247174 [[],[]] .chain = true := by decide
def e1211203247202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203247202 : Closed e1211203247202 ∧ code e1211203247202 = 5609249758306 := by decide
theorem cert_e1211203247202 : check e1211203247202 [[],[]] .chain = true := by decide
def e1211203247214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203247214 : Closed e1211203247214 ∧ code e1211203247214 = 5609249758318 := by decide
theorem cert_e1211203247214 : check e1211203247214 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203247222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203247222 : Closed e1211203247222 ∧ code e1211203247222 = 5609249758326 := by decide
theorem cert_e1211203247222 : check e1211203247222 [[],[]] .chain = true := by decide
def e1211203247226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203247226 : Closed e1211203247226 ∧ code e1211203247226 = 5609249758330 := by decide
theorem cert_e1211203247226 : check e1211203247226 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203247318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203247318 : Closed e1211203247318 ∧ code e1211203247318 = 5609249758422 := by decide
theorem cert_e1211203247318 : check e1211203247318 [[],[]] .chain = true := by decide
def e1211203247322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203247322 : Closed e1211203247322 ∧ code e1211203247322 = 5609249758426 := by decide
theorem cert_e1211203247322 : check e1211203247322 [[],[]] .chain = true := by decide
def e1211203247338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203247338 : Closed e1211203247338 ∧ code e1211203247338 = 5609249758442 := by decide
theorem cert_e1211203247338 : check e1211203247338 [[],[]] .chain = true := by decide
def e1211203247366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203247366 : Closed e1211203247366 ∧ code e1211203247366 = 5609249758470 := by decide
theorem cert_e1211203247366 : check e1211203247366 [[],[]] .chain = true := by decide
def e1211203247390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203247390 : Closed e1211203247390 ∧ code e1211203247390 = 5609249758494 := by decide
theorem cert_e1211203247390 : check e1211203247390 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203247414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203247414 : Closed e1211203247414 ∧ code e1211203247414 = 5609249758518 := by decide
theorem cert_e1211203247414 : check e1211203247414 [[],[]] .chain = true := by decide
def e1211203247418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203247418 : Closed e1211203247418 ∧ code e1211203247418 = 5609249758522 := by decide
theorem cert_e1211203247418 : check e1211203247418 [[],[]] .chain = true := by decide
def e1211203247490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203247490 : Closed e1211203247490 ∧ code e1211203247490 = 5609249758594 := by decide
theorem cert_e1211203247490 : check e1211203247490 [[],[]] .chain = true := by decide
def e1211203247502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203247502 : Closed e1211203247502 ∧ code e1211203247502 = 5609249758606 := by decide
theorem cert_e1211203247502 : check e1211203247502 [[],[]] .chain = true := by decide
def e1211203247514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203247514 : Closed e1211203247514 ∧ code e1211203247514 = 5609249758618 := by decide
theorem cert_e1211203247514 : check e1211203247514 [[],[]] .chain = true := by decide
def e1211203247558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203247558 : Closed e1211203247558 ∧ code e1211203247558 = 5609249758662 := by decide
theorem cert_e1211203247558 : check e1211203247558 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211203248310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e1211203248310 : Closed e1211203248310 ∧ code e1211203248310 = 5609249759414 := by decide
theorem cert_e1211203248310 : check e1211203248310 [[],[]] .chain = true := by decide
def e1211203248342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203248342 : Closed e1211203248342 ∧ code e1211203248342 = 5609249759446 := by decide
theorem cert_e1211203248342 : check e1211203248342 [[],[]] .chain = true := by decide
def e1211203248346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203248346 : Closed e1211203248346 ∧ code e1211203248346 = 5609249759450 := by decide
theorem cert_e1211203248346 : check e1211203248346 [[],[]] .chain = true := by decide
def e1211203248694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203248694 : Closed e1211203248694 ∧ code e1211203248694 = 5609249759798 := by decide
theorem cert_e1211203248694 : check e1211203248694 [[],[]] .chain = true := by decide
def e1211203248698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203248698 : Closed e1211203248698 ∧ code e1211203248698 = 5609249759802 := by decide
theorem cert_e1211203248698 : check e1211203248698 [[],[]] .chain = true := by decide
def e1211203248782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203248782 : Closed e1211203248782 ∧ code e1211203248782 = 5609249759886 := by decide
theorem cert_e1211203248782 : check e1211203248782 [[],[]] .chain = true := by decide
def e1211203248838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203248838 : Closed e1211203248838 ∧ code e1211203248838 = 5609249759942 := by decide
theorem cert_e1211203248838 : check e1211203248838 [[],[]] .chain = true := by decide
def e1211203248918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e1211203248918 : Closed e1211203248918 ∧ code e1211203248918 = 5609249760022 := by decide
theorem cert_e1211203248918 : check e1211203248918 [[],[]] .chain = true := by decide
def e1211203248994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e1211203248994 : Closed e1211203248994 ∧ code e1211203248994 = 5609249760098 := by decide
theorem cert_e1211203248994 : check e1211203248994 [[],[]] .chain = true := by decide
def e1211203249006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1211203249006 : Closed e1211203249006 ∧ code e1211203249006 = 5609249760110 := by decide
theorem cert_e1211203249006 : check e1211203249006 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203249014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1211203249014 : Closed e1211203249014 ∧ code e1211203249014 = 5609249760118 := by decide
theorem cert_e1211203249014 : checkPay e1211203249014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211203249034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203249034 : Closed e1211203249034 ∧ code e1211203249034 = 5609249760138 := by decide
theorem cert_e1211203249034 : check e1211203249034 [[],[]] .chain = true := by decide
def e1211203249058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203249058 : Closed e1211203249058 ∧ code e1211203249058 = 5609249760162 := by decide
theorem cert_e1211203249058 : check e1211203249058 [[],[]] .chain = true := by decide
def e1211203249070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1211203249070 : Closed e1211203249070 ∧ code e1211203249070 = 5609249760174 := by decide
theorem cert_e1211203249070 : check e1211203249070 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203249078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1211203249078 : Closed e1211203249078 ∧ code e1211203249078 = 5609249760182 := by decide
theorem cert_e1211203249078 : check e1211203249078 [[],[]] .chain = true := by decide
def e1211203249082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1211203249082 : Closed e1211203249082 ∧ code e1211203249082 = 5609249760186 := by decide
theorem cert_e1211203249082 : check e1211203249082 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203249110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1211203249110 : Closed e1211203249110 ∧ code e1211203249110 = 5609249760214 := by decide
theorem cert_e1211203249110 : check e1211203249110 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203249114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1211203249114 : Closed e1211203249114 ∧ code e1211203249114 = 5609249760218 := by decide
def e1211203249846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1211203249846 : Closed e1211203249846 ∧ code e1211203249846 = 5609249760950 := by decide
theorem cert_e1211203249846 : check e1211203249846 [[],[]] .chain = true := by decide
def e1211203249878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1211203249878 : Closed e1211203249878 ∧ code e1211203249878 = 5609249760982 := by decide
theorem cert_e1211203249878 : check e1211203249878 [[],[]] .chain = true := by decide
def e1211203249882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1211203249882 : Closed e1211203249882 ∧ code e1211203249882 = 5609249760986 := by decide
theorem cert_e1211203249882 : check e1211203249882 [[],[]] .chain = true := by decide
def e1211203250006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203250006 : Closed e1211203250006 ∧ code e1211203250006 = 5609249761110 := by decide
theorem cert_e1211203250006 : check e1211203250006 [[],[]] .chain = true := by decide
def e1211203250010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203250010 : Closed e1211203250010 ∧ code e1211203250010 = 5609249761114 := by decide
theorem cert_e1211203250010 : check e1211203250010 [[],[]] .chain = true := by decide
def e1211203250026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203250026 : Closed e1211203250026 ∧ code e1211203250026 = 5609249761130 := by decide
theorem cert_e1211203250026 : check e1211203250026 [[],[]] .chain = true := by decide
def e1211203250230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203250230 : Closed e1211203250230 ∧ code e1211203250230 = 5609249761334 := by decide
theorem cert_e1211203250230 : check e1211203250230 [[],[]] .chain = true := by decide
def e1211203250318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203250318 : Closed e1211203250318 ∧ code e1211203250318 = 5609249761422 := by decide
theorem cert_e1211203250318 : check e1211203250318 [[],[]] .chain = true := by decide
def e1211203250402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203250402 : Closed e1211203250402 ∧ code e1211203250402 = 5609249761506 := by decide
theorem cert_e1211203250402 : check e1211203250402 [[],[]] .chain = true := by decide
def e1211203250414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203250414 : Closed e1211203250414 ∧ code e1211203250414 = 5609249761518 := by decide
theorem cert_e1211203250414 : check e1211203250414 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203250422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203250422 : Closed e1211203250422 ∧ code e1211203250422 = 5609249761526 := by decide
theorem cert_e1211203250422 : checkPay e1211203250422 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1211203250614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203250614 : Closed e1211203250614 ∧ code e1211203250614 = 5609249761718 := by decide
theorem cert_e1211203250614 : check e1211203250614 [[],[]] .chain = true := by decide
def e1211203250646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203250646 : Closed e1211203250646 ∧ code e1211203250646 = 5609249761750 := by decide
theorem cert_e1211203250646 : check e1211203250646 [[],[]] .chain = true := by decide
def e1211203250650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203250650 : Closed e1211203250650 ∧ code e1211203250650 = 5609249761754 := by decide
theorem cert_e1211203250650 : check e1211203250650 [[],[]] .chain = true := by decide
def e1211203250806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203250806 : Closed e1211203250806 ∧ code e1211203250806 = 5609249761910 := by decide
theorem cert_e1211203250806 : check e1211203250806 [[],[]] .chain = true := by decide
def e1211203250950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203250950 : Closed e1211203250950 ∧ code e1211203250950 = 5609249762054 := by decide
theorem cert_e1211203250950 : check e1211203250950 [[],[]] .chain = true := by decide
def e1211203250974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203250974 : Closed e1211203250974 ∧ code e1211203250974 = 5609249762078 := by decide
theorem cert_e1211203250974 : check e1211203250974 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1211203250998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203250998 : Closed e1211203250998 ∧ code e1211203250998 = 5609249762102 := by decide
theorem cert_e1211203250998 : check e1211203250998 [[],[]] .chain = true := by decide
def e1211203251002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203251002 : Closed e1211203251002 ∧ code e1211203251002 = 5609249762106 := by decide
theorem cert_e1211203251002 : check e1211203251002 [[],[]] .chain = true := by decide
def e1211203251086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203251086 : Closed e1211203251086 ∧ code e1211203251086 = 5609249762190 := by decide
theorem cert_e1211203251086 : check e1211203251086 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1211203251222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203251222 : Closed e1211203251222 ∧ code e1211203251222 = 5609249762326 := by decide
theorem cert_e1211203251222 : check e1211203251222 [[],[]] .chain = true := by decide
def e1211203251226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203251226 : Closed e1211203251226 ∧ code e1211203251226 = 5609249762330 := by decide
theorem cert_e1211203251226 : check e1211203251226 [[],[]] .chain = true := by decide
def e1211203251270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203251270 : Closed e1211203251270 ∧ code e1211203251270 = 5609249762374 := by decide
theorem cert_e1211203251270 : check e1211203251270 [[],[]] .chain = true := by decide
def e1211203251298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203251298 : Closed e1211203251298 ∧ code e1211203251298 = 5609249762402 := by decide
theorem cert_e1211203251298 : check e1211203251298 [[],[]] .chain = true := by decide
def e1211203251310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203251310 : Closed e1211203251310 ∧ code e1211203251310 = 5609249762414 := by decide
theorem cert_e1211203251310 : check e1211203251310 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211203251318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203251318 : Closed e1211203251318 ∧ code e1211203251318 = 5609249762422 := by decide
theorem cert_e1211203251318 : check e1211203251318 [[],[]] .chain = true := by decide
def e1211203251322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203251322 : Closed e1211203251322 ∧ code e1211203251322 = 5609249762426 := by decide
theorem cert_e1211203251322 : check e1211203251322 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211203251414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203251414 : Closed e1211203251414 ∧ code e1211203251414 = 5609249762518 := by decide
theorem cert_e1211203251414 : check e1211203251414 [[],[]] .chain = true := by decide
def e1211203251418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203251418 : Closed e1211203251418 ∧ code e1211203251418 = 5609249762522 := by decide
theorem cert_e1211203251418 : check e1211203251418 [[],[]] .chain = true := by decide
def e1211203251434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203251434 : Closed e1211203251434 ∧ code e1211203251434 = 5609249762538 := by decide
theorem cert_e1211203251434 : check e1211203251434 [[],[]] .chain = true := by decide
def e1211203251462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203251462 : Closed e1211203251462 ∧ code e1211203251462 = 5609249762566 := by decide
theorem cert_e1211203251462 : check e1211203251462 [[],[]] .chain = true := by decide
def e1211203251486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203251486 : Closed e1211203251486 ∧ code e1211203251486 = 5609249762590 := by decide
theorem cert_e1211203251486 : check e1211203251486 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211203251510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203251510 : Closed e1211203251510 ∧ code e1211203251510 = 5609249762614 := by decide
theorem cert_e1211203251510 : check e1211203251510 [[],[]] .chain = true := by decide
def e1211203251514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203251514 : Closed e1211203251514 ∧ code e1211203251514 = 5609249762618 := by decide
theorem cert_e1211203251514 : check e1211203251514 [[],[]] .chain = true := by decide
def e1211203251586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203251586 : Closed e1211203251586 ∧ code e1211203251586 = 5609249762690 := by decide
theorem cert_e1211203251586 : check e1211203251586 [[],[]] .chain = true := by decide
def e1211203251598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203251598 : Closed e1211203251598 ∧ code e1211203251598 = 5609249762702 := by decide
theorem cert_e1211203251598 : check e1211203251598 [[],[]] .chain = true := by decide
def e1211203251610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203251610 : Closed e1211203251610 ∧ code e1211203251610 = 5609249762714 := by decide
theorem cert_e1211203251610 : check e1211203251610 [[],[]] .chain = true := by decide
def e1211203251654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203251654 : Closed e1211203251654 ∧ code e1211203251654 = 5609249762758 := by decide
theorem cert_e1211203251654 : check e1211203251654 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211203251766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203251766 : Closed e1211203251766 ∧ code e1211203251766 = 5609249762870 := by decide
theorem cert_e1211203251766 : check e1211203251766 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203251770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203251770 : Closed e1211203251770 ∧ code e1211203251770 = 5609249762874 := by decide
theorem cert_e1211203251770 : check e1211203251770 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203251854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203251854 : Closed e1211203251854 ∧ code e1211203251854 = 5609249762958 := by decide
def e1211203251910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203251910 : Closed e1211203251910 ∧ code e1211203251910 = 5609249763014 := by decide
theorem cert_e1211203251910 : check e1211203251910 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203257710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203257710 : Closed e1211203257710 ∧ code e1211203257710 = 5609249768814 := by decide
theorem cert_e1211203257710 : check e1211203257710 [[],[]] .chain = true := by decide
def e1211203257718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203257718 : Closed e1211203257718 ∧ code e1211203257718 = 5609249768822 := by decide
theorem cert_e1211203257718 : check e1211203257718 [[],[]] .chain = true := by decide
def e1211203257774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203257774 : Closed e1211203257774 ∧ code e1211203257774 = 5609249768878 := by decide
theorem cert_e1211203257774 : check e1211203257774 [[],[]] .chain = true := by decide
def e1211203257786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203257786 : Closed e1211203257786 ∧ code e1211203257786 = 5609249768890 := by decide
theorem cert_e1211203257786 : check e1211203257786 [[],[]] .chain = true := by decide
def e1211203257814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203257814 : Closed e1211203257814 ∧ code e1211203257814 = 5609249768918 := by decide
theorem cert_e1211203257814 : check e1211203257814 [[],[]] .chain = true := by decide
def e1211203257818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203257818 : Closed e1211203257818 ∧ code e1211203257818 = 5609249768922 := by decide
theorem cert_e1211203257818 : check e1211203257818 [[],[]] .chain = true := by decide
def e1211203258030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203258030 : Closed e1211203258030 ∧ code e1211203258030 = 5609249769134 := by decide
theorem cert_e1211203258030 : check e1211203258030 [[],[]] .chain = true := by decide
def e1211203258042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203258042 : Closed e1211203258042 ∧ code e1211203258042 = 5609249769146 := by decide
theorem cert_e1211203258042 : check e1211203258042 [[],[]] .chain = true := by decide
def e1211203258090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203258090 : Closed e1211203258090 ∧ code e1211203258090 = 5609249769194 := by decide
theorem cert_e1211203258090 : check e1211203258090 [[],[]] .chain = true := by decide
def e1211203260846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203260846 : Closed e1211203260846 ∧ code e1211203260846 = 5609249771950 := by decide
theorem cert_e1211203260846 : check e1211203260846 [[],[]] .chain = true := by decide
def e1211203260858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203260858 : Closed e1211203260858 ∧ code e1211203260858 = 5609249771962 := by decide
theorem cert_e1211203260858 : check e1211203260858 [[],[]] .chain = true := by decide
def e1211203260906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1211203260906 : Closed e1211203260906 ∧ code e1211203260906 = 5609249772010 := by decide
theorem cert_e1211203260906 : check e1211203260906 [[],[]] .chain = true := by decide
def e1211203261550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203261550 : Closed e1211203261550 ∧ code e1211203261550 = 5609249772654 := by decide
theorem cert_e1211203261550 : check e1211203261550 [[],[]] .chain = true := by decide
def e1211203261562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203261562 : Closed e1211203261562 ∧ code e1211203261562 = 5609249772666 := by decide
theorem cert_e1211203261562 : check e1211203261562 [[],[]] .chain = true := by decide
def e1211203261726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203261726 : Closed e1211203261726 ∧ code e1211203261726 = 5609249772830 := by decide
theorem cert_e1211203261726 : check e1211203261726 [[],[]] .chain = true := by decide
def e1211203261894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203261894 : Closed e1211203261894 ∧ code e1211203261894 = 5609249772998 := by decide
theorem cert_e1211203261894 : check e1211203261894 [[],[]] .chain = true := by decide
def e1211203262234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203262234 : Closed e1211203262234 ∧ code e1211203262234 = 5609249773338 := by decide
theorem cert_e1211203262234 : check e1211203262234 [[],[]] .chain = true := by decide
def e1211203262278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203262278 : Closed e1211203262278 ∧ code e1211203262278 = 5609249773382 := by decide
theorem cert_e1211203262278 : check e1211203262278 [[],[]] .chain = true := by decide
def e1211203262638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203262638 : Closed e1211203262638 ∧ code e1211203262638 = 5609249773742 := by decide
theorem cert_e1211203262638 : check e1211203262638 [[],[]] .chain = true := by decide
def e1211203262650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203262650 : Closed e1211203262650 ∧ code e1211203262650 = 5609249773754 := by decide
theorem cert_e1211203262650 : check e1211203262650 [[],[]] .chain = true := by decide
def e1211203263022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203263022 : Closed e1211203263022 ∧ code e1211203263022 = 5609249774126 := by decide
theorem cert_e1211203263022 : check e1211203263022 [[],[]] .chain = true := by decide
def e1211203263202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203263202 : Closed e1211203263202 ∧ code e1211203263202 = 5609249774306 := by decide
theorem cert_e1211203263202 : check e1211203263202 [[],[]] .chain = true := by decide
def e1211203263214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e1211203263214 : Closed e1211203263214 ∧ code e1211203263214 = 5609249774318 := by decide
theorem cert_e1211203263214 : check e1211203263214 [[],[]] .sourceHead = true := by decide
def e1211203263342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1211203263342 : Closed e1211203263342 ∧ code e1211203263342 = 5609249774446 := by decide
theorem cert_e1211203263342 : check e1211203263342 [[],[]] .chain = true := by decide
def e1211203263350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1211203263350 : Closed e1211203263350 ∧ code e1211203263350 = 5609249774454 := by decide
theorem cert_e1211203263350 : check e1211203263350 [[],[]] .chain = true := by decide
def e1211203263370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203263370 : Closed e1211203263370 ∧ code e1211203263370 = 5609249774474 := by decide
theorem cert_e1211203263370 : check e1211203263370 [[],[]] .chain = true := by decide
def e1211203263394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203263394 : Closed e1211203263394 ∧ code e1211203263394 = 5609249774498 := by decide
theorem cert_e1211203263394 : check e1211203263394 [[],[]] .chain = true := by decide
def e1211203263406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e1211203263406 : Closed e1211203263406 ∧ code e1211203263406 = 5609249774510 := by decide
theorem cert_e1211203263406 : check e1211203263406 [[],[]] .sourceHead = true := by decide
def e1211203263414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1211203263414 : Closed e1211203263414 ∧ code e1211203263414 = 5609249774518 := by decide
theorem cert_e1211203263414 : check e1211203263414 [[],[]] .chain = true := by decide
def e1211203263418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e1211203263418 : Closed e1211203263418 ∧ code e1211203263418 = 5609249774522 := by decide
theorem cert_e1211203263418 : check e1211203263418 [[],[]] .sourceHead = true := by decide
def e1211203263854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203263854 : Closed e1211203263854 ∧ code e1211203263854 = 5609249774958 := by decide
theorem cert_e1211203263854 : check e1211203263854 [[],[]] .chain = true := by decide
def e1211203263862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203263862 : Closed e1211203263862 ∧ code e1211203263862 = 5609249774966 := by decide
theorem cert_e1211203263862 : check e1211203263862 [[],[]] .chain = true := by decide
def e1211203263918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203263918 : Closed e1211203263918 ∧ code e1211203263918 = 5609249775022 := by decide
theorem cert_e1211203263918 : check e1211203263918 [[],[]] .chain = true := by decide
def e1211203263930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203263930 : Closed e1211203263930 ∧ code e1211203263930 = 5609249775034 := by decide
theorem cert_e1211203263930 : check e1211203263930 [[],[]] .chain = true := by decide
def e1211203263958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203263958 : Closed e1211203263958 ∧ code e1211203263958 = 5609249775062 := by decide
theorem cert_e1211203263958 : check e1211203263958 [[],[]] .chain = true := by decide
def e1211203263962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203263962 : Closed e1211203263962 ∧ code e1211203263962 = 5609249775066 := by decide
theorem cert_e1211203263962 : check e1211203263962 [[],[]] .chain = true := by decide
def e1211203264042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203264042 : Closed e1211203264042 ∧ code e1211203264042 = 5609249775146 := by decide
theorem cert_e1211203264042 : check e1211203264042 [[],[]] .chain = true := by decide
def e1211203264138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203264138 : Closed e1211203264138 ∧ code e1211203264138 = 5609249775242 := by decide
theorem cert_e1211203264138 : check e1211203264138 [[],[]] .chain = true := by decide
def e1211203264162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203264162 : Closed e1211203264162 ∧ code e1211203264162 = 5609249775266 := by decide
theorem cert_e1211203264162 : check e1211203264162 [[],[]] .chain = true := by decide
def e1211203264174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203264174 : Closed e1211203264174 ∧ code e1211203264174 = 5609249775278 := by decide
theorem cert_e1211203264174 : check e1211203264174 [[],[]] .sourceHead = true := by decide
def e1211203264182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1211203264182 : Closed e1211203264182 ∧ code e1211203264182 = 5609249775286 := by decide
theorem cert_e1211203264182 : check e1211203264182 [[],[]] .chain = true := by decide
def e1211203264186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203264186 : Closed e1211203264186 ∧ code e1211203264186 = 5609249775290 := by decide
theorem cert_e1211203264186 : check e1211203264186 [[],[]] .sourceHead = true := by decide
def e1211203264214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1211203264214 : Closed e1211203264214 ∧ code e1211203264214 = 5609249775318 := by decide
theorem cert_e1211203264214 : check e1211203264214 [[],[]] .chain = true := by decide
def e1211203264218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1211203264218 : Closed e1211203264218 ∧ code e1211203264218 = 5609249775322 := by decide
theorem cert_e1211203264218 : check e1211203264218 [[],[]] .chain = true := by decide
def e1211203264234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203264234 : Closed e1211203264234 ∧ code e1211203264234 = 5609249775338 := by decide
theorem cert_e1211203264234 : check e1211203264234 [[],[]] .sourceHead = true := by decide
def e1211203269998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1211203269998 : Closed e1211203269998 ∧ code e1211203269998 = 5609249781102 := by decide
theorem cert_e1211203269998 : check e1211203269998 [[],[]] .chain = true := by decide
def e1211203270006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1211203270006 : Closed e1211203270006 ∧ code e1211203270006 = 5609249781110 := by decide
theorem cert_e1211203270006 : check e1211203270006 [[],[]] .chain = true := by decide
def e1211203270062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1211203270062 : Closed e1211203270062 ∧ code e1211203270062 = 5609249781166 := by decide
theorem cert_e1211203270062 : check e1211203270062 [[],[]] .chain = true := by decide
end Blc.Floor42
