import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1202987993882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1202987993882 : Closed e1202987993882 ∧ code e1202987993882 = 5601034504986 := by decide
theorem cert_e1202987993882 : check e1202987993882 [[]] .width = true := by decide
def e1202987993926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1202987993926 : Closed e1202987993926 ∧ code e1202987993926 = 5601034505030 := by decide
theorem cert_e1202987993926 : check e1202987993926 [[]] .width = true := by decide
def e1202987994038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1202987994038 : Closed e1202987994038 ∧ code e1202987994038 = 5601034505142 := by decide
theorem cert_e1202987994038 : check e1202987994038 [[]] .width = true := by decide
def e1202987994166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1202987994166 : Closed e1202987994166 ∧ code e1202987994166 = 5601034505270 := by decide
theorem cert_e1202987994166 : check e1202987994166 [[]] .width = true := by decide
def e1202987994170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1202987994170 : Closed e1202987994170 ∧ code e1202987994170 = 5601034505274 := by decide
theorem cert_e1202987994170 : check e1202987994170 [[]] .width = true := by decide
def e1202987994310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202987994310 : Closed e1202987994310 ∧ code e1202987994310 = 5601034505414 := by decide
theorem cert_e1202987994310 : check e1202987994310 [[]] .width = true := by decide
def e1202987994650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202987994650 : Closed e1202987994650 ∧ code e1202987994650 = 5601034505754 := by decide
theorem cert_e1202987994650 : check e1202987994650 [[]] .width = true := by decide
def e1202987994742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1202987994742 : Closed e1202987994742 ∧ code e1202987994742 = 5601034505846 := by decide
theorem cert_e1202987994742 : check e1202987994742 [[]] .width = true := by decide
def e1202988002330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1202988002330 : Closed e1202988002330 ∧ code e1202988002330 = 5601034513434 := by decide
theorem cert_e1202988002330 : check e1202988002330 [[]] .width = true := by decide
def e1202988002374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1202988002374 : Closed e1202988002374 ∧ code e1202988002374 = 5601034513478 := by decide
theorem cert_e1202988002374 : check e1202988002374 [[]] .width = true := by decide
def e1202988002402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1202988002402 : Closed e1202988002402 ∧ code e1202988002402 = 5601034513506 := by decide
theorem cert_e1202988002402 : check e1202988002402 [[]] .width = true := by decide
def e1202988002566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1202988002566 : Closed e1202988002566 ∧ code e1202988002566 = 5601034513670 := by decide
theorem cert_e1202988002566 : check e1202988002566 [[]] .width = true := by decide
def e1202988003358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1202988003358 : Closed e1202988003358 ∧ code e1202988003358 = 5601034514462 := by decide
theorem cert_e1202988003358 : check e1202988003358 [[]] .width = true := by decide
def e1202988003526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202988003526 : Closed e1202988003526 ∧ code e1202988003526 = 5601034514630 := by decide
theorem cert_e1202988003526 : check e1202988003526 [[]] .width = true := by decide
def e1202988003554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1202988003554 : Closed e1202988003554 ∧ code e1202988003554 = 5601034514658 := by decide
theorem cert_e1202988003554 : check e1202988003554 [[]] .width = true := by decide
def e1202988004102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1202988004102 : Closed e1202988004102 ∧ code e1202988004102 = 5601034515206 := by decide
theorem cert_e1202988004102 : check e1202988004102 [[]] .width = true := by decide
def e1202988282054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202988282054 : Closed e1202988282054 ∧ code e1202988282054 = 5601034793158 := by decide
theorem cert_e1202988282054 : check e1202988282054 [[]] .width = true := by decide
def e1202988308506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202988308506 : Closed e1202988308506 ∧ code e1202988308506 = 5601034819610 := by decide
theorem cert_e1202988308506 : check e1202988308506 [[]] .width = true := by decide
def e1202988312602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202988312602 : Closed e1202988312602 ∧ code e1202988312602 = 5601034823706 := by decide
theorem cert_e1202988312602 : check e1202988312602 [[]] .width = true := by decide
def e1202988351514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202988351514 : Closed e1202988351514 ∧ code e1202988351514 = 5601034862618 := by decide
theorem cert_e1202988351514 : check e1202988351514 [[]] .width = true := by decide
def e1202988351606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1202988351606 : Closed e1202988351606 ∧ code e1202988351606 = 5601034862710 := by decide
theorem cert_e1202988351606 : check e1202988351606 [[]] .width = true := by decide
def e1202988351850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1202988351850 : Closed e1202988351850 ∧ code e1202988351850 = 5601034862954 := by decide
theorem cert_e1202988351850 : check e1202988351850 [[]] .width = true := by decide
def e1202988351898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1202988351898 : Closed e1202988351898 ∧ code e1202988351898 = 5601034863002 := by decide
theorem cert_e1202988351898 : check e1202988351898 [[]] .width = true := by decide
def e1202988352906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1202988352906 : Closed e1202988352906 ∧ code e1202988352906 = 5601034864010 := by decide
theorem cert_e1202988352906 : check e1202988352906 [[]] .width = true := by decide
def e1202988352930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1202988352930 : Closed e1202988352930 ∧ code e1202988352930 = 5601034864034 := by decide
private def t_e1202988352930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e1202988352930 : ¬ IsSelfInterpreter e1202988352930 :=
  wSource (t := t_e1202988352930) (replay_sound (ps := []) (t := e1202988352930) (by decide)) (by decide)
def e1202988353038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1202988353038 : Closed e1202988353038 ∧ code e1202988353038 = 5601034864142 := by decide
theorem cert_e1202988353038 : check e1202988353038 [[]] .width = true := by decide
def e1202988353050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202988353050 : Closed e1202988353050 ∧ code e1202988353050 = 5601034864154 := by decide
private def t_e1202988353050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e1202988353050 : ¬ IsSelfInterpreter e1202988353050 :=
  wSource (t := t_e1202988353050) (replay_sound (ps := []) (t := e1202988353050) (by decide)) (by decide)
def e1202988353122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1202988353122 : Closed e1202988353122 ∧ code e1202988353122 = 5601034864226 := by decide
theorem cert_e1202988353122 : check e1202988353122 [[]] .width = true := by decide
def e1202988454086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202988454086 : Closed e1202988454086 ∧ code e1202988454086 = 5601034965190 := by decide
theorem cert_e1202988454086 : check e1202988454086 [[]] .width = true := by decide
def e1202988455962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1202988455962 : Closed e1202988455962 ∧ code e1202988455962 = 5601034967066 := by decide
theorem cert_e1202988455962 : check e1202988455962 [[]] .width = true := by decide
def e1202988457498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202988457498 : Closed e1202988457498 ∧ code e1202988457498 = 5601034968602 := by decide
private def t_e1202988457498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202988457498 : ¬ IsSelfInterpreter e1202988457498 :=
  wSource (t := t_e1202988457498) (replay_sound (ps := []) (t := e1202988457498) (by decide)) (by decide)
def e1202988466374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1202988466374 : Closed e1202988466374 ∧ code e1202988466374 = 5601034977478 := by decide
theorem cert_e1202988466374 : check e1202988466374 [[]] .width = true := by decide
def e1202988474394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202988474394 : Closed e1202988474394 ∧ code e1202988474394 = 5601034985498 := by decide
theorem cert_e1202988474394 : check e1202988474394 [[]] .width = true := by decide
def e1202988474486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202988474486 : Closed e1202988474486 ∧ code e1202988474486 = 5601034985590 := by decide
private def t_e1202988474486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202988474486 : ¬ IsSelfInterpreter e1202988474486 :=
  wSource (t := t_e1202988474486) (replay_sound (ps := []) (t := e1202988474486) (by decide)) (by decide)
def e1202988474730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202988474730 : Closed e1202988474730 ∧ code e1202988474730 = 5601034985834 := by decide
private def t_e1202988474730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202988474730 : ¬ IsSelfInterpreter e1202988474730 :=
  wSource (t := t_e1202988474730) (replay_sound (ps := []) (t := e1202988474730) (by decide)) (by decide)
def e1202988474778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202988474778 : Closed e1202988474778 ∧ code e1202988474778 = 5601034985882 := by decide
private def t_e1202988474778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202988474778 : ¬ IsSelfInterpreter e1202988474778 :=
  wSource (t := t_e1202988474778) (replay_sound (ps := []) (t := e1202988474778) (by decide)) (by decide)
def e1202988478662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202988478662 : Closed e1202988478662 ∧ code e1202988478662 = 5601034989766 := by decide
theorem cert_e1202988478662 : check e1202988478662 [[]] .width = true := by decide
def e1202988490778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1202988490778 : Closed e1202988490778 ∧ code e1202988490778 = 5601035001882 := by decide
theorem cert_e1202988490778 : check e1202988490778 [[]] .width = true := by decide
def e1202988490870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1202988490870 : Closed e1202988490870 ∧ code e1202988490870 = 5601035001974 := by decide
private def t_e1202988490870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1202988490870 : ¬ IsSelfInterpreter e1202988490870 :=
  wSource (t := t_e1202988490870) (replay_sound (ps := []) (t := e1202988490870) (by decide)) (by decide)
def e1202988491114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1202988491114 : Closed e1202988491114 ∧ code e1202988491114 = 5601035002218 := by decide
private def t_e1202988491114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1202988491114 : ¬ IsSelfInterpreter e1202988491114 :=
  wSource (t := t_e1202988491114) (replay_sound (ps := []) (t := e1202988491114) (by decide)) (by decide)
def e1202988491162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1202988491162 : Closed e1202988491162 ∧ code e1202988491162 = 5601035002266 := by decide
private def t_e1202988491162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1202988491162 : ¬ IsSelfInterpreter e1202988491162 :=
  wSource (t := t_e1202988491162) (replay_sound (ps := []) (t := e1202988491162) (by decide)) (by decide)
def e1202988500506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202988500506 : Closed e1202988500506 ∧ code e1202988500506 = 5601035011610 := by decide
private def t_e1202988500506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202988500506 : ¬ IsSelfInterpreter e1202988500506 :=
  wSource (t := t_e1202988500506) (replay_sound (ps := []) (t := e1202988500506) (by decide)) (by decide)
def e1202988503238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202988503238 : Closed e1202988503238 ∧ code e1202988503238 = 5601035014342 := by decide
theorem cert_e1202988503238 : check e1202988503238 [[]] .width = true := by decide
def e1202988515526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1202988515526 : Closed e1202988515526 ∧ code e1202988515526 = 5601035026630 := by decide
theorem cert_e1202988515526 : check e1202988515526 [[]] .width = true := by decide
def e1202988516054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1202988516054 : Closed e1202988516054 ∧ code e1202988516054 = 5601035027158 := by decide
theorem cert_e1202988516054 : check e1202988516054 [[]] .width = true := by decide
def e1202988516058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1202988516058 : Closed e1202988516058 ∧ code e1202988516058 = 5601035027162 := by decide
theorem cert_e1202988516058 : check e1202988516058 [[]] .width = true := by decide
def e1202988516074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1202988516074 : Closed e1202988516074 ∧ code e1202988516074 = 5601035027178 := by decide
theorem cert_e1202988516074 : check e1202988516074 [[]] .width = true := by decide
def e1202988516150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1202988516150 : Closed e1202988516150 ∧ code e1202988516150 = 5601035027254 := by decide
theorem cert_e1202988516150 : check e1202988516150 [[]] .width = true := by decide
def e1202988516154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1202988516154 : Closed e1202988516154 ∧ code e1202988516154 = 5601035027258 := by decide
theorem cert_e1202988516154 : check e1202988516154 [[]] .width = true := by decide
def e1202988516238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1202988516238 : Closed e1202988516238 ∧ code e1202988516238 = 5601035027342 := by decide
theorem cert_e1202988516238 : check e1202988516238 [[]] .width = true := by decide
def e1202988516250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1202988516250 : Closed e1202988516250 ∧ code e1202988516250 = 5601035027354 := by decide
theorem cert_e1202988516250 : check e1202988516250 [[]] .width = true := by decide
def e1202988518170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1202988518170 : Closed e1202988518170 ∧ code e1202988518170 = 5601035029274 := by decide
theorem cert_e1202988518170 : check e1202988518170 [[]] .width = true := by decide
def e1202988518214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1202988518214 : Closed e1202988518214 ∧ code e1202988518214 = 5601035029318 := by decide
theorem cert_e1202988518214 : check e1202988518214 [[]] .width = true := by decide
def e1202988518326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1202988518326 : Closed e1202988518326 ∧ code e1202988518326 = 5601035029430 := by decide
private def t_e1202988518326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem cert_e1202988518326 : ¬ IsSelfInterpreter e1202988518326 :=
  wSource (t := t_e1202988518326) (replay_sound (ps := []) (t := e1202988518326) (by decide)) (by decide)
def e1202988518454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1202988518454 : Closed e1202988518454 ∧ code e1202988518454 = 5601035029558 := by decide
theorem cert_e1202988518454 : check e1202988518454 [[]] .width = true := by decide
def e1202988518458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1202988518458 : Closed e1202988518458 ∧ code e1202988518458 = 5601035029562 := by decide
theorem cert_e1202988518458 : check e1202988518458 [[]] .width = true := by decide
def e1202988518598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202988518598 : Closed e1202988518598 ∧ code e1202988518598 = 5601035029702 := by decide
theorem cert_e1202988518598 : check e1202988518598 [[]] .width = true := by decide
def e1202988518938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1202988518938 : Closed e1202988518938 ∧ code e1202988518938 = 5601035030042 := by decide
private def t_e1202988518938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem cert_e1202988518938 : ¬ IsSelfInterpreter e1202988518938 :=
  wSource (t := t_e1202988518938) (replay_sound (ps := []) (t := e1202988518938) (by decide)) (by decide)
def e1202988519030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1202988519030 : Closed e1202988519030 ∧ code e1202988519030 = 5601035030134 := by decide
private def t_e1202988519030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem cert_e1202988519030 : ¬ IsSelfInterpreter e1202988519030 :=
  wSource (t := t_e1202988519030) (replay_sound (ps := []) (t := e1202988519030) (by decide)) (by decide)
def e1202988526618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1202988526618 : Closed e1202988526618 ∧ code e1202988526618 = 5601035037722 := by decide
theorem cert_e1202988526618 : check e1202988526618 [[]] .width = true := by decide
def e1202988526662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1202988526662 : Closed e1202988526662 ∧ code e1202988526662 = 5601035037766 := by decide
theorem cert_e1202988526662 : check e1202988526662 [[]] .width = true := by decide
def e1202988526690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1202988526690 : Closed e1202988526690 ∧ code e1202988526690 = 5601035037794 := by decide
theorem cert_e1202988526690 : check e1202988526690 [[]] .width = true := by decide
def e1202988526854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1202988526854 : Closed e1202988526854 ∧ code e1202988526854 = 5601035037958 := by decide
private def t_e1202988526854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem cert_e1202988526854 : ¬ IsSelfInterpreter e1202988526854 :=
  wSource (t := t_e1202988526854) (replay_sound (ps := []) (t := e1202988526854) (by decide)) (by decide)
def e1202988527646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1202988527646 : Closed e1202988527646 ∧ code e1202988527646 = 5601035038750 := by decide
theorem cert_e1202988527646 : check e1202988527646 [[]] .width = true := by decide
def e1202988527814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1202988527814 : Closed e1202988527814 ∧ code e1202988527814 = 5601035038918 := by decide
theorem cert_e1202988527814 : check e1202988527814 [[]] .width = true := by decide
def e1202988527842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e1202988527842 : Closed e1202988527842 ∧ code e1202988527842 = 5601035038946 := by decide
theorem cert_e1202988527842 : check e1202988527842 [[]] .width = true := by decide
def e1202988528390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e1202988528390 : Closed e1202988528390 ∧ code e1202988528390 = 5601035039494 := by decide
theorem cert_e1202988528390 : check e1202988528390 [[]] .width = true := by decide
def e1202988879386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202988879386 : Closed e1202988879386 ∧ code e1202988879386 = 5601035390490 := by decide
private def t_e1202988879386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202988879386 : ¬ IsSelfInterpreter e1202988879386 :=
  wSource (t := t_e1202988879386) (replay_sound (ps := []) (t := e1202988879386) (by decide)) (by decide)
def e1202988888262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202988888262 : Closed e1202988888262 ∧ code e1202988888262 = 5601035399366 := by decide
theorem cert_e1202988888262 : check e1202988888262 [[]] .width = true := by decide
def e1202988893722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1202988893722 : Closed e1202988893722 ∧ code e1202988893722 = 5601035404826 := by decide
private def t_e1202988893722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1202988893722 : ¬ IsSelfInterpreter e1202988893722 :=
  wSource (t := t_e1202988893722) (replay_sound (ps := []) (t := e1202988893722) (by decide)) (by decide)
def e1202988896454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1202988896454 : Closed e1202988896454 ∧ code e1202988896454 = 5601035407558 := by decide
theorem cert_e1202988896454 : check e1202988896454 [[]] .width = true := by decide
def e1203001606342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203001606342 : Closed e1203001606342 ∧ code e1203001606342 = 5601048117446 := by decide
theorem cert_e1203001606342 : check e1203001606342 [[]] .width = true := by decide
def e1203001737414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203001737414 : Closed e1203001737414 ∧ code e1203001737414 = 5601048248518 := by decide
theorem cert_e1203001737414 : check e1203001737414 [[]] .width = true := by decide
def e1203016808474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203016808474 : Closed e1203016808474 ∧ code e1203016808474 = 5601063319578 := by decide
theorem cert_e1203016808474 : check e1203016808474 [[]] .width = true := by decide
def e1203017466054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203017466054 : Closed e1203017466054 ∧ code e1203017466054 = 5601063977158 := by decide
theorem cert_e1203017466054 : check e1203017466054 [[]] .width = true := by decide
def e1203017496602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203017496602 : Closed e1203017496602 ∧ code e1203017496602 = 5601064007706 := by decide
theorem cert_e1203017496602 : check e1203017496602 [[]] .width = true := by decide
def e1203017531590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203017531590 : Closed e1203017531590 ∧ code e1203017531590 = 5601064042694 := by decide
theorem cert_e1203017531590 : check e1203017531590 [[]] .width = true := by decide
def e1203017707718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203017707718 : Closed e1203017707718 ∧ code e1203017707718 = 5601064218822 := by decide
theorem cert_e1203017707718 : check e1203017707718 [[]] .width = true := by decide
def e1203017725978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203017725978 : Closed e1203017725978 ∧ code e1203017725978 = 5601064237082 := by decide
theorem cert_e1203017725978 : check e1203017725978 [[]] .width = true := by decide
def e1203017739802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203017739802 : Closed e1203017739802 ∧ code e1203017739802 = 5601064250906 := by decide
theorem cert_e1203017739802 : check e1203017739802 [[]] .width = true := by decide
def e1203017990342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203017990342 : Closed e1203017990342 ∧ code e1203017990342 = 5601064501446 := by decide
theorem cert_e1203017990342 : check e1203017990342 [[]] .width = true := by decide
def e1203018063898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203018063898 : Closed e1203018063898 ∧ code e1203018063898 = 5601064575002 := by decide
theorem cert_e1203018063898 : check e1203018063898 [[]] .width = true := by decide
def e1203018063990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203018063990 : Closed e1203018063990 ∧ code e1203018063990 = 5601064575094 := by decide
theorem cert_e1203018063990 : check e1203018063990 [[]] .width = true := by decide
def e1203018064234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203018064234 : Closed e1203018064234 ∧ code e1203018064234 = 5601064575338 := by decide
theorem cert_e1203018064234 : check e1203018064234 [[]] .width = true := by decide
def e1203018064282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203018064282 : Closed e1203018064282 ∧ code e1203018064282 = 5601064575386 := by decide
theorem cert_e1203018064282 : check e1203018064282 [[]] .width = true := by decide
def e1203018076358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203018076358 : Closed e1203018076358 ∧ code e1203018076358 = 5601064587462 := by decide
theorem cert_e1203018076358 : check e1203018076358 [[]] .width = true := by decide
def e1203018078234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203018078234 : Closed e1203018078234 ∧ code e1203018078234 = 5601064589338 := by decide
theorem cert_e1203018078234 : check e1203018078234 [[]] .width = true := by decide
def e1203018079770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203018079770 : Closed e1203018079770 ∧ code e1203018079770 = 5601064590874 := by decide
theorem cert_e1203018079770 : check e1203018079770 [[]] .width = true := by decide
def e1203018088646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203018088646 : Closed e1203018088646 ∧ code e1203018088646 = 5601064599750 := by decide
theorem cert_e1203018088646 : check e1203018088646 [[]] .width = true := by decide
def e1203018096666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203018096666 : Closed e1203018096666 ∧ code e1203018096666 = 5601064607770 := by decide
theorem cert_e1203018096666 : check e1203018096666 [[]] .width = true := by decide
def e1203018096758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203018096758 : Closed e1203018096758 ∧ code e1203018096758 = 5601064607862 := by decide
theorem cert_e1203018096758 : check e1203018096758 [[]] .width = true := by decide
def e1203018097002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203018097002 : Closed e1203018097002 ∧ code e1203018097002 = 5601064608106 := by decide
theorem cert_e1203018097002 : check e1203018097002 [[]] .width = true := by decide
def e1203018097050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203018097050 : Closed e1203018097050 ∧ code e1203018097050 = 5601064608154 := by decide
theorem cert_e1203018097050 : check e1203018097050 [[]] .width = true := by decide
def e1203018100934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203018100934 : Closed e1203018100934 ∧ code e1203018100934 = 5601064612038 := by decide
theorem cert_e1203018100934 : check e1203018100934 [[]] .width = true := by decide
def e1203018182854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203018182854 : Closed e1203018182854 ∧ code e1203018182854 = 5601064693958 := by decide
theorem cert_e1203018182854 : check e1203018182854 [[]] .width = true := by decide
def e1203018192922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203018192922 : Closed e1203018192922 ∧ code e1203018192922 = 5601064704026 := by decide
theorem cert_e1203018192922 : check e1203018192922 [[]] .width = true := by decide
def e1203018197018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203018197018 : Closed e1203018197018 ∧ code e1203018197018 = 5601064708122 := by decide
theorem cert_e1203018197018 : check e1203018197018 [[]] .width = true := by decide
def e1203018198554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203018198554 : Closed e1203018198554 ∧ code e1203018198554 = 5601064709658 := by decide
theorem cert_e1203018198554 : check e1203018198554 [[]] .width = true := by decide
def e1203018200602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203018200602 : Closed e1203018200602 ∧ code e1203018200602 = 5601064711706 := by decide
theorem cert_e1203018200602 : check e1203018200602 [[]] .width = true := by decide
def e1203018283034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203018283034 : Closed e1203018283034 ∧ code e1203018283034 = 5601064794138 := by decide
theorem cert_e1203018283034 : check e1203018283034 [[]] .width = true := by decide
def e1203018318022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203018318022 : Closed e1203018318022 ∧ code e1203018318022 = 5601064829126 := by decide
theorem cert_e1203018318022 : check e1203018318022 [[]] .width = true := by decide
def e1203018338502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203018338502 : Closed e1203018338502 ∧ code e1203018338502 = 5601064849606 := by decide
theorem cert_e1203018338502 : check e1203018338502 [[]] .width = true := by decide
def e1203018340378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203018340378 : Closed e1203018340378 ∧ code e1203018340378 = 5601064851482 := by decide
theorem cert_e1203018340378 : check e1203018340378 [[]] .width = true := by decide
def e1203018341914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203018341914 : Closed e1203018341914 ∧ code e1203018341914 = 5601064853018 := by decide
theorem cert_e1203018341914 : check e1203018341914 [[]] .width = true := by decide
def e1203018350790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203018350790 : Closed e1203018350790 ∧ code e1203018350790 = 5601064861894 := by decide
theorem cert_e1203018350790 : check e1203018350790 [[]] .width = true := by decide
def e1203018358810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203018358810 : Closed e1203018358810 ∧ code e1203018358810 = 5601064869914 := by decide
theorem cert_e1203018358810 : check e1203018358810 [[]] .width = true := by decide
def e1203018358902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203018358902 : Closed e1203018358902 ∧ code e1203018358902 = 5601064870006 := by decide
theorem cert_e1203018358902 : check e1203018358902 [[]] .width = true := by decide
def e1203018359146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203018359146 : Closed e1203018359146 ∧ code e1203018359146 = 5601064870250 := by decide
theorem cert_e1203018359146 : check e1203018359146 [[]] .width = true := by decide
def e1203018359194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203018359194 : Closed e1203018359194 ∧ code e1203018359194 = 5601064870298 := by decide
theorem cert_e1203018359194 : check e1203018359194 [[]] .width = true := by decide
def e1203018363078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203018363078 : Closed e1203018363078 ∧ code e1203018363078 = 5601064874182 := by decide
theorem cert_e1203018363078 : check e1203018363078 [[]] .width = true := by decide
def e1203018370586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203018370586 : Closed e1203018370586 ∧ code e1203018370586 = 5601064881690 := by decide
theorem cert_e1203018370586 : check e1203018370586 [[]] .width = true := by decide
def e1203018379462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203018379462 : Closed e1203018379462 ∧ code e1203018379462 = 5601064890566 := by decide
theorem cert_e1203018379462 : check e1203018379462 [[]] .width = true := by decide
def e1203020611782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203020611782 : Closed e1203020611782 ∧ code e1203020611782 = 5601067122886 := by decide
theorem cert_e1203020611782 : check e1203020611782 [[]] .width = true := by decide
def e1203020642330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203020642330 : Closed e1203020642330 ∧ code e1203020642330 = 5601067153434 := by decide
theorem cert_e1203020642330 : check e1203020642330 [[]] .width = true := by decide
def e1203020677318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203020677318 : Closed e1203020677318 ∧ code e1203020677318 = 5601067188422 := by decide
theorem cert_e1203020677318 : check e1203020677318 [[]] .width = true := by decide
def e1203023347738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203023347738 : Closed e1203023347738 ∧ code e1203023347738 = 5601069858842 := by decide
theorem cert_e1203023347738 : check e1203023347738 [[]] .width = true := by decide
def e1203023347830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1203023347830 : Closed e1203023347830 ∧ code e1203023347830 = 5601069858934 := by decide
theorem cert_e1203023347830 : check e1203023347830 [[]] .width = true := by decide
def e1203023348074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1203023348074 : Closed e1203023348074 ∧ code e1203023348074 = 5601069859178 := by decide
theorem cert_e1203023348074 : check e1203023348074 [[]] .width = true := by decide
def e1203023348122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1203023348122 : Closed e1203023348122 ∧ code e1203023348122 = 5601069859226 := by decide
theorem cert_e1203023348122 : check e1203023348122 [[]] .width = true := by decide
def e1203023349130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e1203023349130 : Closed e1203023349130 ∧ code e1203023349130 = 5601069860234 := by decide
theorem cert_e1203023349130 : check e1203023349130 [[]] .width = true := by decide
def e1203023349154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e1203023349154 : Closed e1203023349154 ∧ code e1203023349154 = 5601069860258 := by decide
theorem cert_e1203023349154 : check e1203023349154 [[]] .width = true := by decide
def e1203023349262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e1203023349262 : Closed e1203023349262 ∧ code e1203023349262 = 5601069860366 := by decide
theorem cert_e1203023349262 : check e1203023349262 [[]] .width = true := by decide
def e1203023349274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203023349274 : Closed e1203023349274 ∧ code e1203023349274 = 5601069860378 := by decide
theorem cert_e1203023349274 : check e1203023349274 [[]] .width = true := by decide
def e1203023349346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e1203023349346 : Closed e1203023349346 ∧ code e1203023349346 = 5601069860450 := by decide
theorem cert_e1203023349346 : check e1203023349346 [[]] .width = true := by decide
def e1203023757510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203023757510 : Closed e1203023757510 ∧ code e1203023757510 = 5601070268614 := by decide
theorem cert_e1203023757510 : check e1203023757510 [[]] .width = true := by decide
def e1203023831066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203023831066 : Closed e1203023831066 ∧ code e1203023831066 = 5601070342170 := by decide
theorem cert_e1203023831066 : check e1203023831066 [[]] .width = true := by decide
def e1203023831158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203023831158 : Closed e1203023831158 ∧ code e1203023831158 = 5601070342262 := by decide
theorem cert_e1203023831158 : check e1203023831158 [[]] .width = true := by decide
def e1203023831402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203023831402 : Closed e1203023831402 ∧ code e1203023831402 = 5601070342506 := by decide
theorem cert_e1203023831402 : check e1203023831402 [[]] .width = true := by decide
def e1203023831450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203023831450 : Closed e1203023831450 ∧ code e1203023831450 = 5601070342554 := by decide
theorem cert_e1203023831450 : check e1203023831450 [[]] .width = true := by decide
def e1203023843526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203023843526 : Closed e1203023843526 ∧ code e1203023843526 = 5601070354630 := by decide
theorem cert_e1203023843526 : check e1203023843526 [[]] .width = true := by decide
def e1203023845402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1203023845402 : Closed e1203023845402 ∧ code e1203023845402 = 5601070356506 := by decide
theorem cert_e1203023845402 : check e1203023845402 [[]] .width = true := by decide
def e1203023846938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1203023846938 : Closed e1203023846938 ∧ code e1203023846938 = 5601070358042 := by decide
theorem cert_e1203023846938 : check e1203023846938 [[]] .width = true := by decide
def e1203023855814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1203023855814 : Closed e1203023855814 ∧ code e1203023855814 = 5601070366918 := by decide
theorem cert_e1203023855814 : check e1203023855814 [[]] .width = true := by decide
def e1203023863834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1203023863834 : Closed e1203023863834 ∧ code e1203023863834 = 5601070374938 := by decide
theorem cert_e1203023863834 : check e1203023863834 [[]] .width = true := by decide
def e1203023863926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1203023863926 : Closed e1203023863926 ∧ code e1203023863926 = 5601070375030 := by decide
theorem cert_e1203023863926 : check e1203023863926 [[]] .width = true := by decide
def e1203023864170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1203023864170 : Closed e1203023864170 ∧ code e1203023864170 = 5601070375274 := by decide
theorem cert_e1203023864170 : check e1203023864170 [[]] .width = true := by decide
def e1203023864218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1203023864218 : Closed e1203023864218 ∧ code e1203023864218 = 5601070375322 := by decide
theorem cert_e1203023864218 : check e1203023864218 [[]] .width = true := by decide
def e1203023868102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1203023868102 : Closed e1203023868102 ∧ code e1203023868102 = 5601070379206 := by decide
theorem cert_e1203023868102 : check e1203023868102 [[]] .width = true := by decide
def e1203024691398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1203024691398 : Closed e1203024691398 ∧ code e1203024691398 = 5601071202502 := by decide
theorem cert_e1203024691398 : check e1203024691398 [[]] .width = true := by decide
def e1203024691926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e1203024691926 : Closed e1203024691926 ∧ code e1203024691926 = 5601071203030 := by decide
theorem cert_e1203024691926 : check e1203024691926 [[]] .width = true := by decide
def e1203024691930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e1203024691930 : Closed e1203024691930 ∧ code e1203024691930 = 5601071203034 := by decide
theorem cert_e1203024691930 : check e1203024691930 [[]] .width = true := by decide
def e1203024691946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e1203024691946 : Closed e1203024691946 ∧ code e1203024691946 = 5601071203050 := by decide
theorem cert_e1203024691946 : check e1203024691946 [[]] .width = true := by decide
def e1203024692022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e1203024692022 : Closed e1203024692022 ∧ code e1203024692022 = 5601071203126 := by decide
theorem cert_e1203024692022 : check e1203024692022 [[]] .width = true := by decide
def e1203024692026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e1203024692026 : Closed e1203024692026 ∧ code e1203024692026 = 5601071203130 := by decide
theorem cert_e1203024692026 : check e1203024692026 [[]] .width = true := by decide
def e1203024692110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e1203024692110 : Closed e1203024692110 ∧ code e1203024692110 = 5601071203214 := by decide
theorem cert_e1203024692110 : check e1203024692110 [[]] .width = true := by decide
def e1203024692122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e1203024692122 : Closed e1203024692122 ∧ code e1203024692122 = 5601071203226 := by decide
theorem cert_e1203024692122 : check e1203024692122 [[]] .width = true := by decide
def e1203024694042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e1203024694042 : Closed e1203024694042 ∧ code e1203024694042 = 5601071205146 := by decide
theorem cert_e1203024694042 : check e1203024694042 [[]] .width = true := by decide
def e1203024694086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e1203024694086 : Closed e1203024694086 ∧ code e1203024694086 = 5601071205190 := by decide
theorem cert_e1203024694086 : check e1203024694086 [[]] .width = true := by decide
def e1203024694198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e1203024694198 : Closed e1203024694198 ∧ code e1203024694198 = 5601071205302 := by decide
theorem cert_e1203024694198 : check e1203024694198 [[]] .width = true := by decide
def e1203024694326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e1203024694326 : Closed e1203024694326 ∧ code e1203024694326 = 5601071205430 := by decide
theorem cert_e1203024694326 : check e1203024694326 [[]] .width = true := by decide
def e1203024694330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e1203024694330 : Closed e1203024694330 ∧ code e1203024694330 = 5601071205434 := by decide
theorem cert_e1203024694330 : check e1203024694330 [[]] .width = true := by decide
def e1203024694470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203024694470 : Closed e1203024694470 ∧ code e1203024694470 = 5601071205574 := by decide
theorem cert_e1203024694470 : check e1203024694470 [[]] .width = true := by decide
def e1203024694810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1203024694810 : Closed e1203024694810 ∧ code e1203024694810 = 5601071205914 := by decide
theorem cert_e1203024694810 : check e1203024694810 [[]] .width = true := by decide
def e1203024694902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e1203024694902 : Closed e1203024694902 ∧ code e1203024694902 = 5601071206006 := by decide
theorem cert_e1203024694902 : check e1203024694902 [[]] .width = true := by decide
def e1203024702490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e1203024702490 : Closed e1203024702490 ∧ code e1203024702490 = 5601071213594 := by decide
theorem cert_e1203024702490 : check e1203024702490 [[]] .width = true := by decide
def e1203024702534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e1203024702534 : Closed e1203024702534 ∧ code e1203024702534 = 5601071213638 := by decide
theorem cert_e1203024702534 : check e1203024702534 [[]] .width = true := by decide
def e1203024702562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e1203024702562 : Closed e1203024702562 ∧ code e1203024702562 = 5601071213666 := by decide
theorem cert_e1203024702562 : check e1203024702562 [[]] .width = true := by decide
def e1203024702726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e1203024702726 : Closed e1203024702726 ∧ code e1203024702726 = 5601071213830 := by decide
theorem cert_e1203024702726 : check e1203024702726 [[]] .width = true := by decide
def e1203024703518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e1203024703518 : Closed e1203024703518 ∧ code e1203024703518 = 5601071214622 := by decide
theorem cert_e1203024703518 : check e1203024703518 [[]] .width = true := by decide
def e1203024703686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1203024703686 : Closed e1203024703686 ∧ code e1203024703686 = 5601071214790 := by decide
theorem cert_e1203024703686 : check e1203024703686 [[]] .width = true := by decide
end Blc.Floor42
