import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1105807082198 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105807082198 : Closed e1105807082198 ∧ code e1105807082198 = 5503853593302 := by decide
theorem cert_e1105807082198 : check e1105807082198 [[]] .width = true := by decide
def e1105807082202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105807082202 : Closed e1105807082202 ∧ code e1105807082202 = 5503853593306 := by decide
theorem cert_e1105807082202 : check e1105807082202 [[]] .width = true := by decide
def e1105807082218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105807082218 : Closed e1105807082218 ∧ code e1105807082218 = 5503853593322 := by decide
theorem cert_e1105807082218 : check e1105807082218 [[]] .width = true := by decide
def e1105807082294 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105807082294 : Closed e1105807082294 ∧ code e1105807082294 = 5503853593398 := by decide
theorem cert_e1105807082294 : check e1105807082294 [[]] .width = true := by decide
def e1105807082298 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105807082298 : Closed e1105807082298 ∧ code e1105807082298 = 5503853593402 := by decide
theorem cert_e1105807082298 : check e1105807082298 [[]] .width = true := by decide
def e1105807082382 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105807082382 : Closed e1105807082382 ∧ code e1105807082382 = 5503853593486 := by decide
theorem cert_e1105807082382 : check e1105807082382 [[]] .width = true := by decide
def e1105807082394 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105807082394 : Closed e1105807082394 ∧ code e1105807082394 = 5503853593498 := by decide
theorem cert_e1105807082394 : check e1105807082394 [[]] .width = true := by decide
def e1105807084314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105807084314 : Closed e1105807084314 ∧ code e1105807084314 = 5503853595418 := by decide
theorem cert_e1105807084314 : check e1105807084314 [[]] .width = true := by decide
def e1105807084358 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105807084358 : Closed e1105807084358 ∧ code e1105807084358 = 5503853595462 := by decide
theorem cert_e1105807084358 : check e1105807084358 [[]] .width = true := by decide
def e1105807084598 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105807084598 : Closed e1105807084598 ∧ code e1105807084598 = 5503853595702 := by decide
theorem cert_e1105807084598 : check e1105807084598 [[]] .width = true := by decide
def e1105807084602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105807084602 : Closed e1105807084602 ∧ code e1105807084602 = 5503853595706 := by decide
theorem cert_e1105807084602 : check e1105807084602 [[]] .width = true := by decide
def e1105807084742 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105807084742 : Closed e1105807084742 ∧ code e1105807084742 = 5503853595846 := by decide
theorem cert_e1105807084742 : check e1105807084742 [[]] .width = true := by decide
def e1105833418778 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105833418778 : Closed e1105833418778 ∧ code e1105833418778 = 5503879929882 := by decide
theorem cert_e1105833418778 : check e1105833418778 [[]] .width = true := by decide
def e1105833418870 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105833418870 : Closed e1105833418870 ∧ code e1105833418870 = 5503879929974 := by decide
theorem cert_e1105833418870 : check e1105833418870 [[]] .width = true := by decide
def e1105833419114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105833419114 : Closed e1105833419114 ∧ code e1105833419114 = 5503879930218 := by decide
theorem cert_e1105833419114 : check e1105833419114 [[]] .width = true := by decide
def e1105833419162 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105833419162 : Closed e1105833419162 ∧ code e1105833419162 = 5503879930266 := by decide
theorem cert_e1105833419162 : check e1105833419162 [[]] .width = true := by decide
def e1105833451546 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105833451546 : Closed e1105833451546 ∧ code e1105833451546 = 5503879962650 := by decide
theorem cert_e1105833451546 : check e1105833451546 [[]] .width = true := by decide
def e1105833451638 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105833451638 : Closed e1105833451638 ∧ code e1105833451638 = 5503879962742 := by decide
theorem cert_e1105833451638 : check e1105833451638 [[]] .width = true := by decide
def e1105833451882 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105833451882 : Closed e1105833451882 ∧ code e1105833451882 = 5503879962986 := by decide
theorem cert_e1105833451882 : check e1105833451882 [[]] .width = true := by decide
def e1105833451930 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105833451930 : Closed e1105833451930 ∧ code e1105833451930 = 5503879963034 := by decide
theorem cert_e1105833451930 : check e1105833451930 [[]] .width = true := by decide
def e1105834991642 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105834991642 : Closed e1105834991642 ∧ code e1105834991642 = 5503881502746 := by decide
theorem cert_e1105834991642 : check e1105834991642 [[]] .width = true := by decide
def e1105834991734 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105834991734 : Closed e1105834991734 ∧ code e1105834991734 = 5503881502838 := by decide
theorem cert_e1105834991734 : check e1105834991734 [[]] .width = true := by decide
def e1105834991978 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105834991978 : Closed e1105834991978 ∧ code e1105834991978 = 5503881503082 := by decide
theorem cert_e1105834991978 : check e1105834991978 [[]] .width = true := by decide
def e1105834992026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105834992026 : Closed e1105834992026 ∧ code e1105834992026 = 5503881503130 := by decide
theorem cert_e1105834992026 : check e1105834992026 [[]] .width = true := by decide
def e1105835040794 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105835040794 : Closed e1105835040794 ∧ code e1105835040794 = 5503881551898 := by decide
theorem cert_e1105835040794 : check e1105835040794 [[]] .width = true := by decide
def e1105835040886 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105835040886 : Closed e1105835040886 ∧ code e1105835040886 = 5503881551990 := by decide
theorem cert_e1105835040886 : check e1105835040886 [[]] .width = true := by decide
def e1105835041130 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105835041130 : Closed e1105835041130 ∧ code e1105835041130 = 5503881552234 := by decide
theorem cert_e1105835041130 : check e1105835041130 [[]] .width = true := by decide
def e1105835041178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105835041178 : Closed e1105835041178 ∧ code e1105835041178 = 5503881552282 := by decide
theorem cert_e1105835041178 : check e1105835041178 [[]] .width = true := by decide
def e1105846001690 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105846001690 : Closed e1105846001690 ∧ code e1105846001690 = 5503892512794 := by decide
theorem cert_e1105846001690 : check e1105846001690 [[]] .width = true := by decide
def e1105846001782 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105846001782 : Closed e1105846001782 ∧ code e1105846001782 = 5503892512886 := by decide
theorem cert_e1105846001782 : check e1105846001782 [[]] .width = true := by decide
def e1105846002026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105846002026 : Closed e1105846002026 ∧ code e1105846002026 = 5503892513130 := by decide
theorem cert_e1105846002026 : check e1105846002026 [[]] .width = true := by decide
def e1105846002074 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105846002074 : Closed e1105846002074 ∧ code e1105846002074 = 5503892513178 := by decide
theorem cert_e1105846002074 : check e1105846002074 [[]] .width = true := by decide
def e1105848631494 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105848631494 : Closed e1105848631494 ∧ code e1105848631494 = 5503895142598 := by decide
theorem cert_e1105848631494 : check e1105848631494 [[]] .width = true := by decide
def e1105848632022 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105848632022 : Closed e1105848632022 ∧ code e1105848632022 = 5503895143126 := by decide
theorem cert_e1105848632022 : check e1105848632022 [[]] .width = true := by decide
def e1105848632026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105848632026 : Closed e1105848632026 ∧ code e1105848632026 = 5503895143130 := by decide
theorem cert_e1105848632026 : check e1105848632026 [[]] .width = true := by decide
def e1105848632042 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105848632042 : Closed e1105848632042 ∧ code e1105848632042 = 5503895143146 := by decide
theorem cert_e1105848632042 : check e1105848632042 [[]] .width = true := by decide
def e1105848632118 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105848632118 : Closed e1105848632118 ∧ code e1105848632118 = 5503895143222 := by decide
theorem cert_e1105848632118 : check e1105848632118 [[]] .width = true := by decide
def e1105848632122 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105848632122 : Closed e1105848632122 ∧ code e1105848632122 = 5503895143226 := by decide
theorem cert_e1105848632122 : check e1105848632122 [[]] .width = true := by decide
def e1105848632206 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105848632206 : Closed e1105848632206 ∧ code e1105848632206 = 5503895143310 := by decide
theorem cert_e1105848632206 : check e1105848632206 [[]] .width = true := by decide
def e1105848632218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105848632218 : Closed e1105848632218 ∧ code e1105848632218 = 5503895143322 := by decide
theorem cert_e1105848632218 : check e1105848632218 [[]] .width = true := by decide
def e1105848634138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105848634138 : Closed e1105848634138 ∧ code e1105848634138 = 5503895145242 := by decide
theorem cert_e1105848634138 : check e1105848634138 [[]] .width = true := by decide
def e1105848634182 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105848634182 : Closed e1105848634182 ∧ code e1105848634182 = 5503895145286 := by decide
theorem cert_e1105848634182 : check e1105848634182 [[]] .width = true := by decide
def e1105848634422 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105848634422 : Closed e1105848634422 ∧ code e1105848634422 = 5503895145526 := by decide
theorem cert_e1105848634422 : check e1105848634422 [[]] .width = true := by decide
def e1105848634426 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105848634426 : Closed e1105848634426 ∧ code e1105848634426 = 5503895145530 := by decide
theorem cert_e1105848634426 : check e1105848634426 [[]] .width = true := by decide
def e1105848634566 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105848634566 : Closed e1105848634566 ∧ code e1105848634566 = 5503895145670 := by decide
theorem cert_e1105848634566 : check e1105848634566 [[]] .width = true := by decide
def e1105848754202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105848754202 : Closed e1105848754202 ∧ code e1105848754202 = 5503895265306 := by decide
theorem cert_e1105848754202 : check e1105848754202 [[]] .width = true := by decide
def e1105848754294 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105848754294 : Closed e1105848754294 ∧ code e1105848754294 = 5503895265398 := by decide
theorem cert_e1105848754294 : check e1105848754294 [[]] .width = true := by decide
def e1105848754538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105848754538 : Closed e1105848754538 ∧ code e1105848754538 = 5503895265642 := by decide
theorem cert_e1105848754538 : check e1105848754538 [[]] .width = true := by decide
def e1105848754586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105848754586 : Closed e1105848754586 ∧ code e1105848754586 = 5503895265690 := by decide
theorem cert_e1105848754586 : check e1105848754586 [[]] .width = true := by decide
def e1105848893638 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105848893638 : Closed e1105848893638 ∧ code e1105848893638 = 5503895404742 := by decide
theorem cert_e1105848893638 : check e1105848893638 [[]] .width = true := by decide
def e1105848894166 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105848894166 : Closed e1105848894166 ∧ code e1105848894166 = 5503895405270 := by decide
theorem cert_e1105848894166 : check e1105848894166 [[]] .width = true := by decide
def e1105848894170 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105848894170 : Closed e1105848894170 ∧ code e1105848894170 = 5503895405274 := by decide
theorem cert_e1105848894170 : check e1105848894170 [[]] .width = true := by decide
def e1105848894186 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105848894186 : Closed e1105848894186 ∧ code e1105848894186 = 5503895405290 := by decide
theorem cert_e1105848894186 : check e1105848894186 [[]] .width = true := by decide
def e1105848894262 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105848894262 : Closed e1105848894262 ∧ code e1105848894262 = 5503895405366 := by decide
theorem cert_e1105848894262 : check e1105848894262 [[]] .width = true := by decide
def e1105848894266 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105848894266 : Closed e1105848894266 ∧ code e1105848894266 = 5503895405370 := by decide
theorem cert_e1105848894266 : check e1105848894266 [[]] .width = true := by decide
def e1105848894350 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105848894350 : Closed e1105848894350 ∧ code e1105848894350 = 5503895405454 := by decide
theorem cert_e1105848894350 : check e1105848894350 [[]] .width = true := by decide
def e1105848894362 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105848894362 : Closed e1105848894362 ∧ code e1105848894362 = 5503895405466 := by decide
theorem cert_e1105848894362 : check e1105848894362 [[]] .width = true := by decide
def e1105848896282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105848896282 : Closed e1105848896282 ∧ code e1105848896282 = 5503895407386 := by decide
theorem cert_e1105848896282 : check e1105848896282 [[]] .width = true := by decide
def e1105848896326 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105848896326 : Closed e1105848896326 ∧ code e1105848896326 = 5503895407430 := by decide
theorem cert_e1105848896326 : check e1105848896326 [[]] .width = true := by decide
def e1105848896566 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105848896566 : Closed e1105848896566 ∧ code e1105848896566 = 5503895407670 := by decide
theorem cert_e1105848896566 : check e1105848896566 [[]] .width = true := by decide
def e1105848896570 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105848896570 : Closed e1105848896570 ∧ code e1105848896570 = 5503895407674 := by decide
theorem cert_e1105848896570 : check e1105848896570 [[]] .width = true := by decide
def e1105848896710 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105848896710 : Closed e1105848896710 ∧ code e1105848896710 = 5503895407814 := by decide
theorem cert_e1105848896710 : check e1105848896710 [[]] .width = true := by decide
def e1105849671706 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105849671706 : Closed e1105849671706 ∧ code e1105849671706 = 5503896182810 := by decide
theorem cert_e1105849671706 : check e1105849671706 [[]] .width = true := by decide
def e1105849671798 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105849671798 : Closed e1105849671798 ∧ code e1105849671798 = 5503896182902 := by decide
theorem cert_e1105849671798 : check e1105849671798 [[]] .width = true := by decide
def e1105849672042 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105849672042 : Closed e1105849672042 ∧ code e1105849672042 = 5503896183146 := by decide
theorem cert_e1105849672042 : check e1105849672042 [[]] .width = true := by decide
def e1105849672090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105849672090 : Closed e1105849672090 ∧ code e1105849672090 = 5503896183194 := by decide
theorem cert_e1105849672090 : check e1105849672090 [[]] .width = true := by decide
def e1105850728646 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105850728646 : Closed e1105850728646 ∧ code e1105850728646 = 5503897239750 := by decide
theorem cert_e1105850728646 : check e1105850728646 [[]] .width = true := by decide
def e1105850729174 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105850729174 : Closed e1105850729174 ∧ code e1105850729174 = 5503897240278 := by decide
theorem cert_e1105850729174 : check e1105850729174 [[]] .width = true := by decide
def e1105850729178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105850729178 : Closed e1105850729178 ∧ code e1105850729178 = 5503897240282 := by decide
theorem cert_e1105850729178 : check e1105850729178 [[]] .width = true := by decide
def e1105850729194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105850729194 : Closed e1105850729194 ∧ code e1105850729194 = 5503897240298 := by decide
theorem cert_e1105850729194 : check e1105850729194 [[]] .width = true := by decide
def e1105850729270 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105850729270 : Closed e1105850729270 ∧ code e1105850729270 = 5503897240374 := by decide
theorem cert_e1105850729270 : check e1105850729270 [[]] .width = true := by decide
def e1105850729274 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105850729274 : Closed e1105850729274 ∧ code e1105850729274 = 5503897240378 := by decide
theorem cert_e1105850729274 : check e1105850729274 [[]] .width = true := by decide
def e1105850729358 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105850729358 : Closed e1105850729358 ∧ code e1105850729358 = 5503897240462 := by decide
theorem cert_e1105850729358 : check e1105850729358 [[]] .width = true := by decide
def e1105850729370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105850729370 : Closed e1105850729370 ∧ code e1105850729370 = 5503897240474 := by decide
theorem cert_e1105850729370 : check e1105850729370 [[]] .width = true := by decide
def e1105850731290 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105850731290 : Closed e1105850731290 ∧ code e1105850731290 = 5503897242394 := by decide
theorem cert_e1105850731290 : check e1105850731290 [[]] .width = true := by decide
def e1105850731334 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105850731334 : Closed e1105850731334 ∧ code e1105850731334 = 5503897242438 := by decide
theorem cert_e1105850731334 : check e1105850731334 [[]] .width = true := by decide
def e1105850731574 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105850731574 : Closed e1105850731574 ∧ code e1105850731574 = 5503897242678 := by decide
theorem cert_e1105850731574 : check e1105850731574 [[]] .width = true := by decide
def e1105850731578 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105850731578 : Closed e1105850731578 ∧ code e1105850731578 = 5503897242682 := by decide
theorem cert_e1105850731578 : check e1105850731578 [[]] .width = true := by decide
def e1105850731718 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105850731718 : Closed e1105850731718 ∧ code e1105850731718 = 5503897242822 := by decide
theorem cert_e1105850731718 : check e1105850731718 [[]] .width = true := by decide
def e1105851080730 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105851080730 : Closed e1105851080730 ∧ code e1105851080730 = 5503897591834 := by decide
theorem cert_e1105851080730 : check e1105851080730 [[]] .width = true := by decide
def e1105851080822 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105851080822 : Closed e1105851080822 ∧ code e1105851080822 = 5503897591926 := by decide
theorem cert_e1105851080822 : check e1105851080822 [[]] .width = true := by decide
def e1105851081066 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105851081066 : Closed e1105851081066 ∧ code e1105851081066 = 5503897592170 := by decide
theorem cert_e1105851081066 : check e1105851081066 [[]] .width = true := by decide
def e1105851081114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105851081114 : Closed e1105851081114 ∧ code e1105851081114 = 5503897592218 := by decide
theorem cert_e1105851081114 : check e1105851081114 [[]] .width = true := by decide
def e1105851121862 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105851121862 : Closed e1105851121862 ∧ code e1105851121862 = 5503897632966 := by decide
theorem cert_e1105851121862 : check e1105851121862 [[]] .width = true := by decide
def e1105851122390 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105851122390 : Closed e1105851122390 ∧ code e1105851122390 = 5503897633494 := by decide
theorem cert_e1105851122390 : check e1105851122390 [[]] .width = true := by decide
def e1105851122394 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105851122394 : Closed e1105851122394 ∧ code e1105851122394 = 5503897633498 := by decide
theorem cert_e1105851122394 : check e1105851122394 [[]] .width = true := by decide
def e1105851122410 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105851122410 : Closed e1105851122410 ∧ code e1105851122410 = 5503897633514 := by decide
theorem cert_e1105851122410 : check e1105851122410 [[]] .width = true := by decide
def e1105851122486 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105851122486 : Closed e1105851122486 ∧ code e1105851122486 = 5503897633590 := by decide
theorem cert_e1105851122486 : check e1105851122486 [[]] .width = true := by decide
def e1105851122490 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105851122490 : Closed e1105851122490 ∧ code e1105851122490 = 5503897633594 := by decide
theorem cert_e1105851122490 : check e1105851122490 [[]] .width = true := by decide
def e1105851122574 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105851122574 : Closed e1105851122574 ∧ code e1105851122574 = 5503897633678 := by decide
theorem cert_e1105851122574 : check e1105851122574 [[]] .width = true := by decide
def e1105851122586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105851122586 : Closed e1105851122586 ∧ code e1105851122586 = 5503897633690 := by decide
theorem cert_e1105851122586 : check e1105851122586 [[]] .width = true := by decide
def e1105851124506 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105851124506 : Closed e1105851124506 ∧ code e1105851124506 = 5503897635610 := by decide
theorem cert_e1105851124506 : check e1105851124506 [[]] .width = true := by decide
def e1105851124550 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105851124550 : Closed e1105851124550 ∧ code e1105851124550 = 5503897635654 := by decide
theorem cert_e1105851124550 : check e1105851124550 [[]] .width = true := by decide
def e1105851124790 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105851124790 : Closed e1105851124790 ∧ code e1105851124790 = 5503897635894 := by decide
theorem cert_e1105851124790 : check e1105851124790 [[]] .width = true := by decide
def e1105851124794 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105851124794 : Closed e1105851124794 ∧ code e1105851124794 = 5503897635898 := by decide
theorem cert_e1105851124794 : check e1105851124794 [[]] .width = true := by decide
def e1105851124934 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105851124934 : Closed e1105851124934 ∧ code e1105851124934 = 5503897636038 := by decide
theorem cert_e1105851124934 : check e1105851124934 [[]] .width = true := by decide
def e1105851539482 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105851539482 : Closed e1105851539482 ∧ code e1105851539482 = 5503898050586 := by decide
theorem cert_e1105851539482 : check e1105851539482 [[]] .width = true := by decide
def e1105851539574 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105851539574 : Closed e1105851539574 ∧ code e1105851539574 = 5503898050678 := by decide
theorem cert_e1105851539574 : check e1105851539574 [[]] .width = true := by decide
def e1105851539818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105851539818 : Closed e1105851539818 ∧ code e1105851539818 = 5503898050922 := by decide
theorem cert_e1105851539818 : check e1105851539818 [[]] .width = true := by decide
def e1105851539866 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105851539866 : Closed e1105851539866 ∧ code e1105851539866 = 5503898050970 := by decide
theorem cert_e1105851539866 : check e1105851539866 [[]] .width = true := by decide
def e1105851555866 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105851555866 : Closed e1105851555866 ∧ code e1105851555866 = 5503898066970 := by decide
theorem cert_e1105851555866 : check e1105851555866 [[]] .width = true := by decide
def e1105851555958 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105851555958 : Closed e1105851555958 ∧ code e1105851555958 = 5503898067062 := by decide
theorem cert_e1105851555958 : check e1105851555958 [[]] .width = true := by decide
def e1105851556202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105851556202 : Closed e1105851556202 ∧ code e1105851556202 = 5503898067306 := by decide
theorem cert_e1105851556202 : check e1105851556202 [[]] .width = true := by decide
def e1105851556250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105851556250 : Closed e1105851556250 ∧ code e1105851556250 = 5503898067354 := by decide
theorem cert_e1105851556250 : check e1105851556250 [[]] .width = true := by decide
def e1105851899930 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105851899930 : Closed e1105851899930 ∧ code e1105851899930 = 5503898411034 := by decide
theorem cert_e1105851899930 : check e1105851899930 [[]] .width = true := by decide
def e1105851900022 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105851900022 : Closed e1105851900022 ∧ code e1105851900022 = 5503898411126 := by decide
theorem cert_e1105851900022 : check e1105851900022 [[]] .width = true := by decide
def e1105851900266 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105851900266 : Closed e1105851900266 ∧ code e1105851900266 = 5503898411370 := by decide
theorem cert_e1105851900266 : check e1105851900266 [[]] .width = true := by decide
def e1105851900314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105851900314 : Closed e1105851900314 ∧ code e1105851900314 = 5503898411418 := by decide
theorem cert_e1105851900314 : check e1105851900314 [[]] .width = true := by decide
def e1105852039366 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105852039366 : Closed e1105852039366 ∧ code e1105852039366 = 5503898550470 := by decide
theorem cert_e1105852039366 : check e1105852039366 [[]] .width = true := by decide
def e1105852039894 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105852039894 : Closed e1105852039894 ∧ code e1105852039894 = 5503898550998 := by decide
theorem cert_e1105852039894 : check e1105852039894 [[]] .width = true := by decide
def e1105852039898 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105852039898 : Closed e1105852039898 ∧ code e1105852039898 = 5503898551002 := by decide
theorem cert_e1105852039898 : check e1105852039898 [[]] .width = true := by decide
def e1105852039914 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105852039914 : Closed e1105852039914 ∧ code e1105852039914 = 5503898551018 := by decide
theorem cert_e1105852039914 : check e1105852039914 [[]] .width = true := by decide
def e1105852039990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105852039990 : Closed e1105852039990 ∧ code e1105852039990 = 5503898551094 := by decide
theorem cert_e1105852039990 : check e1105852039990 [[]] .width = true := by decide
def e1105852039994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105852039994 : Closed e1105852039994 ∧ code e1105852039994 = 5503898551098 := by decide
theorem cert_e1105852039994 : check e1105852039994 [[]] .width = true := by decide
def e1105852040078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105852040078 : Closed e1105852040078 ∧ code e1105852040078 = 5503898551182 := by decide
theorem cert_e1105852040078 : check e1105852040078 [[]] .width = true := by decide
def e1105852040090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105852040090 : Closed e1105852040090 ∧ code e1105852040090 = 5503898551194 := by decide
theorem cert_e1105852040090 : check e1105852040090 [[]] .width = true := by decide
def e1105852042010 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105852042010 : Closed e1105852042010 ∧ code e1105852042010 = 5503898553114 := by decide
theorem cert_e1105852042010 : check e1105852042010 [[]] .width = true := by decide
def e1105852042054 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105852042054 : Closed e1105852042054 ∧ code e1105852042054 = 5503898553158 := by decide
theorem cert_e1105852042054 : check e1105852042054 [[]] .width = true := by decide
def e1105852042294 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105852042294 : Closed e1105852042294 ∧ code e1105852042294 = 5503898553398 := by decide
theorem cert_e1105852042294 : check e1105852042294 [[]] .width = true := by decide
def e1105852042298 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105852042298 : Closed e1105852042298 ∧ code e1105852042298 = 5503898553402 := by decide
theorem cert_e1105852042298 : check e1105852042298 [[]] .width = true := by decide
def e1105852042438 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105852042438 : Closed e1105852042438 ∧ code e1105852042438 = 5503898553542 := by decide
theorem cert_e1105852042438 : check e1105852042438 [[]] .width = true := by decide
def e1105852129306 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105852129306 : Closed e1105852129306 ∧ code e1105852129306 = 5503898640410 := by decide
theorem cert_e1105852129306 : check e1105852129306 [[]] .width = true := by decide
def e1105852129398 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105852129398 : Closed e1105852129398 ∧ code e1105852129398 = 5503898640502 := by decide
theorem cert_e1105852129398 : check e1105852129398 [[]] .width = true := by decide
def e1105852129642 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105852129642 : Closed e1105852129642 ∧ code e1105852129642 = 5503898640746 := by decide
theorem cert_e1105852129642 : check e1105852129642 [[]] .width = true := by decide
def e1105852129690 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105852129690 : Closed e1105852129690 ∧ code e1105852129690 = 5503898640794 := by decide
theorem cert_e1105852129690 : check e1105852129690 [[]] .width = true := by decide
def e1105852170438 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105852170438 : Closed e1105852170438 ∧ code e1105852170438 = 5503898681542 := by decide
theorem cert_e1105852170438 : check e1105852170438 [[]] .width = true := by decide
def e1105852170966 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105852170966 : Closed e1105852170966 ∧ code e1105852170966 = 5503898682070 := by decide
theorem cert_e1105852170966 : check e1105852170966 [[]] .width = true := by decide
def e1105852170970 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105852170970 : Closed e1105852170970 ∧ code e1105852170970 = 5503898682074 := by decide
theorem cert_e1105852170970 : check e1105852170970 [[]] .width = true := by decide
def e1105852170986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105852170986 : Closed e1105852170986 ∧ code e1105852170986 = 5503898682090 := by decide
theorem cert_e1105852170986 : check e1105852170986 [[]] .width = true := by decide
def e1105852171062 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105852171062 : Closed e1105852171062 ∧ code e1105852171062 = 5503898682166 := by decide
theorem cert_e1105852171062 : check e1105852171062 [[]] .width = true := by decide
def e1105852171066 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105852171066 : Closed e1105852171066 ∧ code e1105852171066 = 5503898682170 := by decide
theorem cert_e1105852171066 : check e1105852171066 [[]] .width = true := by decide
def e1105852171150 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105852171150 : Closed e1105852171150 ∧ code e1105852171150 = 5503898682254 := by decide
theorem cert_e1105852171150 : check e1105852171150 [[]] .width = true := by decide
def e1105852171162 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105852171162 : Closed e1105852171162 ∧ code e1105852171162 = 5503898682266 := by decide
theorem cert_e1105852171162 : check e1105852171162 [[]] .width = true := by decide
def e1105852173082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105852173082 : Closed e1105852173082 ∧ code e1105852173082 = 5503898684186 := by decide
theorem cert_e1105852173082 : check e1105852173082 [[]] .width = true := by decide
def e1105852173126 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105852173126 : Closed e1105852173126 ∧ code e1105852173126 = 5503898684230 := by decide
theorem cert_e1105852173126 : check e1105852173126 [[]] .width = true := by decide
def e1105852173366 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105852173366 : Closed e1105852173366 ∧ code e1105852173366 = 5503898684470 := by decide
theorem cert_e1105852173366 : check e1105852173366 [[]] .width = true := by decide
def e1105852173370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105852173370 : Closed e1105852173370 ∧ code e1105852173370 = 5503898684474 := by decide
theorem cert_e1105852173370 : check e1105852173370 [[]] .width = true := by decide
def e1105852173510 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105852173510 : Closed e1105852173510 ∧ code e1105852173510 = 5503898684614 := by decide
theorem cert_e1105852173510 : check e1105852173510 [[]] .width = true := by decide
def e1105861214406 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105861214406 : Closed e1105861214406 ∧ code e1105861214406 = 5503907725510 := by decide
theorem cert_e1105861214406 : check e1105861214406 [[]] .width = true := by decide
def e1105861214934 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105861214934 : Closed e1105861214934 ∧ code e1105861214934 = 5503907726038 := by decide
theorem cert_e1105861214934 : check e1105861214934 [[]] .width = true := by decide
def e1105861214938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105861214938 : Closed e1105861214938 ∧ code e1105861214938 = 5503907726042 := by decide
theorem cert_e1105861214938 : check e1105861214938 [[]] .width = true := by decide
def e1105861214954 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105861214954 : Closed e1105861214954 ∧ code e1105861214954 = 5503907726058 := by decide
theorem cert_e1105861214954 : check e1105861214954 [[]] .width = true := by decide
def e1105861215030 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105861215030 : Closed e1105861215030 ∧ code e1105861215030 = 5503907726134 := by decide
theorem cert_e1105861215030 : check e1105861215030 [[]] .width = true := by decide
def e1105861215034 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e1105861215034 : Closed e1105861215034 ∧ code e1105861215034 = 5503907726138 := by decide
theorem cert_e1105861215034 : check e1105861215034 [[]] .width = true := by decide
def e1105861215118 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e1105861215118 : Closed e1105861215118 ∧ code e1105861215118 = 5503907726222 := by decide
theorem cert_e1105861215118 : check e1105861215118 [[]] .width = true := by decide
def e1105861215130 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e1105861215130 : Closed e1105861215130 ∧ code e1105861215130 = 5503907726234 := by decide
theorem cert_e1105861215130 : check e1105861215130 [[]] .width = true := by decide
def e1105861217050 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e1105861217050 : Closed e1105861217050 ∧ code e1105861217050 = 5503907728154 := by decide
theorem cert_e1105861217050 : check e1105861217050 [[]] .width = true := by decide
def e1105861217094 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e1105861217094 : Closed e1105861217094 ∧ code e1105861217094 = 5503907728198 := by decide
theorem cert_e1105861217094 : check e1105861217094 [[]] .width = true := by decide
def e1105861217334 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e1105861217334 : Closed e1105861217334 ∧ code e1105861217334 = 5503907728438 := by decide
theorem cert_e1105861217334 : check e1105861217334 [[]] .width = true := by decide
def e1105861217338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e1105861217338 : Closed e1105861217338 ∧ code e1105861217338 = 5503907728442 := by decide
theorem cert_e1105861217338 : check e1105861217338 [[]] .width = true := by decide
def e1105861217478 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1105861217478 : Closed e1105861217478 ∧ code e1105861217478 = 5503907728582 := by decide
theorem cert_e1105861217478 : check e1105861217478 [[]] .width = true := by decide
def e1105861337114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1105861337114 : Closed e1105861337114 ∧ code e1105861337114 = 5503907848218 := by decide
theorem cert_e1105861337114 : check e1105861337114 [[]] .width = true := by decide
def e1105861337206 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1105861337206 : Closed e1105861337206 ∧ code e1105861337206 = 5503907848310 := by decide
theorem cert_e1105861337206 : check e1105861337206 [[]] .width = true := by decide
def e1105861337450 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1105861337450 : Closed e1105861337450 ∧ code e1105861337450 = 5503907848554 := by decide
theorem cert_e1105861337450 : check e1105861337450 [[]] .width = true := by decide
def e1105861337498 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1105861337498 : Closed e1105861337498 ∧ code e1105861337498 = 5503907848602 := by decide
theorem cert_e1105861337498 : check e1105861337498 [[]] .width = true := by decide
def e1105861476550 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e1105861476550 : Closed e1105861476550 ∧ code e1105861476550 = 5503907987654 := by decide
theorem cert_e1105861476550 : check e1105861476550 [[]] .width = true := by decide
def e1105861477078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e1105861477078 : Closed e1105861477078 ∧ code e1105861477078 = 5503907988182 := by decide
theorem cert_e1105861477078 : check e1105861477078 [[]] .width = true := by decide
def e1105861477082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e1105861477082 : Closed e1105861477082 ∧ code e1105861477082 = 5503907988186 := by decide
theorem cert_e1105861477082 : check e1105861477082 [[]] .width = true := by decide
def e1105861477098 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e1105861477098 : Closed e1105861477098 ∧ code e1105861477098 = 5503907988202 := by decide
theorem cert_e1105861477098 : check e1105861477098 [[]] .width = true := by decide
def e1105861477174 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e1105861477174 : Closed e1105861477174 ∧ code e1105861477174 = 5503907988278 := by decide
theorem cert_e1105861477174 : check e1105861477174 [[]] .width = true := by decide
end Blc.Floor42
