import R1196692655738V0
import R1196692655738K0
import R1196692655738st0
import R1196692655738hs0
import CodeBridge
import Batch081
namespace Certgen.R1196692655738
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 72,.app 2 63,.app 3 26,.app 4 23,.app 5 11,.lam 6,.app 7 10,.app 8 9,.var 0,.var 0,.var 0,.lam 12,.lam 13,.app 14 15,.var 1,.lam 16,.app 17 18,.var 0,.app 19 20,.var 1,.app 21 22,.var 2,.var 0,.lam 24,.lam 25,.var 1,.lam 27,.app 28 33,.app 29 30,.var 0,.lam 31,.lam 32,.var 1,.lam 34,.app 35 40,.app 36 37,.var 0,.lam 38,.lam 39,.var 1,.lam 41,.app 42 47,.app 43 44,.var 0,.lam 45,.lam 46,.var 0,.lam 48,.app 49 54,.app 50 51,.var 0,.lam 52,.lam 53,.var 1,.app 55 59,.lam 56,.app 57 58,.var 0,.var 0,.lam 60,.app 61 62,.var 0,.var 0,.app 64 68,.lam 65,.app 66 67,.var 0,.var 0,.lam 69,.app 70 71,.var 0,.var 0,.lam 73,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 150 then (if i < 80 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (st60[i-60]?.getD entry))) else (if i < 120 then (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)) else (if i < 140 then (st120[i-120]?.getD entry) else (st140[i-140]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 80 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (hs60[i-60]?.getD []))) else (if i < 120 then (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])) else (if i < 140 then (hs120[i-120]?.getD []) else (hs140[i-140]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R1196692655738
