import Tables
import Batch074
namespace Blc.Floor42.Grades074
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1196585061998 : ¬ IsSelfInterpreter e1196585061998 := cutM1_2 (by decide)
#print axioms ex_e1196585061998
theorem ex_e1196584689070 : ¬ IsSelfInterpreter e1196584689070 := cutM4_1 (by decide)
#print axioms ex_e1196584689070
theorem ex_e1196584695406 : ¬ IsSelfInterpreter e1196584695406 := cutM4_1 (by decide)
#print axioms ex_e1196584695406
theorem ex_e1196584695418 : ¬ IsSelfInterpreter e1196584695418 := cutM4_1 (by decide)
#print axioms ex_e1196584695418
end Blc.Floor42.Grades074
