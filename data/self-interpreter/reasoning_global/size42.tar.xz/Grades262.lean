import Tables
import Batch262
namespace Blc.Floor42.Grades262
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211585317818 : ¬ IsSelfInterpreter e1211585317818 := cutM1_2 (by decide)
#print axioms ex_e1211585317818
theorem ex_e1211585317850 : ¬ IsSelfInterpreter e1211585317850 := cutM1_2 (by decide)
#print axioms ex_e1211585317850
theorem ex_e1211585318126 : ¬ IsSelfInterpreter e1211585318126 := cutM1_2 (by decide)
#print axioms ex_e1211585318126
theorem ex_e1211585318134 : ¬ IsSelfInterpreter e1211585318134 := cutM1_2 (by decide)
#print axioms ex_e1211585318134
theorem ex_e1211585318714 : ¬ IsSelfInterpreter e1211585318714 := cutM1_2 (by decide)
#print axioms ex_e1211585318714
theorem ex_e1211585315822 : ¬ IsSelfInterpreter e1211585315822 := cutM13_0 (by decide)
#print axioms ex_e1211585315822
end Blc.Floor42.Grades262
