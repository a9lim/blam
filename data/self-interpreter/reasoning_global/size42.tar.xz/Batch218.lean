import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211207831150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211207831150 : Closed e1211207831150 ∧ code e1211207831150 = 5609254342254 := by decide
theorem cert_e1211207831150 : check e1211207831150 [[],[]] .chain = true := by decide
def e1211207831162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211207831162 : Closed e1211207831162 ∧ code e1211207831162 = 5609254342266 := by decide
theorem cert_e1211207831162 : check e1211207831162 [[],[]] .chain = true := by decide
def e1211207831302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211207831302 : Closed e1211207831302 ∧ code e1211207831302 = 5609254342406 := by decide
theorem cert_e1211207831302 : check e1211207831302 [[],[]] .chain = true := by decide
def e1211207831326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211207831326 : Closed e1211207831326 ∧ code e1211207831326 = 5609254342430 := by decide
theorem cert_e1211207831326 : check e1211207831326 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207831350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207831350 : Closed e1211207831350 ∧ code e1211207831350 = 5609254342454 := by decide
theorem cert_e1211207831350 : check e1211207831350 [[],[]] .chain = true := by decide
def e1211207831354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207831354 : Closed e1211207831354 ∧ code e1211207831354 = 5609254342458 := by decide
theorem cert_e1211207831354 : check e1211207831354 [[],[]] .chain = true := by decide
def e1211207836126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211207836126 : Closed e1211207836126 ∧ code e1211207836126 = 5609254347230 := by decide
theorem cert_e1211207836126 : check e1211207836126 [[],[]] .chain = true := by decide
def e1211207836150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211207836150 : Closed e1211207836150 ∧ code e1211207836150 = 5609254347254 := by decide
theorem cert_e1211207836150 : check e1211207836150 [[],[]] .chain = true := by decide
def e1211207837102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211207837102 : Closed e1211207837102 ∧ code e1211207837102 = 5609254348206 := by decide
theorem cert_e1211207837102 : check e1211207837102 [[],[]] .chain = true := by decide
def e1211207837114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211207837114 : Closed e1211207837114 ∧ code e1211207837114 = 5609254348218 := by decide
theorem cert_e1211207837114 : check e1211207837114 [[],[]] .chain = true := by decide
def e1211207837162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211207837162 : Closed e1211207837162 ∧ code e1211207837162 = 5609254348266 := by decide
theorem cert_e1211207837162 : check e1211207837162 [[],[]] .chain = true := by decide
def e1211207837294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211207837294 : Closed e1211207837294 ∧ code e1211207837294 = 5609254348398 := by decide
theorem cert_e1211207837294 : check e1211207837294 [[],[]] .chain = true := by decide
def e1211207837306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211207837306 : Closed e1211207837306 ∧ code e1211207837306 = 5609254348410 := by decide
theorem cert_e1211207837306 : check e1211207837306 [[],[]] .chain = true := by decide
def e1211207837470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211207837470 : Closed e1211207837470 ∧ code e1211207837470 = 5609254348574 := by decide
theorem cert_e1211207837470 : check e1211207837470 [[],[]] .chain = true := by decide
def e1211207837570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211207837570 : Closed e1211207837570 ∧ code e1211207837570 = 5609254348674 := by decide
theorem cert_e1211207837570 : check e1211207837570 [[],[]] .chain = true := by decide
def e1211207837582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211207837582 : Closed e1211207837582 ∧ code e1211207837582 = 5609254348686 := by decide
theorem cert_e1211207837582 : check e1211207837582 [[],[]] .chain = true := by decide
def e1211207837594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211207837594 : Closed e1211207837594 ∧ code e1211207837594 = 5609254348698 := by decide
theorem cert_e1211207837594 : check e1211207837594 [[],[]] .chain = true := by decide
def e1211207839774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211207839774 : Closed e1211207839774 ∧ code e1211207839774 = 5609254350878 := by decide
theorem cert_e1211207839774 : check e1211207839774 [[],[]] .chain = true := by decide
def e1211207839942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211207839942 : Closed e1211207839942 ∧ code e1211207839942 = 5609254351046 := by decide
theorem cert_e1211207839942 : check e1211207839942 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207839966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211207839966 : Closed e1211207839966 ∧ code e1211207839966 = 5609254351070 := by decide
theorem cert_e1211207839966 : check e1211207839966 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207839970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211207839970 : Closed e1211207839970 ∧ code e1211207839970 = 5609254351074 := by decide
theorem cert_e1211207839970 : check e1211207839970 [[],[]] .chain = true := by decide
def e1211207839982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207839982 : Closed e1211207839982 ∧ code e1211207839982 = 5609254351086 := by decide
theorem cert_e1211207839982 : check e1211207839982 [[],[]] .chain = true := by decide
def e1211207839990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207839990 : Closed e1211207839990 ∧ code e1211207839990 = 5609254351094 := by decide
theorem cert_e1211207839990 : check e1211207839990 [[],[]] .chain = true := by decide
def e1211207839994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211207839994 : Closed e1211207839994 ∧ code e1211207839994 = 5609254351098 := by decide
theorem cert_e1211207839994 : check e1211207839994 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207840470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211207840470 : Closed e1211207840470 ∧ code e1211207840470 = 5609254351574 := by decide
theorem cert_e1211207840470 : check e1211207840470 [[],[]] .chain = true := by decide
def e1211207840474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211207840474 : Closed e1211207840474 ∧ code e1211207840474 = 5609254351578 := by decide
theorem cert_e1211207840474 : check e1211207840474 [[],[]] .chain = true := by decide
def e1211207840490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211207840490 : Closed e1211207840490 ∧ code e1211207840490 = 5609254351594 := by decide
theorem cert_e1211207840490 : check e1211207840490 [[],[]] .chain = true := by decide
def e1211207840518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211207840518 : Closed e1211207840518 ∧ code e1211207840518 = 5609254351622 := by decide
theorem cert_e1211207840518 : check e1211207840518 [[],[]] .chain = true := by decide
def e1211207840542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211207840542 : Closed e1211207840542 ∧ code e1211207840542 = 5609254351646 := by decide
theorem cert_e1211207840542 : check e1211207840542 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207840566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207840566 : Closed e1211207840566 ∧ code e1211207840566 = 5609254351670 := by decide
theorem cert_e1211207840566 : check e1211207840566 [[],[]] .chain = true := by decide
def e1211207840570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207840570 : Closed e1211207840570 ∧ code e1211207840570 = 5609254351674 := by decide
theorem cert_e1211207840570 : check e1211207840570 [[],[]] .chain = true := by decide
def e1211207840642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211207840642 : Closed e1211207840642 ∧ code e1211207840642 = 5609254351746 := by decide
theorem cert_e1211207840642 : check e1211207840642 [[],[]] .chain = true := by decide
def e1211207840654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211207840654 : Closed e1211207840654 ∧ code e1211207840654 = 5609254351758 := by decide
theorem cert_e1211207840654 : check e1211207840654 [[],[]] .chain = true := by decide
def e1211207840666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211207840666 : Closed e1211207840666 ∧ code e1211207840666 = 5609254351770 := by decide
theorem cert_e1211207840666 : check e1211207840666 [[],[]] .chain = true := by decide
def e1211207840710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211207840710 : Closed e1211207840710 ∧ code e1211207840710 = 5609254351814 := by decide
theorem cert_e1211207840710 : check e1211207840710 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207911390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e1211207911390 : Closed e1211207911390 ∧ code e1211207911390 = 5609254422494 := by decide
theorem cert_e1211207911390 : check e1211207911390 [[],[]] .chain = true := by decide
def e1211207915230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211207915230 : Closed e1211207915230 ∧ code e1211207915230 = 5609254426334 := by decide
theorem cert_e1211207915230 : check e1211207915230 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1211207915246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e1211207915246 : Closed e1211207915246 ∧ code e1211207915246 = 5609254426350 := by decide
theorem cert_e1211207915246 : check e1211207915246 [[],[]] .chain = true := by decide
def e1211207915254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211207915254 : Closed e1211207915254 ∧ code e1211207915254 = 5609254426358 := by decide
def e1211207915358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211207915358 : Closed e1211207915358 ∧ code e1211207915358 = 5609254426462 := by decide
theorem cert_e1211207915358 : check e1211207915358 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207915374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211207915374 : Closed e1211207915374 ∧ code e1211207915374 = 5609254426478 := by decide
theorem cert_e1211207915374 : check e1211207915374 [[],[]] .chain = true := by decide
def e1211207915382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211207915382 : Closed e1211207915382 ∧ code e1211207915382 = 5609254426486 := by decide
theorem cert_e1211207915382 : check e1211207915382 [[],[]] .chain = true := by decide
def e1211207915386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211207915386 : Closed e1211207915386 ∧ code e1211207915386 = 5609254426490 := by decide
theorem cert_e1211207915386 : check e1211207915386 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207915438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e1211207915438 : Closed e1211207915438 ∧ code e1211207915438 = 5609254426542 := by decide
theorem cert_e1211207915438 : check e1211207915438 [[],[]] .chain = true := by decide
def e1211207915446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211207915446 : Closed e1211207915446 ∧ code e1211207915446 = 5609254426550 := by decide
theorem cert_e1211207915446 : check e1211207915446 [[],[]] .chain = true := by decide
def e1211207915450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e1211207915450 : Closed e1211207915450 ∧ code e1211207915450 = 5609254426554 := by decide
theorem cert_e1211207915450 : check e1211207915450 [[],[]] .chain = true := by decide
def e1211207915478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211207915478 : Closed e1211207915478 ∧ code e1211207915478 = 5609254426582 := by decide
def e1211207915482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211207915482 : Closed e1211207915482 ∧ code e1211207915482 = 5609254426586 := by decide
theorem cert_e1211207915482 : check e1211207915482 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207915998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211207915998 : Closed e1211207915998 ∧ code e1211207915998 = 5609254427102 := by decide
theorem cert_e1211207915998 : check e1211207915998 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e1211207916014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211207916014 : Closed e1211207916014 ∧ code e1211207916014 = 5609254427118 := by decide
theorem cert_e1211207916014 : check e1211207916014 [[],[]] .chain = true := by decide
def e1211207916022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211207916022 : Closed e1211207916022 ∧ code e1211207916022 = 5609254427126 := by decide
theorem cert_e1211207916022 : check e1211207916022 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e1211207916766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211207916766 : Closed e1211207916766 ∧ code e1211207916766 = 5609254427870 := by decide
theorem cert_e1211207916766 : check e1211207916766 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207916782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207916782 : Closed e1211207916782 ∧ code e1211207916782 = 5609254427886 := by decide
theorem cert_e1211207916782 : check e1211207916782 [[],[]] .chain = true := by decide
def e1211207916790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207916790 : Closed e1211207916790 ∧ code e1211207916790 = 5609254427894 := by decide
theorem cert_e1211207916790 : check e1211207916790 [[],[]] .chain = true := by decide
def e1211207916794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211207916794 : Closed e1211207916794 ∧ code e1211207916794 = 5609254427898 := by decide
def e1211207917082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211207917082 : Closed e1211207917082 ∧ code e1211207917082 = 5609254428186 := by decide
theorem cert_e1211207917082 : check e1211207917082 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207917118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211207917118 : Closed e1211207917118 ∧ code e1211207917118 = 5609254428222 := by decide
theorem cert_e1211207917118 : check e1211207917118 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e1211207917166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211207917166 : Closed e1211207917166 ∧ code e1211207917166 = 5609254428270 := by decide
theorem cert_e1211207917166 : check e1211207917166 [[],[]] .chain = true := by decide
def e1211207917174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211207917174 : Closed e1211207917174 ∧ code e1211207917174 = 5609254428278 := by decide
theorem cert_e1211207917174 : check e1211207917174 [[],[]] .chain = true := by decide
def e1211207917178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211207917178 : Closed e1211207917178 ∧ code e1211207917178 = 5609254428282 := by decide
theorem cert_e1211207917178 : check e1211207917178 [[],[]] .chain = true := by decide
def e1211207917342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211207917342 : Closed e1211207917342 ∧ code e1211207917342 = 5609254428446 := by decide
theorem cert_e1211207917342 : checkPay e1211207917342 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] 1 [] = true := by decide
def e1211207917366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207917366 : Closed e1211207917366 ∧ code e1211207917366 = 5609254428470 := by decide
theorem cert_e1211207917366 : check e1211207917366 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211207917370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207917370 : Closed e1211207917370 ∧ code e1211207917370 = 5609254428474 := by decide
def e1211207931574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211207931574 : Closed e1211207931574 ∧ code e1211207931574 = 5609254442678 := by decide
theorem cert_e1211207931574 : check e1211207931574 [[],[]] .chain = true := by decide
def e1211207931606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211207931606 : Closed e1211207931606 ∧ code e1211207931606 = 5609254442710 := by decide
theorem cert_e1211207931606 : check e1211207931606 [[],[]] .chain = true := by decide
def e1211207931610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211207931610 : Closed e1211207931610 ∧ code e1211207931610 = 5609254442714 := by decide
theorem cert_e1211207931610 : check e1211207931610 [[],[]] .chain = true := by decide
def e1211207931734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211207931734 : Closed e1211207931734 ∧ code e1211207931734 = 5609254442838 := by decide
theorem cert_e1211207931734 : check e1211207931734 [[],[]] .chain = true := by decide
def e1211207931738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211207931738 : Closed e1211207931738 ∧ code e1211207931738 = 5609254442842 := by decide
theorem cert_e1211207931738 : check e1211207931738 [[],[]] .chain = true := by decide
def e1211207931754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211207931754 : Closed e1211207931754 ∧ code e1211207931754 = 5609254442858 := by decide
theorem cert_e1211207931754 : check e1211207931754 [[],[]] .chain = true := by decide
def e1211207931958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211207931958 : Closed e1211207931958 ∧ code e1211207931958 = 5609254443062 := by decide
theorem cert_e1211207931958 : check e1211207931958 [[],[]] .chain = true := by decide
def e1211207932046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211207932046 : Closed e1211207932046 ∧ code e1211207932046 = 5609254443150 := by decide
theorem cert_e1211207932046 : check e1211207932046 [[],[]] .chain = true := by decide
def e1211207932130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0)))))))))
theorem wire_e1211207932130 : Closed e1211207932130 ∧ code e1211207932130 = 5609254443234 := by decide
theorem cert_e1211207932130 : check e1211207932130 [[],[]] .chain = true := by decide
def e1211207932142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211207932142 : Closed e1211207932142 ∧ code e1211207932142 = 5609254443246 := by decide
theorem cert_e1211207932142 : check e1211207932142 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207932150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211207932150 : Closed e1211207932150 ∧ code e1211207932150 = 5609254443254 := by decide
theorem cert_e1211207932150 : check e1211207932150 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207932342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211207932342 : Closed e1211207932342 ∧ code e1211207932342 = 5609254443446 := by decide
theorem cert_e1211207932342 : check e1211207932342 [[],[]] .chain = true := by decide
def e1211207932374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211207932374 : Closed e1211207932374 ∧ code e1211207932374 = 5609254443478 := by decide
theorem cert_e1211207932374 : check e1211207932374 [[],[]] .chain = true := by decide
def e1211207932378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211207932378 : Closed e1211207932378 ∧ code e1211207932378 = 5609254443482 := by decide
theorem cert_e1211207932378 : check e1211207932378 [[],[]] .chain = true := by decide
def e1211207932534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211207932534 : Closed e1211207932534 ∧ code e1211207932534 = 5609254443638 := by decide
theorem cert_e1211207932534 : check e1211207932534 [[],[]] .chain = true := by decide
def e1211207932678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207932678 : Closed e1211207932678 ∧ code e1211207932678 = 5609254443782 := by decide
theorem cert_e1211207932678 : check e1211207932678 [[],[]] .chain = true := by decide
def e1211207932702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211207932702 : Closed e1211207932702 ∧ code e1211207932702 = 5609254443806 := by decide
theorem cert_e1211207932702 : check e1211207932702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207932726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207932726 : Closed e1211207932726 ∧ code e1211207932726 = 5609254443830 := by decide
theorem cert_e1211207932726 : check e1211207932726 [[],[]] .chain = true := by decide
def e1211207932730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207932730 : Closed e1211207932730 ∧ code e1211207932730 = 5609254443834 := by decide
theorem cert_e1211207932730 : check e1211207932730 [[],[]] .chain = true := by decide
def e1211207932814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211207932814 : Closed e1211207932814 ∧ code e1211207932814 = 5609254443918 := by decide
theorem cert_e1211207932814 : check e1211207932814 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211207932950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e1211207932950 : Closed e1211207932950 ∧ code e1211207932950 = 5609254444054 := by decide
theorem cert_e1211207932950 : check e1211207932950 [[],[]] .chain = true := by decide
def e1211207932954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211207932954 : Closed e1211207932954 ∧ code e1211207932954 = 5609254444058 := by decide
theorem cert_e1211207932954 : check e1211207932954 [[],[]] .chain = true := by decide
def e1211207932998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211207932998 : Closed e1211207932998 ∧ code e1211207932998 = 5609254444102 := by decide
theorem cert_e1211207932998 : check e1211207932998 [[],[]] .chain = true := by decide
def e1211207933026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0)))))))))
theorem wire_e1211207933026 : Closed e1211207933026 ∧ code e1211207933026 = 5609254444130 := by decide
theorem cert_e1211207933026 : check e1211207933026 [[],[]] .chain = true := by decide
def e1211207933038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211207933038 : Closed e1211207933038 ∧ code e1211207933038 = 5609254444142 := by decide
theorem cert_e1211207933038 : check e1211207933038 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207933046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 1))))))))
theorem wire_e1211207933046 : Closed e1211207933046 ∧ code e1211207933046 = 5609254444150 := by decide
theorem cert_e1211207933046 : check e1211207933046 [[],[]] .chain = true := by decide
def e1211207933050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211207933050 : Closed e1211207933050 ∧ code e1211207933050 = 5609254444154 := by decide
theorem cert_e1211207933050 : check e1211207933050 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207933142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211207933142 : Closed e1211207933142 ∧ code e1211207933142 = 5609254444246 := by decide
theorem cert_e1211207933142 : check e1211207933142 [[],[]] .chain = true := by decide
def e1211207933146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211207933146 : Closed e1211207933146 ∧ code e1211207933146 = 5609254444250 := by decide
theorem cert_e1211207933146 : check e1211207933146 [[],[]] .chain = true := by decide
def e1211207933162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211207933162 : Closed e1211207933162 ∧ code e1211207933162 = 5609254444266 := by decide
theorem cert_e1211207933162 : check e1211207933162 [[],[]] .chain = true := by decide
def e1211207933190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1))))))))))
theorem wire_e1211207933190 : Closed e1211207933190 ∧ code e1211207933190 = 5609254444294 := by decide
theorem cert_e1211207933190 : check e1211207933190 [[],[]] .chain = true := by decide
def e1211207933214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211207933214 : Closed e1211207933214 ∧ code e1211207933214 = 5609254444318 := by decide
theorem cert_e1211207933214 : check e1211207933214 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207933238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211207933238 : Closed e1211207933238 ∧ code e1211207933238 = 5609254444342 := by decide
theorem cert_e1211207933238 : check e1211207933238 [[],[]] .chain = true := by decide
def e1211207933242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211207933242 : Closed e1211207933242 ∧ code e1211207933242 = 5609254444346 := by decide
theorem cert_e1211207933242 : check e1211207933242 [[],[]] .chain = true := by decide
def e1211207933314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e1211207933314 : Closed e1211207933314 ∧ code e1211207933314 = 5609254444418 := by decide
theorem cert_e1211207933314 : check e1211207933314 [[],[]] .chain = true := by decide
def e1211207933326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e1211207933326 : Closed e1211207933326 ∧ code e1211207933326 = 5609254444430 := by decide
theorem cert_e1211207933326 : check e1211207933326 [[],[]] .chain = true := by decide
def e1211207933338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211207933338 : Closed e1211207933338 ∧ code e1211207933338 = 5609254444442 := by decide
theorem cert_e1211207933338 : check e1211207933338 [[],[]] .chain = true := by decide
def e1211207933382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211207933382 : Closed e1211207933382 ∧ code e1211207933382 = 5609254444486 := by decide
theorem cert_e1211207933382 : check e1211207933382 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207933494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1211207933494 : Closed e1211207933494 ∧ code e1211207933494 = 5609254444598 := by decide
theorem cert_e1211207933494 : check e1211207933494 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207933498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1211207933498 : Closed e1211207933498 ∧ code e1211207933498 = 5609254444602 := by decide
theorem cert_e1211207933498 : check e1211207933498 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207933582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1211207933582 : Closed e1211207933582 ∧ code e1211207933582 = 5609254444686 := by decide
theorem cert_e1211207933582 : check e1211207933582 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211207933638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1211207933638 : Closed e1211207933638 ∧ code e1211207933638 = 5609254444742 := by decide
theorem cert_e1211207933638 : check e1211207933638 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211207934014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))))))))
theorem wire_e1211207934014 : Closed e1211207934014 ∧ code e1211207934014 = 5609254445118 := by decide
theorem cert_e1211207934014 : check e1211207934014 [[],[]] .chain = true := by decide
def e1211207934434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e1211207934434 : Closed e1211207934434 ∧ code e1211207934434 = 5609254445538 := by decide
theorem cert_e1211207934434 : check e1211207934434 [[],[]] .chain = true := by decide
def e1211207934446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211207934446 : Closed e1211207934446 ∧ code e1211207934446 = 5609254445550 := by decide
theorem cert_e1211207934446 : check e1211207934446 [[],[]] .chain = true := by decide
def e1211207935414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211207935414 : Closed e1211207935414 ∧ code e1211207935414 = 5609254446518 := by decide
theorem cert_e1211207935414 : check e1211207935414 [[],[]] .chain = true := by decide
def e1211207935446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211207935446 : Closed e1211207935446 ∧ code e1211207935446 = 5609254446550 := by decide
theorem cert_e1211207935446 : check e1211207935446 [[],[]] .chain = true := by decide
def e1211207935450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211207935450 : Closed e1211207935450 ∧ code e1211207935450 = 5609254446554 := by decide
theorem cert_e1211207935450 : check e1211207935450 [[],[]] .chain = true := by decide
def e1211207935606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211207935606 : Closed e1211207935606 ∧ code e1211207935606 = 5609254446710 := by decide
theorem cert_e1211207935606 : check e1211207935606 [[],[]] .chain = true := by decide
def e1211207935750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211207935750 : Closed e1211207935750 ∧ code e1211207935750 = 5609254446854 := by decide
theorem cert_e1211207935750 : check e1211207935750 [[],[]] .chain = true := by decide
def e1211207935774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211207935774 : Closed e1211207935774 ∧ code e1211207935774 = 5609254446878 := by decide
theorem cert_e1211207935774 : check e1211207935774 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e1211207935798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207935798 : Closed e1211207935798 ∧ code e1211207935798 = 5609254446902 := by decide
theorem cert_e1211207935798 : check e1211207935798 [[],[]] .chain = true := by decide
def e1211207935802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207935802 : Closed e1211207935802 ∧ code e1211207935802 = 5609254446906 := by decide
theorem cert_e1211207935802 : check e1211207935802 [[],[]] .chain = true := by decide
def e1211207935886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211207935886 : Closed e1211207935886 ∧ code e1211207935886 = 5609254446990 := by decide
theorem cert_e1211207935886 : check e1211207935886 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1211207938078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))))))))
theorem wire_e1211207938078 : Closed e1211207938078 ∧ code e1211207938078 = 5609254449182 := by decide
theorem cert_e1211207938078 : check e1211207938078 [[],[]] .chain = true := by decide
def e1211207938246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211207938246 : Closed e1211207938246 ∧ code e1211207938246 = 5609254449350 := by decide
theorem cert_e1211207938246 : check e1211207938246 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207938270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211207938270 : Closed e1211207938270 ∧ code e1211207938270 = 5609254449374 := by decide
theorem cert_e1211207938270 : check e1211207938270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207938274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e1211207938274 : Closed e1211207938274 ∧ code e1211207938274 = 5609254449378 := by decide
theorem cert_e1211207938274 : check e1211207938274 [[],[]] .chain = true := by decide
def e1211207938286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211207938286 : Closed e1211207938286 ∧ code e1211207938286 = 5609254449390 := by decide
theorem cert_e1211207938286 : check e1211207938286 [[],[]] .chain = true := by decide
def e1211207938294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211207938294 : Closed e1211207938294 ∧ code e1211207938294 = 5609254449398 := by decide
theorem cert_e1211207938294 : check e1211207938294 [[],[]] .chain = true := by decide
def e1211207938298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211207938298 : Closed e1211207938298 ∧ code e1211207938298 = 5609254449402 := by decide
theorem cert_e1211207938298 : check e1211207938298 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207938774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211207938774 : Closed e1211207938774 ∧ code e1211207938774 = 5609254449878 := by decide
theorem cert_e1211207938774 : check e1211207938774 [[],[]] .chain = true := by decide
def e1211207938778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211207938778 : Closed e1211207938778 ∧ code e1211207938778 = 5609254449882 := by decide
theorem cert_e1211207938778 : check e1211207938778 [[],[]] .chain = true := by decide
def e1211207938794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211207938794 : Closed e1211207938794 ∧ code e1211207938794 = 5609254449898 := by decide
theorem cert_e1211207938794 : check e1211207938794 [[],[]] .chain = true := by decide
def e1211207938822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1)))))))))))
theorem wire_e1211207938822 : Closed e1211207938822 ∧ code e1211207938822 = 5609254449926 := by decide
theorem cert_e1211207938822 : check e1211207938822 [[],[]] .chain = true := by decide
def e1211207938846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211207938846 : Closed e1211207938846 ∧ code e1211207938846 = 5609254449950 := by decide
theorem cert_e1211207938846 : check e1211207938846 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207938870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211207938870 : Closed e1211207938870 ∧ code e1211207938870 = 5609254449974 := by decide
theorem cert_e1211207938870 : check e1211207938870 [[],[]] .chain = true := by decide
def e1211207938874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211207938874 : Closed e1211207938874 ∧ code e1211207938874 = 5609254449978 := by decide
theorem cert_e1211207938874 : check e1211207938874 [[],[]] .chain = true := by decide
def e1211207938946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211207938946 : Closed e1211207938946 ∧ code e1211207938946 = 5609254450050 := by decide
theorem cert_e1211207938946 : check e1211207938946 [[],[]] .chain = true := by decide
def e1211207938958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211207938958 : Closed e1211207938958 ∧ code e1211207938958 = 5609254450062 := by decide
theorem cert_e1211207938958 : check e1211207938958 [[],[]] .chain = true := by decide
def e1211207938970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211207938970 : Closed e1211207938970 ∧ code e1211207938970 = 5609254450074 := by decide
theorem cert_e1211207938970 : check e1211207938970 [[],[]] .chain = true := by decide
def e1211207939014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211207939014 : Closed e1211207939014 ∧ code e1211207939014 = 5609254450118 := by decide
theorem cert_e1211207939014 : check e1211207939014 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e1211207940206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e1211207940206 : Closed e1211207940206 ∧ code e1211207940206 = 5609254451310 := by decide
theorem cert_e1211207940206 : checkPay e1211207940206 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left]] 0 [[.left],[],[.under,.right],[.under,.right,.left],[.under,.right,.left]] = true := by decide
def e1211207940218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e1211207940218 : Closed e1211207940218 ∧ code e1211207940218 = 5609254451322 := by decide
theorem cert_e1211207940218 : check e1211207940218 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e1211207940494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211207940494 : Closed e1211207940494 ∧ code e1211207940494 = 5609254451598 := by decide
theorem cert_e1211207940494 : checkPay e1211207940494 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1211207940550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211207940550 : Closed e1211207940550 ∧ code e1211207940550 = 5609254451654 := by decide
theorem cert_e1211207940550 : checkPay e1211207940550 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211210149310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e1211210149310 : Closed e1211210149310 ∧ code e1211210149310 = 5609256660414 := by decide
theorem cert_e1211210149310 : check e1211210149310 [[],[]] .smaller = true := by decide
def e1211210149366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e1211210149366 : Closed e1211210149366 ∧ code e1211210149366 = 5609256660470 := by decide
theorem cert_e1211210149366 : check e1211210149366 [[],[]] .smaller = true := by decide
def e1211210149566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e1211210149566 : Closed e1211210149566 ∧ code e1211210149566 = 5609256660670 := by decide
theorem cert_e1211210149566 : check e1211210149566 [[],[]] .smaller = true := by decide
def e1211210149626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e1211210149626 : Closed e1211210149626 ∧ code e1211210149626 = 5609256660730 := by decide
theorem cert_e1211210149626 : check e1211210149626 [[],[]] .smaller = true := by decide
def e1211210149846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e1211210149846 : Closed e1211210149846 ∧ code e1211210149846 = 5609256660950 := by decide
theorem cert_e1211210149846 : check e1211210149846 [[],[]] .smaller = true := by decide
def e1211210149850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e1211210149850 : Closed e1211210149850 ∧ code e1211210149850 = 5609256660954 := by decide
theorem cert_e1211210149850 : check e1211210149850 [[],[]] .smaller = true := by decide
def e1211210150846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211210150846 : Closed e1211210150846 ∧ code e1211210150846 = 5609256661950 := by decide
theorem cert_e1211210150846 : check e1211210150846 [[],[]] .smaller = true := by decide
def e1211210150902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211210150902 : Closed e1211210150902 ∧ code e1211210150902 = 5609256662006 := by decide
theorem cert_e1211210150902 : check e1211210150902 [[],[]] .smaller = true := by decide
def e1211210152382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e1211210152382 : Closed e1211210152382 ∧ code e1211210152382 = 5609256663486 := by decide
theorem cert_e1211210152382 : check e1211210152382 [[],[]] .smaller = true := by decide
def e1211210152442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e1211210152442 : Closed e1211210152442 ∧ code e1211210152442 = 5609256663546 := by decide
theorem cert_e1211210152442 : check e1211210152442 [[],[]] .smaller = true := by decide
def e1211210153782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211210153782 : Closed e1211210153782 ∧ code e1211210153782 = 5609256664886 := by decide
theorem cert_e1211210153782 : check e1211210153782 [[],[]] .smaller = true := by decide
def e1211210153786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211210153786 : Closed e1211210153786 ∧ code e1211210153786 = 5609256664890 := by decide
theorem cert_e1211210153786 : check e1211210153786 [[],[]] .smaller = true := by decide
def e1211210181998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211210181998 : Closed e1211210181998 ∧ code e1211210181998 = 5609256693102 := by decide
theorem cert_e1211210181998 : check e1211210181998 [[],[]] .smaller = true := by decide
def e1211210182006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211210182006 : Closed e1211210182006 ∧ code e1211210182006 = 5609256693110 := by decide
theorem cert_e1211210182006 : check e1211210182006 [[],[]] .smaller = true := by decide
def e1211210182062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211210182062 : Closed e1211210182062 ∧ code e1211210182062 = 5609256693166 := by decide
theorem cert_e1211210182062 : check e1211210182062 [[],[]] .smaller = true := by decide
def e1211210182074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211210182074 : Closed e1211210182074 ∧ code e1211210182074 = 5609256693178 := by decide
theorem cert_e1211210182074 : check e1211210182074 [[],[]] .smaller = true := by decide
def e1211210182102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211210182102 : Closed e1211210182102 ∧ code e1211210182102 = 5609256693206 := by decide
theorem cert_e1211210182102 : check e1211210182102 [[],[]] .smaller = true := by decide
def e1211210182106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211210182106 : Closed e1211210182106 ∧ code e1211210182106 = 5609256693210 := by decide
theorem cert_e1211210182106 : check e1211210182106 [[],[]] .smaller = true := by decide
def e1211210182318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e1211210182318 : Closed e1211210182318 ∧ code e1211210182318 = 5609256693422 := by decide
theorem cert_e1211210182318 : check e1211210182318 [[],[]] .smaller = true := by decide
def e1211210182330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e1211210182330 : Closed e1211210182330 ∧ code e1211210182330 = 5609256693434 := by decide
theorem cert_e1211210182330 : check e1211210182330 [[],[]] .smaller = true := by decide
def e1211210182378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e1211210182378 : Closed e1211210182378 ∧ code e1211210182378 = 5609256693482 := by decide
theorem cert_e1211210182378 : check e1211210182378 [[],[]] .smaller = true := by decide
end Blc.Floor42
