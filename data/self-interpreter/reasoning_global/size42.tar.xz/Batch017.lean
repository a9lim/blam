import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e303198203446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e303198203446 : Closed e303198203446 ∧ code e303198203446 = 4701244714550 := by decide
theorem cert_e303198203446 : check e303198203446 [[.under]] .sourceHead = true := by decide
def e303198203450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e303198203450 : Closed e303198203450 ∧ code e303198203450 = 4701244714554 := by decide
theorem cert_e303198203450 : check e303198203450 [[.under]] .sourceHead = true := by decide
def e303198203534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e303198203534 : Closed e303198203534 ∧ code e303198203534 = 4701244714638 := by decide
theorem cert_e303198203534 : check e303198203534 [[.under]] .sourceHead = true := by decide
def e303198203590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e303198203590 : Closed e303198203590 ∧ code e303198203590 = 4701244714694 := by decide
theorem cert_e303198203590 : check e303198203590 [[.under]] .sourceHead = true := by decide
def e303198204334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e303198204334 : Closed e303198204334 ∧ code e303198204334 = 4701244715438 := by decide
theorem cert_e303198204334 : check e303198204334 [[.under]] .sourceHead = true := by decide
def e303198204346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e303198204346 : Closed e303198204346 ∧ code e303198204346 = 4701244715450 := by decide
theorem cert_e303198204346 : check e303198204346 [[.under]] .sourceHead = true := by decide
def e303198204394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e303198204394 : Closed e303198204394 ∧ code e303198204394 = 4701244715498 := by decide
theorem cert_e303198204394 : check e303198204394 [[.under]] .sourceHead = true := by decide
def e303198205038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e303198205038 : Closed e303198205038 ∧ code e303198205038 = 4701244716142 := by decide
theorem cert_e303198205038 : check e303198205038 [[.under]] .sourceHead = true := by decide
def e303198205050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e303198205050 : Closed e303198205050 ∧ code e303198205050 = 4701244716154 := by decide
theorem cert_e303198205050 : check e303198205050 [[.under]] .sourceHead = true := by decide
def e303198205214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e303198205214 : Closed e303198205214 ∧ code e303198205214 = 4701244716318 := by decide
theorem cert_e303198205214 : check e303198205214 [[.under]] .sourceHead = true := by decide
def e303198205382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e303198205382 : Closed e303198205382 ∧ code e303198205382 = 4701244716486 := by decide
theorem cert_e303198205382 : check e303198205382 [[.under]] .sourceHead = true := by decide
def e303198205722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e303198205722 : Closed e303198205722 ∧ code e303198205722 = 4701244716826 := by decide
theorem cert_e303198205722 : check e303198205722 [[.under]] .sourceHead = true := by decide
def e303198205766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e303198205766 : Closed e303198205766 ∧ code e303198205766 = 4701244716870 := by decide
theorem cert_e303198205766 : check e303198205766 [[.under]] .sourceHead = true := by decide
def e303198206166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e303198206166 : Closed e303198206166 ∧ code e303198206166 = 4701244717270 := by decide
theorem cert_e303198206166 : check e303198206166 [[.under]] .sourceHead = true := by decide
def e303198206170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e303198206170 : Closed e303198206170 ∧ code e303198206170 = 4701244717274 := by decide
theorem cert_e303198206170 : check e303198206170 [[.under]] .sourceHead = true := by decide
def e303198206186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e303198206186 : Closed e303198206186 ∧ code e303198206186 = 4701244717290 := by decide
theorem cert_e303198206186 : check e303198206186 [[.under]] .sourceHead = true := by decide
def e303198206518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e303198206518 : Closed e303198206518 ∧ code e303198206518 = 4701244717622 := by decide
theorem cert_e303198206518 : check e303198206518 [[.under]] .sourceHead = true := by decide
def e303198206522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e303198206522 : Closed e303198206522 ∧ code e303198206522 = 4701244717626 := by decide
theorem cert_e303198206522 : check e303198206522 [[.under]] .sourceHead = true := by decide
def e303198206606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e303198206606 : Closed e303198206606 ∧ code e303198206606 = 4701244717710 := by decide
theorem cert_e303198206606 : check e303198206606 [[.under]] .sourceHead = true := by decide
def e303198206662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e303198206662 : Closed e303198206662 ∧ code e303198206662 = 4701244717766 := by decide
theorem cert_e303198206662 : check e303198206662 [[.under]] .sourceHead = true := by decide
def e303198206746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e303198206746 : Closed e303198206746 ∧ code e303198206746 = 4701244717850 := by decide
theorem cert_e303198206746 : check e303198206746 [[.under]] .sourceHead = true := by decide
def e303198206790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e303198206790 : Closed e303198206790 ∧ code e303198206790 = 4701244717894 := by decide
theorem cert_e303198206790 : check e303198206790 [[.under]] .sourceHead = true := by decide
def e303198211310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e303198211310 : Closed e303198211310 ∧ code e303198211310 = 4701244722414 := by decide
theorem cert_e303198211310 : check e303198211310 [[.under]] .sourceHead = true := by decide
def e303198211318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e303198211318 : Closed e303198211318 ∧ code e303198211318 = 4701244722422 := by decide
theorem cert_e303198211318 : check e303198211318 [[.under]] .sourceHead = true := by decide
def e303198211694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e303198211694 : Closed e303198211694 ∧ code e303198211694 = 4701244722798 := by decide
theorem cert_e303198211694 : check e303198211694 [[.under]] .sourceHead = true := by decide
def e303198211706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e303198211706 : Closed e303198211706 ∧ code e303198211706 = 4701244722810 := by decide
theorem cert_e303198211706 : check e303198211706 [[.under]] .sourceHead = true := by decide
def e303198211894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e303198211894 : Closed e303198211894 ∧ code e303198211894 = 4701244722998 := by decide
theorem cert_e303198211894 : check e303198211894 [[.under]] .sourceHead = true := by decide
def e303198211898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e303198211898 : Closed e303198211898 ∧ code e303198211898 = 4701244723002 := by decide
theorem cert_e303198211898 : check e303198211898 [[.under]] .sourceHead = true := by decide
def e303198214382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e303198214382 : Closed e303198214382 ∧ code e303198214382 = 4701244725486 := by decide
theorem cert_e303198214382 : check e303198214382 [[.under]] .sourceHead = true := by decide
def e303198214390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e303198214390 : Closed e303198214390 ∧ code e303198214390 = 4701244725494 := by decide
theorem cert_e303198214390 : check e303198214390 [[.under]] .sourceHead = true := by decide
def e303198214942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e303198214942 : Closed e303198214942 ∧ code e303198214942 = 4701244726046 := by decide
theorem cert_e303198214942 : check e303198214942 [[.under]] .sourceHead = true := by decide
def e303198215054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e303198215054 : Closed e303198215054 ∧ code e303198215054 = 4701244726158 := by decide
theorem cert_e303198215054 : check e303198215054 [[.under]] .sourceHead = true := by decide
def e303198215278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e303198215278 : Closed e303198215278 ∧ code e303198215278 = 4701244726382 := by decide
theorem cert_e303198215278 : check e303198215278 [[.under]] .sourceHead = true := by decide
def e303198215290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e303198215290 : Closed e303198215290 ∧ code e303198215290 = 4701244726394 := by decide
theorem cert_e303198215290 : check e303198215290 [[.under]] .sourceHead = true := by decide
def e303198215454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e303198215454 : Closed e303198215454 ∧ code e303198215454 = 4701244726558 := by decide
theorem cert_e303198215454 : check e303198215454 [[.under]] .sourceHead = true := by decide
def e303198215622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e303198215622 : Closed e303198215622 ∧ code e303198215622 = 4701244726726 := by decide
theorem cert_e303198215622 : check e303198215622 [[.under]] .sourceHead = true := by decide
def e303198215734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e303198215734 : Closed e303198215734 ∧ code e303198215734 = 4701244726838 := by decide
theorem cert_e303198215734 : check e303198215734 [[.under]] .sourceHead = true := by decide
def e303198215738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e303198215738 : Closed e303198215738 ∧ code e303198215738 = 4701244726842 := by decide
theorem cert_e303198215738 : check e303198215738 [[.under]] .sourceHead = true := by decide
def e303198215822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e303198215822 : Closed e303198215822 ∧ code e303198215822 = 4701244726926 := by decide
theorem cert_e303198215822 : check e303198215822 [[.under]] .sourceHead = true := by decide
def e303198215878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e303198215878 : Closed e303198215878 ∧ code e303198215878 = 4701244726982 := by decide
theorem cert_e303198215878 : check e303198215878 [[.under]] .sourceHead = true := by decide
def e303198218014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e303198218014 : Closed e303198218014 ∧ code e303198218014 = 4701244729118 := by decide
theorem cert_e303198218014 : check e303198218014 [[.under]] .sourceHead = true := by decide
def e303198218126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e303198218126 : Closed e303198218126 ∧ code e303198218126 = 4701244729230 := by decide
theorem cert_e303198218126 : check e303198218126 [[.under]] .sourceHead = true := by decide
def e303198221086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e303198221086 : Closed e303198221086 ∧ code e303198221086 = 4701244732190 := by decide
theorem cert_e303198221086 : check e303198221086 [[.under]] .sourceHead = true := by decide
def e303198221254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e303198221254 : Closed e303198221254 ∧ code e303198221254 = 4701244732358 := by decide
theorem cert_e303198221254 : check e303198221254 [[.under]] .sourceHead = true := by decide
def e303198222734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e303198222734 : Closed e303198222734 ∧ code e303198222734 = 4701244733838 := by decide
theorem cert_e303198222734 : check e303198222734 [[.under]] .sourceHead = true := by decide
def e303198222790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e303198222790 : Closed e303198222790 ∧ code e303198222790 = 4701244733894 := by decide
theorem cert_e303198222790 : check e303198222790 [[.under]] .sourceHead = true := by decide
def e303198226030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e303198226030 : Closed e303198226030 ∧ code e303198226030 = 4701244737134 := by decide
theorem cert_e303198226030 : check e303198226030 [[.under]] .sourceHead = true := by decide
def e303198226042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e303198226042 : Closed e303198226042 ∧ code e303198226042 = 4701244737146 := by decide
theorem cert_e303198226042 : check e303198226042 [[.under]] .sourceHead = true := by decide
def e303198226330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e303198226330 : Closed e303198226330 ∧ code e303198226330 = 4701244737434 := by decide
theorem cert_e303198226330 : check e303198226330 [[.under]] .sourceHead = true := by decide
def e303198227566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e303198227566 : Closed e303198227566 ∧ code e303198227566 = 4701244738670 := by decide
theorem cert_e303198227566 : check e303198227566 [[.under]] .sourceHead = true := by decide
def e303198227578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e303198227578 : Closed e303198227578 ∧ code e303198227578 = 4701244738682 := by decide
theorem cert_e303198227578 : check e303198227578 [[.under]] .sourceHead = true := by decide
def e303198227742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e303198227742 : Closed e303198227742 ∧ code e303198227742 = 4701244738846 := by decide
theorem cert_e303198227742 : check e303198227742 [[.under]] .sourceHead = true := by decide
def e303198227910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e303198227910 : Closed e303198227910 ∧ code e303198227910 = 4701244739014 := by decide
theorem cert_e303198227910 : check e303198227910 [[.under]] .sourceHead = true := by decide
def e303198228250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e303198228250 : Closed e303198228250 ∧ code e303198228250 = 4701244739354 := by decide
theorem cert_e303198228250 : check e303198228250 [[.under]] .sourceHead = true := by decide
def e303198228294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e303198228294 : Closed e303198228294 ∧ code e303198228294 = 4701244739398 := by decide
theorem cert_e303198228294 : check e303198228294 [[.under]] .sourceHead = true := by decide
def e303198229278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e303198229278 : Closed e303198229278 ∧ code e303198229278 = 4701244740382 := by decide
theorem cert_e303198229278 : check e303198229278 [[.under]] .sourceHead = true := by decide
def e303198229446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e303198229446 : Closed e303198229446 ∧ code e303198229446 = 4701244740550 := by decide
theorem cert_e303198229446 : check e303198229446 [[.under]] .sourceHead = true := by decide
def e303198231750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e303198231750 : Closed e303198231750 ∧ code e303198231750 = 4701244742854 := by decide
theorem cert_e303198231750 : check e303198231750 [[.under]] .sourceHead = true := by decide
def e303198233398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e303198233398 : Closed e303198233398 ∧ code e303198233398 = 4701244744502 := by decide
theorem cert_e303198233398 : check e303198233398 [[.under]] .sourceHead = true := by decide
def e303198233402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e303198233402 : Closed e303198233402 ∧ code e303198233402 = 4701244744506 := by decide
theorem cert_e303198233402 : check e303198233402 [[.under]] .sourceHead = true := by decide
def e303198233498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e303198233498 : Closed e303198233498 ∧ code e303198233498 = 4701244744602 := by decide
theorem cert_e303198233498 : check e303198233498 [[.under]] .sourceHead = true := by decide
def e303198234166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e303198234166 : Closed e303198234166 ∧ code e303198234166 = 4701244745270 := by decide
theorem cert_e303198234166 : check e303198234166 [[.under]] .sourceHead = true := by decide
def e303198234170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e303198234170 : Closed e303198234170 ∧ code e303198234170 = 4701244745274 := by decide
theorem cert_e303198234170 : check e303198234170 [[.under]] .sourceHead = true := by decide
def e303198234254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e303198234254 : Closed e303198234254 ∧ code e303198234254 = 4701244745358 := by decide
theorem cert_e303198234254 : check e303198234254 [[.under]] .sourceHead = true := by decide
def e303198234310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e303198234310 : Closed e303198234310 ∧ code e303198234310 = 4701244745414 := by decide
theorem cert_e303198234310 : check e303198234310 [[.under]] .sourceHead = true := by decide
def e303198234394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e303198234394 : Closed e303198234394 ∧ code e303198234394 = 4701244745498 := by decide
theorem cert_e303198234394 : check e303198234394 [[.under]] .sourceHead = true := by decide
def e303198234438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e303198234438 : Closed e303198234438 ∧ code e303198234438 = 4701244745542 := by decide
theorem cert_e303198234438 : check e303198234438 [[.under]] .sourceHead = true := by decide
def e303198235022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e303198235022 : Closed e303198235022 ∧ code e303198235022 = 4701244746126 := by decide
theorem cert_e303198235022 : check e303198235022 [[.under]] .sourceHead = true := by decide
def e303198235078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e303198235078 : Closed e303198235078 ∧ code e303198235078 = 4701244746182 := by decide
theorem cert_e303198235078 : check e303198235078 [[.under]] .sourceHead = true := by decide
def e303198235846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e303198235846 : Closed e303198235846 ∧ code e303198235846 = 4701244746950 := by decide
theorem cert_e303198235846 : check e303198235846 [[.under]] .sourceHead = true := by decide
def e303198246622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e303198246622 : Closed e303198246622 ∧ code e303198246622 = 4701244757726 := by decide
theorem cert_e303198246622 : check e303198246622 [[.under]] .sourceHead = true := by decide
def e303198246646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e303198246646 : Closed e303198246646 ∧ code e303198246646 = 4701244757750 := by decide
theorem cert_e303198246646 : check e303198246646 [[.under]] .sourceHead = true := by decide
def e303198246750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e303198246750 : Closed e303198246750 ∧ code e303198246750 = 4701244757854 := by decide
theorem cert_e303198246750 : check e303198246750 [[.under]] .sourceHead = true := by decide
def e303198246778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e303198246778 : Closed e303198246778 ∧ code e303198246778 = 4701244757882 := by decide
theorem cert_e303198246778 : check e303198246778 [[.under]] .sourceHead = true := by decide
def e303198246870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e303198246870 : Closed e303198246870 ∧ code e303198246870 = 4701244757974 := by decide
theorem cert_e303198246870 : check e303198246870 [[.under]] .sourceHead = true := by decide
def e303198246874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e303198246874 : Closed e303198246874 ∧ code e303198246874 = 4701244757978 := by decide
theorem cert_e303198246874 : check e303198246874 [[.under]] .sourceHead = true := by decide
def e303198247390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e303198247390 : Closed e303198247390 ∧ code e303198247390 = 4701244758494 := by decide
theorem cert_e303198247390 : check e303198247390 [[.under]] .sourceHead = true := by decide
def e303198247414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e303198247414 : Closed e303198247414 ∧ code e303198247414 = 4701244758518 := by decide
theorem cert_e303198247414 : check e303198247414 [[.under]] .sourceHead = true := by decide
def e303198248158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e303198248158 : Closed e303198248158 ∧ code e303198248158 = 4701244759262 := by decide
theorem cert_e303198248158 : check e303198248158 [[.under]] .sourceHead = true := by decide
def e303198248186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e303198248186 : Closed e303198248186 ∧ code e303198248186 = 4701244759290 := by decide
theorem cert_e303198248186 : check e303198248186 [[.under]] .sourceHead = true := by decide
def e303198248758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303198248758 : Closed e303198248758 ∧ code e303198248758 = 4701244759862 := by decide
theorem cert_e303198248758 : check e303198248758 [[.under]] .sourceHead = true := by decide
def e303198248762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303198248762 : Closed e303198248762 ∧ code e303198248762 = 4701244759866 := by decide
theorem cert_e303198248762 : check e303198248762 [[.under]] .sourceHead = true := by decide
def e303198263534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e303198263534 : Closed e303198263534 ∧ code e303198263534 = 4701244774638 := by decide
theorem cert_e303198263534 : check e303198263534 [[.under]] .sourceHead = true := by decide
def e303198263542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e303198263542 : Closed e303198263542 ∧ code e303198263542 = 4701244774646 := by decide
theorem cert_e303198263542 : check e303198263542 [[.under]] .sourceHead = true := by decide
def e303198264094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e303198264094 : Closed e303198264094 ∧ code e303198264094 = 4701244775198 := by decide
theorem cert_e303198264094 : check e303198264094 [[.under]] .sourceHead = true := by decide
def e303198264206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e303198264206 : Closed e303198264206 ∧ code e303198264206 = 4701244775310 := by decide
theorem cert_e303198264206 : check e303198264206 [[.under]] .sourceHead = true := by decide
def e303198264430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e303198264430 : Closed e303198264430 ∧ code e303198264430 = 4701244775534 := by decide
theorem cert_e303198264430 : check e303198264430 [[.under]] .sourceHead = true := by decide
def e303198264442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e303198264442 : Closed e303198264442 ∧ code e303198264442 = 4701244775546 := by decide
theorem cert_e303198264442 : check e303198264442 [[.under]] .sourceHead = true := by decide
def e303198264606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e303198264606 : Closed e303198264606 ∧ code e303198264606 = 4701244775710 := by decide
theorem cert_e303198264606 : check e303198264606 [[.under]] .sourceHead = true := by decide
def e303198264774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e303198264774 : Closed e303198264774 ∧ code e303198264774 = 4701244775878 := by decide
theorem cert_e303198264774 : check e303198264774 [[.under]] .sourceHead = true := by decide
def e303198264886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e303198264886 : Closed e303198264886 ∧ code e303198264886 = 4701244775990 := by decide
theorem cert_e303198264886 : check e303198264886 [[.under]] .sourceHead = true := by decide
def e303198264890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e303198264890 : Closed e303198264890 ∧ code e303198264890 = 4701244775994 := by decide
theorem cert_e303198264890 : check e303198264890 [[.under]] .sourceHead = true := by decide
def e303198264974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e303198264974 : Closed e303198264974 ∧ code e303198264974 = 4701244776078 := by decide
theorem cert_e303198264974 : check e303198264974 [[.under]] .sourceHead = true := by decide
def e303198265030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e303198265030 : Closed e303198265030 ∧ code e303198265030 = 4701244776134 := by decide
theorem cert_e303198265030 : check e303198265030 [[.under]] .sourceHead = true := by decide
def e303198267166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e303198267166 : Closed e303198267166 ∧ code e303198267166 = 4701244778270 := by decide
theorem cert_e303198267166 : check e303198267166 [[.under]] .sourceHead = true := by decide
def e303198267278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e303198267278 : Closed e303198267278 ∧ code e303198267278 = 4701244778382 := by decide
theorem cert_e303198267278 : check e303198267278 [[.under]] .sourceHead = true := by decide
def e303198270238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e303198270238 : Closed e303198270238 ∧ code e303198270238 = 4701244781342 := by decide
theorem cert_e303198270238 : check e303198270238 [[.under]] .sourceHead = true := by decide
def e303198270406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e303198270406 : Closed e303198270406 ∧ code e303198270406 = 4701244781510 := by decide
theorem cert_e303198270406 : check e303198270406 [[.under]] .sourceHead = true := by decide
def e303198271886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e303198271886 : Closed e303198271886 ∧ code e303198271886 = 4701244782990 := by decide
theorem cert_e303198271886 : check e303198271886 [[.under]] .sourceHead = true := by decide
def e303198271942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e303198271942 : Closed e303198271942 ∧ code e303198271942 = 4701244783046 := by decide
theorem cert_e303198271942 : check e303198271942 [[.under]] .sourceHead = true := by decide
def e303198309230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e303198309230 : Closed e303198309230 ∧ code e303198309230 = 4701244820334 := by decide
theorem cert_e303198309230 : check e303198309230 [[.under]] .sourceHead = true := by decide
def e303198309238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e303198309238 : Closed e303198309238 ∧ code e303198309238 = 4701244820342 := by decide
theorem cert_e303198309238 : check e303198309238 [[.under]] .sourceHead = true := by decide
def e303198309294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e303198309294 : Closed e303198309294 ∧ code e303198309294 = 4701244820398 := by decide
theorem cert_e303198309294 : check e303198309294 [[.under]] .sourceHead = true := by decide
def e303198309306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e303198309306 : Closed e303198309306 ∧ code e303198309306 = 4701244820410 := by decide
theorem cert_e303198309306 : check e303198309306 [[.under]] .sourceHead = true := by decide
def e303198309334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e303198309334 : Closed e303198309334 ∧ code e303198309334 = 4701244820438 := by decide
theorem cert_e303198309334 : check e303198309334 [[.under]] .sourceHead = true := by decide
def e303198309338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e303198309338 : Closed e303198309338 ∧ code e303198309338 = 4701244820442 := by decide
theorem cert_e303198309338 : check e303198309338 [[.under]] .sourceHead = true := by decide
def e303198309614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e303198309614 : Closed e303198309614 ∧ code e303198309614 = 4701244820718 := by decide
theorem cert_e303198309614 : check e303198309614 [[.under]] .sourceHead = true := by decide
def e303198309622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e303198309622 : Closed e303198309622 ∧ code e303198309622 = 4701244820726 := by decide
theorem cert_e303198309622 : check e303198309622 [[.under]] .sourceHead = true := by decide
def e303198309998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e303198309998 : Closed e303198309998 ∧ code e303198309998 = 4701244821102 := by decide
theorem cert_e303198309998 : check e303198309998 [[.under]] .sourceHead = true := by decide
def e303198310010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e303198310010 : Closed e303198310010 ∧ code e303198310010 = 4701244821114 := by decide
theorem cert_e303198310010 : check e303198310010 [[.under]] .sourceHead = true := by decide
def e303198310198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303198310198 : Closed e303198310198 ∧ code e303198310198 = 4701244821302 := by decide
theorem cert_e303198310198 : check e303198310198 [[.under]] .sourceHead = true := by decide
def e303198310202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303198310202 : Closed e303198310202 ∧ code e303198310202 = 4701244821306 := by decide
theorem cert_e303198310202 : check e303198310202 [[.under]] .sourceHead = true := by decide
def e303198317678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e303198317678 : Closed e303198317678 ∧ code e303198317678 = 4701244828782 := by decide
theorem cert_e303198317678 : check e303198317678 [[.under]] .sourceHead = true := by decide
def e303198317690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e303198317690 : Closed e303198317690 ∧ code e303198317690 = 4701244828794 := by decide
theorem cert_e303198317690 : check e303198317690 [[.under]] .sourceHead = true := by decide
def e303198317854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e303198317854 : Closed e303198317854 ∧ code e303198317854 = 4701244828958 := by decide
theorem cert_e303198317854 : check e303198317854 [[.under]] .sourceHead = true := by decide
def e303198318022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e303198318022 : Closed e303198318022 ∧ code e303198318022 = 4701244829126 := by decide
theorem cert_e303198318022 : check e303198318022 [[.under]] .sourceHead = true := by decide
def e303198318362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e303198318362 : Closed e303198318362 ∧ code e303198318362 = 4701244829466 := by decide
theorem cert_e303198318362 : check e303198318362 [[.under]] .sourceHead = true := by decide
def e303198318406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e303198318406 : Closed e303198318406 ∧ code e303198318406 = 4701244829510 := by decide
theorem cert_e303198318406 : check e303198318406 [[.under]] .sourceHead = true := by decide
def e303198319390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e303198319390 : Closed e303198319390 ∧ code e303198319390 = 4701244830494 := by decide
theorem cert_e303198319390 : check e303198319390 [[.under]] .sourceHead = true := by decide
def e303198319558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e303198319558 : Closed e303198319558 ∧ code e303198319558 = 4701244830662 := by decide
theorem cert_e303198319558 : check e303198319558 [[.under]] .sourceHead = true := by decide
def e303198321862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e303198321862 : Closed e303198321862 ∧ code e303198321862 = 4701244832966 := by decide
theorem cert_e303198321862 : check e303198321862 [[.under]] .sourceHead = true := by decide
def e303198344758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e303198344758 : Closed e303198344758 ∧ code e303198344758 = 4701244855862 := by decide
theorem cert_e303198344758 : check e303198344758 [[.under]] .sourceHead = true := by decide
def e303198344762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e303198344762 : Closed e303198344762 ∧ code e303198344762 = 4701244855866 := by decide
theorem cert_e303198344762 : check e303198344762 [[.under]] .sourceHead = true := by decide
def e303198344846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e303198344846 : Closed e303198344846 ∧ code e303198344846 = 4701244855950 := by decide
theorem cert_e303198344846 : check e303198344846 [[.under]] .sourceHead = true := by decide
def e303198344902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e303198344902 : Closed e303198344902 ∧ code e303198344902 = 4701244856006 := by decide
theorem cert_e303198344902 : check e303198344902 [[.under]] .sourceHead = true := by decide
def e303198344986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e303198344986 : Closed e303198344986 ∧ code e303198344986 = 4701244856090 := by decide
theorem cert_e303198344986 : check e303198344986 [[.under]] .sourceHead = true := by decide
def e303198345030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e303198345030 : Closed e303198345030 ∧ code e303198345030 = 4701244856134 := by decide
theorem cert_e303198345030 : check e303198345030 [[.under]] .sourceHead = true := by decide
def e303198345614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e303198345614 : Closed e303198345614 ∧ code e303198345614 = 4701244856718 := by decide
theorem cert_e303198345614 : check e303198345614 [[.under]] .sourceHead = true := by decide
def e303198345670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e303198345670 : Closed e303198345670 ∧ code e303198345670 = 4701244856774 := by decide
theorem cert_e303198345670 : check e303198345670 [[.under]] .sourceHead = true := by decide
def e303198346438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e303198346438 : Closed e303198346438 ∧ code e303198346438 = 4701244857542 := by decide
theorem cert_e303198346438 : check e303198346438 [[.under]] .sourceHead = true := by decide
def e303199443182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e303199443182 : Closed e303199443182 ∧ code e303199443182 = 4701245954286 := by decide
theorem cert_e303199443182 : check e303199443182 [[.under]] .sourceHead = true := by decide
def e303199443190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e303199443190 : Closed e303199443190 ∧ code e303199443190 = 4701245954294 := by decide
theorem cert_e303199443190 : check e303199443190 [[.under]] .sourceHead = true := by decide
def e303199443742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e303199443742 : Closed e303199443742 ∧ code e303199443742 = 4701245954846 := by decide
theorem cert_e303199443742 : check e303199443742 [[.under]] .sourceHead = true := by decide
def e303199443854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e303199443854 : Closed e303199443854 ∧ code e303199443854 = 4701245954958 := by decide
theorem cert_e303199443854 : check e303199443854 [[.under]] .sourceHead = true := by decide
def e303199444078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e303199444078 : Closed e303199444078 ∧ code e303199444078 = 4701245955182 := by decide
theorem cert_e303199444078 : check e303199444078 [[.under]] .sourceHead = true := by decide
def e303199444090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e303199444090 : Closed e303199444090 ∧ code e303199444090 = 4701245955194 := by decide
theorem cert_e303199444090 : check e303199444090 [[.under]] .sourceHead = true := by decide
def e303199444254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e303199444254 : Closed e303199444254 ∧ code e303199444254 = 4701245955358 := by decide
theorem cert_e303199444254 : check e303199444254 [[.under]] .sourceHead = true := by decide
def e303199444422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e303199444422 : Closed e303199444422 ∧ code e303199444422 = 4701245955526 := by decide
theorem cert_e303199444422 : check e303199444422 [[.under]] .sourceHead = true := by decide
def e303199444534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e303199444534 : Closed e303199444534 ∧ code e303199444534 = 4701245955638 := by decide
theorem cert_e303199444534 : check e303199444534 [[.under]] .sourceHead = true := by decide
def e303199444538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e303199444538 : Closed e303199444538 ∧ code e303199444538 = 4701245955642 := by decide
theorem cert_e303199444538 : check e303199444538 [[.under]] .sourceHead = true := by decide
def e303199444622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e303199444622 : Closed e303199444622 ∧ code e303199444622 = 4701245955726 := by decide
theorem cert_e303199444622 : check e303199444622 [[.under]] .sourceHead = true := by decide
def e303199444678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e303199444678 : Closed e303199444678 ∧ code e303199444678 = 4701245955782 := by decide
theorem cert_e303199444678 : check e303199444678 [[.under]] .sourceHead = true := by decide
def e303199446814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e303199446814 : Closed e303199446814 ∧ code e303199446814 = 4701245957918 := by decide
theorem cert_e303199446814 : check e303199446814 [[.under]] .sourceHead = true := by decide
def e303199446926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e303199446926 : Closed e303199446926 ∧ code e303199446926 = 4701245958030 := by decide
theorem cert_e303199446926 : check e303199446926 [[.under]] .sourceHead = true := by decide
def e303199449886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e303199449886 : Closed e303199449886 ∧ code e303199449886 = 4701245960990 := by decide
theorem cert_e303199449886 : check e303199449886 [[.under]] .sourceHead = true := by decide
def e303199450054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e303199450054 : Closed e303199450054 ∧ code e303199450054 = 4701245961158 := by decide
theorem cert_e303199450054 : check e303199450054 [[.under]] .sourceHead = true := by decide
def e303199451534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e303199451534 : Closed e303199451534 ∧ code e303199451534 = 4701245962638 := by decide
theorem cert_e303199451534 : check e303199451534 [[.under]] .sourceHead = true := by decide
def e303199451590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e303199451590 : Closed e303199451590 ∧ code e303199451590 = 4701245962694 := by decide
theorem cert_e303199451590 : check e303199451590 [[.under]] .sourceHead = true := by decide
def e303204144862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e303204144862 : Closed e303204144862 ∧ code e303204144862 = 4701250655966 := by decide
theorem cert_e303204144862 : check e303204144862 [[.under]] .sourceHead = true := by decide
def e303204144886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e303204144886 : Closed e303204144886 ∧ code e303204144886 = 4701250655990 := by decide
theorem cert_e303204144886 : check e303204144886 [[.under]] .sourceHead = true := by decide
def e303204144990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e303204144990 : Closed e303204144990 ∧ code e303204144990 = 4701250656094 := by decide
theorem cert_e303204144990 : check e303204144990 [[.under]] .sourceHead = true := by decide
def e303204145018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e303204145018 : Closed e303204145018 ∧ code e303204145018 = 4701250656122 := by decide
theorem cert_e303204145018 : check e303204145018 [[.under]] .sourceHead = true := by decide
def e303204145110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e303204145110 : Closed e303204145110 ∧ code e303204145110 = 4701250656214 := by decide
theorem cert_e303204145110 : check e303204145110 [[.under]] .sourceHead = true := by decide
def e303204145114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e303204145114 : Closed e303204145114 ∧ code e303204145114 = 4701250656218 := by decide
theorem cert_e303204145114 : check e303204145114 [[.under]] .sourceHead = true := by decide
def e303204145630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e303204145630 : Closed e303204145630 ∧ code e303204145630 = 4701250656734 := by decide
theorem cert_e303204145630 : check e303204145630 [[.under]] .sourceHead = true := by decide
def e303204145654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e303204145654 : Closed e303204145654 ∧ code e303204145654 = 4701250656758 := by decide
theorem cert_e303204145654 : check e303204145654 [[.under]] .sourceHead = true := by decide
def e303204146398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e303204146398 : Closed e303204146398 ∧ code e303204146398 = 4701250657502 := by decide
theorem cert_e303204146398 : check e303204146398 [[.under]] .sourceHead = true := by decide
def e303204146426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e303204146426 : Closed e303204146426 ∧ code e303204146426 = 4701250657530 := by decide
theorem cert_e303204146426 : check e303204146426 [[.under]] .sourceHead = true := by decide
def e303204146998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e303204146998 : Closed e303204146998 ∧ code e303204146998 = 4701250658102 := by decide
theorem cert_e303204146998 : check e303204146998 [[.under]] .sourceHead = true := by decide
def e303204147002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e303204147002 : Closed e303204147002 ∧ code e303204147002 = 4701250658106 := by decide
theorem cert_e303204147002 : check e303204147002 [[.under]] .sourceHead = true := by decide
end Blc.Floor42
