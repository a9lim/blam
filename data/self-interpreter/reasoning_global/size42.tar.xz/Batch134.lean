import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211181146074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 5) (.var 1))) (.var 0)))))))))
theorem wire_e1211181146074 : Closed e1211181146074 ∧ code e1211181146074 = 5609227657178 := by decide
theorem cert_e1211181146074 : check e1211181146074 [[],[]] .three = true := by decide
def e1211181147934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211181147934 : Closed e1211181147934 ∧ code e1211181147934 = 5609227659038 := by decide
theorem cert_e1211181147934 : check e1211181147934 [[],[]] .smaller = true := by decide
def e1211181148030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 5))))))))))
theorem wire_e1211181148030 : Closed e1211181148030 ∧ code e1211181148030 = 5609227659134 := by decide
theorem cert_e1211181148030 : check e1211181148030 [[],[]] .three = true := by decide
def e1211181148046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211181148046 : Closed e1211181148046 ∧ code e1211181148046 = 5609227659150 := by decide
theorem cert_e1211181148046 : check e1211181148046 [[],[]] .smaller = true := by decide
def e1211181148094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211181148094 : Closed e1211181148094 ∧ code e1211181148094 = 5609227659198 := by decide
theorem cert_e1211181148094 : check e1211181148094 [[],[]] .smaller = true := by decide
def e1211181148142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211181148142 : Closed e1211181148142 ∧ code e1211181148142 = 5609227659246 := by decide
theorem cert_e1211181148142 : check e1211181148142 [[],[]] .smaller = true := by decide
def e1211181148150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 5) (.var 1))))))))))
theorem wire_e1211181148150 : Closed e1211181148150 ∧ code e1211181148150 = 5609227659254 := by decide
theorem cert_e1211181148150 : check e1211181148150 [[],[]] .three = true := by decide
def e1211181151006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211181151006 : Closed e1211181151006 ∧ code e1211181151006 = 5609227662110 := by decide
theorem cert_e1211181151006 : check e1211181151006 [[],[]] .smaller = true := by decide
def e1211181151102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 5))))))))))
theorem wire_e1211181151102 : Closed e1211181151102 ∧ code e1211181151102 = 5609227662206 := by decide
theorem cert_e1211181151102 : check e1211181151102 [[],[]] .three = true := by decide
def e1211181151166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211181151166 : Closed e1211181151166 ∧ code e1211181151166 = 5609227662270 := by decide
theorem cert_e1211181151166 : check e1211181151166 [[],[]] .smaller = true := by decide
def e1211181151174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211181151174 : Closed e1211181151174 ∧ code e1211181151174 = 5609227662278 := by decide
theorem cert_e1211181151174 : check e1211181151174 [[],[]] .smaller = true := by decide
def e1211181151222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211181151222 : Closed e1211181151222 ∧ code e1211181151222 = 5609227662326 := by decide
theorem cert_e1211181151222 : check e1211181151222 [[],[]] .smaller = true := by decide
def e1211181151226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 5) (.var 0))))))))))
theorem wire_e1211181151226 : Closed e1211181151226 ∧ code e1211181151226 = 5609227662330 := by decide
theorem cert_e1211181151226 : check e1211181151226 [[],[]] .three = true := by decide
def e1211181152654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211181152654 : Closed e1211181152654 ∧ code e1211181152654 = 5609227663758 := by decide
theorem cert_e1211181152654 : check e1211181152654 [[],[]] .smaller = true := by decide
def e1211181152702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211181152702 : Closed e1211181152702 ∧ code e1211181152702 = 5609227663806 := by decide
theorem cert_e1211181152702 : check e1211181152702 [[],[]] .smaller = true := by decide
def e1211181152710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211181152710 : Closed e1211181152710 ∧ code e1211181152710 = 5609227663814 := by decide
theorem cert_e1211181152710 : check e1211181152710 [[],[]] .smaller = true := by decide
def e1211181152762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211181152762 : Closed e1211181152762 ∧ code e1211181152762 = 5609227663866 := by decide
theorem cert_e1211181152762 : check e1211181152762 [[],[]] .smaller = true := by decide
def e1211181153902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211181153902 : Closed e1211181153902 ∧ code e1211181153902 = 5609227665006 := by decide
theorem cert_e1211181153902 : check e1211181153902 [[],[]] .smaller = true := by decide
def e1211181153910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211181153910 : Closed e1211181153910 ∧ code e1211181153910 = 5609227665014 := by decide
theorem cert_e1211181153910 : check e1211181153910 [[],[]] .smaller = true := by decide
def e1211181153914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211181153914 : Closed e1211181153914 ∧ code e1211181153914 = 5609227665018 := by decide
theorem cert_e1211181153914 : check e1211181153914 [[],[]] .smaller = true := by decide
def e1211181154102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 5)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211181154102 : Closed e1211181154102 ∧ code e1211181154102 = 5609227665206 := by decide
theorem cert_e1211181154102 : check e1211181154102 [[],[]] .three = true := by decide
def e1211181154106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 5)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211181154106 : Closed e1211181154106 ∧ code e1211181154106 = 5609227665210 := by decide
theorem cert_e1211181154106 : check e1211181154106 [[],[]] .three = true := by decide
def e1211181155950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211181155950 : Closed e1211181155950 ∧ code e1211181155950 = 5609227667054 := by decide
theorem cert_e1211181155950 : check e1211181155950 [[],[]] .smaller = true := by decide
def e1211181155962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211181155962 : Closed e1211181155962 ∧ code e1211181155962 = 5609227667066 := by decide
theorem cert_e1211181155962 : check e1211181155962 [[],[]] .smaller = true := by decide
def e1211181156250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211181156250 : Closed e1211181156250 ∧ code e1211181156250 = 5609227667354 := by decide
theorem cert_e1211181156250 : check e1211181156250 [[],[]] .smaller = true := by decide
def e1211181157486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))))
theorem wire_e1211181157486 : Closed e1211181157486 ∧ code e1211181157486 = 5609227668590 := by decide
theorem cert_e1211181157486 : check e1211181157486 [[],[]] .smaller = true := by decide
def e1211181157498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))))
theorem wire_e1211181157498 : Closed e1211181157498 ∧ code e1211181157498 = 5609227668602 := by decide
theorem cert_e1211181157498 : check e1211181157498 [[],[]] .smaller = true := by decide
def e1211181157662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))))
theorem wire_e1211181157662 : Closed e1211181157662 ∧ code e1211181157662 = 5609227668766 := by decide
theorem cert_e1211181157662 : check e1211181157662 [[],[]] .smaller = true := by decide
def e1211181157758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 5)))))))))
theorem wire_e1211181157758 : Closed e1211181157758 ∧ code e1211181157758 = 5609227668862 := by decide
theorem cert_e1211181157758 : check e1211181157758 [[],[]] .three = true := by decide
def e1211181157822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 4)))))))))
theorem wire_e1211181157822 : Closed e1211181157822 ∧ code e1211181157822 = 5609227668926 := by decide
theorem cert_e1211181157822 : check e1211181157822 [[],[]] .smaller = true := by decide
def e1211181157830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))))
theorem wire_e1211181157830 : Closed e1211181157830 ∧ code e1211181157830 = 5609227668934 := by decide
theorem cert_e1211181157830 : check e1211181157830 [[],[]] .smaller = true := by decide
def e1211181157878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 1)))))))))
theorem wire_e1211181157878 : Closed e1211181157878 ∧ code e1211181157878 = 5609227668982 := by decide
theorem cert_e1211181157878 : check e1211181157878 [[],[]] .smaller = true := by decide
def e1211181157882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 5))) (.var 0)))))))))
theorem wire_e1211181157882 : Closed e1211181157882 ∧ code e1211181157882 = 5609227668986 := by decide
theorem cert_e1211181157882 : check e1211181157882 [[],[]] .three = true := by decide
def e1211181158078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 4)))))))))
theorem wire_e1211181158078 : Closed e1211181158078 ∧ code e1211181158078 = 5609227669182 := by decide
theorem cert_e1211181158078 : check e1211181158078 [[],[]] .smaller = true := by decide
def e1211181158138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 4))) (.var 0)))))))))
theorem wire_e1211181158138 : Closed e1211181158138 ∧ code e1211181158138 = 5609227669242 := by decide
theorem cert_e1211181158138 : check e1211181158138 [[],[]] .smaller = true := by decide
def e1211181158170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))))
theorem wire_e1211181158170 : Closed e1211181158170 ∧ code e1211181158170 = 5609227669274 := by decide
theorem cert_e1211181158170 : check e1211181158170 [[],[]] .smaller = true := by decide
def e1211181158214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))))
theorem wire_e1211181158214 : Closed e1211181158214 ∧ code e1211181158214 = 5609227669318 := by decide
theorem cert_e1211181158214 : check e1211181158214 [[],[]] .smaller = true := by decide
def e1211181158358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 1)))))))))
theorem wire_e1211181158358 : Closed e1211181158358 ∧ code e1211181158358 = 5609227669462 := by decide
theorem cert_e1211181158358 : check e1211181158358 [[],[]] .smaller = true := by decide
def e1211181158362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 1))) (.var 0)))))))))
theorem wire_e1211181158362 : Closed e1211181158362 ∧ code e1211181158362 = 5609227669466 := by decide
theorem cert_e1211181158362 : check e1211181158362 [[],[]] .smaller = true := by decide
def e1211181158378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 5) (.var 0))) (.var 0)))))))))
theorem wire_e1211181158378 : Closed e1211181158378 ∧ code e1211181158378 = 5609227669482 := by decide
theorem cert_e1211181158378 : check e1211181158378 [[],[]] .three = true := by decide
def e1211181159198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211181159198 : Closed e1211181159198 ∧ code e1211181159198 = 5609227670302 := by decide
theorem cert_e1211181159198 : check e1211181159198 [[],[]] .smaller = true := by decide
def e1211181159294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 5))))))))))
theorem wire_e1211181159294 : Closed e1211181159294 ∧ code e1211181159294 = 5609227670398 := by decide
theorem cert_e1211181159294 : check e1211181159294 [[],[]] .three = true := by decide
def e1211181159358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211181159358 : Closed e1211181159358 ∧ code e1211181159358 = 5609227670462 := by decide
theorem cert_e1211181159358 : check e1211181159358 [[],[]] .smaller = true := by decide
def e1211181159366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211181159366 : Closed e1211181159366 ∧ code e1211181159366 = 5609227670470 := by decide
theorem cert_e1211181159366 : check e1211181159366 [[],[]] .smaller = true := by decide
def e1211181159414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211181159414 : Closed e1211181159414 ∧ code e1211181159414 = 5609227670518 := by decide
theorem cert_e1211181159414 : check e1211181159414 [[],[]] .smaller = true := by decide
def e1211181159418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 5) (.var 0))))))))))
theorem wire_e1211181159418 : Closed e1211181159418 ∧ code e1211181159418 = 5609227670522 := by decide
theorem cert_e1211181159418 : check e1211181159418 [[],[]] .three = true := by decide
def e1211181160894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211181160894 : Closed e1211181160894 ∧ code e1211181160894 = 5609227671998 := by decide
theorem cert_e1211181160894 : check e1211181160894 [[],[]] .smaller = true := by decide
def e1211181160954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211181160954 : Closed e1211181160954 ∧ code e1211181160954 = 5609227672058 := by decide
theorem cert_e1211181160954 : check e1211181160954 [[],[]] .smaller = true := by decide
def e1211181161670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211181161670 : Closed e1211181161670 ∧ code e1211181161670 = 5609227672774 := by decide
theorem cert_e1211181161670 : check e1211181161670 [[],[]] .smaller = true := by decide
def e1211181162294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211181162294 : Closed e1211181162294 ∧ code e1211181162294 = 5609227673398 := by decide
theorem cert_e1211181162294 : check e1211181162294 [[],[]] .smaller = true := by decide
def e1211181162298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211181162298 : Closed e1211181162298 ∧ code e1211181162298 = 5609227673402 := by decide
theorem cert_e1211181162298 : check e1211181162298 [[],[]] .smaller = true := by decide
def e1211181162394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 5)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211181162394 : Closed e1211181162394 ∧ code e1211181162394 = 5609227673498 := by decide
theorem cert_e1211181162394 : check e1211181162394 [[],[]] .three = true := by decide
def e1211181163318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211181163318 : Closed e1211181163318 ∧ code e1211181163318 = 5609227674422 := by decide
theorem cert_e1211181163318 : check e1211181163318 [[],[]] .smaller = true := by decide
def e1211181163322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211181163322 : Closed e1211181163322 ∧ code e1211181163322 = 5609227674426 := by decide
theorem cert_e1211181163322 : check e1211181163322 [[],[]] .smaller = true := by decide
def e1211181163418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211181163418 : Closed e1211181163418 ∧ code e1211181163418 = 5609227674522 := by decide
theorem cert_e1211181163418 : check e1211181163418 [[],[]] .smaller = true := by decide
def e1211181164086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))))
theorem wire_e1211181164086 : Closed e1211181164086 ∧ code e1211181164086 = 5609227675190 := by decide
theorem cert_e1211181164086 : check e1211181164086 [[],[]] .smaller = true := by decide
def e1211181164090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e1211181164090 : Closed e1211181164090 ∧ code e1211181164090 = 5609227675194 := by decide
theorem cert_e1211181164090 : check e1211181164090 [[],[]] .smaller = true := by decide
def e1211181164174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))))
theorem wire_e1211181164174 : Closed e1211181164174 ∧ code e1211181164174 = 5609227675278 := by decide
theorem cert_e1211181164174 : check e1211181164174 [[],[]] .smaller = true := by decide
def e1211181164222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 4)))))))))
theorem wire_e1211181164222 : Closed e1211181164222 ∧ code e1211181164222 = 5609227675326 := by decide
theorem cert_e1211181164222 : check e1211181164222 [[],[]] .smaller = true := by decide
def e1211181164230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))))
theorem wire_e1211181164230 : Closed e1211181164230 ∧ code e1211181164230 = 5609227675334 := by decide
theorem cert_e1211181164230 : check e1211181164230 [[],[]] .smaller = true := by decide
def e1211181164282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 4))) (.var 0)))))))))
theorem wire_e1211181164282 : Closed e1211181164282 ∧ code e1211181164282 = 5609227675386 := by decide
theorem cert_e1211181164282 : check e1211181164282 [[],[]] .smaller = true := by decide
def e1211181164314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))))
theorem wire_e1211181164314 : Closed e1211181164314 ∧ code e1211181164314 = 5609227675418 := by decide
theorem cert_e1211181164314 : check e1211181164314 [[],[]] .smaller = true := by decide
def e1211181164358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))))
theorem wire_e1211181164358 : Closed e1211181164358 ∧ code e1211181164358 = 5609227675462 := by decide
theorem cert_e1211181164358 : check e1211181164358 [[],[]] .smaller = true := by decide
def e1211181164522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 0))) (.var 0)))))))))
theorem wire_e1211181164522 : Closed e1211181164522 ∧ code e1211181164522 = 5609227675626 := by decide
theorem cert_e1211181164522 : check e1211181164522 [[],[]] .smaller = true := by decide
def e1211181164942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211181164942 : Closed e1211181164942 ∧ code e1211181164942 = 5609227676046 := by decide
theorem cert_e1211181164942 : check e1211181164942 [[],[]] .smaller = true := by decide
def e1211181164990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211181164990 : Closed e1211181164990 ∧ code e1211181164990 = 5609227676094 := by decide
theorem cert_e1211181164990 : check e1211181164990 [[],[]] .smaller = true := by decide
def e1211181164998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211181164998 : Closed e1211181164998 ∧ code e1211181164998 = 5609227676102 := by decide
theorem cert_e1211181164998 : check e1211181164998 [[],[]] .smaller = true := by decide
def e1211181165050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211181165050 : Closed e1211181165050 ∧ code e1211181165050 = 5609227676154 := by decide
theorem cert_e1211181165050 : check e1211181165050 [[],[]] .smaller = true := by decide
def e1211181165766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211181165766 : Closed e1211181165766 ∧ code e1211181165766 = 5609227676870 := by decide
theorem cert_e1211181165766 : check e1211181165766 [[],[]] .smaller = true := by decide
def e1211181166490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211181166490 : Closed e1211181166490 ∧ code e1211181166490 = 5609227677594 := by decide
theorem cert_e1211181166490 : check e1211181166490 [[],[]] .smaller = true := by decide
def e1211181169070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e1211181169070 : Closed e1211181169070 ∧ code e1211181169070 = 5609227680174 := by decide
theorem cert_e1211181169070 : check e1211181169070 [[],[]] .smaller = true := by decide
def e1211181169078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211181169078 : Closed e1211181169078 ∧ code e1211181169078 = 5609227680182 := by decide
theorem cert_e1211181169078 : check e1211181169078 [[],[]] .smaller = true := by decide
def e1211181169082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e1211181169082 : Closed e1211181169082 ∧ code e1211181169082 = 5609227680186 := by decide
theorem cert_e1211181169082 : check e1211181169082 [[],[]] .smaller = true := by decide
def e1211181169110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211181169110 : Closed e1211181169110 ∧ code e1211181169110 = 5609227680214 := by decide
theorem cert_e1211181169110 : check e1211181169110 [[],[]] .smaller = true := by decide
def e1211181169114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211181169114 : Closed e1211181169114 ∧ code e1211181169114 = 5609227680218 := by decide
theorem cert_e1211181169114 : check e1211181169114 [[],[]] .smaller = true := by decide
def e1211181169130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e1211181169130 : Closed e1211181169130 ∧ code e1211181169130 = 5609227680234 := by decide
theorem cert_e1211181169130 : check e1211181169130 [[],[]] .smaller = true := by decide
def e1211181169262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211181169262 : Closed e1211181169262 ∧ code e1211181169262 = 5609227680366 := by decide
theorem cert_e1211181169262 : check e1211181169262 [[],[]] .smaller = true := by decide
def e1211181169270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211181169270 : Closed e1211181169270 ∧ code e1211181169270 = 5609227680374 := by decide
theorem cert_e1211181169270 : check e1211181169270 [[],[]] .smaller = true := by decide
def e1211181169274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211181169274 : Closed e1211181169274 ∧ code e1211181169274 = 5609227680378 := by decide
theorem cert_e1211181169274 : check e1211181169274 [[],[]] .smaller = true := by decide
def e1211181169462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211181169462 : Closed e1211181169462 ∧ code e1211181169462 = 5609227680566 := by decide
theorem cert_e1211181169462 : check e1211181169462 [[],[]] .smaller = true := by decide
def e1211181169466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211181169466 : Closed e1211181169466 ∧ code e1211181169466 = 5609227680570 := by decide
theorem cert_e1211181169466 : check e1211181169466 [[],[]] .smaller = true := by decide
def e1211181169562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211181169562 : Closed e1211181169562 ∧ code e1211181169562 = 5609227680666 := by decide
theorem cert_e1211181169562 : check e1211181169562 [[],[]] .smaller = true := by decide
def e1211181169878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211181169878 : Closed e1211181169878 ∧ code e1211181169878 = 5609227680982 := by decide
theorem cert_e1211181169878 : check e1211181169878 [[],[]] .three = true := by decide
def e1211181169882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211181169882 : Closed e1211181169882 ∧ code e1211181169882 = 5609227680986 := by decide
theorem cert_e1211181169882 : check e1211181169882 [[],[]] .three = true := by decide
def e1211181169898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211181169898 : Closed e1211181169898 ∧ code e1211181169898 = 5609227681002 := by decide
theorem cert_e1211181169898 : check e1211181169898 [[],[]] .three = true := by decide
def e1211181169974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211181169974 : Closed e1211181169974 ∧ code e1211181169974 = 5609227681078 := by decide
theorem cert_e1211181169974 : check e1211181169974 [[],[]] .three = true := by decide
def e1211181169978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211181169978 : Closed e1211181169978 ∧ code e1211181169978 = 5609227681082 := by decide
theorem cert_e1211181169978 : check e1211181169978 [[],[]] .three = true := by decide
def e1211181170074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211181170074 : Closed e1211181170074 ∧ code e1211181170074 = 5609227681178 := by decide
theorem cert_e1211181170074 : check e1211181170074 [[],[]] .three = true := by decide
def e1211181176542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))))
theorem wire_e1211181176542 : Closed e1211181176542 ∧ code e1211181176542 = 5609227687646 := by decide
theorem cert_e1211181176542 : check e1211181176542 [[],[]] .smaller = true := by decide
def e1211181176566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))))
theorem wire_e1211181176566 : Closed e1211181176566 ∧ code e1211181176566 = 5609227687670 := by decide
theorem cert_e1211181176566 : check e1211181176566 [[],[]] .smaller = true := by decide
def e1211181176670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))))
theorem wire_e1211181176670 : Closed e1211181176670 ∧ code e1211181176670 = 5609227687774 := by decide
theorem cert_e1211181176670 : check e1211181176670 [[],[]] .smaller = true := by decide
def e1211181176698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))))
theorem wire_e1211181176698 : Closed e1211181176698 ∧ code e1211181176698 = 5609227687802 := by decide
theorem cert_e1211181176698 : check e1211181176698 [[],[]] .smaller = true := by decide
def e1211181176790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))))
theorem wire_e1211181176790 : Closed e1211181176790 ∧ code e1211181176790 = 5609227687894 := by decide
theorem cert_e1211181176790 : check e1211181176790 [[],[]] .smaller = true := by decide
def e1211181176794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))))
theorem wire_e1211181176794 : Closed e1211181176794 ∧ code e1211181176794 = 5609227687898 := by decide
theorem cert_e1211181176794 : check e1211181176794 [[],[]] .smaller = true := by decide
def e1211181177310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))))
theorem wire_e1211181177310 : Closed e1211181177310 ∧ code e1211181177310 = 5609227688414 := by decide
theorem cert_e1211181177310 : check e1211181177310 [[],[]] .smaller = true := by decide
def e1211181177334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))))
theorem wire_e1211181177334 : Closed e1211181177334 ∧ code e1211181177334 = 5609227688438 := by decide
theorem cert_e1211181177334 : check e1211181177334 [[],[]] .smaller = true := by decide
def e1211181178078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))))
theorem wire_e1211181178078 : Closed e1211181178078 ∧ code e1211181178078 = 5609227689182 := by decide
theorem cert_e1211181178078 : check e1211181178078 [[],[]] .smaller = true := by decide
def e1211181178106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))))
theorem wire_e1211181178106 : Closed e1211181178106 ∧ code e1211181178106 = 5609227689210 := by decide
theorem cert_e1211181178106 : check e1211181178106 [[],[]] .smaller = true := by decide
def e1211181178678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211181178678 : Closed e1211181178678 ∧ code e1211181178678 = 5609227689782 := by decide
theorem cert_e1211181178678 : check e1211181178678 [[],[]] .smaller = true := by decide
def e1211181178682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211181178682 : Closed e1211181178682 ∧ code e1211181178682 = 5609227689786 := by decide
theorem cert_e1211181178682 : check e1211181178682 [[],[]] .smaller = true := by decide
def e1211181193454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))))
theorem wire_e1211181193454 : Closed e1211181193454 ∧ code e1211181193454 = 5609227704558 := by decide
theorem cert_e1211181193454 : check e1211181193454 [[],[]] .smaller = true := by decide
def e1211181193462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))))
theorem wire_e1211181193462 : Closed e1211181193462 ∧ code e1211181193462 = 5609227704566 := by decide
theorem cert_e1211181193462 : check e1211181193462 [[],[]] .smaller = true := by decide
def e1211181194014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))))
theorem wire_e1211181194014 : Closed e1211181194014 ∧ code e1211181194014 = 5609227705118 := by decide
theorem cert_e1211181194014 : check e1211181194014 [[],[]] .smaller = true := by decide
def e1211181194110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 5))))))))))
theorem wire_e1211181194110 : Closed e1211181194110 ∧ code e1211181194110 = 5609227705214 := by decide
theorem cert_e1211181194110 : check e1211181194110 [[],[]] .three = true := by decide
def e1211181194126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))))
theorem wire_e1211181194126 : Closed e1211181194126 ∧ code e1211181194126 = 5609227705230 := by decide
theorem cert_e1211181194126 : check e1211181194126 [[],[]] .smaller = true := by decide
def e1211181194174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 4))))))))))
theorem wire_e1211181194174 : Closed e1211181194174 ∧ code e1211181194174 = 5609227705278 := by decide
theorem cert_e1211181194174 : check e1211181194174 [[],[]] .smaller = true := by decide
def e1211181194222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 2))))))))))
theorem wire_e1211181194222 : Closed e1211181194222 ∧ code e1211181194222 = 5609227705326 := by decide
theorem cert_e1211181194222 : check e1211181194222 [[],[]] .smaller = true := by decide
def e1211181194230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 5)) (.var 1))))))))))
theorem wire_e1211181194230 : Closed e1211181194230 ∧ code e1211181194230 = 5609227705334 := by decide
theorem cert_e1211181194230 : check e1211181194230 [[],[]] .three = true := by decide
def e1211181194350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))))
theorem wire_e1211181194350 : Closed e1211181194350 ∧ code e1211181194350 = 5609227705454 := by decide
theorem cert_e1211181194350 : check e1211181194350 [[],[]] .smaller = true := by decide
def e1211181194362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))))
theorem wire_e1211181194362 : Closed e1211181194362 ∧ code e1211181194362 = 5609227705466 := by decide
theorem cert_e1211181194362 : check e1211181194362 [[],[]] .smaller = true := by decide
def e1211181194526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))))
theorem wire_e1211181194526 : Closed e1211181194526 ∧ code e1211181194526 = 5609227705630 := by decide
theorem cert_e1211181194526 : check e1211181194526 [[],[]] .smaller = true := by decide
def e1211181194622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 5))))))))))
theorem wire_e1211181194622 : Closed e1211181194622 ∧ code e1211181194622 = 5609227705726 := by decide
theorem cert_e1211181194622 : check e1211181194622 [[],[]] .three = true := by decide
def e1211181194686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 4))))))))))
theorem wire_e1211181194686 : Closed e1211181194686 ∧ code e1211181194686 = 5609227705790 := by decide
theorem cert_e1211181194686 : check e1211181194686 [[],[]] .smaller = true := by decide
def e1211181194694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))))
theorem wire_e1211181194694 : Closed e1211181194694 ∧ code e1211181194694 = 5609227705798 := by decide
theorem cert_e1211181194694 : check e1211181194694 [[],[]] .smaller = true := by decide
def e1211181194742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 1))))))))))
theorem wire_e1211181194742 : Closed e1211181194742 ∧ code e1211181194742 = 5609227705846 := by decide
theorem cert_e1211181194742 : check e1211181194742 [[],[]] .smaller = true := by decide
def e1211181194746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 5)) (.var 0))))))))))
theorem wire_e1211181194746 : Closed e1211181194746 ∧ code e1211181194746 = 5609227705850 := by decide
theorem cert_e1211181194746 : check e1211181194746 [[],[]] .three = true := by decide
def e1211181194806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e1211181194806 : Closed e1211181194806 ∧ code e1211181194806 = 5609227705910 := by decide
theorem cert_e1211181194806 : check e1211181194806 [[],[]] .smaller = true := by decide
def e1211181194810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e1211181194810 : Closed e1211181194810 ∧ code e1211181194810 = 5609227705914 := by decide
theorem cert_e1211181194810 : check e1211181194810 [[],[]] .smaller = true := by decide
def e1211181194894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e1211181194894 : Closed e1211181194894 ∧ code e1211181194894 = 5609227705998 := by decide
theorem cert_e1211181194894 : check e1211181194894 [[],[]] .smaller = true := by decide
def e1211181194942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 4))))))))))
theorem wire_e1211181194942 : Closed e1211181194942 ∧ code e1211181194942 = 5609227706046 := by decide
theorem cert_e1211181194942 : check e1211181194942 [[],[]] .smaller = true := by decide
def e1211181194950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e1211181194950 : Closed e1211181194950 ∧ code e1211181194950 = 5609227706054 := by decide
theorem cert_e1211181194950 : check e1211181194950 [[],[]] .smaller = true := by decide
def e1211181195002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 4)) (.var 0))))))))))
theorem wire_e1211181195002 : Closed e1211181195002 ∧ code e1211181195002 = 5609227706106 := by decide
theorem cert_e1211181195002 : check e1211181195002 [[],[]] .smaller = true := by decide
def e1211181195182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 2))))))))))
theorem wire_e1211181195182 : Closed e1211181195182 ∧ code e1211181195182 = 5609227706286 := by decide
theorem cert_e1211181195182 : check e1211181195182 [[],[]] .smaller = true := by decide
def e1211181195190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 1))))))))))
theorem wire_e1211181195190 : Closed e1211181195190 ∧ code e1211181195190 = 5609227706294 := by decide
theorem cert_e1211181195190 : check e1211181195190 [[],[]] .smaller = true := by decide
def e1211181195194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 2)) (.var 0))))))))))
theorem wire_e1211181195194 : Closed e1211181195194 ∧ code e1211181195194 = 5609227706298 := by decide
theorem cert_e1211181195194 : check e1211181195194 [[],[]] .smaller = true := by decide
def e1211181195222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 5) (.var 0)) (.var 1))))))))))
theorem wire_e1211181195222 : Closed e1211181195222 ∧ code e1211181195222 = 5609227706326 := by decide
theorem cert_e1211181195222 : check e1211181195222 [[],[]] .three = true := by decide
def e1211181195226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 5) (.var 1)) (.var 0))))))))))
theorem wire_e1211181195226 : Closed e1211181195226 ∧ code e1211181195226 = 5609227706330 := by decide
theorem cert_e1211181195226 : check e1211181195226 [[],[]] .three = true := by decide
def e1211181197086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))))
theorem wire_e1211181197086 : Closed e1211181197086 ∧ code e1211181197086 = 5609227708190 := by decide
theorem cert_e1211181197086 : check e1211181197086 [[],[]] .smaller = true := by decide
def e1211181197182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 5)))))))))))
theorem wire_e1211181197182 : Closed e1211181197182 ∧ code e1211181197182 = 5609227708286 := by decide
theorem cert_e1211181197182 : check e1211181197182 [[],[]] .three = true := by decide
def e1211181197198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))))
theorem wire_e1211181197198 : Closed e1211181197198 ∧ code e1211181197198 = 5609227708302 := by decide
theorem cert_e1211181197198 : check e1211181197198 [[],[]] .smaller = true := by decide
def e1211181197246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 4)))))))))))
theorem wire_e1211181197246 : Closed e1211181197246 ∧ code e1211181197246 = 5609227708350 := by decide
theorem cert_e1211181197246 : check e1211181197246 [[],[]] .smaller = true := by decide
def e1211181197294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 2)))))))))))
theorem wire_e1211181197294 : Closed e1211181197294 ∧ code e1211181197294 = 5609227708398 := by decide
theorem cert_e1211181197294 : check e1211181197294 [[],[]] .smaller = true := by decide
def e1211181197302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 5) (.var 1)))))))))))
theorem wire_e1211181197302 : Closed e1211181197302 ∧ code e1211181197302 = 5609227708406 := by decide
theorem cert_e1211181197302 : check e1211181197302 [[],[]] .three = true := by decide
def e1211181200158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))
theorem wire_e1211181200158 : Closed e1211181200158 ∧ code e1211181200158 = 5609227711262 := by decide
theorem cert_e1211181200158 : check e1211181200158 [[],[]] .smaller = true := by decide
def e1211181200254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 5)))))))))))
theorem wire_e1211181200254 : Closed e1211181200254 ∧ code e1211181200254 = 5609227711358 := by decide
theorem cert_e1211181200254 : check e1211181200254 [[],[]] .three = true := by decide
def e1211181200318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211181200318 : Closed e1211181200318 ∧ code e1211181200318 = 5609227711422 := by decide
theorem cert_e1211181200318 : check e1211181200318 [[],[]] .smaller = true := by decide
def e1211181200326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))))
theorem wire_e1211181200326 : Closed e1211181200326 ∧ code e1211181200326 = 5609227711430 := by decide
theorem cert_e1211181200326 : check e1211181200326 [[],[]] .smaller = true := by decide
def e1211181200374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211181200374 : Closed e1211181200374 ∧ code e1211181200374 = 5609227711478 := by decide
theorem cert_e1211181200374 : check e1211181200374 [[],[]] .smaller = true := by decide
def e1211181200378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 5) (.var 0)))))))))))
theorem wire_e1211181200378 : Closed e1211181200378 ∧ code e1211181200378 = 5609227711482 := by decide
theorem cert_e1211181200378 : check e1211181200378 [[],[]] .three = true := by decide
def e1211181201806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e1211181201806 : Closed e1211181201806 ∧ code e1211181201806 = 5609227712910 := by decide
theorem cert_e1211181201806 : check e1211181201806 [[],[]] .smaller = true := by decide
def e1211181201854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 4)))))))))))
theorem wire_e1211181201854 : Closed e1211181201854 ∧ code e1211181201854 = 5609227712958 := by decide
theorem cert_e1211181201854 : check e1211181201854 [[],[]] .smaller = true := by decide
def e1211181201862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e1211181201862 : Closed e1211181201862 ∧ code e1211181201862 = 5609227712966 := by decide
theorem cert_e1211181201862 : check e1211181201862 [[],[]] .smaller = true := by decide
def e1211181201914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 4) (.var 0)))))))))))
theorem wire_e1211181201914 : Closed e1211181201914 ∧ code e1211181201914 = 5609227713018 := by decide
theorem cert_e1211181201914 : check e1211181201914 [[],[]] .smaller = true := by decide
def e1211181203054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211181203054 : Closed e1211181203054 ∧ code e1211181203054 = 5609227714158 := by decide
theorem cert_e1211181203054 : check e1211181203054 [[],[]] .smaller = true := by decide
def e1211181203062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211181203062 : Closed e1211181203062 ∧ code e1211181203062 = 5609227714166 := by decide
theorem cert_e1211181203062 : check e1211181203062 [[],[]] .smaller = true := by decide
def e1211181203066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211181203066 : Closed e1211181203066 ∧ code e1211181203066 = 5609227714170 := by decide
theorem cert_e1211181203066 : check e1211181203066 [[],[]] .smaller = true := by decide
def e1211181203254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211181203254 : Closed e1211181203254 ∧ code e1211181203254 = 5609227714358 := by decide
theorem cert_e1211181203254 : check e1211181203254 [[],[]] .three = true := by decide
def e1211181203258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211181203258 : Closed e1211181203258 ∧ code e1211181203258 = 5609227714362 := by decide
theorem cert_e1211181203258 : check e1211181203258 [[],[]] .three = true := by decide
def e1211181239150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e1211181239150 : Closed e1211181239150 ∧ code e1211181239150 = 5609227750254 := by decide
theorem cert_e1211181239150 : check e1211181239150 [[],[]] .smaller = true := by decide
def e1211181239158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e1211181239158 : Closed e1211181239158 ∧ code e1211181239158 = 5609227750262 := by decide
theorem cert_e1211181239158 : check e1211181239158 [[],[]] .smaller = true := by decide
def e1211181239214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e1211181239214 : Closed e1211181239214 ∧ code e1211181239214 = 5609227750318 := by decide
theorem cert_e1211181239214 : check e1211181239214 [[],[]] .smaller = true := by decide
def e1211181239226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e1211181239226 : Closed e1211181239226 ∧ code e1211181239226 = 5609227750330 := by decide
theorem cert_e1211181239226 : check e1211181239226 [[],[]] .smaller = true := by decide
def e1211181239254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e1211181239254 : Closed e1211181239254 ∧ code e1211181239254 = 5609227750358 := by decide
theorem cert_e1211181239254 : check e1211181239254 [[],[]] .smaller = true := by decide
def e1211181239258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e1211181239258 : Closed e1211181239258 ∧ code e1211181239258 = 5609227750362 := by decide
theorem cert_e1211181239258 : check e1211181239258 [[],[]] .smaller = true := by decide
def e1211181239534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e1211181239534 : Closed e1211181239534 ∧ code e1211181239534 = 5609227750638 := by decide
theorem cert_e1211181239534 : check e1211181239534 [[],[]] .smaller = true := by decide
def e1211181239542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e1211181239542 : Closed e1211181239542 ∧ code e1211181239542 = 5609227750646 := by decide
theorem cert_e1211181239542 : check e1211181239542 [[],[]] .smaller = true := by decide
def e1211181239918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e1211181239918 : Closed e1211181239918 ∧ code e1211181239918 = 5609227751022 := by decide
theorem cert_e1211181239918 : check e1211181239918 [[],[]] .smaller = true := by decide
def e1211181239930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e1211181239930 : Closed e1211181239930 ∧ code e1211181239930 = 5609227751034 := by decide
theorem cert_e1211181239930 : check e1211181239930 [[],[]] .smaller = true := by decide
def e1211181240118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e1211181240118 : Closed e1211181240118 ∧ code e1211181240118 = 5609227751222 := by decide
theorem cert_e1211181240118 : check e1211181240118 [[],[]] .smaller = true := by decide
def e1211181240122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e1211181240122 : Closed e1211181240122 ∧ code e1211181240122 = 5609227751226 := by decide
theorem cert_e1211181240122 : check e1211181240122 [[],[]] .smaller = true := by decide
end Blc.Floor42
