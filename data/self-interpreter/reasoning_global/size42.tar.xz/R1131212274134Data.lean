import R1131212274134V0
import R1131212274134K0
import R1131212274134st0
import R1131212274134hs0
import CodeBridge
import Batch062
namespace Certgen.R1131212274134
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 73,.app 2 64,.app 3 55,.app 4 26,.app 5 23,.app 6 11,.lam 7,.lam 8,.app 9 10,.var 1,.var 1,.lam 12,.app 13 14,.var 0,.lam 15,.lam 16,.app 17 22,.app 18 19,.var 2,.app 20 21,.var 1,.var 0,.var 1,.lam 24,.lam 25,.var 0,.lam 27,.app 28 33,.app 29 30,.var 0,.lam 31,.lam 32,.var 1,.lam 34,.app 35 40,.app 36 37,.var 0,.lam 38,.lam 39,.var 1,.lam 41,.app 42 47,.app 43 44,.var 0,.lam 45,.lam 46,.var 0,.lam 48,.app 49 54,.app 50 51,.var 0,.lam 52,.lam 53,.var 1,.opaque,.app 56 60,.lam 57,.app 58 59,.var 0,.var 0,.lam 61,.app 62 63,.var 0,.var 0,.app 65 69,.lam 66,.app 67 68,.var 0,.var 0,.lam 70,.app 71 72,.var 0,.var 0,.app 74 78,.lam 75,.app 76 77,.var 0,.var 0,.lam 79,.app 80 81,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (if i < 40 then (V20[i-20]?.getD []) else (V40[i-40]?.getD [])))
def K (i : Nat) : List Frame := (if i < 40 then (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD [])) else (if i < 60 then (K40[i-40]?.getD []) else (K60[i-60]?.getD [])))
def st (i : Nat) : AState := if i < 211 then (if i < 100 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else (if i < 160 then (if i < 120 then (st100[i-100]?.getD entry) else (if i < 140 then (st120[i-120]?.getD entry) else (st140[i-140]?.getD entry))) else (if i < 180 then (st160[i-160]?.getD entry) else (if i < 200 then (st180[i-180]?.getD entry) else (st200[i-200]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 100 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])))) else (if i < 160 then (if i < 120 then (hs100[i-100]?.getD []) else (if i < 140 then (hs120[i-120]?.getD []) else (hs140[i-140]?.getD []))) else (if i < 180 then (hs160[i-160]?.getD []) else (if i < 200 then (hs180[i-180]?.getD []) else (hs200[i-200]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R1131212274134
