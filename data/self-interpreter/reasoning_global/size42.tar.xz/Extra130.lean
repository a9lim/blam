import Batch130
import ExtraBase
namespace Blc.Floor42.Extra130
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1209576209626 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1209576209626 : ¬ IsSelfInterpreter e1209576209626 := by
  intro he
  have hp := replay_sound (t := (.app e1209576209626 diag)) (u := t_e1209576209626) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209576209626) (by decide) (by decide) hj
#print axioms ex_e1209576209626
private def t_e1209576209642 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1209576209642 : ¬ IsSelfInterpreter e1209576209642 := by
  intro he
  have hp := replay_sound (t := (.app e1209576209642 diag)) (u := t_e1209576209642) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1209576209642) (by decide) (by decide) hj
#print axioms ex_e1209576209642
end Blc.Floor42.Extra130
