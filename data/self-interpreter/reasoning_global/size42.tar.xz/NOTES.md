# Size 42 complete

No globally shortest 42-bit exact self-interpreter exists. Conditional on excluding size 41, the global lower bound is 43 bits. The full classification, evidence boundaries and replay instructions are in REPORT-42.md.

- Three enumerations agree: 452,574,468 closed, 187,140 broadly admissible, 43,244 candidates, comprising 37,568 application and 5,676 literal roots.
- All 41,022 finite predicates replay independently. All 2,222 direct exclusions and all exact wire identities compiled in the clean Lean replay. Every one of the 491 first-pass residuals has a direct theorem in residuals.tsv. No survivors.
- ChainModel.necessary supplies an all-size finite ordered-table obstruction; 215 selected witnesses use it, independently grade-audited. The remaining 276 residuals use single-object, weighted, regular or finite call/source obstructions.
- Clean proof and axiom audit passed 923 modules in 704.245 cumulative seconds. The largest clean process used 731,381,760 bytes. All three standard checks passed.
- The independent grade checker prototype exceeded the process budget and was killed at 1,644 MiB. The corrected free-slot cache reran the complete ledger and grade audit at 118,571,008 bytes. The supervisor recorded one strike and a peak lane tree of 2,241 MiB. See resource-summary.json.
