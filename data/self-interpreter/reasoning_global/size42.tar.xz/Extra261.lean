import Batch261
import ExtraBase
namespace Blc.Floor42.Extra261
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211584974650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))) (.app (.var 1) (.var 0)))))))))
theorem ex_e1211584974650 : ¬ IsSelfInterpreter e1211584974650 := by
  intro he
  have hp := replay_sound (t := e1211584974650) (u := t_e1211584974650) (ps := [[],[],[],[],[.under,.right],[.under,.right,.under,.left],[.under,.right,.under],[.under,.right,.under,.right]]) (by decide)
  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)
  exact (by decide : ¬ 1 ≤ occ 0 (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))) (.app (.var 1) (.var 0))))))))) h
#print axioms ex_e1211584974650
private def t_e1211584978042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem ex_e1211584978042 : ¬ IsSelfInterpreter e1211584978042 := by
  intro he
  have hp := replay_sound (t := e1211584978042) (u := t_e1211584978042) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (SO.app (SO.app (SO.var 2) (SO.app (SO.var 1) (so_dead (by decide) (SO.var 3)))) (SO.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 2)))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1211584978042
private def t_e1211584978134 : Term := (.lam (.lam (.var 1)))
theorem ex_e1211584978134 : ¬ IsSelfInterpreter e1211584978134 := by
  intro he
  have hp := replay_sound (t := (.app e1211584978134 churchTrue)) (u := t_e1211584978134) (ps := [[.left],[.left],[.left],[.left],[],[.left,.right,.right],[.left],[.left,.left],[.left,.left,.under,.left,.right],[.left],[.left,.left],[.left,.left,.under,.left,.right],[.left],[.left,.left,.right,.under],[.left,.left],[.left,.left],[.left],[]]) (by decide)
  apply specialized_not_so he hp
  exact (so_closed_lam (by decide) (so_dead (by decide) (SO.var 1)))
#print axioms ex_e1211584978134
private def t_e1211584978138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1211584978138 : ¬ IsSelfInterpreter e1211584978138 := by
  intro he
  have hp := replay_sound (t := (.app e1211584978138 diag)) (u := t_e1211584978138) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211584978138) (by decide) (by decide) hj
#print axioms ex_e1211584978138
private def t_e1211584978154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e1211584978154 : ¬ IsSelfInterpreter e1211584978154 := by
  intro he
  have hp := replay_sound (t := (.app e1211584978154 diag)) (u := t_e1211584978154) (ps := []) (by decide)
  obtain ⟨n, hc⟩ := deltaCount he
  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp
  exact Weighted.no_clock 1 (by decide : Closed t_e1211584978154) (by decide) (by decide) hj
#print axioms ex_e1211584978154
private def t_e1211584978206 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))
theorem ex_e1211584978206 : ¬ IsSelfInterpreter e1211584978206 := by
  intro he
  have hp := replay_sound (t := (call e1211584978206 (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := t_e1211584978206) (ps := [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.right],[.left,.left,.right,.under,.left],[.left,.left,.right,.under],[.left,.left,.right,.under,.left,.right,.left],[.left,.left,.right,.under,.left,.right],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := (.lam (.var 0))) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := Layouts.mismatch_sound 12 hr (by decide)
  exact (by decide : ¬ Layouts.mismatch 12 t_e1211584978206 (.lam (.var 0)) = false) hz
#print axioms ex_e1211584978206
private def t_e1211584978490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem ex_e1211584978490 : ¬ IsSelfInterpreter e1211584978490 := by
  intro he
  have hp := replay_sound (t := e1211584978490) (u := t_e1211584978490) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (SO.app (SO.app (SO.var 2) (SO.app (SO.var 2) (so_dead (by decide) (SO.var 2)))) (SO.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 1) (so_dead (by decide) (SO.var 1)))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl)))))
#print axioms ex_e1211584978490
end Blc.Floor42.Extra261
