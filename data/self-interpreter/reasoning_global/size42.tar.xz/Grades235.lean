import Tables
import Batch235
namespace Blc.Floor42.Grades235
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1211277428662 : ¬ IsSelfInterpreter e1211277428662 := cutM6_2 (by decide)
#print axioms ex_e1211277428662
theorem ex_e1211277708922 : ¬ IsSelfInterpreter e1211277708922 := cutM9_0 (by decide)
#print axioms ex_e1211277708922
end Blc.Floor42.Grades235
