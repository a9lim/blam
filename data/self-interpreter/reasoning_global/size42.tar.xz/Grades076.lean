import Tables
import Batch076
namespace Blc.Floor42.Grades076
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1196686669242 : ¬ IsSelfInterpreter e1196686669242 := cutM5_2 (by decide)
#print axioms ex_e1196686669242
theorem ex_e1196686669230 : ¬ IsSelfInterpreter e1196686669230 := cutM6_2 (by decide)
#print axioms ex_e1196686669230
theorem ex_e1196686691802 : ¬ IsSelfInterpreter e1196686691802 := cutM7_1 (by decide)
#print axioms ex_e1196686691802
theorem ex_e1196686692186 : ¬ IsSelfInterpreter e1196686692186 := cutM7_1 (by decide)
#print axioms ex_e1196686692186
end Blc.Floor42.Grades076
