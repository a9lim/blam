import CodeBridge
import Batch061
namespace Certgen.R1131193764726
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 21,.app 2 20,.app 3 8,.lam 4,.lam 5,.app 6 7,.var 1,.var 1,.lam 9,.lam 10,.app 11 12,.var 0,.app 13 14,.var 1,.lam 15,.app 16 19,.app 17 18,.var 0,.var 2,.var 1,.opaque,.lam 22,.app 23 28,.app 24 25,.var 0,.lam 26,.lam 27,.var 1,.lam 29,.app 30 35,.app 31 32,.var 0,.lam 33,.lam 34,.var 1,.lam 36,.app 37 42,.app 38 39,.var 0,.lam 40,.lam 41,.var 0,.lam 43,.app 44 49,.app 45 46,.var 0,.lam 47,.lam 48,.var 1,.opaque]
def values : Array (List AClo) := #[[⟨14,[12,9]⟩,⟨14,[13,8]⟩],[⟨18,[0,11,10]⟩],[⟨12,[11,10]⟩],[⟨12,[12,9]⟩,⟨12,[13,8]⟩],[⟨19,[0,11,10]⟩],[⟨28,[2]⟩],[⟨8,[]⟩],[⟨20,[]⟩],[⟨14,[11,10]⟩],[⟨18,[1,12,9]⟩,⟨18,[1,13,8]⟩],[⟨7,[7,6]⟩],[⟨21,[]⟩],[⟨19,[1,12,9]⟩,⟨19,[1,13,8]⟩],[⟨25,[2]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨21,[]⟩,0⟩],[⟨⟨20,[]⟩,1⟩],[⟨⟨12,[11,10]⟩,0⟩],[⟨⟨12,[12,9]⟩,9⟩],[⟨⟨12,[13,8]⟩,16⟩],[⟨⟨14,[11,10]⟩,17⟩],[⟨⟨14,[12,9]⟩,0⟩],[⟨⟨14,[13,8]⟩,0⟩],[⟨⟨19,[0,11,10]⟩,0⟩],[⟨⟨19,[1,12,9]⟩,9⟩],[⟨⟨19,[1,13,8]⟩,9⟩],[⟨⟨18,[0,11,10]⟩,9⟩],[⟨⟨18,[1,12,9]⟩,10⟩],[⟨⟨18,[1,13,8]⟩,11⟩],[⟨⟨8,[]⟩,2⟩],[⟨⟨28,[2]⟩,0⟩],[⟨⟨25,[2]⟩,16⟩],[⟨⟨7,[7,6]⟩,1⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[]⟩,15⟩,⟨⟨4,[6]⟩,2⟩,⟨⟨5,[7,6]⟩,1⟩,⟨⟨6,[7,6]⟩,18⟩,⟨⟨7,[7,6]⟩,6⟩,⟨⟨7,[7,6]⟩,13⟩,⟨⟨7,[7,6]⟩,14⟩,⟨⟨8,[]⟩,6⟩,⟨⟨8,[]⟩,13⟩,⟨⟨8,[]⟩,14⟩,⟨⟨8,[]⟩,18⟩,⟨⟨9,[8]⟩,17⟩,⟨⟨9,[9]⟩,10⟩,⟨⟨9,[9]⟩,11⟩,⟨⟨9,[10]⟩,1⟩,⟨⟨10,[11,10]⟩,0⟩,⟨⟨10,[12,9]⟩,9⟩,⟨⟨10,[13,8]⟩,16⟩,⟨⟨11,[11,10]⟩,3⟩,⟨⟨11,[12,9]⟩,4⟩,⟨⟨11,[13,8]⟩,5⟩,⟨⟨12,[11,10]⟩,17⟩,⟨⟨12,[12,9]⟩,0⟩,⟨⟨12,[13,8]⟩,0⟩,⟨⟨13,[11,10]⟩,6⟩,⟨⟨13,[12,9]⟩,7⟩,⟨⟨13,[13,8]⟩,8⟩,⟨⟨14,[11,10]⟩,7⟩,⟨⟨14,[11,10]⟩,8⟩,⟨⟨14,[12,9]⟩,12⟩,⟨⟨14,[13,8]⟩,12⟩,⟨⟨15,[0,11,10]⟩,0⟩,⟨⟨15,[1,12,9]⟩,9⟩,⟨⟨15,[1,13,8]⟩,9⟩,⟨⟨16,[0,11,10]⟩,9⟩,⟨⟨16,[1,12,9]⟩,10⟩,⟨⟨16,[1,13,8]⟩,11⟩,⟨⟨17,[0,11,10]⟩,12⟩,⟨⟨17,[1,12,9]⟩,13⟩,⟨⟨17,[1,13,8]⟩,14⟩,⟨⟨18,[0,11,10]⟩,13⟩,⟨⟨18,[0,11,10]⟩,14⟩,⟨⟨18,[1,12,9]⟩,7⟩,⟨⟨18,[1,13,8]⟩,7⟩,⟨⟨19,[1,12,9]⟩,4⟩,⟨⟨19,[1,13,8]⟩,4⟩,⟨⟨21,[]⟩,3⟩,⟨⟨22,[2]⟩,0⟩,⟨⟨23,[2]⟩,16⟩,⟨⟨24,[2]⟩,17⟩,⟨⟨25,[2]⟩,4⟩,⟨⟨25,[2]⟩,5⟩,⟨⟨26,[3,2]⟩,9⟩,⟨⟨26,[3,2]⟩,16⟩,⟨⟨27,[4,3,2]⟩,0⟩,⟨⟨27,[5,3,2]⟩,0⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[6],[13],[10],[11],[12],[14],[15],[16],[17],[20],[19],[19],[18],[21],[22],[23],[49],[47,48],[54],[27],[28],[29],[7],[45,46],[31],[34],[34],[35],[36],[37],[38],[39],[40],[41],[42],[32,33],[43],[44],[8],[9],[45,46],[30],[47,48],[53],[50],[51],[52],[24],[55],[56],[57],[58],[25,26],[25,26]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 12=true := by decide
theorem block48 : checkRange P V K states hints 48 11=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<59 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 by_cases h36 : i<48
 · exact range_sound block36 i (by omega) h36 hi
 exact range_sound block48 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor42 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit45 : Term := .var 0
def lit48 : Term := .var 1
def lit18 : Term := .var 2
def lit40 : Term := .lam lit45
def lit47 : Term := .lam lit48
def lit39 : Term := .lam lit40
def lit49 : Term := .var 4
def lit46 : Term := .lam lit47
def lit5 : Term := .app lit48 lit48
def lit16 : Term := .app lit45 lit18
def lit4 : Term := .lam lit5
def lit37 : Term := .app lit45 lit39
def lit44 : Term := .app lit45 lit46
def lit3 : Term := .lam lit4
def lit15 : Term := .app lit16 lit48
def lit14 : Term := .lam lit15
def lit43 : Term := .app lit44 lit49
def lit12 : Term := .app lit48 lit14
def lit42 : Term := .lam lit43
def lit10 : Term := .app lit45 lit12
def lit9 : Term := .lam lit10
def lit8 : Term := .lam lit9
def lit36 : Term := .app lit37 lit42
def lit35 : Term := .lam lit36
def lit2 : Term := .app lit3 lit8
def lit1 : Term := .app lit2 lit48
def lit29 : Term := .app lit44 lit35
def lit28 : Term := .lam lit29
def lit22 : Term := .app lit44 lit28
def lit21 : Term := .lam lit22
def lit0 : Term := .app lit1 lit21
def filling : Nat → Term := fun p => if p = 20 then Term.var 1 else if p = 49 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub49 : model.term 49 = lit49 := (opaqueTerm (rankedCode code ordered_code) filling (p := 49) (by rfl)).trans (by rfl)
theorem sub48 : model.term 48 = lit48 := model.var_eq 48 1 (by rfl)
theorem sub47 : model.term 47 = lit47 := by rw [model.lam_eq 47 48 (by rfl), sub48]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.lam_eq 46 47 (by rfl), sub47]; rfl
theorem sub45 : model.term 45 = lit45 := model.var_eq 45 0 (by rfl)
theorem sub44 : model.term 44 = lit44 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit43 := by rw [model.app_eq 43 44 49 (by rfl), sub44, sub49]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit45 := model.var_eq 41 0 (by rfl)
theorem sub40 : model.term 40 = lit40 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit39 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit45 := model.var_eq 38 0 (by rfl)
theorem sub37 : model.term 37 = lit37 := by rw [model.app_eq 37 38 39 (by rfl), sub38, sub39]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 42 (by rfl), sub37, sub42]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit48 := model.var_eq 34 1 (by rfl)
theorem sub33 : model.term 33 = lit47 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit46 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit45 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit44 := by rw [model.app_eq 30 31 32 (by rfl), sub31, sub32]; rfl
theorem sub29 : model.term 29 = lit29 := by rw [model.app_eq 29 30 35 (by rfl), sub30, sub35]; rfl
theorem sub28 : model.term 28 = lit28 := by rw [model.lam_eq 28 29 (by rfl), sub29]; rfl
theorem sub27 : model.term 27 = lit48 := model.var_eq 27 1 (by rfl)
theorem sub26 : model.term 26 = lit47 := by rw [model.lam_eq 26 27 (by rfl), sub27]; rfl
theorem sub25 : model.term 25 = lit46 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit45 := model.var_eq 24 0 (by rfl)
theorem sub23 : model.term 23 = lit44 := by rw [model.app_eq 23 24 25 (by rfl), sub24, sub25]; rfl
theorem sub22 : model.term 22 = lit22 := by rw [model.app_eq 22 23 28 (by rfl), sub23, sub28]; rfl
theorem sub21 : model.term 21 = lit21 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit48 := (opaqueTerm (rankedCode code ordered_code) filling (p := 20) (by rfl)).trans (by rfl)
theorem sub19 : model.term 19 = lit48 := model.var_eq 19 1 (by rfl)
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit45 := model.var_eq 17 0 (by rfl)
theorem sub16 : model.term 16 = lit16 := by rw [model.app_eq 16 17 18 (by rfl), sub17, sub18]; rfl
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 19 (by rfl), sub16, sub19]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.lam_eq 14 15 (by rfl), sub15]; rfl
theorem sub13 : model.term 13 = lit48 := model.var_eq 13 1 (by rfl)
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit45 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit10 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit8 := by rw [model.lam_eq 8 9 (by rfl), sub9]; rfl
theorem sub7 : model.term 7 = lit48 := model.var_eq 7 1 (by rfl)
theorem sub6 : model.term 6 = lit48 := model.var_eq 6 1 (by rfl)
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 7 (by rfl), sub6, sub7]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.lam_eq 4 5 (by rfl), sub5]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.lam_eq 3 4 (by rfl), sub4]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 8 (by rfl), sub3, sub8]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 20 (by rfl), sub2, sub20]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 21 (by rfl), sub1, sub21]; rfl
theorem excluded : ¬ IsSelfInterpreter e1131193764726 := by
 intro he
 have hp : replay [] (call e1131193764726 (.var 1) (.lam (.var 0)) (.var 0) []) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 0) he (by decide) (by decide)) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R1131193764726
