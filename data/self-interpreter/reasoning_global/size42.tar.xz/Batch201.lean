import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205082398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211205082398 : Closed e1211205082398 ∧ code e1211205082398 = 5609251593502 := by decide
theorem cert_e1211205082398 : checkPay e1211205082398 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205082422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205082422 : Closed e1211205082422 ∧ code e1211205082422 = 5609251593526 := by decide
theorem cert_e1211205082422 : check e1211205082422 [[],[]] .chain = true := by decide
def e1211205082426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205082426 : Closed e1211205082426 ∧ code e1211205082426 = 5609251593530 := by decide
theorem cert_e1211205082426 : check e1211205082426 [[],[]] .chain = true := by decide
def e1211205082498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205082498 : Closed e1211205082498 ∧ code e1211205082498 = 5609251593602 := by decide
theorem cert_e1211205082498 : check e1211205082498 [[],[]] .chain = true := by decide
def e1211205082510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211205082510 : Closed e1211205082510 ∧ code e1211205082510 = 5609251593614 := by decide
theorem cert_e1211205082510 : check e1211205082510 [[],[]] .chain = true := by decide
def e1211205082522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205082522 : Closed e1211205082522 ∧ code e1211205082522 = 5609251593626 := by decide
theorem cert_e1211205082522 : check e1211205082522 [[],[]] .chain = true := by decide
def e1211205082566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211205082566 : Closed e1211205082566 ∧ code e1211205082566 = 5609251593670 := by decide
theorem cert_e1211205082566 : checkPay e1211205082566 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205083310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))) (.var 2))))))
theorem wire_e1211205083310 : Closed e1211205083310 ∧ code e1211205083310 = 5609251594414 := by decide
theorem cert_e1211205083310 : check e1211205083310 [[],[]] .chain = true := by decide
def e1211205083322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))) (.var 0))))))
theorem wire_e1211205083322 : Closed e1211205083322 ∧ code e1211205083322 = 5609251594426 := by decide
theorem cert_e1211205083322 : check e1211205083322 [[],[]] .chain = true := by decide
def e1211205084014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e1211205084014 : Closed e1211205084014 ∧ code e1211205084014 = 5609251595118 := by decide
theorem cert_e1211205084014 : check e1211205084014 [[],[]] .chain = true := by decide
def e1211205084022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e1211205084022 : Closed e1211205084022 ∧ code e1211205084022 = 5609251595126 := by decide
theorem cert_e1211205084022 : check e1211205084022 [[],[]] .chain = true := by decide
def e1211205084078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e1211205084078 : Closed e1211205084078 ∧ code e1211205084078 = 5609251595182 := by decide
theorem cert_e1211205084078 : check e1211205084078 [[],[]] .chain = true := by decide
def e1211205084090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e1211205084090 : Closed e1211205084090 ∧ code e1211205084090 = 5609251595194 := by decide
theorem cert_e1211205084090 : check e1211205084090 [[],[]] .chain = true := by decide
def e1211205084118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e1211205084118 : Closed e1211205084118 ∧ code e1211205084118 = 5609251595222 := by decide
theorem cert_e1211205084118 : check e1211205084118 [[],[]] .chain = true := by decide
def e1211205084122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e1211205084122 : Closed e1211205084122 ∧ code e1211205084122 = 5609251595226 := by decide
theorem cert_e1211205084122 : check e1211205084122 [[],[]] .chain = true := by decide
def e1211205084846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e1211205084846 : Closed e1211205084846 ∧ code e1211205084846 = 5609251595950 := by decide
theorem cert_e1211205084846 : check e1211205084846 [[],[]] .chain = true := by decide
def e1211205084858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e1211205084858 : Closed e1211205084858 ∧ code e1211205084858 = 5609251595962 := by decide
theorem cert_e1211205084858 : check e1211205084858 [[],[]] .chain = true := by decide
def e1211205084906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e1211205084906 : Closed e1211205084906 ∧ code e1211205084906 = 5609251596010 := by decide
theorem cert_e1211205084906 : check e1211205084906 [[],[]] .chain = true := by decide
def e1211205085098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e1211205085098 : Closed e1211205085098 ∧ code e1211205085098 = 5609251596202 := by decide
theorem cert_e1211205085098 : check e1211205085098 [[],[]] .chain = true := by decide
def e1211205085230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e1211205085230 : Closed e1211205085230 ∧ code e1211205085230 = 5609251596334 := by decide
theorem cert_e1211205085230 : check e1211205085230 [[],[]] .chain = true := by decide
def e1211205085422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211205085422 : Closed e1211205085422 ∧ code e1211205085422 = 5609251596526 := by decide
theorem cert_e1211205085422 : check e1211205085422 [[],[]] .chain = true := by decide
def e1211205085430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211205085430 : Closed e1211205085430 ∧ code e1211205085430 = 5609251596534 := by decide
theorem cert_e1211205085430 : check e1211205085430 [[],[]] .chain = true := by decide
def e1211205085614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211205085614 : Closed e1211205085614 ∧ code e1211205085614 = 5609251596718 := by decide
theorem cert_e1211205085614 : check e1211205085614 [[],[]] .chain = true := by decide
def e1211205085626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e1211205085626 : Closed e1211205085626 ∧ code e1211205085626 = 5609251596730 := by decide
theorem cert_e1211205085626 : check e1211205085626 [[],[]] .chain = true := by decide
def e1211205085674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1211205085674 : Closed e1211205085674 ∧ code e1211205085674 = 5609251596778 := by decide
theorem cert_e1211205085674 : check e1211205085674 [[],[]] .chain = true := by decide
def e1211205085806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205085806 : Closed e1211205085806 ∧ code e1211205085806 = 5609251596910 := by decide
theorem cert_e1211205085806 : check e1211205085806 [[],[]] .chain = true := by decide
def e1211205085818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205085818 : Closed e1211205085818 ∧ code e1211205085818 = 5609251596922 := by decide
theorem cert_e1211205085818 : check e1211205085818 [[],[]] .chain = true := by decide
def e1211205085982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211205085982 : Closed e1211205085982 ∧ code e1211205085982 = 5609251597086 := by decide
theorem cert_e1211205085982 : check e1211205085982 [[],[]] .chain = true := by decide
def e1211205086082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205086082 : Closed e1211205086082 ∧ code e1211205086082 = 5609251597186 := by decide
theorem cert_e1211205086082 : check e1211205086082 [[],[]] .chain = true := by decide
def e1211205086094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211205086094 : Closed e1211205086094 ∧ code e1211205086094 = 5609251597198 := by decide
theorem cert_e1211205086094 : check e1211205086094 [[],[]] .chain = true := by decide
def e1211205086106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205086106 : Closed e1211205086106 ∧ code e1211205086106 = 5609251597210 := by decide
theorem cert_e1211205086106 : check e1211205086106 [[],[]] .chain = true := by decide
def e1211205086318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211205086318 : Closed e1211205086318 ∧ code e1211205086318 = 5609251597422 := by decide
theorem cert_e1211205086318 : check e1211205086318 [[],[]] .chain = true := by decide
def e1211205086330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211205086330 : Closed e1211205086330 ∧ code e1211205086330 = 5609251597434 := by decide
theorem cert_e1211205086330 : check e1211205086330 [[],[]] .chain = true := by decide
def e1211205086494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211205086494 : Closed e1211205086494 ∧ code e1211205086494 = 5609251597598 := by decide
theorem cert_e1211205086494 : check e1211205086494 [[],[]] .chain = true := by decide
def e1211205086662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211205086662 : Closed e1211205086662 ∧ code e1211205086662 = 5609251597766 := by decide
theorem cert_e1211205086662 : check e1211205086662 [[],[]] .chain = true := by decide
def e1211205086730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211205086730 : Closed e1211205086730 ∧ code e1211205086730 = 5609251597834 := by decide
theorem cert_e1211205086730 : check e1211205086730 [[],[]] .chain = true := by decide
def e1211205086774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211205086774 : Closed e1211205086774 ∧ code e1211205086774 = 5609251597878 := by decide
theorem cert_e1211205086774 : check e1211205086774 [[],[]] .chain = true := by decide
def e1211205086778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211205086778 : Closed e1211205086778 ∧ code e1211205086778 = 5609251597882 := by decide
theorem cert_e1211205086778 : check e1211205086778 [[],[]] .chain = true := by decide
def e1211205086826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211205086826 : Closed e1211205086826 ∧ code e1211205086826 = 5609251597930 := by decide
theorem cert_e1211205086826 : check e1211205086826 [[],[]] .chain = true := by decide
def e1211205086850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205086850 : Closed e1211205086850 ∧ code e1211205086850 = 5609251597954 := by decide
theorem cert_e1211205086850 : check e1211205086850 [[],[]] .chain = true := by decide
def e1211205086862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211205086862 : Closed e1211205086862 ∧ code e1211205086862 = 5609251597966 := by decide
theorem cert_e1211205086862 : check e1211205086862 [[],[]] .chain = true := by decide
def e1211205086874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205086874 : Closed e1211205086874 ∧ code e1211205086874 = 5609251597978 := by decide
theorem cert_e1211205086874 : check e1211205086874 [[],[]] .chain = true := by decide
def e1211205086918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211205086918 : Closed e1211205086918 ∧ code e1211205086918 = 5609251598022 := by decide
theorem cert_e1211205086918 : check e1211205086918 [[],[]] .chain = true := by decide
def e1211205087318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e1211205087318 : Closed e1211205087318 ∧ code e1211205087318 = 5609251598422 := by decide
theorem cert_e1211205087318 : check e1211205087318 [[],[]] .chain = true := by decide
def e1211205087322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e1211205087322 : Closed e1211205087322 ∧ code e1211205087322 = 5609251598426 := by decide
theorem cert_e1211205087322 : check e1211205087322 [[],[]] .chain = true := by decide
def e1211205087338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0))) (.var 0))))))
theorem wire_e1211205087338 : Closed e1211205087338 ∧ code e1211205087338 = 5609251598442 := by decide
theorem cert_e1211205087338 : check e1211205087338 [[],[]] .chain = true := by decide
def e1211205087514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211205087514 : Closed e1211205087514 ∧ code e1211205087514 = 5609251598618 := by decide
theorem cert_e1211205087514 : check e1211205087514 [[],[]] .chain = true := by decide
def e1211205087558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211205087558 : Closed e1211205087558 ∧ code e1211205087558 = 5609251598662 := by decide
theorem cert_e1211205087558 : check e1211205087558 [[],[]] .chain = true := by decide
def e1211205087626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211205087626 : Closed e1211205087626 ∧ code e1211205087626 = 5609251598730 := by decide
theorem cert_e1211205087626 : check e1211205087626 [[],[]] .chain = true := by decide
def e1211205087650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211205087650 : Closed e1211205087650 ∧ code e1211205087650 = 5609251598754 := by decide
theorem cert_e1211205087650 : check e1211205087650 [[],[]] .chain = true := by decide
def e1211205087662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e1211205087662 : Closed e1211205087662 ∧ code e1211205087662 = 5609251598766 := by decide
theorem cert_e1211205087662 : checkPay e1211205087662 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] = true := by decide
def e1211205087670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 1))))))
theorem wire_e1211205087670 : Closed e1211205087670 ∧ code e1211205087670 = 5609251598774 := by decide
theorem cert_e1211205087670 : check e1211205087670 [[],[]] .chain = true := by decide
def e1211205087674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e1211205087674 : Closed e1211205087674 ∧ code e1211205087674 = 5609251598778 := by decide
theorem cert_e1211205087674 : checkPay e1211205087674 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right]] = true := by decide
def e1211205087702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e1211205087702 : Closed e1211205087702 ∧ code e1211205087702 = 5609251598806 := by decide
theorem cert_e1211205087702 : check e1211205087702 [[],[]] .chain = true := by decide
def e1211205087706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e1211205087706 : Closed e1211205087706 ∧ code e1211205087706 = 5609251598810 := by decide
theorem cert_e1211205087706 : check e1211205087706 [[],[]] .chain = true := by decide
def e1211205087722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e1211205087722 : Closed e1211205087722 ∧ code e1211205087722 = 5609251598826 := by decide
theorem cert_e1211205087722 : checkPay e1211205087722 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e1211205088086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e1211205088086 : Closed e1211205088086 ∧ code e1211205088086 = 5609251599190 := by decide
theorem cert_e1211205088086 : check e1211205088086 [[],[]] .chain = true := by decide
def e1211205088090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e1211205088090 : Closed e1211205088090 ∧ code e1211205088090 = 5609251599194 := by decide
theorem cert_e1211205088090 : check e1211205088090 [[],[]] .chain = true := by decide
def e1211205088106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e1211205088106 : Closed e1211205088106 ∧ code e1211205088106 = 5609251599210 := by decide
theorem cert_e1211205088106 : check e1211205088106 [[],[]] .chain = true := by decide
def e1211205088170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e1211205088170 : Closed e1211205088170 ∧ code e1211205088170 = 5609251599274 := by decide
theorem cert_e1211205088170 : check e1211205088170 [[],[]] .chain = true := by decide
def e1211205088278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211205088278 : Closed e1211205088278 ∧ code e1211205088278 = 5609251599382 := by decide
theorem cert_e1211205088278 : check e1211205088278 [[],[]] .chain = true := by decide
def e1211205088282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205088282 : Closed e1211205088282 ∧ code e1211205088282 = 5609251599386 := by decide
theorem cert_e1211205088282 : check e1211205088282 [[],[]] .chain = true := by decide
def e1211205088326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205088326 : Closed e1211205088326 ∧ code e1211205088326 = 5609251599430 := by decide
theorem cert_e1211205088326 : check e1211205088326 [[],[]] .chain = true := by decide
def e1211205088354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211205088354 : Closed e1211205088354 ∧ code e1211205088354 = 5609251599458 := by decide
theorem cert_e1211205088354 : check e1211205088354 [[],[]] .chain = true := by decide
def e1211205088366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211205088366 : Closed e1211205088366 ∧ code e1211205088366 = 5609251599470 := by decide
theorem cert_e1211205088366 : checkPay e1211205088366 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e1211205088374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211205088374 : Closed e1211205088374 ∧ code e1211205088374 = 5609251599478 := by decide
theorem cert_e1211205088374 : check e1211205088374 [[],[]] .chain = true := by decide
def e1211205088378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211205088378 : Closed e1211205088378 ∧ code e1211205088378 = 5609251599482 := by decide
theorem cert_e1211205088378 : checkPay e1211205088378 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e1211205088470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211205088470 : Closed e1211205088470 ∧ code e1211205088470 = 5609251599574 := by decide
theorem cert_e1211205088470 : check e1211205088470 [[],[]] .chain = true := by decide
def e1211205088474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211205088474 : Closed e1211205088474 ∧ code e1211205088474 = 5609251599578 := by decide
theorem cert_e1211205088474 : check e1211205088474 [[],[]] .chain = true := by decide
def e1211205088490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211205088490 : Closed e1211205088490 ∧ code e1211205088490 = 5609251599594 := by decide
theorem cert_e1211205088490 : check e1211205088490 [[],[]] .chain = true := by decide
def e1211205088518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205088518 : Closed e1211205088518 ∧ code e1211205088518 = 5609251599622 := by decide
theorem cert_e1211205088518 : check e1211205088518 [[],[]] .chain = true := by decide
def e1211205088542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211205088542 : Closed e1211205088542 ∧ code e1211205088542 = 5609251599646 := by decide
theorem cert_e1211205088542 : checkPay e1211205088542 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left]] = true := by decide
def e1211205088566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205088566 : Closed e1211205088566 ∧ code e1211205088566 = 5609251599670 := by decide
theorem cert_e1211205088566 : check e1211205088566 [[],[]] .chain = true := by decide
def e1211205088570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205088570 : Closed e1211205088570 ∧ code e1211205088570 = 5609251599674 := by decide
theorem cert_e1211205088570 : check e1211205088570 [[],[]] .chain = true := by decide
def e1211205088642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205088642 : Closed e1211205088642 ∧ code e1211205088642 = 5609251599746 := by decide
theorem cert_e1211205088642 : check e1211205088642 [[],[]] .chain = true := by decide
def e1211205088654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211205088654 : Closed e1211205088654 ∧ code e1211205088654 = 5609251599758 := by decide
theorem cert_e1211205088654 : check e1211205088654 [[],[]] .chain = true := by decide
def e1211205088666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205088666 : Closed e1211205088666 ∧ code e1211205088666 = 5609251599770 := by decide
theorem cert_e1211205088666 : check e1211205088666 [[],[]] .chain = true := by decide
def e1211205088710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211205088710 : Closed e1211205088710 ∧ code e1211205088710 = 5609251599814 := by decide
theorem cert_e1211205088710 : checkPay e1211205088710 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left]] = true := by decide
def e1211205088778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211205088778 : Closed e1211205088778 ∧ code e1211205088778 = 5609251599882 := by decide
theorem cert_e1211205088778 : check e1211205088778 [[],[]] .chain = true := by decide
def e1211205088822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211205088822 : Closed e1211205088822 ∧ code e1211205088822 = 5609251599926 := by decide
theorem cert_e1211205088822 : check e1211205088822 [[],[]] .chain = true := by decide
def e1211205088826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211205088826 : Closed e1211205088826 ∧ code e1211205088826 = 5609251599930 := by decide
theorem cert_e1211205088826 : check e1211205088826 [[],[]] .chain = true := by decide
def e1211205088874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211205088874 : Closed e1211205088874 ∧ code e1211205088874 = 5609251599978 := by decide
theorem cert_e1211205088874 : check e1211205088874 [[],[]] .chain = true := by decide
def e1211205088898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205088898 : Closed e1211205088898 ∧ code e1211205088898 = 5609251600002 := by decide
theorem cert_e1211205088898 : check e1211205088898 [[],[]] .chain = true := by decide
def e1211205088910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211205088910 : Closed e1211205088910 ∧ code e1211205088910 = 5609251600014 := by decide
theorem cert_e1211205088910 : check e1211205088910 [[],[]] .chain = true := by decide
def e1211205088922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205088922 : Closed e1211205088922 ∧ code e1211205088922 = 5609251600026 := by decide
theorem cert_e1211205088922 : check e1211205088922 [[],[]] .chain = true := by decide
def e1211205088966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211205088966 : Closed e1211205088966 ∧ code e1211205088966 = 5609251600070 := by decide
theorem cert_e1211205088966 : check e1211205088966 [[],[]] .chain = true := by decide
def e1211205089050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211205089050 : Closed e1211205089050 ∧ code e1211205089050 = 5609251600154 := by decide
theorem cert_e1211205089050 : checkPay e1211205089050 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e1211205089094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211205089094 : Closed e1211205089094 ∧ code e1211205089094 = 5609251600198 := by decide
theorem cert_e1211205089094 : checkPay e1211205089094 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211205091822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 2))))))
theorem wire_e1211205091822 : Closed e1211205091822 ∧ code e1211205091822 = 5609251602926 := by decide
theorem cert_e1211205091822 : check e1211205091822 [[],[]] .chain = true := by decide
def e1211205091834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 5)))))) (.var 0))))))
theorem wire_e1211205091834 : Closed e1211205091834 ∧ code e1211205091834 = 5609251602938 := by decide
theorem cert_e1211205091834 : check e1211205091834 [[],[]] .chain = true := by decide
def e1211205092590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205092590 : Closed e1211205092590 ∧ code e1211205092590 = 5609251603694 := by decide
theorem cert_e1211205092590 : check e1211205092590 [[],[]] .chain = true := by decide
def e1211205092598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205092598 : Closed e1211205092598 ∧ code e1211205092598 = 5609251603702 := by decide
theorem cert_e1211205092598 : check e1211205092598 [[],[]] .chain = true := by decide
def e1211205092974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205092974 : Closed e1211205092974 ∧ code e1211205092974 = 5609251604078 := by decide
theorem cert_e1211205092974 : check e1211205092974 [[],[]] .chain = true := by decide
def e1211205092986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205092986 : Closed e1211205092986 ∧ code e1211205092986 = 5609251604090 := by decide
theorem cert_e1211205092986 : check e1211205092986 [[],[]] .chain = true := by decide
def e1211205093150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.var 3)))))))
theorem wire_e1211205093150 : Closed e1211205093150 ∧ code e1211205093150 = 5609251604254 := by decide
theorem cert_e1211205093150 : check e1211205093150 [[],[]] .chain = true := by decide
def e1211205093318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.lam (.var 1)))))))
theorem wire_e1211205093318 : Closed e1211205093318 ∧ code e1211205093318 = 5609251604422 := by decide
theorem cert_e1211205093318 : check e1211205093318 [[],[]] .chain = true := by decide
def e1211205094510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 2))))))
theorem wire_e1211205094510 : Closed e1211205094510 ∧ code e1211205094510 = 5609251605614 := by decide
theorem cert_e1211205094510 : checkPay e1211205094510 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1211205094686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 3)))))))
theorem wire_e1211205094686 : Closed e1211205094686 ∧ code e1211205094686 = 5609251605790 := by decide
theorem cert_e1211205094686 : checkPay e1211205094686 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1211205094894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 2))))))
theorem wire_e1211205094894 : Closed e1211205094894 ∧ code e1211205094894 = 5609251605998 := by decide
theorem cert_e1211205094894 : checkPay e1211205094894 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e1211205094958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e1211205094958 : Closed e1211205094958 ∧ code e1211205094958 = 5609251606062 := by decide
theorem cert_e1211205094958 : check e1211205094958 [[],[]] .chain = true := by decide
def e1211205095150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e1211205095150 : Closed e1211205095150 ∧ code e1211205095150 = 5609251606254 := by decide
theorem cert_e1211205095150 : check e1211205095150 [[],[]] .chain = true := by decide
def e1211205095158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e1211205095158 : Closed e1211205095158 ∧ code e1211205095158 = 5609251606262 := by decide
theorem cert_e1211205095158 : check e1211205095158 [[],[]] .chain = true := by decide
def e1211205095278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e1211205095278 : Closed e1211205095278 ∧ code e1211205095278 = 5609251606382 := by decide
theorem cert_e1211205095278 : check e1211205095278 [[],[]] .chain = true := by decide
def e1211205095290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e1211205095290 : Closed e1211205095290 ∧ code e1211205095290 = 5609251606394 := by decide
theorem cert_e1211205095290 : check e1211205095290 [[],[]] .chain = true := by decide
def e1211205095306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205095306 : Closed e1211205095306 ∧ code e1211205095306 = 5609251606410 := by decide
theorem cert_e1211205095306 : check e1211205095306 [[],[]] .chain = true := by decide
def e1211205095342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 2))))))
theorem wire_e1211205095342 : Closed e1211205095342 ∧ code e1211205095342 = 5609251606446 := by decide
theorem cert_e1211205095342 : checkPay e1211205095342 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right,.under]] = true := by decide
def e1211205095350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e1211205095350 : Closed e1211205095350 ∧ code e1211205095350 = 5609251606454 := by decide
theorem cert_e1211205095350 : check e1211205095350 [[],[]] .chain = true := by decide
def e1211205095354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e1211205095354 : Closed e1211205095354 ∧ code e1211205095354 = 5609251606458 := by decide
theorem cert_e1211205095354 : check e1211205095354 [[],[]] .chain = true := by decide
def e1211205096222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211205096222 : Closed e1211205096222 ∧ code e1211205096222 = 5609251607326 := by decide
theorem cert_e1211205096222 : check e1211205096222 [[],[]] .chain = true := by decide
def e1211205096390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211205096390 : Closed e1211205096390 ∧ code e1211205096390 = 5609251607494 := by decide
theorem cert_e1211205096390 : check e1211205096390 [[],[]] .chain = true := by decide
def e1211205097534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 4))))))))
theorem wire_e1211205097534 : Closed e1211205097534 ∧ code e1211205097534 = 5609251608638 := by decide
theorem cert_e1211205097534 : check e1211205097534 [[],[]] .chain = true := by decide
def e1211205097954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211205097954 : Closed e1211205097954 ∧ code e1211205097954 = 5609251609058 := by decide
theorem cert_e1211205097954 : check e1211205097954 [[],[]] .chain = true := by decide
def e1211205097966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 2)))))))
theorem wire_e1211205097966 : Closed e1211205097966 ∧ code e1211205097966 = 5609251609070 := by decide
theorem cert_e1211205097966 : checkPay e1211205097966 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1211205098734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205098734 : Closed e1211205098734 ∧ code e1211205098734 = 5609251609838 := by decide
theorem cert_e1211205098734 : check e1211205098734 [[],[]] .chain = true := by decide
def e1211205098742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205098742 : Closed e1211205098742 ∧ code e1211205098742 = 5609251609846 := by decide
theorem cert_e1211205098742 : check e1211205098742 [[],[]] .chain = true := by decide
def e1211205099022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.lam (.var 2))))))))
theorem wire_e1211205099022 : Closed e1211205099022 ∧ code e1211205099022 = 5609251610126 := by decide
theorem cert_e1211205099022 : check e1211205099022 [[],[]] .chain = true := by decide
def e1211205099034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211205099034 : Closed e1211205099034 ∧ code e1211205099034 = 5609251610138 := by decide
theorem cert_e1211205099034 : checkPay e1211205099034 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e1211205099106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211205099106 : Closed e1211205099106 ∧ code e1211205099106 = 5609251610210 := by decide
theorem cert_e1211205099106 : check e1211205099106 [[],[]] .chain = true := by decide
def e1211205099118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205099118 : Closed e1211205099118 ∧ code e1211205099118 = 5609251610222 := by decide
theorem cert_e1211205099118 : checkPay e1211205099118 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e1211205099126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205099126 : Closed e1211205099126 ∧ code e1211205099126 = 5609251610230 := by decide
theorem cert_e1211205099126 : check e1211205099126 [[],[]] .chain = true := by decide
def e1211205099130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205099130 : Closed e1211205099130 ∧ code e1211205099130 = 5609251610234 := by decide
theorem cert_e1211205099130 : checkPay e1211205099130 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.under,.right]] = true := by decide
def e1211205102958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e1211205102958 : Closed e1211205102958 ∧ code e1211205102958 = 5609251614062 := by decide
theorem cert_e1211205102958 : check e1211205102958 [[],[]] .chain = true := by decide
def e1211205102966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211205102966 : Closed e1211205102966 ∧ code e1211205102966 = 5609251614070 := by decide
theorem cert_e1211205102966 : check e1211205102966 [[],[]] .chain = true := by decide
def e1211205103022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e1211205103022 : Closed e1211205103022 ∧ code e1211205103022 = 5609251614126 := by decide
theorem cert_e1211205103022 : check e1211205103022 [[],[]] .chain = true := by decide
def e1211205103034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211205103034 : Closed e1211205103034 ∧ code e1211205103034 = 5609251614138 := by decide
theorem cert_e1211205103034 : check e1211205103034 [[],[]] .chain = true := by decide
def e1211205103062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211205103062 : Closed e1211205103062 ∧ code e1211205103062 = 5609251614166 := by decide
theorem cert_e1211205103062 : check e1211205103062 [[],[]] .chain = true := by decide
def e1211205103066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211205103066 : Closed e1211205103066 ∧ code e1211205103066 = 5609251614170 := by decide
theorem cert_e1211205103066 : check e1211205103066 [[],[]] .chain = true := by decide
def e1211205103278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e1211205103278 : Closed e1211205103278 ∧ code e1211205103278 = 5609251614382 := by decide
theorem cert_e1211205103278 : check e1211205103278 [[],[]] .chain = true := by decide
def e1211205103290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211205103290 : Closed e1211205103290 ∧ code e1211205103290 = 5609251614394 := by decide
theorem cert_e1211205103290 : check e1211205103290 [[],[]] .chain = true := by decide
def e1211205103338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211205103338 : Closed e1211205103338 ∧ code e1211205103338 = 5609251614442 := by decide
theorem cert_e1211205103338 : check e1211205103338 [[],[]] .chain = true := by decide
def e1211205103446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e1211205103446 : Closed e1211205103446 ∧ code e1211205103446 = 5609251614550 := by decide
theorem cert_e1211205103446 : check e1211205103446 [[],[]] .chain = true := by decide
def e1211205103450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211205103450 : Closed e1211205103450 ∧ code e1211205103450 = 5609251614554 := by decide
theorem cert_e1211205103450 : check e1211205103450 [[],[]] .chain = true := by decide
def e1211205103466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211205103466 : Closed e1211205103466 ∧ code e1211205103466 = 5609251614570 := by decide
theorem cert_e1211205103466 : check e1211205103466 [[],[]] .chain = true := by decide
def e1211205103726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 2))))))
theorem wire_e1211205103726 : Closed e1211205103726 ∧ code e1211205103726 = 5609251614830 := by decide
theorem cert_e1211205103726 : check e1211205103726 [[],[]] .chain = true := by decide
def e1211205103902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.var 3)))))))
theorem wire_e1211205103902 : Closed e1211205103902 ∧ code e1211205103902 = 5609251615006 := by decide
theorem cert_e1211205103902 : check e1211205103902 [[],[]] .chain = true := by decide
def e1211205104098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.lam (.var 0)))))))
theorem wire_e1211205104098 : Closed e1211205104098 ∧ code e1211205104098 = 5609251615202 := by decide
theorem cert_e1211205104098 : check e1211205104098 [[],[]] .chain = true := by decide
def e1211205104110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 2))))))
theorem wire_e1211205104110 : Closed e1211205104110 ∧ code e1211205104110 = 5609251615214 := by decide
theorem cert_e1211205104110 : checkPay e1211205104110 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205104494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211205104494 : Closed e1211205104494 ∧ code e1211205104494 = 5609251615598 := by decide
theorem cert_e1211205104494 : check e1211205104494 [[],[]] .chain = true := by decide
def e1211205104502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211205104502 : Closed e1211205104502 ∧ code e1211205104502 = 5609251615606 := by decide
theorem cert_e1211205104502 : check e1211205104502 [[],[]] .chain = true := by decide
def e1211205104558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211205104558 : Closed e1211205104558 ∧ code e1211205104558 = 5609251615662 := by decide
theorem cert_e1211205104558 : check e1211205104558 [[],[]] .chain = true := by decide
def e1211205104570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211205104570 : Closed e1211205104570 ∧ code e1211205104570 = 5609251615674 := by decide
theorem cert_e1211205104570 : check e1211205104570 [[],[]] .chain = true := by decide
def e1211205104598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211205104598 : Closed e1211205104598 ∧ code e1211205104598 = 5609251615702 := by decide
theorem cert_e1211205104598 : check e1211205104598 [[],[]] .chain = true := by decide
def e1211205104602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211205104602 : Closed e1211205104602 ∧ code e1211205104602 = 5609251615706 := by decide
theorem cert_e1211205104602 : check e1211205104602 [[],[]] .chain = true := by decide
def e1211205104878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205104878 : Closed e1211205104878 ∧ code e1211205104878 = 5609251615982 := by decide
theorem cert_e1211205104878 : check e1211205104878 [[],[]] .chain = true := by decide
def e1211205104886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205104886 : Closed e1211205104886 ∧ code e1211205104886 = 5609251615990 := by decide
theorem cert_e1211205104886 : check e1211205104886 [[],[]] .chain = true := by decide
def e1211205105262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205105262 : Closed e1211205105262 ∧ code e1211205105262 = 5609251616366 := by decide
theorem cert_e1211205105262 : check e1211205105262 [[],[]] .chain = true := by decide
def e1211205105274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205105274 : Closed e1211205105274 ∧ code e1211205105274 = 5609251616378 := by decide
theorem cert_e1211205105274 : check e1211205105274 [[],[]] .chain = true := by decide
def e1211205105414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205105414 : Closed e1211205105414 ∧ code e1211205105414 = 5609251616518 := by decide
theorem cert_e1211205105414 : check e1211205105414 [[],[]] .chain = true := by decide
def e1211205105438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e1211205105438 : Closed e1211205105438 ∧ code e1211205105438 = 5609251616542 := by decide
theorem cert_e1211205105438 : checkPay e1211205105438 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e1211205105462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205105462 : Closed e1211205105462 ∧ code e1211205105462 = 5609251616566 := by decide
theorem cert_e1211205105462 : check e1211205105462 [[],[]] .chain = true := by decide
def e1211205105466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205105466 : Closed e1211205105466 ∧ code e1211205105466 = 5609251616570 := by decide
theorem cert_e1211205105466 : check e1211205105466 [[],[]] .chain = true := by decide
def e1211205105710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e1211205105710 : Closed e1211205105710 ∧ code e1211205105710 = 5609251616814 := by decide
theorem cert_e1211205105710 : check e1211205105710 [[],[]] .chain = true := by decide
def e1211205105902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211205105902 : Closed e1211205105902 ∧ code e1211205105902 = 5609251617006 := by decide
theorem cert_e1211205105902 : check e1211205105902 [[],[]] .chain = true := by decide
def e1211205105910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211205105910 : Closed e1211205105910 ∧ code e1211205105910 = 5609251617014 := by decide
theorem cert_e1211205105910 : check e1211205105910 [[],[]] .chain = true := by decide
def e1211205106094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e1211205106094 : Closed e1211205106094 ∧ code e1211205106094 = 5609251617198 := by decide
theorem cert_e1211205106094 : check e1211205106094 [[],[]] .chain = true := by decide
def e1211205106106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211205106106 : Closed e1211205106106 ∧ code e1211205106106 = 5609251617210 := by decide
theorem cert_e1211205106106 : check e1211205106106 [[],[]] .chain = true := by decide
def e1211205106154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211205106154 : Closed e1211205106154 ∧ code e1211205106154 = 5609251617258 := by decide
theorem cert_e1211205106154 : check e1211205106154 [[],[]] .chain = true := by decide
def e1211205106286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205106286 : Closed e1211205106286 ∧ code e1211205106286 = 5609251617390 := by decide
theorem cert_e1211205106286 : check e1211205106286 [[],[]] .chain = true := by decide
def e1211205106298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205106298 : Closed e1211205106298 ∧ code e1211205106298 = 5609251617402 := by decide
theorem cert_e1211205106298 : check e1211205106298 [[],[]] .chain = true := by decide
def e1211205106462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211205106462 : Closed e1211205106462 ∧ code e1211205106462 = 5609251617566 := by decide
theorem cert_e1211205106462 : check e1211205106462 [[],[]] .chain = true := by decide
end Blc.Floor42
