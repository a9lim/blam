import R1130567044014Data
namespace Certgen.R1130567044014
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl288 : FloorIndex.rangeOK validState 288 3 = true := by decide +kernel
end Certgen.R1130567044014
