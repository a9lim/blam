import Tables
import Batch046
namespace Blc.Floor42.Grades046
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1124661464022 : ¬ IsSelfInterpreter e1124661464022 := cutM3_0 (by decide)
#print axioms ex_e1124661464022
end Blc.Floor42.Grades046
