import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209083670362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1209083670362 : Closed e1209083670362 ∧ code e1209083670362 = 5607130181466 := by decide
theorem cert_e1209083670362 : check e1209083670362 [[],[]] .chain = true := by decide
def e1209083670378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1209083670378 : Closed e1209083670378 ∧ code e1209083670378 = 5607130181482 := by decide
theorem cert_e1209083670378 : check e1209083670378 [[],[]] .chain = true := by decide
def e1209083671406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1209083671406 : Closed e1209083671406 ∧ code e1209083671406 = 5607130182510 := by decide
theorem cert_e1209083671406 : check e1209083671406 [[],[]] .chain = true := by decide
def e1209083671414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1209083671414 : Closed e1209083671414 ∧ code e1209083671414 = 5607130182518 := by decide
theorem cert_e1209083671414 : check e1209083671414 [[],[]] .chain = true := by decide
def e1209083671470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1209083671470 : Closed e1209083671470 ∧ code e1209083671470 = 5607130182574 := by decide
theorem cert_e1209083671470 : check e1209083671470 [[],[]] .chain = true := by decide
def e1209083671482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1209083671482 : Closed e1209083671482 ∧ code e1209083671482 = 5607130182586 := by decide
theorem cert_e1209083671482 : check e1209083671482 [[],[]] .chain = true := by decide
def e1209083671510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1209083671510 : Closed e1209083671510 ∧ code e1209083671510 = 5607130182614 := by decide
theorem cert_e1209083671510 : check e1209083671510 [[],[]] .chain = true := by decide
def e1209083671514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1209083671514 : Closed e1209083671514 ∧ code e1209083671514 = 5607130182618 := by decide
theorem cert_e1209083671514 : check e1209083671514 [[],[]] .chain = true := by decide
def e1209083671790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209083671790 : Closed e1209083671790 ∧ code e1209083671790 = 5607130182894 := by decide
theorem cert_e1209083671790 : check e1209083671790 [[],[]] .chain = true := by decide
def e1209083671798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209083671798 : Closed e1209083671798 ∧ code e1209083671798 = 5607130182902 := by decide
theorem cert_e1209083671798 : check e1209083671798 [[],[]] .chain = true := by decide
def e1209083672174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209083672174 : Closed e1209083672174 ∧ code e1209083672174 = 5607130183278 := by decide
theorem cert_e1209083672174 : check e1209083672174 [[],[]] .chain = true := by decide
def e1209083672186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209083672186 : Closed e1209083672186 ∧ code e1209083672186 = 5607130183290 := by decide
theorem cert_e1209083672186 : check e1209083672186 [[],[]] .chain = true := by decide
def e1209083672374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209083672374 : Closed e1209083672374 ∧ code e1209083672374 = 5607130183478 := by decide
theorem cert_e1209083672374 : check e1209083672374 [[],[]] .chain = true := by decide
def e1209083672378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209083672378 : Closed e1209083672378 ∧ code e1209083672378 = 5607130183482 := by decide
theorem cert_e1209083672378 : check e1209083672378 [[],[]] .chain = true := by decide
def e1209083673006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1209083673006 : Closed e1209083673006 ∧ code e1209083673006 = 5607130184110 := by decide
theorem cert_e1209083673006 : check e1209083673006 [[],[]] .chain = true := by decide
def e1209083673018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1209083673018 : Closed e1209083673018 ∧ code e1209083673018 = 5607130184122 := by decide
theorem cert_e1209083673018 : check e1209083673018 [[],[]] .chain = true := by decide
def e1209083673066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1209083673066 : Closed e1209083673066 ∧ code e1209083673066 = 5607130184170 := by decide
theorem cert_e1209083673066 : check e1209083673066 [[],[]] .chain = true := by decide
def e1209083673198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209083673198 : Closed e1209083673198 ∧ code e1209083673198 = 5607130184302 := by decide
theorem cert_e1209083673198 : check e1209083673198 [[],[]] .chain = true := by decide
def e1209083673210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209083673210 : Closed e1209083673210 ∧ code e1209083673210 = 5607130184314 := by decide
theorem cert_e1209083673210 : check e1209083673210 [[],[]] .chain = true := by decide
def e1209083673498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1209083673498 : Closed e1209083673498 ∧ code e1209083673498 = 5607130184602 := by decide
theorem cert_e1209083673498 : check e1209083673498 [[],[]] .chain = true := by decide
def e1209083673814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1209083673814 : Closed e1209083673814 ∧ code e1209083673814 = 5607130184918 := by decide
theorem cert_e1209083673814 : check e1209083673814 [[],[]] .chain = true := by decide
def e1209083673818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1209083673818 : Closed e1209083673818 ∧ code e1209083673818 = 5607130184922 := by decide
theorem cert_e1209083673818 : check e1209083673818 [[],[]] .chain = true := by decide
def e1209083673834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1209083673834 : Closed e1209083673834 ∧ code e1209083673834 = 5607130184938 := by decide
theorem cert_e1209083673834 : check e1209083673834 [[],[]] .chain = true := by decide
def e1209083673910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209083673910 : Closed e1209083673910 ∧ code e1209083673910 = 5607130185014 := by decide
theorem cert_e1209083673910 : check e1209083673910 [[],[]] .chain = true := by decide
def e1209083673914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209083673914 : Closed e1209083673914 ∧ code e1209083673914 = 5607130185018 := by decide
theorem cert_e1209083673914 : check e1209083673914 [[],[]] .chain = true := by decide
def e1209083674010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1209083674010 : Closed e1209083674010 ∧ code e1209083674010 = 5607130185114 := by decide
theorem cert_e1209083674010 : check e1209083674010 [[],[]] .chain = true := by decide
def e1209083677550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209083677550 : Closed e1209083677550 ∧ code e1209083677550 = 5607130188654 := by decide
theorem cert_e1209083677550 : check e1209083677550 [[],[]] .chain = true := by decide
def e1209083677558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209083677558 : Closed e1209083677558 ∧ code e1209083677558 = 5607130188662 := by decide
theorem cert_e1209083677558 : check e1209083677558 [[],[]] .chain = true := by decide
def e1209083677614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209083677614 : Closed e1209083677614 ∧ code e1209083677614 = 5607130188718 := by decide
theorem cert_e1209083677614 : check e1209083677614 [[],[]] .chain = true := by decide
def e1209083677626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209083677626 : Closed e1209083677626 ∧ code e1209083677626 = 5607130188730 := by decide
theorem cert_e1209083677626 : check e1209083677626 [[],[]] .chain = true := by decide
def e1209083677654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209083677654 : Closed e1209083677654 ∧ code e1209083677654 = 5607130188758 := by decide
theorem cert_e1209083677654 : check e1209083677654 [[],[]] .chain = true := by decide
def e1209083677658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209083677658 : Closed e1209083677658 ∧ code e1209083677658 = 5607130188762 := by decide
theorem cert_e1209083677658 : check e1209083677658 [[],[]] .chain = true := by decide
def e1209083677934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209083677934 : Closed e1209083677934 ∧ code e1209083677934 = 5607130189038 := by decide
theorem cert_e1209083677934 : check e1209083677934 [[],[]] .chain = true := by decide
def e1209083677942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209083677942 : Closed e1209083677942 ∧ code e1209083677942 = 5607130189046 := by decide
theorem cert_e1209083677942 : check e1209083677942 [[],[]] .chain = true := by decide
def e1209083678318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209083678318 : Closed e1209083678318 ∧ code e1209083678318 = 5607130189422 := by decide
theorem cert_e1209083678318 : check e1209083678318 [[],[]] .chain = true := by decide
def e1209083678330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209083678330 : Closed e1209083678330 ∧ code e1209083678330 = 5607130189434 := by decide
theorem cert_e1209083678330 : check e1209083678330 [[],[]] .chain = true := by decide
def e1209083678518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209083678518 : Closed e1209083678518 ∧ code e1209083678518 = 5607130189622 := by decide
theorem cert_e1209083678518 : check e1209083678518 [[],[]] .chain = true := by decide
def e1209083678522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209083678522 : Closed e1209083678522 ∧ code e1209083678522 = 5607130189626 := by decide
theorem cert_e1209083678522 : check e1209083678522 [[],[]] .chain = true := by decide
def e1209083684270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1209083684270 : Closed e1209083684270 ∧ code e1209083684270 = 5607130195374 := by decide
theorem cert_e1209083684270 : check e1209083684270 [[],[]] .chain = true := by decide
def e1209083684282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1209083684282 : Closed e1209083684282 ∧ code e1209083684282 = 5607130195386 := by decide
theorem cert_e1209083684282 : check e1209083684282 [[],[]] .chain = true := by decide
def e1209083684330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1209083684330 : Closed e1209083684330 ∧ code e1209083684330 = 5607130195434 := by decide
theorem cert_e1209083684330 : check e1209083684330 [[],[]] .chain = true := by decide
def e1209083684462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1209083684462 : Closed e1209083684462 ∧ code e1209083684462 = 5607130195566 := by decide
theorem cert_e1209083684462 : check e1209083684462 [[],[]] .chain = true := by decide
def e1209083684474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1209083684474 : Closed e1209083684474 ∧ code e1209083684474 = 5607130195578 := by decide
theorem cert_e1209083684474 : check e1209083684474 [[],[]] .chain = true := by decide
def e1209083684762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1209083684762 : Closed e1209083684762 ∧ code e1209083684762 = 5607130195866 := by decide
theorem cert_e1209083684762 : check e1209083684762 [[],[]] .chain = true := by decide
def e1209083687638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1209083687638 : Closed e1209083687638 ∧ code e1209083687638 = 5607130198742 := by decide
theorem cert_e1209083687638 : check e1209083687638 [[],[]] .chain = true := by decide
def e1209083687642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1209083687642 : Closed e1209083687642 ∧ code e1209083687642 = 5607130198746 := by decide
theorem cert_e1209083687642 : check e1209083687642 [[],[]] .chain = true := by decide
def e1209083687658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1209083687658 : Closed e1209083687658 ∧ code e1209083687658 = 5607130198762 := by decide
theorem cert_e1209083687658 : check e1209083687658 [[],[]] .chain = true := by decide
def e1209083687734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1209083687734 : Closed e1209083687734 ∧ code e1209083687734 = 5607130198838 := by decide
theorem cert_e1209083687734 : check e1209083687734 [[],[]] .chain = true := by decide
def e1209083687738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1209083687738 : Closed e1209083687738 ∧ code e1209083687738 = 5607130198842 := by decide
theorem cert_e1209083687738 : check e1209083687738 [[],[]] .chain = true := by decide
def e1209083687834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1209083687834 : Closed e1209083687834 ∧ code e1209083687834 = 5607130198938 := by decide
theorem cert_e1209083687834 : check e1209083687834 [[],[]] .chain = true := by decide
def e1209083825006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209083825006 : Closed e1209083825006 ∧ code e1209083825006 = 5607130336110 := by decide
theorem cert_e1209083825006 : check e1209083825006 [[],[]] .chain = true := by decide
def e1209083825014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209083825014 : Closed e1209083825014 ∧ code e1209083825014 = 5607130336118 := by decide
theorem cert_e1209083825014 : check e1209083825014 [[],[]] .chain = true := by decide
def e1209083825070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209083825070 : Closed e1209083825070 ∧ code e1209083825070 = 5607130336174 := by decide
theorem cert_e1209083825070 : check e1209083825070 [[],[]] .chain = true := by decide
def e1209083825082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209083825082 : Closed e1209083825082 ∧ code e1209083825082 = 5607130336186 := by decide
theorem cert_e1209083825082 : check e1209083825082 [[],[]] .chain = true := by decide
def e1209083825110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209083825110 : Closed e1209083825110 ∧ code e1209083825110 = 5607130336214 := by decide
theorem cert_e1209083825110 : check e1209083825110 [[],[]] .chain = true := by decide
def e1209083825114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209083825114 : Closed e1209083825114 ∧ code e1209083825114 = 5607130336218 := by decide
theorem cert_e1209083825114 : check e1209083825114 [[],[]] .chain = true := by decide
def e1209083825390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209083825390 : Closed e1209083825390 ∧ code e1209083825390 = 5607130336494 := by decide
theorem cert_e1209083825390 : check e1209083825390 [[],[]] .chain = true := by decide
def e1209083825398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209083825398 : Closed e1209083825398 ∧ code e1209083825398 = 5607130336502 := by decide
theorem cert_e1209083825398 : check e1209083825398 [[],[]] .chain = true := by decide
def e1209083825774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209083825774 : Closed e1209083825774 ∧ code e1209083825774 = 5607130336878 := by decide
theorem cert_e1209083825774 : check e1209083825774 [[],[]] .chain = true := by decide
def e1209083825786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209083825786 : Closed e1209083825786 ∧ code e1209083825786 = 5607130336890 := by decide
theorem cert_e1209083825786 : check e1209083825786 [[],[]] .chain = true := by decide
def e1209083825974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209083825974 : Closed e1209083825974 ∧ code e1209083825974 = 5607130337078 := by decide
theorem cert_e1209083825974 : check e1209083825974 [[],[]] .chain = true := by decide
def e1209083825978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209083825978 : Closed e1209083825978 ∧ code e1209083825978 = 5607130337082 := by decide
theorem cert_e1209083825978 : check e1209083825978 [[],[]] .chain = true := by decide
def e1209084414830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209084414830 : Closed e1209084414830 ∧ code e1209084414830 = 5607130925934 := by decide
theorem cert_e1209084414830 : check e1209084414830 [[],[],[.left]] .chain = true := by decide
def e1209084414838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209084414838 : Closed e1209084414838 ∧ code e1209084414838 = 5607130925942 := by decide
theorem cert_e1209084414838 : check e1209084414838 [[],[],[.left]] .chain = true := by decide
def e1209084414894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209084414894 : Closed e1209084414894 ∧ code e1209084414894 = 5607130925998 := by decide
theorem cert_e1209084414894 : check e1209084414894 [[],[],[.left]] .chain = true := by decide
def e1209084414906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209084414906 : Closed e1209084414906 ∧ code e1209084414906 = 5607130926010 := by decide
theorem cert_e1209084414906 : check e1209084414906 [[],[],[.left]] .chain = true := by decide
def e1209084414934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209084414934 : Closed e1209084414934 ∧ code e1209084414934 = 5607130926038 := by decide
theorem cert_e1209084414934 : check e1209084414934 [[],[],[.left]] .chain = true := by decide
def e1209084414938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209084414938 : Closed e1209084414938 ∧ code e1209084414938 = 5607130926042 := by decide
theorem cert_e1209084414938 : check e1209084414938 [[],[],[.left]] .chain = true := by decide
def e1209084415214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209084415214 : Closed e1209084415214 ∧ code e1209084415214 = 5607130926318 := by decide
theorem cert_e1209084415214 : check e1209084415214 [[],[],[.left]] .chain = true := by decide
def e1209084415222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209084415222 : Closed e1209084415222 ∧ code e1209084415222 = 5607130926326 := by decide
theorem cert_e1209084415222 : check e1209084415222 [[],[],[.left]] .chain = true := by decide
def e1209084415598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209084415598 : Closed e1209084415598 ∧ code e1209084415598 = 5607130926702 := by decide
theorem cert_e1209084415598 : check e1209084415598 [[],[],[.left]] .chain = true := by decide
def e1209084415610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209084415610 : Closed e1209084415610 ∧ code e1209084415610 = 5607130926714 := by decide
theorem cert_e1209084415610 : check e1209084415610 [[],[],[.left]] .chain = true := by decide
def e1209084415798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209084415798 : Closed e1209084415798 ∧ code e1209084415798 = 5607130926902 := by decide
theorem cert_e1209084415798 : check e1209084415798 [[],[],[.left]] .chain = true := by decide
def e1209084415802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209084415802 : Closed e1209084415802 ∧ code e1209084415802 = 5607130926906 := by decide
theorem cert_e1209084415802 : check e1209084415802 [[],[],[.left]] .chain = true := by decide
def e1209151483418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151483418 : Closed e1209151483418 ∧ code e1209151483418 = 5607197994522 := by decide
private def t_e1209151483418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151483418 : ¬ IsSelfInterpreter e1209151483418 :=
  wSource (t := t_e1209151483418) (replay_sound (ps := []) (t := e1209151483418) (by decide)) (by decide)
def e1209151485466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151485466 : Closed e1209151485466 ∧ code e1209151485466 = 5607197996570 := by decide
private def t_e1209151485466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151485466 : ¬ IsSelfInterpreter e1209151485466 :=
  wSource (t := t_e1209151485466) (replay_sound (ps := []) (t := e1209151485466) (by decide)) (by decide)
def e1209151499802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151499802 : Closed e1209151499802 ∧ code e1209151499802 = 5607198010906 := by decide
private def t_e1209151499802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151499802 : ¬ IsSelfInterpreter e1209151499802 :=
  wSource (t := t_e1209151499802) (replay_sound (ps := []) (t := e1209151499802) (by decide)) (by decide)
def e1209151502874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151502874 : Closed e1209151502874 ∧ code e1209151502874 = 5607198013978 := by decide
private def t_e1209151502874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151502874 : ¬ IsSelfInterpreter e1209151502874 :=
  wSource (t := t_e1209151502874) (replay_sound (ps := []) (t := e1209151502874) (by decide)) (by decide)
def e1209151510042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151510042 : Closed e1209151510042 ∧ code e1209151510042 = 5607198021146 := by decide
private def t_e1209151510042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151510042 : ¬ IsSelfInterpreter e1209151510042 :=
  wSource (t := t_e1209151510042) (replay_sound (ps := []) (t := e1209151510042) (by decide)) (by decide)
def e1209151511066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151511066 : Closed e1209151511066 ∧ code e1209151511066 = 5607198022170 := by decide
private def t_e1209151511066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151511066 : ¬ IsSelfInterpreter e1209151511066 :=
  wSource (t := t_e1209151511066) (replay_sound (ps := []) (t := e1209151511066) (by decide)) (by decide)
def e1209151581722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151581722 : Closed e1209151581722 ∧ code e1209151581722 = 5607198092826 := by decide
private def t_e1209151581722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151581722 : ¬ IsSelfInterpreter e1209151581722 :=
  wSource (t := t_e1209151581722) (replay_sound (ps := []) (t := e1209151581722) (by decide)) (by decide)
def e1209151583770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151583770 : Closed e1209151583770 ∧ code e1209151583770 = 5607198094874 := by decide
private def t_e1209151583770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151583770 : ¬ IsSelfInterpreter e1209151583770 :=
  wSource (t := t_e1209151583770) (replay_sound (ps := []) (t := e1209151583770) (by decide)) (by decide)
def e1209151680026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151680026 : Closed e1209151680026 ∧ code e1209151680026 = 5607198191130 := by decide
private def t_e1209151680026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151680026 : ¬ IsSelfInterpreter e1209151680026 :=
  wSource (t := t_e1209151680026) (replay_sound (ps := []) (t := e1209151680026) (by decide)) (by decide)
def e1209151683098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151683098 : Closed e1209151683098 ∧ code e1209151683098 = 5607198194202 := by decide
private def t_e1209151683098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151683098 : ¬ IsSelfInterpreter e1209151683098 :=
  wSource (t := t_e1209151683098) (replay_sound (ps := []) (t := e1209151683098) (by decide)) (by decide)
def e1209151731226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151731226 : Closed e1209151731226 ∧ code e1209151731226 = 5607198242330 := by decide
private def t_e1209151731226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151731226 : ¬ IsSelfInterpreter e1209151731226 :=
  wSource (t := t_e1209151731226) (replay_sound (ps := []) (t := e1209151731226) (by decide)) (by decide)
def e1209151732250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209151732250 : Closed e1209151732250 ∧ code e1209151732250 = 5607198243354 := by decide
private def t_e1209151732250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209151732250 : ¬ IsSelfInterpreter e1209151732250 :=
  wSource (t := t_e1209151732250) (replay_sound (ps := []) (t := e1209151732250) (by decide)) (by decide)
def e1209167600350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1209167600350 : Closed e1209167600350 ∧ code e1209167600350 = 5607214111454 := by decide
theorem cert_e1209167600350 : check e1209167600350 [[],[]] .three = true := by decide
def e1209167600374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1209167600374 : Closed e1209167600374 ∧ code e1209167600374 = 5607214111478 := by decide
theorem cert_e1209167600374 : check e1209167600374 [[],[]] .three = true := by decide
def e1209167600478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1209167600478 : Closed e1209167600478 ∧ code e1209167600478 = 5607214111582 := by decide
theorem cert_e1209167600478 : check e1209167600478 [[],[]] .three = true := by decide
def e1209167600494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1209167600494 : Closed e1209167600494 ∧ code e1209167600494 = 5607214111598 := by decide
theorem cert_e1209167600494 : check e1209167600494 [[],[]] .smaller = true := by decide
def e1209167600502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1209167600502 : Closed e1209167600502 ∧ code e1209167600502 = 5607214111606 := by decide
theorem cert_e1209167600502 : check e1209167600502 [[],[]] .smaller = true := by decide
def e1209167600506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1209167600506 : Closed e1209167600506 ∧ code e1209167600506 = 5607214111610 := by decide
theorem cert_e1209167600506 : check e1209167600506 [[],[]] .three = true := by decide
def e1209167600566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1209167600566 : Closed e1209167600566 ∧ code e1209167600566 = 5607214111670 := by decide
theorem cert_e1209167600566 : check e1209167600566 [[],[]] .smaller = true := by decide
def e1209167600598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1209167600598 : Closed e1209167600598 ∧ code e1209167600598 = 5607214111702 := by decide
theorem cert_e1209167600598 : check e1209167600598 [[],[]] .three = true := by decide
def e1209167600602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1209167600602 : Closed e1209167600602 ∧ code e1209167600602 = 5607214111706 := by decide
theorem cert_e1209167600602 : check e1209167600602 [[],[]] .three = true := by decide
def e1209167600990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1209167600990 : Closed e1209167600990 ∧ code e1209167600990 = 5607214112094 := by decide
theorem cert_e1209167600990 : check e1209167600990 [[],[]] .three = true := by decide
def e1209167601006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1209167601006 : Closed e1209167601006 ∧ code e1209167601006 = 5607214112110 := by decide
theorem cert_e1209167601006 : check e1209167601006 [[],[]] .smaller = true := by decide
def e1209167601014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1209167601014 : Closed e1209167601014 ∧ code e1209167601014 = 5607214112118 := by decide
theorem cert_e1209167601014 : check e1209167601014 [[],[]] .smaller = true := by decide
def e1209167601018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1209167601018 : Closed e1209167601018 ∧ code e1209167601018 = 5607214112122 := by decide
theorem cert_e1209167601018 : check e1209167601018 [[],[]] .three = true := by decide
def e1209167601070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1209167601070 : Closed e1209167601070 ∧ code e1209167601070 = 5607214112174 := by decide
theorem cert_e1209167601070 : check e1209167601070 [[],[]] .smaller = true := by decide
def e1209167601082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1209167601082 : Closed e1209167601082 ∧ code e1209167601082 = 5607214112186 := by decide
theorem cert_e1209167601082 : check e1209167601082 [[],[]] .smaller = true := by decide
def e1209167601110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1209167601110 : Closed e1209167601110 ∧ code e1209167601110 = 5607214112214 := by decide
theorem cert_e1209167601110 : check e1209167601110 [[],[]] .smaller = true := by decide
def e1209167601114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1209167601114 : Closed e1209167601114 ∧ code e1209167601114 = 5607214112218 := by decide
theorem cert_e1209167601114 : check e1209167601114 [[],[]] .smaller = true := by decide
def e1209167601130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1209167601130 : Closed e1209167601130 ∧ code e1209167601130 = 5607214112234 := by decide
theorem cert_e1209167601130 : check e1209167601130 [[],[]] .three = true := by decide
def e1209167601334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1209167601334 : Closed e1209167601334 ∧ code e1209167601334 = 5607214112438 := by decide
theorem cert_e1209167601334 : check e1209167601334 [[],[]] .smaller = true := by decide
def e1209167601366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1209167601366 : Closed e1209167601366 ∧ code e1209167601366 = 5607214112470 := by decide
theorem cert_e1209167601366 : check e1209167601366 [[],[]] .smaller = true := by decide
def e1209167601370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1209167601370 : Closed e1209167601370 ∧ code e1209167601370 = 5607214112474 := by decide
theorem cert_e1209167601370 : check e1209167601370 [[],[]] .smaller = true := by decide
def e1209167601494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1209167601494 : Closed e1209167601494 ∧ code e1209167601494 = 5607214112598 := by decide
theorem cert_e1209167601494 : check e1209167601494 [[],[]] .three = true := by decide
def e1209167601498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1209167601498 : Closed e1209167601498 ∧ code e1209167601498 = 5607214112602 := by decide
theorem cert_e1209167601498 : check e1209167601498 [[],[]] .three = true := by decide
def e1209167601514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1209167601514 : Closed e1209167601514 ∧ code e1209167601514 = 5607214112618 := by decide
theorem cert_e1209167601514 : check e1209167601514 [[],[]] .three = true := by decide
def e1209167603422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1209167603422 : Closed e1209167603422 ∧ code e1209167603422 = 5607214114526 := by decide
theorem cert_e1209167603422 : check e1209167603422 [[],[]] .three = true := by decide
def e1209167603446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1209167603446 : Closed e1209167603446 ∧ code e1209167603446 = 5607214114550 := by decide
theorem cert_e1209167603446 : check e1209167603446 [[],[]] .three = true := by decide
def e1209167603550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1209167603550 : Closed e1209167603550 ∧ code e1209167603550 = 5607214114654 := by decide
theorem cert_e1209167603550 : check e1209167603550 [[],[]] .three = true := by decide
def e1209167603566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1209167603566 : Closed e1209167603566 ∧ code e1209167603566 = 5607214114670 := by decide
theorem cert_e1209167603566 : check e1209167603566 [[],[]] .smaller = true := by decide
def e1209167603574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1209167603574 : Closed e1209167603574 ∧ code e1209167603574 = 5607214114678 := by decide
theorem cert_e1209167603574 : check e1209167603574 [[],[]] .smaller = true := by decide
def e1209167603578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1209167603578 : Closed e1209167603578 ∧ code e1209167603578 = 5607214114682 := by decide
theorem cert_e1209167603578 : check e1209167603578 [[],[]] .three = true := by decide
def e1209167603638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1209167603638 : Closed e1209167603638 ∧ code e1209167603638 = 5607214114742 := by decide
theorem cert_e1209167603638 : check e1209167603638 [[],[]] .smaller = true := by decide
def e1209167603670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1209167603670 : Closed e1209167603670 ∧ code e1209167603670 = 5607214114774 := by decide
theorem cert_e1209167603670 : check e1209167603670 [[],[]] .three = true := by decide
def e1209167603674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1209167603674 : Closed e1209167603674 ∧ code e1209167603674 = 5607214114778 := by decide
theorem cert_e1209167603674 : check e1209167603674 [[],[]] .three = true := by decide
def e1209167604190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1209167604190 : Closed e1209167604190 ∧ code e1209167604190 = 5607214115294 := by decide
theorem cert_e1209167604190 : check e1209167604190 [[],[]] .three = true := by decide
def e1209167604214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1209167604214 : Closed e1209167604214 ∧ code e1209167604214 = 5607214115318 := by decide
theorem cert_e1209167604214 : check e1209167604214 [[],[]] .three = true := by decide
def e1209167604958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1209167604958 : Closed e1209167604958 ∧ code e1209167604958 = 5607214116062 := by decide
theorem cert_e1209167604958 : check e1209167604958 [[],[]] .three = true := by decide
def e1209167604974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209167604974 : Closed e1209167604974 ∧ code e1209167604974 = 5607214116078 := by decide
theorem cert_e1209167604974 : check e1209167604974 [[],[]] .smaller = true := by decide
def e1209167604982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209167604982 : Closed e1209167604982 ∧ code e1209167604982 = 5607214116086 := by decide
theorem cert_e1209167604982 : check e1209167604982 [[],[]] .smaller = true := by decide
def e1209167604986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1209167604986 : Closed e1209167604986 ∧ code e1209167604986 = 5607214116090 := by decide
theorem cert_e1209167604986 : check e1209167604986 [[],[]] .three = true := by decide
def e1209167605366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209167605366 : Closed e1209167605366 ∧ code e1209167605366 = 5607214116470 := by decide
theorem cert_e1209167605366 : check e1209167605366 [[],[]] .smaller = true := by decide
def e1209167605558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209167605558 : Closed e1209167605558 ∧ code e1209167605558 = 5607214116662 := by decide
theorem cert_e1209167605558 : check e1209167605558 [[],[]] .three = true := by decide
def e1209167605562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209167605562 : Closed e1209167605562 ∧ code e1209167605562 = 5607214116666 := by decide
theorem cert_e1209167605562 : check e1209167605562 [[],[]] .three = true := by decide
def e1209167606622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e1209167606622 : Closed e1209167606622 ∧ code e1209167606622 = 5607214117726 := by decide
theorem cert_e1209167606622 : check e1209167606622 [[],[]] .three = true := by decide
def e1209167606638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1209167606638 : Closed e1209167606638 ∧ code e1209167606638 = 5607214117742 := by decide
theorem cert_e1209167606638 : check e1209167606638 [[],[]] .smaller = true := by decide
def e1209167606646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1209167606646 : Closed e1209167606646 ∧ code e1209167606646 = 5607214117750 := by decide
theorem cert_e1209167606646 : check e1209167606646 [[],[]] .smaller = true := by decide
def e1209167606650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e1209167606650 : Closed e1209167606650 ∧ code e1209167606650 = 5607214117754 := by decide
theorem cert_e1209167606650 : check e1209167606650 [[],[]] .three = true := by decide
def e1209167606702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1209167606702 : Closed e1209167606702 ∧ code e1209167606702 = 5607214117806 := by decide
theorem cert_e1209167606702 : check e1209167606702 [[],[]] .smaller = true := by decide
def e1209167606714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1209167606714 : Closed e1209167606714 ∧ code e1209167606714 = 5607214117818 := by decide
theorem cert_e1209167606714 : check e1209167606714 [[],[]] .smaller = true := by decide
def e1209167606742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1209167606742 : Closed e1209167606742 ∧ code e1209167606742 = 5607214117846 := by decide
theorem cert_e1209167606742 : check e1209167606742 [[],[]] .smaller = true := by decide
def e1209167606746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1209167606746 : Closed e1209167606746 ∧ code e1209167606746 = 5607214117850 := by decide
theorem cert_e1209167606746 : check e1209167606746 [[],[]] .smaller = true := by decide
def e1209167606762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e1209167606762 : Closed e1209167606762 ∧ code e1209167606762 = 5607214117866 := by decide
theorem cert_e1209167606762 : check e1209167606762 [[],[]] .three = true := by decide
def e1209167607006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e1209167607006 : Closed e1209167607006 ∧ code e1209167607006 = 5607214118110 := by decide
theorem cert_e1209167607006 : check e1209167607006 [[],[]] .three = true := by decide
def e1209167607022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1209167607022 : Closed e1209167607022 ∧ code e1209167607022 = 5607214118126 := by decide
theorem cert_e1209167607022 : check e1209167607022 [[],[]] .smaller = true := by decide
def e1209167607030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1209167607030 : Closed e1209167607030 ∧ code e1209167607030 = 5607214118134 := by decide
theorem cert_e1209167607030 : check e1209167607030 [[],[]] .smaller = true := by decide
def e1209167607034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e1209167607034 : Closed e1209167607034 ∧ code e1209167607034 = 5607214118138 := by decide
theorem cert_e1209167607034 : check e1209167607034 [[],[]] .three = true := by decide
def e1209167607406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1209167607406 : Closed e1209167607406 ∧ code e1209167607406 = 5607214118510 := by decide
theorem cert_e1209167607406 : check e1209167607406 [[],[]] .smaller = true := by decide
def e1209167607418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1209167607418 : Closed e1209167607418 ∧ code e1209167607418 = 5607214118522 := by decide
theorem cert_e1209167607418 : check e1209167607418 [[],[]] .smaller = true := by decide
def e1209167607606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209167607606 : Closed e1209167607606 ∧ code e1209167607606 = 5607214118710 := by decide
theorem cert_e1209167607606 : check e1209167607606 [[],[]] .smaller = true := by decide
def e1209167607610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209167607610 : Closed e1209167607610 ∧ code e1209167607610 = 5607214118714 := by decide
theorem cert_e1209167607610 : check e1209167607610 [[],[]] .smaller = true := by decide
def e1209167607706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209167607706 : Closed e1209167607706 ∧ code e1209167607706 = 5607214118810 := by decide
theorem cert_e1209167607706 : check e1209167607706 [[],[]] .three = true := by decide
def e1209167608246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1209167608246 : Closed e1209167608246 ∧ code e1209167608246 = 5607214119350 := by decide
theorem cert_e1209167608246 : check e1209167608246 [[],[]] .smaller = true := by decide
def e1209167608278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1209167608278 : Closed e1209167608278 ∧ code e1209167608278 = 5607214119382 := by decide
theorem cert_e1209167608278 : check e1209167608278 [[],[]] .smaller = true := by decide
def e1209167608282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1209167608282 : Closed e1209167608282 ∧ code e1209167608282 = 5607214119386 := by decide
theorem cert_e1209167608282 : check e1209167608282 [[],[]] .smaller = true := by decide
def e1209167608438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1209167608438 : Closed e1209167608438 ∧ code e1209167608438 = 5607214119542 := by decide
theorem cert_e1209167608438 : check e1209167608438 [[],[]] .smaller = true := by decide
def e1209167608630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209167608630 : Closed e1209167608630 ∧ code e1209167608630 = 5607214119734 := by decide
theorem cert_e1209167608630 : check e1209167608630 [[],[]] .smaller = true := by decide
def e1209167608634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209167608634 : Closed e1209167608634 ∧ code e1209167608634 = 5607214119738 := by decide
theorem cert_e1209167608634 : check e1209167608634 [[],[]] .smaller = true := by decide
def e1209167609046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1209167609046 : Closed e1209167609046 ∧ code e1209167609046 = 5607214120150 := by decide
theorem cert_e1209167609046 : check e1209167609046 [[],[]] .three = true := by decide
def e1209167609050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1209167609050 : Closed e1209167609050 ∧ code e1209167609050 = 5607214120154 := by decide
theorem cert_e1209167609050 : check e1209167609050 [[],[]] .three = true := by decide
def e1209167609066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1209167609066 : Closed e1209167609066 ∧ code e1209167609066 = 5607214120170 := by decide
theorem cert_e1209167609066 : check e1209167609066 [[],[]] .three = true := by decide
def e1209167609142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1209167609142 : Closed e1209167609142 ∧ code e1209167609142 = 5607214120246 := by decide
theorem cert_e1209167609142 : check e1209167609142 [[],[]] .three = true := by decide
def e1209167609146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1209167609146 : Closed e1209167609146 ∧ code e1209167609146 = 5607214120250 := by decide
theorem cert_e1209167609146 : check e1209167609146 [[],[]] .three = true := by decide
def e1209167609242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1209167609242 : Closed e1209167609242 ∧ code e1209167609242 = 5607214120346 := by decide
theorem cert_e1209167609242 : check e1209167609242 [[],[]] .three = true := by decide
def e1209167615710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1209167615710 : Closed e1209167615710 ∧ code e1209167615710 = 5607214126814 := by decide
theorem cert_e1209167615710 : check e1209167615710 [[],[]] .three = true := by decide
def e1209167615734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1209167615734 : Closed e1209167615734 ∧ code e1209167615734 = 5607214126838 := by decide
theorem cert_e1209167615734 : check e1209167615734 [[],[]] .three = true := by decide
end Blc.Floor42
