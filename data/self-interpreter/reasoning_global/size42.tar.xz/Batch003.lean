import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e299238633198 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e299238633198 : Closed e299238633198 ∧ code e299238633198 = 4697285144302 := by decide
theorem cert_e299238633198 : check e299238633198 [[.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e299238633326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e299238633326 : Closed e299238633326 ∧ code e299238633326 = 4697285144430 := by decide
theorem cert_e299238633326 : checkPay e299238633326 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e299238633334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e299238633334 : Closed e299238633334 ∧ code e299238633334 = 4697285144438 := by decide
theorem cert_e299238633334 : check e299238633334 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e299238636014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e299238636014 : Closed e299238636014 ∧ code e299238636014 = 4697285147118 := by decide
theorem cert_e299238636014 : check e299238636014 [[.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e299238636782 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e299238636782 : Closed e299238636782 ∧ code e299238636782 = 4697285147886 := by decide
theorem cert_e299238636782 : check e299238636782 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e299238636790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e299238636790 : Closed e299238636790 ∧ code e299238636790 = 4697285147894 := by decide
theorem cert_e299238636790 : check e299238636790 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e299238659822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e299238659822 : Closed e299238659822 ∧ code e299238659822 = 4697285170926 := by decide
theorem cert_e299238659822 : check e299238659822 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238660014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e299238660014 : Closed e299238660014 ∧ code e299238660014 = 4697285171118 := by decide
theorem cert_e299238660014 : check e299238660014 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238660026 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e299238660026 : Closed e299238660026 ∧ code e299238660026 = 4697285171130 := by decide
theorem cert_e299238660026 : check e299238660026 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238660590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e299238660590 : Closed e299238660590 ∧ code e299238660590 = 4697285171694 := by decide
theorem cert_e299238660590 : check e299238660590 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238661742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e299238661742 : Closed e299238661742 ∧ code e299238661742 = 4697285172846 := by decide
theorem cert_e299238661742 : check e299238661742 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238661754 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e299238661754 : Closed e299238661754 ∧ code e299238661754 = 4697285172858 := by decide
theorem cert_e299238661754 : check e299238661754 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299238673262 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e299238673262 : Closed e299238673262 ∧ code e299238673262 = 4697285184366 := by decide
theorem cert_e299238673262 : check e299238673262 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e299238673270 : Closed e299238673270 ∧ code e299238673270 = 4697285184374 := by decide
theorem cert_e299238673270 : check e299238673270 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e299238673326 : Closed e299238673326 ∧ code e299238673326 = 4697285184430 := by decide
theorem cert_e299238673326 : check e299238673326 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e299238673338 : Closed e299238673338 ∧ code e299238673338 = 4697285184442 := by decide
theorem cert_e299238673338 : check e299238673338 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e299238673366 : Closed e299238673366 ∧ code e299238673366 = 4697285184470 := by decide
theorem cert_e299238673366 : check e299238673366 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673370 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e299238673370 : Closed e299238673370 ∧ code e299238673370 = 4697285184474 := by decide
theorem cert_e299238673370 : check e299238673370 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e299238673646 : Closed e299238673646 ∧ code e299238673646 = 4697285184750 := by decide
theorem cert_e299238673646 : check e299238673646 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238673654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e299238673654 : Closed e299238673654 ∧ code e299238673654 = 4697285184758 := by decide
theorem cert_e299238673654 : check e299238673654 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238674030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e299238674030 : Closed e299238674030 ∧ code e299238674030 = 4697285185134 := by decide
theorem cert_e299238674030 : check e299238674030 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238674042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e299238674042 : Closed e299238674042 ∧ code e299238674042 = 4697285185146 := by decide
theorem cert_e299238674042 : check e299238674042 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238674230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e299238674230 : Closed e299238674230 ∧ code e299238674230 = 4697285185334 := by decide
theorem cert_e299238674230 : check e299238674230 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299238674234 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e299238674234 : Closed e299238674234 ∧ code e299238674234 = 4697285185338 := by decide
theorem cert_e299238674234 : check e299238674234 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e299239213934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299239213934 : Closed e299239213934 ∧ code e299239213934 = 4697285725038 := by decide
theorem cert_e299239213934 : check e299239213934 [[.under],[.under,.left]] .smaller = true := by decide
def e299239213942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299239213942 : Closed e299239213942 ∧ code e299239213942 = 4697285725046 := by decide
theorem cert_e299239213942 : check e299239213942 [[.under],[.under,.left]] .smaller = true := by decide
def e299239213998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299239213998 : Closed e299239213998 ∧ code e299239213998 = 4697285725102 := by decide
theorem cert_e299239213998 : check e299239213998 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214010 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299239214010 : Closed e299239214010 ∧ code e299239214010 = 4697285725114 := by decide
theorem cert_e299239214010 : check e299239214010 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299239214038 : Closed e299239214038 ∧ code e299239214038 = 4697285725142 := by decide
theorem cert_e299239214038 : check e299239214038 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299239214042 : Closed e299239214042 ∧ code e299239214042 = 4697285725146 := by decide
theorem cert_e299239214042 : check e299239214042 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214318 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299239214318 : Closed e299239214318 ∧ code e299239214318 = 4697285725422 := by decide
theorem cert_e299239214318 : check e299239214318 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299239214326 : Closed e299239214326 ∧ code e299239214326 = 4697285725430 := by decide
theorem cert_e299239214326 : check e299239214326 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299239214702 : Closed e299239214702 ∧ code e299239214702 = 4697285725806 := by decide
theorem cert_e299239214702 : check e299239214702 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299239214714 : Closed e299239214714 ∧ code e299239214714 = 4697285725818 := by decide
theorem cert_e299239214714 : check e299239214714 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299239214902 : Closed e299239214902 ∧ code e299239214902 = 4697285726006 := by decide
theorem cert_e299239214902 : check e299239214902 [[.under],[.under,.left]] .smaller = true := by decide
def e299239214906 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299239214906 : Closed e299239214906 ∧ code e299239214906 = 4697285726010 := by decide
theorem cert_e299239214906 : check e299239214906 [[.under],[.under,.left]] .smaller = true := by decide
def e299372686702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e299372686702 : Closed e299372686702 ∧ code e299372686702 = 4697419197806 := by decide
theorem cert_e299372686702 : check e299372686702 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372686710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e299372686710 : Closed e299372686710 ∧ code e299372686710 = 4697419197814 := by decide
theorem cert_e299372686710 : check e299372686710 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372686766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e299372686766 : Closed e299372686766 ∧ code e299372686766 = 4697419197870 := by decide
theorem cert_e299372686766 : check e299372686766 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372686778 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e299372686778 : Closed e299372686778 ∧ code e299372686778 = 4697419197882 := by decide
theorem cert_e299372686778 : check e299372686778 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372686806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e299372686806 : Closed e299372686806 ∧ code e299372686806 = 4697419197910 := by decide
theorem cert_e299372686806 : check e299372686806 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372686810 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e299372686810 : Closed e299372686810 ∧ code e299372686810 = 4697419197914 := by decide
theorem cert_e299372686810 : check e299372686810 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372687022 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e299372687022 : Closed e299372687022 ∧ code e299372687022 = 4697419198126 := by decide
theorem cert_e299372687022 : check e299372687022 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372687034 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e299372687034 : Closed e299372687034 ∧ code e299372687034 = 4697419198138 := by decide
theorem cert_e299372687034 : check e299372687034 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372687082 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e299372687082 : Closed e299372687082 ∧ code e299372687082 = 4697419198186 := by decide
theorem cert_e299372687082 : check e299372687082 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372687190 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e299372687190 : Closed e299372687190 ∧ code e299372687190 = 4697419198294 := by decide
theorem cert_e299372687190 : check e299372687190 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372687194 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e299372687194 : Closed e299372687194 ∧ code e299372687194 = 4697419198298 := by decide
theorem cert_e299372687194 : check e299372687194 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372687210 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e299372687210 : Closed e299372687210 ∧ code e299372687210 = 4697419198314 := by decide
theorem cert_e299372687210 : check e299372687210 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e299372688238 : Closed e299372688238 ∧ code e299372688238 = 4697419199342 := by decide
theorem cert_e299372688238 : check e299372688238 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e299372688246 : Closed e299372688246 ∧ code e299372688246 = 4697419199350 := by decide
theorem cert_e299372688246 : check e299372688246 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e299372688302 : Closed e299372688302 ∧ code e299372688302 = 4697419199406 := by decide
theorem cert_e299372688302 : check e299372688302 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e299372688314 : Closed e299372688314 ∧ code e299372688314 = 4697419199418 := by decide
theorem cert_e299372688314 : check e299372688314 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e299372688342 : Closed e299372688342 ∧ code e299372688342 = 4697419199446 := by decide
theorem cert_e299372688342 : check e299372688342 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e299372688346 : Closed e299372688346 ∧ code e299372688346 = 4697419199450 := by decide
theorem cert_e299372688346 : check e299372688346 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e299372688622 : Closed e299372688622 ∧ code e299372688622 = 4697419199726 := by decide
theorem cert_e299372688622 : check e299372688622 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372688630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e299372688630 : Closed e299372688630 ∧ code e299372688630 = 4697419199734 := by decide
theorem cert_e299372688630 : check e299372688630 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e299372689006 : Closed e299372689006 ∧ code e299372689006 = 4697419200110 := by decide
theorem cert_e299372689006 : check e299372689006 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e299372689018 : Closed e299372689018 ∧ code e299372689018 = 4697419200122 := by decide
theorem cert_e299372689018 : check e299372689018 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e299372689206 : Closed e299372689206 ∧ code e299372689206 = 4697419200310 := by decide
theorem cert_e299372689206 : check e299372689206 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689210 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e299372689210 : Closed e299372689210 ∧ code e299372689210 = 4697419200314 := by decide
theorem cert_e299372689210 : check e299372689210 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e299372689838 : Closed e299372689838 ∧ code e299372689838 = 4697419200942 := by decide
theorem cert_e299372689838 : check e299372689838 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689850 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e299372689850 : Closed e299372689850 ∧ code e299372689850 = 4697419200954 := by decide
theorem cert_e299372689850 : check e299372689850 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372689898 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e299372689898 : Closed e299372689898 ∧ code e299372689898 = 4697419201002 := by decide
theorem cert_e299372689898 : check e299372689898 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e299372690030 : Closed e299372690030 ∧ code e299372690030 = 4697419201134 := by decide
theorem cert_e299372690030 : check e299372690030 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e299372690042 : Closed e299372690042 ∧ code e299372690042 = 4697419201146 := by decide
theorem cert_e299372690042 : check e299372690042 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690330 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e299372690330 : Closed e299372690330 ∧ code e299372690330 = 4697419201434 := by decide
theorem cert_e299372690330 : check e299372690330 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e299372690646 : Closed e299372690646 ∧ code e299372690646 = 4697419201750 := by decide
theorem cert_e299372690646 : check e299372690646 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690650 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e299372690650 : Closed e299372690650 ∧ code e299372690650 = 4697419201754 := by decide
theorem cert_e299372690650 : check e299372690650 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e299372690666 : Closed e299372690666 ∧ code e299372690666 = 4697419201770 := by decide
theorem cert_e299372690666 : check e299372690666 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e299372690742 : Closed e299372690742 ∧ code e299372690742 = 4697419201846 := by decide
theorem cert_e299372690742 : check e299372690742 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e299372690746 : Closed e299372690746 ∧ code e299372690746 = 4697419201850 := by decide
theorem cert_e299372690746 : check e299372690746 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372690842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e299372690842 : Closed e299372690842 ∧ code e299372690842 = 4697419201946 := by decide
theorem cert_e299372690842 : check e299372690842 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694382 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299372694382 : Closed e299372694382 ∧ code e299372694382 = 4697419205486 := by decide
theorem cert_e299372694382 : check e299372694382 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299372694390 : Closed e299372694390 ∧ code e299372694390 = 4697419205494 := by decide
theorem cert_e299372694390 : check e299372694390 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299372694446 : Closed e299372694446 ∧ code e299372694446 = 4697419205550 := by decide
theorem cert_e299372694446 : check e299372694446 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694458 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299372694458 : Closed e299372694458 ∧ code e299372694458 = 4697419205562 := by decide
theorem cert_e299372694458 : check e299372694458 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299372694486 : Closed e299372694486 ∧ code e299372694486 = 4697419205590 := by decide
theorem cert_e299372694486 : check e299372694486 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694490 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299372694490 : Closed e299372694490 ∧ code e299372694490 = 4697419205594 := by decide
theorem cert_e299372694490 : check e299372694490 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299372694766 : Closed e299372694766 ∧ code e299372694766 = 4697419205870 := by decide
theorem cert_e299372694766 : check e299372694766 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372694774 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299372694774 : Closed e299372694774 ∧ code e299372694774 = 4697419205878 := by decide
theorem cert_e299372694774 : check e299372694774 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372695150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299372695150 : Closed e299372695150 ∧ code e299372695150 = 4697419206254 := by decide
theorem cert_e299372695150 : check e299372695150 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372695162 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299372695162 : Closed e299372695162 ∧ code e299372695162 = 4697419206266 := by decide
theorem cert_e299372695162 : check e299372695162 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372695350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299372695350 : Closed e299372695350 ∧ code e299372695350 = 4697419206454 := by decide
theorem cert_e299372695350 : check e299372695350 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372695354 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299372695354 : Closed e299372695354 ∧ code e299372695354 = 4697419206458 := by decide
theorem cert_e299372695354 : check e299372695354 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372701102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e299372701102 : Closed e299372701102 ∧ code e299372701102 = 4697419212206 := by decide
theorem cert_e299372701102 : check e299372701102 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372701114 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e299372701114 : Closed e299372701114 ∧ code e299372701114 = 4697419212218 := by decide
theorem cert_e299372701114 : check e299372701114 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372701162 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e299372701162 : Closed e299372701162 ∧ code e299372701162 = 4697419212266 := by decide
theorem cert_e299372701162 : check e299372701162 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372701294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e299372701294 : Closed e299372701294 ∧ code e299372701294 = 4697419212398 := by decide
theorem cert_e299372701294 : check e299372701294 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372701306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e299372701306 : Closed e299372701306 ∧ code e299372701306 = 4697419212410 := by decide
theorem cert_e299372701306 : check e299372701306 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372701594 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e299372701594 : Closed e299372701594 ∧ code e299372701594 = 4697419212698 := by decide
theorem cert_e299372701594 : check e299372701594 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372704470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e299372704470 : Closed e299372704470 ∧ code e299372704470 = 4697419215574 := by decide
theorem cert_e299372704470 : check e299372704470 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372704474 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e299372704474 : Closed e299372704474 ∧ code e299372704474 = 4697419215578 := by decide
theorem cert_e299372704474 : check e299372704474 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372704490 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e299372704490 : Closed e299372704490 ∧ code e299372704490 = 4697419215594 := by decide
theorem cert_e299372704490 : check e299372704490 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372704566 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e299372704566 : Closed e299372704566 ∧ code e299372704566 = 4697419215670 := by decide
theorem cert_e299372704566 : check e299372704566 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372704570 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e299372704570 : Closed e299372704570 ∧ code e299372704570 = 4697419215674 := by decide
theorem cert_e299372704570 : check e299372704570 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372704666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e299372704666 : Closed e299372704666 ∧ code e299372704666 = 4697419215770 := by decide
theorem cert_e299372704666 : check e299372704666 [[.under],[.under,.left],[.under]] .three = true := by decide
def e299372820206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e299372820206 : Closed e299372820206 ∧ code e299372820206 = 4697419331310 := by decide
theorem cert_e299372820206 : check e299372820206 [[.under],[.under,.left]] .chain = true := by decide
def e299372820334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e299372820334 : Closed e299372820334 ∧ code e299372820334 = 4697419331438 := by decide
theorem cert_e299372820334 : check e299372820334 [[.under],[.under,.left]] .chain = true := by decide
def e299372820342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e299372820342 : Closed e299372820342 ∧ code e299372820342 = 4697419331446 := by decide
theorem cert_e299372820342 : check e299372820342 [[.under],[.under,.left]] .chain = true := by decide
def e299372821230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e299372821230 : Closed e299372821230 ∧ code e299372821230 = 4697419332334 := by decide
theorem cert_e299372821230 : check e299372821230 [[.under],[.under,.left]] .chain = true := by decide
def e299372821422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e299372821422 : Closed e299372821422 ∧ code e299372821422 = 4697419332526 := by decide
theorem cert_e299372821422 : check e299372821422 [[.under],[.under,.left]] .chain = true := by decide
def e299372821434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e299372821434 : Closed e299372821434 ∧ code e299372821434 = 4697419332538 := by decide
theorem cert_e299372821434 : check e299372821434 [[.under],[.under,.left]] .chain = true := by decide
def e299372821870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e299372821870 : Closed e299372821870 ∧ code e299372821870 = 4697419332974 := by decide
theorem cert_e299372821870 : check e299372821870 [[.under],[.under,.left]] .chain = true := by decide
def e299372821878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e299372821878 : Closed e299372821878 ∧ code e299372821878 = 4697419332982 := by decide
theorem cert_e299372821878 : check e299372821878 [[.under],[.under,.left]] .chain = true := by decide
def e299372821934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e299372821934 : Closed e299372821934 ∧ code e299372821934 = 4697419333038 := by decide
theorem cert_e299372821934 : check e299372821934 [[.under],[.under,.left]] .chain = true := by decide
def e299372821946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e299372821946 : Closed e299372821946 ∧ code e299372821946 = 4697419333050 := by decide
theorem cert_e299372821946 : check e299372821946 [[.under],[.under,.left]] .chain = true := by decide
def e299372821974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e299372821974 : Closed e299372821974 ∧ code e299372821974 = 4697419333078 := by decide
theorem cert_e299372821974 : check e299372821974 [[.under],[.under,.left]] .chain = true := by decide
def e299372821978 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e299372821978 : Closed e299372821978 ∧ code e299372821978 = 4697419333082 := by decide
theorem cert_e299372821978 : check e299372821978 [[.under],[.under,.left]] .chain = true := by decide
def e299372826350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e299372826350 : Closed e299372826350 ∧ code e299372826350 = 4697419337454 := by decide
theorem cert_e299372826350 : check e299372826350 [[.under],[.under,.left]] .chain = true := by decide
def e299372826478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e299372826478 : Closed e299372826478 ∧ code e299372826478 = 4697419337582 := by decide
theorem cert_e299372826478 : check e299372826478 [[.under],[.under,.left]] .chain = true := by decide
def e299372826486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e299372826486 : Closed e299372826486 ∧ code e299372826486 = 4697419337590 := by decide
theorem cert_e299372826486 : check e299372826486 [[.under],[.under,.left]] .chain = true := by decide
def e299372829166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e299372829166 : Closed e299372829166 ∧ code e299372829166 = 4697419340270 := by decide
theorem cert_e299372829166 : check e299372829166 [[.under],[.under,.left]] .chain = true := by decide
def e299372829934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e299372829934 : Closed e299372829934 ∧ code e299372829934 = 4697419341038 := by decide
theorem cert_e299372829934 : check e299372829934 [[.under],[.under,.left]] .chain = true := by decide
def e299372829942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e299372829942 : Closed e299372829942 ∧ code e299372829942 = 4697419341046 := by decide
theorem cert_e299372829942 : check e299372829942 [[.under],[.under,.left]] .chain = true := by decide
def e299372832494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e299372832494 : Closed e299372832494 ∧ code e299372832494 = 4697419343598 := by decide
theorem cert_e299372832494 : check e299372832494 [[.under],[.under,.left]] .chain = true := by decide
def e299372832686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e299372832686 : Closed e299372832686 ∧ code e299372832686 = 4697419343790 := by decide
theorem cert_e299372832686 : check e299372832686 [[.under],[.under,.left]] .chain = true := by decide
def e299372832698 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e299372832698 : Closed e299372832698 ∧ code e299372832698 = 4697419343802 := by decide
theorem cert_e299372832698 : check e299372832698 [[.under],[.under,.left]] .chain = true := by decide
def e299372833262 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e299372833262 : Closed e299372833262 ∧ code e299372833262 = 4697419344366 := by decide
theorem cert_e299372833262 : check e299372833262 [[.under],[.under,.left]] .chain = true := by decide
def e299372834414 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e299372834414 : Closed e299372834414 ∧ code e299372834414 = 4697419345518 := by decide
theorem cert_e299372834414 : check e299372834414 [[.under],[.under,.left]] .chain = true := by decide
def e299372834426 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e299372834426 : Closed e299372834426 ∧ code e299372834426 = 4697419345530 := by decide
theorem cert_e299372834426 : check e299372834426 [[.under],[.under,.left]] .chain = true := by decide
def e299372835694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e299372835694 : Closed e299372835694 ∧ code e299372835694 = 4697419346798 := by decide
theorem cert_e299372835694 : check e299372835694 [[.under],[.under,.left]] .chain = true := by decide
def e299372835702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e299372835702 : Closed e299372835702 ∧ code e299372835702 = 4697419346806 := by decide
theorem cert_e299372835702 : check e299372835702 [[.under],[.under,.left]] .chain = true := by decide
def e299372835758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e299372835758 : Closed e299372835758 ∧ code e299372835758 = 4697419346862 := by decide
theorem cert_e299372835758 : check e299372835758 [[.under],[.under,.left]] .chain = true := by decide
def e299372835770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e299372835770 : Closed e299372835770 ∧ code e299372835770 = 4697419346874 := by decide
theorem cert_e299372835770 : check e299372835770 [[.under],[.under,.left]] .chain = true := by decide
def e299372835798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e299372835798 : Closed e299372835798 ∧ code e299372835798 = 4697419346902 := by decide
theorem cert_e299372835798 : check e299372835798 [[.under],[.under,.left]] .chain = true := by decide
def e299372835802 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e299372835802 : Closed e299372835802 ∧ code e299372835802 = 4697419346906 := by decide
theorem cert_e299372835802 : check e299372835802 [[.under],[.under,.left]] .chain = true := by decide
def e299372836078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e299372836078 : Closed e299372836078 ∧ code e299372836078 = 4697419347182 := by decide
theorem cert_e299372836078 : check e299372836078 [[.under],[.under,.left]] .chain = true := by decide
def e299372836086 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e299372836086 : Closed e299372836086 ∧ code e299372836086 = 4697419347190 := by decide
theorem cert_e299372836086 : check e299372836086 [[.under],[.under,.left]] .chain = true := by decide
def e299372836462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e299372836462 : Closed e299372836462 ∧ code e299372836462 = 4697419347566 := by decide
theorem cert_e299372836462 : check e299372836462 [[.under],[.under,.left]] .chain = true := by decide
def e299372836474 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e299372836474 : Closed e299372836474 ∧ code e299372836474 = 4697419347578 := by decide
theorem cert_e299372836474 : check e299372836474 [[.under],[.under,.left]] .chain = true := by decide
def e299372836662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e299372836662 : Closed e299372836662 ∧ code e299372836662 = 4697419347766 := by decide
theorem cert_e299372836662 : check e299372836662 [[.under],[.under,.left]] .chain = true := by decide
def e299372836666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e299372836666 : Closed e299372836666 ∧ code e299372836666 = 4697419347770 := by decide
theorem cert_e299372836666 : check e299372836666 [[.under],[.under,.left]] .chain = true := by decide
def e299372841838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e299372841838 : Closed e299372841838 ∧ code e299372841838 = 4697419352942 := by decide
theorem cert_e299372841838 : check e299372841838 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372841846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e299372841846 : Closed e299372841846 ∧ code e299372841846 = 4697419352950 := by decide
theorem cert_e299372841846 : check e299372841846 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372841902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e299372841902 : Closed e299372841902 ∧ code e299372841902 = 4697419353006 := by decide
theorem cert_e299372841902 : check e299372841902 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372841914 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e299372841914 : Closed e299372841914 ∧ code e299372841914 = 4697419353018 := by decide
theorem cert_e299372841914 : check e299372841914 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372841942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e299372841942 : Closed e299372841942 ∧ code e299372841942 = 4697419353046 := by decide
theorem cert_e299372841942 : check e299372841942 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372841946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e299372841946 : Closed e299372841946 ∧ code e299372841946 = 4697419353050 := by decide
theorem cert_e299372841946 : check e299372841946 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372842222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e299372842222 : Closed e299372842222 ∧ code e299372842222 = 4697419353326 := by decide
theorem cert_e299372842222 : check e299372842222 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372842230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e299372842230 : Closed e299372842230 ∧ code e299372842230 = 4697419353334 := by decide
theorem cert_e299372842230 : check e299372842230 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372842606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e299372842606 : Closed e299372842606 ∧ code e299372842606 = 4697419353710 := by decide
theorem cert_e299372842606 : check e299372842606 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372842618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e299372842618 : Closed e299372842618 ∧ code e299372842618 = 4697419353722 := by decide
theorem cert_e299372842618 : check e299372842618 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372842806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e299372842806 : Closed e299372842806 ∧ code e299372842806 = 4697419353910 := by decide
theorem cert_e299372842806 : check e299372842806 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372842810 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e299372842810 : Closed e299372842810 ∧ code e299372842810 = 4697419353914 := by decide
theorem cert_e299372842810 : check e299372842810 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e299372850926 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e299372850926 : Closed e299372850926 ∧ code e299372850926 = 4697419362030 := by decide
theorem cert_e299372850926 : check e299372850926 [[.under],[.under,.left]] .chain = true := by decide
def e299372851054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e299372851054 : Closed e299372851054 ∧ code e299372851054 = 4697419362158 := by decide
theorem cert_e299372851054 : check e299372851054 [[.under],[.under,.left]] .chain = true := by decide
def e299372851062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e299372851062 : Closed e299372851062 ∧ code e299372851062 = 4697419362166 := by decide
theorem cert_e299372851062 : check e299372851062 [[.under],[.under,.left]] .chain = true := by decide
def e299372853742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e299372853742 : Closed e299372853742 ∧ code e299372853742 = 4697419364846 := by decide
theorem cert_e299372853742 : check e299372853742 [[.under],[.under,.left]] .chain = true := by decide
def e299372854510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e299372854510 : Closed e299372854510 ∧ code e299372854510 = 4697419365614 := by decide
theorem cert_e299372854510 : check e299372854510 [[.under],[.under,.left]] .chain = true := by decide
def e299372854518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e299372854518 : Closed e299372854518 ∧ code e299372854518 = 4697419365622 := by decide
theorem cert_e299372854518 : check e299372854518 [[.under],[.under,.left]] .chain = true := by decide
def e299372877550 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e299372877550 : Closed e299372877550 ∧ code e299372877550 = 4697419388654 := by decide
theorem cert_e299372877550 : check e299372877550 [[.under],[.under,.left]] .chain = true := by decide
def e299372877742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e299372877742 : Closed e299372877742 ∧ code e299372877742 = 4697419388846 := by decide
theorem cert_e299372877742 : check e299372877742 [[.under],[.under,.left]] .chain = true := by decide
def e299372877754 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e299372877754 : Closed e299372877754 ∧ code e299372877754 = 4697419388858 := by decide
theorem cert_e299372877754 : check e299372877754 [[.under],[.under,.left]] .chain = true := by decide
def e299372878318 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e299372878318 : Closed e299372878318 ∧ code e299372878318 = 4697419389422 := by decide
theorem cert_e299372878318 : check e299372878318 [[.under],[.under,.left]] .chain = true := by decide
def e299372879470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e299372879470 : Closed e299372879470 ∧ code e299372879470 = 4697419390574 := by decide
theorem cert_e299372879470 : check e299372879470 [[.under],[.under,.left]] .chain = true := by decide
def e299372879482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e299372879482 : Closed e299372879482 ∧ code e299372879482 = 4697419390586 := by decide
theorem cert_e299372879482 : check e299372879482 [[.under],[.under,.left]] .chain = true := by decide
def e299372890990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e299372890990 : Closed e299372890990 ∧ code e299372890990 = 4697419402094 := by decide
theorem cert_e299372890990 : check e299372890990 [[.under],[.under,.left]] .chain = true := by decide
def e299372890998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e299372890998 : Closed e299372890998 ∧ code e299372890998 = 4697419402102 := by decide
theorem cert_e299372890998 : check e299372890998 [[.under],[.under,.left]] .chain = true := by decide
def e299372891054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e299372891054 : Closed e299372891054 ∧ code e299372891054 = 4697419402158 := by decide
theorem cert_e299372891054 : check e299372891054 [[.under],[.under,.left]] .chain = true := by decide
def e299372891066 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e299372891066 : Closed e299372891066 ∧ code e299372891066 = 4697419402170 := by decide
theorem cert_e299372891066 : check e299372891066 [[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor42
