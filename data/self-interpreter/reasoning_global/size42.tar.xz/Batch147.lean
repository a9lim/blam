import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186410586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211186410586 : Closed e1211186410586 ∧ code e1211186410586 = 5609232921690 := by decide
theorem cert_e1211186410586 : check e1211186410586 [[],[]] .three = true := by decide
def e1211186410774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186410774 : Closed e1211186410774 ∧ code e1211186410774 = 5609232921878 := by decide
theorem cert_e1211186410774 : check e1211186410774 [[],[]] .three = true := by decide
def e1211186410850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186410850 : Closed e1211186410850 ∧ code e1211186410850 = 5609232921954 := by decide
theorem cert_e1211186410850 : check e1211186410850 [[],[]] .three = true := by decide
def e1211186410862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211186410862 : Closed e1211186410862 ∧ code e1211186410862 = 5609232921966 := by decide
theorem cert_e1211186410862 : check e1211186410862 [[],[]] .three = true := by decide
def e1211186410870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211186410870 : Closed e1211186410870 ∧ code e1211186410870 = 5609232921974 := by decide
theorem cert_e1211186410870 : check e1211186410870 [[],[]] .three = true := by decide
def e1211186410890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186410890 : Closed e1211186410890 ∧ code e1211186410890 = 5609232921994 := by decide
theorem cert_e1211186410890 : check e1211186410890 [[],[]] .three = true := by decide
def e1211186410914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186410914 : Closed e1211186410914 ∧ code e1211186410914 = 5609232922018 := by decide
theorem cert_e1211186410914 : check e1211186410914 [[],[]] .three = true := by decide
def e1211186410926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211186410926 : Closed e1211186410926 ∧ code e1211186410926 = 5609232922030 := by decide
theorem cert_e1211186410926 : check e1211186410926 [[],[]] .three = true := by decide
def e1211186410934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e1211186410934 : Closed e1211186410934 ∧ code e1211186410934 = 5609232922038 := by decide
theorem cert_e1211186410934 : check e1211186410934 [[],[]] .three = true := by decide
def e1211186410938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211186410938 : Closed e1211186410938 ∧ code e1211186410938 = 5609232922042 := by decide
theorem cert_e1211186410938 : check e1211186410938 [[],[]] .three = true := by decide
def e1211186410966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211186410966 : Closed e1211186410966 ∧ code e1211186410966 = 5609232922070 := by decide
theorem cert_e1211186410966 : check e1211186410966 [[],[]] .three = true := by decide
def e1211186410970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211186410970 : Closed e1211186410970 ∧ code e1211186410970 = 5609232922074 := by decide
theorem cert_e1211186410970 : check e1211186410970 [[],[]] .three = true := by decide
def e1211186411050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211186411050 : Closed e1211186411050 ∧ code e1211186411050 = 5609232922154 := by decide
theorem cert_e1211186411050 : check e1211186411050 [[],[]] .three = true := by decide
def e1211186411146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186411146 : Closed e1211186411146 ∧ code e1211186411146 = 5609232922250 := by decide
theorem cert_e1211186411146 : check e1211186411146 [[],[]] .three = true := by decide
def e1211186411170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186411170 : Closed e1211186411170 ∧ code e1211186411170 = 5609232922274 := by decide
theorem cert_e1211186411170 : check e1211186411170 [[],[]] .three = true := by decide
def e1211186411182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211186411182 : Closed e1211186411182 ∧ code e1211186411182 = 5609232922286 := by decide
theorem cert_e1211186411182 : check e1211186411182 [[],[]] .three = true := by decide
def e1211186411190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211186411190 : Closed e1211186411190 ∧ code e1211186411190 = 5609232922294 := by decide
theorem cert_e1211186411190 : check e1211186411190 [[],[]] .three = true := by decide
def e1211186411194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211186411194 : Closed e1211186411194 ∧ code e1211186411194 = 5609232922298 := by decide
theorem cert_e1211186411194 : check e1211186411194 [[],[]] .three = true := by decide
def e1211186411222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211186411222 : Closed e1211186411222 ∧ code e1211186411222 = 5609232922326 := by decide
theorem cert_e1211186411222 : check e1211186411222 [[],[]] .three = true := by decide
def e1211186411226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211186411226 : Closed e1211186411226 ∧ code e1211186411226 = 5609232922330 := by decide
theorem cert_e1211186411226 : check e1211186411226 [[],[]] .three = true := by decide
def e1211186411242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211186411242 : Closed e1211186411242 ∧ code e1211186411242 = 5609232922346 := by decide
theorem cert_e1211186411242 : check e1211186411242 [[],[]] .three = true := by decide
def e1211186411350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211186411350 : Closed e1211186411350 ∧ code e1211186411350 = 5609232922454 := by decide
theorem cert_e1211186411350 : check e1211186411350 [[],[]] .three = true := by decide
def e1211186411354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211186411354 : Closed e1211186411354 ∧ code e1211186411354 = 5609232922458 := by decide
theorem cert_e1211186411354 : check e1211186411354 [[],[]] .three = true := by decide
def e1211186411370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211186411370 : Closed e1211186411370 ∧ code e1211186411370 = 5609232922474 := by decide
theorem cert_e1211186411370 : check e1211186411370 [[],[]] .three = true := by decide
def e1211186417374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 3)))))))
theorem wire_e1211186417374 : Closed e1211186417374 ∧ code e1211186417374 = 5609232928478 := by decide
theorem cert_e1211186417374 : check e1211186417374 [[],[]] .three = true := by decide
def e1211186417398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 3)) (.var 1)))))))
theorem wire_e1211186417398 : Closed e1211186417398 ∧ code e1211186417398 = 5609232928502 := by decide
theorem cert_e1211186417398 : check e1211186417398 [[],[]] .three = true := by decide
def e1211186417502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 3)))))))
theorem wire_e1211186417502 : Closed e1211186417502 ∧ code e1211186417502 = 5609232928606 := by decide
theorem cert_e1211186417502 : check e1211186417502 [[],[]] .three = true := by decide
def e1211186417518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186417518 : Closed e1211186417518 ∧ code e1211186417518 = 5609232928622 := by decide
theorem cert_e1211186417518 : check e1211186417518 [[],[]] .smaller = true := by decide
def e1211186417526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186417526 : Closed e1211186417526 ∧ code e1211186417526 = 5609232928630 := by decide
theorem cert_e1211186417526 : check e1211186417526 [[],[]] .smaller = true := by decide
def e1211186417530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 3)) (.var 0)))))))
theorem wire_e1211186417530 : Closed e1211186417530 ∧ code e1211186417530 = 5609232928634 := by decide
theorem cert_e1211186417530 : check e1211186417530 [[],[]] .three = true := by decide
def e1211186417590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 1)))))))
theorem wire_e1211186417590 : Closed e1211186417590 ∧ code e1211186417590 = 5609232928694 := by decide
theorem cert_e1211186417590 : check e1211186417590 [[],[]] .smaller = true := by decide
def e1211186417622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186417622 : Closed e1211186417622 ∧ code e1211186417622 = 5609232928726 := by decide
theorem cert_e1211186417622 : check e1211186417622 [[],[]] .three = true := by decide
def e1211186417626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186417626 : Closed e1211186417626 ∧ code e1211186417626 = 5609232928730 := by decide
theorem cert_e1211186417626 : check e1211186417626 [[],[]] .three = true := by decide
def e1211186420446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 3)))))))
theorem wire_e1211186420446 : Closed e1211186420446 ∧ code e1211186420446 = 5609232931550 := by decide
theorem cert_e1211186420446 : check e1211186420446 [[],[]] .three = true := by decide
def e1211186420470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 3)) (.var 1)))))))
theorem wire_e1211186420470 : Closed e1211186420470 ∧ code e1211186420470 = 5609232931574 := by decide
theorem cert_e1211186420470 : check e1211186420470 [[],[]] .three = true := by decide
def e1211186420590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186420590 : Closed e1211186420590 ∧ code e1211186420590 = 5609232931694 := by decide
theorem cert_e1211186420590 : check e1211186420590 [[],[]] .smaller = true := by decide
def e1211186420598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186420598 : Closed e1211186420598 ∧ code e1211186420598 = 5609232931702 := by decide
theorem cert_e1211186420598 : check e1211186420598 [[],[]] .smaller = true := by decide
def e1211186420654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186420654 : Closed e1211186420654 ∧ code e1211186420654 = 5609232931758 := by decide
theorem cert_e1211186420654 : check e1211186420654 [[],[]] .smaller = true := by decide
def e1211186420666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186420666 : Closed e1211186420666 ∧ code e1211186420666 = 5609232931770 := by decide
theorem cert_e1211186420666 : check e1211186420666 [[],[]] .smaller = true := by decide
def e1211186420694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186420694 : Closed e1211186420694 ∧ code e1211186420694 = 5609232931798 := by decide
theorem cert_e1211186420694 : check e1211186420694 [[],[]] .smaller = true := by decide
def e1211186420698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186420698 : Closed e1211186420698 ∧ code e1211186420698 = 5609232931802 := by decide
theorem cert_e1211186420698 : check e1211186420698 [[],[]] .smaller = true := by decide
def e1211186421102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186421102 : Closed e1211186421102 ∧ code e1211186421102 = 5609232932206 := by decide
theorem cert_e1211186421102 : check e1211186421102 [[],[]] .smaller = true := by decide
def e1211186421110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186421110 : Closed e1211186421110 ∧ code e1211186421110 = 5609232932214 := by decide
theorem cert_e1211186421110 : check e1211186421110 [[],[]] .smaller = true := by decide
def e1211186421422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186421422 : Closed e1211186421422 ∧ code e1211186421422 = 5609232932526 := by decide
theorem cert_e1211186421422 : check e1211186421422 [[],[]] .smaller = true := by decide
def e1211186421434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186421434 : Closed e1211186421434 ∧ code e1211186421434 = 5609232932538 := by decide
theorem cert_e1211186421434 : check e1211186421434 [[],[]] .smaller = true := by decide
def e1211186421590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186421590 : Closed e1211186421590 ∧ code e1211186421590 = 5609232932694 := by decide
theorem cert_e1211186421590 : check e1211186421590 [[],[]] .smaller = true := by decide
def e1211186421594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186421594 : Closed e1211186421594 ∧ code e1211186421594 = 5609232932698 := by decide
theorem cert_e1211186421594 : check e1211186421594 [[],[]] .smaller = true := by decide
def e1211186423518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e1211186423518 : Closed e1211186423518 ∧ code e1211186423518 = 5609232934622 := by decide
theorem cert_e1211186423518 : check e1211186423518 [[],[]] .three = true := by decide
def e1211186423542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e1211186423542 : Closed e1211186423542 ∧ code e1211186423542 = 5609232934646 := by decide
theorem cert_e1211186423542 : check e1211186423542 [[],[]] .three = true := by decide
def e1211186423646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e1211186423646 : Closed e1211186423646 ∧ code e1211186423646 = 5609232934750 := by decide
theorem cert_e1211186423646 : check e1211186423646 [[],[]] .three = true := by decide
def e1211186423662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e1211186423662 : Closed e1211186423662 ∧ code e1211186423662 = 5609232934766 := by decide
theorem cert_e1211186423662 : check e1211186423662 [[],[]] .smaller = true := by decide
def e1211186423670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e1211186423670 : Closed e1211186423670 ∧ code e1211186423670 = 5609232934774 := by decide
theorem cert_e1211186423670 : check e1211186423670 [[],[]] .smaller = true := by decide
def e1211186423674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e1211186423674 : Closed e1211186423674 ∧ code e1211186423674 = 5609232934778 := by decide
theorem cert_e1211186423674 : check e1211186423674 [[],[]] .three = true := by decide
def e1211186423734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e1211186423734 : Closed e1211186423734 ∧ code e1211186423734 = 5609232934838 := by decide
theorem cert_e1211186423734 : check e1211186423734 [[],[]] .smaller = true := by decide
def e1211186423766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e1211186423766 : Closed e1211186423766 ∧ code e1211186423766 = 5609232934870 := by decide
theorem cert_e1211186423766 : check e1211186423766 [[],[]] .three = true := by decide
def e1211186423770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e1211186423770 : Closed e1211186423770 ∧ code e1211186423770 = 5609232934874 := by decide
theorem cert_e1211186423770 : check e1211186423770 [[],[]] .three = true := by decide
def e1211186424286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186424286 : Closed e1211186424286 ∧ code e1211186424286 = 5609232935390 := by decide
theorem cert_e1211186424286 : check e1211186424286 [[],[]] .three = true := by decide
def e1211186424310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186424310 : Closed e1211186424310 ∧ code e1211186424310 = 5609232935414 := by decide
theorem cert_e1211186424310 : check e1211186424310 [[],[]] .three = true := by decide
def e1211186425054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186425054 : Closed e1211186425054 ∧ code e1211186425054 = 5609232936158 := by decide
theorem cert_e1211186425054 : check e1211186425054 [[],[]] .three = true := by decide
def e1211186425070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186425070 : Closed e1211186425070 ∧ code e1211186425070 = 5609232936174 := by decide
theorem cert_e1211186425070 : check e1211186425070 [[],[]] .smaller = true := by decide
def e1211186425078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186425078 : Closed e1211186425078 ∧ code e1211186425078 = 5609232936182 := by decide
theorem cert_e1211186425078 : check e1211186425078 [[],[]] .smaller = true := by decide
def e1211186425082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186425082 : Closed e1211186425082 ∧ code e1211186425082 = 5609232936186 := by decide
theorem cert_e1211186425082 : check e1211186425082 [[],[]] .three = true := by decide
def e1211186425462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186425462 : Closed e1211186425462 ∧ code e1211186425462 = 5609232936566 := by decide
theorem cert_e1211186425462 : check e1211186425462 [[],[]] .smaller = true := by decide
def e1211186425654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186425654 : Closed e1211186425654 ∧ code e1211186425654 = 5609232936758 := by decide
theorem cert_e1211186425654 : check e1211186425654 [[],[]] .three = true := by decide
def e1211186425658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186425658 : Closed e1211186425658 ∧ code e1211186425658 = 5609232936762 := by decide
theorem cert_e1211186425658 : check e1211186425658 [[],[]] .three = true := by decide
def e1211186426334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 3)))))))
theorem wire_e1211186426334 : Closed e1211186426334 ∧ code e1211186426334 = 5609232937438 := by decide
theorem cert_e1211186426334 : check e1211186426334 [[],[]] .three = true := by decide
def e1211186426358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 4))) (.var 1)))))))
theorem wire_e1211186426358 : Closed e1211186426358 ∧ code e1211186426358 = 5609232937462 := by decide
theorem cert_e1211186426358 : check e1211186426358 [[],[]] .three = true := by decide
def e1211186426734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211186426734 : Closed e1211186426734 ∧ code e1211186426734 = 5609232937838 := by decide
theorem cert_e1211186426734 : check e1211186426734 [[],[]] .smaller = true := by decide
def e1211186426742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211186426742 : Closed e1211186426742 ∧ code e1211186426742 = 5609232937846 := by decide
theorem cert_e1211186426742 : check e1211186426742 [[],[]] .smaller = true := by decide
def e1211186426798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211186426798 : Closed e1211186426798 ∧ code e1211186426798 = 5609232937902 := by decide
theorem cert_e1211186426798 : check e1211186426798 [[],[]] .smaller = true := by decide
def e1211186426810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211186426810 : Closed e1211186426810 ∧ code e1211186426810 = 5609232937914 := by decide
theorem cert_e1211186426810 : check e1211186426810 [[],[]] .smaller = true := by decide
def e1211186426838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211186426838 : Closed e1211186426838 ∧ code e1211186426838 = 5609232937942 := by decide
theorem cert_e1211186426838 : check e1211186426838 [[],[]] .smaller = true := by decide
def e1211186426842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211186426842 : Closed e1211186426842 ∧ code e1211186426842 = 5609232937946 := by decide
theorem cert_e1211186426842 : check e1211186426842 [[],[]] .smaller = true := by decide
def e1211186427118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186427118 : Closed e1211186427118 ∧ code e1211186427118 = 5609232938222 := by decide
theorem cert_e1211186427118 : check e1211186427118 [[],[]] .smaller = true := by decide
def e1211186427126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186427126 : Closed e1211186427126 ∧ code e1211186427126 = 5609232938230 := by decide
theorem cert_e1211186427126 : check e1211186427126 [[],[]] .smaller = true := by decide
def e1211186427454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 4))))))))
theorem wire_e1211186427454 : Closed e1211186427454 ∧ code e1211186427454 = 5609232938558 := by decide
theorem cert_e1211186427454 : check e1211186427454 [[],[]] .three = true := by decide
def e1211186427502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186427502 : Closed e1211186427502 ∧ code e1211186427502 = 5609232938606 := by decide
theorem cert_e1211186427502 : check e1211186427502 [[],[]] .smaller = true := by decide
def e1211186427514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186427514 : Closed e1211186427514 ∧ code e1211186427514 = 5609232938618 := by decide
theorem cert_e1211186427514 : check e1211186427514 [[],[]] .smaller = true := by decide
def e1211186427702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186427702 : Closed e1211186427702 ∧ code e1211186427702 = 5609232938806 := by decide
theorem cert_e1211186427702 : check e1211186427702 [[],[]] .smaller = true := by decide
def e1211186427706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186427706 : Closed e1211186427706 ∧ code e1211186427706 = 5609232938810 := by decide
theorem cert_e1211186427706 : check e1211186427706 [[],[]] .smaller = true := by decide
def e1211186427790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.lam (.var 2))))))))
theorem wire_e1211186427790 : Closed e1211186427790 ∧ code e1211186427790 = 5609232938894 := by decide
theorem cert_e1211186427790 : check e1211186427790 [[],[]] .three = true := by decide
def e1211186428126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e1211186428126 : Closed e1211186428126 ∧ code e1211186428126 = 5609232939230 := by decide
theorem cert_e1211186428126 : check e1211186428126 [[],[]] .three = true := by decide
def e1211186428142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211186428142 : Closed e1211186428142 ∧ code e1211186428142 = 5609232939246 := by decide
theorem cert_e1211186428142 : check e1211186428142 [[],[]] .smaller = true := by decide
def e1211186428150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211186428150 : Closed e1211186428150 ∧ code e1211186428150 = 5609232939254 := by decide
theorem cert_e1211186428150 : check e1211186428150 [[],[]] .smaller = true := by decide
def e1211186428154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e1211186428154 : Closed e1211186428154 ∧ code e1211186428154 = 5609232939258 := by decide
theorem cert_e1211186428154 : check e1211186428154 [[],[]] .three = true := by decide
def e1211186428334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211186428334 : Closed e1211186428334 ∧ code e1211186428334 = 5609232939438 := by decide
theorem cert_e1211186428334 : check e1211186428334 [[],[]] .smaller = true := by decide
def e1211186428346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211186428346 : Closed e1211186428346 ∧ code e1211186428346 = 5609232939450 := by decide
theorem cert_e1211186428346 : check e1211186428346 [[],[]] .smaller = true := by decide
def e1211186428394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211186428394 : Closed e1211186428394 ∧ code e1211186428394 = 5609232939498 := by decide
theorem cert_e1211186428394 : check e1211186428394 [[],[]] .smaller = true := by decide
def e1211186428478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e1211186428478 : Closed e1211186428478 ∧ code e1211186428478 = 5609232939582 := by decide
theorem cert_e1211186428478 : check e1211186428478 [[],[]] .three = true := by decide
def e1211186428526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186428526 : Closed e1211186428526 ∧ code e1211186428526 = 5609232939630 := by decide
theorem cert_e1211186428526 : check e1211186428526 [[],[]] .smaller = true := by decide
def e1211186428538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186428538 : Closed e1211186428538 ∧ code e1211186428538 = 5609232939642 := by decide
theorem cert_e1211186428538 : check e1211186428538 [[],[]] .smaller = true := by decide
def e1211186428702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211186428702 : Closed e1211186428702 ∧ code e1211186428702 = 5609232939806 := by decide
theorem cert_e1211186428702 : check e1211186428702 [[],[]] .smaller = true := by decide
def e1211186428814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211186428814 : Closed e1211186428814 ∧ code e1211186428814 = 5609232939918 := by decide
theorem cert_e1211186428814 : check e1211186428814 [[],[]] .smaller = true := by decide
def e1211186428826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186428826 : Closed e1211186428826 ∧ code e1211186428826 = 5609232939930 := by decide
theorem cert_e1211186428826 : check e1211186428826 [[],[]] .smaller = true := by decide
def e1211186428870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e1211186428870 : Closed e1211186428870 ∧ code e1211186428870 = 5609232939974 := by decide
theorem cert_e1211186428870 : check e1211186428870 [[],[]] .three = true := by decide
def e1211186428894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 3)))))))
theorem wire_e1211186428894 : Closed e1211186428894 ∧ code e1211186428894 = 5609232939998 := by decide
theorem cert_e1211186428894 : check e1211186428894 [[],[]] .three = true := by decide
def e1211186429046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211186429046 : Closed e1211186429046 ∧ code e1211186429046 = 5609232940150 := by decide
theorem cert_e1211186429046 : check e1211186429046 [[],[]] .smaller = true := by decide
def e1211186429142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211186429142 : Closed e1211186429142 ∧ code e1211186429142 = 5609232940246 := by decide
theorem cert_e1211186429142 : check e1211186429142 [[],[]] .smaller = true := by decide
def e1211186429146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211186429146 : Closed e1211186429146 ∧ code e1211186429146 = 5609232940250 := by decide
theorem cert_e1211186429146 : check e1211186429146 [[],[]] .smaller = true := by decide
def e1211186429162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211186429162 : Closed e1211186429162 ∧ code e1211186429162 = 5609232940266 := by decide
theorem cert_e1211186429162 : check e1211186429162 [[],[]] .smaller = true := by decide
def e1211186429238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186429238 : Closed e1211186429238 ∧ code e1211186429238 = 5609232940342 := by decide
theorem cert_e1211186429238 : check e1211186429238 [[],[]] .smaller = true := by decide
def e1211186429242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186429242 : Closed e1211186429242 ∧ code e1211186429242 = 5609232940346 := by decide
theorem cert_e1211186429242 : check e1211186429242 [[],[]] .smaller = true := by decide
def e1211186429326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211186429326 : Closed e1211186429326 ∧ code e1211186429326 = 5609232940430 := by decide
theorem cert_e1211186429326 : check e1211186429326 [[],[]] .smaller = true := by decide
def e1211186429338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186429338 : Closed e1211186429338 ∧ code e1211186429338 = 5609232940442 := by decide
theorem cert_e1211186429338 : check e1211186429338 [[],[]] .smaller = true := by decide
def e1211186429406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 3)))))))
theorem wire_e1211186429406 : Closed e1211186429406 ∧ code e1211186429406 = 5609232940510 := by decide
theorem cert_e1211186429406 : check e1211186429406 [[],[]] .three = true := by decide
def e1211186429422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 3)) (.var 2)))))))
theorem wire_e1211186429422 : Closed e1211186429422 ∧ code e1211186429422 = 5609232940526 := by decide
theorem cert_e1211186429422 : check e1211186429422 [[],[]] .three = true := by decide
def e1211186429494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186429494 : Closed e1211186429494 ∧ code e1211186429494 = 5609232940598 := by decide
theorem cert_e1211186429494 : check e1211186429494 [[],[]] .three = true := by decide
def e1211186429498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186429498 : Closed e1211186429498 ∧ code e1211186429498 = 5609232940602 := by decide
theorem cert_e1211186429498 : check e1211186429498 [[],[]] .three = true := by decide
def e1211186429582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186429582 : Closed e1211186429582 ∧ code e1211186429582 = 5609232940686 := by decide
theorem cert_e1211186429582 : check e1211186429582 [[],[]] .three = true := by decide
def e1211186429638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186429638 : Closed e1211186429638 ∧ code e1211186429638 = 5609232940742 := by decide
theorem cert_e1211186429638 : check e1211186429638 [[],[]] .three = true := by decide
def e1211186429662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 3)))))))
theorem wire_e1211186429662 : Closed e1211186429662 ∧ code e1211186429662 = 5609232940766 := by decide
theorem cert_e1211186429662 : check e1211186429662 [[],[]] .three = true := by decide
def e1211186429678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 2)) (.var 2)))))))
theorem wire_e1211186429678 : Closed e1211186429678 ∧ code e1211186429678 = 5609232940782 := by decide
theorem cert_e1211186429678 : check e1211186429678 [[],[]] .three = true := by decide
def e1211186429686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 3)) (.var 1)))))))
theorem wire_e1211186429686 : Closed e1211186429686 ∧ code e1211186429686 = 5609232940790 := by decide
theorem cert_e1211186429686 : check e1211186429686 [[],[]] .three = true := by decide
def e1211186438878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 3)))))))
theorem wire_e1211186438878 : Closed e1211186438878 ∧ code e1211186438878 = 5609232949982 := by decide
theorem cert_e1211186438878 : check e1211186438878 [[],[]] .three = true := by decide
def e1211186438902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 3)) (.var 1)))))))
theorem wire_e1211186438902 : Closed e1211186438902 ∧ code e1211186438902 = 5609232950006 := by decide
theorem cert_e1211186438902 : check e1211186438902 [[],[]] .three = true := by decide
def e1211186439022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186439022 : Closed e1211186439022 ∧ code e1211186439022 = 5609232950126 := by decide
theorem cert_e1211186439022 : check e1211186439022 [[],[]] .smaller = true := by decide
def e1211186439030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186439030 : Closed e1211186439030 ∧ code e1211186439030 = 5609232950134 := by decide
theorem cert_e1211186439030 : check e1211186439030 [[],[]] .smaller = true := by decide
def e1211186439086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186439086 : Closed e1211186439086 ∧ code e1211186439086 = 5609232950190 := by decide
theorem cert_e1211186439086 : check e1211186439086 [[],[]] .smaller = true := by decide
def e1211186439098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186439098 : Closed e1211186439098 ∧ code e1211186439098 = 5609232950202 := by decide
theorem cert_e1211186439098 : check e1211186439098 [[],[]] .smaller = true := by decide
def e1211186439126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186439126 : Closed e1211186439126 ∧ code e1211186439126 = 5609232950230 := by decide
theorem cert_e1211186439126 : check e1211186439126 [[],[]] .smaller = true := by decide
def e1211186439130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186439130 : Closed e1211186439130 ∧ code e1211186439130 = 5609232950234 := by decide
theorem cert_e1211186439130 : check e1211186439130 [[],[]] .smaller = true := by decide
def e1211186440430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211186440430 : Closed e1211186440430 ∧ code e1211186440430 = 5609232951534 := by decide
theorem cert_e1211186440430 : check e1211186440430 [[],[]] .smaller = true := by decide
def e1211186440438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211186440438 : Closed e1211186440438 ∧ code e1211186440438 = 5609232951542 := by decide
theorem cert_e1211186440438 : check e1211186440438 [[],[]] .smaller = true := by decide
def e1211186440990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211186440990 : Closed e1211186440990 ∧ code e1211186440990 = 5609232952094 := by decide
theorem cert_e1211186440990 : check e1211186440990 [[],[]] .smaller = true := by decide
def e1211186441102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211186441102 : Closed e1211186441102 ∧ code e1211186441102 = 5609232952206 := by decide
theorem cert_e1211186441102 : check e1211186441102 [[],[]] .smaller = true := by decide
def e1211186441310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e1211186441310 : Closed e1211186441310 ∧ code e1211186441310 = 5609232952414 := by decide
theorem cert_e1211186441310 : check e1211186441310 [[],[]] .three = true := by decide
def e1211186441326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186441326 : Closed e1211186441326 ∧ code e1211186441326 = 5609232952430 := by decide
theorem cert_e1211186441326 : check e1211186441326 [[],[]] .smaller = true := by decide
def e1211186441338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186441338 : Closed e1211186441338 ∧ code e1211186441338 = 5609232952442 := by decide
theorem cert_e1211186441338 : check e1211186441338 [[],[]] .smaller = true := by decide
def e1211186441502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186441502 : Closed e1211186441502 ∧ code e1211186441502 = 5609232952606 := by decide
theorem cert_e1211186441502 : check e1211186441502 [[],[]] .smaller = true := by decide
def e1211186441670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186441670 : Closed e1211186441670 ∧ code e1211186441670 = 5609232952774 := by decide
theorem cert_e1211186441670 : check e1211186441670 [[],[]] .smaller = true := by decide
def e1211186441694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e1211186441694 : Closed e1211186441694 ∧ code e1211186441694 = 5609232952798 := by decide
theorem cert_e1211186441694 : check e1211186441694 [[],[]] .three = true := by decide
def e1211186441698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e1211186441698 : Closed e1211186441698 ∧ code e1211186441698 = 5609232952802 := by decide
theorem cert_e1211186441698 : check e1211186441698 [[],[]] .three = true := by decide
def e1211186441710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e1211186441710 : Closed e1211186441710 ∧ code e1211186441710 = 5609232952814 := by decide
theorem cert_e1211186441710 : check e1211186441710 [[],[]] .three = true := by decide
def e1211186441782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186441782 : Closed e1211186441782 ∧ code e1211186441782 = 5609232952886 := by decide
theorem cert_e1211186441782 : check e1211186441782 [[],[]] .smaller = true := by decide
def e1211186441786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186441786 : Closed e1211186441786 ∧ code e1211186441786 = 5609232952890 := by decide
theorem cert_e1211186441786 : check e1211186441786 [[],[]] .smaller = true := by decide
def e1211186441870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186441870 : Closed e1211186441870 ∧ code e1211186441870 = 5609232952974 := by decide
theorem cert_e1211186441870 : check e1211186441870 [[],[]] .smaller = true := by decide
def e1211186441926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186441926 : Closed e1211186441926 ∧ code e1211186441926 = 5609232953030 := by decide
theorem cert_e1211186441926 : check e1211186441926 [[],[]] .smaller = true := by decide
def e1211186441950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e1211186441950 : Closed e1211186441950 ∧ code e1211186441950 = 5609232953054 := by decide
theorem cert_e1211186441950 : check e1211186441950 [[],[]] .three = true := by decide
def e1211186441974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e1211186441974 : Closed e1211186441974 ∧ code e1211186441974 = 5609232953078 := by decide
theorem cert_e1211186441974 : check e1211186441974 [[],[]] .three = true := by decide
def e1211186442006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186442006 : Closed e1211186442006 ∧ code e1211186442006 = 5609232953110 := by decide
theorem cert_e1211186442006 : check e1211186442006 [[],[]] .three = true := by decide
def e1211186442082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186442082 : Closed e1211186442082 ∧ code e1211186442082 = 5609232953186 := by decide
theorem cert_e1211186442082 : check e1211186442082 [[],[]] .three = true := by decide
def e1211186442094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e1211186442094 : Closed e1211186442094 ∧ code e1211186442094 = 5609232953198 := by decide
theorem cert_e1211186442094 : check e1211186442094 [[],[]] .three = true := by decide
def e1211186442102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e1211186442102 : Closed e1211186442102 ∧ code e1211186442102 = 5609232953206 := by decide
theorem cert_e1211186442102 : check e1211186442102 [[],[]] .three = true := by decide
def e1211186442590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e1211186442590 : Closed e1211186442590 ∧ code e1211186442590 = 5609232953694 := by decide
theorem cert_e1211186442590 : check e1211186442590 [[],[]] .three = true := by decide
def e1211186442606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186442606 : Closed e1211186442606 ∧ code e1211186442606 = 5609232953710 := by decide
theorem cert_e1211186442606 : check e1211186442606 [[],[]] .smaller = true := by decide
def e1211186442614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186442614 : Closed e1211186442614 ∧ code e1211186442614 = 5609232953718 := by decide
theorem cert_e1211186442614 : check e1211186442614 [[],[]] .smaller = true := by decide
def e1211186442618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e1211186442618 : Closed e1211186442618 ∧ code e1211186442618 = 5609232953722 := by decide
theorem cert_e1211186442618 : check e1211186442618 [[],[]] .three = true := by decide
def e1211186442670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186442670 : Closed e1211186442670 ∧ code e1211186442670 = 5609232953774 := by decide
theorem cert_e1211186442670 : check e1211186442670 [[],[]] .smaller = true := by decide
def e1211186442682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186442682 : Closed e1211186442682 ∧ code e1211186442682 = 5609232953786 := by decide
theorem cert_e1211186442682 : check e1211186442682 [[],[]] .smaller = true := by decide
def e1211186442730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186442730 : Closed e1211186442730 ∧ code e1211186442730 = 5609232953834 := by decide
theorem cert_e1211186442730 : check e1211186442730 [[],[]] .smaller = true := by decide
def e1211186443358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e1211186443358 : Closed e1211186443358 ∧ code e1211186443358 = 5609232954462 := by decide
theorem cert_e1211186443358 : check e1211186443358 [[],[]] .three = true := by decide
def e1211186443374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186443374 : Closed e1211186443374 ∧ code e1211186443374 = 5609232954478 := by decide
theorem cert_e1211186443374 : check e1211186443374 [[],[]] .smaller = true := by decide
def e1211186443386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186443386 : Closed e1211186443386 ∧ code e1211186443386 = 5609232954490 := by decide
theorem cert_e1211186443386 : check e1211186443386 [[],[]] .smaller = true := by decide
def e1211186443550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186443550 : Closed e1211186443550 ∧ code e1211186443550 = 5609232954654 := by decide
theorem cert_e1211186443550 : check e1211186443550 [[],[]] .smaller = true := by decide
def e1211186443718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186443718 : Closed e1211186443718 ∧ code e1211186443718 = 5609232954822 := by decide
theorem cert_e1211186443718 : check e1211186443718 [[],[]] .smaller = true := by decide
def e1211186443742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e1211186443742 : Closed e1211186443742 ∧ code e1211186443742 = 5609232954846 := by decide
theorem cert_e1211186443742 : check e1211186443742 [[],[]] .three = true := by decide
def e1211186443746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e1211186443746 : Closed e1211186443746 ∧ code e1211186443746 = 5609232954850 := by decide
theorem cert_e1211186443746 : check e1211186443746 [[],[]] .three = true := by decide
def e1211186443758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e1211186443758 : Closed e1211186443758 ∧ code e1211186443758 = 5609232954862 := by decide
theorem cert_e1211186443758 : check e1211186443758 [[],[]] .three = true := by decide
def e1211186443822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211186443822 : Closed e1211186443822 ∧ code e1211186443822 = 5609232954926 := by decide
theorem cert_e1211186443822 : check e1211186443822 [[],[]] .smaller = true := by decide
def e1211186443998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e1211186443998 : Closed e1211186443998 ∧ code e1211186443998 = 5609232955102 := by decide
theorem cert_e1211186443998 : check e1211186443998 [[],[]] .three = true := by decide
end Blc.Floor42
