import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211277424058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e1211277424058 : Closed e1211277424058 ∧ code e1211277424058 = 5609323935162 := by decide
private def t_e1211277424058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0)))))
theorem cert_e1211277424058 : ¬ IsSelfInterpreter e1211277424058 :=
  wSource (t := t_e1211277424058) (replay_sound (ps := []) (t := e1211277424058) (by decide)) (by decide)
def e1211277424090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e1211277424090 : Closed e1211277424090 ∧ code e1211277424090 = 5609323935194 := by decide
private def t_e1211277424090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0)))))
theorem cert_e1211277424090 : ¬ IsSelfInterpreter e1211277424090 :=
  wSource (t := t_e1211277424090) (replay_sound (ps := []) (t := e1211277424090) (by decide)) (by decide)
def e1211277424314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1211277424314 : Closed e1211277424314 ∧ code e1211277424314 = 5609323935418 := by decide
theorem cert_e1211277424314 : check e1211277424314 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211277424362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1211277424362 : Closed e1211277424362 ∧ code e1211277424362 = 5609323935466 := by decide
theorem cert_e1211277424362 : check e1211277424362 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211277424474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1211277424474 : Closed e1211277424474 ∧ code e1211277424474 = 5609323935578 := by decide
private def t_e1211277424474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)))))
theorem cert_e1211277424474 : ¬ IsSelfInterpreter e1211277424474 :=
  wSource (t := t_e1211277424474) (replay_sound (ps := []) (t := e1211277424474) (by decide)) (by decide)
def e1211277424490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1211277424490 : Closed e1211277424490 ∧ code e1211277424490 = 5609323935594 := by decide
private def t_e1211277424490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 0)))))
theorem cert_e1211277424490 : ¬ IsSelfInterpreter e1211277424490 :=
  wSource (t := t_e1211277424490) (replay_sound (ps := []) (t := e1211277424490) (by decide)) (by decide)
def e1211277425338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e1211277425338 : Closed e1211277425338 ∧ code e1211277425338 = 5609323936442 := by decide
theorem cert_e1211277425338 : check e1211277425338 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277425386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e1211277425386 : Closed e1211277425386 ∧ code e1211277425386 = 5609323936490 := by decide
theorem cert_e1211277425386 : check e1211277425386 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277425578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.var 0)))))
theorem wire_e1211277425578 : Closed e1211277425578 ∧ code e1211277425578 = 5609323936682 := by decide
theorem cert_e1211277425578 : check e1211277425578 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277426010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e1211277426010 : Closed e1211277426010 ∧ code e1211277426010 = 5609323937114 := by decide
private def t_e1211277426010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 0)))))
theorem cert_e1211277426010 : ¬ IsSelfInterpreter e1211277426010 :=
  wSource (t := t_e1211277426010) (replay_sound (ps := []) (t := e1211277426010) (by decide)) (by decide)
def e1211277426026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e1211277426026 : Closed e1211277426026 ∧ code e1211277426026 = 5609323937130 := by decide
private def t_e1211277426026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 0)))))
theorem cert_e1211277426026 : ¬ IsSelfInterpreter e1211277426026 :=
  wSource (t := t_e1211277426026) (replay_sound (ps := []) (t := e1211277426026) (by decide)) (by decide)
def e1211277426090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.var 0)))))
theorem wire_e1211277426090 : Closed e1211277426090 ∧ code e1211277426090 = 5609323937194 := by decide
theorem cert_e1211277426090 : check e1211277426090 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277428598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 1)))))
theorem wire_e1211277428598 : Closed e1211277428598 ∧ code e1211277428598 = 5609323939702 := by decide
theorem cert_e1211277428598 : check e1211277428598 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211277428662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 1)))))
theorem wire_e1211277428662 : Closed e1211277428662 ∧ code e1211277428662 = 5609323939766 := by decide
def e1211277430202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e1211277430202 : Closed e1211277430202 ∧ code e1211277430202 = 5609323941306 := by decide
theorem cert_e1211277430202 : check e1211277430202 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211277430234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)))))
theorem wire_e1211277430234 : Closed e1211277430234 ∧ code e1211277430234 = 5609323941338 := by decide
private def t_e1211277430234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)))))
theorem cert_e1211277430234 : ¬ IsSelfInterpreter e1211277430234 :=
  wSource (t := t_e1211277430234) (replay_sound (ps := []) (t := e1211277430234) (by decide)) (by decide)
def e1211277430458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.var 0)))))
theorem wire_e1211277430458 : Closed e1211277430458 ∧ code e1211277430458 = 5609323941562 := by decide
theorem cert_e1211277430458 : check e1211277430458 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277430506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e1211277430506 : Closed e1211277430506 ∧ code e1211277430506 = 5609323941610 := by decide
theorem cert_e1211277430506 : check e1211277430506 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277430618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 0)))))
theorem wire_e1211277430618 : Closed e1211277430618 ∧ code e1211277430618 = 5609323941722 := by decide
private def t_e1211277430618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 0)))))
theorem cert_e1211277430618 : ¬ IsSelfInterpreter e1211277430618 :=
  wSource (t := t_e1211277430618) (replay_sound (ps := []) (t := e1211277430618) (by decide)) (by decide)
def e1211277430634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.var 0)))))
theorem wire_e1211277430634 : Closed e1211277430634 ∧ code e1211277430634 = 5609323941738 := by decide
theorem cert_e1211277430634 : check e1211277430634 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211277431738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e1211277431738 : Closed e1211277431738 ∧ code e1211277431738 = 5609323942842 := by decide
private def t_e1211277431738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem cert_e1211277431738 : ¬ IsSelfInterpreter e1211277431738 :=
  wSource (t := t_e1211277431738) (replay_sound (ps := []) (t := e1211277431738) (by decide)) (by decide)
def e1211277431770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e1211277431770 : Closed e1211277431770 ∧ code e1211277431770 = 5609323942874 := by decide
private def t_e1211277431770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem cert_e1211277431770 : ¬ IsSelfInterpreter e1211277431770 :=
  wSource (t := t_e1211277431770) (replay_sound (ps := []) (t := e1211277431770) (by decide)) (by decide)
def e1211277433078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 1)))))
theorem wire_e1211277433078 : Closed e1211277433078 ∧ code e1211277433078 = 5609323944182 := by decide
theorem cert_e1211277433078 : check e1211277433078 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277433274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1211277433274 : Closed e1211277433274 ∧ code e1211277433274 = 5609323944378 := by decide
theorem cert_e1211277433274 : check e1211277433274 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277433322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1211277433322 : Closed e1211277433322 ∧ code e1211277433322 = 5609323944426 := by decide
theorem cert_e1211277433322 : check e1211277433322 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277433730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277433730 : Closed e1211277433730 ∧ code e1211277433730 = 5609323944834 := by decide
theorem cert_e1211277433730 : check e1211277433730 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277433742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 2))))))
theorem wire_e1211277433742 : Closed e1211277433742 ∧ code e1211277433742 = 5609323944846 := by decide
theorem cert_e1211277433742 : check e1211277433742 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277433754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277433754 : Closed e1211277433754 ∧ code e1211277433754 = 5609323944858 := by decide
theorem cert_e1211277433754 : check e1211277433754 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277433974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 1)))))
theorem wire_e1211277433974 : Closed e1211277433974 ∧ code e1211277433974 = 5609323945078 := by decide
private def t_e1211277433974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 1)))))
theorem cert_e1211277433974 : ¬ IsSelfInterpreter e1211277433974 :=
  wSource (t := t_e1211277433974) (replay_sound (ps := []) (t := e1211277433974) (by decide)) (by decide)
def e1211277434074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1211277434074 : Closed e1211277434074 ∧ code e1211277434074 = 5609323945178 := by decide
private def t_e1211277434074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem cert_e1211277434074 : ¬ IsSelfInterpreter e1211277434074 :=
  wSource (t := t_e1211277434074) (replay_sound (ps := []) (t := e1211277434074) (by decide)) (by decide)
def e1211277434090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1211277434090 : Closed e1211277434090 ∧ code e1211277434090 = 5609323945194 := by decide
private def t_e1211277434090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem cert_e1211277434090 : ¬ IsSelfInterpreter e1211277434090 :=
  wSource (t := t_e1211277434090) (replay_sound (ps := []) (t := e1211277434090) (by decide)) (by decide)
def e1211277434242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277434242 : Closed e1211277434242 ∧ code e1211277434242 = 5609323945346 := by decide
private def t_e1211277434242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.var 0)))))))
theorem cert_e1211277434242 : ¬ IsSelfInterpreter e1211277434242 :=
  wSource (t := t_e1211277434242) (replay_sound (ps := []) (t := e1211277434242) (by decide)) (by decide)
def e1211277434254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 2))))))
theorem wire_e1211277434254 : Closed e1211277434254 ∧ code e1211277434254 = 5609323945358 := by decide
private def t_e1211277434254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 2))))))
theorem cert_e1211277434254 : ¬ IsSelfInterpreter e1211277434254 :=
  wSource (t := t_e1211277434254) (replay_sound (ps := []) (t := e1211277434254) (by decide)) (by decide)
def e1211277434266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277434266 : Closed e1211277434266 ∧ code e1211277434266 = 5609323945370 := by decide
private def t_e1211277434266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 0))))))
theorem cert_e1211277434266 : ¬ IsSelfInterpreter e1211277434266 :=
  wSource (t := t_e1211277434266) (replay_sound (ps := []) (t := e1211277434266) (by decide)) (by decide)
def e1211277435766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 1)))))
theorem wire_e1211277435766 : Closed e1211277435766 ∧ code e1211277435766 = 5609323946870 := by decide
theorem cert_e1211277435766 : check e1211277435766 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277435862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 1)))))
theorem wire_e1211277435862 : Closed e1211277435862 ∧ code e1211277435862 = 5609323946966 := by decide
theorem cert_e1211277435862 : check e1211277435862 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277436602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.var 0)))))
theorem wire_e1211277436602 : Closed e1211277436602 ∧ code e1211277436602 = 5609323947706 := by decide
theorem cert_e1211277436602 : check e1211277436602 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277436650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e1211277436650 : Closed e1211277436650 ∧ code e1211277436650 = 5609323947754 := by decide
theorem cert_e1211277436650 : check e1211277436650 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277436842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.var 0)))))
theorem wire_e1211277436842 : Closed e1211277436842 ∧ code e1211277436842 = 5609323947946 := by decide
theorem cert_e1211277436842 : check e1211277436842 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277437174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 1)))))
theorem wire_e1211277437174 : Closed e1211277437174 ∧ code e1211277437174 = 5609323948278 := by decide
theorem cert_e1211277437174 : check e1211277437174 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277437370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e1211277437370 : Closed e1211277437370 ∧ code e1211277437370 = 5609323948474 := by decide
theorem cert_e1211277437370 : check e1211277437370 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277437418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e1211277437418 : Closed e1211277437418 ∧ code e1211277437418 = 5609323948522 := by decide
theorem cert_e1211277437418 : check e1211277437418 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277437826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277437826 : Closed e1211277437826 ∧ code e1211277437826 = 5609323948930 := by decide
theorem cert_e1211277437826 : check e1211277437826 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277437838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 2))))))
theorem wire_e1211277437838 : Closed e1211277437838 ∧ code e1211277437838 = 5609323948942 := by decide
theorem cert_e1211277437838 : check e1211277437838 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277437850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277437850 : Closed e1211277437850 ∧ code e1211277437850 = 5609323948954 := by decide
theorem cert_e1211277437850 : check e1211277437850 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277438518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 1)))))
theorem wire_e1211277438518 : Closed e1211277438518 ∧ code e1211277438518 = 5609323949622 := by decide
theorem cert_e1211277438518 : check e1211277438518 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277438570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.var 0)))))
theorem wire_e1211277438570 : Closed e1211277438570 ∧ code e1211277438570 = 5609323949674 := by decide
theorem cert_e1211277438570 : check e1211277438570 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277438594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277438594 : Closed e1211277438594 ∧ code e1211277438594 = 5609323949698 := by decide
theorem cert_e1211277438594 : check e1211277438594 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277438606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 2))))))
theorem wire_e1211277438606 : Closed e1211277438606 ∧ code e1211277438606 = 5609323949710 := by decide
theorem cert_e1211277438606 : check e1211277438606 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277438618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277438618 : Closed e1211277438618 ∧ code e1211277438618 = 5609323949722 := by decide
theorem cert_e1211277438618 : check e1211277438618 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277439414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 1)))))
theorem wire_e1211277439414 : Closed e1211277439414 ∧ code e1211277439414 = 5609323950518 := by decide
theorem cert_e1211277439414 : check e1211277439414 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211277439446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 1)))))
theorem wire_e1211277439446 : Closed e1211277439446 ∧ code e1211277439446 = 5609323950550 := by decide
theorem cert_e1211277439446 : check e1211277439446 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211277439834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 0)))))
theorem wire_e1211277439834 : Closed e1211277439834 ∧ code e1211277439834 = 5609323950938 := by decide
private def t_e1211277439834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 0)))))
theorem cert_e1211277439834 : ¬ IsSelfInterpreter e1211277439834 :=
  wSource (t := t_e1211277439834) (replay_sound (ps := []) (t := e1211277439834) (by decide)) (by decide)
def e1211277439850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.var 0)))))
theorem wire_e1211277439850 : Closed e1211277439850 ∧ code e1211277439850 = 5609323950954 := by decide
theorem cert_e1211277439850 : check e1211277439850 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211277439914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.var 0)))))
theorem wire_e1211277439914 : Closed e1211277439914 ∧ code e1211277439914 = 5609323951018 := by decide
theorem cert_e1211277439914 : check e1211277439914 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277440118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 1)))))
theorem wire_e1211277440118 : Closed e1211277440118 ∧ code e1211277440118 = 5609323951222 := by decide
private def t_e1211277440118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 1)))))
theorem cert_e1211277440118 : ¬ IsSelfInterpreter e1211277440118 :=
  wSource (t := t_e1211277440118) (replay_sound (ps := []) (t := e1211277440118) (by decide)) (by decide)
def e1211277440218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e1211277440218 : Closed e1211277440218 ∧ code e1211277440218 = 5609323951322 := by decide
private def t_e1211277440218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem cert_e1211277440218 : ¬ IsSelfInterpreter e1211277440218 :=
  wSource (t := t_e1211277440218) (replay_sound (ps := []) (t := e1211277440218) (by decide)) (by decide)
def e1211277440234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e1211277440234 : Closed e1211277440234 ∧ code e1211277440234 = 5609323951338 := by decide
private def t_e1211277440234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem cert_e1211277440234 : ¬ IsSelfInterpreter e1211277440234 :=
  wSource (t := t_e1211277440234) (replay_sound (ps := []) (t := e1211277440234) (by decide)) (by decide)
def e1211277440386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277440386 : Closed e1211277440386 ∧ code e1211277440386 = 5609323951490 := by decide
private def t_e1211277440386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.var 0)))))))
theorem cert_e1211277440386 : ¬ IsSelfInterpreter e1211277440386 :=
  wSource (t := t_e1211277440386) (replay_sound (ps := []) (t := e1211277440386) (by decide)) (by decide)
def e1211277440398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 2))))))
theorem wire_e1211277440398 : Closed e1211277440398 ∧ code e1211277440398 = 5609323951502 := by decide
private def t_e1211277440398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 2))))))
theorem cert_e1211277440398 : ¬ IsSelfInterpreter e1211277440398 :=
  wSource (t := t_e1211277440398) (replay_sound (ps := []) (t := e1211277440398) (by decide)) (by decide)
def e1211277440410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277440410 : Closed e1211277440410 ∧ code e1211277440410 = 5609323951514 := by decide
private def t_e1211277440410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 0))))))
theorem cert_e1211277440410 : ¬ IsSelfInterpreter e1211277440410 :=
  wSource (t := t_e1211277440410) (replay_sound (ps := []) (t := e1211277440410) (by decide)) (by decide)
def e1211277440566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 1)))))
theorem wire_e1211277440566 : Closed e1211277440566 ∧ code e1211277440566 = 5609323951670 := by decide
theorem cert_e1211277440566 : check e1211277440566 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277440618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.var 0)))))
theorem wire_e1211277440618 : Closed e1211277440618 ∧ code e1211277440618 = 5609323951722 := by decide
theorem cert_e1211277440618 : check e1211277440618 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277440642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277440642 : Closed e1211277440642 ∧ code e1211277440642 = 5609323951746 := by decide
theorem cert_e1211277440642 : check e1211277440642 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211277440654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 2))))))
theorem wire_e1211277440654 : Closed e1211277440654 ∧ code e1211277440654 = 5609323951758 := by decide
theorem cert_e1211277440654 : check e1211277440654 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277440666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277440666 : Closed e1211277440666 ∧ code e1211277440666 = 5609323951770 := by decide
theorem cert_e1211277440666 : check e1211277440666 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277447034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))) (.var 0)))))
theorem wire_e1211277447034 : Closed e1211277447034 ∧ code e1211277447034 = 5609323958138 := by decide
theorem cert_e1211277447034 : check e1211277447034 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211277447098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))) (.var 0)))))
theorem wire_e1211277447098 : Closed e1211277447098 ∧ code e1211277447098 = 5609323958202 := by decide
theorem cert_e1211277447098 : check e1211277447098 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e1211277454778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1211277454778 : Closed e1211277454778 ∧ code e1211277454778 = 5609323965882 := by decide
theorem cert_e1211277454778 : check e1211277454778 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211277454810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1211277454810 : Closed e1211277454810 ∧ code e1211277454810 = 5609323965914 := by decide
private def t_e1211277454810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem cert_e1211277454810 : ¬ IsSelfInterpreter e1211277454810 :=
  wSource (t := t_e1211277454810) (replay_sound (ps := []) (t := e1211277454810) (by decide)) (by decide)
def e1211277455034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1211277455034 : Closed e1211277455034 ∧ code e1211277455034 = 5609323966138 := by decide
theorem cert_e1211277455034 : check e1211277455034 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277455082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1211277455082 : Closed e1211277455082 ∧ code e1211277455082 = 5609323966186 := by decide
theorem cert_e1211277455082 : check e1211277455082 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277455194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1211277455194 : Closed e1211277455194 ∧ code e1211277455194 = 5609323966298 := by decide
private def t_e1211277455194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem cert_e1211277455194 : ¬ IsSelfInterpreter e1211277455194 :=
  wSource (t := t_e1211277455194) (replay_sound (ps := []) (t := e1211277455194) (by decide)) (by decide)
def e1211277455210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1211277455210 : Closed e1211277455210 ∧ code e1211277455210 = 5609323966314 := by decide
theorem cert_e1211277455210 : check e1211277455210 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277456314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211277456314 : Closed e1211277456314 ∧ code e1211277456314 = 5609323967418 := by decide
theorem cert_e1211277456314 : check e1211277456314 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277456346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211277456346 : Closed e1211277456346 ∧ code e1211277456346 = 5609323967450 := by decide
theorem cert_e1211277456346 : check e1211277456346 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277457654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 1)))))
theorem wire_e1211277457654 : Closed e1211277457654 ∧ code e1211277457654 = 5609323968758 := by decide
theorem cert_e1211277457654 : check e1211277457654 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277457850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1211277457850 : Closed e1211277457850 ∧ code e1211277457850 = 5609323968954 := by decide
theorem cert_e1211277457850 : check e1211277457850 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277457898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1211277457898 : Closed e1211277457898 ∧ code e1211277457898 = 5609323969002 := by decide
theorem cert_e1211277457898 : check e1211277457898 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277458306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277458306 : Closed e1211277458306 ∧ code e1211277458306 = 5609323969410 := by decide
theorem cert_e1211277458306 : check e1211277458306 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277458318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 2))))))
theorem wire_e1211277458318 : Closed e1211277458318 ∧ code e1211277458318 = 5609323969422 := by decide
theorem cert_e1211277458318 : check e1211277458318 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277458330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277458330 : Closed e1211277458330 ∧ code e1211277458330 = 5609323969434 := by decide
theorem cert_e1211277458330 : check e1211277458330 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277458550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 1)))))
theorem wire_e1211277458550 : Closed e1211277458550 ∧ code e1211277458550 = 5609323969654 := by decide
theorem cert_e1211277458550 : check e1211277458550 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211277458650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1211277458650 : Closed e1211277458650 ∧ code e1211277458650 = 5609323969754 := by decide
theorem cert_e1211277458650 : check e1211277458650 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211277458666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1211277458666 : Closed e1211277458666 ∧ code e1211277458666 = 5609323969770 := by decide
theorem cert_e1211277458666 : check e1211277458666 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277458818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277458818 : Closed e1211277458818 ∧ code e1211277458818 = 5609323969922 := by decide
theorem cert_e1211277458818 : check e1211277458818 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e1211277458830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 2))))))
theorem wire_e1211277458830 : Closed e1211277458830 ∧ code e1211277458830 = 5609323969934 := by decide
theorem cert_e1211277458830 : check e1211277458830 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277458842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277458842 : Closed e1211277458842 ∧ code e1211277458842 = 5609323969946 := by decide
theorem cert_e1211277458842 : check e1211277458842 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277477754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))) (.var 0)))))
theorem wire_e1211277477754 : Closed e1211277477754 ∧ code e1211277477754 = 5609323988858 := by decide
theorem cert_e1211277477754 : check e1211277477754 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277477850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))) (.var 0)))))
theorem wire_e1211277477850 : Closed e1211277477850 ∧ code e1211277477850 = 5609323988954 := by decide
theorem cert_e1211277477850 : check e1211277477850 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277481658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1211277481658 : Closed e1211277481658 ∧ code e1211277481658 = 5609323992762 := by decide
theorem cert_e1211277481658 : check e1211277481658 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277481706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1211277481706 : Closed e1211277481706 ∧ code e1211277481706 = 5609323992810 := by decide
theorem cert_e1211277481706 : check e1211277481706 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277481898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.var 0)))))
theorem wire_e1211277481898 : Closed e1211277481898 ∧ code e1211277481898 = 5609323993002 := by decide
theorem cert_e1211277481898 : check e1211277481898 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277482230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 1)))))
theorem wire_e1211277482230 : Closed e1211277482230 ∧ code e1211277482230 = 5609323993334 := by decide
theorem cert_e1211277482230 : check e1211277482230 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277482426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1211277482426 : Closed e1211277482426 ∧ code e1211277482426 = 5609323993530 := by decide
theorem cert_e1211277482426 : check e1211277482426 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277482474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1211277482474 : Closed e1211277482474 ∧ code e1211277482474 = 5609323993578 := by decide
theorem cert_e1211277482474 : check e1211277482474 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277482882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277482882 : Closed e1211277482882 ∧ code e1211277482882 = 5609323993986 := by decide
theorem cert_e1211277482882 : check e1211277482882 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277482894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 2))))))
theorem wire_e1211277482894 : Closed e1211277482894 ∧ code e1211277482894 = 5609323993998 := by decide
theorem cert_e1211277482894 : check e1211277482894 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277482906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277482906 : Closed e1211277482906 ∧ code e1211277482906 = 5609323994010 := by decide
theorem cert_e1211277482906 : check e1211277482906 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277483574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 1)))))
theorem wire_e1211277483574 : Closed e1211277483574 ∧ code e1211277483574 = 5609323994678 := by decide
theorem cert_e1211277483574 : check e1211277483574 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277483626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.var 0)))))
theorem wire_e1211277483626 : Closed e1211277483626 ∧ code e1211277483626 = 5609323994730 := by decide
theorem cert_e1211277483626 : check e1211277483626 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277483650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277483650 : Closed e1211277483650 ∧ code e1211277483650 = 5609323994754 := by decide
theorem cert_e1211277483650 : check e1211277483650 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277483662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 2))))))
theorem wire_e1211277483662 : Closed e1211277483662 ∧ code e1211277483662 = 5609323994766 := by decide
theorem cert_e1211277483662 : check e1211277483662 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277483674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277483674 : Closed e1211277483674 ∧ code e1211277483674 = 5609323994778 := by decide
theorem cert_e1211277483674 : check e1211277483674 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211277493178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211277493178 : Closed e1211277493178 ∧ code e1211277493178 = 5609324004282 := by decide
theorem cert_e1211277493178 : check e1211277493178 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277493210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211277493210 : Closed e1211277493210 ∧ code e1211277493210 = 5609324004314 := by decide
theorem cert_e1211277493210 : check e1211277493210 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277495130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1211277495130 : Closed e1211277495130 ∧ code e1211277495130 = 5609324006234 := by decide
private def t_e1211277495130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0)))))
theorem cert_e1211277495130 : ¬ IsSelfInterpreter e1211277495130 :=
  wSource (t := t_e1211277495130) (replay_sound (ps := []) (t := e1211277495130) (by decide)) (by decide)
def e1211277495146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1211277495146 : Closed e1211277495146 ∧ code e1211277495146 = 5609324006250 := by decide
theorem cert_e1211277495146 : check e1211277495146 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211277495210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.var 0)))))
theorem wire_e1211277495210 : Closed e1211277495210 ∧ code e1211277495210 = 5609324006314 := by decide
theorem cert_e1211277495210 : check e1211277495210 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211277495414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 1)))))
theorem wire_e1211277495414 : Closed e1211277495414 ∧ code e1211277495414 = 5609324006518 := by decide
theorem cert_e1211277495414 : check e1211277495414 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211277495514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1211277495514 : Closed e1211277495514 ∧ code e1211277495514 = 5609324006618 := by decide
def e1211277495530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1211277495530 : Closed e1211277495530 ∧ code e1211277495530 = 5609324006634 := by decide
def e1211277495682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277495682 : Closed e1211277495682 ∧ code e1211277495682 = 5609324006786 := by decide
theorem cert_e1211277495682 : check e1211277495682 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e1211277495694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 2))))))
theorem wire_e1211277495694 : Closed e1211277495694 ∧ code e1211277495694 = 5609324006798 := by decide
theorem cert_e1211277495694 : check e1211277495694 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277495706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277495706 : Closed e1211277495706 ∧ code e1211277495706 = 5609324006810 := by decide
theorem cert_e1211277495706 : check e1211277495706 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211277495862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 1)))))
theorem wire_e1211277495862 : Closed e1211277495862 ∧ code e1211277495862 = 5609324006966 := by decide
theorem cert_e1211277495862 : check e1211277495862 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211277495914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.var 0)))))
theorem wire_e1211277495914 : Closed e1211277495914 ∧ code e1211277495914 = 5609324007018 := by decide
theorem cert_e1211277495914 : check e1211277495914 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211277495938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.var 0)))))))
theorem wire_e1211277495938 : Closed e1211277495938 ∧ code e1211277495938 = 5609324007042 := by decide
theorem cert_e1211277495938 : check e1211277495938 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211277495950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 2))))))
theorem wire_e1211277495950 : Closed e1211277495950 ∧ code e1211277495950 = 5609324007054 := by decide
theorem cert_e1211277495950 : check e1211277495950 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211277495962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 0) (.var 0))))))
theorem wire_e1211277495962 : Closed e1211277495962 ∧ code e1211277495962 = 5609324007066 := by decide
theorem cert_e1211277495962 : check e1211277495962 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211277708142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211277708142 : Closed e1211277708142 ∧ code e1211277708142 = 5609324219246 := by decide
theorem cert_e1211277708142 : check e1211277708142 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211277708150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211277708150 : Closed e1211277708150 ∧ code e1211277708150 = 5609324219254 := by decide
theorem cert_e1211277708150 : check e1211277708150 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1211277708206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211277708206 : Closed e1211277708206 ∧ code e1211277708206 = 5609324219310 := by decide
theorem cert_e1211277708206 : check e1211277708206 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211277708218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211277708218 : Closed e1211277708218 ∧ code e1211277708218 = 5609324219322 := by decide
theorem cert_e1211277708218 : check e1211277708218 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211277708246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211277708246 : Closed e1211277708246 ∧ code e1211277708246 = 5609324219350 := by decide
theorem cert_e1211277708246 : check e1211277708246 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1211277708250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211277708250 : Closed e1211277708250 ∧ code e1211277708250 = 5609324219354 := by decide
theorem cert_e1211277708250 : check e1211277708250 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211277708526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211277708526 : Closed e1211277708526 ∧ code e1211277708526 = 5609324219630 := by decide
theorem cert_e1211277708526 : check e1211277708526 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211277708534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211277708534 : Closed e1211277708534 ∧ code e1211277708534 = 5609324219638 := by decide
theorem cert_e1211277708534 : check e1211277708534 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211277708910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211277708910 : Closed e1211277708910 ∧ code e1211277708910 = 5609324220014 := by decide
theorem cert_e1211277708910 : checkPay e1211277708910 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left]] 1 [[.under],[.under,.left,.left,.right,.under]] = true := by decide
def e1211277708922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211277708922 : Closed e1211277708922 ∧ code e1211277708922 = 5609324220026 := by decide
def e1211277709110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211277709110 : Closed e1211277709110 ∧ code e1211277709110 = 5609324220214 := by decide
theorem cert_e1211277709110 : check e1211277709110 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211277709114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211277709114 : Closed e1211277709114 ∧ code e1211277709114 = 5609324220218 := by decide
theorem cert_e1211277709114 : check e1211277709114 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211278044602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e1211278044602 : Closed e1211278044602 ∧ code e1211278044602 = 5609324555706 := by decide
theorem cert_e1211278044602 : check e1211278044602 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278044634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e1211278044634 : Closed e1211278044634 ∧ code e1211278044634 = 5609324555738 := by decide
theorem cert_e1211278044634 : check e1211278044634 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278044858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1211278044858 : Closed e1211278044858 ∧ code e1211278044858 = 5609324555962 := by decide
theorem cert_e1211278044858 : check e1211278044858 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278044906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1211278044906 : Closed e1211278044906 ∧ code e1211278044906 = 5609324556010 := by decide
theorem cert_e1211278044906 : check e1211278044906 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278045018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e1211278045018 : Closed e1211278045018 ∧ code e1211278045018 = 5609324556122 := by decide
theorem cert_e1211278045018 : check e1211278045018 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278045034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e1211278045034 : Closed e1211278045034 ∧ code e1211278045034 = 5609324556138 := by decide
theorem cert_e1211278045034 : check e1211278045034 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278046138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e1211278046138 : Closed e1211278046138 ∧ code e1211278046138 = 5609324557242 := by decide
theorem cert_e1211278046138 : check e1211278046138 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278046170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e1211278046170 : Closed e1211278046170 ∧ code e1211278046170 = 5609324557274 := by decide
theorem cert_e1211278046170 : check e1211278046170 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278047674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1211278047674 : Closed e1211278047674 ∧ code e1211278047674 = 5609324558778 := by decide
theorem cert_e1211278047674 : check e1211278047674 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278047722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1211278047722 : Closed e1211278047722 ∧ code e1211278047722 = 5609324558826 := by decide
theorem cert_e1211278047722 : check e1211278047722 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278048474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e1211278048474 : Closed e1211278048474 ∧ code e1211278048474 = 5609324559578 := by decide
theorem cert_e1211278048474 : check e1211278048474 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278048490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e1211278048490 : Closed e1211278048490 ∧ code e1211278048490 = 5609324559594 := by decide
theorem cert_e1211278048490 : check e1211278048490 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211278101358 : Closed e1211278101358 ∧ code e1211278101358 = 5609324612462 := by decide
theorem cert_e1211278101358 : check e1211278101358 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211278101366 : Closed e1211278101366 ∧ code e1211278101366 = 5609324612470 := by decide
theorem cert_e1211278101366 : check e1211278101366 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211278101422 : Closed e1211278101422 ∧ code e1211278101422 = 5609324612526 := by decide
theorem cert_e1211278101422 : check e1211278101422 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211278101434 : Closed e1211278101434 ∧ code e1211278101434 = 5609324612538 := by decide
theorem cert_e1211278101434 : check e1211278101434 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211278101462 : Closed e1211278101462 ∧ code e1211278101462 = 5609324612566 := by decide
theorem cert_e1211278101462 : check e1211278101462 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211278101466 : Closed e1211278101466 ∧ code e1211278101466 = 5609324612570 := by decide
theorem cert_e1211278101466 : check e1211278101466 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211278101742 : Closed e1211278101742 ∧ code e1211278101742 = 5609324612846 := by decide
theorem cert_e1211278101742 : check e1211278101742 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278101750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211278101750 : Closed e1211278101750 ∧ code e1211278101750 = 5609324612854 := by decide
theorem cert_e1211278101750 : check e1211278101750 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278102126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211278102126 : Closed e1211278102126 ∧ code e1211278102126 = 5609324613230 := by decide
theorem cert_e1211278102126 : check e1211278102126 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278102138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211278102138 : Closed e1211278102138 ∧ code e1211278102138 = 5609324613242 := by decide
theorem cert_e1211278102138 : check e1211278102138 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278102326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211278102326 : Closed e1211278102326 ∧ code e1211278102326 = 5609324613430 := by decide
theorem cert_e1211278102326 : check e1211278102326 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278102330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211278102330 : Closed e1211278102330 ∧ code e1211278102330 = 5609324613434 := by decide
theorem cert_e1211278102330 : check e1211278102330 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278306782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1211278306782 : Closed e1211278306782 ∧ code e1211278306782 = 5609324817886 := by decide
theorem cert_e1211278306782 : check e1211278306782 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278306798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1211278306798 : Closed e1211278306798 ∧ code e1211278306798 = 5609324817902 := by decide
theorem cert_e1211278306798 : check e1211278306798 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278307166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1211278307166 : Closed e1211278307166 ∧ code e1211278307166 = 5609324818270 := by decide
theorem cert_e1211278307166 : check e1211278307166 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211278307194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1211278307194 : Closed e1211278307194 ∧ code e1211278307194 = 5609324818298 := by decide
theorem cert_e1211278307194 : check e1211278307194 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor42
