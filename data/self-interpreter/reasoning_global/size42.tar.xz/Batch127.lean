import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209571593686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1209571593686 : Closed e1209571593686 ∧ code e1209571593686 = 5607618104790 := by decide
theorem cert_e1209571593686 : check e1209571593686 [[],[]] .sourceHead = true := by decide
def e1209571593690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1209571593690 : Closed e1209571593690 ∧ code e1209571593690 = 5607618104794 := by decide
theorem cert_e1209571593690 : check e1209571593690 [[],[]] .sourceHead = true := by decide
def e1209571593902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1209571593902 : Closed e1209571593902 ∧ code e1209571593902 = 5607618105006 := by decide
theorem cert_e1209571593902 : check e1209571593902 [[],[]] .sourceHead = true := by decide
def e1209571593914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1209571593914 : Closed e1209571593914 ∧ code e1209571593914 = 5607618105018 := by decide
theorem cert_e1209571593914 : check e1209571593914 [[],[]] .sourceHead = true := by decide
def e1209571593962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1209571593962 : Closed e1209571593962 ∧ code e1209571593962 = 5607618105066 := by decide
theorem cert_e1209571593962 : check e1209571593962 [[],[]] .sourceHead = true := by decide
def e1209571594070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1209571594070 : Closed e1209571594070 ∧ code e1209571594070 = 5607618105174 := by decide
theorem cert_e1209571594070 : check e1209571594070 [[],[]] .sourceHead = true := by decide
def e1209571594074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1209571594074 : Closed e1209571594074 ∧ code e1209571594074 = 5607618105178 := by decide
theorem cert_e1209571594074 : check e1209571594074 [[],[]] .sourceHead = true := by decide
def e1209571594090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1209571594090 : Closed e1209571594090 ∧ code e1209571594090 = 5607618105194 := by decide
theorem cert_e1209571594090 : check e1209571594090 [[],[]] .sourceHead = true := by decide
def e1209571594734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1209571594734 : Closed e1209571594734 ∧ code e1209571594734 = 5607618105838 := by decide
theorem cert_e1209571594734 : check e1209571594734 [[],[]] .sourceHead = true := by decide
def e1209571595118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1209571595118 : Closed e1209571595118 ∧ code e1209571595118 = 5607618106222 := by decide
theorem cert_e1209571595118 : check e1209571595118 [[],[]] .sourceHead = true := by decide
def e1209571595126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1209571595126 : Closed e1209571595126 ∧ code e1209571595126 = 5607618106230 := by decide
theorem cert_e1209571595126 : check e1209571595126 [[],[]] .sourceHead = true := by decide
def e1209571595182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1209571595182 : Closed e1209571595182 ∧ code e1209571595182 = 5607618106286 := by decide
theorem cert_e1209571595182 : check e1209571595182 [[],[]] .sourceHead = true := by decide
def e1209571595194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1209571595194 : Closed e1209571595194 ∧ code e1209571595194 = 5607618106298 := by decide
theorem cert_e1209571595194 : check e1209571595194 [[],[]] .sourceHead = true := by decide
def e1209571595222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1209571595222 : Closed e1209571595222 ∧ code e1209571595222 = 5607618106326 := by decide
theorem cert_e1209571595222 : check e1209571595222 [[],[]] .sourceHead = true := by decide
def e1209571595226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1209571595226 : Closed e1209571595226 ∧ code e1209571595226 = 5607618106330 := by decide
theorem cert_e1209571595226 : check e1209571595226 [[],[]] .sourceHead = true := by decide
def e1209571595502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571595502 : Closed e1209571595502 ∧ code e1209571595502 = 5607618106606 := by decide
theorem cert_e1209571595502 : check e1209571595502 [[],[]] .sourceHead = true := by decide
def e1209571595510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571595510 : Closed e1209571595510 ∧ code e1209571595510 = 5607618106614 := by decide
theorem cert_e1209571595510 : check e1209571595510 [[],[]] .sourceHead = true := by decide
def e1209571595886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571595886 : Closed e1209571595886 ∧ code e1209571595886 = 5607618106990 := by decide
theorem cert_e1209571595886 : check e1209571595886 [[],[]] .sourceHead = true := by decide
def e1209571595898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571595898 : Closed e1209571595898 ∧ code e1209571595898 = 5607618107002 := by decide
theorem cert_e1209571595898 : check e1209571595898 [[],[]] .sourceHead = true := by decide
def e1209571596062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1209571596062 : Closed e1209571596062 ∧ code e1209571596062 = 5607618107166 := by decide
theorem cert_e1209571596062 : check e1209571596062 [[],[]] .sourceHead = true := by decide
def e1209571596086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571596086 : Closed e1209571596086 ∧ code e1209571596086 = 5607618107190 := by decide
theorem cert_e1209571596086 : check e1209571596086 [[],[]] .sourceHead = true := by decide
def e1209571596090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571596090 : Closed e1209571596090 ∧ code e1209571596090 = 5607618107194 := by decide
theorem cert_e1209571596090 : check e1209571596090 [[],[]] .sourceHead = true := by decide
def e1209571596718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1209571596718 : Closed e1209571596718 ∧ code e1209571596718 = 5607618107822 := by decide
theorem cert_e1209571596718 : check e1209571596718 [[],[]] .sourceHead = true := by decide
def e1209571596730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1209571596730 : Closed e1209571596730 ∧ code e1209571596730 = 5607618107834 := by decide
theorem cert_e1209571596730 : check e1209571596730 [[],[]] .sourceHead = true := by decide
def e1209571596778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1209571596778 : Closed e1209571596778 ∧ code e1209571596778 = 5607618107882 := by decide
theorem cert_e1209571596778 : check e1209571596778 [[],[]] .sourceHead = true := by decide
def e1209571596910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571596910 : Closed e1209571596910 ∧ code e1209571596910 = 5607618108014 := by decide
theorem cert_e1209571596910 : check e1209571596910 [[],[]] .sourceHead = true := by decide
def e1209571596922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571596922 : Closed e1209571596922 ∧ code e1209571596922 = 5607618108026 := by decide
theorem cert_e1209571596922 : check e1209571596922 [[],[]] .sourceHead = true := by decide
def e1209571597210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1209571597210 : Closed e1209571597210 ∧ code e1209571597210 = 5607618108314 := by decide
theorem cert_e1209571597210 : check e1209571597210 [[],[]] .sourceHead = true := by decide
def e1209571597422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1209571597422 : Closed e1209571597422 ∧ code e1209571597422 = 5607618108526 := by decide
theorem cert_e1209571597422 : check e1209571597422 [[],[]] .sourceHead = true := by decide
def e1209571597434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1209571597434 : Closed e1209571597434 ∧ code e1209571597434 = 5607618108538 := by decide
theorem cert_e1209571597434 : check e1209571597434 [[],[]] .sourceHead = true := by decide
def e1209571597526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1209571597526 : Closed e1209571597526 ∧ code e1209571597526 = 5607618108630 := by decide
theorem cert_e1209571597526 : check e1209571597526 [[],[]] .sourceHead = true := by decide
def e1209571597530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1209571597530 : Closed e1209571597530 ∧ code e1209571597530 = 5607618108634 := by decide
theorem cert_e1209571597530 : check e1209571597530 [[],[]] .sourceHead = true := by decide
def e1209571597546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1209571597546 : Closed e1209571597546 ∧ code e1209571597546 = 5607618108650 := by decide
theorem cert_e1209571597546 : check e1209571597546 [[],[]] .sourceHead = true := by decide
def e1209571597598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1209571597598 : Closed e1209571597598 ∧ code e1209571597598 = 5607618108702 := by decide
theorem cert_e1209571597598 : check e1209571597598 [[],[]] .sourceHead = true := by decide
def e1209571597622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571597622 : Closed e1209571597622 ∧ code e1209571597622 = 5607618108726 := by decide
theorem cert_e1209571597622 : check e1209571597622 [[],[]] .sourceHead = true := by decide
def e1209571597626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571597626 : Closed e1209571597626 ∧ code e1209571597626 = 5607618108730 := by decide
theorem cert_e1209571597626 : check e1209571597626 [[],[]] .sourceHead = true := by decide
def e1209571597722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1209571597722 : Closed e1209571597722 ∧ code e1209571597722 = 5607618108826 := by decide
theorem cert_e1209571597722 : check e1209571597722 [[],[]] .sourceHead = true := by decide
def e1209571597766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1209571597766 : Closed e1209571597766 ∧ code e1209571597766 = 5607618108870 := by decide
theorem cert_e1209571597766 : check e1209571597766 [[],[]] .sourceHead = true := by decide
def e1209571599214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1209571599214 : Closed e1209571599214 ∧ code e1209571599214 = 5607618110318 := by decide
theorem cert_e1209571599214 : check e1209571599214 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1209571599222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1209571599222 : Closed e1209571599222 ∧ code e1209571599222 = 5607618110326 := by decide
theorem cert_e1209571599222 : check e1209571599222 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571599278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1209571599278 : Closed e1209571599278 ∧ code e1209571599278 = 5607618110382 := by decide
theorem cert_e1209571599278 : checkPay e1209571599278 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e1209571599290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1209571599290 : Closed e1209571599290 ∧ code e1209571599290 = 5607618110394 := by decide
theorem cert_e1209571599290 : checkPay e1209571599290 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] 0 [[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] = true := by decide
def e1209571599318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1209571599318 : Closed e1209571599318 ∧ code e1209571599318 = 5607618110422 := by decide
theorem cert_e1209571599318 : check e1209571599318 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .smaller = true := by decide
def e1209571599322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1209571599322 : Closed e1209571599322 ∧ code e1209571599322 = 5607618110426 := by decide
theorem cert_e1209571599322 : check e1209571599322 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .smaller = true := by decide
def e1209571600054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1209571600054 : Closed e1209571600054 ∧ code e1209571600054 = 5607618111158 := by decide
theorem cert_e1209571600054 : check e1209571600054 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1209571600086 : Closed e1209571600086 ∧ code e1209571600086 = 5607618111190 := by decide
theorem cert_e1209571600086 : check e1209571600086 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1209571600090 : Closed e1209571600090 ∧ code e1209571600090 = 5607618111194 := by decide
theorem cert_e1209571600090 : check e1209571600090 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1209571600214 : Closed e1209571600214 ∧ code e1209571600214 = 5607618111318 := by decide
theorem cert_e1209571600214 : check e1209571600214 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1209571600218 : Closed e1209571600218 ∧ code e1209571600218 = 5607618111322 := by decide
theorem cert_e1209571600218 : check e1209571600218 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1209571600234 : Closed e1209571600234 ∧ code e1209571600234 = 5607618111338 := by decide
theorem cert_e1209571600234 : check e1209571600234 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1209571600622 : Closed e1209571600622 ∧ code e1209571600622 = 5607618111726 := by decide
theorem cert_e1209571600622 : check e1209571600622 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e1209571600630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1209571600630 : Closed e1209571600630 ∧ code e1209571600630 = 5607618111734 := by decide
theorem cert_e1209571600630 : check e1209571600630 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1209571600822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1209571600822 : Closed e1209571600822 ∧ code e1209571600822 = 5607618111926 := by decide
theorem cert_e1209571600822 : check e1209571600822 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1209571600854 : Closed e1209571600854 ∧ code e1209571600854 = 5607618111958 := by decide
theorem cert_e1209571600854 : check e1209571600854 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571600858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1209571600858 : Closed e1209571600858 ∧ code e1209571600858 = 5607618111962 := by decide
theorem cert_e1209571600858 : check e1209571600858 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209571601014 : Closed e1209571601014 ∧ code e1209571601014 = 5607618112118 := by decide
theorem cert_e1209571601014 : check e1209571601014 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1209571601182 : Closed e1209571601182 ∧ code e1209571601182 = 5607618112286 := by decide
theorem cert_e1209571601182 : check e1209571601182 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1209571601206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571601206 : Closed e1209571601206 ∧ code e1209571601206 = 5607618112310 := by decide
theorem cert_e1209571601206 : check e1209571601206 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571601210 : Closed e1209571601210 ∧ code e1209571601210 = 5607618112314 := by decide
theorem cert_e1209571601210 : check e1209571601210 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1209571601294 : Closed e1209571601294 ∧ code e1209571601294 = 5607618112398 := by decide
def e1209571601518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1209571601518 : Closed e1209571601518 ∧ code e1209571601518 = 5607618112622 := by decide
theorem cert_e1209571601518 : check e1209571601518 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1209571601530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1209571601530 : Closed e1209571601530 ∧ code e1209571601530 = 5607618112634 := by decide
theorem cert_e1209571601530 : check e1209571601530 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1209571601622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1209571601622 : Closed e1209571601622 ∧ code e1209571601622 = 5607618112726 := by decide
theorem cert_e1209571601622 : check e1209571601622 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1209571601626 : Closed e1209571601626 ∧ code e1209571601626 = 5607618112730 := by decide
theorem cert_e1209571601626 : check e1209571601626 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1209571601642 : Closed e1209571601642 ∧ code e1209571601642 = 5607618112746 := by decide
theorem cert_e1209571601642 : check e1209571601642 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1209571601694 : Closed e1209571601694 ∧ code e1209571601694 = 5607618112798 := by decide
theorem cert_e1209571601694 : check e1209571601694 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1209571601718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571601718 : Closed e1209571601718 ∧ code e1209571601718 = 5607618112822 := by decide
theorem cert_e1209571601718 : check e1209571601718 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571601722 : Closed e1209571601722 ∧ code e1209571601722 = 5607618112826 := by decide
theorem cert_e1209571601722 : check e1209571601722 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1209571601818 : Closed e1209571601818 ∧ code e1209571601818 = 5607618112922 := by decide
theorem cert_e1209571601818 : check e1209571601818 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e1209571601862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1209571601862 : Closed e1209571601862 ∧ code e1209571601862 = 5607618112966 := by decide
theorem cert_e1209571601862 : check e1209571601862 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e1209571601974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1209571601974 : Closed e1209571601974 ∧ code e1209571601974 = 5607618113078 := by decide
private def t_e1209571601974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem cert_e1209571601974 : ¬ IsSelfInterpreter e1209571601974 :=
  wSource (t := t_e1209571601974) (replay_sound (ps := []) (t := e1209571601974) (by decide)) (by decide)
def e1209571601978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1209571601978 : Closed e1209571601978 ∧ code e1209571601978 = 5607618113082 := by decide
private def t_e1209571601978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem cert_e1209571601978 : ¬ IsSelfInterpreter e1209571601978 :=
  wSource (t := t_e1209571601978) (replay_sound (ps := []) (t := e1209571601978) (by decide)) (by decide)
def e1209571602062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1209571602062 : Closed e1209571602062 ∧ code e1209571602062 = 5607618113166 := by decide
private def t_e1209571602062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem cert_e1209571602062 : ¬ IsSelfInterpreter e1209571602062 :=
  wSource (t := t_e1209571602062) (replay_sound (ps := []) (t := e1209571602062) (by decide)) (by decide)
def e1209571602118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1209571602118 : Closed e1209571602118 ∧ code e1209571602118 = 5607618113222 := by decide
private def t_e1209571602118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem cert_e1209571602118 : ¬ IsSelfInterpreter e1209571602118 :=
  wSource (t := t_e1209571602118) (replay_sound (ps := []) (t := e1209571602118) (by decide)) (by decide)
def e1209571614446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e1209571614446 : Closed e1209571614446 ∧ code e1209571614446 = 5607618125550 := by decide
theorem cert_e1209571614446 : check e1209571614446 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1209571614454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e1209571614454 : Closed e1209571614454 ∧ code e1209571614454 = 5607618125558 := by decide
theorem cert_e1209571614454 : check e1209571614454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e1209571614582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e1209571614582 : Closed e1209571614582 ∧ code e1209571614582 = 5607618125686 := by decide
theorem cert_e1209571614582 : check e1209571614582 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1209571621358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e1209571621358 : Closed e1209571621358 ∧ code e1209571621358 = 5607618132462 := by decide
theorem cert_e1209571621358 : checkPay e1209571621358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e1209571622126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571622126 : Closed e1209571622126 ∧ code e1209571622126 = 5607618133230 := by decide
theorem cert_e1209571622126 : check e1209571622126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571622134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571622134 : Closed e1209571622134 ∧ code e1209571622134 = 5607618133238 := by decide
theorem cert_e1209571622134 : check e1209571622134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571629934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e1209571629934 : Closed e1209571629934 ∧ code e1209571629934 = 5607618141038 := by decide
theorem cert_e1209571629934 : check e1209571629934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571629942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e1209571629942 : Closed e1209571629942 ∧ code e1209571629942 = 5607618141046 := by decide
theorem cert_e1209571629942 : check e1209571629942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571630006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e1209571630006 : Closed e1209571630006 ∧ code e1209571630006 = 5607618141110 := by decide
theorem cert_e1209571630006 : check e1209571630006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571630446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e1209571630446 : Closed e1209571630446 ∧ code e1209571630446 = 5607618141550 := by decide
theorem cert_e1209571630446 : check e1209571630446 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571630454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e1209571630454 : Closed e1209571630454 ∧ code e1209571630454 = 5607618141558 := by decide
theorem cert_e1209571630454 : check e1209571630454 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571630510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e1209571630510 : Closed e1209571630510 ∧ code e1209571630510 = 5607618141614 := by decide
theorem cert_e1209571630510 : check e1209571630510 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571630522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e1209571630522 : Closed e1209571630522 ∧ code e1209571630522 = 5607618141626 := by decide
theorem cert_e1209571630522 : check e1209571630522 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571630550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e1209571630550 : Closed e1209571630550 ∧ code e1209571630550 = 5607618141654 := by decide
theorem cert_e1209571630550 : check e1209571630550 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571630554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e1209571630554 : Closed e1209571630554 ∧ code e1209571630554 = 5607618141658 := by decide
theorem cert_e1209571630554 : check e1209571630554 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571630774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1209571630774 : Closed e1209571630774 ∧ code e1209571630774 = 5607618141878 := by decide
theorem cert_e1209571630774 : check e1209571630774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571630806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1209571630806 : Closed e1209571630806 ∧ code e1209571630806 = 5607618141910 := by decide
theorem cert_e1209571630806 : check e1209571630806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571630810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1209571630810 : Closed e1209571630810 ∧ code e1209571630810 = 5607618141914 := by decide
theorem cert_e1209571630810 : check e1209571630810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571633006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e1209571633006 : Closed e1209571633006 ∧ code e1209571633006 = 5607618144110 := by decide
theorem cert_e1209571633006 : check e1209571633006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571633014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1209571633014 : Closed e1209571633014 ∧ code e1209571633014 = 5607618144118 := by decide
theorem cert_e1209571633014 : check e1209571633014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571633078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1209571633078 : Closed e1209571633078 ∧ code e1209571633078 = 5607618144182 := by decide
theorem cert_e1209571633078 : check e1209571633078 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1209571634414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571634414 : Closed e1209571634414 ∧ code e1209571634414 = 5607618145518 := by decide
theorem cert_e1209571634414 : check e1209571634414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571634422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571634422 : Closed e1209571634422 ∧ code e1209571634422 = 5607618145526 := by decide
theorem cert_e1209571634422 : check e1209571634422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e1209571634806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1209571634806 : Closed e1209571634806 ∧ code e1209571634806 = 5607618145910 := by decide
theorem cert_e1209571634806 : check e1209571634806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571635694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e1209571635694 : Closed e1209571635694 ∧ code e1209571635694 = 5607618146798 := by decide
theorem cert_e1209571635694 : check e1209571635694 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1209571636078 : Closed e1209571636078 ∧ code e1209571636078 = 5607618147182 := by decide
theorem cert_e1209571636078 : check e1209571636078 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e1209571636086 : Closed e1209571636086 ∧ code e1209571636086 = 5607618147190 := by decide
theorem cert_e1209571636086 : check e1209571636086 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1209571636142 : Closed e1209571636142 ∧ code e1209571636142 = 5607618147246 := by decide
theorem cert_e1209571636142 : check e1209571636142 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1209571636154 : Closed e1209571636154 ∧ code e1209571636154 = 5607618147258 := by decide
theorem cert_e1209571636154 : check e1209571636154 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e1209571636182 : Closed e1209571636182 ∧ code e1209571636182 = 5607618147286 := by decide
theorem cert_e1209571636182 : check e1209571636182 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1209571636186 : Closed e1209571636186 ∧ code e1209571636186 = 5607618147290 := by decide
theorem cert_e1209571636186 : check e1209571636186 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e1209571636462 : Closed e1209571636462 ∧ code e1209571636462 = 5607618147566 := by decide
theorem cert_e1209571636462 : check e1209571636462 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e1209571636470 : Closed e1209571636470 ∧ code e1209571636470 = 5607618147574 := by decide
theorem cert_e1209571636470 : check e1209571636470 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571636846 : Closed e1209571636846 ∧ code e1209571636846 = 5607618147950 := by decide
theorem cert_e1209571636846 : check e1209571636846 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571636858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1209571636858 : Closed e1209571636858 ∧ code e1209571636858 = 5607618147962 := by decide
theorem cert_e1209571636858 : check e1209571636858 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571637022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e1209571637022 : Closed e1209571637022 ∧ code e1209571637022 = 5607618148126 := by decide
theorem cert_e1209571637022 : check e1209571637022 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571637046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571637046 : Closed e1209571637046 ∧ code e1209571637046 = 5607618148150 := by decide
theorem cert_e1209571637046 : check e1209571637046 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571637050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571637050 : Closed e1209571637050 ∧ code e1209571637050 = 5607618148154 := by decide
theorem cert_e1209571637050 : check e1209571637050 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571637486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1209571637486 : Closed e1209571637486 ∧ code e1209571637486 = 5607618148590 := by decide
theorem cert_e1209571637486 : check e1209571637486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e1209571637494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1209571637494 : Closed e1209571637494 ∧ code e1209571637494 = 5607618148598 := by decide
theorem cert_e1209571637494 : checkPay e1209571637494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e1209571637686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1209571637686 : Closed e1209571637686 ∧ code e1209571637686 = 5607618148790 := by decide
theorem cert_e1209571637686 : checkPay e1209571637686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[]] = true := by decide
def e1209571637718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1209571637718 : Closed e1209571637718 ∧ code e1209571637718 = 5607618148822 := by decide
theorem cert_e1209571637718 : checkPay e1209571637718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e1209571637722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1209571637722 : Closed e1209571637722 ∧ code e1209571637722 = 5607618148826 := by decide
theorem cert_e1209571637722 : check e1209571637722 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571637878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1209571637878 : Closed e1209571637878 ∧ code e1209571637878 = 5607618148982 := by decide
theorem cert_e1209571637878 : check e1209571637878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571638046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1209571638046 : Closed e1209571638046 ∧ code e1209571638046 = 5607618149150 := by decide
theorem cert_e1209571638046 : check e1209571638046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e1209571638070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1209571638070 : Closed e1209571638070 ∧ code e1209571638070 = 5607618149174 := by decide
theorem cert_e1209571638070 : check e1209571638070 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1209571638074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1209571638074 : Closed e1209571638074 ∧ code e1209571638074 = 5607618149178 := by decide
theorem cert_e1209571638074 : check e1209571638074 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571638158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1209571638158 : Closed e1209571638158 ∧ code e1209571638158 = 5607618149262 := by decide
theorem cert_e1209571638158 : check e1209571638158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571645294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1209571645294 : Closed e1209571645294 ∧ code e1209571645294 = 5607618156398 := by decide
theorem cert_e1209571645294 : check e1209571645294 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571645302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1209571645302 : Closed e1209571645302 ∧ code e1209571645302 = 5607618156406 := by decide
theorem cert_e1209571645302 : check e1209571645302 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571645366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1209571645366 : Closed e1209571645366 ∧ code e1209571645366 = 5607618156470 := by decide
theorem cert_e1209571645366 : check e1209571645366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571646702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1209571646702 : Closed e1209571646702 ∧ code e1209571646702 = 5607618157806 := by decide
theorem cert_e1209571646702 : check e1209571646702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571646710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1209571646710 : Closed e1209571646710 ∧ code e1209571646710 = 5607618157814 := by decide
theorem cert_e1209571646710 : check e1209571646710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571647094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1209571647094 : Closed e1209571647094 ∧ code e1209571647094 = 5607618158198 := by decide
theorem cert_e1209571647094 : check e1209571647094 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571656670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1209571656670 : Closed e1209571656670 ∧ code e1209571656670 = 5607618167774 := by decide
theorem cert_e1209571656670 : check e1209571656670 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571656686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1209571656686 : Closed e1209571656686 ∧ code e1209571656686 = 5607618167790 := by decide
theorem cert_e1209571656686 : check e1209571656686 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209571658606 : Closed e1209571658606 ∧ code e1209571658606 = 5607618169710 := by decide
theorem cert_e1209571658606 : check e1209571658606 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209571658614 : Closed e1209571658614 ∧ code e1209571658614 = 5607618169718 := by decide
theorem cert_e1209571658614 : check e1209571658614 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209571658670 : Closed e1209571658670 ∧ code e1209571658670 = 5607618169774 := by decide
theorem cert_e1209571658670 : check e1209571658670 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209571658682 : Closed e1209571658682 ∧ code e1209571658682 = 5607618169786 := by decide
theorem cert_e1209571658682 : check e1209571658682 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209571658710 : Closed e1209571658710 ∧ code e1209571658710 = 5607618169814 := by decide
theorem cert_e1209571658710 : check e1209571658710 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209571658714 : Closed e1209571658714 ∧ code e1209571658714 = 5607618169818 := by decide
theorem cert_e1209571658714 : check e1209571658714 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209571658990 : Closed e1209571658990 ∧ code e1209571658990 = 5607618170094 := by decide
theorem cert_e1209571658990 : check e1209571658990 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571658998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209571658998 : Closed e1209571658998 ∧ code e1209571658998 = 5607618170102 := by decide
theorem cert_e1209571658998 : check e1209571658998 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571659374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209571659374 : Closed e1209571659374 ∧ code e1209571659374 = 5607618170478 := by decide
theorem cert_e1209571659374 : check e1209571659374 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571659386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209571659386 : Closed e1209571659386 ∧ code e1209571659386 = 5607618170490 := by decide
theorem cert_e1209571659386 : check e1209571659386 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571659550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1209571659550 : Closed e1209571659550 ∧ code e1209571659550 = 5607618170654 := by decide
theorem cert_e1209571659550 : check e1209571659550 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571659574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571659574 : Closed e1209571659574 ∧ code e1209571659574 = 5607618170678 := by decide
theorem cert_e1209571659574 : check e1209571659574 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571659578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571659578 : Closed e1209571659578 ∧ code e1209571659578 = 5607618170682 := by decide
theorem cert_e1209571659578 : check e1209571659578 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e1209571664366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1209571664366 : Closed e1209571664366 ∧ code e1209571664366 = 5607618175470 := by decide
theorem cert_e1209571664366 : check e1209571664366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1209571665334 : Closed e1209571665334 ∧ code e1209571665334 = 5607618176438 := by decide
theorem cert_e1209571665334 : check e1209571665334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1209571665366 : Closed e1209571665366 ∧ code e1209571665366 = 5607618176470 := by decide
theorem cert_e1209571665366 : check e1209571665366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1209571665370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1209571665370 : Closed e1209571665370 ∧ code e1209571665370 = 5607618176474 := by decide
theorem cert_e1209571665370 : check e1209571665370 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1209571665526 : Closed e1209571665526 ∧ code e1209571665526 = 5607618176630 := by decide
theorem cert_e1209571665526 : check e1209571665526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1209571665694 : Closed e1209571665694 ∧ code e1209571665694 = 5607618176798 := by decide
theorem cert_e1209571665694 : check e1209571665694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1209571665718 : Closed e1209571665718 ∧ code e1209571665718 = 5607618176822 := by decide
theorem cert_e1209571665718 : check e1209571665718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1209571665722 : Closed e1209571665722 ∧ code e1209571665722 = 5607618176826 := by decide
theorem cert_e1209571665722 : check e1209571665722 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1209571665806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1209571665806 : Closed e1209571665806 ∧ code e1209571665806 = 5607618176910 := by decide
theorem cert_e1209571665806 : check e1209571665806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1209571675886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e1209571675886 : Closed e1209571675886 ∧ code e1209571675886 = 5607618186990 := by decide
theorem cert_e1209571675886 : checkPay e1209571675886 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e1209571675894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e1209571675894 : Closed e1209571675894 ∧ code e1209571675894 = 5607618186998 := by decide
theorem cert_e1209571675894 : checkPay e1209571675894 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.under,.left],[.under,.under,.under,.left,.left]] = true := by decide
def e1209571676014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e1209571676014 : Closed e1209571676014 ∧ code e1209571676014 = 5607618187118 := by decide
theorem cert_e1209571676014 : checkPay e1209571676014 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571676026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e1209571676026 : Closed e1209571676026 ∧ code e1209571676026 = 5607618187130 := by decide
theorem cert_e1209571676026 : checkPay e1209571676026 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e1209571676086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e1209571676086 : Closed e1209571676086 ∧ code e1209571676086 = 5607618187190 := by decide
theorem cert_e1209571676086 : checkPay e1209571676086 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e1209571676090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e1209571676090 : Closed e1209571676090 ∧ code e1209571676090 = 5607618187194 := by decide
theorem cert_e1209571676090 : checkPay e1209571676090 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.under,.left,.right,.under]] = true := by decide
def e1209571678702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e1209571678702 : Closed e1209571678702 ∧ code e1209571678702 = 5607618189806 := by decide
theorem cert_e1209571678702 : checkPay e1209571678702 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1209571679854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e1209571679854 : Closed e1209571679854 ∧ code e1209571679854 = 5607618190958 := by decide
theorem cert_e1209571679854 : checkPay e1209571679854 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
end Blc.Floor42
