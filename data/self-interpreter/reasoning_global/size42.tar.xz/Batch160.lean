import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186870710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211186870710 : Closed e1211186870710 ∧ code e1211186870710 = 5609233381814 := by decide
theorem cert_e1211186870710 : check e1211186870710 [[],[]] .three = true := by decide
def e1211186870714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211186870714 : Closed e1211186870714 ∧ code e1211186870714 = 5609233381818 := by decide
theorem cert_e1211186870714 : check e1211186870714 [[],[]] .three = true := by decide
def e1211186870742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211186870742 : Closed e1211186870742 ∧ code e1211186870742 = 5609233381846 := by decide
theorem cert_e1211186870742 : check e1211186870742 [[],[]] .three = true := by decide
def e1211186870746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211186870746 : Closed e1211186870746 ∧ code e1211186870746 = 5609233381850 := by decide
theorem cert_e1211186870746 : check e1211186870746 [[],[]] .three = true := by decide
def e1211186870762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211186870762 : Closed e1211186870762 ∧ code e1211186870762 = 5609233381866 := by decide
theorem cert_e1211186870762 : check e1211186870762 [[],[]] .three = true := by decide
def e1211186870798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211186870798 : Closed e1211186870798 ∧ code e1211186870798 = 5609233381902 := by decide
theorem cert_e1211186870798 : check e1211186870798 [[],[]] .three = true := by decide
def e1211186870810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1211186870810 : Closed e1211186870810 ∧ code e1211186870810 = 5609233381914 := by decide
theorem cert_e1211186870810 : check e1211186870810 [[],[]] .three = true := by decide
def e1211186870846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 4))))))))
theorem wire_e1211186870846 : Closed e1211186870846 ∧ code e1211186870846 = 5609233381950 := by decide
theorem cert_e1211186870846 : check e1211186870846 [[],[]] .three = true := by decide
def e1211186870882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211186870882 : Closed e1211186870882 ∧ code e1211186870882 = 5609233381986 := by decide
theorem cert_e1211186870882 : check e1211186870882 [[],[]] .three = true := by decide
def e1211186870894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186870894 : Closed e1211186870894 ∧ code e1211186870894 = 5609233381998 := by decide
theorem cert_e1211186870894 : check e1211186870894 [[],[]] .three = true := by decide
def e1211186870902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211186870902 : Closed e1211186870902 ∧ code e1211186870902 = 5609233382006 := by decide
theorem cert_e1211186870902 : check e1211186870902 [[],[]] .three = true := by decide
def e1211186870906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186870906 : Closed e1211186870906 ∧ code e1211186870906 = 5609233382010 := by decide
theorem cert_e1211186870906 : check e1211186870906 [[],[]] .three = true := by decide
def e1211186871070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211186871070 : Closed e1211186871070 ∧ code e1211186871070 = 5609233382174 := by decide
theorem cert_e1211186871070 : check e1211186871070 [[],[]] .three = true := by decide
def e1211186871094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211186871094 : Closed e1211186871094 ∧ code e1211186871094 = 5609233382198 := by decide
theorem cert_e1211186871094 : check e1211186871094 [[],[]] .three = true := by decide
def e1211186871098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211186871098 : Closed e1211186871098 ∧ code e1211186871098 = 5609233382202 := by decide
theorem cert_e1211186871098 : check e1211186871098 [[],[]] .three = true := by decide
def e1211186871182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211186871182 : Closed e1211186871182 ∧ code e1211186871182 = 5609233382286 := by decide
theorem cert_e1211186871182 : check e1211186871182 [[],[]] .three = true := by decide
def e1211186871194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186871194 : Closed e1211186871194 ∧ code e1211186871194 = 5609233382298 := by decide
theorem cert_e1211186871194 : check e1211186871194 [[],[]] .three = true := by decide
def e1211186871238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.lam (.var 1))))))))
theorem wire_e1211186871238 : Closed e1211186871238 ∧ code e1211186871238 = 5609233382342 := by decide
theorem cert_e1211186871238 : check e1211186871238 [[],[]] .three = true := by decide
def e1211186875230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211186875230 : Closed e1211186875230 ∧ code e1211186875230 = 5609233386334 := by decide
theorem cert_e1211186875230 : check e1211186875230 [[],[]] .smaller = true := by decide
def e1211186875246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211186875246 : Closed e1211186875246 ∧ code e1211186875246 = 5609233386350 := by decide
theorem cert_e1211186875246 : check e1211186875246 [[],[]] .smaller = true := by decide
def e1211186875254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211186875254 : Closed e1211186875254 ∧ code e1211186875254 = 5609233386358 := by decide
theorem cert_e1211186875254 : check e1211186875254 [[],[]] .smaller = true := by decide
def e1211186875258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211186875258 : Closed e1211186875258 ∧ code e1211186875258 = 5609233386362 := by decide
theorem cert_e1211186875258 : check e1211186875258 [[],[]] .smaller = true := by decide
def e1211186875310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211186875310 : Closed e1211186875310 ∧ code e1211186875310 = 5609233386414 := by decide
theorem cert_e1211186875310 : check e1211186875310 [[],[]] .smaller = true := by decide
def e1211186875322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211186875322 : Closed e1211186875322 ∧ code e1211186875322 = 5609233386426 := by decide
theorem cert_e1211186875322 : check e1211186875322 [[],[]] .smaller = true := by decide
def e1211186875350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211186875350 : Closed e1211186875350 ∧ code e1211186875350 = 5609233386454 := by decide
theorem cert_e1211186875350 : check e1211186875350 [[],[]] .smaller = true := by decide
def e1211186875354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211186875354 : Closed e1211186875354 ∧ code e1211186875354 = 5609233386458 := by decide
theorem cert_e1211186875354 : check e1211186875354 [[],[]] .smaller = true := by decide
def e1211186875370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211186875370 : Closed e1211186875370 ∧ code e1211186875370 = 5609233386474 := by decide
theorem cert_e1211186875370 : check e1211186875370 [[],[]] .smaller = true := by decide
def e1211186875614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211186875614 : Closed e1211186875614 ∧ code e1211186875614 = 5609233386718 := by decide
theorem cert_e1211186875614 : check e1211186875614 [[],[]] .smaller = true := by decide
def e1211186875630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211186875630 : Closed e1211186875630 ∧ code e1211186875630 = 5609233386734 := by decide
theorem cert_e1211186875630 : check e1211186875630 [[],[]] .smaller = true := by decide
def e1211186875638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211186875638 : Closed e1211186875638 ∧ code e1211186875638 = 5609233386742 := by decide
theorem cert_e1211186875638 : check e1211186875638 [[],[]] .smaller = true := by decide
def e1211186875642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211186875642 : Closed e1211186875642 ∧ code e1211186875642 = 5609233386746 := by decide
theorem cert_e1211186875642 : check e1211186875642 [[],[]] .smaller = true := by decide
def e1211186875966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1211186875966 : Closed e1211186875966 ∧ code e1211186875966 = 5609233387070 := by decide
theorem cert_e1211186875966 : check e1211186875966 [[],[]] .smaller = true := by decide
def e1211186876014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211186876014 : Closed e1211186876014 ∧ code e1211186876014 = 5609233387118 := by decide
theorem cert_e1211186876014 : check e1211186876014 [[],[]] .smaller = true := by decide
def e1211186876026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211186876026 : Closed e1211186876026 ∧ code e1211186876026 = 5609233387130 := by decide
theorem cert_e1211186876026 : check e1211186876026 [[],[]] .smaller = true := by decide
def e1211186876214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186876214 : Closed e1211186876214 ∧ code e1211186876214 = 5609233387318 := by decide
theorem cert_e1211186876214 : check e1211186876214 [[],[]] .smaller = true := by decide
def e1211186876218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186876218 : Closed e1211186876218 ∧ code e1211186876218 = 5609233387322 := by decide
theorem cert_e1211186876218 : check e1211186876218 [[],[]] .smaller = true := by decide
def e1211186876302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211186876302 : Closed e1211186876302 ∧ code e1211186876302 = 5609233387406 := by decide
theorem cert_e1211186876302 : check e1211186876302 [[],[]] .smaller = true := by decide
def e1211186876314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186876314 : Closed e1211186876314 ∧ code e1211186876314 = 5609233387418 := by decide
theorem cert_e1211186876314 : check e1211186876314 [[],[]] .smaller = true := by decide
def e1211186883678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))))))))
theorem wire_e1211186883678 : Closed e1211186883678 ∧ code e1211186883678 = 5609233394782 := by decide
theorem cert_e1211186883678 : check e1211186883678 [[],[]] .three = true := by decide
def e1211186883694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211186883694 : Closed e1211186883694 ∧ code e1211186883694 = 5609233394798 := by decide
theorem cert_e1211186883694 : check e1211186883694 [[],[]] .smaller = true := by decide
def e1211186883706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211186883706 : Closed e1211186883706 ∧ code e1211186883706 = 5609233394810 := by decide
theorem cert_e1211186883706 : check e1211186883706 [[],[]] .smaller = true := by decide
def e1211186883870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211186883870 : Closed e1211186883870 ∧ code e1211186883870 = 5609233394974 := by decide
theorem cert_e1211186883870 : check e1211186883870 [[],[]] .smaller = true := by decide
def e1211186884038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211186884038 : Closed e1211186884038 ∧ code e1211186884038 = 5609233395142 := by decide
theorem cert_e1211186884038 : check e1211186884038 [[],[]] .smaller = true := by decide
def e1211186884062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1211186884062 : Closed e1211186884062 ∧ code e1211186884062 = 5609233395166 := by decide
theorem cert_e1211186884062 : check e1211186884062 [[],[]] .three = true := by decide
def e1211186884066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e1211186884066 : Closed e1211186884066 ∧ code e1211186884066 = 5609233395170 := by decide
theorem cert_e1211186884066 : check e1211186884066 [[],[]] .three = true := by decide
def e1211186884078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1211186884078 : Closed e1211186884078 ∧ code e1211186884078 = 5609233395182 := by decide
theorem cert_e1211186884078 : check e1211186884078 [[],[]] .three = true := by decide
def e1211186884142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211186884142 : Closed e1211186884142 ∧ code e1211186884142 = 5609233395246 := by decide
theorem cert_e1211186884142 : check e1211186884142 [[],[]] .smaller = true := by decide
def e1211186884318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e1211186884318 : Closed e1211186884318 ∧ code e1211186884318 = 5609233395422 := by decide
theorem cert_e1211186884318 : check e1211186884318 [[],[]] .three = true := by decide
def e1211186884322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211186884322 : Closed e1211186884322 ∧ code e1211186884322 = 5609233395426 := by decide
theorem cert_e1211186884322 : check e1211186884322 [[],[]] .smaller = true := by decide
def e1211186884334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e1211186884334 : Closed e1211186884334 ∧ code e1211186884334 = 5609233395438 := by decide
theorem cert_e1211186884334 : check e1211186884334 [[],[]] .smaller = true := by decide
def e1211186884342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e1211186884342 : Closed e1211186884342 ∧ code e1211186884342 = 5609233395446 := by decide
theorem cert_e1211186884342 : check e1211186884342 [[],[]] .three = true := by decide
def e1211186884374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186884374 : Closed e1211186884374 ∧ code e1211186884374 = 5609233395478 := by decide
theorem cert_e1211186884374 : check e1211186884374 [[],[]] .smaller = true := by decide
def e1211186884378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211186884378 : Closed e1211186884378 ∧ code e1211186884378 = 5609233395482 := by decide
theorem cert_e1211186884378 : check e1211186884378 [[],[]] .smaller = true := by decide
def e1211186884422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211186884422 : Closed e1211186884422 ∧ code e1211186884422 = 5609233395526 := by decide
theorem cert_e1211186884422 : check e1211186884422 [[],[]] .smaller = true := by decide
def e1211186884446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1211186884446 : Closed e1211186884446 ∧ code e1211186884446 = 5609233395550 := by decide
theorem cert_e1211186884446 : check e1211186884446 [[],[]] .three = true := by decide
def e1211186884450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186884450 : Closed e1211186884450 ∧ code e1211186884450 = 5609233395554 := by decide
theorem cert_e1211186884450 : check e1211186884450 [[],[]] .smaller = true := by decide
def e1211186884462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e1211186884462 : Closed e1211186884462 ∧ code e1211186884462 = 5609233395566 := by decide
theorem cert_e1211186884462 : check e1211186884462 [[],[]] .smaller = true := by decide
def e1211186884470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e1211186884470 : Closed e1211186884470 ∧ code e1211186884470 = 5609233395574 := by decide
theorem cert_e1211186884470 : check e1211186884470 [[],[]] .smaller = true := by decide
def e1211186884474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1211186884474 : Closed e1211186884474 ∧ code e1211186884474 = 5609233395578 := by decide
theorem cert_e1211186884474 : check e1211186884474 [[],[]] .three = true := by decide
def e1211186884490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186884490 : Closed e1211186884490 ∧ code e1211186884490 = 5609233395594 := by decide
theorem cert_e1211186884490 : check e1211186884490 [[],[]] .three = true := by decide
def e1211186884514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186884514 : Closed e1211186884514 ∧ code e1211186884514 = 5609233395618 := by decide
theorem cert_e1211186884514 : check e1211186884514 [[],[]] .three = true := by decide
def e1211186884526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1211186884526 : Closed e1211186884526 ∧ code e1211186884526 = 5609233395630 := by decide
theorem cert_e1211186884526 : check e1211186884526 [[],[]] .three = true := by decide
def e1211186884534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e1211186884534 : Closed e1211186884534 ∧ code e1211186884534 = 5609233395638 := by decide
theorem cert_e1211186884534 : check e1211186884534 [[],[]] .three = true := by decide
def e1211186884538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1211186884538 : Closed e1211186884538 ∧ code e1211186884538 = 5609233395642 := by decide
theorem cert_e1211186884538 : check e1211186884538 [[],[]] .three = true := by decide
def e1211186884734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 5))))))))))
theorem wire_e1211186884734 : Closed e1211186884734 ∧ code e1211186884734 = 5609233395838 := by decide
theorem cert_e1211186884734 : check e1211186884734 [[],[]] .three = true := by decide
def e1211186884830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e1211186884830 : Closed e1211186884830 ∧ code e1211186884830 = 5609233395934 := by decide
theorem cert_e1211186884830 : check e1211186884830 [[],[]] .smaller = true := by decide
def e1211186884858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e1211186884858 : Closed e1211186884858 ∧ code e1211186884858 = 5609233395962 := by decide
theorem cert_e1211186884858 : check e1211186884858 [[],[]] .smaller = true := by decide
def e1211186885406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211186885406 : Closed e1211186885406 ∧ code e1211186885406 = 5609233396510 := by decide
theorem cert_e1211186885406 : check e1211186885406 [[],[]] .smaller = true := by decide
def e1211186885574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211186885574 : Closed e1211186885574 ∧ code e1211186885574 = 5609233396678 := by decide
theorem cert_e1211186885574 : check e1211186885574 [[],[]] .smaller = true := by decide
def e1211186885598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211186885598 : Closed e1211186885598 ∧ code e1211186885598 = 5609233396702 := by decide
theorem cert_e1211186885598 : check e1211186885598 [[],[]] .three = true := by decide
def e1211186885602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211186885602 : Closed e1211186885602 ∧ code e1211186885602 = 5609233396706 := by decide
theorem cert_e1211186885602 : check e1211186885602 [[],[]] .three = true := by decide
def e1211186885614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211186885614 : Closed e1211186885614 ∧ code e1211186885614 = 5609233396718 := by decide
theorem cert_e1211186885614 : check e1211186885614 [[],[]] .three = true := by decide
def e1211186886718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e1211186886718 : Closed e1211186886718 ∧ code e1211186886718 = 5609233397822 := by decide
theorem cert_e1211186886718 : check e1211186886718 [[],[]] .smaller = true := by decide
def e1211186887134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186887134 : Closed e1211186887134 ∧ code e1211186887134 = 5609233398238 := by decide
theorem cert_e1211186887134 : check e1211186887134 [[],[]] .three = true := by decide
def e1211186887138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211186887138 : Closed e1211186887138 ∧ code e1211186887138 = 5609233398242 := by decide
theorem cert_e1211186887138 : check e1211186887138 [[],[]] .smaller = true := by decide
def e1211186887150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211186887150 : Closed e1211186887150 ∧ code e1211186887150 = 5609233398254 := by decide
theorem cert_e1211186887150 : check e1211186887150 [[],[]] .smaller = true := by decide
def e1211186887158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186887158 : Closed e1211186887158 ∧ code e1211186887158 = 5609233398262 := by decide
theorem cert_e1211186887158 : check e1211186887158 [[],[]] .three = true := by decide
def e1211186887710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186887710 : Closed e1211186887710 ∧ code e1211186887710 = 5609233398814 := by decide
theorem cert_e1211186887710 : check e1211186887710 [[],[]] .smaller = true := by decide
def e1211186887734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186887734 : Closed e1211186887734 ∧ code e1211186887734 = 5609233398838 := by decide
theorem cert_e1211186887734 : check e1211186887734 [[],[]] .smaller = true := by decide
def e1211186887738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186887738 : Closed e1211186887738 ∧ code e1211186887738 = 5609233398842 := by decide
theorem cert_e1211186887738 : check e1211186887738 [[],[]] .smaller = true := by decide
def e1211186887878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211186887878 : Closed e1211186887878 ∧ code e1211186887878 = 5609233398982 := by decide
theorem cert_e1211186887878 : check e1211186887878 [[],[]] .smaller = true := by decide
def e1211186887902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186887902 : Closed e1211186887902 ∧ code e1211186887902 = 5609233399006 := by decide
theorem cert_e1211186887902 : check e1211186887902 [[],[]] .three = true := by decide
def e1211186887906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186887906 : Closed e1211186887906 ∧ code e1211186887906 = 5609233399010 := by decide
theorem cert_e1211186887906 : check e1211186887906 [[],[]] .smaller = true := by decide
def e1211186887918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186887918 : Closed e1211186887918 ∧ code e1211186887918 = 5609233399022 := by decide
theorem cert_e1211186887918 : check e1211186887918 [[],[]] .smaller = true := by decide
def e1211186887926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186887926 : Closed e1211186887926 ∧ code e1211186887926 = 5609233399030 := by decide
theorem cert_e1211186887926 : check e1211186887926 [[],[]] .smaller = true := by decide
def e1211186887930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186887930 : Closed e1211186887930 ∧ code e1211186887930 = 5609233399034 := by decide
theorem cert_e1211186887930 : check e1211186887930 [[],[]] .three = true := by decide
def e1211186888206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186888206 : Closed e1211186888206 ∧ code e1211186888206 = 5609233399310 := by decide
theorem cert_e1211186888206 : check e1211186888206 [[],[]] .three = true := by decide
def e1211186888218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186888218 : Closed e1211186888218 ∧ code e1211186888218 = 5609233399322 := by decide
theorem cert_e1211186888218 : check e1211186888218 [[],[]] .three = true := by decide
def e1211186888254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 4)))))))))
theorem wire_e1211186888254 : Closed e1211186888254 ∧ code e1211186888254 = 5609233399358 := by decide
theorem cert_e1211186888254 : check e1211186888254 [[],[]] .three = true := by decide
def e1211186888290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186888290 : Closed e1211186888290 ∧ code e1211186888290 = 5609233399394 := by decide
theorem cert_e1211186888290 : check e1211186888290 [[],[]] .three = true := by decide
def e1211186888302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186888302 : Closed e1211186888302 ∧ code e1211186888302 = 5609233399406 := by decide
theorem cert_e1211186888302 : check e1211186888302 [[],[]] .three = true := by decide
def e1211186888310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211186888310 : Closed e1211186888310 ∧ code e1211186888310 = 5609233399414 := by decide
theorem cert_e1211186888310 : check e1211186888310 [[],[]] .three = true := by decide
def e1211186888314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186888314 : Closed e1211186888314 ∧ code e1211186888314 = 5609233399418 := by decide
theorem cert_e1211186888314 : check e1211186888314 [[],[]] .three = true := by decide
def e1211186910766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e1211186910766 : Closed e1211186910766 ∧ code e1211186910766 = 5609233421870 := by decide
theorem cert_e1211186910766 : check e1211186910766 [[],[]] .smaller = true := by decide
def e1211186910942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211186910942 : Closed e1211186910942 ∧ code e1211186910942 = 5609233422046 := by decide
theorem cert_e1211186910942 : check e1211186910942 [[],[]] .three = true := by decide
def e1211186910946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e1211186910946 : Closed e1211186910946 ∧ code e1211186910946 = 5609233422050 := by decide
theorem cert_e1211186910946 : check e1211186910946 [[],[]] .smaller = true := by decide
def e1211186910958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1211186910958 : Closed e1211186910958 ∧ code e1211186910958 = 5609233422062 := by decide
theorem cert_e1211186910958 : check e1211186910958 [[],[]] .smaller = true := by decide
def e1211186910966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211186910966 : Closed e1211186910966 ∧ code e1211186910966 = 5609233422070 := by decide
theorem cert_e1211186910966 : check e1211186910966 [[],[]] .three = true := by decide
def e1211186911070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211186911070 : Closed e1211186911070 ∧ code e1211186911070 = 5609233422174 := by decide
theorem cert_e1211186911070 : check e1211186911070 [[],[]] .three = true := by decide
def e1211186911098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211186911098 : Closed e1211186911098 ∧ code e1211186911098 = 5609233422202 := by decide
theorem cert_e1211186911098 : check e1211186911098 [[],[]] .three = true := by decide
def e1211186911114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186911114 : Closed e1211186911114 ∧ code e1211186911114 = 5609233422218 := by decide
theorem cert_e1211186911114 : check e1211186911114 [[],[]] .smaller = true := by decide
def e1211186911138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186911138 : Closed e1211186911138 ∧ code e1211186911138 = 5609233422242 := by decide
theorem cert_e1211186911138 : check e1211186911138 [[],[]] .smaller = true := by decide
def e1211186911150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1211186911150 : Closed e1211186911150 ∧ code e1211186911150 = 5609233422254 := by decide
theorem cert_e1211186911150 : check e1211186911150 [[],[]] .smaller = true := by decide
def e1211186911162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1211186911162 : Closed e1211186911162 ∧ code e1211186911162 = 5609233422266 := by decide
theorem cert_e1211186911162 : check e1211186911162 [[],[]] .smaller = true := by decide
def e1211186911190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211186911190 : Closed e1211186911190 ∧ code e1211186911190 = 5609233422294 := by decide
theorem cert_e1211186911190 : check e1211186911190 [[],[]] .three = true := by decide
def e1211186911194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211186911194 : Closed e1211186911194 ∧ code e1211186911194 = 5609233422298 := by decide
theorem cert_e1211186911194 : check e1211186911194 [[],[]] .three = true := by decide
def e1211186911294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e1211186911294 : Closed e1211186911294 ∧ code e1211186911294 = 5609233422398 := by decide
theorem cert_e1211186911294 : check e1211186911294 [[],[]] .smaller = true := by decide
def e1211186911710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211186911710 : Closed e1211186911710 ∧ code e1211186911710 = 5609233422814 := by decide
theorem cert_e1211186911710 : check e1211186911710 [[],[]] .three = true := by decide
def e1211186911714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211186911714 : Closed e1211186911714 ∧ code e1211186911714 = 5609233422818 := by decide
theorem cert_e1211186911714 : check e1211186911714 [[],[]] .smaller = true := by decide
def e1211186911726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211186911726 : Closed e1211186911726 ∧ code e1211186911726 = 5609233422830 := by decide
theorem cert_e1211186911726 : check e1211186911726 [[],[]] .smaller = true := by decide
def e1211186911734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211186911734 : Closed e1211186911734 ∧ code e1211186911734 = 5609233422838 := by decide
theorem cert_e1211186911734 : check e1211186911734 [[],[]] .three = true := by decide
def e1211186912478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186912478 : Closed e1211186912478 ∧ code e1211186912478 = 5609233423582 := by decide
theorem cert_e1211186912478 : check e1211186912478 [[],[]] .three = true := by decide
def e1211186912506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186912506 : Closed e1211186912506 ∧ code e1211186912506 = 5609233423610 := by decide
theorem cert_e1211186912506 : check e1211186912506 [[],[]] .three = true := by decide
def e1211186912782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186912782 : Closed e1211186912782 ∧ code e1211186912782 = 5609233423886 := by decide
theorem cert_e1211186912782 : check e1211186912782 [[],[]] .smaller = true := by decide
def e1211186912830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e1211186912830 : Closed e1211186912830 ∧ code e1211186912830 = 5609233423934 := by decide
theorem cert_e1211186912830 : check e1211186912830 [[],[]] .three = true := by decide
def e1211186912866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186912866 : Closed e1211186912866 ∧ code e1211186912866 = 5609233423970 := by decide
theorem cert_e1211186912866 : check e1211186912866 [[],[]] .smaller = true := by decide
def e1211186912878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186912878 : Closed e1211186912878 ∧ code e1211186912878 = 5609233423982 := by decide
theorem cert_e1211186912878 : check e1211186912878 [[],[]] .smaller = true := by decide
def e1211186912890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186912890 : Closed e1211186912890 ∧ code e1211186912890 = 5609233423994 := by decide
theorem cert_e1211186912890 : check e1211186912890 [[],[]] .smaller = true := by decide
def e1211186913054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e1211186913054 : Closed e1211186913054 ∧ code e1211186913054 = 5609233424158 := by decide
theorem cert_e1211186913054 : check e1211186913054 [[],[]] .three = true := by decide
def e1211186913078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186913078 : Closed e1211186913078 ∧ code e1211186913078 = 5609233424182 := by decide
theorem cert_e1211186913078 : check e1211186913078 [[],[]] .three = true := by decide
def e1211186913082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186913082 : Closed e1211186913082 ∧ code e1211186913082 = 5609233424186 := by decide
theorem cert_e1211186913082 : check e1211186913082 [[],[]] .three = true := by decide
def e1211186922198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211186922198 : Closed e1211186922198 ∧ code e1211186922198 = 5609233433302 := by decide
theorem cert_e1211186922198 : check e1211186922198 [[],[]] .smaller = true := by decide
def e1211186922202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211186922202 : Closed e1211186922202 ∧ code e1211186922202 = 5609233433306 := by decide
theorem cert_e1211186922202 : check e1211186922202 [[],[]] .smaller = true := by decide
def e1211186922218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211186922218 : Closed e1211186922218 ∧ code e1211186922218 = 5609233433322 := by decide
theorem cert_e1211186922218 : check e1211186922218 [[],[]] .smaller = true := by decide
def e1211186922294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186922294 : Closed e1211186922294 ∧ code e1211186922294 = 5609233433398 := by decide
theorem cert_e1211186922294 : check e1211186922294 [[],[]] .smaller = true := by decide
def e1211186922298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186922298 : Closed e1211186922298 ∧ code e1211186922298 = 5609233433402 := by decide
theorem cert_e1211186922298 : check e1211186922298 [[],[]] .smaller = true := by decide
def e1211186922382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e1211186922382 : Closed e1211186922382 ∧ code e1211186922382 = 5609233433486 := by decide
theorem cert_e1211186922382 : check e1211186922382 [[],[]] .smaller = true := by decide
def e1211186922394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211186922394 : Closed e1211186922394 ∧ code e1211186922394 = 5609233433498 := by decide
theorem cert_e1211186922394 : check e1211186922394 [[],[]] .smaller = true := by decide
def e1211186924310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e1211186924310 : Closed e1211186924310 ∧ code e1211186924310 = 5609233435414 := by decide
theorem cert_e1211186924310 : check e1211186924310 [[],[]] .smaller = true := by decide
def e1211186924314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1211186924314 : Closed e1211186924314 ∧ code e1211186924314 = 5609233435418 := by decide
theorem cert_e1211186924314 : check e1211186924314 [[],[]] .smaller = true := by decide
def e1211186924358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1211186924358 : Closed e1211186924358 ∧ code e1211186924358 = 5609233435462 := by decide
theorem cert_e1211186924358 : check e1211186924358 [[],[]] .smaller = true := by decide
def e1211186924382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e1211186924382 : Closed e1211186924382 ∧ code e1211186924382 = 5609233435486 := by decide
theorem cert_e1211186924382 : check e1211186924382 [[],[]] .three = true := by decide
def e1211186924386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e1211186924386 : Closed e1211186924386 ∧ code e1211186924386 = 5609233435490 := by decide
theorem cert_e1211186924386 : check e1211186924386 [[],[]] .smaller = true := by decide
def e1211186924398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211186924398 : Closed e1211186924398 ∧ code e1211186924398 = 5609233435502 := by decide
theorem cert_e1211186924398 : check e1211186924398 [[],[]] .smaller = true := by decide
def e1211186924406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211186924406 : Closed e1211186924406 ∧ code e1211186924406 = 5609233435510 := by decide
theorem cert_e1211186924406 : check e1211186924406 [[],[]] .smaller = true := by decide
def e1211186924410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e1211186924410 : Closed e1211186924410 ∧ code e1211186924410 = 5609233435514 := by decide
theorem cert_e1211186924410 : check e1211186924410 [[],[]] .three = true := by decide
def e1211186924426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e1211186924426 : Closed e1211186924426 ∧ code e1211186924426 = 5609233435530 := by decide
theorem cert_e1211186924426 : check e1211186924426 [[],[]] .smaller = true := by decide
def e1211186924450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e1211186924450 : Closed e1211186924450 ∧ code e1211186924450 = 5609233435554 := by decide
theorem cert_e1211186924450 : check e1211186924450 [[],[]] .smaller = true := by decide
def e1211186924462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211186924462 : Closed e1211186924462 ∧ code e1211186924462 = 5609233435566 := by decide
theorem cert_e1211186924462 : check e1211186924462 [[],[]] .smaller = true := by decide
def e1211186924474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211186924474 : Closed e1211186924474 ∧ code e1211186924474 = 5609233435578 := by decide
theorem cert_e1211186924474 : check e1211186924474 [[],[]] .smaller = true := by decide
def e1211186924502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211186924502 : Closed e1211186924502 ∧ code e1211186924502 = 5609233435606 := by decide
theorem cert_e1211186924502 : check e1211186924502 [[],[]] .smaller = true := by decide
def e1211186924506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211186924506 : Closed e1211186924506 ∧ code e1211186924506 = 5609233435610 := by decide
theorem cert_e1211186924506 : check e1211186924506 [[],[]] .smaller = true := by decide
def e1211186924522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e1211186924522 : Closed e1211186924522 ∧ code e1211186924522 = 5609233435626 := by decide
theorem cert_e1211186924522 : check e1211186924522 [[],[]] .three = true := by decide
def e1211186924574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e1211186924574 : Closed e1211186924574 ∧ code e1211186924574 = 5609233435678 := by decide
theorem cert_e1211186924574 : check e1211186924574 [[],[]] .smaller = true := by decide
def e1211186924598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211186924598 : Closed e1211186924598 ∧ code e1211186924598 = 5609233435702 := by decide
theorem cert_e1211186924598 : check e1211186924598 [[],[]] .smaller = true := by decide
def e1211186924602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211186924602 : Closed e1211186924602 ∧ code e1211186924602 = 5609233435706 := by decide
theorem cert_e1211186924602 : check e1211186924602 [[],[]] .smaller = true := by decide
def e1211186924742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211186924742 : Closed e1211186924742 ∧ code e1211186924742 = 5609233435846 := by decide
theorem cert_e1211186924742 : check e1211186924742 [[],[]] .smaller = true := by decide
def e1211186924766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186924766 : Closed e1211186924766 ∧ code e1211186924766 = 5609233435870 := by decide
theorem cert_e1211186924766 : check e1211186924766 [[],[]] .three = true := by decide
def e1211186924770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211186924770 : Closed e1211186924770 ∧ code e1211186924770 = 5609233435874 := by decide
theorem cert_e1211186924770 : check e1211186924770 [[],[]] .smaller = true := by decide
def e1211186924782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211186924782 : Closed e1211186924782 ∧ code e1211186924782 = 5609233435886 := by decide
theorem cert_e1211186924782 : check e1211186924782 [[],[]] .smaller = true := by decide
def e1211186924790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211186924790 : Closed e1211186924790 ∧ code e1211186924790 = 5609233435894 := by decide
theorem cert_e1211186924790 : check e1211186924790 [[],[]] .smaller = true := by decide
def e1211186924794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186924794 : Closed e1211186924794 ∧ code e1211186924794 = 5609233435898 := by decide
theorem cert_e1211186924794 : check e1211186924794 [[],[]] .three = true := by decide
def e1211186925070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e1211186925070 : Closed e1211186925070 ∧ code e1211186925070 = 5609233436174 := by decide
theorem cert_e1211186925070 : check e1211186925070 [[],[]] .smaller = true := by decide
def e1211186925118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211186925118 : Closed e1211186925118 ∧ code e1211186925118 = 5609233436222 := by decide
theorem cert_e1211186925118 : check e1211186925118 [[],[]] .three = true := by decide
def e1211186925154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e1211186925154 : Closed e1211186925154 ∧ code e1211186925154 = 5609233436258 := by decide
theorem cert_e1211186925154 : check e1211186925154 [[],[]] .smaller = true := by decide
def e1211186925166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211186925166 : Closed e1211186925166 ∧ code e1211186925166 = 5609233436270 := by decide
theorem cert_e1211186925166 : check e1211186925166 [[],[]] .smaller = true := by decide
def e1211186925178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211186925178 : Closed e1211186925178 ∧ code e1211186925178 = 5609233436282 := by decide
theorem cert_e1211186925178 : check e1211186925178 [[],[]] .smaller = true := by decide
def e1211186925366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186925366 : Closed e1211186925366 ∧ code e1211186925366 = 5609233436470 := by decide
theorem cert_e1211186925366 : check e1211186925366 [[],[]] .smaller = true := by decide
def e1211186925370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186925370 : Closed e1211186925370 ∧ code e1211186925370 = 5609233436474 := by decide
theorem cert_e1211186925370 : check e1211186925370 [[],[]] .smaller = true := by decide
def e1211186925454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211186925454 : Closed e1211186925454 ∧ code e1211186925454 = 5609233436558 := by decide
theorem cert_e1211186925454 : check e1211186925454 [[],[]] .three = true := by decide
end Blc.Floor42
