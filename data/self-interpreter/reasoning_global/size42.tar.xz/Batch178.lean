import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203270074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1211203270074 : Closed e1211203270074 ∧ code e1211203270074 = 5609249781178 := by decide
theorem cert_e1211203270074 : check e1211203270074 [[],[]] .chain = true := by decide
def e1211203270102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1211203270102 : Closed e1211203270102 ∧ code e1211203270102 = 5609249781206 := by decide
theorem cert_e1211203270102 : check e1211203270102 [[],[]] .chain = true := by decide
def e1211203270106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1211203270106 : Closed e1211203270106 ∧ code e1211203270106 = 5609249781210 := by decide
theorem cert_e1211203270106 : check e1211203270106 [[],[]] .chain = true := by decide
def e1211203270318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203270318 : Closed e1211203270318 ∧ code e1211203270318 = 5609249781422 := by decide
theorem cert_e1211203270318 : check e1211203270318 [[],[]] .chain = true := by decide
def e1211203270330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203270330 : Closed e1211203270330 ∧ code e1211203270330 = 5609249781434 := by decide
theorem cert_e1211203270330 : check e1211203270330 [[],[]] .chain = true := by decide
def e1211203270378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203270378 : Closed e1211203270378 ∧ code e1211203270378 = 5609249781482 := by decide
theorem cert_e1211203270378 : check e1211203270378 [[],[]] .chain = true := by decide
def e1211203270486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203270486 : Closed e1211203270486 ∧ code e1211203270486 = 5609249781590 := by decide
theorem cert_e1211203270486 : check e1211203270486 [[],[]] .chain = true := by decide
def e1211203270490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203270490 : Closed e1211203270490 ∧ code e1211203270490 = 5609249781594 := by decide
theorem cert_e1211203270490 : check e1211203270490 [[],[]] .chain = true := by decide
def e1211203270506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203270506 : Closed e1211203270506 ∧ code e1211203270506 = 5609249781610 := by decide
theorem cert_e1211203270506 : check e1211203270506 [[],[]] .chain = true := by decide
def e1211203271342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1211203271342 : Closed e1211203271342 ∧ code e1211203271342 = 5609249782446 := by decide
theorem cert_e1211203271342 : check e1211203271342 [[],[]] .chain = true := by decide
def e1211203271354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1211203271354 : Closed e1211203271354 ∧ code e1211203271354 = 5609249782458 := by decide
theorem cert_e1211203271354 : check e1211203271354 [[],[]] .chain = true := by decide
def e1211203271402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1211203271402 : Closed e1211203271402 ∧ code e1211203271402 = 5609249782506 := by decide
theorem cert_e1211203271402 : check e1211203271402 [[],[]] .chain = true := by decide
def e1211203271594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e1211203271594 : Closed e1211203271594 ∧ code e1211203271594 = 5609249782698 := by decide
theorem cert_e1211203271594 : check e1211203271594 [[],[]] .chain = true := by decide
def e1211203272022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1211203272022 : Closed e1211203272022 ∧ code e1211203272022 = 5609249783126 := by decide
theorem cert_e1211203272022 : check e1211203272022 [[],[]] .chain = true := by decide
def e1211203272026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1211203272026 : Closed e1211203272026 ∧ code e1211203272026 = 5609249783130 := by decide
theorem cert_e1211203272026 : check e1211203272026 [[],[]] .chain = true := by decide
def e1211203272042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1211203272042 : Closed e1211203272042 ∧ code e1211203272042 = 5609249783146 := by decide
theorem cert_e1211203272042 : check e1211203272042 [[],[]] .chain = true := by decide
def e1211203272106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e1211203272106 : Closed e1211203272106 ∧ code e1211203272106 = 5609249783210 := by decide
theorem cert_e1211203272106 : check e1211203272106 [[],[]] .chain = true := by decide
def e1211203273070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203273070 : Closed e1211203273070 ∧ code e1211203273070 = 5609249784174 := by decide
theorem cert_e1211203273070 : check e1211203273070 [[],[]] .chain = true := by decide
def e1211203273078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203273078 : Closed e1211203273078 ∧ code e1211203273078 = 5609249784182 := by decide
theorem cert_e1211203273078 : check e1211203273078 [[],[]] .chain = true := by decide
def e1211203273134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203273134 : Closed e1211203273134 ∧ code e1211203273134 = 5609249784238 := by decide
theorem cert_e1211203273134 : check e1211203273134 [[],[]] .chain = true := by decide
def e1211203273146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203273146 : Closed e1211203273146 ∧ code e1211203273146 = 5609249784250 := by decide
theorem cert_e1211203273146 : check e1211203273146 [[],[]] .chain = true := by decide
def e1211203273838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203273838 : Closed e1211203273838 ∧ code e1211203273838 = 5609249784942 := by decide
theorem cert_e1211203273838 : check e1211203273838 [[],[]] .chain = true := by decide
def e1211203273850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203273850 : Closed e1211203273850 ∧ code e1211203273850 = 5609249784954 := by decide
theorem cert_e1211203273850 : check e1211203273850 [[],[]] .chain = true := by decide
def e1211203274014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203274014 : Closed e1211203274014 ∧ code e1211203274014 = 5609249785118 := by decide
theorem cert_e1211203274014 : check e1211203274014 [[],[]] .chain = true := by decide
def e1211203274182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203274182 : Closed e1211203274182 ∧ code e1211203274182 = 5609249785286 := by decide
theorem cert_e1211203274182 : check e1211203274182 [[],[]] .chain = true := by decide
def e1211203274286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203274286 : Closed e1211203274286 ∧ code e1211203274286 = 5609249785390 := by decide
theorem cert_e1211203274286 : check e1211203274286 [[],[]] .chain = true := by decide
def e1211203274466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203274466 : Closed e1211203274466 ∧ code e1211203274466 = 5609249785570 := by decide
theorem cert_e1211203274466 : check e1211203274466 [[],[]] .chain = true := by decide
def e1211203274478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e1211203274478 : Closed e1211203274478 ∧ code e1211203274478 = 5609249785582 := by decide
theorem cert_e1211203274478 : check e1211203274478 [[],[]] .sourceHead = true := by decide
def e1211203274606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e1211203274606 : Closed e1211203274606 ∧ code e1211203274606 = 5609249785710 := by decide
theorem cert_e1211203274606 : check e1211203274606 [[],[]] .chain = true := by decide
def e1211203274614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e1211203274614 : Closed e1211203274614 ∧ code e1211203274614 = 5609249785718 := by decide
theorem cert_e1211203274614 : check e1211203274614 [[],[]] .chain = true := by decide
def e1211203274634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203274634 : Closed e1211203274634 ∧ code e1211203274634 = 5609249785738 := by decide
theorem cert_e1211203274634 : check e1211203274634 [[],[]] .chain = true := by decide
def e1211203274658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203274658 : Closed e1211203274658 ∧ code e1211203274658 = 5609249785762 := by decide
theorem cert_e1211203274658 : check e1211203274658 [[],[]] .chain = true := by decide
def e1211203274670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e1211203274670 : Closed e1211203274670 ∧ code e1211203274670 = 5609249785774 := by decide
theorem cert_e1211203274670 : check e1211203274670 [[],[]] .sourceHead = true := by decide
def e1211203274678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e1211203274678 : Closed e1211203274678 ∧ code e1211203274678 = 5609249785782 := by decide
theorem cert_e1211203274678 : check e1211203274678 [[],[]] .chain = true := by decide
def e1211203274682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e1211203274682 : Closed e1211203274682 ∧ code e1211203274682 = 5609249785786 := by decide
theorem cert_e1211203274682 : check e1211203274682 [[],[]] .sourceHead = true := by decide
def e1211203276142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203276142 : Closed e1211203276142 ∧ code e1211203276142 = 5609249787246 := by decide
theorem cert_e1211203276142 : check e1211203276142 [[],[]] .chain = true := by decide
def e1211203276150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203276150 : Closed e1211203276150 ∧ code e1211203276150 = 5609249787254 := by decide
theorem cert_e1211203276150 : check e1211203276150 [[],[]] .chain = true := by decide
def e1211203276206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203276206 : Closed e1211203276206 ∧ code e1211203276206 = 5609249787310 := by decide
theorem cert_e1211203276206 : check e1211203276206 [[],[]] .chain = true := by decide
def e1211203276218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203276218 : Closed e1211203276218 ∧ code e1211203276218 = 5609249787322 := by decide
theorem cert_e1211203276218 : check e1211203276218 [[],[]] .chain = true := by decide
def e1211203276246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203276246 : Closed e1211203276246 ∧ code e1211203276246 = 5609249787350 := by decide
theorem cert_e1211203276246 : check e1211203276246 [[],[]] .chain = true := by decide
def e1211203276250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203276250 : Closed e1211203276250 ∧ code e1211203276250 = 5609249787354 := by decide
theorem cert_e1211203276250 : check e1211203276250 [[],[]] .chain = true := by decide
def e1211203276462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203276462 : Closed e1211203276462 ∧ code e1211203276462 = 5609249787566 := by decide
theorem cert_e1211203276462 : check e1211203276462 [[],[]] .chain = true := by decide
def e1211203276474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203276474 : Closed e1211203276474 ∧ code e1211203276474 = 5609249787578 := by decide
theorem cert_e1211203276474 : check e1211203276474 [[],[]] .chain = true := by decide
def e1211203276522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203276522 : Closed e1211203276522 ∧ code e1211203276522 = 5609249787626 := by decide
theorem cert_e1211203276522 : check e1211203276522 [[],[]] .chain = true := by decide
def e1211203276630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203276630 : Closed e1211203276630 ∧ code e1211203276630 = 5609249787734 := by decide
theorem cert_e1211203276630 : check e1211203276630 [[],[]] .chain = true := by decide
def e1211203276634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203276634 : Closed e1211203276634 ∧ code e1211203276634 = 5609249787738 := by decide
theorem cert_e1211203276634 : check e1211203276634 [[],[]] .chain = true := by decide
def e1211203276650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203276650 : Closed e1211203276650 ∧ code e1211203276650 = 5609249787754 := by decide
theorem cert_e1211203276650 : check e1211203276650 [[],[]] .chain = true := by decide
def e1211203276910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203276910 : Closed e1211203276910 ∧ code e1211203276910 = 5609249788014 := by decide
theorem cert_e1211203276910 : check e1211203276910 [[],[]] .chain = true := by decide
def e1211203277086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203277086 : Closed e1211203277086 ∧ code e1211203277086 = 5609249788190 := by decide
theorem cert_e1211203277086 : check e1211203277086 [[],[]] .chain = true := by decide
def e1211203277282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e1211203277282 : Closed e1211203277282 ∧ code e1211203277282 = 5609249788386 := by decide
theorem cert_e1211203277282 : check e1211203277282 [[],[]] .chain = true := by decide
def e1211203277294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1211203277294 : Closed e1211203277294 ∧ code e1211203277294 = 5609249788398 := by decide
theorem cert_e1211203277294 : check e1211203277294 [[],[]] .sourceHead = true := by decide
def e1211203277678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203277678 : Closed e1211203277678 ∧ code e1211203277678 = 5609249788782 := by decide
theorem cert_e1211203277678 : check e1211203277678 [[],[]] .chain = true := by decide
def e1211203277686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203277686 : Closed e1211203277686 ∧ code e1211203277686 = 5609249788790 := by decide
theorem cert_e1211203277686 : check e1211203277686 [[],[]] .chain = true := by decide
def e1211203277742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203277742 : Closed e1211203277742 ∧ code e1211203277742 = 5609249788846 := by decide
theorem cert_e1211203277742 : check e1211203277742 [[],[]] .chain = true := by decide
def e1211203277754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203277754 : Closed e1211203277754 ∧ code e1211203277754 = 5609249788858 := by decide
theorem cert_e1211203277754 : check e1211203277754 [[],[]] .chain = true := by decide
def e1211203277782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203277782 : Closed e1211203277782 ∧ code e1211203277782 = 5609249788886 := by decide
theorem cert_e1211203277782 : check e1211203277782 [[],[]] .chain = true := by decide
def e1211203277786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203277786 : Closed e1211203277786 ∧ code e1211203277786 = 5609249788890 := by decide
theorem cert_e1211203277786 : check e1211203277786 [[],[]] .chain = true := by decide
def e1211203278062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203278062 : Closed e1211203278062 ∧ code e1211203278062 = 5609249789166 := by decide
theorem cert_e1211203278062 : check e1211203278062 [[],[]] .chain = true := by decide
def e1211203278070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203278070 : Closed e1211203278070 ∧ code e1211203278070 = 5609249789174 := by decide
theorem cert_e1211203278070 : check e1211203278070 [[],[]] .chain = true := by decide
def e1211203278446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203278446 : Closed e1211203278446 ∧ code e1211203278446 = 5609249789550 := by decide
theorem cert_e1211203278446 : check e1211203278446 [[],[]] .chain = true := by decide
def e1211203278458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203278458 : Closed e1211203278458 ∧ code e1211203278458 = 5609249789562 := by decide
theorem cert_e1211203278458 : check e1211203278458 [[],[]] .chain = true := by decide
def e1211203278598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203278598 : Closed e1211203278598 ∧ code e1211203278598 = 5609249789702 := by decide
theorem cert_e1211203278598 : check e1211203278598 [[],[]] .chain = true := by decide
def e1211203278622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1211203278622 : Closed e1211203278622 ∧ code e1211203278622 = 5609249789726 := by decide
theorem cert_e1211203278622 : check e1211203278622 [[],[]] .sourceHead = true := by decide
def e1211203278646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203278646 : Closed e1211203278646 ∧ code e1211203278646 = 5609249789750 := by decide
theorem cert_e1211203278646 : check e1211203278646 [[],[]] .chain = true := by decide
def e1211203278650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203278650 : Closed e1211203278650 ∧ code e1211203278650 = 5609249789754 := by decide
theorem cert_e1211203278650 : check e1211203278650 [[],[]] .chain = true := by decide
def e1211203278894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203278894 : Closed e1211203278894 ∧ code e1211203278894 = 5609249789998 := by decide
theorem cert_e1211203278894 : check e1211203278894 [[],[]] .chain = true := by decide
def e1211203279086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203279086 : Closed e1211203279086 ∧ code e1211203279086 = 5609249790190 := by decide
theorem cert_e1211203279086 : check e1211203279086 [[],[]] .chain = true := by decide
def e1211203279094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203279094 : Closed e1211203279094 ∧ code e1211203279094 = 5609249790198 := by decide
theorem cert_e1211203279094 : check e1211203279094 [[],[]] .chain = true := by decide
def e1211203279278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203279278 : Closed e1211203279278 ∧ code e1211203279278 = 5609249790382 := by decide
theorem cert_e1211203279278 : check e1211203279278 [[],[]] .chain = true := by decide
def e1211203279290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203279290 : Closed e1211203279290 ∧ code e1211203279290 = 5609249790394 := by decide
theorem cert_e1211203279290 : check e1211203279290 [[],[]] .chain = true := by decide
def e1211203279338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203279338 : Closed e1211203279338 ∧ code e1211203279338 = 5609249790442 := by decide
theorem cert_e1211203279338 : check e1211203279338 [[],[]] .chain = true := by decide
def e1211203279470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203279470 : Closed e1211203279470 ∧ code e1211203279470 = 5609249790574 := by decide
theorem cert_e1211203279470 : check e1211203279470 [[],[]] .chain = true := by decide
def e1211203279482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203279482 : Closed e1211203279482 ∧ code e1211203279482 = 5609249790586 := by decide
theorem cert_e1211203279482 : check e1211203279482 [[],[]] .chain = true := by decide
def e1211203279646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203279646 : Closed e1211203279646 ∧ code e1211203279646 = 5609249790750 := by decide
theorem cert_e1211203279646 : check e1211203279646 [[],[]] .chain = true := by decide
def e1211203279746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203279746 : Closed e1211203279746 ∧ code e1211203279746 = 5609249790850 := by decide
theorem cert_e1211203279746 : check e1211203279746 [[],[]] .chain = true := by decide
def e1211203279758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203279758 : Closed e1211203279758 ∧ code e1211203279758 = 5609249790862 := by decide
theorem cert_e1211203279758 : check e1211203279758 [[],[]] .chain = true := by decide
def e1211203279770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203279770 : Closed e1211203279770 ∧ code e1211203279770 = 5609249790874 := by decide
theorem cert_e1211203279770 : check e1211203279770 [[],[]] .chain = true := by decide
def e1211203279894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203279894 : Closed e1211203279894 ∧ code e1211203279894 = 5609249790998 := by decide
theorem cert_e1211203279894 : check e1211203279894 [[],[]] .chain = true := by decide
def e1211203279898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203279898 : Closed e1211203279898 ∧ code e1211203279898 = 5609249791002 := by decide
theorem cert_e1211203279898 : check e1211203279898 [[],[]] .chain = true := by decide
def e1211203279942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203279942 : Closed e1211203279942 ∧ code e1211203279942 = 5609249791046 := by decide
theorem cert_e1211203279942 : check e1211203279942 [[],[]] .chain = true := by decide
def e1211203279970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203279970 : Closed e1211203279970 ∧ code e1211203279970 = 5609249791074 := by decide
theorem cert_e1211203279970 : check e1211203279970 [[],[]] .chain = true := by decide
def e1211203279982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203279982 : Closed e1211203279982 ∧ code e1211203279982 = 5609249791086 := by decide
theorem cert_e1211203279982 : check e1211203279982 [[],[]] .sourceHead = true := by decide
def e1211203279990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203279990 : Closed e1211203279990 ∧ code e1211203279990 = 5609249791094 := by decide
theorem cert_e1211203279990 : check e1211203279990 [[],[]] .chain = true := by decide
def e1211203279994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203279994 : Closed e1211203279994 ∧ code e1211203279994 = 5609249791098 := by decide
theorem cert_e1211203279994 : check e1211203279994 [[],[]] .sourceHead = true := by decide
def e1211203280086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203280086 : Closed e1211203280086 ∧ code e1211203280086 = 5609249791190 := by decide
theorem cert_e1211203280086 : check e1211203280086 [[],[]] .chain = true := by decide
def e1211203280090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203280090 : Closed e1211203280090 ∧ code e1211203280090 = 5609249791194 := by decide
theorem cert_e1211203280090 : check e1211203280090 [[],[]] .chain = true := by decide
def e1211203280106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203280106 : Closed e1211203280106 ∧ code e1211203280106 = 5609249791210 := by decide
theorem cert_e1211203280106 : check e1211203280106 [[],[]] .chain = true := by decide
def e1211203280134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203280134 : Closed e1211203280134 ∧ code e1211203280134 = 5609249791238 := by decide
theorem cert_e1211203280134 : check e1211203280134 [[],[]] .chain = true := by decide
def e1211203280158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203280158 : Closed e1211203280158 ∧ code e1211203280158 = 5609249791262 := by decide
theorem cert_e1211203280158 : check e1211203280158 [[],[]] .sourceHead = true := by decide
def e1211203280182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203280182 : Closed e1211203280182 ∧ code e1211203280182 = 5609249791286 := by decide
theorem cert_e1211203280182 : check e1211203280182 [[],[]] .chain = true := by decide
def e1211203280186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203280186 : Closed e1211203280186 ∧ code e1211203280186 = 5609249791290 := by decide
theorem cert_e1211203280186 : check e1211203280186 [[],[]] .chain = true := by decide
def e1211203280258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203280258 : Closed e1211203280258 ∧ code e1211203280258 = 5609249791362 := by decide
theorem cert_e1211203280258 : check e1211203280258 [[],[]] .chain = true := by decide
def e1211203280270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e1211203280270 : Closed e1211203280270 ∧ code e1211203280270 = 5609249791374 := by decide
theorem cert_e1211203280270 : check e1211203280270 [[],[]] .chain = true := by decide
def e1211203280282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203280282 : Closed e1211203280282 ∧ code e1211203280282 = 5609249791386 := by decide
theorem cert_e1211203280282 : check e1211203280282 [[],[]] .chain = true := by decide
def e1211203280326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203280326 : Closed e1211203280326 ∧ code e1211203280326 = 5609249791430 := by decide
theorem cert_e1211203280326 : check e1211203280326 [[],[]] .sourceHead = true := by decide
def e1211203281070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1211203281070 : Closed e1211203281070 ∧ code e1211203281070 = 5609249792174 := by decide
theorem cert_e1211203281070 : check e1211203281070 [[],[]] .chain = true := by decide
def e1211203281082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1211203281082 : Closed e1211203281082 ∧ code e1211203281082 = 5609249792186 := by decide
theorem cert_e1211203281082 : check e1211203281082 [[],[]] .chain = true := by decide
def e1211203281774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1211203281774 : Closed e1211203281774 ∧ code e1211203281774 = 5609249792878 := by decide
theorem cert_e1211203281774 : check e1211203281774 [[],[]] .chain = true := by decide
def e1211203281782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1211203281782 : Closed e1211203281782 ∧ code e1211203281782 = 5609249792886 := by decide
theorem cert_e1211203281782 : check e1211203281782 [[],[]] .chain = true := by decide
def e1211203281838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e1211203281838 : Closed e1211203281838 ∧ code e1211203281838 = 5609249792942 := by decide
theorem cert_e1211203281838 : check e1211203281838 [[],[]] .chain = true := by decide
def e1211203281850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e1211203281850 : Closed e1211203281850 ∧ code e1211203281850 = 5609249792954 := by decide
theorem cert_e1211203281850 : check e1211203281850 [[],[]] .chain = true := by decide
def e1211203281878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e1211203281878 : Closed e1211203281878 ∧ code e1211203281878 = 5609249792982 := by decide
theorem cert_e1211203281878 : check e1211203281878 [[],[]] .chain = true := by decide
def e1211203281882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e1211203281882 : Closed e1211203281882 ∧ code e1211203281882 = 5609249792986 := by decide
theorem cert_e1211203281882 : check e1211203281882 [[],[]] .chain = true := by decide
def e1211203282606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203282606 : Closed e1211203282606 ∧ code e1211203282606 = 5609249793710 := by decide
theorem cert_e1211203282606 : check e1211203282606 [[],[]] .chain = true := by decide
def e1211203282618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203282618 : Closed e1211203282618 ∧ code e1211203282618 = 5609249793722 := by decide
theorem cert_e1211203282618 : check e1211203282618 [[],[]] .chain = true := by decide
def e1211203282666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203282666 : Closed e1211203282666 ∧ code e1211203282666 = 5609249793770 := by decide
theorem cert_e1211203282666 : check e1211203282666 [[],[]] .chain = true := by decide
def e1211203282858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203282858 : Closed e1211203282858 ∧ code e1211203282858 = 5609249793962 := by decide
theorem cert_e1211203282858 : check e1211203282858 [[],[]] .chain = true := by decide
def e1211203282990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203282990 : Closed e1211203282990 ∧ code e1211203282990 = 5609249794094 := by decide
theorem cert_e1211203282990 : check e1211203282990 [[],[]] .chain = true := by decide
def e1211203283182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1211203283182 : Closed e1211203283182 ∧ code e1211203283182 = 5609249794286 := by decide
theorem cert_e1211203283182 : check e1211203283182 [[],[]] .chain = true := by decide
def e1211203283190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1211203283190 : Closed e1211203283190 ∧ code e1211203283190 = 5609249794294 := by decide
theorem cert_e1211203283190 : check e1211203283190 [[],[]] .chain = true := by decide
def e1211203283374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203283374 : Closed e1211203283374 ∧ code e1211203283374 = 5609249794478 := by decide
theorem cert_e1211203283374 : check e1211203283374 [[],[]] .chain = true := by decide
def e1211203283386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203283386 : Closed e1211203283386 ∧ code e1211203283386 = 5609249794490 := by decide
theorem cert_e1211203283386 : check e1211203283386 [[],[]] .chain = true := by decide
def e1211203283434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203283434 : Closed e1211203283434 ∧ code e1211203283434 = 5609249794538 := by decide
theorem cert_e1211203283434 : check e1211203283434 [[],[]] .chain = true := by decide
def e1211203283566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203283566 : Closed e1211203283566 ∧ code e1211203283566 = 5609249794670 := by decide
theorem cert_e1211203283566 : check e1211203283566 [[],[]] .chain = true := by decide
def e1211203283578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203283578 : Closed e1211203283578 ∧ code e1211203283578 = 5609249794682 := by decide
theorem cert_e1211203283578 : check e1211203283578 [[],[]] .chain = true := by decide
def e1211203283742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1211203283742 : Closed e1211203283742 ∧ code e1211203283742 = 5609249794846 := by decide
theorem cert_e1211203283742 : check e1211203283742 [[],[]] .chain = true := by decide
def e1211203283842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203283842 : Closed e1211203283842 ∧ code e1211203283842 = 5609249794946 := by decide
theorem cert_e1211203283842 : check e1211203283842 [[],[]] .chain = true := by decide
def e1211203283854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1211203283854 : Closed e1211203283854 ∧ code e1211203283854 = 5609249794958 := by decide
theorem cert_e1211203283854 : check e1211203283854 [[],[]] .chain = true := by decide
def e1211203283866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203283866 : Closed e1211203283866 ∧ code e1211203283866 = 5609249794970 := by decide
theorem cert_e1211203283866 : check e1211203283866 [[],[]] .chain = true := by decide
def e1211203284078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203284078 : Closed e1211203284078 ∧ code e1211203284078 = 5609249795182 := by decide
theorem cert_e1211203284078 : check e1211203284078 [[],[]] .chain = true := by decide
def e1211203284090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203284090 : Closed e1211203284090 ∧ code e1211203284090 = 5609249795194 := by decide
theorem cert_e1211203284090 : check e1211203284090 [[],[]] .chain = true := by decide
def e1211203284254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203284254 : Closed e1211203284254 ∧ code e1211203284254 = 5609249795358 := by decide
theorem cert_e1211203284254 : check e1211203284254 [[],[]] .chain = true := by decide
def e1211203284422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203284422 : Closed e1211203284422 ∧ code e1211203284422 = 5609249795526 := by decide
theorem cert_e1211203284422 : check e1211203284422 [[],[]] .chain = true := by decide
def e1211203284490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203284490 : Closed e1211203284490 ∧ code e1211203284490 = 5609249795594 := by decide
theorem cert_e1211203284490 : check e1211203284490 [[],[]] .chain = true := by decide
def e1211203284534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e1211203284534 : Closed e1211203284534 ∧ code e1211203284534 = 5609249795638 := by decide
theorem cert_e1211203284534 : check e1211203284534 [[],[]] .chain = true := by decide
def e1211203284538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e1211203284538 : Closed e1211203284538 ∧ code e1211203284538 = 5609249795642 := by decide
theorem cert_e1211203284538 : check e1211203284538 [[],[]] .chain = true := by decide
def e1211203284586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e1211203284586 : Closed e1211203284586 ∧ code e1211203284586 = 5609249795690 := by decide
theorem cert_e1211203284586 : check e1211203284586 [[],[]] .chain = true := by decide
def e1211203284610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e1211203284610 : Closed e1211203284610 ∧ code e1211203284610 = 5609249795714 := by decide
theorem cert_e1211203284610 : check e1211203284610 [[],[]] .chain = true := by decide
def e1211203284622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1211203284622 : Closed e1211203284622 ∧ code e1211203284622 = 5609249795726 := by decide
theorem cert_e1211203284622 : check e1211203284622 [[],[]] .chain = true := by decide
def e1211203284634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203284634 : Closed e1211203284634 ∧ code e1211203284634 = 5609249795738 := by decide
theorem cert_e1211203284634 : check e1211203284634 [[],[]] .chain = true := by decide
def e1211203284678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1211203284678 : Closed e1211203284678 ∧ code e1211203284678 = 5609249795782 := by decide
theorem cert_e1211203284678 : check e1211203284678 [[],[]] .chain = true := by decide
def e1211203285078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203285078 : Closed e1211203285078 ∧ code e1211203285078 = 5609249796182 := by decide
theorem cert_e1211203285078 : check e1211203285078 [[],[]] .chain = true := by decide
def e1211203285082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203285082 : Closed e1211203285082 ∧ code e1211203285082 = 5609249796186 := by decide
theorem cert_e1211203285082 : check e1211203285082 [[],[]] .chain = true := by decide
def e1211203285098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203285098 : Closed e1211203285098 ∧ code e1211203285098 = 5609249796202 := by decide
theorem cert_e1211203285098 : check e1211203285098 [[],[]] .chain = true := by decide
def e1211203285274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203285274 : Closed e1211203285274 ∧ code e1211203285274 = 5609249796378 := by decide
theorem cert_e1211203285274 : check e1211203285274 [[],[]] .chain = true := by decide
def e1211203285318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203285318 : Closed e1211203285318 ∧ code e1211203285318 = 5609249796422 := by decide
theorem cert_e1211203285318 : check e1211203285318 [[],[]] .chain = true := by decide
def e1211203285386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203285386 : Closed e1211203285386 ∧ code e1211203285386 = 5609249796490 := by decide
theorem cert_e1211203285386 : check e1211203285386 [[],[]] .chain = true := by decide
def e1211203285410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203285410 : Closed e1211203285410 ∧ code e1211203285410 = 5609249796514 := by decide
theorem cert_e1211203285410 : check e1211203285410 [[],[]] .chain = true := by decide
def e1211203285422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203285422 : Closed e1211203285422 ∧ code e1211203285422 = 5609249796526 := by decide
theorem cert_e1211203285422 : check e1211203285422 [[],[]] .sourceHead = true := by decide
def e1211203285430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e1211203285430 : Closed e1211203285430 ∧ code e1211203285430 = 5609249796534 := by decide
theorem cert_e1211203285430 : check e1211203285430 [[],[]] .chain = true := by decide
def e1211203285434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203285434 : Closed e1211203285434 ∧ code e1211203285434 = 5609249796538 := by decide
theorem cert_e1211203285434 : check e1211203285434 [[],[]] .sourceHead = true := by decide
def e1211203285462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203285462 : Closed e1211203285462 ∧ code e1211203285462 = 5609249796566 := by decide
theorem cert_e1211203285462 : check e1211203285462 [[],[]] .chain = true := by decide
def e1211203285466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203285466 : Closed e1211203285466 ∧ code e1211203285466 = 5609249796570 := by decide
theorem cert_e1211203285466 : check e1211203285466 [[],[]] .chain = true := by decide
def e1211203285482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e1211203285482 : Closed e1211203285482 ∧ code e1211203285482 = 5609249796586 := by decide
theorem cert_e1211203285482 : check e1211203285482 [[],[]] .sourceHead = true := by decide
def e1211203285846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203285846 : Closed e1211203285846 ∧ code e1211203285846 = 5609249796950 := by decide
theorem cert_e1211203285846 : check e1211203285846 [[],[]] .chain = true := by decide
def e1211203285850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203285850 : Closed e1211203285850 ∧ code e1211203285850 = 5609249796954 := by decide
theorem cert_e1211203285850 : check e1211203285850 [[],[]] .chain = true := by decide
def e1211203285866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203285866 : Closed e1211203285866 ∧ code e1211203285866 = 5609249796970 := by decide
theorem cert_e1211203285866 : check e1211203285866 [[],[]] .chain = true := by decide
def e1211203285930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203285930 : Closed e1211203285930 ∧ code e1211203285930 = 5609249797034 := by decide
theorem cert_e1211203285930 : check e1211203285930 [[],[]] .chain = true := by decide
def e1211203286038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e1211203286038 : Closed e1211203286038 ∧ code e1211203286038 = 5609249797142 := by decide
theorem cert_e1211203286038 : check e1211203286038 [[],[]] .chain = true := by decide
def e1211203286042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203286042 : Closed e1211203286042 ∧ code e1211203286042 = 5609249797146 := by decide
theorem cert_e1211203286042 : check e1211203286042 [[],[]] .chain = true := by decide
def e1211203286086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203286086 : Closed e1211203286086 ∧ code e1211203286086 = 5609249797190 := by decide
theorem cert_e1211203286086 : check e1211203286086 [[],[]] .chain = true := by decide
def e1211203286114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e1211203286114 : Closed e1211203286114 ∧ code e1211203286114 = 5609249797218 := by decide
theorem cert_e1211203286114 : check e1211203286114 [[],[]] .chain = true := by decide
def e1211203286126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203286126 : Closed e1211203286126 ∧ code e1211203286126 = 5609249797230 := by decide
theorem cert_e1211203286126 : check e1211203286126 [[],[]] .sourceHead = true := by decide
def e1211203286134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e1211203286134 : Closed e1211203286134 ∧ code e1211203286134 = 5609249797238 := by decide
theorem cert_e1211203286134 : check e1211203286134 [[],[]] .chain = true := by decide
def e1211203286138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203286138 : Closed e1211203286138 ∧ code e1211203286138 = 5609249797242 := by decide
theorem cert_e1211203286138 : check e1211203286138 [[],[]] .sourceHead = true := by decide
def e1211203286230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1211203286230 : Closed e1211203286230 ∧ code e1211203286230 = 5609249797334 := by decide
theorem cert_e1211203286230 : check e1211203286230 [[],[]] .chain = true := by decide
def e1211203286234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1211203286234 : Closed e1211203286234 ∧ code e1211203286234 = 5609249797338 := by decide
theorem cert_e1211203286234 : check e1211203286234 [[],[]] .chain = true := by decide
def e1211203286250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1211203286250 : Closed e1211203286250 ∧ code e1211203286250 = 5609249797354 := by decide
theorem cert_e1211203286250 : check e1211203286250 [[],[]] .chain = true := by decide
def e1211203286278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e1211203286278 : Closed e1211203286278 ∧ code e1211203286278 = 5609249797382 := by decide
theorem cert_e1211203286278 : check e1211203286278 [[],[]] .chain = true := by decide
def e1211203286302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203286302 : Closed e1211203286302 ∧ code e1211203286302 = 5609249797406 := by decide
theorem cert_e1211203286302 : check e1211203286302 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
