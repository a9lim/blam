import Tables
import Batch131
namespace Blc.Floor42.Grades131
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1209577553130 : ¬ IsSelfInterpreter e1209577553130 := cutM0_2 (by decide)
#print axioms ex_e1209577553130
theorem ex_e1209577557614 : ¬ IsSelfInterpreter e1209577557614 := cutM14_0 (by decide)
#print axioms ex_e1209577557614
end Blc.Floor42.Grades131
