import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302593916218 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302593916218 : Closed e302593916218 ∧ code e302593916218 = 4700640427322 := by decide
theorem cert_e302593916218 : check e302593916218 [[.under],[.under]] .smaller = true := by decide
def e302593916314 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302593916314 : Closed e302593916314 ∧ code e302593916314 = 4700640427418 := by decide
theorem cert_e302593916314 : check e302593916314 [[.under],[.under]] .smaller = true := by decide
def e302593919854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302593919854 : Closed e302593919854 ∧ code e302593919854 = 4700640430958 := by decide
theorem cert_e302593919854 : check e302593919854 [[.under],[.under]] .smaller = true := by decide
def e302593919862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302593919862 : Closed e302593919862 ∧ code e302593919862 = 4700640430966 := by decide
theorem cert_e302593919862 : check e302593919862 [[.under],[.under]] .smaller = true := by decide
def e302593919918 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302593919918 : Closed e302593919918 ∧ code e302593919918 = 4700640431022 := by decide
theorem cert_e302593919918 : check e302593919918 [[.under],[.under]] .smaller = true := by decide
def e302593919930 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302593919930 : Closed e302593919930 ∧ code e302593919930 = 4700640431034 := by decide
theorem cert_e302593919930 : check e302593919930 [[.under],[.under]] .smaller = true := by decide
def e302593919958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302593919958 : Closed e302593919958 ∧ code e302593919958 = 4700640431062 := by decide
theorem cert_e302593919958 : check e302593919958 [[.under],[.under]] .smaller = true := by decide
def e302593919962 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302593919962 : Closed e302593919962 ∧ code e302593919962 = 4700640431066 := by decide
theorem cert_e302593919962 : check e302593919962 [[.under],[.under]] .smaller = true := by decide
def e302593920238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302593920238 : Closed e302593920238 ∧ code e302593920238 = 4700640431342 := by decide
theorem cert_e302593920238 : check e302593920238 [[.under],[.under]] .smaller = true := by decide
def e302593920246 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302593920246 : Closed e302593920246 ∧ code e302593920246 = 4700640431350 := by decide
theorem cert_e302593920246 : check e302593920246 [[.under],[.under]] .smaller = true := by decide
def e302593920622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302593920622 : Closed e302593920622 ∧ code e302593920622 = 4700640431726 := by decide
theorem cert_e302593920622 : check e302593920622 [[.under],[.under]] .smaller = true := by decide
def e302593920634 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302593920634 : Closed e302593920634 ∧ code e302593920634 = 4700640431738 := by decide
theorem cert_e302593920634 : check e302593920634 [[.under],[.under]] .smaller = true := by decide
def e302593920822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302593920822 : Closed e302593920822 ∧ code e302593920822 = 4700640431926 := by decide
theorem cert_e302593920822 : check e302593920822 [[.under],[.under]] .smaller = true := by decide
def e302593920826 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302593920826 : Closed e302593920826 ∧ code e302593920826 = 4700640431930 := by decide
theorem cert_e302593920826 : check e302593920826 [[.under],[.under]] .smaller = true := by decide
def e302593926574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302593926574 : Closed e302593926574 ∧ code e302593926574 = 4700640437678 := by decide
theorem cert_e302593926574 : check e302593926574 [[.under],[.under]] .smaller = true := by decide
def e302593926586 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302593926586 : Closed e302593926586 ∧ code e302593926586 = 4700640437690 := by decide
theorem cert_e302593926586 : check e302593926586 [[.under],[.under]] .smaller = true := by decide
def e302593926634 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302593926634 : Closed e302593926634 ∧ code e302593926634 = 4700640437738 := by decide
theorem cert_e302593926634 : check e302593926634 [[.under],[.under]] .smaller = true := by decide
def e302593926766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302593926766 : Closed e302593926766 ∧ code e302593926766 = 4700640437870 := by decide
theorem cert_e302593926766 : check e302593926766 [[.under],[.under]] .smaller = true := by decide
def e302593926778 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302593926778 : Closed e302593926778 ∧ code e302593926778 = 4700640437882 := by decide
theorem cert_e302593926778 : check e302593926778 [[.under],[.under]] .smaller = true := by decide
def e302593927066 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302593927066 : Closed e302593927066 ∧ code e302593927066 = 4700640438170 := by decide
theorem cert_e302593927066 : check e302593927066 [[.under],[.under]] .smaller = true := by decide
def e302593929942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302593929942 : Closed e302593929942 ∧ code e302593929942 = 4700640441046 := by decide
theorem cert_e302593929942 : check e302593929942 [[.under],[.under]] .smaller = true := by decide
def e302593929946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302593929946 : Closed e302593929946 ∧ code e302593929946 = 4700640441050 := by decide
theorem cert_e302593929946 : check e302593929946 [[.under],[.under]] .smaller = true := by decide
def e302593929962 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302593929962 : Closed e302593929962 ∧ code e302593929962 = 4700640441066 := by decide
theorem cert_e302593929962 : check e302593929962 [[.under],[.under]] .smaller = true := by decide
def e302593930038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302593930038 : Closed e302593930038 ∧ code e302593930038 = 4700640441142 := by decide
theorem cert_e302593930038 : check e302593930038 [[.under],[.under]] .smaller = true := by decide
def e302593930042 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302593930042 : Closed e302593930042 ∧ code e302593930042 = 4700640441146 := by decide
theorem cert_e302593930042 : check e302593930042 [[.under],[.under]] .smaller = true := by decide
def e302593930138 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302593930138 : Closed e302593930138 ∧ code e302593930138 = 4700640441242 := by decide
theorem cert_e302593930138 : check e302593930138 [[.under],[.under]] .smaller = true := by decide
def e302594045678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e302594045678 : Closed e302594045678 ∧ code e302594045678 = 4700640556782 := by decide
theorem cert_e302594045678 : check e302594045678 [[.under],[.under]] .three = true := by decide
def e302594045806 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e302594045806 : Closed e302594045806 ∧ code e302594045806 = 4700640556910 := by decide
theorem cert_e302594045806 : check e302594045806 [[.under],[.under]] .three = true := by decide
def e302594045814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e302594045814 : Closed e302594045814 ∧ code e302594045814 = 4700640556918 := by decide
theorem cert_e302594045814 : check e302594045814 [[.under],[.under]] .three = true := by decide
def e302594046702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e302594046702 : Closed e302594046702 ∧ code e302594046702 = 4700640557806 := by decide
theorem cert_e302594046702 : check e302594046702 [[.under],[.under]] .three = true := by decide
def e302594046894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e302594046894 : Closed e302594046894 ∧ code e302594046894 = 4700640557998 := by decide
theorem cert_e302594046894 : check e302594046894 [[.under],[.under]] .three = true := by decide
def e302594046906 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e302594046906 : Closed e302594046906 ∧ code e302594046906 = 4700640558010 := by decide
theorem cert_e302594046906 : check e302594046906 [[.under],[.under]] .three = true := by decide
def e302594047342 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302594047342 : Closed e302594047342 ∧ code e302594047342 = 4700640558446 := by decide
theorem cert_e302594047342 : check e302594047342 [[.under],[.under]] .three = true := by decide
def e302594047350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302594047350 : Closed e302594047350 ∧ code e302594047350 = 4700640558454 := by decide
theorem cert_e302594047350 : check e302594047350 [[.under],[.under]] .three = true := by decide
def e302594047406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302594047406 : Closed e302594047406 ∧ code e302594047406 = 4700640558510 := by decide
theorem cert_e302594047406 : check e302594047406 [[.under],[.under]] .three = true := by decide
def e302594047418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302594047418 : Closed e302594047418 ∧ code e302594047418 = 4700640558522 := by decide
theorem cert_e302594047418 : check e302594047418 [[.under],[.under]] .three = true := by decide
def e302594047446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302594047446 : Closed e302594047446 ∧ code e302594047446 = 4700640558550 := by decide
theorem cert_e302594047446 : check e302594047446 [[.under],[.under]] .three = true := by decide
def e302594047450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302594047450 : Closed e302594047450 ∧ code e302594047450 = 4700640558554 := by decide
theorem cert_e302594047450 : check e302594047450 [[.under],[.under]] .three = true := by decide
def e302594051822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e302594051822 : Closed e302594051822 ∧ code e302594051822 = 4700640562926 := by decide
theorem cert_e302594051822 : check e302594051822 [[.under],[.under]] .three = true := by decide
def e302594051950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e302594051950 : Closed e302594051950 ∧ code e302594051950 = 4700640563054 := by decide
theorem cert_e302594051950 : check e302594051950 [[.under],[.under]] .three = true := by decide
def e302594051958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e302594051958 : Closed e302594051958 ∧ code e302594051958 = 4700640563062 := by decide
theorem cert_e302594051958 : check e302594051958 [[.under],[.under]] .three = true := by decide
def e302594054638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e302594054638 : Closed e302594054638 ∧ code e302594054638 = 4700640565742 := by decide
theorem cert_e302594054638 : check e302594054638 [[.under],[.under]] .three = true := by decide
def e302594055406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e302594055406 : Closed e302594055406 ∧ code e302594055406 = 4700640566510 := by decide
theorem cert_e302594055406 : check e302594055406 [[.under],[.under]] .three = true := by decide
def e302594055414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e302594055414 : Closed e302594055414 ∧ code e302594055414 = 4700640566518 := by decide
theorem cert_e302594055414 : check e302594055414 [[.under],[.under]] .three = true := by decide
def e302594057966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e302594057966 : Closed e302594057966 ∧ code e302594057966 = 4700640569070 := by decide
theorem cert_e302594057966 : check e302594057966 [[.under],[.under]] .three = true := by decide
def e302594058158 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e302594058158 : Closed e302594058158 ∧ code e302594058158 = 4700640569262 := by decide
theorem cert_e302594058158 : check e302594058158 [[.under],[.under]] .three = true := by decide
def e302594058170 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e302594058170 : Closed e302594058170 ∧ code e302594058170 = 4700640569274 := by decide
theorem cert_e302594058170 : check e302594058170 [[.under],[.under]] .three = true := by decide
def e302594058734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e302594058734 : Closed e302594058734 ∧ code e302594058734 = 4700640569838 := by decide
theorem cert_e302594058734 : check e302594058734 [[.under],[.under]] .three = true := by decide
def e302594059886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e302594059886 : Closed e302594059886 ∧ code e302594059886 = 4700640570990 := by decide
theorem cert_e302594059886 : check e302594059886 [[.under],[.under]] .three = true := by decide
def e302594059898 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e302594059898 : Closed e302594059898 ∧ code e302594059898 = 4700640571002 := by decide
theorem cert_e302594059898 : check e302594059898 [[.under],[.under]] .three = true := by decide
def e302594061166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302594061166 : Closed e302594061166 ∧ code e302594061166 = 4700640572270 := by decide
theorem cert_e302594061166 : check e302594061166 [[.under],[.under]] .three = true := by decide
def e302594061174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302594061174 : Closed e302594061174 ∧ code e302594061174 = 4700640572278 := by decide
theorem cert_e302594061174 : check e302594061174 [[.under],[.under]] .three = true := by decide
def e302594061230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302594061230 : Closed e302594061230 ∧ code e302594061230 = 4700640572334 := by decide
theorem cert_e302594061230 : check e302594061230 [[.under],[.under]] .three = true := by decide
def e302594061242 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302594061242 : Closed e302594061242 ∧ code e302594061242 = 4700640572346 := by decide
theorem cert_e302594061242 : check e302594061242 [[.under],[.under]] .three = true := by decide
def e302594061270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302594061270 : Closed e302594061270 ∧ code e302594061270 = 4700640572374 := by decide
theorem cert_e302594061270 : check e302594061270 [[.under],[.under]] .three = true := by decide
def e302594061274 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302594061274 : Closed e302594061274 ∧ code e302594061274 = 4700640572378 := by decide
theorem cert_e302594061274 : check e302594061274 [[.under],[.under]] .three = true := by decide
def e302594061550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302594061550 : Closed e302594061550 ∧ code e302594061550 = 4700640572654 := by decide
theorem cert_e302594061550 : check e302594061550 [[.under],[.under]] .three = true := by decide
def e302594061558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302594061558 : Closed e302594061558 ∧ code e302594061558 = 4700640572662 := by decide
theorem cert_e302594061558 : check e302594061558 [[.under],[.under]] .three = true := by decide
def e302594061934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302594061934 : Closed e302594061934 ∧ code e302594061934 = 4700640573038 := by decide
theorem cert_e302594061934 : check e302594061934 [[.under],[.under]] .three = true := by decide
def e302594061946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302594061946 : Closed e302594061946 ∧ code e302594061946 = 4700640573050 := by decide
theorem cert_e302594061946 : check e302594061946 [[.under],[.under]] .three = true := by decide
def e302594062134 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302594062134 : Closed e302594062134 ∧ code e302594062134 = 4700640573238 := by decide
theorem cert_e302594062134 : check e302594062134 [[.under],[.under]] .three = true := by decide
def e302594062138 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302594062138 : Closed e302594062138 ∧ code e302594062138 = 4700640573242 := by decide
theorem cert_e302594062138 : check e302594062138 [[.under],[.under]] .three = true := by decide
def e302594067310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302594067310 : Closed e302594067310 ∧ code e302594067310 = 4700640578414 := by decide
theorem cert_e302594067310 : check e302594067310 [[.under],[.under]] .smaller = true := by decide
def e302594067318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302594067318 : Closed e302594067318 ∧ code e302594067318 = 4700640578422 := by decide
theorem cert_e302594067318 : check e302594067318 [[.under],[.under]] .smaller = true := by decide
def e302594067374 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302594067374 : Closed e302594067374 ∧ code e302594067374 = 4700640578478 := by decide
theorem cert_e302594067374 : check e302594067374 [[.under],[.under]] .smaller = true := by decide
def e302594067386 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302594067386 : Closed e302594067386 ∧ code e302594067386 = 4700640578490 := by decide
theorem cert_e302594067386 : check e302594067386 [[.under],[.under]] .smaller = true := by decide
def e302594067414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302594067414 : Closed e302594067414 ∧ code e302594067414 = 4700640578518 := by decide
theorem cert_e302594067414 : check e302594067414 [[.under],[.under]] .smaller = true := by decide
def e302594067418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302594067418 : Closed e302594067418 ∧ code e302594067418 = 4700640578522 := by decide
theorem cert_e302594067418 : check e302594067418 [[.under],[.under]] .smaller = true := by decide
def e302594067694 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302594067694 : Closed e302594067694 ∧ code e302594067694 = 4700640578798 := by decide
theorem cert_e302594067694 : check e302594067694 [[.under],[.under]] .smaller = true := by decide
def e302594067702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302594067702 : Closed e302594067702 ∧ code e302594067702 = 4700640578806 := by decide
theorem cert_e302594067702 : check e302594067702 [[.under],[.under]] .smaller = true := by decide
def e302594068078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302594068078 : Closed e302594068078 ∧ code e302594068078 = 4700640579182 := by decide
theorem cert_e302594068078 : check e302594068078 [[.under],[.under]] .smaller = true := by decide
def e302594068090 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302594068090 : Closed e302594068090 ∧ code e302594068090 = 4700640579194 := by decide
theorem cert_e302594068090 : check e302594068090 [[.under],[.under]] .smaller = true := by decide
def e302594068278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302594068278 : Closed e302594068278 ∧ code e302594068278 = 4700640579382 := by decide
theorem cert_e302594068278 : check e302594068278 [[.under],[.under]] .smaller = true := by decide
def e302594068282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302594068282 : Closed e302594068282 ∧ code e302594068282 = 4700640579386 := by decide
theorem cert_e302594068282 : check e302594068282 [[.under],[.under]] .smaller = true := by decide
def e302594076398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e302594076398 : Closed e302594076398 ∧ code e302594076398 = 4700640587502 := by decide
theorem cert_e302594076398 : check e302594076398 [[.under],[.under]] .three = true := by decide
def e302594076526 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e302594076526 : Closed e302594076526 ∧ code e302594076526 = 4700640587630 := by decide
theorem cert_e302594076526 : check e302594076526 [[.under],[.under]] .three = true := by decide
def e302594076534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e302594076534 : Closed e302594076534 ∧ code e302594076534 = 4700640587638 := by decide
theorem cert_e302594076534 : check e302594076534 [[.under],[.under]] .three = true := by decide
def e302594079214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e302594079214 : Closed e302594079214 ∧ code e302594079214 = 4700640590318 := by decide
theorem cert_e302594079214 : check e302594079214 [[.under],[.under]] .three = true := by decide
def e302594079982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e302594079982 : Closed e302594079982 ∧ code e302594079982 = 4700640591086 := by decide
theorem cert_e302594079982 : check e302594079982 [[.under],[.under]] .three = true := by decide
def e302594079990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e302594079990 : Closed e302594079990 ∧ code e302594079990 = 4700640591094 := by decide
theorem cert_e302594079990 : check e302594079990 [[.under],[.under]] .three = true := by decide
def e302594103022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e302594103022 : Closed e302594103022 ∧ code e302594103022 = 4700640614126 := by decide
theorem cert_e302594103022 : check e302594103022 [[.under],[.under]] .three = true := by decide
def e302594103214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e302594103214 : Closed e302594103214 ∧ code e302594103214 = 4700640614318 := by decide
theorem cert_e302594103214 : check e302594103214 [[.under],[.under]] .three = true := by decide
def e302594103226 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e302594103226 : Closed e302594103226 ∧ code e302594103226 = 4700640614330 := by decide
theorem cert_e302594103226 : check e302594103226 [[.under],[.under]] .three = true := by decide
def e302594103790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e302594103790 : Closed e302594103790 ∧ code e302594103790 = 4700640614894 := by decide
theorem cert_e302594103790 : check e302594103790 [[.under],[.under]] .three = true := by decide
def e302594104942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e302594104942 : Closed e302594104942 ∧ code e302594104942 = 4700640616046 := by decide
theorem cert_e302594104942 : check e302594104942 [[.under],[.under]] .three = true := by decide
def e302594104954 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e302594104954 : Closed e302594104954 ∧ code e302594104954 = 4700640616058 := by decide
theorem cert_e302594104954 : check e302594104954 [[.under],[.under]] .three = true := by decide
def e302594116462 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302594116462 : Closed e302594116462 ∧ code e302594116462 = 4700640627566 := by decide
theorem cert_e302594116462 : check e302594116462 [[.under],[.under]] .three = true := by decide
def e302594116470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302594116470 : Closed e302594116470 ∧ code e302594116470 = 4700640627574 := by decide
theorem cert_e302594116470 : check e302594116470 [[.under],[.under]] .three = true := by decide
def e302594116526 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302594116526 : Closed e302594116526 ∧ code e302594116526 = 4700640627630 := by decide
theorem cert_e302594116526 : check e302594116526 [[.under],[.under]] .three = true := by decide
def e302594116538 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302594116538 : Closed e302594116538 ∧ code e302594116538 = 4700640627642 := by decide
theorem cert_e302594116538 : check e302594116538 [[.under],[.under]] .three = true := by decide
def e302594116566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302594116566 : Closed e302594116566 ∧ code e302594116566 = 4700640627670 := by decide
theorem cert_e302594116566 : check e302594116566 [[.under],[.under]] .three = true := by decide
def e302594116570 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302594116570 : Closed e302594116570 ∧ code e302594116570 = 4700640627674 := by decide
theorem cert_e302594116570 : check e302594116570 [[.under],[.under]] .three = true := by decide
def e302594116846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302594116846 : Closed e302594116846 ∧ code e302594116846 = 4700640627950 := by decide
theorem cert_e302594116846 : check e302594116846 [[.under],[.under]] .three = true := by decide
def e302594116854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302594116854 : Closed e302594116854 ∧ code e302594116854 = 4700640627958 := by decide
theorem cert_e302594116854 : check e302594116854 [[.under],[.under]] .three = true := by decide
def e302594117230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302594117230 : Closed e302594117230 ∧ code e302594117230 = 4700640628334 := by decide
theorem cert_e302594117230 : check e302594117230 [[.under],[.under]] .three = true := by decide
def e302594117242 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302594117242 : Closed e302594117242 ∧ code e302594117242 = 4700640628346 := by decide
theorem cert_e302594117242 : check e302594117242 [[.under],[.under]] .three = true := by decide
def e302594117430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302594117430 : Closed e302594117430 ∧ code e302594117430 = 4700640628534 := by decide
theorem cert_e302594117430 : check e302594117430 [[.under],[.under]] .three = true := by decide
def e302594117434 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302594117434 : Closed e302594117434 ∧ code e302594117434 = 4700640628538 := by decide
theorem cert_e302594117434 : check e302594117434 [[.under],[.under]] .three = true := by decide
def e302594657134 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302594657134 : Closed e302594657134 ∧ code e302594657134 = 4700641168238 := by decide
theorem cert_e302594657134 : check e302594657134 [[.under],[.under]] .smaller = true := by decide
def e302594657142 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302594657142 : Closed e302594657142 ∧ code e302594657142 = 4700641168246 := by decide
theorem cert_e302594657142 : check e302594657142 [[.under],[.under]] .smaller = true := by decide
def e302594657198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302594657198 : Closed e302594657198 ∧ code e302594657198 = 4700641168302 := by decide
theorem cert_e302594657198 : check e302594657198 [[.under],[.under]] .smaller = true := by decide
def e302594657210 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302594657210 : Closed e302594657210 ∧ code e302594657210 = 4700641168314 := by decide
theorem cert_e302594657210 : check e302594657210 [[.under],[.under]] .smaller = true := by decide
def e302594657238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302594657238 : Closed e302594657238 ∧ code e302594657238 = 4700641168342 := by decide
theorem cert_e302594657238 : check e302594657238 [[.under],[.under]] .smaller = true := by decide
def e302594657242 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302594657242 : Closed e302594657242 ∧ code e302594657242 = 4700641168346 := by decide
theorem cert_e302594657242 : check e302594657242 [[.under],[.under]] .smaller = true := by decide
def e302594657518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302594657518 : Closed e302594657518 ∧ code e302594657518 = 4700641168622 := by decide
theorem cert_e302594657518 : check e302594657518 [[.under],[.under]] .smaller = true := by decide
def e302594657526 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302594657526 : Closed e302594657526 ∧ code e302594657526 = 4700641168630 := by decide
theorem cert_e302594657526 : check e302594657526 [[.under],[.under]] .smaller = true := by decide
def e302594657902 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302594657902 : Closed e302594657902 ∧ code e302594657902 = 4700641169006 := by decide
theorem cert_e302594657902 : check e302594657902 [[.under],[.under]] .smaller = true := by decide
def e302594657914 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302594657914 : Closed e302594657914 ∧ code e302594657914 = 4700641169018 := by decide
theorem cert_e302594657914 : check e302594657914 [[.under],[.under]] .smaller = true := by decide
def e302594658102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302594658102 : Closed e302594658102 ∧ code e302594658102 = 4700641169206 := by decide
theorem cert_e302594658102 : check e302594658102 [[.under],[.under]] .smaller = true := by decide
def e302594658106 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302594658106 : Closed e302594658106 ∧ code e302594658106 = 4700641169210 := by decide
theorem cert_e302594658106 : check e302594658106 [[.under],[.under]] .smaller = true := by decide
def e302800809438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e302800809438 : Closed e302800809438 ∧ code e302800809438 = 4700847320542 := by decide
theorem cert_e302800809438 : check e302800809438 [[.under],[.under]] .three = true := by decide
def e302800809454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e302800809454 : Closed e302800809454 ∧ code e302800809454 = 4700847320558 := by decide
theorem cert_e302800809454 : check e302800809454 [[.under],[.under]] .three = true := by decide
def e302800809694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e302800809694 : Closed e302800809694 ∧ code e302800809694 = 4700847320798 := by decide
theorem cert_e302800809694 : check e302800809694 [[.under],[.under]] .three = true := by decide
def e302800809718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e302800809718 : Closed e302800809718 ∧ code e302800809718 = 4700847320822 := by decide
theorem cert_e302800809718 : check e302800809718 [[.under],[.under]] .three = true := by decide
def e302800809838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e302800809838 : Closed e302800809838 ∧ code e302800809838 = 4700847320942 := by decide
theorem cert_e302800809838 : check e302800809838 [[.under],[.under]] .three = true := by decide
def e302800809846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e302800809846 : Closed e302800809846 ∧ code e302800809846 = 4700847320950 := by decide
theorem cert_e302800809846 : check e302800809846 [[.under],[.under]] .three = true := by decide
def e302800811486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e302800811486 : Closed e302800811486 ∧ code e302800811486 = 4700847322590 := by decide
theorem cert_e302800811486 : check e302800811486 [[.under],[.under]] .three = true := by decide
def e302800811502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e302800811502 : Closed e302800811502 ∧ code e302800811502 = 4700847322606 := by decide
theorem cert_e302800811502 : check e302800811502 [[.under],[.under]] .three = true := by decide
def e302800811870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e302800811870 : Closed e302800811870 ∧ code e302800811870 = 4700847322974 := by decide
theorem cert_e302800811870 : check e302800811870 [[.under],[.under]] .three = true := by decide
def e302800811898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e302800811898 : Closed e302800811898 ∧ code e302800811898 = 4700847323002 := by decide
theorem cert_e302800811898 : check e302800811898 [[.under],[.under]] .three = true := by decide
def e302800811950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e302800811950 : Closed e302800811950 ∧ code e302800811950 = 4700847323054 := by decide
theorem cert_e302800811950 : check e302800811950 [[.under],[.under]] .three = true := by decide
def e302800811962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e302800811962 : Closed e302800811962 ∧ code e302800811962 = 4700847323066 := by decide
theorem cert_e302800811962 : check e302800811962 [[.under],[.under]] .three = true := by decide
def e302800812766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e302800812766 : Closed e302800812766 ∧ code e302800812766 = 4700847323870 := by decide
theorem cert_e302800812766 : check e302800812766 [[.under],[.under]] .three = true := by decide
def e302800812790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e302800812790 : Closed e302800812790 ∧ code e302800812790 = 4700847323894 := by decide
theorem cert_e302800812790 : check e302800812790 [[.under],[.under]] .three = true := by decide
def e302800812894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e302800812894 : Closed e302800812894 ∧ code e302800812894 = 4700847323998 := by decide
theorem cert_e302800812894 : check e302800812894 [[.under],[.under]] .three = true := by decide
def e302800812922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e302800812922 : Closed e302800812922 ∧ code e302800812922 = 4700847324026 := by decide
theorem cert_e302800812922 : check e302800812922 [[.under],[.under]] .three = true := by decide
def e302800813014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e302800813014 : Closed e302800813014 ∧ code e302800813014 = 4700847324118 := by decide
theorem cert_e302800813014 : check e302800813014 [[.under],[.under]] .three = true := by decide
def e302800813018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e302800813018 : Closed e302800813018 ∧ code e302800813018 = 4700847324122 := by decide
theorem cert_e302800813018 : check e302800813018 [[.under],[.under]] .three = true := by decide
def e302800813422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302800813422 : Closed e302800813422 ∧ code e302800813422 = 4700847324526 := by decide
theorem cert_e302800813422 : check e302800813422 [[.under],[.under]] .three = true := by decide
def e302800813430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302800813430 : Closed e302800813430 ∧ code e302800813430 = 4700847324534 := by decide
theorem cert_e302800813430 : check e302800813430 [[.under],[.under]] .three = true := by decide
def e302800813486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302800813486 : Closed e302800813486 ∧ code e302800813486 = 4700847324590 := by decide
theorem cert_e302800813486 : check e302800813486 [[.under],[.under]] .three = true := by decide
def e302800813498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302800813498 : Closed e302800813498 ∧ code e302800813498 = 4700847324602 := by decide
theorem cert_e302800813498 : check e302800813498 [[.under],[.under]] .three = true := by decide
def e302800813526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302800813526 : Closed e302800813526 ∧ code e302800813526 = 4700847324630 := by decide
theorem cert_e302800813526 : check e302800813526 [[.under],[.under]] .three = true := by decide
def e302800813530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302800813530 : Closed e302800813530 ∧ code e302800813530 = 4700847324634 := by decide
theorem cert_e302800813530 : check e302800813530 [[.under],[.under]] .three = true := by decide
def e302800819678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e302800819678 : Closed e302800819678 ∧ code e302800819678 = 4700847330782 := by decide
theorem cert_e302800819678 : check e302800819678 [[.under],[.under]] .three = true := by decide
def e302800819694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e302800819694 : Closed e302800819694 ∧ code e302800819694 = 4700847330798 := by decide
theorem cert_e302800819694 : check e302800819694 [[.under],[.under]] .three = true := by decide
def e302800820062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e302800820062 : Closed e302800820062 ∧ code e302800820062 = 4700847331166 := by decide
theorem cert_e302800820062 : check e302800820062 [[.under],[.under]] .three = true := by decide
def e302800820090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e302800820090 : Closed e302800820090 ∧ code e302800820090 = 4700847331194 := by decide
theorem cert_e302800820090 : check e302800820090 [[.under],[.under]] .three = true := by decide
def e302800820142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e302800820142 : Closed e302800820142 ∧ code e302800820142 = 4700847331246 := by decide
theorem cert_e302800820142 : check e302800820142 [[.under],[.under]] .three = true := by decide
def e302800820154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e302800820154 : Closed e302800820154 ∧ code e302800820154 = 4700847331258 := by decide
theorem cert_e302800820154 : check e302800820154 [[.under],[.under]] .three = true := by decide
def e302800821598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e302800821598 : Closed e302800821598 ∧ code e302800821598 = 4700847332702 := by decide
theorem cert_e302800821598 : check e302800821598 [[.under],[.under]] .three = true := by decide
def e302800821626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e302800821626 : Closed e302800821626 ∧ code e302800821626 = 4700847332730 := by decide
theorem cert_e302800821626 : check e302800821626 [[.under],[.under]] .three = true := by decide
def e302800821738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e302800821738 : Closed e302800821738 ∧ code e302800821738 = 4700847332842 := by decide
theorem cert_e302800821738 : check e302800821738 [[.under],[.under]] .three = true := by decide
def e302800821934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e302800821934 : Closed e302800821934 ∧ code e302800821934 = 4700847333038 := by decide
theorem cert_e302800821934 : check e302800821934 [[.under],[.under]] .three = true := by decide
def e302800821946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e302800821946 : Closed e302800821946 ∧ code e302800821946 = 4700847333050 := by decide
theorem cert_e302800821946 : check e302800821946 [[.under],[.under]] .three = true := by decide
def e302800821994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e302800821994 : Closed e302800821994 ∧ code e302800821994 = 4700847333098 := by decide
theorem cert_e302800821994 : check e302800821994 [[.under],[.under]] .three = true := by decide
def e302800825054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e302800825054 : Closed e302800825054 ∧ code e302800825054 = 4700847336158 := by decide
theorem cert_e302800825054 : check e302800825054 [[.under],[.under]] .three = true := by decide
def e302800825078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e302800825078 : Closed e302800825078 ∧ code e302800825078 = 4700847336182 := by decide
theorem cert_e302800825078 : check e302800825078 [[.under],[.under]] .three = true := by decide
def e302800825182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e302800825182 : Closed e302800825182 ∧ code e302800825182 = 4700847336286 := by decide
theorem cert_e302800825182 : check e302800825182 [[.under],[.under]] .three = true := by decide
def e302800825210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e302800825210 : Closed e302800825210 ∧ code e302800825210 = 4700847336314 := by decide
theorem cert_e302800825210 : check e302800825210 [[.under],[.under]] .three = true := by decide
def e302800825302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e302800825302 : Closed e302800825302 ∧ code e302800825302 = 4700847336406 := by decide
theorem cert_e302800825302 : check e302800825302 [[.under],[.under]] .three = true := by decide
def e302800825306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e302800825306 : Closed e302800825306 ∧ code e302800825306 = 4700847336410 := by decide
theorem cert_e302800825306 : check e302800825306 [[.under],[.under]] .three = true := by decide
def e302800825694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e302800825694 : Closed e302800825694 ∧ code e302800825694 = 4700847336798 := by decide
theorem cert_e302800825694 : check e302800825694 [[.under],[.under]] .three = true := by decide
def e302800825722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e302800825722 : Closed e302800825722 ∧ code e302800825722 = 4700847336826 := by decide
theorem cert_e302800825722 : check e302800825722 [[.under],[.under]] .three = true := by decide
def e302800825834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e302800825834 : Closed e302800825834 ∧ code e302800825834 = 4700847336938 := by decide
theorem cert_e302800825834 : check e302800825834 [[.under],[.under]] .three = true := by decide
def e302800826198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302800826198 : Closed e302800826198 ∧ code e302800826198 = 4700847337302 := by decide
theorem cert_e302800826198 : check e302800826198 [[.under],[.under]] .three = true := by decide
def e302800826202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302800826202 : Closed e302800826202 ∧ code e302800826202 = 4700847337306 := by decide
theorem cert_e302800826202 : check e302800826202 [[.under],[.under]] .three = true := by decide
def e302800826218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302800826218 : Closed e302800826218 ∧ code e302800826218 = 4700847337322 := by decide
theorem cert_e302800826218 : check e302800826218 [[.under],[.under]] .three = true := by decide
def e302800827758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302800827758 : Closed e302800827758 ∧ code e302800827758 = 4700847338862 := by decide
theorem cert_e302800827758 : check e302800827758 [[.under],[.under]] .three = true := by decide
def e302800827766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302800827766 : Closed e302800827766 ∧ code e302800827766 = 4700847338870 := by decide
theorem cert_e302800827766 : check e302800827766 [[.under],[.under]] .three = true := by decide
end Blc.Floor42
