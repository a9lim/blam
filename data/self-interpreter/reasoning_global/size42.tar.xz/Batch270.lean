import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1402407984226 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402407984226 : Closed e1402407984226 ∧ code e1402407984226 = 5800454495330 := by decide
theorem cert_e1402407984226 : check e1402407984226 [[.left],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e1402407984390 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402407984390 : Closed e1402407984390 ∧ code e1402407984390 = 5800454495494 := by decide
theorem cert_e1402407984390 : check e1402407984390 [[.left],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1402410634094 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))
theorem wire_e1402410634094 : Closed e1402410634094 ∧ code e1402410634094 = 5800457145198 := by decide
theorem cert_e1402410634094 : check e1402410634094 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634102 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))
theorem wire_e1402410634102 : Closed e1402410634102 ∧ code e1402410634102 = 5800457145206 := by decide
theorem cert_e1402410634102 : check e1402410634102 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634158 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))
theorem wire_e1402410634158 : Closed e1402410634158 ∧ code e1402410634158 = 5800457145262 := by decide
theorem cert_e1402410634158 : check e1402410634158 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))
theorem wire_e1402410634170 : Closed e1402410634170 ∧ code e1402410634170 = 5800457145274 := by decide
theorem cert_e1402410634170 : check e1402410634170 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634198 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))
theorem wire_e1402410634198 : Closed e1402410634198 ∧ code e1402410634198 = 5800457145302 := by decide
theorem cert_e1402410634198 : check e1402410634198 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))
theorem wire_e1402410634202 : Closed e1402410634202 ∧ code e1402410634202 = 5800457145306 := by decide
theorem cert_e1402410634202 : check e1402410634202 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634478 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))
theorem wire_e1402410634478 : Closed e1402410634478 ∧ code e1402410634478 = 5800457145582 := by decide
theorem cert_e1402410634478 : check e1402410634478 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634486 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))
theorem wire_e1402410634486 : Closed e1402410634486 ∧ code e1402410634486 = 5800457145590 := by decide
theorem cert_e1402410634486 : check e1402410634486 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634862 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))
theorem wire_e1402410634862 : Closed e1402410634862 ∧ code e1402410634862 = 5800457145966 := by decide
theorem cert_e1402410634862 : check e1402410634862 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410634874 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))
theorem wire_e1402410634874 : Closed e1402410634874 ∧ code e1402410634874 = 5800457145978 := by decide
theorem cert_e1402410634874 : check e1402410634874 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410635062 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))
theorem wire_e1402410635062 : Closed e1402410635062 ∧ code e1402410635062 = 5800457146166 := by decide
theorem cert_e1402410635062 : check e1402410635062 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402410635066 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))
theorem wire_e1402410635066 : Closed e1402410635066 ∧ code e1402410635066 = 5800457146170 := by decide
theorem cert_e1402410635066 : check e1402410635066 [[.left],[.left],[.left],[.left]] .smaller = true := by decide
def e1402415879902 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))
theorem wire_e1402415879902 : Closed e1402415879902 ∧ code e1402415879902 = 5800462391006 := by decide
private def t_e1402415879902 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))
theorem cert_e1402415879902 : ¬ IsSelfInterpreter e1402415879902 :=
  wSource (t := t_e1402415879902) (replay_sound (ps := []) (t := e1402415879902) (by decide)) (by decide)
def e1402415879926 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))
theorem wire_e1402415879926 : Closed e1402415879926 ∧ code e1402415879926 = 5800462391030 := by decide
private def t_e1402415879926 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))
theorem cert_e1402415879926 : ¬ IsSelfInterpreter e1402415879926 :=
  wSource (t := t_e1402415879926) (replay_sound (ps := []) (t := e1402415879926) (by decide)) (by decide)
def e1402415880030 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))
theorem wire_e1402415880030 : Closed e1402415880030 ∧ code e1402415880030 = 5800462391134 := by decide
private def t_e1402415880030 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))
theorem cert_e1402415880030 : ¬ IsSelfInterpreter e1402415880030 :=
  wSource (t := t_e1402415880030) (replay_sound (ps := []) (t := e1402415880030) (by decide)) (by decide)
def e1402415880058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))
theorem wire_e1402415880058 : Closed e1402415880058 ∧ code e1402415880058 = 5800462391162 := by decide
private def t_e1402415880058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))
theorem cert_e1402415880058 : ¬ IsSelfInterpreter e1402415880058 :=
  wSource (t := t_e1402415880058) (replay_sound (ps := []) (t := e1402415880058) (by decide)) (by decide)
def e1402415880150 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))
theorem wire_e1402415880150 : Closed e1402415880150 ∧ code e1402415880150 = 5800462391254 := by decide
private def t_e1402415880150 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))
theorem cert_e1402415880150 : ¬ IsSelfInterpreter e1402415880150 :=
  wSource (t := t_e1402415880150) (replay_sound (ps := []) (t := e1402415880150) (by decide)) (by decide)
def e1402415880154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))
theorem wire_e1402415880154 : Closed e1402415880154 ∧ code e1402415880154 = 5800462391258 := by decide
private def t_e1402415880154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))
theorem cert_e1402415880154 : ¬ IsSelfInterpreter e1402415880154 :=
  wSource (t := t_e1402415880154) (replay_sound (ps := []) (t := e1402415880154) (by decide)) (by decide)
def e1402415880670 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))
theorem wire_e1402415880670 : Closed e1402415880670 ∧ code e1402415880670 = 5800462391774 := by decide
private def t_e1402415880670 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))
theorem cert_e1402415880670 : ¬ IsSelfInterpreter e1402415880670 :=
  wSource (t := t_e1402415880670) (replay_sound (ps := []) (t := e1402415880670) (by decide)) (by decide)
def e1402415880694 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))
theorem wire_e1402415880694 : Closed e1402415880694 ∧ code e1402415880694 = 5800462391798 := by decide
private def t_e1402415880694 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))
theorem cert_e1402415880694 : ¬ IsSelfInterpreter e1402415880694 :=
  wSource (t := t_e1402415880694) (replay_sound (ps := []) (t := e1402415880694) (by decide)) (by decide)
def e1402415881438 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))
theorem wire_e1402415881438 : Closed e1402415881438 ∧ code e1402415881438 = 5800462392542 := by decide
private def t_e1402415881438 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))
theorem cert_e1402415881438 : ¬ IsSelfInterpreter e1402415881438 :=
  wSource (t := t_e1402415881438) (replay_sound (ps := []) (t := e1402415881438) (by decide)) (by decide)
def e1402415881466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))
theorem wire_e1402415881466 : Closed e1402415881466 ∧ code e1402415881466 = 5800462392570 := by decide
private def t_e1402415881466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))
theorem cert_e1402415881466 : ¬ IsSelfInterpreter e1402415881466 :=
  wSource (t := t_e1402415881466) (replay_sound (ps := []) (t := e1402415881466) (by decide)) (by decide)
def e1402415882038 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))
theorem wire_e1402415882038 : Closed e1402415882038 ∧ code e1402415882038 = 5800462393142 := by decide
private def t_e1402415882038 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))
theorem cert_e1402415882038 : ¬ IsSelfInterpreter e1402415882038 :=
  wSource (t := t_e1402415882038) (replay_sound (ps := []) (t := e1402415882038) (by decide)) (by decide)
def e1402415882042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))
theorem wire_e1402415882042 : Closed e1402415882042 ∧ code e1402415882042 = 5800462393146 := by decide
private def t_e1402415882042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))
theorem cert_e1402415882042 : ¬ IsSelfInterpreter e1402415882042 :=
  wSource (t := t_e1402415882042) (replay_sound (ps := []) (t := e1402415882042) (by decide)) (by decide)
def e1402415896814 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))
theorem wire_e1402415896814 : Closed e1402415896814 ∧ code e1402415896814 = 5800462407918 := by decide
private def t_e1402415896814 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))
theorem cert_e1402415896814 : ¬ IsSelfInterpreter e1402415896814 :=
  wSource (t := t_e1402415896814) (replay_sound (ps := []) (t := e1402415896814) (by decide)) (by decide)
def e1402415896822 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))
theorem wire_e1402415896822 : Closed e1402415896822 ∧ code e1402415896822 = 5800462407926 := by decide
private def t_e1402415896822 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))
theorem cert_e1402415896822 : ¬ IsSelfInterpreter e1402415896822 :=
  wSource (t := t_e1402415896822) (replay_sound (ps := []) (t := e1402415896822) (by decide)) (by decide)
def e1402415897374 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1402415897374 : Closed e1402415897374 ∧ code e1402415897374 = 5800462408478 := by decide
private def t_e1402415897374 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))
theorem cert_e1402415897374 : ¬ IsSelfInterpreter e1402415897374 :=
  wSource (t := t_e1402415897374) (replay_sound (ps := []) (t := e1402415897374) (by decide)) (by decide)
def e1402415897486 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1402415897486 : Closed e1402415897486 ∧ code e1402415897486 = 5800462408590 := by decide
private def t_e1402415897486 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))
theorem cert_e1402415897486 : ¬ IsSelfInterpreter e1402415897486 :=
  wSource (t := t_e1402415897486) (replay_sound (ps := []) (t := e1402415897486) (by decide)) (by decide)
def e1402415897710 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))
theorem wire_e1402415897710 : Closed e1402415897710 ∧ code e1402415897710 = 5800462408814 := by decide
private def t_e1402415897710 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))
theorem cert_e1402415897710 : ¬ IsSelfInterpreter e1402415897710 :=
  wSource (t := t_e1402415897710) (replay_sound (ps := []) (t := e1402415897710) (by decide)) (by decide)
def e1402415897722 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))
theorem wire_e1402415897722 : Closed e1402415897722 ∧ code e1402415897722 = 5800462408826 := by decide
private def t_e1402415897722 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))
theorem cert_e1402415897722 : ¬ IsSelfInterpreter e1402415897722 :=
  wSource (t := t_e1402415897722) (replay_sound (ps := []) (t := e1402415897722) (by decide)) (by decide)
def e1402415897886 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1402415897886 : Closed e1402415897886 ∧ code e1402415897886 = 5800462408990 := by decide
private def t_e1402415897886 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))
theorem cert_e1402415897886 : ¬ IsSelfInterpreter e1402415897886 :=
  wSource (t := t_e1402415897886) (replay_sound (ps := []) (t := e1402415897886) (by decide)) (by decide)
def e1402415898054 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1402415898054 : Closed e1402415898054 ∧ code e1402415898054 = 5800462409158 := by decide
private def t_e1402415898054 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))
theorem cert_e1402415898054 : ¬ IsSelfInterpreter e1402415898054 :=
  wSource (t := t_e1402415898054) (replay_sound (ps := []) (t := e1402415898054) (by decide)) (by decide)
def e1402415898166 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))
theorem wire_e1402415898166 : Closed e1402415898166 ∧ code e1402415898166 = 5800462409270 := by decide
private def t_e1402415898166 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))
theorem cert_e1402415898166 : ¬ IsSelfInterpreter e1402415898166 :=
  wSource (t := t_e1402415898166) (replay_sound (ps := []) (t := e1402415898166) (by decide)) (by decide)
def e1402415898170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))
theorem wire_e1402415898170 : Closed e1402415898170 ∧ code e1402415898170 = 5800462409274 := by decide
private def t_e1402415898170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))
theorem cert_e1402415898170 : ¬ IsSelfInterpreter e1402415898170 :=
  wSource (t := t_e1402415898170) (replay_sound (ps := []) (t := e1402415898170) (by decide)) (by decide)
def e1402415898254 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))
theorem wire_e1402415898254 : Closed e1402415898254 ∧ code e1402415898254 = 5800462409358 := by decide
private def t_e1402415898254 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))
theorem cert_e1402415898254 : ¬ IsSelfInterpreter e1402415898254 :=
  wSource (t := t_e1402415898254) (replay_sound (ps := []) (t := e1402415898254) (by decide)) (by decide)
def e1402415898310 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))
theorem wire_e1402415898310 : Closed e1402415898310 ∧ code e1402415898310 = 5800462409414 := by decide
private def t_e1402415898310 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))
theorem cert_e1402415898310 : ¬ IsSelfInterpreter e1402415898310 :=
  wSource (t := t_e1402415898310) (replay_sound (ps := []) (t := e1402415898310) (by decide)) (by decide)
def e1402415900446 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1402415900446 : Closed e1402415900446 ∧ code e1402415900446 = 5800462411550 := by decide
private def t_e1402415900446 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))
theorem cert_e1402415900446 : ¬ IsSelfInterpreter e1402415900446 :=
  wSource (t := t_e1402415900446) (replay_sound (ps := []) (t := e1402415900446) (by decide)) (by decide)
def e1402415900558 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1402415900558 : Closed e1402415900558 ∧ code e1402415900558 = 5800462411662 := by decide
private def t_e1402415900558 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))
theorem cert_e1402415900558 : ¬ IsSelfInterpreter e1402415900558 :=
  wSource (t := t_e1402415900558) (replay_sound (ps := []) (t := e1402415900558) (by decide)) (by decide)
def e1402415903518 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1402415903518 : Closed e1402415903518 ∧ code e1402415903518 = 5800462414622 := by decide
private def t_e1402415903518 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))
theorem cert_e1402415903518 : ¬ IsSelfInterpreter e1402415903518 :=
  wSource (t := t_e1402415903518) (replay_sound (ps := []) (t := e1402415903518) (by decide)) (by decide)
def e1402415903686 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1402415903686 : Closed e1402415903686 ∧ code e1402415903686 = 5800462414790 := by decide
private def t_e1402415903686 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))
theorem cert_e1402415903686 : ¬ IsSelfInterpreter e1402415903686 :=
  wSource (t := t_e1402415903686) (replay_sound (ps := []) (t := e1402415903686) (by decide)) (by decide)
def e1402415905166 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1402415905166 : Closed e1402415905166 ∧ code e1402415905166 = 5800462416270 := by decide
private def t_e1402415905166 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e1402415905166 : ¬ IsSelfInterpreter e1402415905166 :=
  wSource (t := t_e1402415905166) (replay_sound (ps := []) (t := e1402415905166) (by decide)) (by decide)
def e1402415905222 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1402415905222 : Closed e1402415905222 ∧ code e1402415905222 = 5800462416326 := by decide
private def t_e1402415905222 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e1402415905222 : ¬ IsSelfInterpreter e1402415905222 :=
  wSource (t := t_e1402415905222) (replay_sound (ps := []) (t := e1402415905222) (by decide)) (by decide)
end Blc.Floor42
