import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196685650374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1196685650374 : Closed e1196685650374 ∧ code e1196685650374 = 5594732161478 := by decide
theorem cert_e1196685650374 : check e1196685650374 [[],[.left],[]] .chain = true := by decide
def e1196685651142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1196685651142 : Closed e1196685651142 ∧ code e1196685651142 = 5594732162246 := by decide
theorem cert_e1196685651142 : check e1196685651142 [[],[.left],[]] .chain = true := by decide
def e1196685661918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1196685661918 : Closed e1196685661918 ∧ code e1196685661918 = 5594732173022 := by decide
theorem cert_e1196685661918 : check e1196685661918 [[],[.left],[]] .chain = true := by decide
def e1196685661942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1196685661942 : Closed e1196685661942 ∧ code e1196685661942 = 5594732173046 := by decide
theorem cert_e1196685661942 : check e1196685661942 [[],[.left],[]] .chain = true := by decide
def e1196685662046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1196685662046 : Closed e1196685662046 ∧ code e1196685662046 = 5594732173150 := by decide
theorem cert_e1196685662046 : check e1196685662046 [[],[.left],[]] .chain = true := by decide
def e1196685662074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1196685662074 : Closed e1196685662074 ∧ code e1196685662074 = 5594732173178 := by decide
theorem cert_e1196685662074 : check e1196685662074 [[],[.left],[]] .chain = true := by decide
def e1196685662166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1196685662166 : Closed e1196685662166 ∧ code e1196685662166 = 5594732173270 := by decide
theorem cert_e1196685662166 : check e1196685662166 [[],[.left],[]] .chain = true := by decide
def e1196685662170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1196685662170 : Closed e1196685662170 ∧ code e1196685662170 = 5594732173274 := by decide
theorem cert_e1196685662170 : check e1196685662170 [[],[.left],[]] .chain = true := by decide
def e1196685662686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1196685662686 : Closed e1196685662686 ∧ code e1196685662686 = 5594732173790 := by decide
theorem cert_e1196685662686 : check e1196685662686 [[],[.left],[]] .chain = true := by decide
def e1196685662710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1196685662710 : Closed e1196685662710 ∧ code e1196685662710 = 5594732173814 := by decide
theorem cert_e1196685662710 : check e1196685662710 [[],[.left],[]] .chain = true := by decide
def e1196685663454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1196685663454 : Closed e1196685663454 ∧ code e1196685663454 = 5594732174558 := by decide
theorem cert_e1196685663454 : check e1196685663454 [[],[.left],[]] .chain = true := by decide
def e1196685663482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1196685663482 : Closed e1196685663482 ∧ code e1196685663482 = 5594732174586 := by decide
theorem cert_e1196685663482 : check e1196685663482 [[],[.left],[]] .chain = true := by decide
def e1196685664054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196685664054 : Closed e1196685664054 ∧ code e1196685664054 = 5594732175158 := by decide
theorem cert_e1196685664054 : check e1196685664054 [[],[.left],[]] .chain = true := by decide
def e1196685664058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196685664058 : Closed e1196685664058 ∧ code e1196685664058 = 5594732175162 := by decide
theorem cert_e1196685664058 : check e1196685664058 [[],[.left],[]] .chain = true := by decide
def e1196685678830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1196685678830 : Closed e1196685678830 ∧ code e1196685678830 = 5594732189934 := by decide
theorem cert_e1196685678830 : check e1196685678830 [[],[.left],[]] .chain = true := by decide
def e1196685678838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1196685678838 : Closed e1196685678838 ∧ code e1196685678838 = 5594732189942 := by decide
theorem cert_e1196685678838 : check e1196685678838 [[],[.left],[]] .chain = true := by decide
def e1196685679390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1196685679390 : Closed e1196685679390 ∧ code e1196685679390 = 5594732190494 := by decide
theorem cert_e1196685679390 : check e1196685679390 [[],[.left],[]] .chain = true := by decide
def e1196685679502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1196685679502 : Closed e1196685679502 ∧ code e1196685679502 = 5594732190606 := by decide
theorem cert_e1196685679502 : check e1196685679502 [[],[.left],[]] .chain = true := by decide
def e1196685679726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1196685679726 : Closed e1196685679726 ∧ code e1196685679726 = 5594732190830 := by decide
theorem cert_e1196685679726 : check e1196685679726 [[],[.left],[]] .chain = true := by decide
def e1196685679738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1196685679738 : Closed e1196685679738 ∧ code e1196685679738 = 5594732190842 := by decide
theorem cert_e1196685679738 : check e1196685679738 [[],[.left],[]] .chain = true := by decide
def e1196685679902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1196685679902 : Closed e1196685679902 ∧ code e1196685679902 = 5594732191006 := by decide
theorem cert_e1196685679902 : check e1196685679902 [[],[.left],[]] .chain = true := by decide
def e1196685680070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1196685680070 : Closed e1196685680070 ∧ code e1196685680070 = 5594732191174 := by decide
theorem cert_e1196685680070 : check e1196685680070 [[],[.left],[]] .chain = true := by decide
def e1196685680182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1196685680182 : Closed e1196685680182 ∧ code e1196685680182 = 5594732191286 := by decide
theorem cert_e1196685680182 : check e1196685680182 [[],[.left],[]] .chain = true := by decide
def e1196685680186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1196685680186 : Closed e1196685680186 ∧ code e1196685680186 = 5594732191290 := by decide
theorem cert_e1196685680186 : check e1196685680186 [[],[.left],[]] .chain = true := by decide
def e1196685680270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1196685680270 : Closed e1196685680270 ∧ code e1196685680270 = 5594732191374 := by decide
theorem cert_e1196685680270 : check e1196685680270 [[],[.left],[]] .chain = true := by decide
def e1196685680326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1196685680326 : Closed e1196685680326 ∧ code e1196685680326 = 5594732191430 := by decide
theorem cert_e1196685680326 : check e1196685680326 [[],[.left],[]] .chain = true := by decide
def e1196685682462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1196685682462 : Closed e1196685682462 ∧ code e1196685682462 = 5594732193566 := by decide
theorem cert_e1196685682462 : check e1196685682462 [[],[.left],[]] .chain = true := by decide
def e1196685682574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1196685682574 : Closed e1196685682574 ∧ code e1196685682574 = 5594732193678 := by decide
theorem cert_e1196685682574 : check e1196685682574 [[],[.left],[]] .chain = true := by decide
def e1196685685534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1196685685534 : Closed e1196685685534 ∧ code e1196685685534 = 5594732196638 := by decide
theorem cert_e1196685685534 : check e1196685685534 [[],[.left],[]] .chain = true := by decide
def e1196685685702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1196685685702 : Closed e1196685685702 ∧ code e1196685685702 = 5594732196806 := by decide
theorem cert_e1196685685702 : check e1196685685702 [[],[.left],[]] .chain = true := by decide
def e1196685687182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1196685687182 : Closed e1196685687182 ∧ code e1196685687182 = 5594732198286 := by decide
theorem cert_e1196685687182 : check e1196685687182 [[],[.left],[]] .chain = true := by decide
def e1196685687238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1196685687238 : Closed e1196685687238 ∧ code e1196685687238 = 5594732198342 := by decide
theorem cert_e1196685687238 : check e1196685687238 [[],[.left],[]] .chain = true := by decide
def e1196685724526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1196685724526 : Closed e1196685724526 ∧ code e1196685724526 = 5594732235630 := by decide
theorem cert_e1196685724526 : check e1196685724526 [[],[.left],[]] .smaller = true := by decide
def e1196685724534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1196685724534 : Closed e1196685724534 ∧ code e1196685724534 = 5594732235638 := by decide
theorem cert_e1196685724534 : check e1196685724534 [[],[.left],[]] .smaller = true := by decide
def e1196685724590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1196685724590 : Closed e1196685724590 ∧ code e1196685724590 = 5594732235694 := by decide
theorem cert_e1196685724590 : check e1196685724590 [[],[.left],[]] .smaller = true := by decide
def e1196685724602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1196685724602 : Closed e1196685724602 ∧ code e1196685724602 = 5594732235706 := by decide
theorem cert_e1196685724602 : check e1196685724602 [[],[.left],[]] .smaller = true := by decide
def e1196685724630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1196685724630 : Closed e1196685724630 ∧ code e1196685724630 = 5594732235734 := by decide
theorem cert_e1196685724630 : check e1196685724630 [[],[.left],[]] .smaller = true := by decide
def e1196685724634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1196685724634 : Closed e1196685724634 ∧ code e1196685724634 = 5594732235738 := by decide
theorem cert_e1196685724634 : check e1196685724634 [[],[.left],[]] .smaller = true := by decide
def e1196685724910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1196685724910 : Closed e1196685724910 ∧ code e1196685724910 = 5594732236014 := by decide
theorem cert_e1196685724910 : check e1196685724910 [[],[.left],[]] .smaller = true := by decide
def e1196685724918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1196685724918 : Closed e1196685724918 ∧ code e1196685724918 = 5594732236022 := by decide
theorem cert_e1196685724918 : check e1196685724918 [[],[.left],[]] .smaller = true := by decide
def e1196685725294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1196685725294 : Closed e1196685725294 ∧ code e1196685725294 = 5594732236398 := by decide
theorem cert_e1196685725294 : check e1196685725294 [[],[.left],[]] .smaller = true := by decide
def e1196685725306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1196685725306 : Closed e1196685725306 ∧ code e1196685725306 = 5594732236410 := by decide
theorem cert_e1196685725306 : check e1196685725306 [[],[.left],[]] .smaller = true := by decide
def e1196685725494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1196685725494 : Closed e1196685725494 ∧ code e1196685725494 = 5594732236598 := by decide
theorem cert_e1196685725494 : check e1196685725494 [[],[.left],[]] .smaller = true := by decide
def e1196685725498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1196685725498 : Closed e1196685725498 ∧ code e1196685725498 = 5594732236602 := by decide
theorem cert_e1196685725498 : check e1196685725498 [[],[.left],[]] .smaller = true := by decide
def e1196685732974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1196685732974 : Closed e1196685732974 ∧ code e1196685732974 = 5594732244078 := by decide
theorem cert_e1196685732974 : check e1196685732974 [[],[.left],[]] .chain = true := by decide
def e1196685732986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1196685732986 : Closed e1196685732986 ∧ code e1196685732986 = 5594732244090 := by decide
theorem cert_e1196685732986 : check e1196685732986 [[],[.left],[]] .chain = true := by decide
def e1196685733150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1196685733150 : Closed e1196685733150 ∧ code e1196685733150 = 5594732244254 := by decide
theorem cert_e1196685733150 : check e1196685733150 [[],[.left],[]] .chain = true := by decide
def e1196685733318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1196685733318 : Closed e1196685733318 ∧ code e1196685733318 = 5594732244422 := by decide
theorem cert_e1196685733318 : check e1196685733318 [[],[.left],[]] .chain = true := by decide
def e1196685733658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1196685733658 : Closed e1196685733658 ∧ code e1196685733658 = 5594732244762 := by decide
theorem cert_e1196685733658 : check e1196685733658 [[],[.left],[]] .chain = true := by decide
def e1196685733702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1196685733702 : Closed e1196685733702 ∧ code e1196685733702 = 5594732244806 := by decide
theorem cert_e1196685733702 : check e1196685733702 [[],[.left],[]] .chain = true := by decide
def e1196685734686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1196685734686 : Closed e1196685734686 ∧ code e1196685734686 = 5594732245790 := by decide
theorem cert_e1196685734686 : check e1196685734686 [[],[.left],[]] .chain = true := by decide
def e1196685734854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1196685734854 : Closed e1196685734854 ∧ code e1196685734854 = 5594732245958 := by decide
theorem cert_e1196685734854 : check e1196685734854 [[],[.left],[]] .chain = true := by decide
def e1196685737158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1196685737158 : Closed e1196685737158 ∧ code e1196685737158 = 5594732248262 := by decide
theorem cert_e1196685737158 : check e1196685737158 [[],[.left],[]] .chain = true := by decide
def e1196685760054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1196685760054 : Closed e1196685760054 ∧ code e1196685760054 = 5594732271158 := by decide
theorem cert_e1196685760054 : check e1196685760054 [[],[.left],[]] .chain = true := by decide
def e1196685760058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1196685760058 : Closed e1196685760058 ∧ code e1196685760058 = 5594732271162 := by decide
theorem cert_e1196685760058 : check e1196685760058 [[],[.left],[]] .chain = true := by decide
def e1196685760142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1196685760142 : Closed e1196685760142 ∧ code e1196685760142 = 5594732271246 := by decide
theorem cert_e1196685760142 : check e1196685760142 [[],[.left],[]] .chain = true := by decide
def e1196685760198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1196685760198 : Closed e1196685760198 ∧ code e1196685760198 = 5594732271302 := by decide
theorem cert_e1196685760198 : check e1196685760198 [[],[.left],[]] .chain = true := by decide
def e1196685760282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e1196685760282 : Closed e1196685760282 ∧ code e1196685760282 = 5594732271386 := by decide
theorem cert_e1196685760282 : check e1196685760282 [[],[.left],[]] .chain = true := by decide
def e1196685760326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e1196685760326 : Closed e1196685760326 ∧ code e1196685760326 = 5594732271430 := by decide
theorem cert_e1196685760326 : check e1196685760326 [[],[.left],[]] .chain = true := by decide
def e1196685760910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1196685760910 : Closed e1196685760910 ∧ code e1196685760910 = 5594732272014 := by decide
theorem cert_e1196685760910 : check e1196685760910 [[],[.left],[]] .chain = true := by decide
def e1196685760966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1196685760966 : Closed e1196685760966 ∧ code e1196685760966 = 5594732272070 := by decide
theorem cert_e1196685760966 : check e1196685760966 [[],[.left],[]] .chain = true := by decide
def e1196685761734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1196685761734 : Closed e1196685761734 ∧ code e1196685761734 = 5594732272838 := by decide
theorem cert_e1196685761734 : check e1196685761734 [[],[.left],[]] .chain = true := by decide
def e1196686666606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1196686666606 : Closed e1196686666606 ∧ code e1196686666606 = 5594733177710 := by decide
theorem cert_e1196686666606 : check e1196686666606 [[],[.left],[]] .sourceHead = true := by decide
def e1196686666614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1196686666614 : Closed e1196686666614 ∧ code e1196686666614 = 5594733177718 := by decide
theorem cert_e1196686666614 : check e1196686666614 [[],[.left],[]] .sourceHead = true := by decide
def e1196686666678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1196686666678 : Closed e1196686666678 ∧ code e1196686666678 = 5594733177782 := by decide
theorem cert_e1196686666678 : check e1196686666678 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1196686667118 : Closed e1196686667118 ∧ code e1196686667118 = 5594733178222 := by decide
theorem cert_e1196686667118 : check e1196686667118 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1196686667126 : Closed e1196686667126 ∧ code e1196686667126 = 5594733178230 := by decide
theorem cert_e1196686667126 : check e1196686667126 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1196686667182 : Closed e1196686667182 ∧ code e1196686667182 = 5594733178286 := by decide
theorem cert_e1196686667182 : check e1196686667182 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1196686667194 : Closed e1196686667194 ∧ code e1196686667194 = 5594733178298 := by decide
theorem cert_e1196686667194 : check e1196686667194 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1196686667222 : Closed e1196686667222 ∧ code e1196686667222 = 5594733178326 := by decide
theorem cert_e1196686667222 : check e1196686667222 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1196686667226 : Closed e1196686667226 ∧ code e1196686667226 = 5594733178330 := by decide
theorem cert_e1196686667226 : check e1196686667226 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1196686667446 : Closed e1196686667446 ∧ code e1196686667446 = 5594733178550 := by decide
theorem cert_e1196686667446 : check e1196686667446 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1196686667478 : Closed e1196686667478 ∧ code e1196686667478 = 5594733178582 := by decide
theorem cert_e1196686667478 : check e1196686667478 [[],[.left],[]] .sourceHead = true := by decide
def e1196686667482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1196686667482 : Closed e1196686667482 ∧ code e1196686667482 = 5594733178586 := by decide
theorem cert_e1196686667482 : check e1196686667482 [[],[.left],[]] .sourceHead = true := by decide
def e1196686669166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1196686669166 : Closed e1196686669166 ∧ code e1196686669166 = 5594733180270 := by decide
theorem cert_e1196686669166 : check e1196686669166 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686669174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1196686669174 : Closed e1196686669174 ∧ code e1196686669174 = 5594733180278 := by decide
theorem cert_e1196686669174 : check e1196686669174 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686669230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1196686669230 : Closed e1196686669230 ∧ code e1196686669230 = 5594733180334 := by decide
def e1196686669242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1196686669242 : Closed e1196686669242 ∧ code e1196686669242 = 5594733180346 := by decide
def e1196686669270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1196686669270 : Closed e1196686669270 ∧ code e1196686669270 = 5594733180374 := by decide
theorem cert_e1196686669270 : check e1196686669270 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686669274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1196686669274 : Closed e1196686669274 ∧ code e1196686669274 = 5594733180378 := by decide
theorem cert_e1196686669274 : check e1196686669274 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686669486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1196686669486 : Closed e1196686669486 ∧ code e1196686669486 = 5594733180590 := by decide
theorem cert_e1196686669486 : check e1196686669486 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686669498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1196686669498 : Closed e1196686669498 ∧ code e1196686669498 = 5594733180602 := by decide
theorem cert_e1196686669498 : check e1196686669498 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686669546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1196686669546 : Closed e1196686669546 ∧ code e1196686669546 = 5594733180650 := by decide
def e1196686669654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1196686669654 : Closed e1196686669654 ∧ code e1196686669654 = 5594733180758 := by decide
theorem cert_e1196686669654 : check e1196686669654 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686669658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1196686669658 : Closed e1196686669658 ∧ code e1196686669658 = 5594733180762 := by decide
theorem cert_e1196686669658 : check e1196686669658 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686669674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1196686669674 : Closed e1196686669674 ∧ code e1196686669674 = 5594733180778 := by decide
def e1196686670518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1196686670518 : Closed e1196686670518 ∧ code e1196686670518 = 5594733181622 := by decide
theorem cert_e1196686670518 : check e1196686670518 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686670550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1196686670550 : Closed e1196686670550 ∧ code e1196686670550 = 5594733181654 := by decide
theorem cert_e1196686670550 : check e1196686670550 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686670554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1196686670554 : Closed e1196686670554 ∧ code e1196686670554 = 5594733181658 := by decide
theorem cert_e1196686670554 : check e1196686670554 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686670678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1196686670678 : Closed e1196686670678 ∧ code e1196686670678 = 5594733181782 := by decide
theorem cert_e1196686670678 : check e1196686670678 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e1196686670682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1196686670682 : Closed e1196686670682 ∧ code e1196686670682 = 5594733181786 := by decide
theorem cert_e1196686670682 : check e1196686670682 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686670698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1196686670698 : Closed e1196686670698 ∧ code e1196686670698 = 5594733181802 := by decide
def e1196686675694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e1196686675694 : Closed e1196686675694 ∧ code e1196686675694 = 5594733186798 := by decide
theorem cert_e1196686675694 : check e1196686675694 [[],[.left],[]] .sourceHead = true := by decide
def e1196686675822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e1196686675822 : Closed e1196686675822 ∧ code e1196686675822 = 5594733186926 := by decide
theorem cert_e1196686675822 : check e1196686675822 [[],[.left],[]] .sourceHead = true := by decide
def e1196686675830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e1196686675830 : Closed e1196686675830 ∧ code e1196686675830 = 5594733186934 := by decide
theorem cert_e1196686675830 : check e1196686675830 [[],[.left],[]] .sourceHead = true := by decide
def e1196686678894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e1196686678894 : Closed e1196686678894 ∧ code e1196686678894 = 5594733189998 := by decide
theorem cert_e1196686678894 : check e1196686678894 [[],[.left],[]] .sourceHead = true := by decide
def e1196686678902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e1196686678902 : Closed e1196686678902 ∧ code e1196686678902 = 5594733190006 := by decide
theorem cert_e1196686678902 : check e1196686678902 [[],[.left],[]] .sourceHead = true := by decide
def e1196686678966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e1196686678966 : Closed e1196686678966 ∧ code e1196686678966 = 5594733190070 := by decide
theorem cert_e1196686678966 : check e1196686678966 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1196686679406 : Closed e1196686679406 ∧ code e1196686679406 = 5594733190510 := by decide
theorem cert_e1196686679406 : check e1196686679406 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1196686679414 : Closed e1196686679414 ∧ code e1196686679414 = 5594733190518 := by decide
theorem cert_e1196686679414 : check e1196686679414 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1196686679470 : Closed e1196686679470 ∧ code e1196686679470 = 5594733190574 := by decide
theorem cert_e1196686679470 : check e1196686679470 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1196686679482 : Closed e1196686679482 ∧ code e1196686679482 = 5594733190586 := by decide
theorem cert_e1196686679482 : check e1196686679482 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1196686679510 : Closed e1196686679510 ∧ code e1196686679510 = 5594733190614 := by decide
theorem cert_e1196686679510 : check e1196686679510 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1196686679514 : Closed e1196686679514 ∧ code e1196686679514 = 5594733190618 := by decide
theorem cert_e1196686679514 : check e1196686679514 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e1196686679734 : Closed e1196686679734 ∧ code e1196686679734 = 5594733190838 := by decide
theorem cert_e1196686679734 : check e1196686679734 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e1196686679766 : Closed e1196686679766 ∧ code e1196686679766 = 5594733190870 := by decide
theorem cert_e1196686679766 : check e1196686679766 [[],[.left],[]] .sourceHead = true := by decide
def e1196686679770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e1196686679770 : Closed e1196686679770 ∧ code e1196686679770 = 5594733190874 := by decide
theorem cert_e1196686679770 : check e1196686679770 [[],[.left],[]] .sourceHead = true := by decide
def e1196686681966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1196686681966 : Closed e1196686681966 ∧ code e1196686681966 = 5594733193070 := by decide
theorem cert_e1196686681966 : check e1196686681966 [[],[.left],[]] .sourceHead = true := by decide
def e1196686681974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1196686681974 : Closed e1196686681974 ∧ code e1196686681974 = 5594733193078 := by decide
theorem cert_e1196686681974 : check e1196686681974 [[],[.left],[]] .sourceHead = true := by decide
def e1196686682038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1196686682038 : Closed e1196686682038 ∧ code e1196686682038 = 5594733193142 := by decide
theorem cert_e1196686682038 : check e1196686682038 [[],[.left],[]] .sourceHead = true := by decide
def e1196686683374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686683374 : Closed e1196686683374 ∧ code e1196686683374 = 5594733194478 := by decide
theorem cert_e1196686683374 : check e1196686683374 [[],[.left],[]] .sourceHead = true := by decide
def e1196686683382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686683382 : Closed e1196686683382 ∧ code e1196686683382 = 5594733194486 := by decide
theorem cert_e1196686683382 : check e1196686683382 [[],[.left],[]] .sourceHead = true := by decide
def e1196686683766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196686683766 : Closed e1196686683766 ∧ code e1196686683766 = 5594733194870 := by decide
theorem cert_e1196686683766 : check e1196686683766 [[],[.left],[]] .sourceHead = true := by decide
def e1196686684654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1196686684654 : Closed e1196686684654 ∧ code e1196686684654 = 5594733195758 := by decide
theorem cert_e1196686684654 : check e1196686684654 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1196686685038 : Closed e1196686685038 ∧ code e1196686685038 = 5594733196142 := by decide
theorem cert_e1196686685038 : check e1196686685038 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1196686685046 : Closed e1196686685046 ∧ code e1196686685046 = 5594733196150 := by decide
theorem cert_e1196686685046 : check e1196686685046 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1196686685102 : Closed e1196686685102 ∧ code e1196686685102 = 5594733196206 := by decide
theorem cert_e1196686685102 : check e1196686685102 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1196686685114 : Closed e1196686685114 ∧ code e1196686685114 = 5594733196218 := by decide
theorem cert_e1196686685114 : check e1196686685114 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1196686685142 : Closed e1196686685142 ∧ code e1196686685142 = 5594733196246 := by decide
theorem cert_e1196686685142 : check e1196686685142 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1196686685146 : Closed e1196686685146 ∧ code e1196686685146 = 5594733196250 := by decide
theorem cert_e1196686685146 : check e1196686685146 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686685422 : Closed e1196686685422 ∧ code e1196686685422 = 5594733196526 := by decide
theorem cert_e1196686685422 : check e1196686685422 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196686685430 : Closed e1196686685430 ∧ code e1196686685430 = 5594733196534 := by decide
theorem cert_e1196686685430 : check e1196686685430 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196686685806 : Closed e1196686685806 ∧ code e1196686685806 = 5594733196910 := by decide
theorem cert_e1196686685806 : check e1196686685806 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196686685818 : Closed e1196686685818 ∧ code e1196686685818 = 5594733196922 := by decide
theorem cert_e1196686685818 : check e1196686685818 [[],[.left],[]] .sourceHead = true := by decide
def e1196686685982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e1196686685982 : Closed e1196686685982 ∧ code e1196686685982 = 5594733197086 := by decide
theorem cert_e1196686685982 : check e1196686685982 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686686006 : Closed e1196686686006 ∧ code e1196686686006 = 5594733197110 := by decide
theorem cert_e1196686686006 : check e1196686686006 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686686010 : Closed e1196686686010 ∧ code e1196686686010 = 5594733197114 := by decide
theorem cert_e1196686686010 : check e1196686686010 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e1196686686446 : Closed e1196686686446 ∧ code e1196686686446 = 5594733197550 := by decide
theorem cert_e1196686686446 : check e1196686686446 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e1196686686454 : Closed e1196686686454 ∧ code e1196686686454 = 5594733197558 := by decide
theorem cert_e1196686686454 : check e1196686686454 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1196686686646 : Closed e1196686686646 ∧ code e1196686686646 = 5594733197750 := by decide
theorem cert_e1196686686646 : check e1196686686646 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1196686686678 : Closed e1196686686678 ∧ code e1196686686678 = 5594733197782 := by decide
theorem cert_e1196686686678 : check e1196686686678 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1196686686682 : Closed e1196686686682 ∧ code e1196686686682 = 5594733197786 := by decide
theorem cert_e1196686686682 : check e1196686686682 [[],[.left],[]] .sourceHead = true := by decide
def e1196686686838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196686686838 : Closed e1196686686838 ∧ code e1196686686838 = 5594733197942 := by decide
theorem cert_e1196686686838 : check e1196686686838 [[],[.left],[]] .sourceHead = true := by decide
def e1196686687006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e1196686687006 : Closed e1196686687006 ∧ code e1196686687006 = 5594733198110 := by decide
theorem cert_e1196686687006 : check e1196686687006 [[],[.left],[]] .sourceHead = true := by decide
def e1196686687030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196686687030 : Closed e1196686687030 ∧ code e1196686687030 = 5594733198134 := by decide
theorem cert_e1196686687030 : check e1196686687030 [[],[.left],[]] .sourceHead = true := by decide
def e1196686687034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196686687034 : Closed e1196686687034 ∧ code e1196686687034 = 5594733198138 := by decide
theorem cert_e1196686687034 : check e1196686687034 [[],[.left],[]] .sourceHead = true := by decide
def e1196686687118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e1196686687118 : Closed e1196686687118 ∧ code e1196686687118 = 5594733198222 := by decide
theorem cert_e1196686687118 : check e1196686687118 [[],[.left],[]] .sourceHead = true := by decide
def e1196686690030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e1196686690030 : Closed e1196686690030 ∧ code e1196686690030 = 5594733201134 := by decide
theorem cert_e1196686690030 : check e1196686690030 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686690222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e1196686690222 : Closed e1196686690222 ∧ code e1196686690222 = 5594733201326 := by decide
theorem cert_e1196686690222 : check e1196686690222 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686690234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e1196686690234 : Closed e1196686690234 ∧ code e1196686690234 = 5594733201338 := by decide
theorem cert_e1196686690234 : check e1196686690234 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686691694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1196686691694 : Closed e1196686691694 ∧ code e1196686691694 = 5594733202798 := by decide
def e1196686691702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1196686691702 : Closed e1196686691702 ∧ code e1196686691702 = 5594733202806 := by decide
theorem cert_e1196686691702 : check e1196686691702 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686691758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1196686691758 : Closed e1196686691758 ∧ code e1196686691758 = 5594733202862 := by decide
theorem cert_e1196686691758 : check e1196686691758 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686691770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1196686691770 : Closed e1196686691770 ∧ code e1196686691770 = 5594733202874 := by decide
theorem cert_e1196686691770 : check e1196686691770 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686691798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1196686691798 : Closed e1196686691798 ∧ code e1196686691798 = 5594733202902 := by decide
theorem cert_e1196686691798 : check e1196686691798 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686691802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1196686691802 : Closed e1196686691802 ∧ code e1196686691802 = 5594733202906 := by decide
def e1196686692014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1196686692014 : Closed e1196686692014 ∧ code e1196686692014 = 5594733203118 := by decide
theorem cert_e1196686692014 : check e1196686692014 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686692026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1196686692026 : Closed e1196686692026 ∧ code e1196686692026 = 5594733203130 := by decide
theorem cert_e1196686692026 : check e1196686692026 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1196686692074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1196686692074 : Closed e1196686692074 ∧ code e1196686692074 = 5594733203178 := by decide
theorem cert_e1196686692074 : check e1196686692074 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686692182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1196686692182 : Closed e1196686692182 ∧ code e1196686692182 = 5594733203286 := by decide
theorem cert_e1196686692182 : check e1196686692182 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686692186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1196686692186 : Closed e1196686692186 ∧ code e1196686692186 = 5594733203290 := by decide
def e1196686692202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1196686692202 : Closed e1196686692202 ∧ code e1196686692202 = 5594733203306 := by decide
theorem cert_e1196686692202 : check e1196686692202 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686692846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e1196686692846 : Closed e1196686692846 ∧ code e1196686692846 = 5594733203950 := by decide
theorem cert_e1196686692846 : check e1196686692846 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e1196686693230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1196686693230 : Closed e1196686693230 ∧ code e1196686693230 = 5594733204334 := by decide
theorem cert_e1196686693230 : check e1196686693230 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686693238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1196686693238 : Closed e1196686693238 ∧ code e1196686693238 = 5594733204342 := by decide
theorem cert_e1196686693238 : check e1196686693238 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196686693294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1196686693294 : Closed e1196686693294 ∧ code e1196686693294 = 5594733204398 := by decide
theorem cert_e1196686693294 : check e1196686693294 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196686693306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1196686693306 : Closed e1196686693306 ∧ code e1196686693306 = 5594733204410 := by decide
theorem cert_e1196686693306 : check e1196686693306 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686693334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1196686693334 : Closed e1196686693334 ∧ code e1196686693334 = 5594733204438 := by decide
theorem cert_e1196686693334 : check e1196686693334 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686693338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1196686693338 : Closed e1196686693338 ∧ code e1196686693338 = 5594733204442 := by decide
theorem cert_e1196686693338 : check e1196686693338 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196686693614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196686693614 : Closed e1196686693614 ∧ code e1196686693614 = 5594733204718 := by decide
theorem cert_e1196686693614 : check e1196686693614 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor42
