import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e378063996442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378063996442 : Closed e378063996442 ∧ code e378063996442 = 4776110507546 := by decide
theorem cert_e378063996442 : check e378063996442 [] .sourceHead = true := by decide
def e378063999174 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378063999174 : Closed e378063999174 ∧ code e378063999174 = 4776110510278 := by decide
theorem cert_e378063999174 : check e378063999174 [] .sourceHead = true := by decide
def e378064001050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378064001050 : Closed e378064001050 ∧ code e378064001050 = 4776110512154 := by decide
theorem cert_e378064001050 : check e378064001050 [] .sourceHead = true := by decide
def e378064543258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378064543258 : Closed e378064543258 ∧ code e378064543258 = 4776111054362 := by decide
theorem cert_e378064543258 : check e378064543258 [] .sourceHead = true := by decide
def e378064564422 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378064564422 : Closed e378064564422 ∧ code e378064564422 = 4776111075526 := by decide
theorem cert_e378064564422 : check e378064564422 [] .sourceHead = true := by decide
def e378064571930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378064571930 : Closed e378064571930 ∧ code e378064571930 = 4776111083034 := by decide
theorem cert_e378064571930 : check e378064571930 [] .sourceHead = true := by decide
def e378064580806 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378064580806 : Closed e378064580806 ∧ code e378064580806 = 4776111091910 := by decide
theorem cert_e378064580806 : check e378064580806 [] .sourceHead = true := by decide
def e378065329690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378065329690 : Closed e378065329690 ∧ code e378065329690 = 4776111840794 := by decide
theorem cert_e378065329690 : check e378065329690 [] .sourceHead = true := by decide
def e378065350854 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378065350854 : Closed e378065350854 ∧ code e378065350854 = 4776111861958 := by decide
theorem cert_e378065350854 : check e378065350854 [] .sourceHead = true := by decide
def e378065369114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378065369114 : Closed e378065369114 ∧ code e378065369114 = 4776111880218 := by decide
theorem cert_e378065369114 : check e378065369114 [] .sourceHead = true := by decide
def e378065372698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378065372698 : Closed e378065372698 ∧ code e378065372698 = 4776111883802 := by decide
theorem cert_e378065372698 : check e378065372698 [] .sourceHead = true := by decide
def e378065375430 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378065375430 : Closed e378065375430 ∧ code e378065375430 = 4776111886534 := by decide
theorem cert_e378065375430 : check e378065375430 [] .sourceHead = true := by decide
def e378065377306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378065377306 : Closed e378065377306 ∧ code e378065377306 = 4776111888410 := by decide
theorem cert_e378065377306 : check e378065377306 [] .sourceHead = true := by decide
def e378065751578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378065751578 : Closed e378065751578 ∧ code e378065751578 = 4776112262682 := by decide
theorem cert_e378065751578 : check e378065751578 [] .sourceHead = true := by decide
def e378065760454 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378065760454 : Closed e378065760454 ∧ code e378065760454 = 4776112271558 := by decide
theorem cert_e378065760454 : check e378065760454 [] .sourceHead = true := by decide
def e378065765914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378065765914 : Closed e378065765914 ∧ code e378065765914 = 4776112277018 := by decide
theorem cert_e378065765914 : check e378065765914 [] .sourceHead = true := by decide
def e378065768646 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378065768646 : Closed e378065768646 ∧ code e378065768646 = 4776112279750 := by decide
theorem cert_e378065768646 : check e378065768646 [] .sourceHead = true := by decide
def e378065770522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378065770522 : Closed e378065770522 ∧ code e378065770522 = 4776112281626 := by decide
theorem cert_e378065770522 : check e378065770522 [] .sourceHead = true := by decide
def e378075311642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075311642 : Closed e378075311642 ∧ code e378075311642 = 4776121822746 := by decide
theorem cert_e378075311642 : check e378075311642 [] .sourceHead = true := by decide
def e378075313690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075313690 : Closed e378075313690 ∧ code e378075313690 = 4776121824794 := by decide
theorem cert_e378075313690 : check e378075313690 [] .sourceHead = true := by decide
def e378075328026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075328026 : Closed e378075328026 ∧ code e378075328026 = 4776121839130 := by decide
theorem cert_e378075328026 : check e378075328026 [] .sourceHead = true := by decide
def e378075331098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075331098 : Closed e378075331098 ∧ code e378075331098 = 4776121842202 := by decide
theorem cert_e378075331098 : check e378075331098 [] .sourceHead = true := by decide
def e378075338266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075338266 : Closed e378075338266 ∧ code e378075338266 = 4776121849370 := by decide
theorem cert_e378075338266 : check e378075338266 [] .sourceHead = true := by decide
def e378075339290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075339290 : Closed e378075339290 ∧ code e378075339290 = 4776121850394 := by decide
theorem cert_e378075339290 : check e378075339290 [] .sourceHead = true := by decide
def e378075409946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075409946 : Closed e378075409946 ∧ code e378075409946 = 4776121921050 := by decide
theorem cert_e378075409946 : check e378075409946 [] .sourceHead = true := by decide
def e378075411994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075411994 : Closed e378075411994 ∧ code e378075411994 = 4776121923098 := by decide
theorem cert_e378075411994 : check e378075411994 [] .sourceHead = true := by decide
def e378075508250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075508250 : Closed e378075508250 ∧ code e378075508250 = 4776122019354 := by decide
theorem cert_e378075508250 : check e378075508250 [] .sourceHead = true := by decide
def e378075511322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075511322 : Closed e378075511322 ∧ code e378075511322 = 4776122022426 := by decide
theorem cert_e378075511322 : check e378075511322 [] .sourceHead = true := by decide
def e378075559450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075559450 : Closed e378075559450 ∧ code e378075559450 = 4776122070554 := by decide
theorem cert_e378075559450 : check e378075559450 [] .sourceHead = true := by decide
def e378075560474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378075560474 : Closed e378075560474 ∧ code e378075560474 = 4776122071578 := by decide
theorem cert_e378075560474 : check e378075560474 [] .sourceHead = true := by decide
def e378077474330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077474330 : Closed e378077474330 ∧ code e378077474330 = 4776123985434 := by decide
theorem cert_e378077474330 : check e378077474330 [] .sourceHead = true := by decide
def e378077477402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077477402 : Closed e378077477402 ∧ code e378077477402 = 4776123988506 := by decide
theorem cert_e378077477402 : check e378077477402 [] .sourceHead = true := by decide
def e378077519386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077519386 : Closed e378077519386 ∧ code e378077519386 = 4776124030490 := by decide
theorem cert_e378077519386 : check e378077519386 [] .sourceHead = true := by decide
def e378077540550 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378077540550 : Closed e378077540550 ∧ code e378077540550 = 4776124051654 := by decide
theorem cert_e378077540550 : check e378077540550 [] .sourceHead = true := by decide
def e378077558810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077558810 : Closed e378077558810 ∧ code e378077558810 = 4776124069914 := by decide
theorem cert_e378077558810 : check e378077558810 [] .sourceHead = true := by decide
def e378077562394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077562394 : Closed e378077562394 ∧ code e378077562394 = 4776124073498 := by decide
theorem cert_e378077562394 : check e378077562394 [] .sourceHead = true := by decide
def e378077565126 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378077565126 : Closed e378077565126 ∧ code e378077565126 = 4776124076230 := by decide
theorem cert_e378077565126 : check e378077565126 [] .sourceHead = true := by decide
def e378077567002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077567002 : Closed e378077567002 ∧ code e378077567002 = 4776124078106 := by decide
theorem cert_e378077567002 : check e378077567002 [] .sourceHead = true := by decide
def e378077624346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077624346 : Closed e378077624346 ∧ code e378077624346 = 4776124135450 := by decide
theorem cert_e378077624346 : check e378077624346 [] .sourceHead = true := by decide
def e378077636634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077636634 : Closed e378077636634 ∧ code e378077636634 = 4776124147738 := by decide
theorem cert_e378077636634 : check e378077636634 [] .sourceHead = true := by decide
def e378077649434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077649434 : Closed e378077649434 ∧ code e378077649434 = 4776124160538 := by decide
theorem cert_e378077649434 : check e378077649434 [] .sourceHead = true := by decide
def e378077660698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077660698 : Closed e378077660698 ∧ code e378077660698 = 4776124171802 := by decide
theorem cert_e378077660698 : check e378077660698 [] .sourceHead = true := by decide
def e378077663430 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378077663430 : Closed e378077663430 ∧ code e378077663430 = 4776124174534 := by decide
theorem cert_e378077663430 : check e378077663430 [] .sourceHead = true := by decide
def e378077665306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077665306 : Closed e378077665306 ∧ code e378077665306 = 4776124176410 := by decide
theorem cert_e378077665306 : check e378077665306 [] .sourceHead = true := by decide
def e378077669402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077669402 : Closed e378077669402 ∧ code e378077669402 = 4776124180506 := by decide
theorem cert_e378077669402 : check e378077669402 [] .sourceHead = true := by decide
def e378077912602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077912602 : Closed e378077912602 ∧ code e378077912602 = 4776124423706 := by decide
theorem cert_e378077912602 : check e378077912602 [] .sourceHead = true := by decide
def e378077933766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378077933766 : Closed e378077933766 ∧ code e378077933766 = 4776124444870 := by decide
theorem cert_e378077933766 : check e378077933766 [] .sourceHead = true := by decide
def e378077952026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077952026 : Closed e378077952026 ∧ code e378077952026 = 4776124463130 := by decide
theorem cert_e378077952026 : check e378077952026 [] .sourceHead = true := by decide
def e378077955610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378077955610 : Closed e378077955610 ∧ code e378077955610 = 4776124466714 := by decide
theorem cert_e378077955610 : check e378077955610 [] .sourceHead = true := by decide
def e378077958342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378077958342 : Closed e378077958342 ∧ code e378077958342 = 4776124469446 := by decide
theorem cert_e378077958342 : check e378077958342 [] .sourceHead = true := by decide
def e378077960218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378077960218 : Closed e378077960218 ∧ code e378077960218 = 4776124471322 := by decide
theorem cert_e378077960218 : check e378077960218 [] .sourceHead = true := by decide
def e378078345242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378078345242 : Closed e378078345242 ∧ code e378078345242 = 4776124856346 := by decide
theorem cert_e378078345242 : check e378078345242 [] .sourceHead = true := by decide
def e378078357530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378078357530 : Closed e378078357530 ∧ code e378078357530 = 4776124868634 := by decide
theorem cert_e378078357530 : check e378078357530 [] .sourceHead = true := by decide
def e378078545434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378078545434 : Closed e378078545434 ∧ code e378078545434 = 4776125056538 := by decide
theorem cert_e378078545434 : check e378078545434 [] .sourceHead = true := by decide
def e378078548166 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378078548166 : Closed e378078548166 ∧ code e378078548166 = 4776125059270 := by decide
theorem cert_e378078548166 : check e378078548166 [] .sourceHead = true := by decide
def e378078550042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378078550042 : Closed e378078550042 ∧ code e378078550042 = 4776125061146 := by decide
theorem cert_e378078550042 : check e378078550042 [] .sourceHead = true := by decide
def e378078554138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378078554138 : Closed e378078554138 ∧ code e378078554138 = 4776125065242 := by decide
theorem cert_e378078554138 : check e378078554138 [] .sourceHead = true := by decide
def e378084406810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084406810 : Closed e378084406810 ∧ code e378084406810 = 4776130917914 := by decide
theorem cert_e378084406810 : check e378084406810 [] .sourceHead = true := by decide
def e378084407834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084407834 : Closed e378084407834 ∧ code e378084407834 = 4776130918938 := by decide
theorem cert_e378084407834 : check e378084407834 [] .sourceHead = true := by decide
def e378084429338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084429338 : Closed e378084429338 ∧ code e378084429338 = 4776130940442 := by decide
theorem cert_e378084429338 : check e378084429338 [] .sourceHead = true := by decide
def e378084438214 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378084438214 : Closed e378084438214 ∧ code e378084438214 = 4776130949318 := by decide
theorem cert_e378084438214 : check e378084438214 [] .sourceHead = true := by decide
def e378084443674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084443674 : Closed e378084443674 ∧ code e378084443674 = 4776130954778 := by decide
theorem cert_e378084443674 : check e378084443674 [] .sourceHead = true := by decide
def e378084446406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378084446406 : Closed e378084446406 ∧ code e378084446406 = 4776130957510 := by decide
theorem cert_e378084446406 : check e378084446406 [] .sourceHead = true := by decide
def e378084448282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378084448282 : Closed e378084448282 ∧ code e378084448282 = 4776130959386 := by decide
theorem cert_e378084448282 : check e378084448282 [] .sourceHead = true := by decide
def e378084465178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084465178 : Closed e378084465178 ∧ code e378084465178 = 4776130976282 := by decide
theorem cert_e378084465178 : check e378084465178 [] .sourceHead = true := by decide
def e378084476442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084476442 : Closed e378084476442 ∧ code e378084476442 = 4776130987546 := by decide
theorem cert_e378084476442 : check e378084476442 [] .sourceHead = true := by decide
def e378084479174 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378084479174 : Closed e378084479174 ∧ code e378084479174 = 4776130990278 := by decide
theorem cert_e378084479174 : check e378084479174 [] .sourceHead = true := by decide
def e378084481050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378084481050 : Closed e378084481050 ∧ code e378084481050 = 4776130992154 := by decide
theorem cert_e378084481050 : check e378084481050 [] .sourceHead = true := by decide
def e378084485146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378084485146 : Closed e378084485146 ∧ code e378084485146 = 4776130996250 := by decide
theorem cert_e378084485146 : check e378084485146 [] .sourceHead = true := by decide
def e378084625946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084625946 : Closed e378084625946 ∧ code e378084625946 = 4776131137050 := by decide
theorem cert_e378084625946 : check e378084625946 [] .sourceHead = true := by decide
def e378084634822 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378084634822 : Closed e378084634822 ∧ code e378084634822 = 4776131145926 := by decide
theorem cert_e378084634822 : check e378084634822 [] .sourceHead = true := by decide
def e378084640282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084640282 : Closed e378084640282 ∧ code e378084640282 = 4776131151386 := by decide
theorem cert_e378084640282 : check e378084640282 [] .sourceHead = true := by decide
def e378084643014 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378084643014 : Closed e378084643014 ∧ code e378084643014 = 4776131154118 := by decide
theorem cert_e378084643014 : check e378084643014 [] .sourceHead = true := by decide
def e378084644890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378084644890 : Closed e378084644890 ∧ code e378084644890 = 4776131155994 := by decide
theorem cert_e378084644890 : check e378084644890 [] .sourceHead = true := by decide
def e378084836890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378084836890 : Closed e378084836890 ∧ code e378084836890 = 4776131347994 := by decide
theorem cert_e378084836890 : check e378084836890 [] .sourceHead = true := by decide
def e378084839622 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378084839622 : Closed e378084839622 ∧ code e378084839622 = 4776131350726 := by decide
theorem cert_e378084839622 : check e378084839622 [] .sourceHead = true := by decide
def e378084841498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378084841498 : Closed e378084841498 ∧ code e378084841498 = 4776131352602 := by decide
theorem cert_e378084841498 : check e378084841498 [] .sourceHead = true := by decide
def e378084845594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378084845594 : Closed e378084845594 ∧ code e378084845594 = 4776131356698 := by decide
theorem cert_e378084845594 : check e378084845594 [] .sourceHead = true := by decide
def e378365603354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365603354 : Closed e378365603354 ∧ code e378365603354 = 4776412114458 := by decide
theorem cert_e378365603354 : check e378365603354 [] .sourceHead = true := by decide
def e378365605402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365605402 : Closed e378365605402 ∧ code e378365605402 = 4776412116506 := by decide
theorem cert_e378365605402 : check e378365605402 [] .sourceHead = true := by decide
def e378365746714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365746714 : Closed e378365746714 ∧ code e378365746714 = 4776412257818 := by decide
theorem cert_e378365746714 : check e378365746714 [] .sourceHead = true := by decide
def e378365767878 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378365767878 : Closed e378365767878 ∧ code e378365767878 = 4776412278982 := by decide
theorem cert_e378365767878 : check e378365767878 [] .sourceHead = true := by decide
def e378365775386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365775386 : Closed e378365775386 ∧ code e378365775386 = 4776412286490 := by decide
theorem cert_e378365775386 : check e378365775386 [] .sourceHead = true := by decide
def e378365784262 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378365784262 : Closed e378365784262 ∧ code e378365784262 = 4776412295366 := by decide
theorem cert_e378365784262 : check e378365784262 [] .sourceHead = true := by decide
def e378365832730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365832730 : Closed e378365832730 ∧ code e378365832730 = 4776412343834 := by decide
theorem cert_e378365832730 : check e378365832730 [] .sourceHead = true := by decide
def e378365835802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365835802 : Closed e378365835802 ∧ code e378365835802 = 4776412346906 := by decide
theorem cert_e378365835802 : check e378365835802 [] .sourceHead = true := by decide
def e378365877786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365877786 : Closed e378365877786 ∧ code e378365877786 = 4776412388890 := by decide
theorem cert_e378365877786 : check e378365877786 [] .sourceHead = true := by decide
def e378365898950 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378365898950 : Closed e378365898950 ∧ code e378365898950 = 4776412410054 := by decide
theorem cert_e378365898950 : check e378365898950 [] .sourceHead = true := by decide
def e378365920794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365920794 : Closed e378365920794 ∧ code e378365920794 = 4776412431898 := by decide
theorem cert_e378365920794 : check e378365920794 [] .sourceHead = true := by decide
def e378365923526 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378365923526 : Closed e378365923526 ∧ code e378365923526 = 4776412434630 := by decide
theorem cert_e378365923526 : check e378365923526 [] .sourceHead = true := by decide
def e378365949466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365949466 : Closed e378365949466 ∧ code e378365949466 = 4776412460570 := by decide
theorem cert_e378365949466 : check e378365949466 [] .sourceHead = true := by decide
def e378365950490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365950490 : Closed e378365950490 ∧ code e378365950490 = 4776412461594 := by decide
theorem cert_e378365950490 : check e378365950490 [] .sourceHead = true := by decide
def e378365971994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365971994 : Closed e378365971994 ∧ code e378365971994 = 4776412483098 := by decide
theorem cert_e378365971994 : check e378365971994 [] .sourceHead = true := by decide
def e378365980870 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378365980870 : Closed e378365980870 ∧ code e378365980870 = 4776412491974 := by decide
theorem cert_e378365980870 : check e378365980870 [] .sourceHead = true := by decide
def e378365986330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378365986330 : Closed e378365986330 ∧ code e378365986330 = 4776412497434 := by decide
theorem cert_e378365986330 : check e378365986330 [] .sourceHead = true := by decide
def e378365989062 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378365989062 : Closed e378365989062 ∧ code e378365989062 = 4776412500166 := by decide
theorem cert_e378365989062 : check e378365989062 [] .sourceHead = true := by decide
def e378366533146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378366533146 : Closed e378366533146 ∧ code e378366533146 = 4776413044250 := by decide
theorem cert_e378366533146 : check e378366533146 [] .sourceHead = true := by decide
def e378366554310 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378366554310 : Closed e378366554310 ∧ code e378366554310 = 4776413065414 := by decide
theorem cert_e378366554310 : check e378366554310 [] .sourceHead = true := by decide
def e378366561818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378366561818 : Closed e378366561818 ∧ code e378366561818 = 4776413072922 := by decide
theorem cert_e378366561818 : check e378366561818 [] .sourceHead = true := by decide
def e378366570694 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378366570694 : Closed e378366570694 ∧ code e378366570694 = 4776413081798 := by decide
theorem cert_e378366570694 : check e378366570694 [] .sourceHead = true := by decide
def e378367319578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378367319578 : Closed e378367319578 ∧ code e378367319578 = 4776413830682 := by decide
theorem cert_e378367319578 : check e378367319578 [] .sourceHead = true := by decide
def e378367340742 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378367340742 : Closed e378367340742 ∧ code e378367340742 = 4776413851846 := by decide
theorem cert_e378367340742 : check e378367340742 [] .sourceHead = true := by decide
def e378367362586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378367362586 : Closed e378367362586 ∧ code e378367362586 = 4776413873690 := by decide
theorem cert_e378367362586 : check e378367362586 [] .sourceHead = true := by decide
def e378367365318 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378367365318 : Closed e378367365318 ∧ code e378367365318 = 4776413876422 := by decide
theorem cert_e378367365318 : check e378367365318 [] .sourceHead = true := by decide
def e378367741466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378367741466 : Closed e378367741466 ∧ code e378367741466 = 4776414252570 := by decide
theorem cert_e378367741466 : check e378367741466 [] .sourceHead = true := by decide
def e378367750342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378367750342 : Closed e378367750342 ∧ code e378367750342 = 4776414261446 := by decide
theorem cert_e378367750342 : check e378367750342 [] .sourceHead = true := by decide
def e378367755802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378367755802 : Closed e378367755802 ∧ code e378367755802 = 4776414266906 := by decide
theorem cert_e378367755802 : check e378367755802 [] .sourceHead = true := by decide
def e378367758534 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378367758534 : Closed e378367758534 ∧ code e378367758534 = 4776414269638 := by decide
theorem cert_e378367758534 : check e378367758534 [] .sourceHead = true := by decide
def e378393418606 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e378393418606 : Closed e378393418606 ∧ code e378393418606 = 4776439929710 := by decide
theorem cert_e378393418606 : check e378393418606 [] .sourceHead = true := by decide
def e378393418614 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e378393418614 : Closed e378393418614 ∧ code e378393418614 = 4776439929718 := by decide
theorem cert_e378393418614 : check e378393418614 [] .sourceHead = true := by decide
def e378393418678 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e378393418678 : Closed e378393418678 ∧ code e378393418678 = 4776439929782 := by decide
theorem cert_e378393418678 : check e378393418678 [] .sourceHead = true := by decide
def e378393419118 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e378393419118 : Closed e378393419118 ∧ code e378393419118 = 4776439930222 := by decide
theorem cert_e378393419118 : check e378393419118 [] .sourceHead = true := by decide
def e378393419126 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e378393419126 : Closed e378393419126 ∧ code e378393419126 = 4776439930230 := by decide
theorem cert_e378393419126 : check e378393419126 [] .sourceHead = true := by decide
def e378393419182 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e378393419182 : Closed e378393419182 ∧ code e378393419182 = 4776439930286 := by decide
theorem cert_e378393419182 : check e378393419182 [] .sourceHead = true := by decide
def e378393419194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e378393419194 : Closed e378393419194 ∧ code e378393419194 = 4776439930298 := by decide
theorem cert_e378393419194 : check e378393419194 [] .sourceHead = true := by decide
def e378393419222 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e378393419222 : Closed e378393419222 ∧ code e378393419222 = 4776439930326 := by decide
theorem cert_e378393419222 : check e378393419222 [] .sourceHead = true := by decide
def e378393419226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e378393419226 : Closed e378393419226 ∧ code e378393419226 = 4776439930330 := by decide
theorem cert_e378393419226 : check e378393419226 [] .sourceHead = true := by decide
def e378393419446 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e378393419446 : Closed e378393419446 ∧ code e378393419446 = 4776439930550 := by decide
theorem cert_e378393419446 : check e378393419446 [] .sourceHead = true := by decide
def e378393419478 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e378393419478 : Closed e378393419478 ∧ code e378393419478 = 4776439930582 := by decide
theorem cert_e378393419478 : check e378393419478 [] .sourceHead = true := by decide
def e378393419482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e378393419482 : Closed e378393419482 ∧ code e378393419482 = 4776439930586 := by decide
theorem cert_e378393419482 : check e378393419482 [] .sourceHead = true := by decide
def e378393421678 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e378393421678 : Closed e378393421678 ∧ code e378393421678 = 4776439932782 := by decide
theorem cert_e378393421678 : check e378393421678 [] .sourceHead = true := by decide
def e378393421686 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e378393421686 : Closed e378393421686 ∧ code e378393421686 = 4776439932790 := by decide
theorem cert_e378393421686 : check e378393421686 [] .sourceHead = true := by decide
def e378393421750 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e378393421750 : Closed e378393421750 ∧ code e378393421750 = 4776439932854 := by decide
theorem cert_e378393421750 : check e378393421750 [] .sourceHead = true := by decide
def e378393423086 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e378393423086 : Closed e378393423086 ∧ code e378393423086 = 4776439934190 := by decide
theorem cert_e378393423086 : check e378393423086 [] .sourceHead = true := by decide
def e378393423094 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e378393423094 : Closed e378393423094 ∧ code e378393423094 = 4776439934198 := by decide
theorem cert_e378393423094 : check e378393423094 [] .sourceHead = true := by decide
def e378393423478 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e378393423478 : Closed e378393423478 ∧ code e378393423478 = 4776439934582 := by decide
theorem cert_e378393423478 : check e378393423478 [] .sourceHead = true := by decide
def e378393424750 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e378393424750 : Closed e378393424750 ∧ code e378393424750 = 4776439935854 := by decide
theorem cert_e378393424750 : check e378393424750 [] .sourceHead = true := by decide
def e378393424758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e378393424758 : Closed e378393424758 ∧ code e378393424758 = 4776439935862 := by decide
theorem cert_e378393424758 : check e378393424758 [] .sourceHead = true := by decide
def e378393424814 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e378393424814 : Closed e378393424814 ∧ code e378393424814 = 4776439935918 := by decide
theorem cert_e378393424814 : check e378393424814 [] .sourceHead = true := by decide
def e378393424826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e378393424826 : Closed e378393424826 ∧ code e378393424826 = 4776439935930 := by decide
theorem cert_e378393424826 : check e378393424826 [] .sourceHead = true := by decide
def e378393424854 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e378393424854 : Closed e378393424854 ∧ code e378393424854 = 4776439935958 := by decide
theorem cert_e378393424854 : check e378393424854 [] .sourceHead = true := by decide
def e378393424858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e378393424858 : Closed e378393424858 ∧ code e378393424858 = 4776439935962 := by decide
theorem cert_e378393424858 : check e378393424858 [] .sourceHead = true := by decide
def e378393425134 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e378393425134 : Closed e378393425134 ∧ code e378393425134 = 4776439936238 := by decide
theorem cert_e378393425134 : check e378393425134 [] .sourceHead = true := by decide
def e378393425142 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e378393425142 : Closed e378393425142 ∧ code e378393425142 = 4776439936246 := by decide
theorem cert_e378393425142 : check e378393425142 [] .sourceHead = true := by decide
def e378393425518 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e378393425518 : Closed e378393425518 ∧ code e378393425518 = 4776439936622 := by decide
theorem cert_e378393425518 : check e378393425518 [] .sourceHead = true := by decide
def e378393425530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e378393425530 : Closed e378393425530 ∧ code e378393425530 = 4776439936634 := by decide
theorem cert_e378393425530 : check e378393425530 [] .sourceHead = true := by decide
def e378393425718 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e378393425718 : Closed e378393425718 ∧ code e378393425718 = 4776439936822 := by decide
theorem cert_e378393425718 : check e378393425718 [] .sourceHead = true := by decide
def e378393425722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e378393425722 : Closed e378393425722 ∧ code e378393425722 = 4776439936826 := by decide
theorem cert_e378393425722 : check e378393425722 [] .sourceHead = true := by decide
def e378393426358 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e378393426358 : Closed e378393426358 ∧ code e378393426358 = 4776439937462 := by decide
theorem cert_e378393426358 : check e378393426358 [] .sourceHead = true := by decide
def e378393426390 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e378393426390 : Closed e378393426390 ∧ code e378393426390 = 4776439937494 := by decide
theorem cert_e378393426390 : check e378393426390 [] .sourceHead = true := by decide
def e378393426394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e378393426394 : Closed e378393426394 ∧ code e378393426394 = 4776439937498 := by decide
theorem cert_e378393426394 : check e378393426394 [] .sourceHead = true := by decide
def e378393426550 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e378393426550 : Closed e378393426550 ∧ code e378393426550 = 4776439937654 := by decide
theorem cert_e378393426550 : check e378393426550 [] .sourceHead = true := by decide
def e378393426742 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e378393426742 : Closed e378393426742 ∧ code e378393426742 = 4776439937846 := by decide
theorem cert_e378393426742 : check e378393426742 [] .sourceHead = true := by decide
def e378393426746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e378393426746 : Closed e378393426746 ∧ code e378393426746 = 4776439937850 := by decide
theorem cert_e378393426746 : check e378393426746 [] .sourceHead = true := by decide
def e378393433966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e378393433966 : Closed e378393433966 ∧ code e378393433966 = 4776439945070 := by decide
theorem cert_e378393433966 : check e378393433966 [] .sourceHead = true := by decide
def e378393433974 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e378393433974 : Closed e378393433974 ∧ code e378393433974 = 4776439945078 := by decide
theorem cert_e378393433974 : check e378393433974 [] .sourceHead = true := by decide
def e378393434038 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e378393434038 : Closed e378393434038 ∧ code e378393434038 = 4776439945142 := by decide
theorem cert_e378393434038 : check e378393434038 [] .sourceHead = true := by decide
def e378393435374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e378393435374 : Closed e378393435374 ∧ code e378393435374 = 4776439946478 := by decide
theorem cert_e378393435374 : check e378393435374 [] .sourceHead = true := by decide
def e378393435382 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e378393435382 : Closed e378393435382 ∧ code e378393435382 = 4776439946486 := by decide
theorem cert_e378393435382 : check e378393435382 [] .sourceHead = true := by decide
def e378393435766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e378393435766 : Closed e378393435766 ∧ code e378393435766 = 4776439946870 := by decide
theorem cert_e378393435766 : check e378393435766 [] .sourceHead = true := by decide
def e378393447278 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e378393447278 : Closed e378393447278 ∧ code e378393447278 = 4776439958382 := by decide
theorem cert_e378393447278 : check e378393447278 [] .sourceHead = true := by decide
def e378393447286 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e378393447286 : Closed e378393447286 ∧ code e378393447286 = 4776439958390 := by decide
theorem cert_e378393447286 : check e378393447286 [] .sourceHead = true := by decide
def e378393447342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e378393447342 : Closed e378393447342 ∧ code e378393447342 = 4776439958446 := by decide
theorem cert_e378393447342 : check e378393447342 [] .sourceHead = true := by decide
def e378393447354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e378393447354 : Closed e378393447354 ∧ code e378393447354 = 4776439958458 := by decide
theorem cert_e378393447354 : check e378393447354 [] .sourceHead = true := by decide
def e378393447382 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e378393447382 : Closed e378393447382 ∧ code e378393447382 = 4776439958486 := by decide
theorem cert_e378393447382 : check e378393447382 [] .sourceHead = true := by decide
def e378393447386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e378393447386 : Closed e378393447386 ∧ code e378393447386 = 4776439958490 := by decide
theorem cert_e378393447386 : check e378393447386 [] .sourceHead = true := by decide
def e378393447662 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e378393447662 : Closed e378393447662 ∧ code e378393447662 = 4776439958766 := by decide
theorem cert_e378393447662 : check e378393447662 [] .sourceHead = true := by decide
def e378393447670 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e378393447670 : Closed e378393447670 ∧ code e378393447670 = 4776439958774 := by decide
theorem cert_e378393447670 : check e378393447670 [] .sourceHead = true := by decide
def e378393448046 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e378393448046 : Closed e378393448046 ∧ code e378393448046 = 4776439959150 := by decide
theorem cert_e378393448046 : check e378393448046 [] .sourceHead = true := by decide
def e378393448058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e378393448058 : Closed e378393448058 ∧ code e378393448058 = 4776439959162 := by decide
theorem cert_e378393448058 : check e378393448058 [] .sourceHead = true := by decide
end Blc.Floor42
