import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182624634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e1211182624634 : Closed e1211182624634 ∧ code e1211182624634 = 5609229135738 := by decide
theorem cert_e1211182624634 : check e1211182624634 [[],[]] .smaller = true := by decide
def e1211182624686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e1211182624686 : Closed e1211182624686 ∧ code e1211182624686 = 5609229135790 := by decide
theorem cert_e1211182624686 : check e1211182624686 [[],[]] .smaller = true := by decide
def e1211182624694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e1211182624694 : Closed e1211182624694 ∧ code e1211182624694 = 5609229135798 := by decide
theorem cert_e1211182624694 : check e1211182624694 [[],[]] .smaller = true := by decide
def e1211182624698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e1211182624698 : Closed e1211182624698 ∧ code e1211182624698 = 5609229135802 := by decide
theorem cert_e1211182624698 : check e1211182624698 [[],[]] .smaller = true := by decide
def e1211182625758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211182625758 : Closed e1211182625758 ∧ code e1211182625758 = 5609229136862 := by decide
theorem cert_e1211182625758 : check e1211182625758 [[],[]] .smaller = true := by decide
def e1211182625774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211182625774 : Closed e1211182625774 ∧ code e1211182625774 = 5609229136878 := by decide
theorem cert_e1211182625774 : check e1211182625774 [[],[]] .smaller = true := by decide
def e1211182627294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211182627294 : Closed e1211182627294 ∧ code e1211182627294 = 5609229138398 := by decide
theorem cert_e1211182627294 : check e1211182627294 [[],[]] .smaller = true := by decide
def e1211182627318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211182627318 : Closed e1211182627318 ∧ code e1211182627318 = 5609229138422 := by decide
theorem cert_e1211182627318 : check e1211182627318 [[],[]] .smaller = true := by decide
def e1211182628062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211182628062 : Closed e1211182628062 ∧ code e1211182628062 = 5609229139166 := by decide
theorem cert_e1211182628062 : check e1211182628062 [[],[]] .smaller = true := by decide
def e1211182628090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211182628090 : Closed e1211182628090 ∧ code e1211182628090 = 5609229139194 := by decide
theorem cert_e1211182628090 : check e1211182628090 [[],[]] .smaller = true := by decide
def e1211182628462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211182628462 : Closed e1211182628462 ∧ code e1211182628462 = 5609229139566 := by decide
theorem cert_e1211182628462 : check e1211182628462 [[],[]] .smaller = true := by decide
def e1211182628470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182628470 : Closed e1211182628470 ∧ code e1211182628470 = 5609229139574 := by decide
theorem cert_e1211182628470 : check e1211182628470 [[],[]] .smaller = true := by decide
def e1211182628474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211182628474 : Closed e1211182628474 ∧ code e1211182628474 = 5609229139578 := by decide
theorem cert_e1211182628474 : check e1211182628474 [[],[]] .smaller = true := by decide
def e1211182656862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e1211182656862 : Closed e1211182656862 ∧ code e1211182656862 = 5609229167966 := by decide
theorem cert_e1211182656862 : check e1211182656862 [[],[]] .smaller = true := by decide
def e1211182656878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e1211182656878 : Closed e1211182656878 ∧ code e1211182656878 = 5609229167982 := by decide
theorem cert_e1211182656878 : check e1211182656878 [[],[]] .smaller = true := by decide
def e1211182656886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e1211182656886 : Closed e1211182656886 ∧ code e1211182656886 = 5609229167990 := by decide
theorem cert_e1211182656886 : check e1211182656886 [[],[]] .smaller = true := by decide
def e1211182656890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e1211182656890 : Closed e1211182656890 ∧ code e1211182656890 = 5609229167994 := by decide
theorem cert_e1211182656890 : check e1211182656890 [[],[]] .smaller = true := by decide
def e1211182656942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e1211182656942 : Closed e1211182656942 ∧ code e1211182656942 = 5609229168046 := by decide
theorem cert_e1211182656942 : check e1211182656942 [[],[]] .smaller = true := by decide
def e1211182656954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e1211182656954 : Closed e1211182656954 ∧ code e1211182656954 = 5609229168058 := by decide
theorem cert_e1211182656954 : check e1211182656954 [[],[]] .smaller = true := by decide
def e1211182656982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182656982 : Closed e1211182656982 ∧ code e1211182656982 = 5609229168086 := by decide
theorem cert_e1211182656982 : check e1211182656982 [[],[]] .smaller = true := by decide
def e1211182656986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182656986 : Closed e1211182656986 ∧ code e1211182656986 = 5609229168090 := by decide
theorem cert_e1211182656986 : check e1211182656986 [[],[]] .smaller = true := by decide
def e1211182657002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182657002 : Closed e1211182657002 ∧ code e1211182657002 = 5609229168106 := by decide
theorem cert_e1211182657002 : check e1211182657002 [[],[]] .smaller = true := by decide
def e1211182657198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e1211182657198 : Closed e1211182657198 ∧ code e1211182657198 = 5609229168302 := by decide
theorem cert_e1211182657198 : check e1211182657198 [[],[]] .smaller = true := by decide
def e1211182657210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e1211182657210 : Closed e1211182657210 ∧ code e1211182657210 = 5609229168314 := by decide
theorem cert_e1211182657210 : check e1211182657210 [[],[]] .smaller = true := by decide
def e1211182657258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182657258 : Closed e1211182657258 ∧ code e1211182657258 = 5609229168362 := by decide
theorem cert_e1211182657258 : check e1211182657258 [[],[]] .smaller = true := by decide
def e1211182657366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e1211182657366 : Closed e1211182657366 ∧ code e1211182657366 = 5609229168470 := by decide
theorem cert_e1211182657366 : check e1211182657366 [[],[]] .smaller = true := by decide
def e1211182657370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e1211182657370 : Closed e1211182657370 ∧ code e1211182657370 = 5609229168474 := by decide
theorem cert_e1211182657370 : check e1211182657370 [[],[]] .smaller = true := by decide
def e1211182657386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182657386 : Closed e1211182657386 ∧ code e1211182657386 = 5609229168490 := by decide
theorem cert_e1211182657386 : check e1211182657386 [[],[]] .smaller = true := by decide
def e1211182657450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e1211182657450 : Closed e1211182657450 ∧ code e1211182657450 = 5609229168554 := by decide
theorem cert_e1211182657450 : check e1211182657450 [[],[]] .smaller = true := by decide
def e1211182657982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e1211182657982 : Closed e1211182657982 ∧ code e1211182657982 = 5609229169086 := by decide
theorem cert_e1211182657982 : check e1211182657982 [[],[]] .three = true := by decide
def e1211182658014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e1211182658014 : Closed e1211182658014 ∧ code e1211182658014 = 5609229169118 := by decide
theorem cert_e1211182658014 : check e1211182658014 [[],[]] .smaller = true := by decide
def e1211182658030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))))
theorem wire_e1211182658030 : Closed e1211182658030 ∧ code e1211182658030 = 5609229169134 := by decide
theorem cert_e1211182658030 : check e1211182658030 [[],[]] .smaller = true := by decide
def e1211182658038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e1211182658038 : Closed e1211182658038 ∧ code e1211182658038 = 5609229169142 := by decide
theorem cert_e1211182658038 : check e1211182658038 [[],[]] .smaller = true := by decide
def e1211182658042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e1211182658042 : Closed e1211182658042 ∧ code e1211182658042 = 5609229169146 := by decide
theorem cert_e1211182658042 : check e1211182658042 [[],[]] .three = true := by decide
def e1211182658398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e1211182658398 : Closed e1211182658398 ∧ code e1211182658398 = 5609229169502 := by decide
theorem cert_e1211182658398 : check e1211182658398 [[],[]] .smaller = true := by decide
def e1211182658414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211182658414 : Closed e1211182658414 ∧ code e1211182658414 = 5609229169518 := by decide
theorem cert_e1211182658414 : check e1211182658414 [[],[]] .smaller = true := by decide
def e1211182658422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211182658422 : Closed e1211182658422 ∧ code e1211182658422 = 5609229169526 := by decide
theorem cert_e1211182658422 : check e1211182658422 [[],[]] .smaller = true := by decide
def e1211182658426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e1211182658426 : Closed e1211182658426 ∧ code e1211182658426 = 5609229169530 := by decide
theorem cert_e1211182658426 : check e1211182658426 [[],[]] .smaller = true := by decide
def e1211182658478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211182658478 : Closed e1211182658478 ∧ code e1211182658478 = 5609229169582 := by decide
theorem cert_e1211182658478 : check e1211182658478 [[],[]] .smaller = true := by decide
def e1211182658490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211182658490 : Closed e1211182658490 ∧ code e1211182658490 = 5609229169594 := by decide
theorem cert_e1211182658490 : check e1211182658490 [[],[]] .smaller = true := by decide
def e1211182658518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211182658518 : Closed e1211182658518 ∧ code e1211182658518 = 5609229169622 := by decide
theorem cert_e1211182658518 : check e1211182658518 [[],[]] .smaller = true := by decide
def e1211182658522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211182658522 : Closed e1211182658522 ∧ code e1211182658522 = 5609229169626 := by decide
theorem cert_e1211182658522 : check e1211182658522 [[],[]] .smaller = true := by decide
def e1211182658538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e1211182658538 : Closed e1211182658538 ∧ code e1211182658538 = 5609229169642 := by decide
theorem cert_e1211182658538 : check e1211182658538 [[],[]] .smaller = true := by decide
def e1211182658686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e1211182658686 : Closed e1211182658686 ∧ code e1211182658686 = 5609229169790 := by decide
theorem cert_e1211182658686 : check e1211182658686 [[],[]] .three = true := by decide
def e1211182658782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182658782 : Closed e1211182658782 ∧ code e1211182658782 = 5609229169886 := by decide
theorem cert_e1211182658782 : check e1211182658782 [[],[]] .smaller = true := by decide
def e1211182658798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182658798 : Closed e1211182658798 ∧ code e1211182658798 = 5609229169902 := by decide
theorem cert_e1211182658798 : check e1211182658798 [[],[]] .smaller = true := by decide
def e1211182658806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182658806 : Closed e1211182658806 ∧ code e1211182658806 = 5609229169910 := by decide
theorem cert_e1211182658806 : check e1211182658806 [[],[]] .smaller = true := by decide
def e1211182658810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182658810 : Closed e1211182658810 ∧ code e1211182658810 = 5609229169914 := by decide
theorem cert_e1211182658810 : check e1211182658810 [[],[]] .smaller = true := by decide
def e1211182659134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e1211182659134 : Closed e1211182659134 ∧ code e1211182659134 = 5609229170238 := by decide
theorem cert_e1211182659134 : check e1211182659134 [[],[]] .smaller = true := by decide
def e1211182659182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182659182 : Closed e1211182659182 ∧ code e1211182659182 = 5609229170286 := by decide
theorem cert_e1211182659182 : check e1211182659182 [[],[]] .smaller = true := by decide
def e1211182659194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182659194 : Closed e1211182659194 ∧ code e1211182659194 = 5609229170298 := by decide
theorem cert_e1211182659194 : check e1211182659194 [[],[]] .smaller = true := by decide
def e1211182659358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))))
theorem wire_e1211182659358 : Closed e1211182659358 ∧ code e1211182659358 = 5609229170462 := by decide
theorem cert_e1211182659358 : check e1211182659358 [[],[]] .smaller = true := by decide
def e1211182659382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182659382 : Closed e1211182659382 ∧ code e1211182659382 = 5609229170486 := by decide
theorem cert_e1211182659382 : check e1211182659382 [[],[]] .smaller = true := by decide
def e1211182659386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182659386 : Closed e1211182659386 ∧ code e1211182659386 = 5609229170490 := by decide
theorem cert_e1211182659386 : check e1211182659386 [[],[]] .smaller = true := by decide
def e1211182659470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e1211182659470 : Closed e1211182659470 ∧ code e1211182659470 = 5609229170574 := by decide
theorem cert_e1211182659470 : check e1211182659470 [[],[]] .smaller = true := by decide
def e1211182659482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182659482 : Closed e1211182659482 ∧ code e1211182659482 = 5609229170586 := by decide
theorem cert_e1211182659482 : check e1211182659482 [[],[]] .smaller = true := by decide
def e1211182659526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e1211182659526 : Closed e1211182659526 ∧ code e1211182659526 = 5609229170630 := by decide
theorem cert_e1211182659526 : check e1211182659526 [[],[]] .three = true := by decide
def e1211182659806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e1211182659806 : Closed e1211182659806 ∧ code e1211182659806 = 5609229170910 := by decide
theorem cert_e1211182659806 : check e1211182659806 [[],[]] .smaller = true := by decide
def e1211182659834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e1211182659834 : Closed e1211182659834 ∧ code e1211182659834 = 5609229170938 := by decide
theorem cert_e1211182659834 : check e1211182659834 [[],[]] .smaller = true := by decide
def e1211182660014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e1211182660014 : Closed e1211182660014 ∧ code e1211182660014 = 5609229171118 := by decide
theorem cert_e1211182660014 : check e1211182660014 [[],[]] .smaller = true := by decide
def e1211182660026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e1211182660026 : Closed e1211182660026 ∧ code e1211182660026 = 5609229171130 := by decide
theorem cert_e1211182660026 : check e1211182660026 [[],[]] .smaller = true := by decide
def e1211182660074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e1211182660074 : Closed e1211182660074 ∧ code e1211182660074 = 5609229171178 := by decide
theorem cert_e1211182660074 : check e1211182660074 [[],[]] .smaller = true := by decide
def e1211182660158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e1211182660158 : Closed e1211182660158 ∧ code e1211182660158 = 5609229171262 := by decide
theorem cert_e1211182660158 : check e1211182660158 [[],[]] .smaller = true := by decide
def e1211182660206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182660206 : Closed e1211182660206 ∧ code e1211182660206 = 5609229171310 := by decide
theorem cert_e1211182660206 : check e1211182660206 [[],[]] .smaller = true := by decide
def e1211182660218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182660218 : Closed e1211182660218 ∧ code e1211182660218 = 5609229171322 := by decide
theorem cert_e1211182660218 : check e1211182660218 [[],[]] .smaller = true := by decide
def e1211182660506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182660506 : Closed e1211182660506 ∧ code e1211182660506 = 5609229171610 := by decide
theorem cert_e1211182660506 : check e1211182660506 [[],[]] .smaller = true := by decide
def e1211182660542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e1211182660542 : Closed e1211182660542 ∧ code e1211182660542 = 5609229171646 := by decide
theorem cert_e1211182660542 : check e1211182660542 [[],[]] .three = true := by decide
def e1211182660550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e1211182660550 : Closed e1211182660550 ∧ code e1211182660550 = 5609229171654 := by decide
theorem cert_e1211182660550 : check e1211182660550 [[],[]] .smaller = true := by decide
def e1211182660590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e1211182660590 : Closed e1211182660590 ∧ code e1211182660590 = 5609229171694 := by decide
theorem cert_e1211182660590 : check e1211182660590 [[],[]] .three = true := by decide
def e1211182660718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211182660718 : Closed e1211182660718 ∧ code e1211182660718 = 5609229171822 := by decide
theorem cert_e1211182660718 : check e1211182660718 [[],[]] .smaller = true := by decide
def e1211182660730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211182660730 : Closed e1211182660730 ∧ code e1211182660730 = 5609229171834 := by decide
theorem cert_e1211182660730 : check e1211182660730 [[],[]] .smaller = true := by decide
def e1211182660822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211182660822 : Closed e1211182660822 ∧ code e1211182660822 = 5609229171926 := by decide
theorem cert_e1211182660822 : check e1211182660822 [[],[]] .smaller = true := by decide
def e1211182660826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211182660826 : Closed e1211182660826 ∧ code e1211182660826 = 5609229171930 := by decide
theorem cert_e1211182660826 : check e1211182660826 [[],[]] .smaller = true := by decide
def e1211182660842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211182660842 : Closed e1211182660842 ∧ code e1211182660842 = 5609229171946 := by decide
theorem cert_e1211182660842 : check e1211182660842 [[],[]] .smaller = true := by decide
def e1211182660894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211182660894 : Closed e1211182660894 ∧ code e1211182660894 = 5609229171998 := by decide
theorem cert_e1211182660894 : check e1211182660894 [[],[]] .smaller = true := by decide
def e1211182660918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182660918 : Closed e1211182660918 ∧ code e1211182660918 = 5609229172022 := by decide
theorem cert_e1211182660918 : check e1211182660918 [[],[]] .smaller = true := by decide
def e1211182660922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182660922 : Closed e1211182660922 ∧ code e1211182660922 = 5609229172026 := by decide
theorem cert_e1211182660922 : check e1211182660922 [[],[]] .smaller = true := by decide
def e1211182661018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182661018 : Closed e1211182661018 ∧ code e1211182661018 = 5609229172122 := by decide
theorem cert_e1211182661018 : check e1211182661018 [[],[]] .smaller = true := by decide
def e1211182661054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e1211182661054 : Closed e1211182661054 ∧ code e1211182661054 = 5609229172158 := by decide
theorem cert_e1211182661054 : check e1211182661054 [[],[]] .three = true := by decide
def e1211182661062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211182661062 : Closed e1211182661062 ∧ code e1211182661062 = 5609229172166 := by decide
theorem cert_e1211182661062 : check e1211182661062 [[],[]] .smaller = true := by decide
def e1211182661086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 3)))))))))
theorem wire_e1211182661086 : Closed e1211182661086 ∧ code e1211182661086 = 5609229172190 := by decide
theorem cert_e1211182661086 : check e1211182661086 [[],[]] .smaller = true := by decide
def e1211182661102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 2)))))))))
theorem wire_e1211182661102 : Closed e1211182661102 ∧ code e1211182661102 = 5609229172206 := by decide
theorem cert_e1211182661102 : check e1211182661102 [[],[]] .smaller = true := by decide
def e1211182661110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e1211182661110 : Closed e1211182661110 ∧ code e1211182661110 = 5609229172214 := by decide
theorem cert_e1211182661110 : check e1211182661110 [[],[]] .three = true := by decide
def e1211182661174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211182661174 : Closed e1211182661174 ∧ code e1211182661174 = 5609229172278 := by decide
theorem cert_e1211182661174 : check e1211182661174 [[],[]] .smaller = true := by decide
def e1211182661178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211182661178 : Closed e1211182661178 ∧ code e1211182661178 = 5609229172282 := by decide
theorem cert_e1211182661178 : check e1211182661178 [[],[]] .smaller = true := by decide
def e1211182661226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e1211182661226 : Closed e1211182661226 ∧ code e1211182661226 = 5609229172330 := by decide
theorem cert_e1211182661226 : check e1211182661226 [[],[]] .smaller = true := by decide
def e1211182661262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211182661262 : Closed e1211182661262 ∧ code e1211182661262 = 5609229172366 := by decide
theorem cert_e1211182661262 : check e1211182661262 [[],[]] .smaller = true := by decide
def e1211182661274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182661274 : Closed e1211182661274 ∧ code e1211182661274 = 5609229172378 := by decide
theorem cert_e1211182661274 : check e1211182661274 [[],[]] .smaller = true := by decide
def e1211182661318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211182661318 : Closed e1211182661318 ∧ code e1211182661318 = 5609229172422 := by decide
theorem cert_e1211182661318 : check e1211182661318 [[],[]] .smaller = true := by decide
def e1211182661358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 2)))))))))
theorem wire_e1211182661358 : Closed e1211182661358 ∧ code e1211182661358 = 5609229172462 := by decide
theorem cert_e1211182661358 : check e1211182661358 [[],[]] .smaller = true := by decide
def e1211182661402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e1211182661402 : Closed e1211182661402 ∧ code e1211182661402 = 5609229172506 := by decide
theorem cert_e1211182661402 : check e1211182661402 [[],[]] .three = true := by decide
def e1211182661446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e1211182661446 : Closed e1211182661446 ∧ code e1211182661446 = 5609229172550 := by decide
theorem cert_e1211182661446 : check e1211182661446 [[],[]] .three = true := by decide
def e1211182661486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e1211182661486 : Closed e1211182661486 ∧ code e1211182661486 = 5609229172590 := by decide
theorem cert_e1211182661486 : check e1211182661486 [[],[]] .three = true := by decide
def e1211182661494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e1211182661494 : Closed e1211182661494 ∧ code e1211182661494 = 5609229172598 := by decide
theorem cert_e1211182661494 : check e1211182661494 [[],[]] .three = true := by decide
def e1211182662590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211182662590 : Closed e1211182662590 ∧ code e1211182662590 = 5609229173694 := by decide
theorem cert_e1211182662590 : check e1211182662590 [[],[]] .smaller = true := by decide
def e1211182662622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211182662622 : Closed e1211182662622 ∧ code e1211182662622 = 5609229173726 := by decide
theorem cert_e1211182662622 : check e1211182662622 [[],[]] .smaller = true := by decide
def e1211182662638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211182662638 : Closed e1211182662638 ∧ code e1211182662638 = 5609229173742 := by decide
theorem cert_e1211182662638 : check e1211182662638 [[],[]] .smaller = true := by decide
def e1211182662646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211182662646 : Closed e1211182662646 ∧ code e1211182662646 = 5609229173750 := by decide
theorem cert_e1211182662646 : check e1211182662646 [[],[]] .smaller = true := by decide
def e1211182664542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211182664542 : Closed e1211182664542 ∧ code e1211182664542 = 5609229175646 := by decide
theorem cert_e1211182664542 : check e1211182664542 [[],[]] .smaller = true := by decide
def e1211182664558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211182664558 : Closed e1211182664558 ∧ code e1211182664558 = 5609229175662 := by decide
theorem cert_e1211182664558 : check e1211182664558 [[],[]] .smaller = true := by decide
def e1211182664566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211182664566 : Closed e1211182664566 ∧ code e1211182664566 = 5609229175670 := by decide
theorem cert_e1211182664566 : check e1211182664566 [[],[]] .smaller = true := by decide
def e1211182664570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211182664570 : Closed e1211182664570 ∧ code e1211182664570 = 5609229175674 := by decide
theorem cert_e1211182664570 : check e1211182664570 [[],[]] .smaller = true := by decide
def e1211182664622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211182664622 : Closed e1211182664622 ∧ code e1211182664622 = 5609229175726 := by decide
theorem cert_e1211182664622 : check e1211182664622 [[],[]] .smaller = true := by decide
def e1211182664634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211182664634 : Closed e1211182664634 ∧ code e1211182664634 = 5609229175738 := by decide
theorem cert_e1211182664634 : check e1211182664634 [[],[]] .smaller = true := by decide
def e1211182664662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211182664662 : Closed e1211182664662 ∧ code e1211182664662 = 5609229175766 := by decide
theorem cert_e1211182664662 : check e1211182664662 [[],[]] .smaller = true := by decide
def e1211182664666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211182664666 : Closed e1211182664666 ∧ code e1211182664666 = 5609229175770 := by decide
theorem cert_e1211182664666 : check e1211182664666 [[],[]] .smaller = true := by decide
def e1211182664682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211182664682 : Closed e1211182664682 ∧ code e1211182664682 = 5609229175786 := by decide
theorem cert_e1211182664682 : check e1211182664682 [[],[]] .smaller = true := by decide
def e1211182664830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e1211182664830 : Closed e1211182664830 ∧ code e1211182664830 = 5609229175934 := by decide
theorem cert_e1211182664830 : check e1211182664830 [[],[]] .three = true := by decide
def e1211182664926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211182664926 : Closed e1211182664926 ∧ code e1211182664926 = 5609229176030 := by decide
theorem cert_e1211182664926 : check e1211182664926 [[],[]] .smaller = true := by decide
def e1211182664942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182664942 : Closed e1211182664942 ∧ code e1211182664942 = 5609229176046 := by decide
theorem cert_e1211182664942 : check e1211182664942 [[],[]] .smaller = true := by decide
def e1211182664950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182664950 : Closed e1211182664950 ∧ code e1211182664950 = 5609229176054 := by decide
theorem cert_e1211182664950 : check e1211182664950 [[],[]] .smaller = true := by decide
def e1211182664954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211182664954 : Closed e1211182664954 ∧ code e1211182664954 = 5609229176058 := by decide
theorem cert_e1211182664954 : check e1211182664954 [[],[]] .smaller = true := by decide
def e1211182665278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211182665278 : Closed e1211182665278 ∧ code e1211182665278 = 5609229176382 := by decide
theorem cert_e1211182665278 : check e1211182665278 [[],[]] .smaller = true := by decide
def e1211182665326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211182665326 : Closed e1211182665326 ∧ code e1211182665326 = 5609229176430 := by decide
theorem cert_e1211182665326 : check e1211182665326 [[],[]] .smaller = true := by decide
def e1211182665338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211182665338 : Closed e1211182665338 ∧ code e1211182665338 = 5609229176442 := by decide
theorem cert_e1211182665338 : check e1211182665338 [[],[]] .smaller = true := by decide
def e1211182665502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))))
theorem wire_e1211182665502 : Closed e1211182665502 ∧ code e1211182665502 = 5609229176606 := by decide
theorem cert_e1211182665502 : check e1211182665502 [[],[]] .smaller = true := by decide
def e1211182665526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182665526 : Closed e1211182665526 ∧ code e1211182665526 = 5609229176630 := by decide
theorem cert_e1211182665526 : check e1211182665526 [[],[]] .smaller = true := by decide
def e1211182665530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182665530 : Closed e1211182665530 ∧ code e1211182665530 = 5609229176634 := by decide
theorem cert_e1211182665530 : check e1211182665530 [[],[]] .smaller = true := by decide
def e1211182665614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211182665614 : Closed e1211182665614 ∧ code e1211182665614 = 5609229176718 := by decide
theorem cert_e1211182665614 : check e1211182665614 [[],[]] .smaller = true := by decide
def e1211182665626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182665626 : Closed e1211182665626 ∧ code e1211182665626 = 5609229176730 := by decide
theorem cert_e1211182665626 : check e1211182665626 [[],[]] .smaller = true := by decide
def e1211182665670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e1211182665670 : Closed e1211182665670 ∧ code e1211182665670 = 5609229176774 := by decide
theorem cert_e1211182665670 : check e1211182665670 [[],[]] .three = true := by decide
def e1211182670302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211182670302 : Closed e1211182670302 ∧ code e1211182670302 = 5609229181406 := by decide
theorem cert_e1211182670302 : check e1211182670302 [[],[]] .smaller = true := by decide
def e1211182670326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211182670326 : Closed e1211182670326 ∧ code e1211182670326 = 5609229181430 := by decide
theorem cert_e1211182670326 : check e1211182670326 [[],[]] .smaller = true := by decide
def e1211182671278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e1211182671278 : Closed e1211182671278 ∧ code e1211182671278 = 5609229182382 := by decide
theorem cert_e1211182671278 : check e1211182671278 [[],[]] .smaller = true := by decide
def e1211182671290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e1211182671290 : Closed e1211182671290 ∧ code e1211182671290 = 5609229182394 := by decide
theorem cert_e1211182671290 : check e1211182671290 [[],[]] .smaller = true := by decide
def e1211182671338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e1211182671338 : Closed e1211182671338 ∧ code e1211182671338 = 5609229182442 := by decide
theorem cert_e1211182671338 : check e1211182671338 [[],[]] .smaller = true := by decide
def e1211182671422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e1211182671422 : Closed e1211182671422 ∧ code e1211182671422 = 5609229182526 := by decide
theorem cert_e1211182671422 : check e1211182671422 [[],[]] .smaller = true := by decide
def e1211182671470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211182671470 : Closed e1211182671470 ∧ code e1211182671470 = 5609229182574 := by decide
theorem cert_e1211182671470 : check e1211182671470 [[],[]] .smaller = true := by decide
def e1211182671482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211182671482 : Closed e1211182671482 ∧ code e1211182671482 = 5609229182586 := by decide
theorem cert_e1211182671482 : check e1211182671482 [[],[]] .smaller = true := by decide
def e1211182671770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182671770 : Closed e1211182671770 ∧ code e1211182671770 = 5609229182874 := by decide
theorem cert_e1211182671770 : check e1211182671770 [[],[]] .smaller = true := by decide
def e1211182671806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211182671806 : Closed e1211182671806 ∧ code e1211182671806 = 5609229182910 := by decide
theorem cert_e1211182671806 : check e1211182671806 [[],[]] .three = true := by decide
def e1211182671814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e1211182671814 : Closed e1211182671814 ∧ code e1211182671814 = 5609229182918 := by decide
theorem cert_e1211182671814 : check e1211182671814 [[],[]] .smaller = true := by decide
def e1211182671854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211182671854 : Closed e1211182671854 ∧ code e1211182671854 = 5609229182958 := by decide
theorem cert_e1211182671854 : check e1211182671854 [[],[]] .three = true := by decide
def e1211182674158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182674158 : Closed e1211182674158 ∧ code e1211182674158 = 5609229185262 := by decide
theorem cert_e1211182674158 : check e1211182674158 [[],[]] .smaller = true := by decide
def e1211182674166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182674166 : Closed e1211182674166 ∧ code e1211182674166 = 5609229185270 := by decide
theorem cert_e1211182674166 : check e1211182674166 [[],[]] .smaller = true := by decide
def e1211182674646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211182674646 : Closed e1211182674646 ∧ code e1211182674646 = 5609229185750 := by decide
theorem cert_e1211182674646 : check e1211182674646 [[],[]] .smaller = true := by decide
def e1211182674650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211182674650 : Closed e1211182674650 ∧ code e1211182674650 = 5609229185754 := by decide
theorem cert_e1211182674650 : check e1211182674650 [[],[]] .smaller = true := by decide
def e1211182674666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211182674666 : Closed e1211182674666 ∧ code e1211182674666 = 5609229185770 := by decide
theorem cert_e1211182674666 : check e1211182674666 [[],[]] .smaller = true := by decide
def e1211182674718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211182674718 : Closed e1211182674718 ∧ code e1211182674718 = 5609229185822 := by decide
theorem cert_e1211182674718 : check e1211182674718 [[],[]] .smaller = true := by decide
def e1211182674742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182674742 : Closed e1211182674742 ∧ code e1211182674742 = 5609229185846 := by decide
theorem cert_e1211182674742 : check e1211182674742 [[],[]] .smaller = true := by decide
def e1211182674746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182674746 : Closed e1211182674746 ∧ code e1211182674746 = 5609229185850 := by decide
theorem cert_e1211182674746 : check e1211182674746 [[],[]] .smaller = true := by decide
def e1211182674842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182674842 : Closed e1211182674842 ∧ code e1211182674842 = 5609229185946 := by decide
theorem cert_e1211182674842 : check e1211182674842 [[],[]] .smaller = true := by decide
def e1211182674878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211182674878 : Closed e1211182674878 ∧ code e1211182674878 = 5609229185982 := by decide
theorem cert_e1211182674878 : check e1211182674878 [[],[]] .three = true := by decide
def e1211182674886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211182674886 : Closed e1211182674886 ∧ code e1211182674886 = 5609229185990 := by decide
theorem cert_e1211182674886 : check e1211182674886 [[],[]] .smaller = true := by decide
def e1211182674910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211182674910 : Closed e1211182674910 ∧ code e1211182674910 = 5609229186014 := by decide
theorem cert_e1211182674910 : check e1211182674910 [[],[]] .smaller = true := by decide
def e1211182674926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211182674926 : Closed e1211182674926 ∧ code e1211182674926 = 5609229186030 := by decide
theorem cert_e1211182674926 : check e1211182674926 [[],[]] .smaller = true := by decide
def e1211182674934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211182674934 : Closed e1211182674934 ∧ code e1211182674934 = 5609229186038 := by decide
theorem cert_e1211182674934 : check e1211182674934 [[],[]] .three = true := by decide
def e1211182676086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182676086 : Closed e1211182676086 ∧ code e1211182676086 = 5609229187190 := by decide
theorem cert_e1211182676086 : check e1211182676086 [[],[]] .smaller = true := by decide
def e1211182676330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e1211182676330 : Closed e1211182676330 ∧ code e1211182676330 = 5609229187434 := by decide
theorem cert_e1211182676330 : check e1211182676330 [[],[]] .smaller = true := by decide
def e1211182676366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211182676366 : Closed e1211182676366 ∧ code e1211182676366 = 5609229187470 := by decide
theorem cert_e1211182676366 : check e1211182676366 [[],[]] .smaller = true := by decide
def e1211182676378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182676378 : Closed e1211182676378 ∧ code e1211182676378 = 5609229187482 := by decide
theorem cert_e1211182676378 : check e1211182676378 [[],[]] .smaller = true := by decide
def e1211182676422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211182676422 : Closed e1211182676422 ∧ code e1211182676422 = 5609229187526 := by decide
theorem cert_e1211182676422 : check e1211182676422 [[],[]] .smaller = true := by decide
def e1211182676462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211182676462 : Closed e1211182676462 ∧ code e1211182676462 = 5609229187566 := by decide
theorem cert_e1211182676462 : check e1211182676462 [[],[]] .smaller = true := by decide
def e1211182677190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e1211182677190 : Closed e1211182677190 ∧ code e1211182677190 = 5609229188294 := by decide
theorem cert_e1211182677190 : check e1211182677190 [[],[]] .three = true := by decide
def e1211182677230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182677230 : Closed e1211182677230 ∧ code e1211182677230 = 5609229188334 := by decide
theorem cert_e1211182677230 : check e1211182677230 [[],[]] .three = true := by decide
def e1211182677238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182677238 : Closed e1211182677238 ∧ code e1211182677238 = 5609229188342 := by decide
theorem cert_e1211182677238 : check e1211182677238 [[],[]] .three = true := by decide
def e1211182749406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211182749406 : Closed e1211182749406 ∧ code e1211182749406 = 5609229260510 := by decide
theorem cert_e1211182749406 : check e1211182749406 [[],[]] .smaller = true := by decide
def e1211182749430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211182749430 : Closed e1211182749430 ∧ code e1211182749430 = 5609229260534 := by decide
theorem cert_e1211182749430 : check e1211182749430 [[],[]] .smaller = true := by decide
def e1211182749534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211182749534 : Closed e1211182749534 ∧ code e1211182749534 = 5609229260638 := by decide
theorem cert_e1211182749534 : check e1211182749534 [[],[]] .smaller = true := by decide
def e1211182749550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e1211182749550 : Closed e1211182749550 ∧ code e1211182749550 = 5609229260654 := by decide
theorem cert_e1211182749550 : check e1211182749550 [[],[]] .smaller = true := by decide
end Blc.Floor42
