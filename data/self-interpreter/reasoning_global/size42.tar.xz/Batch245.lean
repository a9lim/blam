import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211283437966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211283437966 : Closed e1211283437966 ∧ code e1211283437966 = 5609329949070 := by decide
theorem cert_e1211283437966 : check e1211283437966 [[],[]] .sourceHead = true := by decide
def e1211283438022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211283438022 : Closed e1211283438022 ∧ code e1211283438022 = 5609329949126 := by decide
theorem cert_e1211283438022 : check e1211283438022 [[],[]] .sourceHead = true := by decide
def e1211287231350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e1211287231350 : Closed e1211287231350 ∧ code e1211287231350 = 5609333742454 := by decide
theorem cert_e1211287231350 : check e1211287231350 [[],[]] .sourceHead = true := by decide
def e1211287231414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e1211287231414 : Closed e1211287231414 ∧ code e1211287231414 = 5609333742518 := by decide
theorem cert_e1211287231414 : check e1211287231414 [[],[]] .sourceHead = true := by decide
def e1211287231862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e1211287231862 : Closed e1211287231862 ∧ code e1211287231862 = 5609333742966 := by decide
theorem cert_e1211287231862 : check e1211287231862 [[],[]] .sourceHead = true := by decide
def e1211287231958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e1211287231958 : Closed e1211287231958 ∧ code e1211287231958 = 5609333743062 := by decide
theorem cert_e1211287231958 : check e1211287231958 [[],[]] .sourceHead = true := by decide
def e1211287232182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e1211287232182 : Closed e1211287232182 ∧ code e1211287232182 = 5609333743286 := by decide
theorem cert_e1211287232182 : check e1211287232182 [[],[]] .sourceHead = true := by decide
def e1211287232214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e1211287232214 : Closed e1211287232214 ∧ code e1211287232214 = 5609333743318 := by decide
theorem cert_e1211287232214 : check e1211287232214 [[],[]] .sourceHead = true := by decide
def e1211287234422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e1211287234422 : Closed e1211287234422 ∧ code e1211287234422 = 5609333745526 := by decide
theorem cert_e1211287234422 : check e1211287234422 [[],[]] .sourceHead = true := by decide
def e1211287234486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e1211287234486 : Closed e1211287234486 ∧ code e1211287234486 = 5609333745590 := by decide
theorem cert_e1211287234486 : check e1211287234486 [[],[]] .sourceHead = true := by decide
def e1211287237494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e1211287237494 : Closed e1211287237494 ∧ code e1211287237494 = 5609333748598 := by decide
theorem cert_e1211287237494 : check e1211287237494 [[],[]] .sourceHead = true := by decide
def e1211287237590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e1211287237590 : Closed e1211287237590 ∧ code e1211287237590 = 5609333748694 := by decide
theorem cert_e1211287237590 : check e1211287237590 [[],[]] .sourceHead = true := by decide
def e1211287239094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211287239094 : Closed e1211287239094 ∧ code e1211287239094 = 5609333750198 := by decide
theorem cert_e1211287239094 : check e1211287239094 [[],[]] .sourceHead = true := by decide
def e1211287239126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211287239126 : Closed e1211287239126 ∧ code e1211287239126 = 5609333750230 := by decide
theorem cert_e1211287239126 : check e1211287239126 [[],[]] .sourceHead = true := by decide
def e1211287407470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211287407470 : Closed e1211287407470 ∧ code e1211287407470 = 5609333918574 := by decide
theorem cert_e1211287407470 : check e1211287407470 [[],[]] .sourceHead = true := by decide
def e1211287407478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211287407478 : Closed e1211287407478 ∧ code e1211287407478 = 5609333918582 := by decide
theorem cert_e1211287407478 : check e1211287407478 [[],[]] .sourceHead = true := by decide
def e1211287407534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211287407534 : Closed e1211287407534 ∧ code e1211287407534 = 5609333918638 := by decide
theorem cert_e1211287407534 : check e1211287407534 [[],[]] .sourceHead = true := by decide
def e1211287407546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211287407546 : Closed e1211287407546 ∧ code e1211287407546 = 5609333918650 := by decide
theorem cert_e1211287407546 : check e1211287407546 [[],[]] .sourceHead = true := by decide
def e1211287407574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211287407574 : Closed e1211287407574 ∧ code e1211287407574 = 5609333918678 := by decide
theorem cert_e1211287407574 : check e1211287407574 [[],[]] .sourceHead = true := by decide
def e1211287407578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211287407578 : Closed e1211287407578 ∧ code e1211287407578 = 5609333918682 := by decide
theorem cert_e1211287407578 : check e1211287407578 [[],[]] .sourceHead = true := by decide
def e1211287407854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211287407854 : Closed e1211287407854 ∧ code e1211287407854 = 5609333918958 := by decide
theorem cert_e1211287407854 : check e1211287407854 [[],[]] .sourceHead = true := by decide
def e1211287407862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211287407862 : Closed e1211287407862 ∧ code e1211287407862 = 5609333918966 := by decide
theorem cert_e1211287407862 : check e1211287407862 [[],[]] .sourceHead = true := by decide
def e1211287408238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211287408238 : Closed e1211287408238 ∧ code e1211287408238 = 5609333919342 := by decide
theorem cert_e1211287408238 : check e1211287408238 [[],[]] .sourceHead = true := by decide
def e1211287408250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211287408250 : Closed e1211287408250 ∧ code e1211287408250 = 5609333919354 := by decide
theorem cert_e1211287408250 : check e1211287408250 [[],[]] .sourceHead = true := by decide
def e1211287408438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211287408438 : Closed e1211287408438 ∧ code e1211287408438 = 5609333919542 := by decide
theorem cert_e1211287408438 : check e1211287408438 [[],[]] .sourceHead = true := by decide
def e1211287408442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211287408442 : Closed e1211287408442 ∧ code e1211287408442 = 5609333919546 := by decide
theorem cert_e1211287408442 : check e1211287408442 [[],[]] .sourceHead = true := by decide
def e1211287481786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e1211287481786 : Closed e1211287481786 ∧ code e1211287481786 = 5609333992890 := by decide
theorem cert_e1211287481786 : check e1211287481786 [[],[]] .sourceHead = true := by decide
def e1211287481818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e1211287481818 : Closed e1211287481818 ∧ code e1211287481818 = 5609333992922 := by decide
theorem cert_e1211287481818 : check e1211287481818 [[],[]] .sourceHead = true := by decide
def e1211287482042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211287482042 : Closed e1211287482042 ∧ code e1211287482042 = 5609333993146 := by decide
theorem cert_e1211287482042 : check e1211287482042 [[],[]] .sourceHead = true := by decide
def e1211287482090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211287482090 : Closed e1211287482090 ∧ code e1211287482090 = 5609333993194 := by decide
theorem cert_e1211287482090 : check e1211287482090 [[],[]] .sourceHead = true := by decide
def e1211287482202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211287482202 : Closed e1211287482202 ∧ code e1211287482202 = 5609333993306 := by decide
theorem cert_e1211287482202 : check e1211287482202 [[],[]] .sourceHead = true := by decide
def e1211287482218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211287482218 : Closed e1211287482218 ∧ code e1211287482218 = 5609333993322 := by decide
theorem cert_e1211287482218 : check e1211287482218 [[],[]] .sourceHead = true := by decide
def e1211287483322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211287483322 : Closed e1211287483322 ∧ code e1211287483322 = 5609333994426 := by decide
theorem cert_e1211287483322 : check e1211287483322 [[],[]] .sourceHead = true := by decide
def e1211287483354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211287483354 : Closed e1211287483354 ∧ code e1211287483354 = 5609333994458 := by decide
theorem cert_e1211287483354 : check e1211287483354 [[],[]] .sourceHead = true := by decide
def e1211287484858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211287484858 : Closed e1211287484858 ∧ code e1211287484858 = 5609333995962 := by decide
theorem cert_e1211287484858 : check e1211287484858 [[],[]] .sourceHead = true := by decide
def e1211287484906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211287484906 : Closed e1211287484906 ∧ code e1211287484906 = 5609333996010 := by decide
theorem cert_e1211287484906 : check e1211287484906 [[],[]] .sourceHead = true := by decide
def e1211287485658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211287485658 : Closed e1211287485658 ∧ code e1211287485658 = 5609333996762 := by decide
theorem cert_e1211287485658 : check e1211287485658 [[],[]] .sourceHead = true := by decide
def e1211287485674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211287485674 : Closed e1211287485674 ∧ code e1211287485674 = 5609333996778 := by decide
theorem cert_e1211287485674 : check e1211287485674 [[],[]] .sourceHead = true := by decide
def e1211287538542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211287538542 : Closed e1211287538542 ∧ code e1211287538542 = 5609334049646 := by decide
theorem cert_e1211287538542 : check e1211287538542 [[],[]] .sourceHead = true := by decide
def e1211287538550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211287538550 : Closed e1211287538550 ∧ code e1211287538550 = 5609334049654 := by decide
theorem cert_e1211287538550 : check e1211287538550 [[],[]] .sourceHead = true := by decide
def e1211287538606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211287538606 : Closed e1211287538606 ∧ code e1211287538606 = 5609334049710 := by decide
theorem cert_e1211287538606 : check e1211287538606 [[],[]] .sourceHead = true := by decide
def e1211287538618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211287538618 : Closed e1211287538618 ∧ code e1211287538618 = 5609334049722 := by decide
theorem cert_e1211287538618 : check e1211287538618 [[],[]] .sourceHead = true := by decide
def e1211287538646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211287538646 : Closed e1211287538646 ∧ code e1211287538646 = 5609334049750 := by decide
theorem cert_e1211287538646 : check e1211287538646 [[],[]] .sourceHead = true := by decide
def e1211287538650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211287538650 : Closed e1211287538650 ∧ code e1211287538650 = 5609334049754 := by decide
theorem cert_e1211287538650 : check e1211287538650 [[],[]] .sourceHead = true := by decide
def e1211287538926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211287538926 : Closed e1211287538926 ∧ code e1211287538926 = 5609334050030 := by decide
theorem cert_e1211287538926 : check e1211287538926 [[],[]] .sourceHead = true := by decide
def e1211287538934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211287538934 : Closed e1211287538934 ∧ code e1211287538934 = 5609334050038 := by decide
theorem cert_e1211287538934 : check e1211287538934 [[],[]] .sourceHead = true := by decide
def e1211287539310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211287539310 : Closed e1211287539310 ∧ code e1211287539310 = 5609334050414 := by decide
theorem cert_e1211287539310 : check e1211287539310 [[],[]] .sourceHead = true := by decide
def e1211287539322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211287539322 : Closed e1211287539322 ∧ code e1211287539322 = 5609334050426 := by decide
theorem cert_e1211287539322 : check e1211287539322 [[],[]] .sourceHead = true := by decide
def e1211287539510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211287539510 : Closed e1211287539510 ∧ code e1211287539510 = 5609334050614 := by decide
theorem cert_e1211287539510 : check e1211287539510 [[],[]] .sourceHead = true := by decide
def e1211287539514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211287539514 : Closed e1211287539514 ∧ code e1211287539514 = 5609334050618 := by decide
theorem cert_e1211287539514 : check e1211287539514 [[],[]] .sourceHead = true := by decide
def e1211287738078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211287738078 : Closed e1211287738078 ∧ code e1211287738078 = 5609334249182 := by decide
theorem cert_e1211287738078 : check e1211287738078 [[],[]] .smaller = true := by decide
def e1211287738102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211287738102 : Closed e1211287738102 ∧ code e1211287738102 = 5609334249206 := by decide
theorem cert_e1211287738102 : check e1211287738102 [[],[]] .smaller = true := by decide
def e1211287738206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211287738206 : Closed e1211287738206 ∧ code e1211287738206 = 5609334249310 := by decide
theorem cert_e1211287738206 : check e1211287738206 [[],[]] .smaller = true := by decide
def e1211287738234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211287738234 : Closed e1211287738234 ∧ code e1211287738234 = 5609334249338 := by decide
theorem cert_e1211287738234 : check e1211287738234 [[],[]] .smaller = true := by decide
def e1211287738326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211287738326 : Closed e1211287738326 ∧ code e1211287738326 = 5609334249430 := by decide
theorem cert_e1211287738326 : check e1211287738326 [[],[]] .smaller = true := by decide
def e1211287738330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211287738330 : Closed e1211287738330 ∧ code e1211287738330 = 5609334249434 := by decide
theorem cert_e1211287738330 : check e1211287738330 [[],[]] .smaller = true := by decide
def e1211287738846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211287738846 : Closed e1211287738846 ∧ code e1211287738846 = 5609334249950 := by decide
theorem cert_e1211287738846 : check e1211287738846 [[],[]] .smaller = true := by decide
def e1211287738870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211287738870 : Closed e1211287738870 ∧ code e1211287738870 = 5609334249974 := by decide
theorem cert_e1211287738870 : check e1211287738870 [[],[]] .smaller = true := by decide
def e1211287739614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211287739614 : Closed e1211287739614 ∧ code e1211287739614 = 5609334250718 := by decide
theorem cert_e1211287739614 : check e1211287739614 [[],[]] .smaller = true := by decide
def e1211287739642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211287739642 : Closed e1211287739642 ∧ code e1211287739642 = 5609334250746 := by decide
theorem cert_e1211287739642 : check e1211287739642 [[],[]] .smaller = true := by decide
def e1211287740214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211287740214 : Closed e1211287740214 ∧ code e1211287740214 = 5609334251318 := by decide
theorem cert_e1211287740214 : check e1211287740214 [[],[]] .smaller = true := by decide
def e1211287740218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211287740218 : Closed e1211287740218 ∧ code e1211287740218 = 5609334251322 := by decide
theorem cert_e1211287740218 : check e1211287740218 [[],[]] .smaller = true := by decide
def e1211287754990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211287754990 : Closed e1211287754990 ∧ code e1211287754990 = 5609334266094 := by decide
theorem cert_e1211287754990 : check e1211287754990 [[],[]] .smaller = true := by decide
def e1211287754998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211287754998 : Closed e1211287754998 ∧ code e1211287754998 = 5609334266102 := by decide
theorem cert_e1211287754998 : check e1211287754998 [[],[]] .smaller = true := by decide
def e1211287755550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211287755550 : Closed e1211287755550 ∧ code e1211287755550 = 5609334266654 := by decide
theorem cert_e1211287755550 : check e1211287755550 [[],[]] .smaller = true := by decide
def e1211287755662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211287755662 : Closed e1211287755662 ∧ code e1211287755662 = 5609334266766 := by decide
theorem cert_e1211287755662 : check e1211287755662 [[],[]] .smaller = true := by decide
def e1211287755886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211287755886 : Closed e1211287755886 ∧ code e1211287755886 = 5609334266990 := by decide
theorem cert_e1211287755886 : check e1211287755886 [[],[]] .smaller = true := by decide
def e1211287755898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211287755898 : Closed e1211287755898 ∧ code e1211287755898 = 5609334267002 := by decide
theorem cert_e1211287755898 : check e1211287755898 [[],[]] .smaller = true := by decide
def e1211287756062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211287756062 : Closed e1211287756062 ∧ code e1211287756062 = 5609334267166 := by decide
theorem cert_e1211287756062 : check e1211287756062 [[],[]] .smaller = true := by decide
def e1211287756230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211287756230 : Closed e1211287756230 ∧ code e1211287756230 = 5609334267334 := by decide
theorem cert_e1211287756230 : check e1211287756230 [[],[]] .smaller = true := by decide
def e1211287756254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e1211287756254 : Closed e1211287756254 ∧ code e1211287756254 = 5609334267358 := by decide
theorem cert_e1211287756254 : check e1211287756254 [[],[]] .chain = true := by decide
def e1211287756270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e1211287756270 : Closed e1211287756270 ∧ code e1211287756270 = 5609334267374 := by decide
theorem cert_e1211287756270 : check e1211287756270 [[],[]] .chain = true := by decide
def e1211287756342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211287756342 : Closed e1211287756342 ∧ code e1211287756342 = 5609334267446 := by decide
theorem cert_e1211287756342 : check e1211287756342 [[],[]] .smaller = true := by decide
def e1211287756346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211287756346 : Closed e1211287756346 ∧ code e1211287756346 = 5609334267450 := by decide
theorem cert_e1211287756346 : check e1211287756346 [[],[]] .smaller = true := by decide
def e1211287756430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211287756430 : Closed e1211287756430 ∧ code e1211287756430 = 5609334267534 := by decide
theorem cert_e1211287756430 : check e1211287756430 [[],[]] .smaller = true := by decide
def e1211287756486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211287756486 : Closed e1211287756486 ∧ code e1211287756486 = 5609334267590 := by decide
theorem cert_e1211287756486 : check e1211287756486 [[],[]] .smaller = true := by decide
def e1211287756510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e1211287756510 : Closed e1211287756510 ∧ code e1211287756510 = 5609334267614 := by decide
theorem cert_e1211287756510 : check e1211287756510 [[],[]] .chain = true := by decide
def e1211287756534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e1211287756534 : Closed e1211287756534 ∧ code e1211287756534 = 5609334267638 := by decide
theorem cert_e1211287756534 : check e1211287756534 [[],[]] .chain = true := by decide
def e1211287756654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211287756654 : Closed e1211287756654 ∧ code e1211287756654 = 5609334267758 := by decide
theorem cert_e1211287756654 : check e1211287756654 [[],[]] .chain = true := by decide
def e1211287756662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211287756662 : Closed e1211287756662 ∧ code e1211287756662 = 5609334267766 := by decide
theorem cert_e1211287756662 : check e1211287756662 [[],[]] .chain = true := by decide
def e1211287758622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211287758622 : Closed e1211287758622 ∧ code e1211287758622 = 5609334269726 := by decide
theorem cert_e1211287758622 : check e1211287758622 [[],[]] .smaller = true := by decide
def e1211287758734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211287758734 : Closed e1211287758734 ∧ code e1211287758734 = 5609334269838 := by decide
theorem cert_e1211287758734 : check e1211287758734 [[],[]] .smaller = true := by decide
def e1211287761694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211287761694 : Closed e1211287761694 ∧ code e1211287761694 = 5609334272798 := by decide
theorem cert_e1211287761694 : check e1211287761694 [[],[]] .smaller = true := by decide
def e1211287761862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211287761862 : Closed e1211287761862 ∧ code e1211287761862 = 5609334272966 := by decide
theorem cert_e1211287761862 : check e1211287761862 [[],[]] .smaller = true := by decide
def e1211287761886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211287761886 : Closed e1211287761886 ∧ code e1211287761886 = 5609334272990 := by decide
theorem cert_e1211287761886 : check e1211287761886 [[],[]] .chain = true := by decide
def e1211287761902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211287761902 : Closed e1211287761902 ∧ code e1211287761902 = 5609334273006 := by decide
theorem cert_e1211287761902 : check e1211287761902 [[],[]] .chain = true := by decide
def e1211287763342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211287763342 : Closed e1211287763342 ∧ code e1211287763342 = 5609334274446 := by decide
theorem cert_e1211287763342 : check e1211287763342 [[],[]] .smaller = true := by decide
def e1211287763398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211287763398 : Closed e1211287763398 ∧ code e1211287763398 = 5609334274502 := by decide
theorem cert_e1211287763398 : check e1211287763398 [[],[]] .smaller = true := by decide
def e1211287763422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211287763422 : Closed e1211287763422 ∧ code e1211287763422 = 5609334274526 := by decide
theorem cert_e1211287763422 : check e1211287763422 [[],[]] .chain = true := by decide
def e1211287763446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211287763446 : Closed e1211287763446 ∧ code e1211287763446 = 5609334274550 := by decide
theorem cert_e1211287763446 : check e1211287763446 [[],[]] .chain = true := by decide
def e1211287764206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211287764206 : Closed e1211287764206 ∧ code e1211287764206 = 5609334275310 := by decide
theorem cert_e1211287764206 : check e1211287764206 [[],[]] .chain = true := by decide
def e1211287764214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211287764214 : Closed e1211287764214 ∧ code e1211287764214 = 5609334275318 := by decide
theorem cert_e1211287764214 : check e1211287764214 [[],[]] .chain = true := by decide
def e1211287821166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211287821166 : Closed e1211287821166 ∧ code e1211287821166 = 5609334332270 := by decide
theorem cert_e1211287821166 : check e1211287821166 [[],[]] .chain = true := by decide
def e1211287821174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211287821174 : Closed e1211287821174 ∧ code e1211287821174 = 5609334332278 := by decide
theorem cert_e1211287821174 : check e1211287821174 [[],[]] .chain = true := by decide
def e1211287821238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211287821238 : Closed e1211287821238 ∧ code e1211287821238 = 5609334332342 := by decide
theorem cert_e1211287821238 : check e1211287821238 [[],[]] .chain = true := by decide
def e1211287821678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211287821678 : Closed e1211287821678 ∧ code e1211287821678 = 5609334332782 := by decide
theorem cert_e1211287821678 : check e1211287821678 [[],[]] .chain = true := by decide
def e1211287821686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211287821686 : Closed e1211287821686 ∧ code e1211287821686 = 5609334332790 := by decide
theorem cert_e1211287821686 : check e1211287821686 [[],[]] .chain = true := by decide
def e1211287821742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211287821742 : Closed e1211287821742 ∧ code e1211287821742 = 5609334332846 := by decide
theorem cert_e1211287821742 : check e1211287821742 [[],[]] .chain = true := by decide
def e1211287821754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211287821754 : Closed e1211287821754 ∧ code e1211287821754 = 5609334332858 := by decide
theorem cert_e1211287821754 : check e1211287821754 [[],[]] .chain = true := by decide
def e1211287821782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211287821782 : Closed e1211287821782 ∧ code e1211287821782 = 5609334332886 := by decide
theorem cert_e1211287821782 : check e1211287821782 [[],[]] .chain = true := by decide
def e1211287821786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211287821786 : Closed e1211287821786 ∧ code e1211287821786 = 5609334332890 := by decide
theorem cert_e1211287821786 : check e1211287821786 [[],[]] .chain = true := by decide
def e1211287822006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211287822006 : Closed e1211287822006 ∧ code e1211287822006 = 5609334333110 := by decide
theorem cert_e1211287822006 : check e1211287822006 [[],[]] .chain = true := by decide
def e1211287822038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211287822038 : Closed e1211287822038 ∧ code e1211287822038 = 5609334333142 := by decide
theorem cert_e1211287822038 : check e1211287822038 [[],[]] .chain = true := by decide
def e1211287822042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211287822042 : Closed e1211287822042 ∧ code e1211287822042 = 5609334333146 := by decide
theorem cert_e1211287822042 : check e1211287822042 [[],[]] .chain = true := by decide
def e1211287824238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211287824238 : Closed e1211287824238 ∧ code e1211287824238 = 5609334335342 := by decide
theorem cert_e1211287824238 : check e1211287824238 [[],[]] .chain = true := by decide
def e1211287824246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211287824246 : Closed e1211287824246 ∧ code e1211287824246 = 5609334335350 := by decide
theorem cert_e1211287824246 : check e1211287824246 [[],[]] .chain = true := by decide
def e1211287824310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211287824310 : Closed e1211287824310 ∧ code e1211287824310 = 5609334335414 := by decide
theorem cert_e1211287824310 : check e1211287824310 [[],[]] .chain = true := by decide
def e1211287825646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211287825646 : Closed e1211287825646 ∧ code e1211287825646 = 5609334336750 := by decide
theorem cert_e1211287825646 : check e1211287825646 [[],[]] .chain = true := by decide
def e1211287825654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211287825654 : Closed e1211287825654 ∧ code e1211287825654 = 5609334336758 := by decide
theorem cert_e1211287825654 : check e1211287825654 [[],[]] .chain = true := by decide
def e1211287826038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211287826038 : Closed e1211287826038 ∧ code e1211287826038 = 5609334337142 := by decide
theorem cert_e1211287826038 : check e1211287826038 [[],[]] .chain = true := by decide
def e1211287827310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211287827310 : Closed e1211287827310 ∧ code e1211287827310 = 5609334338414 := by decide
theorem cert_e1211287827310 : check e1211287827310 [[],[]] .chain = true := by decide
def e1211287827318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211287827318 : Closed e1211287827318 ∧ code e1211287827318 = 5609334338422 := by decide
theorem cert_e1211287827318 : check e1211287827318 [[],[]] .chain = true := by decide
def e1211287827374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211287827374 : Closed e1211287827374 ∧ code e1211287827374 = 5609334338478 := by decide
theorem cert_e1211287827374 : check e1211287827374 [[],[]] .chain = true := by decide
def e1211287827386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211287827386 : Closed e1211287827386 ∧ code e1211287827386 = 5609334338490 := by decide
theorem cert_e1211287827386 : check e1211287827386 [[],[]] .chain = true := by decide
def e1211287827414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211287827414 : Closed e1211287827414 ∧ code e1211287827414 = 5609334338518 := by decide
theorem cert_e1211287827414 : check e1211287827414 [[],[]] .chain = true := by decide
def e1211287827418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211287827418 : Closed e1211287827418 ∧ code e1211287827418 = 5609334338522 := by decide
theorem cert_e1211287827418 : check e1211287827418 [[],[]] .chain = true := by decide
def e1211287827694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211287827694 : Closed e1211287827694 ∧ code e1211287827694 = 5609334338798 := by decide
theorem cert_e1211287827694 : check e1211287827694 [[],[]] .chain = true := by decide
def e1211287827702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211287827702 : Closed e1211287827702 ∧ code e1211287827702 = 5609334338806 := by decide
theorem cert_e1211287827702 : check e1211287827702 [[],[]] .chain = true := by decide
def e1211287828078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211287828078 : Closed e1211287828078 ∧ code e1211287828078 = 5609334339182 := by decide
theorem cert_e1211287828078 : check e1211287828078 [[],[]] .chain = true := by decide
def e1211287828090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211287828090 : Closed e1211287828090 ∧ code e1211287828090 = 5609334339194 := by decide
theorem cert_e1211287828090 : check e1211287828090 [[],[]] .chain = true := by decide
def e1211287828278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211287828278 : Closed e1211287828278 ∧ code e1211287828278 = 5609334339382 := by decide
theorem cert_e1211287828278 : check e1211287828278 [[],[]] .chain = true := by decide
def e1211287828282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211287828282 : Closed e1211287828282 ∧ code e1211287828282 = 5609334339386 := by decide
theorem cert_e1211287828282 : check e1211287828282 [[],[]] .chain = true := by decide
def e1211287828918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211287828918 : Closed e1211287828918 ∧ code e1211287828918 = 5609334340022 := by decide
theorem cert_e1211287828918 : check e1211287828918 [[],[]] .chain = true := by decide
def e1211287828950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211287828950 : Closed e1211287828950 ∧ code e1211287828950 = 5609334340054 := by decide
theorem cert_e1211287828950 : check e1211287828950 [[],[]] .chain = true := by decide
def e1211287828954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211287828954 : Closed e1211287828954 ∧ code e1211287828954 = 5609334340058 := by decide
theorem cert_e1211287828954 : check e1211287828954 [[],[]] .chain = true := by decide
def e1211287829110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211287829110 : Closed e1211287829110 ∧ code e1211287829110 = 5609334340214 := by decide
theorem cert_e1211287829110 : check e1211287829110 [[],[]] .chain = true := by decide
def e1211287829302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211287829302 : Closed e1211287829302 ∧ code e1211287829302 = 5609334340406 := by decide
theorem cert_e1211287829302 : check e1211287829302 [[],[]] .chain = true := by decide
def e1211287829306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211287829306 : Closed e1211287829306 ∧ code e1211287829306 = 5609334340410 := by decide
theorem cert_e1211287829306 : check e1211287829306 [[],[]] .chain = true := by decide
def e1211287836526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211287836526 : Closed e1211287836526 ∧ code e1211287836526 = 5609334347630 := by decide
theorem cert_e1211287836526 : check e1211287836526 [[],[]] .chain = true := by decide
def e1211287836534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211287836534 : Closed e1211287836534 ∧ code e1211287836534 = 5609334347638 := by decide
theorem cert_e1211287836534 : check e1211287836534 [[],[]] .chain = true := by decide
def e1211287836598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211287836598 : Closed e1211287836598 ∧ code e1211287836598 = 5609334347702 := by decide
theorem cert_e1211287836598 : check e1211287836598 [[],[]] .chain = true := by decide
def e1211287837934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211287837934 : Closed e1211287837934 ∧ code e1211287837934 = 5609334349038 := by decide
theorem cert_e1211287837934 : check e1211287837934 [[],[]] .chain = true := by decide
def e1211287837942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211287837942 : Closed e1211287837942 ∧ code e1211287837942 = 5609334349046 := by decide
theorem cert_e1211287837942 : check e1211287837942 [[],[]] .chain = true := by decide
def e1211287838326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211287838326 : Closed e1211287838326 ∧ code e1211287838326 = 5609334349430 := by decide
theorem cert_e1211287838326 : check e1211287838326 [[],[]] .chain = true := by decide
def e1211287849838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211287849838 : Closed e1211287849838 ∧ code e1211287849838 = 5609334360942 := by decide
theorem cert_e1211287849838 : check e1211287849838 [[],[]] .chain = true := by decide
def e1211287849846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211287849846 : Closed e1211287849846 ∧ code e1211287849846 = 5609334360950 := by decide
theorem cert_e1211287849846 : check e1211287849846 [[],[]] .chain = true := by decide
def e1211287849902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211287849902 : Closed e1211287849902 ∧ code e1211287849902 = 5609334361006 := by decide
theorem cert_e1211287849902 : check e1211287849902 [[],[]] .chain = true := by decide
def e1211287849914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211287849914 : Closed e1211287849914 ∧ code e1211287849914 = 5609334361018 := by decide
theorem cert_e1211287849914 : check e1211287849914 [[],[]] .chain = true := by decide
def e1211287849942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211287849942 : Closed e1211287849942 ∧ code e1211287849942 = 5609334361046 := by decide
theorem cert_e1211287849942 : check e1211287849942 [[],[]] .chain = true := by decide
def e1211287849946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211287849946 : Closed e1211287849946 ∧ code e1211287849946 = 5609334361050 := by decide
theorem cert_e1211287849946 : check e1211287849946 [[],[]] .chain = true := by decide
def e1211287850222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211287850222 : Closed e1211287850222 ∧ code e1211287850222 = 5609334361326 := by decide
theorem cert_e1211287850222 : check e1211287850222 [[],[]] .chain = true := by decide
def e1211287850230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211287850230 : Closed e1211287850230 ∧ code e1211287850230 = 5609334361334 := by decide
theorem cert_e1211287850230 : check e1211287850230 [[],[]] .chain = true := by decide
def e1211287850606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211287850606 : Closed e1211287850606 ∧ code e1211287850606 = 5609334361710 := by decide
theorem cert_e1211287850606 : check e1211287850606 [[],[]] .chain = true := by decide
def e1211287850618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211287850618 : Closed e1211287850618 ∧ code e1211287850618 = 5609334361722 := by decide
theorem cert_e1211287850618 : check e1211287850618 [[],[]] .chain = true := by decide
def e1211287850806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211287850806 : Closed e1211287850806 ∧ code e1211287850806 = 5609334361910 := by decide
theorem cert_e1211287850806 : check e1211287850806 [[],[]] .chain = true := by decide
def e1211287850810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211287850810 : Closed e1211287850810 ∧ code e1211287850810 = 5609334361914 := by decide
theorem cert_e1211287850810 : check e1211287850810 [[],[]] .chain = true := by decide
def e1211287856566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211287856566 : Closed e1211287856566 ∧ code e1211287856566 = 5609334367670 := by decide
theorem cert_e1211287856566 : check e1211287856566 [[],[]] .chain = true := by decide
def e1211287856598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211287856598 : Closed e1211287856598 ∧ code e1211287856598 = 5609334367702 := by decide
theorem cert_e1211287856598 : check e1211287856598 [[],[]] .chain = true := by decide
def e1211287856602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211287856602 : Closed e1211287856602 ∧ code e1211287856602 = 5609334367706 := by decide
theorem cert_e1211287856602 : check e1211287856602 [[],[]] .chain = true := by decide
def e1211287856758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211287856758 : Closed e1211287856758 ∧ code e1211287856758 = 5609334367862 := by decide
theorem cert_e1211287856758 : check e1211287856758 [[],[]] .chain = true := by decide
def e1211287856950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211287856950 : Closed e1211287856950 ∧ code e1211287856950 = 5609334368054 := by decide
theorem cert_e1211287856950 : check e1211287856950 [[],[]] .chain = true := by decide
def e1211287856954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211287856954 : Closed e1211287856954 ∧ code e1211287856954 = 5609334368058 := by decide
theorem cert_e1211287856954 : check e1211287856954 [[],[]] .chain = true := by decide
def e1211288193902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211288193902 : Closed e1211288193902 ∧ code e1211288193902 = 5609334705006 := by decide
theorem cert_e1211288193902 : check e1211288193902 [[],[]] .sourceHead = true := by decide
def e1211288193910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211288193910 : Closed e1211288193910 ∧ code e1211288193910 = 5609334705014 := by decide
theorem cert_e1211288193910 : check e1211288193910 [[],[]] .sourceHead = true := by decide
def e1211288193966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211288193966 : Closed e1211288193966 ∧ code e1211288193966 = 5609334705070 := by decide
theorem cert_e1211288193966 : check e1211288193966 [[],[]] .sourceHead = true := by decide
def e1211288193978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211288193978 : Closed e1211288193978 ∧ code e1211288193978 = 5609334705082 := by decide
theorem cert_e1211288193978 : check e1211288193978 [[],[]] .sourceHead = true := by decide
def e1211288194006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211288194006 : Closed e1211288194006 ∧ code e1211288194006 = 5609334705110 := by decide
theorem cert_e1211288194006 : check e1211288194006 [[],[]] .sourceHead = true := by decide
def e1211288194010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211288194010 : Closed e1211288194010 ∧ code e1211288194010 = 5609334705114 := by decide
theorem cert_e1211288194010 : check e1211288194010 [[],[]] .sourceHead = true := by decide
def e1211288194286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211288194286 : Closed e1211288194286 ∧ code e1211288194286 = 5609334705390 := by decide
theorem cert_e1211288194286 : check e1211288194286 [[],[]] .sourceHead = true := by decide
def e1211288194294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211288194294 : Closed e1211288194294 ∧ code e1211288194294 = 5609334705398 := by decide
theorem cert_e1211288194294 : check e1211288194294 [[],[]] .sourceHead = true := by decide
end Blc.Floor42
