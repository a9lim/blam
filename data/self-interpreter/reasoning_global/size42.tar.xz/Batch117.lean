import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205858217402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e1205858217402 : Closed e1205858217402 ∧ code e1205858217402 = 5603904728506 := by decide
def e1205858217434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e1205858217434 : Closed e1205858217434 ∧ code e1205858217434 = 5603904728538 := by decide
def e1205858217658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e1205858217658 : Closed e1205858217658 ∧ code e1205858217658 = 5603904728762 := by decide
def e1205858217706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e1205858217706 : Closed e1205858217706 ∧ code e1205858217706 = 5603904728810 := by decide
def e1205858217818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e1205858217818 : Closed e1205858217818 ∧ code e1205858217818 = 5603904728922 := by decide
def e1205858217834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e1205858217834 : Closed e1205858217834 ∧ code e1205858217834 = 5603904728938 := by decide
def e1205858218938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e1205858218938 : Closed e1205858218938 ∧ code e1205858218938 = 5603904730042 := by decide
def e1205858218970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e1205858218970 : Closed e1205858218970 ∧ code e1205858218970 = 5603904730074 := by decide
def e1205858220474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e1205858220474 : Closed e1205858220474 ∧ code e1205858220474 = 5603904731578 := by decide
def e1205858220522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e1205858220522 : Closed e1205858220522 ∧ code e1205858220522 = 5603904731626 := by decide
def e1205858221274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e1205858221274 : Closed e1205858221274 ∧ code e1205858221274 = 5603904732378 := by decide
def e1205858221290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e1205858221290 : Closed e1205858221290 ∧ code e1205858221290 = 5603904732394 := by decide
def e1205858252514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e1205858252514 : Closed e1205858252514 ∧ code e1205858252514 = 5603904763618 := by decide
theorem cert_e1205858252514 : check e1205858252514 [[],[],[.left]] .smaller = true := by decide
def e1205858252642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e1205858252642 : Closed e1205858252642 ∧ code e1205858252642 = 5603904763746 := by decide
theorem cert_e1205858252642 : check e1205858252642 [[],[],[.left]] .smaller = true := by decide
def e1205858253538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e1205858253538 : Closed e1205858253538 ∧ code e1205858253538 = 5603904764642 := by decide
theorem cert_e1205858253538 : check e1205858253538 [[],[],[.left]] .smaller = true := by decide
def e1205858253730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e1205858253730 : Closed e1205858253730 ∧ code e1205858253730 = 5603904764834 := by decide
theorem cert_e1205858253730 : check e1205858253730 [[],[],[.left]] .smaller = true := by decide
def e1205858254178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e1205858254178 : Closed e1205858254178 ∧ code e1205858254178 = 5603904765282 := by decide
theorem cert_e1205858254178 : check e1205858254178 [[],[],[.left]] .smaller = true := by decide
def e1205858254242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e1205858254242 : Closed e1205858254242 ∧ code e1205858254242 = 5603904765346 := by decide
theorem cert_e1205858254242 : check e1205858254242 [[],[],[.left]] .smaller = true := by decide
def e1205858258658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e1205858258658 : Closed e1205858258658 ∧ code e1205858258658 = 5603904769762 := by decide
theorem cert_e1205858258658 : check e1205858258658 [[],[],[.left]] .smaller = true := by decide
def e1205858258786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e1205858258786 : Closed e1205858258786 ∧ code e1205858258786 = 5603904769890 := by decide
theorem cert_e1205858258786 : check e1205858258786 [[],[],[.left]] .smaller = true := by decide
def e1205858264802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e1205858264802 : Closed e1205858264802 ∧ code e1205858264802 = 5603904775906 := by decide
theorem cert_e1205858264802 : check e1205858264802 [[],[],[.left]] .smaller = true := by decide
def e1205858264994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e1205858264994 : Closed e1205858264994 ∧ code e1205858264994 = 5603904776098 := by decide
theorem cert_e1205858264994 : check e1205858264994 [[],[],[.left]] .smaller = true := by decide
def e1205858268002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e1205858268002 : Closed e1205858268002 ∧ code e1205858268002 = 5603904779106 := by decide
theorem cert_e1205858268002 : check e1205858268002 [[],[],[.left]] .smaller = true := by decide
def e1205858268066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e1205858268066 : Closed e1205858268066 ∧ code e1205858268066 = 5603904779170 := by decide
theorem cert_e1205858268066 : check e1205858268066 [[],[],[.left]] .smaller = true := by decide
def e1205858470766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205858470766 : Closed e1205858470766 ∧ code e1205858470766 = 5603904981870 := by decide
def e1205858470774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205858470774 : Closed e1205858470774 ∧ code e1205858470774 = 5603904981878 := by decide
theorem cert_e1205858470774 : check e1205858470774 [[],[],[.left],[],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e1205858470830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205858470830 : Closed e1205858470830 ∧ code e1205858470830 = 5603904981934 := by decide
theorem cert_e1205858470830 : check e1205858470830 [[],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205858470842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205858470842 : Closed e1205858470842 ∧ code e1205858470842 = 5603904981946 := by decide
theorem cert_e1205858470842 : check e1205858470842 [[],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e1205858470870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205858470870 : Closed e1205858470870 ∧ code e1205858470870 = 5603904981974 := by decide
theorem cert_e1205858470870 : check e1205858470870 [[],[],[.left],[],[.left],[],[.left]] .smaller = true := by decide
def e1205858470874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205858470874 : Closed e1205858470874 ∧ code e1205858470874 = 5603904981978 := by decide
def e1205858471150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205858471150 : Closed e1205858471150 ∧ code e1205858471150 = 5603904982254 := by decide
theorem cert_e1205858471150 : check e1205858471150 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e1205858471158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205858471158 : Closed e1205858471158 ∧ code e1205858471158 = 5603904982262 := by decide
theorem cert_e1205858471158 : check e1205858471158 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e1205858471534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205858471534 : Closed e1205858471534 ∧ code e1205858471534 = 5603904982638 := by decide
theorem cert_e1205858471534 : check e1205858471534 [[],[],[.left],[],[.left],[],[],[],[.under]] .smaller = true := by decide
def e1205858471546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205858471546 : Closed e1205858471546 ∧ code e1205858471546 = 5603904982650 := by decide
theorem cert_e1205858471546 : check e1205858471546 [[],[],[.left],[],[.left],[],[],[]] .smaller = true := by decide
def e1205858471734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205858471734 : Closed e1205858471734 ∧ code e1205858471734 = 5603904982838 := by decide
theorem cert_e1205858471734 : check e1205858471734 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e1205858471738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205858471738 : Closed e1205858471738 ∧ code e1205858471738 = 5603904982842 := by decide
theorem cert_e1205858471738 : check e1205858471738 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e1205859257198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1205859257198 : Closed e1205859257198 ∧ code e1205859257198 = 5603905768302 := by decide
theorem cert_e1205859257198 : check e1205859257198 [[],[],[.left]] .chain = true := by decide
def e1205859257206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1205859257206 : Closed e1205859257206 ∧ code e1205859257206 = 5603905768310 := by decide
theorem cert_e1205859257206 : check e1205859257206 [[],[],[.left]] .chain = true := by decide
def e1205859257262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1205859257262 : Closed e1205859257262 ∧ code e1205859257262 = 5603905768366 := by decide
theorem cert_e1205859257262 : check e1205859257262 [[],[],[.left]] .chain = true := by decide
def e1205859257274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1205859257274 : Closed e1205859257274 ∧ code e1205859257274 = 5603905768378 := by decide
theorem cert_e1205859257274 : check e1205859257274 [[],[],[.left]] .chain = true := by decide
def e1205859257302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1205859257302 : Closed e1205859257302 ∧ code e1205859257302 = 5603905768406 := by decide
theorem cert_e1205859257302 : check e1205859257302 [[],[],[.left]] .chain = true := by decide
def e1205859257306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1205859257306 : Closed e1205859257306 ∧ code e1205859257306 = 5603905768410 := by decide
theorem cert_e1205859257306 : check e1205859257306 [[],[],[.left]] .chain = true := by decide
def e1205859257582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205859257582 : Closed e1205859257582 ∧ code e1205859257582 = 5603905768686 := by decide
theorem cert_e1205859257582 : check e1205859257582 [[],[],[.left]] .chain = true := by decide
def e1205859257590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205859257590 : Closed e1205859257590 ∧ code e1205859257590 = 5603905768694 := by decide
theorem cert_e1205859257590 : check e1205859257590 [[],[],[.left]] .chain = true := by decide
def e1205859257966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205859257966 : Closed e1205859257966 ∧ code e1205859257966 = 5603905769070 := by decide
theorem cert_e1205859257966 : check e1205859257966 [[],[],[.left]] .chain = true := by decide
def e1205859257978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205859257978 : Closed e1205859257978 ∧ code e1205859257978 = 5603905769082 := by decide
theorem cert_e1205859257978 : check e1205859257978 [[],[],[.left]] .chain = true := by decide
def e1205859258166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205859258166 : Closed e1205859258166 ∧ code e1205859258166 = 5603905769270 := by decide
theorem cert_e1205859258166 : check e1205859258166 [[],[],[.left]] .chain = true := by decide
def e1205859258170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205859258170 : Closed e1205859258170 ∧ code e1205859258170 = 5603905769274 := by decide
theorem cert_e1205859258170 : check e1205859258170 [[],[],[.left]] .chain = true := by decide
def e1205862411710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e1205862411710 : Closed e1205862411710 ∧ code e1205862411710 = 5603908922814 := by decide
theorem cert_e1205862411710 : check e1205862411710 [[],[],[]] .smaller = true := by decide
def e1205862411766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e1205862411766 : Closed e1205862411766 ∧ code e1205862411766 = 5603908922870 := by decide
theorem cert_e1205862411766 : check e1205862411766 [[],[],[]] .smaller = true := by decide
def e1205862411966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e1205862411966 : Closed e1205862411966 ∧ code e1205862411966 = 5603908923070 := by decide
theorem cert_e1205862411966 : check e1205862411966 [[],[],[]] .smaller = true := by decide
def e1205862412026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e1205862412026 : Closed e1205862412026 ∧ code e1205862412026 = 5603908923130 := by decide
theorem cert_e1205862412026 : check e1205862412026 [[],[],[]] .smaller = true := by decide
def e1205862412246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e1205862412246 : Closed e1205862412246 ∧ code e1205862412246 = 5603908923350 := by decide
theorem cert_e1205862412246 : check e1205862412246 [[],[],[]] .smaller = true := by decide
def e1205862412250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e1205862412250 : Closed e1205862412250 ∧ code e1205862412250 = 5603908923354 := by decide
theorem cert_e1205862412250 : check e1205862412250 [[],[],[]] .smaller = true := by decide
def e1205862413246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e1205862413246 : Closed e1205862413246 ∧ code e1205862413246 = 5603908924350 := by decide
theorem cert_e1205862413246 : check e1205862413246 [[],[],[]] .smaller = true := by decide
def e1205862413302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e1205862413302 : Closed e1205862413302 ∧ code e1205862413302 = 5603908924406 := by decide
theorem cert_e1205862413302 : check e1205862413302 [[],[],[]] .smaller = true := by decide
def e1205862414782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e1205862414782 : Closed e1205862414782 ∧ code e1205862414782 = 5603908925886 := by decide
theorem cert_e1205862414782 : check e1205862414782 [[],[],[]] .smaller = true := by decide
def e1205862414842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e1205862414842 : Closed e1205862414842 ∧ code e1205862414842 = 5603908925946 := by decide
theorem cert_e1205862414842 : check e1205862414842 [[],[],[]] .smaller = true := by decide
def e1205862416182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205862416182 : Closed e1205862416182 ∧ code e1205862416182 = 5603908927286 := by decide
theorem cert_e1205862416182 : check e1205862416182 [[],[],[]] .smaller = true := by decide
def e1205862416186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205862416186 : Closed e1205862416186 ∧ code e1205862416186 = 5603908927290 := by decide
theorem cert_e1205862416186 : check e1205862416186 [[],[],[]] .smaller = true := by decide
def e1205862444398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1205862444398 : Closed e1205862444398 ∧ code e1205862444398 = 5603908955502 := by decide
theorem cert_e1205862444398 : check e1205862444398 [[],[],[]] .smaller = true := by decide
def e1205862444406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1205862444406 : Closed e1205862444406 ∧ code e1205862444406 = 5603908955510 := by decide
theorem cert_e1205862444406 : check e1205862444406 [[],[],[]] .smaller = true := by decide
def e1205862444462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1205862444462 : Closed e1205862444462 ∧ code e1205862444462 = 5603908955566 := by decide
theorem cert_e1205862444462 : check e1205862444462 [[],[],[]] .smaller = true := by decide
def e1205862444474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1205862444474 : Closed e1205862444474 ∧ code e1205862444474 = 5603908955578 := by decide
theorem cert_e1205862444474 : check e1205862444474 [[],[],[]] .smaller = true := by decide
def e1205862444502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1205862444502 : Closed e1205862444502 ∧ code e1205862444502 = 5603908955606 := by decide
theorem cert_e1205862444502 : check e1205862444502 [[],[],[]] .smaller = true := by decide
def e1205862444506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1205862444506 : Closed e1205862444506 ∧ code e1205862444506 = 5603908955610 := by decide
theorem cert_e1205862444506 : check e1205862444506 [[],[],[]] .smaller = true := by decide
def e1205862444718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1205862444718 : Closed e1205862444718 ∧ code e1205862444718 = 5603908955822 := by decide
theorem cert_e1205862444718 : check e1205862444718 [[],[],[]] .smaller = true := by decide
def e1205862444730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1205862444730 : Closed e1205862444730 ∧ code e1205862444730 = 5603908955834 := by decide
theorem cert_e1205862444730 : check e1205862444730 [[],[],[]] .smaller = true := by decide
def e1205862444778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1205862444778 : Closed e1205862444778 ∧ code e1205862444778 = 5603908955882 := by decide
theorem cert_e1205862444778 : check e1205862444778 [[],[],[]] .smaller = true := by decide
def e1205862444886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1205862444886 : Closed e1205862444886 ∧ code e1205862444886 = 5603908955990 := by decide
theorem cert_e1205862444886 : check e1205862444886 [[],[],[]] .smaller = true := by decide
def e1205862444890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1205862444890 : Closed e1205862444890 ∧ code e1205862444890 = 5603908955994 := by decide
theorem cert_e1205862444890 : check e1205862444890 [[],[],[]] .smaller = true := by decide
def e1205862444906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1205862444906 : Closed e1205862444906 ∧ code e1205862444906 = 5603908956010 := by decide
theorem cert_e1205862444906 : check e1205862444906 [[],[],[]] .smaller = true := by decide
def e1205862445534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1205862445534 : Closed e1205862445534 ∧ code e1205862445534 = 5603908956638 := by decide
theorem cert_e1205862445534 : check e1205862445534 [[],[],[]] .smaller = true := by decide
def e1205862445558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1205862445558 : Closed e1205862445558 ∧ code e1205862445558 = 5603908956662 := by decide
theorem cert_e1205862445558 : check e1205862445558 [[],[],[]] .smaller = true := by decide
def e1205862445934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1205862445934 : Closed e1205862445934 ∧ code e1205862445934 = 5603908957038 := by decide
theorem cert_e1205862445934 : check e1205862445934 [[],[],[]] .smaller = true := by decide
def e1205862445942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1205862445942 : Closed e1205862445942 ∧ code e1205862445942 = 5603908957046 := by decide
theorem cert_e1205862445942 : check e1205862445942 [[],[],[]] .smaller = true := by decide
def e1205862445998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1205862445998 : Closed e1205862445998 ∧ code e1205862445998 = 5603908957102 := by decide
theorem cert_e1205862445998 : check e1205862445998 [[],[],[]] .smaller = true := by decide
def e1205862446010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1205862446010 : Closed e1205862446010 ∧ code e1205862446010 = 5603908957114 := by decide
theorem cert_e1205862446010 : check e1205862446010 [[],[],[]] .smaller = true := by decide
def e1205862446038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1205862446038 : Closed e1205862446038 ∧ code e1205862446038 = 5603908957142 := by decide
theorem cert_e1205862446038 : check e1205862446038 [[],[],[]] .smaller = true := by decide
def e1205862446042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1205862446042 : Closed e1205862446042 ∧ code e1205862446042 = 5603908957146 := by decide
theorem cert_e1205862446042 : check e1205862446042 [[],[],[]] .smaller = true := by decide
def e1205862446318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205862446318 : Closed e1205862446318 ∧ code e1205862446318 = 5603908957422 := by decide
theorem cert_e1205862446318 : check e1205862446318 [[],[],[]] .smaller = true := by decide
def e1205862446326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205862446326 : Closed e1205862446326 ∧ code e1205862446326 = 5603908957430 := by decide
theorem cert_e1205862446326 : check e1205862446326 [[],[],[]] .smaller = true := by decide
def e1205862446654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1205862446654 : Closed e1205862446654 ∧ code e1205862446654 = 5603908957758 := by decide
theorem cert_e1205862446654 : check e1205862446654 [[],[],[]] .smaller = true := by decide
def e1205862446702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205862446702 : Closed e1205862446702 ∧ code e1205862446702 = 5603908957806 := by decide
theorem cert_e1205862446702 : check e1205862446702 [[],[],[]] .smaller = true := by decide
def e1205862446714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205862446714 : Closed e1205862446714 ∧ code e1205862446714 = 5603908957818 := by decide
theorem cert_e1205862446714 : check e1205862446714 [[],[],[]] .smaller = true := by decide
def e1205862446902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205862446902 : Closed e1205862446902 ∧ code e1205862446902 = 5603908958006 := by decide
theorem cert_e1205862446902 : check e1205862446902 [[],[],[]] .smaller = true := by decide
def e1205862446906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205862446906 : Closed e1205862446906 ∧ code e1205862446906 = 5603908958010 := by decide
theorem cert_e1205862446906 : check e1205862446906 [[],[],[]] .smaller = true := by decide
def e1205862446990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1205862446990 : Closed e1205862446990 ∧ code e1205862446990 = 5603908958094 := by decide
theorem cert_e1205862446990 : check e1205862446990 [[],[],[]] .smaller = true := by decide
def e1205862447326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1205862447326 : Closed e1205862447326 ∧ code e1205862447326 = 5603908958430 := by decide
theorem cert_e1205862447326 : check e1205862447326 [[],[],[]] .smaller = true := by decide
def e1205862447354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1205862447354 : Closed e1205862447354 ∧ code e1205862447354 = 5603908958458 := by decide
theorem cert_e1205862447354 : check e1205862447354 [[],[],[]] .smaller = true := by decide
def e1205862447534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1205862447534 : Closed e1205862447534 ∧ code e1205862447534 = 5603908958638 := by decide
theorem cert_e1205862447534 : check e1205862447534 [[],[],[]] .smaller = true := by decide
def e1205862447546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1205862447546 : Closed e1205862447546 ∧ code e1205862447546 = 5603908958650 := by decide
theorem cert_e1205862447546 : check e1205862447546 [[],[],[]] .smaller = true := by decide
def e1205862447594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1205862447594 : Closed e1205862447594 ∧ code e1205862447594 = 5603908958698 := by decide
theorem cert_e1205862447594 : check e1205862447594 [[],[],[]] .smaller = true := by decide
def e1205862447678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1205862447678 : Closed e1205862447678 ∧ code e1205862447678 = 5603908958782 := by decide
theorem cert_e1205862447678 : check e1205862447678 [[],[],[]] .smaller = true := by decide
def e1205862447726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205862447726 : Closed e1205862447726 ∧ code e1205862447726 = 5603908958830 := by decide
theorem cert_e1205862447726 : check e1205862447726 [[],[],[]] .smaller = true := by decide
def e1205862447738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205862447738 : Closed e1205862447738 ∧ code e1205862447738 = 5603908958842 := by decide
theorem cert_e1205862447738 : check e1205862447738 [[],[],[]] .smaller = true := by decide
def e1205862448026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205862448026 : Closed e1205862448026 ∧ code e1205862448026 = 5603908959130 := by decide
theorem cert_e1205862448026 : check e1205862448026 [[],[],[]] .smaller = true := by decide
def e1205862448070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1205862448070 : Closed e1205862448070 ∧ code e1205862448070 = 5603908959174 := by decide
theorem cert_e1205862448070 : check e1205862448070 [[],[],[]] .smaller = true := by decide
def e1205862448342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1205862448342 : Closed e1205862448342 ∧ code e1205862448342 = 5603908959446 := by decide
theorem cert_e1205862448342 : check e1205862448342 [[],[],[]] .smaller = true := by decide
def e1205862448346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1205862448346 : Closed e1205862448346 ∧ code e1205862448346 = 5603908959450 := by decide
theorem cert_e1205862448346 : check e1205862448346 [[],[],[]] .smaller = true := by decide
def e1205862448362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1205862448362 : Closed e1205862448362 ∧ code e1205862448362 = 5603908959466 := by decide
theorem cert_e1205862448362 : check e1205862448362 [[],[],[]] .smaller = true := by decide
def e1205862448438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205862448438 : Closed e1205862448438 ∧ code e1205862448438 = 5603908959542 := by decide
theorem cert_e1205862448438 : check e1205862448438 [[],[],[]] .smaller = true := by decide
def e1205862448442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205862448442 : Closed e1205862448442 ∧ code e1205862448442 = 5603908959546 := by decide
theorem cert_e1205862448442 : check e1205862448442 [[],[],[]] .smaller = true := by decide
def e1205862448538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205862448538 : Closed e1205862448538 ∧ code e1205862448538 = 5603908959642 := by decide
theorem cert_e1205862448538 : check e1205862448538 [[],[],[]] .smaller = true := by decide
def e1205862448694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205862448694 : Closed e1205862448694 ∧ code e1205862448694 = 5603908959798 := by decide
theorem cert_e1205862448694 : check e1205862448694 [[],[],[]] .smaller = true := by decide
def e1205862448698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205862448698 : Closed e1205862448698 ∧ code e1205862448698 = 5603908959802 := by decide
theorem cert_e1205862448698 : check e1205862448698 [[],[],[]] .smaller = true := by decide
def e1205862448782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205862448782 : Closed e1205862448782 ∧ code e1205862448782 = 5603908959886 := by decide
theorem cert_e1205862448782 : check e1205862448782 [[],[],[]] .smaller = true := by decide
def e1205862448838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205862448838 : Closed e1205862448838 ∧ code e1205862448838 = 5603908959942 := by decide
theorem cert_e1205862448838 : check e1205862448838 [[],[],[]] .smaller = true := by decide
def e1205862452078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205862452078 : Closed e1205862452078 ∧ code e1205862452078 = 5603908963182 := by decide
theorem cert_e1205862452078 : check e1205862452078 [[],[],[]] .smaller = true := by decide
def e1205862452086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205862452086 : Closed e1205862452086 ∧ code e1205862452086 = 5603908963190 := by decide
theorem cert_e1205862452086 : check e1205862452086 [[],[],[]] .smaller = true := by decide
def e1205862452142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205862452142 : Closed e1205862452142 ∧ code e1205862452142 = 5603908963246 := by decide
theorem cert_e1205862452142 : check e1205862452142 [[],[],[]] .smaller = true := by decide
def e1205862452154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205862452154 : Closed e1205862452154 ∧ code e1205862452154 = 5603908963258 := by decide
theorem cert_e1205862452154 : check e1205862452154 [[],[],[]] .smaller = true := by decide
def e1205862452182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205862452182 : Closed e1205862452182 ∧ code e1205862452182 = 5603908963286 := by decide
theorem cert_e1205862452182 : check e1205862452182 [[],[],[]] .smaller = true := by decide
def e1205862452186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205862452186 : Closed e1205862452186 ∧ code e1205862452186 = 5603908963290 := by decide
theorem cert_e1205862452186 : check e1205862452186 [[],[],[]] .smaller = true := by decide
def e1205862452462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205862452462 : Closed e1205862452462 ∧ code e1205862452462 = 5603908963566 := by decide
theorem cert_e1205862452462 : check e1205862452462 [[],[],[]] .smaller = true := by decide
def e1205862452470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205862452470 : Closed e1205862452470 ∧ code e1205862452470 = 5603908963574 := by decide
theorem cert_e1205862452470 : check e1205862452470 [[],[],[]] .smaller = true := by decide
def e1205862452798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1205862452798 : Closed e1205862452798 ∧ code e1205862452798 = 5603908963902 := by decide
theorem cert_e1205862452798 : check e1205862452798 [[],[],[]] .smaller = true := by decide
def e1205862452846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205862452846 : Closed e1205862452846 ∧ code e1205862452846 = 5603908963950 := by decide
theorem cert_e1205862452846 : check e1205862452846 [[],[],[]] .smaller = true := by decide
def e1205862452858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205862452858 : Closed e1205862452858 ∧ code e1205862452858 = 5603908963962 := by decide
theorem cert_e1205862452858 : check e1205862452858 [[],[],[]] .smaller = true := by decide
def e1205862453046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205862453046 : Closed e1205862453046 ∧ code e1205862453046 = 5603908964150 := by decide
theorem cert_e1205862453046 : check e1205862453046 [[],[],[]] .smaller = true := by decide
def e1205862453050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205862453050 : Closed e1205862453050 ∧ code e1205862453050 = 5603908964154 := by decide
theorem cert_e1205862453050 : check e1205862453050 [[],[],[]] .smaller = true := by decide
def e1205862453134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1205862453134 : Closed e1205862453134 ∧ code e1205862453134 = 5603908964238 := by decide
theorem cert_e1205862453134 : check e1205862453134 [[],[],[]] .smaller = true := by decide
def e1205862458798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1205862458798 : Closed e1205862458798 ∧ code e1205862458798 = 5603908969902 := by decide
theorem cert_e1205862458798 : check e1205862458798 [[],[],[]] .smaller = true := by decide
def e1205862458810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1205862458810 : Closed e1205862458810 ∧ code e1205862458810 = 5603908969914 := by decide
theorem cert_e1205862458810 : check e1205862458810 [[],[],[]] .smaller = true := by decide
def e1205862458858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1205862458858 : Closed e1205862458858 ∧ code e1205862458858 = 5603908969962 := by decide
theorem cert_e1205862458858 : check e1205862458858 [[],[],[]] .smaller = true := by decide
def e1205862458942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1205862458942 : Closed e1205862458942 ∧ code e1205862458942 = 5603908970046 := by decide
theorem cert_e1205862458942 : check e1205862458942 [[],[],[]] .smaller = true := by decide
def e1205862458990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205862458990 : Closed e1205862458990 ∧ code e1205862458990 = 5603908970094 := by decide
theorem cert_e1205862458990 : check e1205862458990 [[],[],[]] .smaller = true := by decide
def e1205862459002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205862459002 : Closed e1205862459002 ∧ code e1205862459002 = 5603908970106 := by decide
theorem cert_e1205862459002 : check e1205862459002 [[],[],[]] .smaller = true := by decide
def e1205862459290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205862459290 : Closed e1205862459290 ∧ code e1205862459290 = 5603908970394 := by decide
theorem cert_e1205862459290 : check e1205862459290 [[],[],[]] .smaller = true := by decide
def e1205862459334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1205862459334 : Closed e1205862459334 ∧ code e1205862459334 = 5603908970438 := by decide
theorem cert_e1205862459334 : check e1205862459334 [[],[],[]] .smaller = true := by decide
def e1205862462166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1205862462166 : Closed e1205862462166 ∧ code e1205862462166 = 5603908973270 := by decide
theorem cert_e1205862462166 : check e1205862462166 [[],[],[]] .smaller = true := by decide
def e1205862462170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1205862462170 : Closed e1205862462170 ∧ code e1205862462170 = 5603908973274 := by decide
theorem cert_e1205862462170 : check e1205862462170 [[],[],[]] .smaller = true := by decide
def e1205862462186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1205862462186 : Closed e1205862462186 ∧ code e1205862462186 = 5603908973290 := by decide
theorem cert_e1205862462186 : check e1205862462186 [[],[],[]] .smaller = true := by decide
def e1205862462262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205862462262 : Closed e1205862462262 ∧ code e1205862462262 = 5603908973366 := by decide
theorem cert_e1205862462262 : check e1205862462262 [[],[],[]] .smaller = true := by decide
def e1205862462266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205862462266 : Closed e1205862462266 ∧ code e1205862462266 = 5603908973370 := by decide
theorem cert_e1205862462266 : check e1205862462266 [[],[],[]] .smaller = true := by decide
def e1205862462362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205862462362 : Closed e1205862462362 ∧ code e1205862462362 = 5603908973466 := by decide
theorem cert_e1205862462362 : check e1205862462362 [[],[],[]] .smaller = true := by decide
def e1205862463886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1205862463886 : Closed e1205862463886 ∧ code e1205862463886 = 5603908974990 := by decide
theorem cert_e1205862463886 : check e1205862463886 [[],[],[]] .smaller = true := by decide
def e1205862463942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1205862463942 : Closed e1205862463942 ∧ code e1205862463942 = 5603908975046 := by decide
theorem cert_e1205862463942 : check e1205862463942 [[],[],[]] .smaller = true := by decide
def e1205862576494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1205862576494 : Closed e1205862576494 ∧ code e1205862576494 = 5603909087598 := by decide
theorem cert_e1205862576494 : check e1205862576494 [[],[],[]] .smaller = true := by decide
def e1205862576502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1205862576502 : Closed e1205862576502 ∧ code e1205862576502 = 5603909087606 := by decide
theorem cert_e1205862576502 : check e1205862576502 [[],[],[]] .smaller = true := by decide
def e1205862577710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205862577710 : Closed e1205862577710 ∧ code e1205862577710 = 5603909088814 := by decide
theorem cert_e1205862577710 : check e1205862577710 [[],[],[]] .smaller = true := by decide
def e1205862577890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205862577890 : Closed e1205862577890 ∧ code e1205862577890 = 5603909088994 := by decide
theorem cert_e1205862577890 : check e1205862577890 [[],[],[]] .smaller = true := by decide
def e1205862577902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e1205862577902 : Closed e1205862577902 ∧ code e1205862577902 = 5603909089006 := by decide
theorem cert_e1205862577902 : check e1205862577902 [[],[],[]] .smaller = true := by decide
def e1205862577942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205862577942 : Closed e1205862577942 ∧ code e1205862577942 = 5603909089046 := by decide
theorem cert_e1205862577942 : check e1205862577942 [[],[],[]] .smaller = true := by decide
def e1205862578018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205862578018 : Closed e1205862578018 ∧ code e1205862578018 = 5603909089122 := by decide
theorem cert_e1205862578018 : check e1205862578018 [[],[],[]] .smaller = true := by decide
def e1205862578030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e1205862578030 : Closed e1205862578030 ∧ code e1205862578030 = 5603909089134 := by decide
theorem cert_e1205862578030 : check e1205862578030 [[],[],[]] .smaller = true := by decide
def e1205862578038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e1205862578038 : Closed e1205862578038 ∧ code e1205862578038 = 5603909089142 := by decide
theorem cert_e1205862578038 : check e1205862578038 [[],[],[]] .smaller = true := by decide
def e1205862578350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1205862578350 : Closed e1205862578350 ∧ code e1205862578350 = 5603909089454 := by decide
theorem cert_e1205862578350 : check e1205862578350 [[],[],[]] .smaller = true := by decide
def e1205862578362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1205862578362 : Closed e1205862578362 ∧ code e1205862578362 = 5603909089466 := by decide
theorem cert_e1205862578362 : check e1205862578362 [[],[],[]] .smaller = true := by decide
def e1205862578734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1205862578734 : Closed e1205862578734 ∧ code e1205862578734 = 5603909089838 := by decide
theorem cert_e1205862578734 : check e1205862578734 [[],[],[]] .smaller = true := by decide
def e1205862578914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1205862578914 : Closed e1205862578914 ∧ code e1205862578914 = 5603909090018 := by decide
theorem cert_e1205862578914 : check e1205862578914 [[],[],[]] .smaller = true := by decide
def e1205862578926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e1205862578926 : Closed e1205862578926 ∧ code e1205862578926 = 5603909090030 := by decide
theorem cert_e1205862578926 : check e1205862578926 [[],[],[]] .smaller = true := by decide
def e1205862579082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205862579082 : Closed e1205862579082 ∧ code e1205862579082 = 5603909090186 := by decide
theorem cert_e1205862579082 : check e1205862579082 [[],[],[]] .smaller = true := by decide
def e1205862579106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205862579106 : Closed e1205862579106 ∧ code e1205862579106 = 5603909090210 := by decide
theorem cert_e1205862579106 : check e1205862579106 [[],[],[]] .smaller = true := by decide
def e1205862579118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e1205862579118 : Closed e1205862579118 ∧ code e1205862579118 = 5603909090222 := by decide
theorem cert_e1205862579118 : check e1205862579118 [[],[],[]] .smaller = true := by decide
def e1205862579130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e1205862579130 : Closed e1205862579130 ∧ code e1205862579130 = 5603909090234 := by decide
theorem cert_e1205862579130 : check e1205862579130 [[],[],[]] .smaller = true := by decide
def e1205862579286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1205862579286 : Closed e1205862579286 ∧ code e1205862579286 = 5603909090390 := by decide
theorem cert_e1205862579286 : check e1205862579286 [[],[],[]] .smaller = true := by decide
def e1205862579290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1205862579290 : Closed e1205862579290 ∧ code e1205862579290 = 5603909090394 := by decide
theorem cert_e1205862579290 : check e1205862579290 [[],[],[]] .smaller = true := by decide
def e1205862579478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205862579478 : Closed e1205862579478 ∧ code e1205862579478 = 5603909090582 := by decide
theorem cert_e1205862579478 : check e1205862579478 [[],[],[]] .smaller = true := by decide
def e1205862579554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205862579554 : Closed e1205862579554 ∧ code e1205862579554 = 5603909090658 := by decide
theorem cert_e1205862579554 : check e1205862579554 [[],[],[]] .smaller = true := by decide
end Blc.Floor42
