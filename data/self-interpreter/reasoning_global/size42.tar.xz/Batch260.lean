import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211584902382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584902382 : Closed e1211584902382 ∧ code e1211584902382 = 5609631413486 := by decide
theorem cert_e1211584902382 : check e1211584902382 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584902390 : Closed e1211584902390 ∧ code e1211584902390 = 5609631413494 := by decide
theorem cert_e1211584902390 : check e1211584902390 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584902766 : Closed e1211584902766 ∧ code e1211584902766 = 5609631413870 := by decide
theorem cert_e1211584902766 : check e1211584902766 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584902778 : Closed e1211584902778 ∧ code e1211584902778 = 5609631413882 := by decide
theorem cert_e1211584902778 : check e1211584902778 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584902918 : Closed e1211584902918 ∧ code e1211584902918 = 5609631414022 := by decide
theorem cert_e1211584902918 : check e1211584902918 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211584902942 : Closed e1211584902942 ∧ code e1211584902942 = 5609631414046 := by decide
theorem cert_e1211584902942 : check e1211584902942 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584902966 : Closed e1211584902966 ∧ code e1211584902966 = 5609631414070 := by decide
theorem cert_e1211584902966 : check e1211584902966 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584902970 : Closed e1211584902970 ∧ code e1211584902970 = 5609631414074 := by decide
theorem cert_e1211584902970 : check e1211584902970 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1)))))))
theorem wire_e1211584903222 : Closed e1211584903222 ∧ code e1211584903222 = 5609631414326 := by decide
theorem cert_e1211584903222 : check e1211584903222 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2))))))))
theorem wire_e1211584903310 : Closed e1211584903310 ∧ code e1211584903310 = 5609631414414 := by decide
theorem cert_e1211584903310 : check e1211584903310 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0))))))))
theorem wire_e1211584903394 : Closed e1211584903394 ∧ code e1211584903394 = 5609631414498 := by decide
theorem cert_e1211584903394 : check e1211584903394 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e1211584903406 : Closed e1211584903406 ∧ code e1211584903406 = 5609631414510 := by decide
theorem cert_e1211584903406 : check e1211584903406 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e1211584903414 : Closed e1211584903414 ∧ code e1211584903414 = 5609631414518 := by decide
theorem cert_e1211584903414 : check e1211584903414 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e1211584903606 : Closed e1211584903606 ∧ code e1211584903606 = 5609631414710 := by decide
theorem cert_e1211584903606 : check e1211584903606 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e1211584903638 : Closed e1211584903638 ∧ code e1211584903638 = 5609631414742 := by decide
theorem cert_e1211584903638 : check e1211584903638 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e1211584903642 : Closed e1211584903642 ∧ code e1211584903642 = 5609631414746 := by decide
theorem cert_e1211584903642 : check e1211584903642 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211584903798 : Closed e1211584903798 ∧ code e1211584903798 = 5609631414902 := by decide
theorem cert_e1211584903798 : check e1211584903798 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584903942 : Closed e1211584903942 ∧ code e1211584903942 = 5609631415046 := by decide
theorem cert_e1211584903942 : check e1211584903942 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))))
theorem wire_e1211584903966 : Closed e1211584903966 ∧ code e1211584903966 = 5609631415070 := by decide
theorem cert_e1211584903966 : check e1211584903966 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584903990 : Closed e1211584903990 ∧ code e1211584903990 = 5609631415094 := by decide
theorem cert_e1211584903990 : check e1211584903990 [[],[],[],[]] .sourceHead = true := by decide
def e1211584903994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584903994 : Closed e1211584903994 ∧ code e1211584903994 = 5609631415098 := by decide
theorem cert_e1211584903994 : check e1211584903994 [[],[],[],[]] .sourceHead = true := by decide
def e1211584904078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))))
theorem wire_e1211584904078 : Closed e1211584904078 ∧ code e1211584904078 = 5609631415182 := by decide
theorem cert_e1211584904078 : check e1211584904078 [[],[],[],[]] .sourceHead = true := by decide
def e1211584911214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211584911214 : Closed e1211584911214 ∧ code e1211584911214 = 5609631422318 := by decide
theorem cert_e1211584911214 : check e1211584911214 [[],[],[],[]] .sourceHead = true := by decide
def e1211584911222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211584911222 : Closed e1211584911222 ∧ code e1211584911222 = 5609631422326 := by decide
theorem cert_e1211584911222 : check e1211584911222 [[],[],[],[]] .sourceHead = true := by decide
def e1211584911286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211584911286 : Closed e1211584911286 ∧ code e1211584911286 = 5609631422390 := by decide
theorem cert_e1211584911286 : check e1211584911286 [[],[],[],[]] .sourceHead = true := by decide
def e1211584912622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211584912622 : Closed e1211584912622 ∧ code e1211584912622 = 5609631423726 := by decide
theorem cert_e1211584912622 : check e1211584912622 [[],[],[],[]] .sourceHead = true := by decide
def e1211584912630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211584912630 : Closed e1211584912630 ∧ code e1211584912630 = 5609631423734 := by decide
theorem cert_e1211584912630 : check e1211584912630 [[],[],[],[]] .sourceHead = true := by decide
def e1211584913014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211584913014 : Closed e1211584913014 ∧ code e1211584913014 = 5609631424118 := by decide
theorem cert_e1211584913014 : check e1211584913014 [[],[],[],[]] .sourceHead = true := by decide
def e1211584921726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211584921726 : Closed e1211584921726 ∧ code e1211584921726 = 5609631432830 := by decide
theorem cert_e1211584921726 : check e1211584921726 [[],[],[],[]] .sourceHead = true := by decide
def e1211584922590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211584922590 : Closed e1211584922590 ∧ code e1211584922590 = 5609631433694 := by decide
theorem cert_e1211584922590 : check e1211584922590 [[],[],[],[]] .sourceHead = true := by decide
def e1211584922594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211584922594 : Closed e1211584922594 ∧ code e1211584922594 = 5609631433698 := by decide
theorem cert_e1211584922594 : check e1211584922594 [[],[],[],[]] .sourceHead = true := by decide
def e1211584922606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211584922606 : Closed e1211584922606 ∧ code e1211584922606 = 5609631433710 := by decide
theorem cert_e1211584922606 : check e1211584922606 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211584924526 : Closed e1211584924526 ∧ code e1211584924526 = 5609631435630 := by decide
theorem cert_e1211584924526 : check e1211584924526 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211584924534 : Closed e1211584924534 ∧ code e1211584924534 = 5609631435638 := by decide
theorem cert_e1211584924534 : check e1211584924534 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211584924590 : Closed e1211584924590 ∧ code e1211584924590 = 5609631435694 := by decide
theorem cert_e1211584924590 : check e1211584924590 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211584924602 : Closed e1211584924602 ∧ code e1211584924602 = 5609631435706 := by decide
theorem cert_e1211584924602 : check e1211584924602 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211584924630 : Closed e1211584924630 ∧ code e1211584924630 = 5609631435734 := by decide
theorem cert_e1211584924630 : check e1211584924630 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211584924634 : Closed e1211584924634 ∧ code e1211584924634 = 5609631435738 := by decide
theorem cert_e1211584924634 : check e1211584924634 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211584924910 : Closed e1211584924910 ∧ code e1211584924910 = 5609631436014 := by decide
theorem cert_e1211584924910 : check e1211584924910 [[],[],[],[]] .sourceHead = true := by decide
def e1211584924918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211584924918 : Closed e1211584924918 ∧ code e1211584924918 = 5609631436022 := by decide
theorem cert_e1211584924918 : check e1211584924918 [[],[],[],[]] .sourceHead = true := by decide
def e1211584925294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211584925294 : Closed e1211584925294 ∧ code e1211584925294 = 5609631436398 := by decide
theorem cert_e1211584925294 : check e1211584925294 [[],[],[],[]] .sourceHead = true := by decide
def e1211584925306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211584925306 : Closed e1211584925306 ∧ code e1211584925306 = 5609631436410 := by decide
theorem cert_e1211584925306 : check e1211584925306 [[],[],[],[]] .sourceHead = true := by decide
def e1211584925446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211584925446 : Closed e1211584925446 ∧ code e1211584925446 = 5609631436550 := by decide
theorem cert_e1211584925446 : check e1211584925446 [[],[],[],[]] .sourceHead = true := by decide
def e1211584925470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211584925470 : Closed e1211584925470 ∧ code e1211584925470 = 5609631436574 := by decide
theorem cert_e1211584925470 : check e1211584925470 [[],[],[],[]] .sourceHead = true := by decide
def e1211584925494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211584925494 : Closed e1211584925494 ∧ code e1211584925494 = 5609631436598 := by decide
theorem cert_e1211584925494 : check e1211584925494 [[],[],[],[]] .sourceHead = true := by decide
def e1211584925498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211584925498 : Closed e1211584925498 ∧ code e1211584925498 = 5609631436602 := by decide
theorem cert_e1211584925498 : check e1211584925498 [[],[],[],[]] .sourceHead = true := by decide
def e1211584929854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211584929854 : Closed e1211584929854 ∧ code e1211584929854 = 5609631440958 := by decide
theorem cert_e1211584929854 : check e1211584929854 [[],[],[],[]] .sourceHead = true := by decide
def e1211584930274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211584930274 : Closed e1211584930274 ∧ code e1211584930274 = 5609631441378 := by decide
theorem cert_e1211584930274 : check e1211584930274 [[],[],[],[]] .sourceHead = true := by decide
def e1211584930286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211584930286 : Closed e1211584930286 ∧ code e1211584930286 = 5609631441390 := by decide
theorem cert_e1211584930286 : check e1211584930286 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211584931254 : Closed e1211584931254 ∧ code e1211584931254 = 5609631442358 := by decide
theorem cert_e1211584931254 : check e1211584931254 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211584931286 : Closed e1211584931286 ∧ code e1211584931286 = 5609631442390 := by decide
theorem cert_e1211584931286 : check e1211584931286 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211584931290 : Closed e1211584931290 ∧ code e1211584931290 = 5609631442394 := by decide
theorem cert_e1211584931290 : check e1211584931290 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211584931446 : Closed e1211584931446 ∧ code e1211584931446 = 5609631442550 := by decide
theorem cert_e1211584931446 : check e1211584931446 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211584931590 : Closed e1211584931590 ∧ code e1211584931590 = 5609631442694 := by decide
theorem cert_e1211584931590 : check e1211584931590 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211584931614 : Closed e1211584931614 ∧ code e1211584931614 = 5609631442718 := by decide
theorem cert_e1211584931614 : check e1211584931614 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211584931638 : Closed e1211584931638 ∧ code e1211584931638 = 5609631442742 := by decide
theorem cert_e1211584931638 : check e1211584931638 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211584931642 : Closed e1211584931642 ∧ code e1211584931642 = 5609631442746 := by decide
theorem cert_e1211584931642 : check e1211584931642 [[],[],[],[]] .sourceHead = true := by decide
def e1211584931726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211584931726 : Closed e1211584931726 ∧ code e1211584931726 = 5609631442830 := by decide
theorem cert_e1211584931726 : check e1211584931726 [[],[],[],[]] .sourceHead = true := by decide
def e1211584938478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e1211584938478 : Closed e1211584938478 ∧ code e1211584938478 = 5609631449582 := by decide
theorem cert_e1211584938478 : check e1211584938478 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584938490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e1211584938490 : Closed e1211584938490 ∧ code e1211584938490 = 5609631449594 := by decide
theorem cert_e1211584938490 : check e1211584938490 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584939630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584939630 : Closed e1211584939630 ∧ code e1211584939630 = 5609631450734 := by decide
theorem cert_e1211584939630 : check e1211584939630 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .smaller = true := by decide
def e1211584939642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584939642 : Closed e1211584939642 ∧ code e1211584939642 = 5609631450746 := by decide
theorem cert_e1211584939642 : check e1211584939642 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .smaller = true := by decide
def e1211584939806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e1211584939806 : Closed e1211584939806 ∧ code e1211584939806 = 5609631450910 := by decide
theorem cert_e1211584939806 : check e1211584939806 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584939974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e1211584939974 : Closed e1211584939974 ∧ code e1211584939974 = 5609631451078 := by decide
theorem cert_e1211584939974 : check e1211584939974 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584941614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211584941614 : Closed e1211584941614 ∧ code e1211584941614 = 5609631452718 := by decide
theorem cert_e1211584941614 : check e1211584941614 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584941806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e1211584941806 : Closed e1211584941806 ∧ code e1211584941806 = 5609631452910 := by decide
theorem cert_e1211584941806 : check e1211584941806 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211584941814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e1211584941814 : Closed e1211584941814 ∧ code e1211584941814 = 5609631452918 := by decide
theorem cert_e1211584941814 : check e1211584941814 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211584941934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e1211584941934 : Closed e1211584941934 ∧ code e1211584941934 = 5609631453038 := by decide
theorem cert_e1211584941934 : check e1211584941934 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584941946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e1211584941946 : Closed e1211584941946 ∧ code e1211584941946 = 5609631453050 := by decide
private def t_e1211584941946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem cert_e1211584941946 : ¬ IsSelfInterpreter e1211584941946 :=
  wSource (t := t_e1211584941946) (replay_sound (ps := []) (t := e1211584941946) (by decide)) (by decide)
def e1211584941962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e1211584941962 : Closed e1211584941962 ∧ code e1211584941962 = 5609631453066 := by decide
theorem cert_e1211584941962 : check e1211584941962 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584942006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e1211584942006 : Closed e1211584942006 ∧ code e1211584942006 = 5609631453110 := by decide
theorem cert_e1211584942006 : check e1211584942006 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584942010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e1211584942010 : Closed e1211584942010 ∧ code e1211584942010 = 5609631453114 := by decide
private def t_e1211584942010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem cert_e1211584942010 : ¬ IsSelfInterpreter e1211584942010 :=
  wSource (t := t_e1211584942010) (replay_sound (ps := []) (t := e1211584942010) (by decide)) (by decide)
def e1211584942878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211584942878 : Closed e1211584942878 ∧ code e1211584942878 = 5609631453982 := by decide
theorem cert_e1211584942878 : check e1211584942878 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584943046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211584943046 : Closed e1211584943046 ∧ code e1211584943046 = 5609631454150 := by decide
theorem cert_e1211584943046 : check e1211584943046 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1211584944190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211584944190 : Closed e1211584944190 ∧ code e1211584944190 = 5609631455294 := by decide
theorem cert_e1211584944190 : check e1211584944190 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584944610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211584944610 : Closed e1211584944610 ∧ code e1211584944610 = 5609631455714 := by decide
theorem cert_e1211584944610 : check e1211584944610 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584944622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211584944622 : Closed e1211584944622 ∧ code e1211584944622 = 5609631455726 := by decide
theorem cert_e1211584944622 : check e1211584944622 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e1211584945678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e1211584945678 : Closed e1211584945678 ∧ code e1211584945678 = 5609631456782 := by decide
theorem cert_e1211584945678 : check e1211584945678 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584945762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1211584945762 : Closed e1211584945762 ∧ code e1211584945762 = 5609631456866 := by decide
theorem cert_e1211584945762 : check e1211584945762 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211584945774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584945774 : Closed e1211584945774 ∧ code e1211584945774 = 5609631456878 := by decide
theorem cert_e1211584945774 : check e1211584945774 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584945786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584945786 : Closed e1211584945786 ∧ code e1211584945786 = 5609631456890 := by decide
theorem cert_e1211584945786 : check e1211584945786 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584949614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211584949614 : Closed e1211584949614 ∧ code e1211584949614 = 5609631460718 := by decide
theorem cert_e1211584949614 : check e1211584949614 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584949622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211584949622 : Closed e1211584949622 ∧ code e1211584949622 = 5609631460726 := by decide
theorem cert_e1211584949622 : check e1211584949622 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584949678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211584949678 : Closed e1211584949678 ∧ code e1211584949678 = 5609631460782 := by decide
theorem cert_e1211584949678 : check e1211584949678 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584949690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211584949690 : Closed e1211584949690 ∧ code e1211584949690 = 5609631460794 := by decide
theorem cert_e1211584949690 : check e1211584949690 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584949718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211584949718 : Closed e1211584949718 ∧ code e1211584949718 = 5609631460822 := by decide
theorem cert_e1211584949718 : check e1211584949718 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584949722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211584949722 : Closed e1211584949722 ∧ code e1211584949722 = 5609631460826 := by decide
theorem cert_e1211584949722 : check e1211584949722 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584949934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e1211584949934 : Closed e1211584949934 ∧ code e1211584949934 = 5609631461038 := by decide
theorem cert_e1211584949934 : check e1211584949934 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584949946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e1211584949946 : Closed e1211584949946 ∧ code e1211584949946 = 5609631461050 := by decide
theorem cert_e1211584949946 : check e1211584949946 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584949994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e1211584949994 : Closed e1211584949994 ∧ code e1211584949994 = 5609631461098 := by decide
private def t_e1211584949994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem cert_e1211584949994 : ¬ IsSelfInterpreter e1211584949994 :=
  wSource (t := t_e1211584949994) (replay_sound (ps := []) (t := e1211584949994) (by decide)) (by decide)
def e1211584950102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e1211584950102 : Closed e1211584950102 ∧ code e1211584950102 = 5609631461206 := by decide
theorem cert_e1211584950102 : check e1211584950102 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584950106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e1211584950106 : Closed e1211584950106 ∧ code e1211584950106 = 5609631461210 := by decide
theorem cert_e1211584950106 : check e1211584950106 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584950122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e1211584950122 : Closed e1211584950122 ∧ code e1211584950122 = 5609631461226 := by decide
private def t_e1211584950122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem cert_e1211584950122 : ¬ IsSelfInterpreter e1211584950122 :=
  wSource (t := t_e1211584950122) (replay_sound (ps := []) (t := e1211584950122) (by decide)) (by decide)
def e1211584950382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211584950382 : Closed e1211584950382 ∧ code e1211584950382 = 5609631461486 := by decide
theorem cert_e1211584950382 : check e1211584950382 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584950558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211584950558 : Closed e1211584950558 ∧ code e1211584950558 = 5609631461662 := by decide
theorem cert_e1211584950558 : check e1211584950558 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584950754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211584950754 : Closed e1211584950754 ∧ code e1211584950754 = 5609631461858 := by decide
theorem cert_e1211584950754 : check e1211584950754 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584950766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211584950766 : Closed e1211584950766 ∧ code e1211584950766 = 5609631461870 := by decide
theorem cert_e1211584950766 : check e1211584950766 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211584951150 : Closed e1211584951150 ∧ code e1211584951150 = 5609631462254 := by decide
theorem cert_e1211584951150 : check e1211584951150 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211584951158 : Closed e1211584951158 ∧ code e1211584951158 = 5609631462262 := by decide
theorem cert_e1211584951158 : check e1211584951158 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211584951214 : Closed e1211584951214 ∧ code e1211584951214 = 5609631462318 := by decide
theorem cert_e1211584951214 : check e1211584951214 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211584951226 : Closed e1211584951226 ∧ code e1211584951226 = 5609631462330 := by decide
theorem cert_e1211584951226 : check e1211584951226 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211584951254 : Closed e1211584951254 ∧ code e1211584951254 = 5609631462358 := by decide
theorem cert_e1211584951254 : check e1211584951254 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211584951258 : Closed e1211584951258 ∧ code e1211584951258 = 5609631462362 := by decide
theorem cert_e1211584951258 : check e1211584951258 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584951534 : Closed e1211584951534 ∧ code e1211584951534 = 5609631462638 := by decide
theorem cert_e1211584951534 : check e1211584951534 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584951542 : Closed e1211584951542 ∧ code e1211584951542 = 5609631462646 := by decide
theorem cert_e1211584951542 : check e1211584951542 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584951918 : Closed e1211584951918 ∧ code e1211584951918 = 5609631463022 := by decide
theorem cert_e1211584951918 : check e1211584951918 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584951930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584951930 : Closed e1211584951930 ∧ code e1211584951930 = 5609631463034 := by decide
theorem cert_e1211584951930 : check e1211584951930 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584952070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584952070 : Closed e1211584952070 ∧ code e1211584952070 = 5609631463174 := by decide
theorem cert_e1211584952070 : check e1211584952070 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584952094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211584952094 : Closed e1211584952094 ∧ code e1211584952094 = 5609631463198 := by decide
theorem cert_e1211584952094 : check e1211584952094 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584952118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584952118 : Closed e1211584952118 ∧ code e1211584952118 = 5609631463222 := by decide
theorem cert_e1211584952118 : check e1211584952118 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584952122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584952122 : Closed e1211584952122 ∧ code e1211584952122 = 5609631463226 := by decide
theorem cert_e1211584952122 : check e1211584952122 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584952750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e1211584952750 : Closed e1211584952750 ∧ code e1211584952750 = 5609631463854 := by decide
theorem cert_e1211584952750 : check e1211584952750 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584952762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e1211584952762 : Closed e1211584952762 ∧ code e1211584952762 = 5609631463866 := by decide
theorem cert_e1211584952762 : check e1211584952762 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584952810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e1211584952810 : Closed e1211584952810 ∧ code e1211584952810 = 5609631463914 := by decide
theorem cert_e1211584952810 : check e1211584952810 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584952942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584952942 : Closed e1211584952942 ∧ code e1211584952942 = 5609631464046 := by decide
theorem cert_e1211584952942 : check e1211584952942 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584952954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584952954 : Closed e1211584952954 ∧ code e1211584952954 = 5609631464058 := by decide
theorem cert_e1211584952954 : check e1211584952954 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584953242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211584953242 : Closed e1211584953242 ∧ code e1211584953242 = 5609631464346 := by decide
private def t_e1211584953242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem cert_e1211584953242 : ¬ IsSelfInterpreter e1211584953242 :=
  wSource (t := t_e1211584953242) (replay_sound (ps := []) (t := e1211584953242) (by decide)) (by decide)
def e1211584953370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)))))))
theorem wire_e1211584953370 : Closed e1211584953370 ∧ code e1211584953370 = 5609631464474 := by decide
theorem cert_e1211584953370 : check e1211584953370 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e1211584953414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))))))))
theorem wire_e1211584953414 : Closed e1211584953414 ∧ code e1211584953414 = 5609631464518 := by decide
theorem cert_e1211584953414 : check e1211584953414 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e1211584953442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))))))))
theorem wire_e1211584953442 : Closed e1211584953442 ∧ code e1211584953442 = 5609631464546 := by decide
theorem cert_e1211584953442 : check e1211584953442 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e1211584953454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211584953454 : Closed e1211584953454 ∧ code e1211584953454 = 5609631464558 := by decide
theorem cert_e1211584953454 : check e1211584953454 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211584953466 : Closed e1211584953466 ∧ code e1211584953466 = 5609631464570 := by decide
def e1211584953558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e1211584953558 : Closed e1211584953558 ∧ code e1211584953558 = 5609631464662 := by decide
theorem cert_e1211584953558 : check e1211584953558 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e1211584953562 : Closed e1211584953562 ∧ code e1211584953562 = 5609631464666 := by decide
theorem cert_e1211584953562 : check e1211584953562 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e1211584953578 : Closed e1211584953578 ∧ code e1211584953578 = 5609631464682 := by decide
theorem cert_e1211584953578 : check e1211584953578 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584953606 : Closed e1211584953606 ∧ code e1211584953606 = 5609631464710 := by decide
theorem cert_e1211584953606 : check e1211584953606 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e1211584953630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211584953630 : Closed e1211584953630 ∧ code e1211584953630 = 5609631464734 := by decide
theorem cert_e1211584953630 : check e1211584953630 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584953654 : Closed e1211584953654 ∧ code e1211584953654 = 5609631464758 := by decide
theorem cert_e1211584953654 : check e1211584953654 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584953658 : Closed e1211584953658 ∧ code e1211584953658 = 5609631464762 := by decide
theorem cert_e1211584953658 : check e1211584953658 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584953754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211584953754 : Closed e1211584953754 ∧ code e1211584953754 = 5609631464858 := by decide
private def t_e1211584953754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem cert_e1211584953754 : ¬ IsSelfInterpreter e1211584953754 :=
  wSource (t := t_e1211584953754) (replay_sound (ps := []) (t := e1211584953754) (by decide)) (by decide)
def e1211584953798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211584953798 : Closed e1211584953798 ∧ code e1211584953798 = 5609631464902 := by decide
private def t_e1211584953798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem cert_e1211584953798 : ¬ IsSelfInterpreter e1211584953798 :=
  wSource (t := t_e1211584953798) (replay_sound (ps := []) (t := e1211584953798) (by decide)) (by decide)
def e1211584954494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 5))))))))))
theorem wire_e1211584954494 : Closed e1211584954494 ∧ code e1211584954494 = 5609631465598 := by decide
theorem cert_e1211584954494 : check e1211584954494 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584955358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211584955358 : Closed e1211584955358 ∧ code e1211584955358 = 5609631466462 := by decide
theorem cert_e1211584955358 : check e1211584955358 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584955362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e1211584955362 : Closed e1211584955362 ∧ code e1211584955362 = 5609631466466 := by decide
theorem cert_e1211584955362 : check e1211584955362 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584955374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211584955374 : Closed e1211584955374 ∧ code e1211584955374 = 5609631466478 := by decide
theorem cert_e1211584955374 : check e1211584955374 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211584957294 : Closed e1211584957294 ∧ code e1211584957294 = 5609631468398 := by decide
theorem cert_e1211584957294 : check e1211584957294 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211584957302 : Closed e1211584957302 ∧ code e1211584957302 = 5609631468406 := by decide
theorem cert_e1211584957302 : check e1211584957302 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211584957358 : Closed e1211584957358 ∧ code e1211584957358 = 5609631468462 := by decide
theorem cert_e1211584957358 : check e1211584957358 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211584957370 : Closed e1211584957370 ∧ code e1211584957370 = 5609631468474 := by decide
theorem cert_e1211584957370 : check e1211584957370 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211584957398 : Closed e1211584957398 ∧ code e1211584957398 = 5609631468502 := by decide
theorem cert_e1211584957398 : check e1211584957398 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211584957402 : Closed e1211584957402 ∧ code e1211584957402 = 5609631468506 := by decide
theorem cert_e1211584957402 : check e1211584957402 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211584957678 : Closed e1211584957678 ∧ code e1211584957678 = 5609631468782 := by decide
theorem cert_e1211584957678 : check e1211584957678 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584957686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211584957686 : Closed e1211584957686 ∧ code e1211584957686 = 5609631468790 := by decide
theorem cert_e1211584957686 : check e1211584957686 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584958062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211584958062 : Closed e1211584958062 ∧ code e1211584958062 = 5609631469166 := by decide
theorem cert_e1211584958062 : check e1211584958062 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584958074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211584958074 : Closed e1211584958074 ∧ code e1211584958074 = 5609631469178 := by decide
theorem cert_e1211584958074 : check e1211584958074 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584958214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))))))))
theorem wire_e1211584958214 : Closed e1211584958214 ∧ code e1211584958214 = 5609631469318 := by decide
theorem cert_e1211584958214 : check e1211584958214 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584958238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e1211584958238 : Closed e1211584958238 ∧ code e1211584958238 = 5609631469342 := by decide
theorem cert_e1211584958238 : check e1211584958238 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584958262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211584958262 : Closed e1211584958262 ∧ code e1211584958262 = 5609631469366 := by decide
theorem cert_e1211584958262 : check e1211584958262 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584958266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211584958266 : Closed e1211584958266 ∧ code e1211584958266 = 5609631469370 := by decide
theorem cert_e1211584958266 : check e1211584958266 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211584963038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211584963038 : Closed e1211584963038 ∧ code e1211584963038 = 5609631474142 := by decide
private def t_e1211584963038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem cert_e1211584963038 : ¬ IsSelfInterpreter e1211584963038 :=
  wSource (t := t_e1211584963038) (replay_sound (ps := []) (t := e1211584963038) (by decide)) (by decide)
def e1211584963062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211584963062 : Closed e1211584963062 ∧ code e1211584963062 = 5609631474166 := by decide
private def t_e1211584963062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem cert_e1211584963062 : ¬ IsSelfInterpreter e1211584963062 :=
  wSource (t := t_e1211584963062) (replay_sound (ps := []) (t := e1211584963062) (by decide)) (by decide)
def e1211584964014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211584964014 : Closed e1211584964014 ∧ code e1211584964014 = 5609631475118 := by decide
private def t_e1211584964014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem cert_e1211584964014 : ¬ IsSelfInterpreter e1211584964014 :=
  wSource (t := t_e1211584964014) (replay_sound (ps := []) (t := e1211584964014) (by decide)) (by decide)
def e1211584964026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211584964026 : Closed e1211584964026 ∧ code e1211584964026 = 5609631475130 := by decide
private def t_e1211584964026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem cert_e1211584964026 : ¬ IsSelfInterpreter e1211584964026 :=
  wSource (t := t_e1211584964026) (replay_sound (ps := []) (t := e1211584964026) (by decide)) (by decide)
def e1211584964074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211584964074 : Closed e1211584964074 ∧ code e1211584964074 = 5609631475178 := by decide
private def t_e1211584964074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem cert_e1211584964074 : ¬ IsSelfInterpreter e1211584964074 :=
  wSource (t := t_e1211584964074) (replay_sound (ps := []) (t := e1211584964074) (by decide)) (by decide)
def e1211584964206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211584964206 : Closed e1211584964206 ∧ code e1211584964206 = 5609631475310 := by decide
private def t_e1211584964206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211584964206 : ¬ IsSelfInterpreter e1211584964206 :=
  wSource (t := t_e1211584964206) (replay_sound (ps := []) (t := e1211584964206) (by decide)) (by decide)
def e1211584964218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211584964218 : Closed e1211584964218 ∧ code e1211584964218 = 5609631475322 := by decide
private def t_e1211584964218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211584964218 : ¬ IsSelfInterpreter e1211584964218 :=
  wSource (t := t_e1211584964218) (replay_sound (ps := []) (t := e1211584964218) (by decide)) (by decide)
def e1211584964506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211584964506 : Closed e1211584964506 ∧ code e1211584964506 = 5609631475610 := by decide
private def t_e1211584964506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211584964506 : ¬ IsSelfInterpreter e1211584964506 :=
  wSource (t := t_e1211584964506) (replay_sound (ps := []) (t := e1211584964506) (by decide)) (by decide)
def e1211584966686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211584966686 : Closed e1211584966686 ∧ code e1211584966686 = 5609631477790 := by decide
private def t_e1211584966686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 3))))))))))
theorem cert_e1211584966686 : ¬ IsSelfInterpreter e1211584966686 :=
  wSource (t := t_e1211584966686) (replay_sound (ps := []) (t := e1211584966686) (by decide)) (by decide)
def e1211584966882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211584966882 : Closed e1211584966882 ∧ code e1211584966882 = 5609631477986 := by decide
private def t_e1211584966882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem cert_e1211584966882 : ¬ IsSelfInterpreter e1211584966882 :=
  wSource (t := t_e1211584966882) (replay_sound (ps := []) (t := e1211584966882) (by decide)) (by decide)
def e1211584966894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211584966894 : Closed e1211584966894 ∧ code e1211584966894 = 5609631477998 := by decide
private def t_e1211584966894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem cert_e1211584966894 : ¬ IsSelfInterpreter e1211584966894 :=
  wSource (t := t_e1211584966894) (replay_sound (ps := []) (t := e1211584966894) (by decide)) (by decide)
end Blc.Floor42
