import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182443742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182443742 : Closed e1211182443742 ∧ code e1211182443742 = 5609228954846 := by decide
theorem cert_e1211182443742 : check e1211182443742 [[],[]] .smaller = true := by decide
def e1211182443758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182443758 : Closed e1211182443758 ∧ code e1211182443758 = 5609228954862 := by decide
theorem cert_e1211182443758 : check e1211182443758 [[],[]] .smaller = true := by decide
def e1211182443766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182443766 : Closed e1211182443766 ∧ code e1211182443766 = 5609228954870 := by decide
theorem cert_e1211182443766 : check e1211182443766 [[],[]] .smaller = true := by decide
def e1211182443770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182443770 : Closed e1211182443770 ∧ code e1211182443770 = 5609228954874 := by decide
theorem cert_e1211182443770 : check e1211182443770 [[],[]] .smaller = true := by decide
def e1211182444094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 4))))))))))
theorem wire_e1211182444094 : Closed e1211182444094 ∧ code e1211182444094 = 5609228955198 := by decide
theorem cert_e1211182444094 : check e1211182444094 [[],[]] .smaller = true := by decide
def e1211182444150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182444150 : Closed e1211182444150 ∧ code e1211182444150 = 5609228955254 := by decide
theorem cert_e1211182444150 : check e1211182444150 [[],[]] .smaller = true := by decide
def e1211182444318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 3))))))))))
theorem wire_e1211182444318 : Closed e1211182444318 ∧ code e1211182444318 = 5609228955422 := by decide
theorem cert_e1211182444318 : check e1211182444318 [[],[]] .smaller = true := by decide
def e1211182444342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182444342 : Closed e1211182444342 ∧ code e1211182444342 = 5609228955446 := by decide
theorem cert_e1211182444342 : check e1211182444342 [[],[]] .smaller = true := by decide
def e1211182444346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182444346 : Closed e1211182444346 ∧ code e1211182444346 = 5609228955450 := by decide
theorem cert_e1211182444346 : check e1211182444346 [[],[]] .smaller = true := by decide
def e1211182444430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.lam (.var 2))))))))))
theorem wire_e1211182444430 : Closed e1211182444430 ∧ code e1211182444430 = 5609228955534 := by decide
theorem cert_e1211182444430 : check e1211182444430 [[],[]] .three = true := by decide
def e1211182444990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e1211182444990 : Closed e1211182444990 ∧ code e1211182444990 = 5609228956094 := by decide
theorem cert_e1211182444990 : check e1211182444990 [[],[]] .three = true := by decide
def e1211182445022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e1211182445022 : Closed e1211182445022 ∧ code e1211182445022 = 5609228956126 := by decide
theorem cert_e1211182445022 : check e1211182445022 [[],[]] .smaller = true := by decide
def e1211182445038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2)))))))))
theorem wire_e1211182445038 : Closed e1211182445038 ∧ code e1211182445038 = 5609228956142 := by decide
theorem cert_e1211182445038 : check e1211182445038 [[],[]] .smaller = true := by decide
def e1211182445046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e1211182445046 : Closed e1211182445046 ∧ code e1211182445046 = 5609228956150 := by decide
theorem cert_e1211182445046 : check e1211182445046 [[],[]] .smaller = true := by decide
def e1211182445050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e1211182445050 : Closed e1211182445050 ∧ code e1211182445050 = 5609228956154 := by decide
theorem cert_e1211182445050 : check e1211182445050 [[],[]] .three = true := by decide
def e1211182445406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e1211182445406 : Closed e1211182445406 ∧ code e1211182445406 = 5609228956510 := by decide
theorem cert_e1211182445406 : check e1211182445406 [[],[]] .smaller = true := by decide
def e1211182445422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e1211182445422 : Closed e1211182445422 ∧ code e1211182445422 = 5609228956526 := by decide
theorem cert_e1211182445422 : check e1211182445422 [[],[]] .smaller = true := by decide
def e1211182445430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e1211182445430 : Closed e1211182445430 ∧ code e1211182445430 = 5609228956534 := by decide
theorem cert_e1211182445430 : check e1211182445430 [[],[]] .smaller = true := by decide
def e1211182445434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e1211182445434 : Closed e1211182445434 ∧ code e1211182445434 = 5609228956538 := by decide
theorem cert_e1211182445434 : check e1211182445434 [[],[]] .smaller = true := by decide
def e1211182445486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e1211182445486 : Closed e1211182445486 ∧ code e1211182445486 = 5609228956590 := by decide
theorem cert_e1211182445486 : check e1211182445486 [[],[]] .smaller = true := by decide
def e1211182445498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e1211182445498 : Closed e1211182445498 ∧ code e1211182445498 = 5609228956602 := by decide
theorem cert_e1211182445498 : check e1211182445498 [[],[]] .smaller = true := by decide
def e1211182445526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e1211182445526 : Closed e1211182445526 ∧ code e1211182445526 = 5609228956630 := by decide
theorem cert_e1211182445526 : check e1211182445526 [[],[]] .smaller = true := by decide
def e1211182445530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e1211182445530 : Closed e1211182445530 ∧ code e1211182445530 = 5609228956634 := by decide
theorem cert_e1211182445530 : check e1211182445530 [[],[]] .smaller = true := by decide
def e1211182445546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e1211182445546 : Closed e1211182445546 ∧ code e1211182445546 = 5609228956650 := by decide
theorem cert_e1211182445546 : check e1211182445546 [[],[]] .smaller = true := by decide
def e1211182445694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e1211182445694 : Closed e1211182445694 ∧ code e1211182445694 = 5609228956798 := by decide
theorem cert_e1211182445694 : check e1211182445694 [[],[]] .three = true := by decide
def e1211182445790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211182445790 : Closed e1211182445790 ∧ code e1211182445790 = 5609228956894 := by decide
theorem cert_e1211182445790 : check e1211182445790 [[],[]] .smaller = true := by decide
def e1211182445806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182445806 : Closed e1211182445806 ∧ code e1211182445806 = 5609228956910 := by decide
theorem cert_e1211182445806 : check e1211182445806 [[],[]] .smaller = true := by decide
def e1211182445814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182445814 : Closed e1211182445814 ∧ code e1211182445814 = 5609228956918 := by decide
theorem cert_e1211182445814 : check e1211182445814 [[],[]] .smaller = true := by decide
def e1211182445818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211182445818 : Closed e1211182445818 ∧ code e1211182445818 = 5609228956922 := by decide
theorem cert_e1211182445818 : check e1211182445818 [[],[]] .smaller = true := by decide
def e1211182446142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e1211182446142 : Closed e1211182446142 ∧ code e1211182446142 = 5609228957246 := by decide
theorem cert_e1211182446142 : check e1211182446142 [[],[]] .smaller = true := by decide
def e1211182446190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182446190 : Closed e1211182446190 ∧ code e1211182446190 = 5609228957294 := by decide
theorem cert_e1211182446190 : check e1211182446190 [[],[]] .smaller = true := by decide
def e1211182446202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182446202 : Closed e1211182446202 ∧ code e1211182446202 = 5609228957306 := by decide
theorem cert_e1211182446202 : check e1211182446202 [[],[]] .smaller = true := by decide
def e1211182446366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3))))))))))
theorem wire_e1211182446366 : Closed e1211182446366 ∧ code e1211182446366 = 5609228957470 := by decide
theorem cert_e1211182446366 : check e1211182446366 [[],[]] .smaller = true := by decide
def e1211182446390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182446390 : Closed e1211182446390 ∧ code e1211182446390 = 5609228957494 := by decide
theorem cert_e1211182446390 : check e1211182446390 [[],[]] .smaller = true := by decide
def e1211182446394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182446394 : Closed e1211182446394 ∧ code e1211182446394 = 5609228957498 := by decide
theorem cert_e1211182446394 : check e1211182446394 [[],[]] .smaller = true := by decide
def e1211182446478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e1211182446478 : Closed e1211182446478 ∧ code e1211182446478 = 5609228957582 := by decide
theorem cert_e1211182446478 : check e1211182446478 [[],[]] .smaller = true := by decide
def e1211182446490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182446490 : Closed e1211182446490 ∧ code e1211182446490 = 5609228957594 := by decide
theorem cert_e1211182446490 : check e1211182446490 [[],[]] .smaller = true := by decide
def e1211182446534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e1211182446534 : Closed e1211182446534 ∧ code e1211182446534 = 5609228957638 := by decide
theorem cert_e1211182446534 : check e1211182446534 [[],[]] .three = true := by decide
def e1211182446814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e1211182446814 : Closed e1211182446814 ∧ code e1211182446814 = 5609228957918 := by decide
theorem cert_e1211182446814 : check e1211182446814 [[],[]] .smaller = true := by decide
def e1211182446830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e1211182446830 : Closed e1211182446830 ∧ code e1211182446830 = 5609228957934 := by decide
theorem cert_e1211182446830 : check e1211182446830 [[],[]] .smaller = true := by decide
def e1211182446838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e1211182446838 : Closed e1211182446838 ∧ code e1211182446838 = 5609228957942 := by decide
theorem cert_e1211182446838 : check e1211182446838 [[],[]] .smaller = true := by decide
def e1211182446842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e1211182446842 : Closed e1211182446842 ∧ code e1211182446842 = 5609228957946 := by decide
theorem cert_e1211182446842 : check e1211182446842 [[],[]] .smaller = true := by decide
def e1211182447030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e1211182447030 : Closed e1211182447030 ∧ code e1211182447030 = 5609228958134 := by decide
theorem cert_e1211182447030 : check e1211182447030 [[],[]] .smaller = true := by decide
def e1211182447062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e1211182447062 : Closed e1211182447062 ∧ code e1211182447062 = 5609228958166 := by decide
theorem cert_e1211182447062 : check e1211182447062 [[],[]] .smaller = true := by decide
def e1211182447066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e1211182447066 : Closed e1211182447066 ∧ code e1211182447066 = 5609228958170 := by decide
theorem cert_e1211182447066 : check e1211182447066 [[],[]] .smaller = true := by decide
def e1211182447166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e1211182447166 : Closed e1211182447166 ∧ code e1211182447166 = 5609228958270 := by decide
theorem cert_e1211182447166 : check e1211182447166 [[],[]] .smaller = true := by decide
def e1211182447222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182447222 : Closed e1211182447222 ∧ code e1211182447222 = 5609228958326 := by decide
theorem cert_e1211182447222 : check e1211182447222 [[],[]] .smaller = true := by decide
def e1211182447390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e1211182447390 : Closed e1211182447390 ∧ code e1211182447390 = 5609228958494 := by decide
theorem cert_e1211182447390 : check e1211182447390 [[],[]] .smaller = true := by decide
def e1211182447414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182447414 : Closed e1211182447414 ∧ code e1211182447414 = 5609228958518 := by decide
theorem cert_e1211182447414 : check e1211182447414 [[],[]] .smaller = true := by decide
def e1211182447418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182447418 : Closed e1211182447418 ∧ code e1211182447418 = 5609228958522 := by decide
theorem cert_e1211182447418 : check e1211182447418 [[],[]] .smaller = true := by decide
def e1211182447502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e1211182447502 : Closed e1211182447502 ∧ code e1211182447502 = 5609228958606 := by decide
theorem cert_e1211182447502 : check e1211182447502 [[],[]] .smaller = true := by decide
def e1211182447550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 4)))))))))
theorem wire_e1211182447550 : Closed e1211182447550 ∧ code e1211182447550 = 5609228958654 := by decide
theorem cert_e1211182447550 : check e1211182447550 [[],[]] .three = true := by decide
def e1211182447558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e1211182447558 : Closed e1211182447558 ∧ code e1211182447558 = 5609228958662 := by decide
theorem cert_e1211182447558 : check e1211182447558 [[],[]] .smaller = true := by decide
def e1211182447582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 3)))))))))
theorem wire_e1211182447582 : Closed e1211182447582 ∧ code e1211182447582 = 5609228958686 := by decide
theorem cert_e1211182447582 : check e1211182447582 [[],[]] .smaller = true := by decide
def e1211182447598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 4)) (.var 2)))))))))
theorem wire_e1211182447598 : Closed e1211182447598 ∧ code e1211182447598 = 5609228958702 := by decide
theorem cert_e1211182447598 : check e1211182447598 [[],[]] .three = true := by decide
def e1211182447726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e1211182447726 : Closed e1211182447726 ∧ code e1211182447726 = 5609228958830 := by decide
theorem cert_e1211182447726 : check e1211182447726 [[],[]] .smaller = true := by decide
def e1211182447734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e1211182447734 : Closed e1211182447734 ∧ code e1211182447734 = 5609228958838 := by decide
theorem cert_e1211182447734 : check e1211182447734 [[],[]] .smaller = true := by decide
def e1211182447738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e1211182447738 : Closed e1211182447738 ∧ code e1211182447738 = 5609228958842 := by decide
theorem cert_e1211182447738 : check e1211182447738 [[],[]] .smaller = true := by decide
def e1211182447830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e1211182447830 : Closed e1211182447830 ∧ code e1211182447830 = 5609228958934 := by decide
theorem cert_e1211182447830 : check e1211182447830 [[],[]] .smaller = true := by decide
def e1211182447834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e1211182447834 : Closed e1211182447834 ∧ code e1211182447834 = 5609228958938 := by decide
theorem cert_e1211182447834 : check e1211182447834 [[],[]] .smaller = true := by decide
def e1211182447850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e1211182447850 : Closed e1211182447850 ∧ code e1211182447850 = 5609228958954 := by decide
theorem cert_e1211182447850 : check e1211182447850 [[],[]] .smaller = true := by decide
def e1211182447902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e1211182447902 : Closed e1211182447902 ∧ code e1211182447902 = 5609228959006 := by decide
theorem cert_e1211182447902 : check e1211182447902 [[],[]] .smaller = true := by decide
def e1211182447926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182447926 : Closed e1211182447926 ∧ code e1211182447926 = 5609228959030 := by decide
theorem cert_e1211182447926 : check e1211182447926 [[],[]] .smaller = true := by decide
def e1211182447930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182447930 : Closed e1211182447930 ∧ code e1211182447930 = 5609228959034 := by decide
theorem cert_e1211182447930 : check e1211182447930 [[],[]] .smaller = true := by decide
def e1211182448014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e1211182448014 : Closed e1211182448014 ∧ code e1211182448014 = 5609228959118 := by decide
theorem cert_e1211182448014 : check e1211182448014 [[],[]] .smaller = true := by decide
def e1211182448026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182448026 : Closed e1211182448026 ∧ code e1211182448026 = 5609228959130 := by decide
theorem cert_e1211182448026 : check e1211182448026 [[],[]] .smaller = true := by decide
def e1211182448070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e1211182448070 : Closed e1211182448070 ∧ code e1211182448070 = 5609228959174 := by decide
theorem cert_e1211182448070 : check e1211182448070 [[],[]] .smaller = true := by decide
def e1211182448094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 3)))))))))
theorem wire_e1211182448094 : Closed e1211182448094 ∧ code e1211182448094 = 5609228959198 := by decide
theorem cert_e1211182448094 : check e1211182448094 [[],[]] .smaller = true := by decide
def e1211182448110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 2)))))))))
theorem wire_e1211182448110 : Closed e1211182448110 ∧ code e1211182448110 = 5609228959214 := by decide
theorem cert_e1211182448110 : check e1211182448110 [[],[]] .smaller = true := by decide
def e1211182448182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e1211182448182 : Closed e1211182448182 ∧ code e1211182448182 = 5609228959286 := by decide
theorem cert_e1211182448182 : check e1211182448182 [[],[]] .three = true := by decide
def e1211182448186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e1211182448186 : Closed e1211182448186 ∧ code e1211182448186 = 5609228959290 := by decide
theorem cert_e1211182448186 : check e1211182448186 [[],[]] .three = true := by decide
def e1211182448270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e1211182448270 : Closed e1211182448270 ∧ code e1211182448270 = 5609228959374 := by decide
theorem cert_e1211182448270 : check e1211182448270 [[],[]] .three = true := by decide
def e1211182448326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e1211182448326 : Closed e1211182448326 ∧ code e1211182448326 = 5609228959430 := by decide
theorem cert_e1211182448326 : check e1211182448326 [[],[]] .three = true := by decide
def e1211182448366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 2)) (.var 2)))))))))
theorem wire_e1211182448366 : Closed e1211182448366 ∧ code e1211182448366 = 5609228959470 := by decide
theorem cert_e1211182448366 : check e1211182448366 [[],[]] .three = true := by decide
def e1211182450622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e1211182450622 : Closed e1211182450622 ∧ code e1211182450622 = 5609228961726 := by decide
theorem cert_e1211182450622 : check e1211182450622 [[],[]] .smaller = true := by decide
def e1211182450670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e1211182450670 : Closed e1211182450670 ∧ code e1211182450670 = 5609228961774 := by decide
theorem cert_e1211182450670 : check e1211182450670 [[],[]] .smaller = true := by decide
def e1211182454494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e1211182454494 : Closed e1211182454494 ∧ code e1211182454494 = 5609228965598 := by decide
theorem cert_e1211182454494 : check e1211182454494 [[],[]] .smaller = true := by decide
def e1211182454518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e1211182454518 : Closed e1211182454518 ∧ code e1211182454518 = 5609228965622 := by decide
theorem cert_e1211182454518 : check e1211182454518 [[],[]] .smaller = true := by decide
def e1211182454622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e1211182454622 : Closed e1211182454622 ∧ code e1211182454622 = 5609228965726 := by decide
theorem cert_e1211182454622 : check e1211182454622 [[],[]] .smaller = true := by decide
def e1211182454638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e1211182454638 : Closed e1211182454638 ∧ code e1211182454638 = 5609228965742 := by decide
theorem cert_e1211182454638 : check e1211182454638 [[],[]] .smaller = true := by decide
def e1211182454646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e1211182454646 : Closed e1211182454646 ∧ code e1211182454646 = 5609228965750 := by decide
theorem cert_e1211182454646 : check e1211182454646 [[],[]] .smaller = true := by decide
def e1211182454650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e1211182454650 : Closed e1211182454650 ∧ code e1211182454650 = 5609228965754 := by decide
theorem cert_e1211182454650 : check e1211182454650 [[],[]] .smaller = true := by decide
def e1211182454710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e1211182454710 : Closed e1211182454710 ∧ code e1211182454710 = 5609228965814 := by decide
theorem cert_e1211182454710 : check e1211182454710 [[],[]] .smaller = true := by decide
def e1211182454742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e1211182454742 : Closed e1211182454742 ∧ code e1211182454742 = 5609228965846 := by decide
theorem cert_e1211182454742 : check e1211182454742 [[],[]] .smaller = true := by decide
def e1211182454746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e1211182454746 : Closed e1211182454746 ∧ code e1211182454746 = 5609228965850 := by decide
theorem cert_e1211182454746 : check e1211182454746 [[],[]] .smaller = true := by decide
def e1211182455262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e1211182455262 : Closed e1211182455262 ∧ code e1211182455262 = 5609228966366 := by decide
theorem cert_e1211182455262 : check e1211182455262 [[],[]] .smaller = true := by decide
def e1211182455286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e1211182455286 : Closed e1211182455286 ∧ code e1211182455286 = 5609228966390 := by decide
theorem cert_e1211182455286 : check e1211182455286 [[],[]] .smaller = true := by decide
def e1211182455934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e1211182455934 : Closed e1211182455934 ∧ code e1211182455934 = 5609228967038 := by decide
theorem cert_e1211182455934 : check e1211182455934 [[],[]] .three = true := by decide
def e1211182456030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211182456030 : Closed e1211182456030 ∧ code e1211182456030 = 5609228967134 := by decide
theorem cert_e1211182456030 : check e1211182456030 [[],[]] .smaller = true := by decide
def e1211182456046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182456046 : Closed e1211182456046 ∧ code e1211182456046 = 5609228967150 := by decide
theorem cert_e1211182456046 : check e1211182456046 [[],[]] .smaller = true := by decide
def e1211182456054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182456054 : Closed e1211182456054 ∧ code e1211182456054 = 5609228967158 := by decide
theorem cert_e1211182456054 : check e1211182456054 [[],[]] .smaller = true := by decide
def e1211182456058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211182456058 : Closed e1211182456058 ∧ code e1211182456058 = 5609228967162 := by decide
theorem cert_e1211182456058 : check e1211182456058 [[],[]] .smaller = true := by decide
def e1211182456382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e1211182456382 : Closed e1211182456382 ∧ code e1211182456382 = 5609228967486 := by decide
theorem cert_e1211182456382 : check e1211182456382 [[],[]] .smaller = true := by decide
def e1211182456438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182456438 : Closed e1211182456438 ∧ code e1211182456438 = 5609228967542 := by decide
theorem cert_e1211182456438 : check e1211182456438 [[],[]] .smaller = true := by decide
def e1211182456606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e1211182456606 : Closed e1211182456606 ∧ code e1211182456606 = 5609228967710 := by decide
theorem cert_e1211182456606 : check e1211182456606 [[],[]] .smaller = true := by decide
def e1211182456630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182456630 : Closed e1211182456630 ∧ code e1211182456630 = 5609228967734 := by decide
theorem cert_e1211182456630 : check e1211182456630 [[],[]] .smaller = true := by decide
def e1211182456634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182456634 : Closed e1211182456634 ∧ code e1211182456634 = 5609228967738 := by decide
theorem cert_e1211182456634 : check e1211182456634 [[],[]] .smaller = true := by decide
def e1211182456718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e1211182456718 : Closed e1211182456718 ∧ code e1211182456718 = 5609228967822 := by decide
theorem cert_e1211182456718 : check e1211182456718 [[],[]] .three = true := by decide
def e1211182465982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e1211182465982 : Closed e1211182465982 ∧ code e1211182465982 = 5609228977086 := by decide
theorem cert_e1211182465982 : check e1211182465982 [[],[]] .smaller = true := by decide
def e1211182466014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e1211182466014 : Closed e1211182466014 ∧ code e1211182466014 = 5609228977118 := by decide
theorem cert_e1211182466014 : check e1211182466014 [[],[]] .smaller = true := by decide
def e1211182466030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e1211182466030 : Closed e1211182466030 ∧ code e1211182466030 = 5609228977134 := by decide
theorem cert_e1211182466030 : check e1211182466030 [[],[]] .smaller = true := by decide
def e1211182466038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e1211182466038 : Closed e1211182466038 ∧ code e1211182466038 = 5609228977142 := by decide
theorem cert_e1211182466038 : check e1211182466038 [[],[]] .smaller = true := by decide
def e1211182467934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e1211182467934 : Closed e1211182467934 ∧ code e1211182467934 = 5609228979038 := by decide
theorem cert_e1211182467934 : check e1211182467934 [[],[]] .smaller = true := by decide
def e1211182467950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211182467950 : Closed e1211182467950 ∧ code e1211182467950 = 5609228979054 := by decide
theorem cert_e1211182467950 : check e1211182467950 [[],[]] .smaller = true := by decide
def e1211182467958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211182467958 : Closed e1211182467958 ∧ code e1211182467958 = 5609228979062 := by decide
theorem cert_e1211182467958 : check e1211182467958 [[],[]] .smaller = true := by decide
def e1211182467962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e1211182467962 : Closed e1211182467962 ∧ code e1211182467962 = 5609228979066 := by decide
theorem cert_e1211182467962 : check e1211182467962 [[],[]] .smaller = true := by decide
def e1211182468014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211182468014 : Closed e1211182468014 ∧ code e1211182468014 = 5609228979118 := by decide
theorem cert_e1211182468014 : check e1211182468014 [[],[]] .smaller = true := by decide
def e1211182468026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211182468026 : Closed e1211182468026 ∧ code e1211182468026 = 5609228979130 := by decide
theorem cert_e1211182468026 : check e1211182468026 [[],[]] .smaller = true := by decide
def e1211182468054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211182468054 : Closed e1211182468054 ∧ code e1211182468054 = 5609228979158 := by decide
theorem cert_e1211182468054 : check e1211182468054 [[],[]] .smaller = true := by decide
def e1211182468058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211182468058 : Closed e1211182468058 ∧ code e1211182468058 = 5609228979162 := by decide
theorem cert_e1211182468058 : check e1211182468058 [[],[]] .smaller = true := by decide
def e1211182468074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e1211182468074 : Closed e1211182468074 ∧ code e1211182468074 = 5609228979178 := by decide
theorem cert_e1211182468074 : check e1211182468074 [[],[]] .smaller = true := by decide
def e1211182468222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e1211182468222 : Closed e1211182468222 ∧ code e1211182468222 = 5609228979326 := by decide
theorem cert_e1211182468222 : check e1211182468222 [[],[]] .three = true := by decide
def e1211182468318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e1211182468318 : Closed e1211182468318 ∧ code e1211182468318 = 5609228979422 := by decide
theorem cert_e1211182468318 : check e1211182468318 [[],[]] .smaller = true := by decide
def e1211182468334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182468334 : Closed e1211182468334 ∧ code e1211182468334 = 5609228979438 := by decide
theorem cert_e1211182468334 : check e1211182468334 [[],[]] .smaller = true := by decide
def e1211182468342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182468342 : Closed e1211182468342 ∧ code e1211182468342 = 5609228979446 := by decide
theorem cert_e1211182468342 : check e1211182468342 [[],[]] .smaller = true := by decide
def e1211182468346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e1211182468346 : Closed e1211182468346 ∧ code e1211182468346 = 5609228979450 := by decide
theorem cert_e1211182468346 : check e1211182468346 [[],[]] .smaller = true := by decide
def e1211182468670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e1211182468670 : Closed e1211182468670 ∧ code e1211182468670 = 5609228979774 := by decide
theorem cert_e1211182468670 : check e1211182468670 [[],[]] .smaller = true := by decide
def e1211182468718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211182468718 : Closed e1211182468718 ∧ code e1211182468718 = 5609228979822 := by decide
theorem cert_e1211182468718 : check e1211182468718 [[],[]] .smaller = true := by decide
def e1211182468730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211182468730 : Closed e1211182468730 ∧ code e1211182468730 = 5609228979834 := by decide
theorem cert_e1211182468730 : check e1211182468730 [[],[]] .smaller = true := by decide
def e1211182468894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))))))
theorem wire_e1211182468894 : Closed e1211182468894 ∧ code e1211182468894 = 5609228979998 := by decide
theorem cert_e1211182468894 : check e1211182468894 [[],[]] .smaller = true := by decide
def e1211182468918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182468918 : Closed e1211182468918 ∧ code e1211182468918 = 5609228980022 := by decide
theorem cert_e1211182468918 : check e1211182468918 [[],[]] .smaller = true := by decide
def e1211182468922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182468922 : Closed e1211182468922 ∧ code e1211182468922 = 5609228980026 := by decide
theorem cert_e1211182468922 : check e1211182468922 [[],[]] .smaller = true := by decide
def e1211182469006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e1211182469006 : Closed e1211182469006 ∧ code e1211182469006 = 5609228980110 := by decide
theorem cert_e1211182469006 : check e1211182469006 [[],[]] .smaller = true := by decide
def e1211182469018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182469018 : Closed e1211182469018 ∧ code e1211182469018 = 5609228980122 := by decide
theorem cert_e1211182469018 : check e1211182469018 [[],[]] .smaller = true := by decide
def e1211182469062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e1211182469062 : Closed e1211182469062 ∧ code e1211182469062 = 5609228980166 := by decide
theorem cert_e1211182469062 : check e1211182469062 [[],[]] .three = true := by decide
def e1211182473710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))))))
theorem wire_e1211182473710 : Closed e1211182473710 ∧ code e1211182473710 = 5609228984814 := by decide
theorem cert_e1211182473710 : check e1211182473710 [[],[]] .smaller = true := by decide
def e1211182474678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e1211182474678 : Closed e1211182474678 ∧ code e1211182474678 = 5609228985782 := by decide
theorem cert_e1211182474678 : check e1211182474678 [[],[]] .smaller = true := by decide
def e1211182474710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e1211182474710 : Closed e1211182474710 ∧ code e1211182474710 = 5609228985814 := by decide
theorem cert_e1211182474710 : check e1211182474710 [[],[]] .smaller = true := by decide
def e1211182474714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e1211182474714 : Closed e1211182474714 ∧ code e1211182474714 = 5609228985818 := by decide
theorem cert_e1211182474714 : check e1211182474714 [[],[]] .smaller = true := by decide
def e1211182474814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e1211182474814 : Closed e1211182474814 ∧ code e1211182474814 = 5609228985918 := by decide
theorem cert_e1211182474814 : check e1211182474814 [[],[]] .smaller = true := by decide
def e1211182474870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e1211182474870 : Closed e1211182474870 ∧ code e1211182474870 = 5609228985974 := by decide
theorem cert_e1211182474870 : check e1211182474870 [[],[]] .smaller = true := by decide
def e1211182475038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211182475038 : Closed e1211182475038 ∧ code e1211182475038 = 5609228986142 := by decide
theorem cert_e1211182475038 : check e1211182475038 [[],[]] .smaller = true := by decide
def e1211182475062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182475062 : Closed e1211182475062 ∧ code e1211182475062 = 5609228986166 := by decide
theorem cert_e1211182475062 : check e1211182475062 [[],[]] .smaller = true := by decide
def e1211182475066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182475066 : Closed e1211182475066 ∧ code e1211182475066 = 5609228986170 := by decide
theorem cert_e1211182475066 : check e1211182475066 [[],[]] .smaller = true := by decide
def e1211182475150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211182475150 : Closed e1211182475150 ∧ code e1211182475150 = 5609228986254 := by decide
theorem cert_e1211182475150 : check e1211182475150 [[],[]] .smaller = true := by decide
def e1211182475198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211182475198 : Closed e1211182475198 ∧ code e1211182475198 = 5609228986302 := by decide
theorem cert_e1211182475198 : check e1211182475198 [[],[]] .three = true := by decide
def e1211182475206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e1211182475206 : Closed e1211182475206 ∧ code e1211182475206 = 5609228986310 := by decide
theorem cert_e1211182475206 : check e1211182475206 [[],[]] .smaller = true := by decide
def e1211182475230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 3))))))))))
theorem wire_e1211182475230 : Closed e1211182475230 ∧ code e1211182475230 = 5609228986334 := by decide
theorem cert_e1211182475230 : check e1211182475230 [[],[]] .smaller = true := by decide
def e1211182475246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211182475246 : Closed e1211182475246 ∧ code e1211182475246 = 5609228986350 := by decide
theorem cert_e1211182475246 : check e1211182475246 [[],[]] .three = true := by decide
def e1211182477550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211182477550 : Closed e1211182477550 ∧ code e1211182477550 = 5609228988654 := by decide
theorem cert_e1211182477550 : check e1211182477550 [[],[]] .smaller = true := by decide
def e1211182477558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211182477558 : Closed e1211182477558 ∧ code e1211182477558 = 5609228988662 := by decide
theorem cert_e1211182477558 : check e1211182477558 [[],[]] .smaller = true := by decide
def e1211182478038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211182478038 : Closed e1211182478038 ∧ code e1211182478038 = 5609228989142 := by decide
theorem cert_e1211182478038 : check e1211182478038 [[],[]] .smaller = true := by decide
def e1211182478042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211182478042 : Closed e1211182478042 ∧ code e1211182478042 = 5609228989146 := by decide
theorem cert_e1211182478042 : check e1211182478042 [[],[]] .smaller = true := by decide
def e1211182478058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211182478058 : Closed e1211182478058 ∧ code e1211182478058 = 5609228989162 := by decide
theorem cert_e1211182478058 : check e1211182478058 [[],[]] .smaller = true := by decide
def e1211182478110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211182478110 : Closed e1211182478110 ∧ code e1211182478110 = 5609228989214 := by decide
theorem cert_e1211182478110 : check e1211182478110 [[],[]] .smaller = true := by decide
def e1211182478134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211182478134 : Closed e1211182478134 ∧ code e1211182478134 = 5609228989238 := by decide
theorem cert_e1211182478134 : check e1211182478134 [[],[]] .smaller = true := by decide
def e1211182478138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211182478138 : Closed e1211182478138 ∧ code e1211182478138 = 5609228989242 := by decide
theorem cert_e1211182478138 : check e1211182478138 [[],[]] .smaller = true := by decide
def e1211182478222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e1211182478222 : Closed e1211182478222 ∧ code e1211182478222 = 5609228989326 := by decide
theorem cert_e1211182478222 : check e1211182478222 [[],[]] .smaller = true := by decide
def e1211182478234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211182478234 : Closed e1211182478234 ∧ code e1211182478234 = 5609228989338 := by decide
theorem cert_e1211182478234 : check e1211182478234 [[],[]] .smaller = true := by decide
def e1211182478278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211182478278 : Closed e1211182478278 ∧ code e1211182478278 = 5609228989382 := by decide
theorem cert_e1211182478278 : check e1211182478278 [[],[]] .smaller = true := by decide
def e1211182478302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211182478302 : Closed e1211182478302 ∧ code e1211182478302 = 5609228989406 := by decide
theorem cert_e1211182478302 : check e1211182478302 [[],[]] .smaller = true := by decide
def e1211182478318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211182478318 : Closed e1211182478318 ∧ code e1211182478318 = 5609228989422 := by decide
theorem cert_e1211182478318 : check e1211182478318 [[],[]] .smaller = true := by decide
def e1211182479758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211182479758 : Closed e1211182479758 ∧ code e1211182479758 = 5609228990862 := by decide
theorem cert_e1211182479758 : check e1211182479758 [[],[]] .three = true := by decide
def e1211182479814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211182479814 : Closed e1211182479814 ∧ code e1211182479814 = 5609228990918 := by decide
theorem cert_e1211182479814 : check e1211182479814 [[],[]] .three = true := by decide
def e1211182479854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 2) (.var 2))))))))))
theorem wire_e1211182479854 : Closed e1211182479854 ∧ code e1211182479854 = 5609228990958 := by decide
theorem cert_e1211182479854 : check e1211182479854 [[],[]] .three = true := by decide
def e1211182624222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e1211182624222 : Closed e1211182624222 ∧ code e1211182624222 = 5609229135326 := by decide
theorem cert_e1211182624222 : check e1211182624222 [[],[]] .smaller = true := by decide
def e1211182624238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e1211182624238 : Closed e1211182624238 ∧ code e1211182624238 = 5609229135342 := by decide
theorem cert_e1211182624238 : check e1211182624238 [[],[]] .smaller = true := by decide
def e1211182624478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e1211182624478 : Closed e1211182624478 ∧ code e1211182624478 = 5609229135582 := by decide
theorem cert_e1211182624478 : check e1211182624478 [[],[]] .smaller = true := by decide
def e1211182624502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e1211182624502 : Closed e1211182624502 ∧ code e1211182624502 = 5609229135606 := by decide
theorem cert_e1211182624502 : check e1211182624502 [[],[]] .smaller = true := by decide
def e1211182624606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e1211182624606 : Closed e1211182624606 ∧ code e1211182624606 = 5609229135710 := by decide
theorem cert_e1211182624606 : check e1211182624606 [[],[]] .smaller = true := by decide
end Blc.Floor42
