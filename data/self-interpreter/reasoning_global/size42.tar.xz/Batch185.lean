import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203596718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e1211203596718 : Closed e1211203596718 ∧ code e1211203596718 = 5609250107822 := by decide
theorem cert_e1211203596718 : check e1211203596718 [[],[]] .sourceHead = true := by decide
def e1211203596730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e1211203596730 : Closed e1211203596730 ∧ code e1211203596730 = 5609250107834 := by decide
theorem cert_e1211203596730 : check e1211203596730 [[],[]] .sourceHead = true := by decide
def e1211203597422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203597422 : Closed e1211203597422 ∧ code e1211203597422 = 5609250108526 := by decide
theorem cert_e1211203597422 : check e1211203597422 [[],[]] .sourceHead = true := by decide
def e1211203597434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203597434 : Closed e1211203597434 ∧ code e1211203597434 = 5609250108538 := by decide
theorem cert_e1211203597434 : check e1211203597434 [[],[]] .sourceHead = true := by decide
def e1211203597598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203597598 : Closed e1211203597598 ∧ code e1211203597598 = 5609250108702 := by decide
theorem cert_e1211203597598 : check e1211203597598 [[],[]] .sourceHead = true := by decide
def e1211203597766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203597766 : Closed e1211203597766 ∧ code e1211203597766 = 5609250108870 := by decide
theorem cert_e1211203597766 : check e1211203597766 [[],[]] .sourceHead = true := by decide
def e1211203598062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e1211203598062 : Closed e1211203598062 ∧ code e1211203598062 = 5609250109166 := by decide
theorem cert_e1211203598062 : check e1211203598062 [[],[]] .sourceHead = true := by decide
def e1211203598254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e1211203598254 : Closed e1211203598254 ∧ code e1211203598254 = 5609250109358 := by decide
theorem cert_e1211203598254 : check e1211203598254 [[],[]] .sourceHead = true := by decide
def e1211203598266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e1211203598266 : Closed e1211203598266 ∧ code e1211203598266 = 5609250109370 := by decide
theorem cert_e1211203598266 : check e1211203598266 [[],[]] .sourceHead = true := by decide
def e1211203598510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e1211203598510 : Closed e1211203598510 ∧ code e1211203598510 = 5609250109614 := by decide
theorem cert_e1211203598510 : check e1211203598510 [[],[]] .chain = true := by decide
def e1211203598522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e1211203598522 : Closed e1211203598522 ∧ code e1211203598522 = 5609250109626 := by decide
theorem cert_e1211203598522 : check e1211203598522 [[],[]] .chain = true := by decide
def e1211203599086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e1211203599086 : Closed e1211203599086 ∧ code e1211203599086 = 5609250110190 := by decide
theorem cert_e1211203599086 : check e1211203599086 [[],[]] .sourceHead = true := by decide
def e1211203599214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e1211203599214 : Closed e1211203599214 ∧ code e1211203599214 = 5609250110318 := by decide
theorem cert_e1211203599214 : check e1211203599214 [[],[]] .chain = true := by decide
def e1211203599222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e1211203599222 : Closed e1211203599222 ∧ code e1211203599222 = 5609250110326 := by decide
theorem cert_e1211203599222 : check e1211203599222 [[],[]] .chain = true := by decide
def e1211203599278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e1211203599278 : Closed e1211203599278 ∧ code e1211203599278 = 5609250110382 := by decide
theorem cert_e1211203599278 : check e1211203599278 [[],[]] .chain = true := by decide
def e1211203599290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e1211203599290 : Closed e1211203599290 ∧ code e1211203599290 = 5609250110394 := by decide
theorem cert_e1211203599290 : check e1211203599290 [[],[]] .chain = true := by decide
def e1211203599318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e1211203599318 : Closed e1211203599318 ∧ code e1211203599318 = 5609250110422 := by decide
theorem cert_e1211203599318 : check e1211203599318 [[],[]] .chain = true := by decide
def e1211203599322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e1211203599322 : Closed e1211203599322 ∧ code e1211203599322 = 5609250110426 := by decide
theorem cert_e1211203599322 : check e1211203599322 [[],[]] .chain = true := by decide
def e1211203599790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203599790 : Closed e1211203599790 ∧ code e1211203599790 = 5609250110894 := by decide
theorem cert_e1211203599790 : check e1211203599790 [[],[]] .chain = true := by decide
def e1211203599802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203599802 : Closed e1211203599802 ∧ code e1211203599802 = 5609250110906 := by decide
theorem cert_e1211203599802 : check e1211203599802 [[],[]] .chain = true := by decide
def e1211203599850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e1211203599850 : Closed e1211203599850 ∧ code e1211203599850 = 5609250110954 := by decide
theorem cert_e1211203599850 : check e1211203599850 [[],[]] .chain = true := by decide
def e1211203599914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e1211203599914 : Closed e1211203599914 ∧ code e1211203599914 = 5609250111018 := by decide
theorem cert_e1211203599914 : check e1211203599914 [[],[]] .chain = true := by decide
def e1211203600046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1211203600046 : Closed e1211203600046 ∧ code e1211203600046 = 5609250111150 := by decide
theorem cert_e1211203600046 : check e1211203600046 [[],[]] .sourceHead = true := by decide
def e1211203600058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1211203600058 : Closed e1211203600058 ∧ code e1211203600058 = 5609250111162 := by decide
theorem cert_e1211203600058 : check e1211203600058 [[],[]] .sourceHead = true := by decide
def e1211203600086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e1211203600086 : Closed e1211203600086 ∧ code e1211203600086 = 5609250111190 := by decide
theorem cert_e1211203600086 : check e1211203600086 [[],[]] .chain = true := by decide
def e1211203600090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e1211203600090 : Closed e1211203600090 ∧ code e1211203600090 = 5609250111194 := by decide
theorem cert_e1211203600090 : check e1211203600090 [[],[]] .chain = true := by decide
def e1211203600106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e1211203600106 : Closed e1211203600106 ∧ code e1211203600106 = 5609250111210 := by decide
theorem cert_e1211203600106 : check e1211203600106 [[],[]] .chain = true := by decide
def e1211203602030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203602030 : Closed e1211203602030 ∧ code e1211203602030 = 5609250113134 := by decide
theorem cert_e1211203602030 : check e1211203602030 [[],[]] .chain = true := by decide
def e1211203602042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203602042 : Closed e1211203602042 ∧ code e1211203602042 = 5609250113146 := by decide
theorem cert_e1211203602042 : check e1211203602042 [[],[]] .chain = true := by decide
def e1211203602330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203602330 : Closed e1211203602330 ∧ code e1211203602330 = 5609250113434 := by decide
theorem cert_e1211203602330 : check e1211203602330 [[],[]] .chain = true := by decide
def e1211203603566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203603566 : Closed e1211203603566 ∧ code e1211203603566 = 5609250114670 := by decide
theorem cert_e1211203603566 : check e1211203603566 [[],[]] .chain = true := by decide
def e1211203603578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203603578 : Closed e1211203603578 ∧ code e1211203603578 = 5609250114682 := by decide
theorem cert_e1211203603578 : check e1211203603578 [[],[]] .chain = true := by decide
def e1211203603742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203603742 : Closed e1211203603742 ∧ code e1211203603742 = 5609250114846 := by decide
theorem cert_e1211203603742 : check e1211203603742 [[],[]] .chain = true := by decide
def e1211203603910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203603910 : Closed e1211203603910 ∧ code e1211203603910 = 5609250115014 := by decide
theorem cert_e1211203603910 : check e1211203603910 [[],[]] .chain = true := by decide
def e1211203604250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e1211203604250 : Closed e1211203604250 ∧ code e1211203604250 = 5609250115354 := by decide
theorem cert_e1211203604250 : check e1211203604250 [[],[]] .chain = true := by decide
def e1211203604294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e1211203604294 : Closed e1211203604294 ∧ code e1211203604294 = 5609250115398 := by decide
theorem cert_e1211203604294 : check e1211203604294 [[],[]] .chain = true := by decide
def e1211203605278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203605278 : Closed e1211203605278 ∧ code e1211203605278 = 5609250116382 := by decide
theorem cert_e1211203605278 : check e1211203605278 [[],[]] .chain = true := by decide
def e1211203605446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203605446 : Closed e1211203605446 ∧ code e1211203605446 = 5609250116550 := by decide
theorem cert_e1211203605446 : check e1211203605446 [[],[]] .chain = true := by decide
def e1211203607750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203607750 : Closed e1211203607750 ∧ code e1211203607750 = 5609250118854 := by decide
theorem cert_e1211203607750 : check e1211203607750 [[],[]] .chain = true := by decide
def e1211203608814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203608814 : Closed e1211203608814 ∧ code e1211203608814 = 5609250119918 := by decide
theorem cert_e1211203608814 : check e1211203608814 [[],[]] .chain = true := by decide
def e1211203608826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e1211203608826 : Closed e1211203608826 ∧ code e1211203608826 = 5609250119930 := by decide
theorem cert_e1211203608826 : check e1211203608826 [[],[]] .chain = true := by decide
def e1211203609006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e1211203609006 : Closed e1211203609006 ∧ code e1211203609006 = 5609250120110 := by decide
theorem cert_e1211203609006 : check e1211203609006 [[],[]] .sourceHead = true := by decide
def e1211203609198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203609198 : Closed e1211203609198 ∧ code e1211203609198 = 5609250120302 := by decide
theorem cert_e1211203609198 : check e1211203609198 [[],[]] .chain = true := by decide
def e1211203609210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203609210 : Closed e1211203609210 ∧ code e1211203609210 = 5609250120314 := by decide
theorem cert_e1211203609210 : check e1211203609210 [[],[]] .chain = true := by decide
def e1211203609374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203609374 : Closed e1211203609374 ∧ code e1211203609374 = 5609250120478 := by decide
theorem cert_e1211203609374 : check e1211203609374 [[],[]] .chain = true := by decide
def e1211203609542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e1211203609542 : Closed e1211203609542 ∧ code e1211203609542 = 5609250120646 := by decide
theorem cert_e1211203609542 : check e1211203609542 [[],[]] .chain = true := by decide
def e1211203610158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e1211203610158 : Closed e1211203610158 ∧ code e1211203610158 = 5609250121262 := by decide
theorem cert_e1211203610158 : check e1211203610158 [[],[]] .chain = true := by decide
def e1211203610338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e1211203610338 : Closed e1211203610338 ∧ code e1211203610338 = 5609250121442 := by decide
theorem cert_e1211203610338 : check e1211203610338 [[],[]] .chain = true := by decide
def e1211203610350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e1211203610350 : Closed e1211203610350 ∧ code e1211203610350 = 5609250121454 := by decide
theorem cert_e1211203610350 : check e1211203610350 [[],[]] .sourceHead = true := by decide
def e1211203610478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1211203610478 : Closed e1211203610478 ∧ code e1211203610478 = 5609250121582 := by decide
theorem cert_e1211203610478 : check e1211203610478 [[],[]] .chain = true := by decide
def e1211203610486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1211203610486 : Closed e1211203610486 ∧ code e1211203610486 = 5609250121590 := by decide
theorem cert_e1211203610486 : check e1211203610486 [[],[]] .chain = true := by decide
def e1211203610506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203610506 : Closed e1211203610506 ∧ code e1211203610506 = 5609250121610 := by decide
theorem cert_e1211203610506 : check e1211203610506 [[],[]] .chain = true := by decide
def e1211203610530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211203610530 : Closed e1211203610530 ∧ code e1211203610530 = 5609250121634 := by decide
theorem cert_e1211203610530 : check e1211203610530 [[],[]] .chain = true := by decide
def e1211203610542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e1211203610542 : Closed e1211203610542 ∧ code e1211203610542 = 5609250121646 := by decide
theorem cert_e1211203610542 : check e1211203610542 [[],[]] .sourceHead = true := by decide
def e1211203610550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1211203610550 : Closed e1211203610550 ∧ code e1211203610550 = 5609250121654 := by decide
theorem cert_e1211203610550 : check e1211203610550 [[],[]] .chain = true := by decide
def e1211203610554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e1211203610554 : Closed e1211203610554 ∧ code e1211203610554 = 5609250121658 := by decide
theorem cert_e1211203610554 : check e1211203610554 [[],[]] .sourceHead = true := by decide
def e1211203610686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e1211203610686 : Closed e1211203610686 ∧ code e1211203610686 = 5609250121790 := by decide
theorem cert_e1211203610686 : check e1211203610686 [[],[]] .chain = true := by decide
def e1211203611106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e1211203611106 : Closed e1211203611106 ∧ code e1211203611106 = 5609250122210 := by decide
theorem cert_e1211203611106 : check e1211203611106 [[],[]] .chain = true := by decide
def e1211203611118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e1211203611118 : Closed e1211203611118 ∧ code e1211203611118 = 5609250122222 := by decide
theorem cert_e1211203611118 : check e1211203611118 [[],[]] .sourceHead = true := by decide
def e1211203611886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203611886 : Closed e1211203611886 ∧ code e1211203611886 = 5609250122990 := by decide
theorem cert_e1211203611886 : check e1211203611886 [[],[]] .chain = true := by decide
def e1211203611894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203611894 : Closed e1211203611894 ∧ code e1211203611894 = 5609250122998 := by decide
theorem cert_e1211203611894 : check e1211203611894 [[],[]] .chain = true := by decide
def e1211203612174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e1211203612174 : Closed e1211203612174 ∧ code e1211203612174 = 5609250123278 := by decide
theorem cert_e1211203612174 : check e1211203612174 [[],[]] .chain = true := by decide
def e1211203612186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203612186 : Closed e1211203612186 ∧ code e1211203612186 = 5609250123290 := by decide
theorem cert_e1211203612186 : check e1211203612186 [[],[]] .sourceHead = true := by decide
def e1211203612258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203612258 : Closed e1211203612258 ∧ code e1211203612258 = 5609250123362 := by decide
theorem cert_e1211203612258 : check e1211203612258 [[],[]] .chain = true := by decide
def e1211203612270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203612270 : Closed e1211203612270 ∧ code e1211203612270 = 5609250123374 := by decide
theorem cert_e1211203612270 : check e1211203612270 [[],[]] .sourceHead = true := by decide
def e1211203612278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203612278 : Closed e1211203612278 ∧ code e1211203612278 = 5609250123382 := by decide
theorem cert_e1211203612278 : check e1211203612278 [[],[]] .chain = true := by decide
def e1211203612282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203612282 : Closed e1211203612282 ∧ code e1211203612282 = 5609250123386 := by decide
theorem cert_e1211203612282 : check e1211203612282 [[],[]] .sourceHead = true := by decide
def e1211203613550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203613550 : Closed e1211203613550 ∧ code e1211203613550 = 5609250124654 := by decide
theorem cert_e1211203613550 : check e1211203613550 [[],[]] .chain = true := by decide
def e1211203613558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203613558 : Closed e1211203613558 ∧ code e1211203613558 = 5609250124662 := by decide
theorem cert_e1211203613558 : check e1211203613558 [[],[]] .chain = true := by decide
def e1211203613614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203613614 : Closed e1211203613614 ∧ code e1211203613614 = 5609250124718 := by decide
theorem cert_e1211203613614 : check e1211203613614 [[],[]] .chain = true := by decide
def e1211203613626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203613626 : Closed e1211203613626 ∧ code e1211203613626 = 5609250124730 := by decide
theorem cert_e1211203613626 : check e1211203613626 [[],[]] .chain = true := by decide
def e1211203613654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203613654 : Closed e1211203613654 ∧ code e1211203613654 = 5609250124758 := by decide
theorem cert_e1211203613654 : check e1211203613654 [[],[]] .chain = true := by decide
def e1211203613658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203613658 : Closed e1211203613658 ∧ code e1211203613658 = 5609250124762 := by decide
theorem cert_e1211203613658 : check e1211203613658 [[],[]] .chain = true := by decide
def e1211203613934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203613934 : Closed e1211203613934 ∧ code e1211203613934 = 5609250125038 := by decide
theorem cert_e1211203613934 : check e1211203613934 [[],[]] .chain = true := by decide
def e1211203613942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203613942 : Closed e1211203613942 ∧ code e1211203613942 = 5609250125046 := by decide
theorem cert_e1211203613942 : check e1211203613942 [[],[]] .chain = true := by decide
def e1211203614318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203614318 : Closed e1211203614318 ∧ code e1211203614318 = 5609250125422 := by decide
theorem cert_e1211203614318 : check e1211203614318 [[],[]] .chain = true := by decide
def e1211203614330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203614330 : Closed e1211203614330 ∧ code e1211203614330 = 5609250125434 := by decide
theorem cert_e1211203614330 : check e1211203614330 [[],[]] .chain = true := by decide
def e1211203614518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203614518 : Closed e1211203614518 ∧ code e1211203614518 = 5609250125622 := by decide
theorem cert_e1211203614518 : check e1211203614518 [[],[]] .chain = true := by decide
def e1211203614522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203614522 : Closed e1211203614522 ∧ code e1211203614522 = 5609250125626 := by decide
theorem cert_e1211203614522 : check e1211203614522 [[],[]] .chain = true := by decide
def e1211203614778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203614778 : Closed e1211203614778 ∧ code e1211203614778 = 5609250125882 := by decide
theorem cert_e1211203614778 : check e1211203614778 [[],[]] .chain = true := by decide
def e1211203614826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e1211203614826 : Closed e1211203614826 ∧ code e1211203614826 = 5609250125930 := by decide
theorem cert_e1211203614826 : check e1211203614826 [[],[]] .sourceHead = true := by decide
def e1211203614874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203614874 : Closed e1211203614874 ∧ code e1211203614874 = 5609250125978 := by decide
theorem cert_e1211203614874 : check e1211203614874 [[],[]] .chain = true := by decide
def e1211203614918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203614918 : Closed e1211203614918 ∧ code e1211203614918 = 5609250126022 := by decide
theorem cert_e1211203614918 : check e1211203614918 [[],[]] .chain = true := by decide
def e1211203615114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e1211203615114 : Closed e1211203615114 ∧ code e1211203615114 = 5609250126218 := by decide
theorem cert_e1211203615114 : check e1211203615114 [[],[]] .chain = true := by decide
def e1211203615138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e1211203615138 : Closed e1211203615138 ∧ code e1211203615138 = 5609250126242 := by decide
theorem cert_e1211203615138 : check e1211203615138 [[],[]] .chain = true := by decide
def e1211203615150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1211203615150 : Closed e1211203615150 ∧ code e1211203615150 = 5609250126254 := by decide
theorem cert_e1211203615150 : check e1211203615150 [[],[]] .sourceHead = true := by decide
def e1211203615158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1211203615158 : Closed e1211203615158 ∧ code e1211203615158 = 5609250126262 := by decide
theorem cert_e1211203615158 : check e1211203615158 [[],[]] .chain = true := by decide
def e1211203615162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1211203615162 : Closed e1211203615162 ∧ code e1211203615162 = 5609250126266 := by decide
theorem cert_e1211203615162 : check e1211203615162 [[],[]] .sourceHead = true := by decide
def e1211203615190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1211203615190 : Closed e1211203615190 ∧ code e1211203615190 = 5609250126294 := by decide
theorem cert_e1211203615190 : check e1211203615190 [[],[]] .chain = true := by decide
def e1211203615194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1211203615194 : Closed e1211203615194 ∧ code e1211203615194 = 5609250126298 := by decide
theorem cert_e1211203615194 : check e1211203615194 [[],[]] .chain = true := by decide
def e1211203615210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1211203615210 : Closed e1211203615210 ∧ code e1211203615210 = 5609250126314 := by decide
theorem cert_e1211203615210 : check e1211203615210 [[],[]] .sourceHead = true := by decide
def e1211203615246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e1211203615246 : Closed e1211203615246 ∧ code e1211203615246 = 5609250126350 := by decide
theorem cert_e1211203615246 : check e1211203615246 [[],[]] .chain = true := by decide
def e1211203615258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203615258 : Closed e1211203615258 ∧ code e1211203615258 = 5609250126362 := by decide
theorem cert_e1211203615258 : check e1211203615258 [[],[]] .sourceHead = true := by decide
def e1211203615330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203615330 : Closed e1211203615330 ∧ code e1211203615330 = 5609250126434 := by decide
theorem cert_e1211203615330 : check e1211203615330 [[],[]] .chain = true := by decide
def e1211203615342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203615342 : Closed e1211203615342 ∧ code e1211203615342 = 5609250126446 := by decide
theorem cert_e1211203615342 : check e1211203615342 [[],[]] .sourceHead = true := by decide
def e1211203615350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203615350 : Closed e1211203615350 ∧ code e1211203615350 = 5609250126454 := by decide
theorem cert_e1211203615350 : check e1211203615350 [[],[]] .chain = true := by decide
def e1211203615354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203615354 : Closed e1211203615354 ∧ code e1211203615354 = 5609250126458 := by decide
theorem cert_e1211203615354 : check e1211203615354 [[],[]] .sourceHead = true := by decide
def e1211203615542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203615542 : Closed e1211203615542 ∧ code e1211203615542 = 5609250126646 := by decide
theorem cert_e1211203615542 : check e1211203615542 [[],[]] .chain = true := by decide
def e1211203615546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203615546 : Closed e1211203615546 ∧ code e1211203615546 = 5609250126650 := by decide
theorem cert_e1211203615546 : check e1211203615546 [[],[]] .chain = true := by decide
def e1211203615642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203615642 : Closed e1211203615642 ∧ code e1211203615642 = 5609250126746 := by decide
theorem cert_e1211203615642 : check e1211203615642 [[],[]] .sourceHead = true := by decide
def e1211203630446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e1211203630446 : Closed e1211203630446 ∧ code e1211203630446 = 5609250141550 := by decide
theorem cert_e1211203630446 : check e1211203630446 [[],[]] .chain = true := by decide
def e1211203630454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e1211203630454 : Closed e1211203630454 ∧ code e1211203630454 = 5609250141558 := by decide
theorem cert_e1211203630454 : check e1211203630454 [[],[]] .chain = true := by decide
def e1211203630510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e1211203630510 : Closed e1211203630510 ∧ code e1211203630510 = 5609250141614 := by decide
theorem cert_e1211203630510 : check e1211203630510 [[],[]] .chain = true := by decide
def e1211203630522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e1211203630522 : Closed e1211203630522 ∧ code e1211203630522 = 5609250141626 := by decide
theorem cert_e1211203630522 : check e1211203630522 [[],[]] .chain = true := by decide
def e1211203630550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e1211203630550 : Closed e1211203630550 ∧ code e1211203630550 = 5609250141654 := by decide
theorem cert_e1211203630550 : check e1211203630550 [[],[]] .chain = true := by decide
def e1211203630554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e1211203630554 : Closed e1211203630554 ∧ code e1211203630554 = 5609250141658 := by decide
theorem cert_e1211203630554 : check e1211203630554 [[],[]] .chain = true := by decide
def e1211203630766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203630766 : Closed e1211203630766 ∧ code e1211203630766 = 5609250141870 := by decide
theorem cert_e1211203630766 : check e1211203630766 [[],[]] .chain = true := by decide
def e1211203630778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203630778 : Closed e1211203630778 ∧ code e1211203630778 = 5609250141882 := by decide
theorem cert_e1211203630778 : check e1211203630778 [[],[]] .chain = true := by decide
def e1211203630826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203630826 : Closed e1211203630826 ∧ code e1211203630826 = 5609250141930 := by decide
theorem cert_e1211203630826 : check e1211203630826 [[],[]] .chain = true := by decide
def e1211203630934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203630934 : Closed e1211203630934 ∧ code e1211203630934 = 5609250142038 := by decide
theorem cert_e1211203630934 : check e1211203630934 [[],[]] .chain = true := by decide
def e1211203630938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203630938 : Closed e1211203630938 ∧ code e1211203630938 = 5609250142042 := by decide
theorem cert_e1211203630938 : check e1211203630938 [[],[]] .chain = true := by decide
def e1211203630954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203630954 : Closed e1211203630954 ∧ code e1211203630954 = 5609250142058 := by decide
theorem cert_e1211203630954 : check e1211203630954 [[],[]] .chain = true := by decide
def e1211203631790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e1211203631790 : Closed e1211203631790 ∧ code e1211203631790 = 5609250142894 := by decide
theorem cert_e1211203631790 : check e1211203631790 [[],[]] .chain = true := by decide
def e1211203631802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e1211203631802 : Closed e1211203631802 ∧ code e1211203631802 = 5609250142906 := by decide
theorem cert_e1211203631802 : check e1211203631802 [[],[]] .chain = true := by decide
def e1211203631850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e1211203631850 : Closed e1211203631850 ∧ code e1211203631850 = 5609250142954 := by decide
theorem cert_e1211203631850 : check e1211203631850 [[],[]] .chain = true := by decide
def e1211203632042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203632042 : Closed e1211203632042 ∧ code e1211203632042 = 5609250143146 := by decide
theorem cert_e1211203632042 : check e1211203632042 [[],[]] .chain = true := by decide
def e1211203632470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e1211203632470 : Closed e1211203632470 ∧ code e1211203632470 = 5609250143574 := by decide
theorem cert_e1211203632470 : check e1211203632470 [[],[]] .chain = true := by decide
def e1211203632474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e1211203632474 : Closed e1211203632474 ∧ code e1211203632474 = 5609250143578 := by decide
theorem cert_e1211203632474 : check e1211203632474 [[],[]] .chain = true := by decide
def e1211203632490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e1211203632490 : Closed e1211203632490 ∧ code e1211203632490 = 5609250143594 := by decide
theorem cert_e1211203632490 : check e1211203632490 [[],[]] .chain = true := by decide
def e1211203632554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e1211203632554 : Closed e1211203632554 ∧ code e1211203632554 = 5609250143658 := by decide
theorem cert_e1211203632554 : check e1211203632554 [[],[]] .chain = true := by decide
def e1211203633518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e1211203633518 : Closed e1211203633518 ∧ code e1211203633518 = 5609250144622 := by decide
theorem cert_e1211203633518 : check e1211203633518 [[],[]] .chain = true := by decide
def e1211203633526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e1211203633526 : Closed e1211203633526 ∧ code e1211203633526 = 5609250144630 := by decide
theorem cert_e1211203633526 : check e1211203633526 [[],[]] .chain = true := by decide
def e1211203633582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e1211203633582 : Closed e1211203633582 ∧ code e1211203633582 = 5609250144686 := by decide
theorem cert_e1211203633582 : check e1211203633582 [[],[]] .chain = true := by decide
def e1211203633594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e1211203633594 : Closed e1211203633594 ∧ code e1211203633594 = 5609250144698 := by decide
theorem cert_e1211203633594 : check e1211203633594 [[],[]] .chain = true := by decide
def e1211203634286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e1211203634286 : Closed e1211203634286 ∧ code e1211203634286 = 5609250145390 := by decide
theorem cert_e1211203634286 : check e1211203634286 [[],[]] .chain = true := by decide
def e1211203634298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e1211203634298 : Closed e1211203634298 ∧ code e1211203634298 = 5609250145402 := by decide
theorem cert_e1211203634298 : check e1211203634298 [[],[]] .chain = true := by decide
def e1211203634462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e1211203634462 : Closed e1211203634462 ∧ code e1211203634462 = 5609250145566 := by decide
theorem cert_e1211203634462 : check e1211203634462 [[],[]] .chain = true := by decide
def e1211203634630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e1211203634630 : Closed e1211203634630 ∧ code e1211203634630 = 5609250145734 := by decide
theorem cert_e1211203634630 : check e1211203634630 [[],[]] .chain = true := by decide
def e1211203634734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e1211203634734 : Closed e1211203634734 ∧ code e1211203634734 = 5609250145838 := by decide
theorem cert_e1211203634734 : check e1211203634734 [[],[]] .chain = true := by decide
def e1211203634914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e1211203634914 : Closed e1211203634914 ∧ code e1211203634914 = 5609250146018 := by decide
theorem cert_e1211203634914 : check e1211203634914 [[],[]] .chain = true := by decide
def e1211203634926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e1211203634926 : Closed e1211203634926 ∧ code e1211203634926 = 5609250146030 := by decide
theorem cert_e1211203634926 : check e1211203634926 [[],[]] .sourceHead = true := by decide
def e1211203635054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e1211203635054 : Closed e1211203635054 ∧ code e1211203635054 = 5609250146158 := by decide
theorem cert_e1211203635054 : check e1211203635054 [[],[]] .chain = true := by decide
def e1211203635062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e1211203635062 : Closed e1211203635062 ∧ code e1211203635062 = 5609250146166 := by decide
theorem cert_e1211203635062 : check e1211203635062 [[],[]] .chain = true := by decide
def e1211203635082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e1211203635082 : Closed e1211203635082 ∧ code e1211203635082 = 5609250146186 := by decide
theorem cert_e1211203635082 : check e1211203635082 [[],[]] .chain = true := by decide
def e1211203635106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e1211203635106 : Closed e1211203635106 ∧ code e1211203635106 = 5609250146210 := by decide
theorem cert_e1211203635106 : check e1211203635106 [[],[]] .chain = true := by decide
def e1211203635118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e1211203635118 : Closed e1211203635118 ∧ code e1211203635118 = 5609250146222 := by decide
theorem cert_e1211203635118 : check e1211203635118 [[],[]] .sourceHead = true := by decide
def e1211203635126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e1211203635126 : Closed e1211203635126 ∧ code e1211203635126 = 5609250146230 := by decide
theorem cert_e1211203635126 : check e1211203635126 [[],[]] .chain = true := by decide
def e1211203635130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e1211203635130 : Closed e1211203635130 ∧ code e1211203635130 = 5609250146234 := by decide
theorem cert_e1211203635130 : check e1211203635130 [[],[]] .sourceHead = true := by decide
def e1211203636590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e1211203636590 : Closed e1211203636590 ∧ code e1211203636590 = 5609250147694 := by decide
theorem cert_e1211203636590 : check e1211203636590 [[],[]] .chain = true := by decide
def e1211203636598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e1211203636598 : Closed e1211203636598 ∧ code e1211203636598 = 5609250147702 := by decide
theorem cert_e1211203636598 : check e1211203636598 [[],[]] .chain = true := by decide
def e1211203636654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e1211203636654 : Closed e1211203636654 ∧ code e1211203636654 = 5609250147758 := by decide
theorem cert_e1211203636654 : check e1211203636654 [[],[]] .chain = true := by decide
def e1211203636666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e1211203636666 : Closed e1211203636666 ∧ code e1211203636666 = 5609250147770 := by decide
theorem cert_e1211203636666 : check e1211203636666 [[],[]] .chain = true := by decide
def e1211203636694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e1211203636694 : Closed e1211203636694 ∧ code e1211203636694 = 5609250147798 := by decide
theorem cert_e1211203636694 : check e1211203636694 [[],[]] .chain = true := by decide
def e1211203636698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e1211203636698 : Closed e1211203636698 ∧ code e1211203636698 = 5609250147802 := by decide
theorem cert_e1211203636698 : check e1211203636698 [[],[]] .chain = true := by decide
def e1211203636910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e1211203636910 : Closed e1211203636910 ∧ code e1211203636910 = 5609250148014 := by decide
theorem cert_e1211203636910 : check e1211203636910 [[],[]] .chain = true := by decide
def e1211203636922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e1211203636922 : Closed e1211203636922 ∧ code e1211203636922 = 5609250148026 := by decide
theorem cert_e1211203636922 : check e1211203636922 [[],[]] .chain = true := by decide
def e1211203636970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e1211203636970 : Closed e1211203636970 ∧ code e1211203636970 = 5609250148074 := by decide
theorem cert_e1211203636970 : check e1211203636970 [[],[]] .chain = true := by decide
def e1211203637078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e1211203637078 : Closed e1211203637078 ∧ code e1211203637078 = 5609250148182 := by decide
theorem cert_e1211203637078 : check e1211203637078 [[],[]] .chain = true := by decide
def e1211203637082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e1211203637082 : Closed e1211203637082 ∧ code e1211203637082 = 5609250148186 := by decide
theorem cert_e1211203637082 : check e1211203637082 [[],[]] .chain = true := by decide
def e1211203637098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e1211203637098 : Closed e1211203637098 ∧ code e1211203637098 = 5609250148202 := by decide
theorem cert_e1211203637098 : check e1211203637098 [[],[]] .chain = true := by decide
def e1211203637358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203637358 : Closed e1211203637358 ∧ code e1211203637358 = 5609250148462 := by decide
theorem cert_e1211203637358 : check e1211203637358 [[],[]] .chain = true := by decide
def e1211203637534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203637534 : Closed e1211203637534 ∧ code e1211203637534 = 5609250148638 := by decide
theorem cert_e1211203637534 : check e1211203637534 [[],[]] .chain = true := by decide
def e1211203637730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e1211203637730 : Closed e1211203637730 ∧ code e1211203637730 = 5609250148834 := by decide
theorem cert_e1211203637730 : check e1211203637730 [[],[]] .chain = true := by decide
def e1211203637742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 2))))))
theorem wire_e1211203637742 : Closed e1211203637742 ∧ code e1211203637742 = 5609250148846 := by decide
theorem cert_e1211203637742 : check e1211203637742 [[],[]] .sourceHead = true := by decide
def e1211203638126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1211203638126 : Closed e1211203638126 ∧ code e1211203638126 = 5609250149230 := by decide
theorem cert_e1211203638126 : check e1211203638126 [[],[]] .chain = true := by decide
def e1211203638134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1211203638134 : Closed e1211203638134 ∧ code e1211203638134 = 5609250149238 := by decide
theorem cert_e1211203638134 : check e1211203638134 [[],[]] .chain = true := by decide
def e1211203638190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1211203638190 : Closed e1211203638190 ∧ code e1211203638190 = 5609250149294 := by decide
theorem cert_e1211203638190 : check e1211203638190 [[],[]] .chain = true := by decide
def e1211203638202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1211203638202 : Closed e1211203638202 ∧ code e1211203638202 = 5609250149306 := by decide
theorem cert_e1211203638202 : check e1211203638202 [[],[]] .chain = true := by decide
def e1211203638230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1211203638230 : Closed e1211203638230 ∧ code e1211203638230 = 5609250149334 := by decide
theorem cert_e1211203638230 : check e1211203638230 [[],[]] .chain = true := by decide
def e1211203638234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1211203638234 : Closed e1211203638234 ∧ code e1211203638234 = 5609250149338 := by decide
theorem cert_e1211203638234 : check e1211203638234 [[],[]] .chain = true := by decide
end Blc.Floor42
