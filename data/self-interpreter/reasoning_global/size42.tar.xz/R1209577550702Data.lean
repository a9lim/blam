import R1209577550702V0
import R1209577550702K0
import R1209577550702st0
import R1209577550702hs0
import CodeBridge
import Batch131
namespace Certgen.R1209577550702
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 98,.app 2 89,.app 3 80,.app 4 71,.app 5 28,.app 6 25,.app 7 13,.lam 8,.app 9 10,.var 0,.app 11 12,.var 0,.var 0,.lam 14,.lam 15,.app 16 17,.var 1,.lam 18,.app 19 24,.app 20 21,.var 0,.app 22 23,.var 0,.var 1,.var 2,.lam 26,.lam 27,.var 0,.lam 29,.app 30 35,.app 31 32,.var 0,.lam 33,.lam 34,.var 1,.lam 36,.app 37 42,.app 38 39,.var 0,.lam 40,.lam 41,.var 1,.lam 43,.app 44 49,.app 45 46,.var 0,.lam 47,.lam 48,.var 1,.lam 50,.app 51 56,.app 52 53,.var 0,.lam 54,.lam 55,.var 1,.lam 57,.app 58 63,.app 59 60,.var 0,.lam 61,.lam 62,.var 0,.lam 64,.app 65 70,.app 66 67,.var 0,.lam 68,.lam 69,.var 1,.opaque,.app 72 76,.lam 73,.app 74 75,.var 0,.var 0,.lam 77,.app 78 79,.var 0,.var 0,.app 81 85,.lam 82,.app 83 84,.var 0,.var 0,.lam 86,.app 87 88,.var 0,.var 0,.app 90 94,.lam 91,.app 92 93,.var 0,.var 0,.lam 95,.app 96 97,.var 0,.var 0,.app 99 103,.lam 100,.app 101 102,.var 0,.var 0,.lam 104,.app 105 106,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (if i < 40 then (V20[i-20]?.getD []) else (V40[i-40]?.getD [])))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD [])))
def st (i : Nat) : AState := if i < 192 then (if i < 100 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else (if i < 140 then (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)) else (if i < 160 then (st140[i-140]?.getD entry) else (if i < 180 then (st160[i-160]?.getD entry) else (st180[i-180]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 100 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])))) else (if i < 140 then (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD [])) else (if i < 160 then (hs140[i-140]?.getD []) else (if i < 180 then (hs160[i-160]?.getD []) else (hs180[i-180]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R1209577550702
