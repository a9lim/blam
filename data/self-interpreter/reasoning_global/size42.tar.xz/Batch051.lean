import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1129829032298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129829032298 : Closed e1129829032298 ∧ code e1129829032298 = 5527875543402 := by decide
theorem cert_e1129829032298 : check e1129829032298 [[]] .width = true := by decide
def e1129829032346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129829032346 : Closed e1129829032346 ∧ code e1129829032346 = 5527875543450 := by decide
theorem cert_e1129829032346 : check e1129829032346 [[]] .width = true := by decide
def e1129829064730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129829064730 : Closed e1129829064730 ∧ code e1129829064730 = 5527875575834 := by decide
theorem cert_e1129829064730 : check e1129829064730 [[]] .width = true := by decide
def e1129829064822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129829064822 : Closed e1129829064822 ∧ code e1129829064822 = 5527875575926 := by decide
theorem cert_e1129829064822 : check e1129829064822 [[]] .width = true := by decide
def e1129829065066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129829065066 : Closed e1129829065066 ∧ code e1129829065066 = 5527875576170 := by decide
theorem cert_e1129829065066 : check e1129829065066 [[]] .width = true := by decide
def e1129829065114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129829065114 : Closed e1129829065114 ∧ code e1129829065114 = 5527875576218 := by decide
theorem cert_e1129829065114 : check e1129829065114 [[]] .width = true := by decide
def e1129831030810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129831030810 : Closed e1129831030810 ∧ code e1129831030810 = 5527877541914 := by decide
theorem cert_e1129831030810 : check e1129831030810 [[]] .width = true := by decide
def e1129831030902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129831030902 : Closed e1129831030902 ∧ code e1129831030902 = 5527877542006 := by decide
private def t_e1129831030902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e1129831030902 : ¬ IsSelfInterpreter e1129831030902 :=
  wSource (t := t_e1129831030902) (replay_sound (ps := []) (t := e1129831030902) (by decide)) (by decide)
def e1129831031146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129831031146 : Closed e1129831031146 ∧ code e1129831031146 = 5527877542250 := by decide
private def t_e1129831031146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e1129831031146 : ¬ IsSelfInterpreter e1129831031146 :=
  wSource (t := t_e1129831031146) (replay_sound (ps := []) (t := e1129831031146) (by decide)) (by decide)
def e1129831031194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129831031194 : Closed e1129831031194 ∧ code e1129831031194 = 5527877542298 := by decide
private def t_e1129831031194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e1129831031194 : ¬ IsSelfInterpreter e1129831031194 :=
  wSource (t := t_e1129831031194) (replay_sound (ps := []) (t := e1129831031194) (by decide)) (by decide)
def e1129831047194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129831047194 : Closed e1129831047194 ∧ code e1129831047194 = 5527877558298 := by decide
theorem cert_e1129831047194 : check e1129831047194 [[]] .width = true := by decide
def e1129831047286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129831047286 : Closed e1129831047286 ∧ code e1129831047286 = 5527877558390 := by decide
theorem cert_e1129831047286 : check e1129831047286 [[]] .width = true := by decide
def e1129831047530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129831047530 : Closed e1129831047530 ∧ code e1129831047530 = 5527877558634 := by decide
theorem cert_e1129831047530 : check e1129831047530 [[]] .width = true := by decide
def e1129831047578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129831047578 : Closed e1129831047578 ∧ code e1129831047578 = 5527877558682 := by decide
theorem cert_e1129831047578 : check e1129831047578 [[]] .width = true := by decide
def e1129831051462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129831051462 : Closed e1129831051462 ∧ code e1129831051462 = 5527877562566 := by decide
theorem cert_e1129831051462 : check e1129831051462 [[]] .width = true := by decide
def e1129831053338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831053338 : Closed e1129831053338 ∧ code e1129831053338 = 5527877564442 := by decide
theorem cert_e1129831053338 : check e1129831053338 [[]] .width = true := by decide
def e1129831061530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831061530 : Closed e1129831061530 ∧ code e1129831061530 = 5527877572634 := by decide
theorem cert_e1129831061530 : check e1129831061530 [[]] .width = true := by decide
def e1129831112730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129831112730 : Closed e1129831112730 ∧ code e1129831112730 = 5527877623834 := by decide
theorem cert_e1129831112730 : check e1129831112730 [[]] .width = true := by decide
def e1129831112822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129831112822 : Closed e1129831112822 ∧ code e1129831112822 = 5527877623926 := by decide
theorem cert_e1129831112822 : check e1129831112822 [[]] .width = true := by decide
def e1129831113066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129831113066 : Closed e1129831113066 ∧ code e1129831113066 = 5527877624170 := by decide
theorem cert_e1129831113066 : check e1129831113066 [[]] .width = true := by decide
def e1129831113114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129831113114 : Closed e1129831113114 ∧ code e1129831113114 = 5527877624218 := by decide
theorem cert_e1129831113114 : check e1129831113114 [[]] .width = true := by decide
def e1129831116998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129831116998 : Closed e1129831116998 ∧ code e1129831116998 = 5527877628102 := by decide
theorem cert_e1129831116998 : check e1129831116998 [[]] .width = true := by decide
def e1129831118874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831118874 : Closed e1129831118874 ∧ code e1129831118874 = 5527877629978 := by decide
theorem cert_e1129831118874 : check e1129831118874 [[]] .width = true := by decide
def e1129831125190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129831125190 : Closed e1129831125190 ∧ code e1129831125190 = 5527877636294 := by decide
theorem cert_e1129831125190 : check e1129831125190 [[]] .width = true := by decide
def e1129831131162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831131162 : Closed e1129831131162 ∧ code e1129831131162 = 5527877642266 := by decide
theorem cert_e1129831131162 : check e1129831131162 [[]] .width = true := by decide
def e1129831159834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831159834 : Closed e1129831159834 ∧ code e1129831159834 = 5527877670938 := by decide
theorem cert_e1129831159834 : check e1129831159834 [[]] .width = true := by decide
def e1129831163930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831163930 : Closed e1129831163930 ∧ code e1129831163930 = 5527877675034 := by decide
theorem cert_e1129831163930 : check e1129831163930 [[]] .width = true := by decide
def e1129831317702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129831317702 : Closed e1129831317702 ∧ code e1129831317702 = 5527877828806 := by decide
theorem cert_e1129831317702 : check e1129831317702 [[]] .width = true := by decide
def e1129831424026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129831424026 : Closed e1129831424026 ∧ code e1129831424026 = 5527877935130 := by decide
theorem cert_e1129831424026 : check e1129831424026 [[]] .width = true := by decide
def e1129831424118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129831424118 : Closed e1129831424118 ∧ code e1129831424118 = 5527877935222 := by decide
theorem cert_e1129831424118 : check e1129831424118 [[]] .width = true := by decide
def e1129831424362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129831424362 : Closed e1129831424362 ∧ code e1129831424362 = 5527877935466 := by decide
theorem cert_e1129831424362 : check e1129831424362 [[]] .width = true := by decide
def e1129831424410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129831424410 : Closed e1129831424410 ∧ code e1129831424410 = 5527877935514 := by decide
theorem cert_e1129831424410 : check e1129831424410 [[]] .width = true := by decide
def e1129831440410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129831440410 : Closed e1129831440410 ∧ code e1129831440410 = 5527877951514 := by decide
theorem cert_e1129831440410 : check e1129831440410 [[]] .width = true := by decide
def e1129831440502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129831440502 : Closed e1129831440502 ∧ code e1129831440502 = 5527877951606 := by decide
theorem cert_e1129831440502 : check e1129831440502 [[]] .width = true := by decide
def e1129831440746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129831440746 : Closed e1129831440746 ∧ code e1129831440746 = 5527877951850 := by decide
theorem cert_e1129831440746 : check e1129831440746 [[]] .width = true := by decide
def e1129831440794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129831440794 : Closed e1129831440794 ∧ code e1129831440794 = 5527877951898 := by decide
theorem cert_e1129831440794 : check e1129831440794 [[]] .width = true := by decide
def e1129831444678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129831444678 : Closed e1129831444678 ∧ code e1129831444678 = 5527877955782 := by decide
theorem cert_e1129831444678 : check e1129831444678 [[]] .width = true := by decide
def e1129831446554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831446554 : Closed e1129831446554 ∧ code e1129831446554 = 5527877957658 := by decide
theorem cert_e1129831446554 : check e1129831446554 [[]] .width = true := by decide
def e1129831454746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831454746 : Closed e1129831454746 ∧ code e1129831454746 = 5527877965850 := by decide
theorem cert_e1129831454746 : check e1129831454746 [[]] .width = true := by decide
def e1129831596058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129831596058 : Closed e1129831596058 ∧ code e1129831596058 = 5527878107162 := by decide
theorem cert_e1129831596058 : check e1129831596058 [[]] .width = true := by decide
def e1129831596150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129831596150 : Closed e1129831596150 ∧ code e1129831596150 = 5527878107254 := by decide
theorem cert_e1129831596150 : check e1129831596150 [[]] .width = true := by decide
def e1129831596394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129831596394 : Closed e1129831596394 ∧ code e1129831596394 = 5527878107498 := by decide
theorem cert_e1129831596394 : check e1129831596394 [[]] .width = true := by decide
def e1129831596442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129831596442 : Closed e1129831596442 ∧ code e1129831596442 = 5527878107546 := by decide
theorem cert_e1129831596442 : check e1129831596442 [[]] .width = true := by decide
def e1129831596526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129831596526 : Closed e1129831596526 ∧ code e1129831596526 = 5527878107630 := by decide
theorem cert_e1129831596526 : check e1129831596526 [[]] .width = true := by decide
def e1129831597450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129831597450 : Closed e1129831597450 ∧ code e1129831597450 = 5527878108554 := by decide
theorem cert_e1129831597450 : check e1129831597450 [[]] .width = true := by decide
def e1129831597474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129831597474 : Closed e1129831597474 ∧ code e1129831597474 = 5527878108578 := by decide
theorem cert_e1129831597474 : check e1129831597474 [[]] .width = true := by decide
def e1129831597494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129831597494 : Closed e1129831597494 ∧ code e1129831597494 = 5527878108598 := by decide
theorem cert_e1129831597494 : check e1129831597494 [[]] .width = true := by decide
def e1129831597526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129831597526 : Closed e1129831597526 ∧ code e1129831597526 = 5527878108630 := by decide
theorem cert_e1129831597526 : check e1129831597526 [[]] .width = true := by decide
def e1129831597530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129831597530 : Closed e1129831597530 ∧ code e1129831597530 = 5527878108634 := by decide
theorem cert_e1129831597530 : check e1129831597530 [[]] .width = true := by decide
def e1129831597582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129831597582 : Closed e1129831597582 ∧ code e1129831597582 = 5527878108686 := by decide
theorem cert_e1129831597582 : check e1129831597582 [[]] .width = true := by decide
def e1129831597594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129831597594 : Closed e1129831597594 ∧ code e1129831597594 = 5527878108698 := by decide
theorem cert_e1129831597594 : check e1129831597594 [[]] .width = true := by decide
def e1129831597666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129831597666 : Closed e1129831597666 ∧ code e1129831597666 = 5527878108770 := by decide
theorem cert_e1129831597666 : check e1129831597666 [[]] .width = true := by decide
def e1129831597686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129831597686 : Closed e1129831597686 ∧ code e1129831597686 = 5527878108790 := by decide
theorem cert_e1129831597686 : check e1129831597686 [[]] .width = true := by decide
def e1129831597878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129831597878 : Closed e1129831597878 ∧ code e1129831597878 = 5527878108982 := by decide
theorem cert_e1129831597878 : check e1129831597878 [[]] .width = true := by decide
def e1129831597882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129831597882 : Closed e1129831597882 ∧ code e1129831597882 = 5527878108986 := by decide
theorem cert_e1129831597882 : check e1129831597882 [[]] .width = true := by decide
def e1129831601578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129831601578 : Closed e1129831601578 ∧ code e1129831601578 = 5527878112682 := by decide
theorem cert_e1129831601578 : check e1129831601578 [[]] .width = true := by decide
def e1129831601674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129831601674 : Closed e1129831601674 ∧ code e1129831601674 = 5527878112778 := by decide
theorem cert_e1129831601674 : check e1129831601674 [[]] .width = true := by decide
def e1129831601770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129831601770 : Closed e1129831601770 ∧ code e1129831601770 = 5527878112874 := by decide
theorem cert_e1129831601770 : check e1129831601770 [[]] .width = true := by decide
def e1129831601794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129831601794 : Closed e1129831601794 ∧ code e1129831601794 = 5527878112898 := by decide
theorem cert_e1129831601794 : check e1129831601794 [[]] .width = true := by decide
def e1129831601818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129831601818 : Closed e1129831601818 ∧ code e1129831601818 = 5527878112922 := by decide
theorem cert_e1129831601818 : check e1129831601818 [[]] .width = true := by decide
def e1129831602202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129831602202 : Closed e1129831602202 ∧ code e1129831602202 = 5527878113306 := by decide
theorem cert_e1129831602202 : check e1129831602202 [[]] .width = true := by decide
def e1129831602294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129831602294 : Closed e1129831602294 ∧ code e1129831602294 = 5527878113398 := by decide
theorem cert_e1129831602294 : check e1129831602294 [[]] .width = true := by decide
def e1129831602538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129831602538 : Closed e1129831602538 ∧ code e1129831602538 = 5527878113642 := by decide
theorem cert_e1129831602538 : check e1129831602538 [[]] .width = true := by decide
def e1129831602562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129831602562 : Closed e1129831602562 ∧ code e1129831602562 = 5527878113666 := by decide
theorem cert_e1129831602562 : check e1129831602562 [[]] .width = true := by decide
def e1129831602586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129831602586 : Closed e1129831602586 ∧ code e1129831602586 = 5527878113690 := by decide
theorem cert_e1129831602586 : check e1129831602586 [[]] .width = true := by decide
def e1129831776454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1129831776454 : Closed e1129831776454 ∧ code e1129831776454 = 5527878287558 := by decide
theorem cert_e1129831776454 : check e1129831776454 [[]] .width = true := by decide
def e1129831833626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e1129831833626 : Closed e1129831833626 ∧ code e1129831833626 = 5527878344730 := by decide
theorem cert_e1129831833626 : check e1129831833626 [[]] .width = true := by decide
def e1129831833718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e1129831833718 : Closed e1129831833718 ∧ code e1129831833718 = 5527878344822 := by decide
theorem cert_e1129831833718 : check e1129831833718 [[]] .width = true := by decide
def e1129831833962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e1129831833962 : Closed e1129831833962 ∧ code e1129831833962 = 5527878345066 := by decide
theorem cert_e1129831833962 : check e1129831833962 [[]] .width = true := by decide
def e1129831834010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e1129831834010 : Closed e1129831834010 ∧ code e1129831834010 = 5527878345114 := by decide
theorem cert_e1129831834010 : check e1129831834010 [[]] .width = true := by decide
def e1129831837894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129831837894 : Closed e1129831837894 ∧ code e1129831837894 = 5527878348998 := by decide
theorem cert_e1129831837894 : check e1129831837894 [[]] .width = true := by decide
def e1129831839770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831839770 : Closed e1129831839770 ∧ code e1129831839770 = 5527878350874 := by decide
theorem cert_e1129831839770 : check e1129831839770 [[]] .width = true := by decide
def e1129831846086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1129831846086 : Closed e1129831846086 ∧ code e1129831846086 = 5527878357190 := by decide
theorem cert_e1129831846086 : check e1129831846086 [[]] .width = true := by decide
def e1129831852058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129831852058 : Closed e1129831852058 ∧ code e1129831852058 = 5527878363162 := by decide
theorem cert_e1129831852058 : check e1129831852058 [[]] .width = true := by decide
def e1129831858202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1129831858202 : Closed e1129831858202 ∧ code e1129831858202 = 5527878369306 := by decide
theorem cert_e1129831858202 : check e1129831858202 [[]] .width = true := by decide
def e1129831858294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e1129831858294 : Closed e1129831858294 ∧ code e1129831858294 = 5527878369398 := by decide
theorem cert_e1129831858294 : check e1129831858294 [[]] .width = true := by decide
def e1129831858538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e1129831858538 : Closed e1129831858538 ∧ code e1129831858538 = 5527878369642 := by decide
theorem cert_e1129831858538 : check e1129831858538 [[]] .width = true := by decide
def e1129831858586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e1129831858586 : Closed e1129831858586 ∧ code e1129831858586 = 5527878369690 := by decide
theorem cert_e1129831858586 : check e1129831858586 [[]] .width = true := by decide
def e1129831858670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e1129831858670 : Closed e1129831858670 ∧ code e1129831858670 = 5527878369774 := by decide
theorem cert_e1129831858670 : check e1129831858670 [[]] .width = true := by decide
def e1129831859594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e1129831859594 : Closed e1129831859594 ∧ code e1129831859594 = 5527878370698 := by decide
theorem cert_e1129831859594 : check e1129831859594 [[]] .width = true := by decide
def e1129831859618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e1129831859618 : Closed e1129831859618 ∧ code e1129831859618 = 5527878370722 := by decide
theorem cert_e1129831859618 : check e1129831859618 [[]] .width = true := by decide
def e1129831859638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e1129831859638 : Closed e1129831859638 ∧ code e1129831859638 = 5527878370742 := by decide
theorem cert_e1129831859638 : check e1129831859638 [[]] .width = true := by decide
def e1129831859670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e1129831859670 : Closed e1129831859670 ∧ code e1129831859670 = 5527878370774 := by decide
theorem cert_e1129831859670 : check e1129831859670 [[]] .width = true := by decide
def e1129831859674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e1129831859674 : Closed e1129831859674 ∧ code e1129831859674 = 5527878370778 := by decide
theorem cert_e1129831859674 : check e1129831859674 [[]] .width = true := by decide
def e1129831859726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e1129831859726 : Closed e1129831859726 ∧ code e1129831859726 = 5527878370830 := by decide
theorem cert_e1129831859726 : check e1129831859726 [[]] .width = true := by decide
def e1129831859738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129831859738 : Closed e1129831859738 ∧ code e1129831859738 = 5527878370842 := by decide
theorem cert_e1129831859738 : check e1129831859738 [[]] .width = true := by decide
def e1129831859810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e1129831859810 : Closed e1129831859810 ∧ code e1129831859810 = 5527878370914 := by decide
theorem cert_e1129831859810 : check e1129831859810 [[]] .width = true := by decide
def e1129831859830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e1129831859830 : Closed e1129831859830 ∧ code e1129831859830 = 5527878370934 := by decide
theorem cert_e1129831859830 : check e1129831859830 [[]] .width = true := by decide
def e1129831860022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e1129831860022 : Closed e1129831860022 ∧ code e1129831860022 = 5527878371126 := by decide
theorem cert_e1129831860022 : check e1129831860022 [[]] .width = true := by decide
def e1129831860026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e1129831860026 : Closed e1129831860026 ∧ code e1129831860026 = 5527878371130 := by decide
theorem cert_e1129831860026 : check e1129831860026 [[]] .width = true := by decide
def e1129831863722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e1129831863722 : Closed e1129831863722 ∧ code e1129831863722 = 5527878374826 := by decide
theorem cert_e1129831863722 : check e1129831863722 [[]] .width = true := by decide
def e1129831863818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e1129831863818 : Closed e1129831863818 ∧ code e1129831863818 = 5527878374922 := by decide
theorem cert_e1129831863818 : check e1129831863818 [[]] .width = true := by decide
def e1129831863914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e1129831863914 : Closed e1129831863914 ∧ code e1129831863914 = 5527878375018 := by decide
theorem cert_e1129831863914 : check e1129831863914 [[]] .width = true := by decide
def e1129831863938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e1129831863938 : Closed e1129831863938 ∧ code e1129831863938 = 5527878375042 := by decide
theorem cert_e1129831863938 : check e1129831863938 [[]] .width = true := by decide
def e1129831863962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e1129831863962 : Closed e1129831863962 ∧ code e1129831863962 = 5527878375066 := by decide
theorem cert_e1129831863962 : check e1129831863962 [[]] .width = true := by decide
def e1129831864346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e1129831864346 : Closed e1129831864346 ∧ code e1129831864346 = 5527878375450 := by decide
theorem cert_e1129831864346 : check e1129831864346 [[]] .width = true := by decide
def e1129831864438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e1129831864438 : Closed e1129831864438 ∧ code e1129831864438 = 5527878375542 := by decide
theorem cert_e1129831864438 : check e1129831864438 [[]] .width = true := by decide
def e1129831864682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e1129831864682 : Closed e1129831864682 ∧ code e1129831864682 = 5527878375786 := by decide
theorem cert_e1129831864682 : check e1129831864682 [[]] .width = true := by decide
def e1129831864706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e1129831864706 : Closed e1129831864706 ∧ code e1129831864706 = 5527878375810 := by decide
theorem cert_e1129831864706 : check e1129831864706 [[]] .width = true := by decide
def e1129831864730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e1129831864730 : Closed e1129831864730 ∧ code e1129831864730 = 5527878375834 := by decide
theorem cert_e1129831864730 : check e1129831864730 [[]] .width = true := by decide
def e1129832044570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129832044570 : Closed e1129832044570 ∧ code e1129832044570 = 5527878555674 := by decide
theorem cert_e1129832044570 : check e1129832044570 [[]] .width = true := by decide
def e1129832048666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1129832048666 : Closed e1129832048666 ∧ code e1129832048666 = 5527878559770 := by decide
theorem cert_e1129832048666 : check e1129832048666 [[]] .width = true := by decide
def e1130046205294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1130046205294 : Closed e1130046205294 ∧ code e1130046205294 = 5528092716398 := by decide
theorem cert_e1130046205294 : check e1130046205294 [[],[.under]] .smaller = true := by decide
def e1130046205302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1130046205302 : Closed e1130046205302 ∧ code e1130046205302 = 5528092716406 := by decide
theorem cert_e1130046205302 : check e1130046205302 [[],[.under]] .smaller = true := by decide
def e1130046205358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1130046205358 : Closed e1130046205358 ∧ code e1130046205358 = 5528092716462 := by decide
theorem cert_e1130046205358 : check e1130046205358 [[],[.under]] .smaller = true := by decide
def e1130046205370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1130046205370 : Closed e1130046205370 ∧ code e1130046205370 = 5528092716474 := by decide
theorem cert_e1130046205370 : check e1130046205370 [[],[.under]] .smaller = true := by decide
def e1130046205398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1130046205398 : Closed e1130046205398 ∧ code e1130046205398 = 5528092716502 := by decide
theorem cert_e1130046205398 : check e1130046205398 [[],[.under]] .smaller = true := by decide
def e1130046205402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1130046205402 : Closed e1130046205402 ∧ code e1130046205402 = 5528092716506 := by decide
theorem cert_e1130046205402 : check e1130046205402 [[],[.under]] .smaller = true := by decide
def e1130046205614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1130046205614 : Closed e1130046205614 ∧ code e1130046205614 = 5528092716718 := by decide
theorem cert_e1130046205614 : check e1130046205614 [[],[.under]] .smaller = true := by decide
def e1130046205626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1130046205626 : Closed e1130046205626 ∧ code e1130046205626 = 5528092716730 := by decide
theorem cert_e1130046205626 : check e1130046205626 [[],[.under]] .smaller = true := by decide
def e1130046205674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1130046205674 : Closed e1130046205674 ∧ code e1130046205674 = 5528092716778 := by decide
theorem cert_e1130046205674 : check e1130046205674 [[],[.under]] .smaller = true := by decide
def e1130046205782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1130046205782 : Closed e1130046205782 ∧ code e1130046205782 = 5528092716886 := by decide
theorem cert_e1130046205782 : check e1130046205782 [[],[.under]] .smaller = true := by decide
def e1130046205786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1130046205786 : Closed e1130046205786 ∧ code e1130046205786 = 5528092716890 := by decide
theorem cert_e1130046205786 : check e1130046205786 [[],[.under]] .smaller = true := by decide
def e1130046205802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1130046205802 : Closed e1130046205802 ∧ code e1130046205802 = 5528092716906 := by decide
theorem cert_e1130046205802 : check e1130046205802 [[],[.under]] .smaller = true := by decide
def e1130046206830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1130046206830 : Closed e1130046206830 ∧ code e1130046206830 = 5528092717934 := by decide
theorem cert_e1130046206830 : check e1130046206830 [[],[.under]] .smaller = true := by decide
def e1130046206838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1130046206838 : Closed e1130046206838 ∧ code e1130046206838 = 5528092717942 := by decide
theorem cert_e1130046206838 : check e1130046206838 [[],[.under]] .smaller = true := by decide
def e1130046206894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1130046206894 : Closed e1130046206894 ∧ code e1130046206894 = 5528092717998 := by decide
theorem cert_e1130046206894 : check e1130046206894 [[],[.under]] .smaller = true := by decide
def e1130046206906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1130046206906 : Closed e1130046206906 ∧ code e1130046206906 = 5528092718010 := by decide
theorem cert_e1130046206906 : check e1130046206906 [[],[.under]] .smaller = true := by decide
def e1130046206934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1130046206934 : Closed e1130046206934 ∧ code e1130046206934 = 5528092718038 := by decide
theorem cert_e1130046206934 : check e1130046206934 [[],[.under]] .smaller = true := by decide
def e1130046206938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1130046206938 : Closed e1130046206938 ∧ code e1130046206938 = 5528092718042 := by decide
theorem cert_e1130046206938 : check e1130046206938 [[],[.under]] .smaller = true := by decide
def e1130046207214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1130046207214 : Closed e1130046207214 ∧ code e1130046207214 = 5528092718318 := by decide
theorem cert_e1130046207214 : check e1130046207214 [[],[.under]] .smaller = true := by decide
def e1130046207222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1130046207222 : Closed e1130046207222 ∧ code e1130046207222 = 5528092718326 := by decide
theorem cert_e1130046207222 : check e1130046207222 [[],[.under]] .smaller = true := by decide
def e1130046207598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1130046207598 : Closed e1130046207598 ∧ code e1130046207598 = 5528092718702 := by decide
theorem cert_e1130046207598 : check e1130046207598 [[],[.under]] .smaller = true := by decide
def e1130046207610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1130046207610 : Closed e1130046207610 ∧ code e1130046207610 = 5528092718714 := by decide
theorem cert_e1130046207610 : check e1130046207610 [[],[.under]] .smaller = true := by decide
def e1130046207798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1130046207798 : Closed e1130046207798 ∧ code e1130046207798 = 5528092718902 := by decide
theorem cert_e1130046207798 : check e1130046207798 [[],[.under]] .smaller = true := by decide
def e1130046207802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1130046207802 : Closed e1130046207802 ∧ code e1130046207802 = 5528092718906 := by decide
theorem cert_e1130046207802 : check e1130046207802 [[],[.under]] .smaller = true := by decide
def e1130046208430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1130046208430 : Closed e1130046208430 ∧ code e1130046208430 = 5528092719534 := by decide
theorem cert_e1130046208430 : check e1130046208430 [[],[.under]] .smaller = true := by decide
def e1130046208442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1130046208442 : Closed e1130046208442 ∧ code e1130046208442 = 5528092719546 := by decide
theorem cert_e1130046208442 : check e1130046208442 [[],[.under]] .smaller = true := by decide
def e1130046208490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1130046208490 : Closed e1130046208490 ∧ code e1130046208490 = 5528092719594 := by decide
theorem cert_e1130046208490 : check e1130046208490 [[],[.under]] .smaller = true := by decide
def e1130046208622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1130046208622 : Closed e1130046208622 ∧ code e1130046208622 = 5528092719726 := by decide
theorem cert_e1130046208622 : check e1130046208622 [[],[.under]] .smaller = true := by decide
def e1130046208634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1130046208634 : Closed e1130046208634 ∧ code e1130046208634 = 5528092719738 := by decide
theorem cert_e1130046208634 : check e1130046208634 [[],[.under]] .smaller = true := by decide
def e1130046208922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1130046208922 : Closed e1130046208922 ∧ code e1130046208922 = 5528092720026 := by decide
theorem cert_e1130046208922 : check e1130046208922 [[],[.under]] .smaller = true := by decide
def e1130046209238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1130046209238 : Closed e1130046209238 ∧ code e1130046209238 = 5528092720342 := by decide
theorem cert_e1130046209238 : check e1130046209238 [[],[.under]] .smaller = true := by decide
def e1130046209242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1130046209242 : Closed e1130046209242 ∧ code e1130046209242 = 5528092720346 := by decide
theorem cert_e1130046209242 : check e1130046209242 [[],[.under]] .smaller = true := by decide
def e1130046209258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1130046209258 : Closed e1130046209258 ∧ code e1130046209258 = 5528092720362 := by decide
theorem cert_e1130046209258 : check e1130046209258 [[],[.under]] .smaller = true := by decide
def e1130046209334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1130046209334 : Closed e1130046209334 ∧ code e1130046209334 = 5528092720438 := by decide
theorem cert_e1130046209334 : check e1130046209334 [[],[.under]] .smaller = true := by decide
def e1130046209338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1130046209338 : Closed e1130046209338 ∧ code e1130046209338 = 5528092720442 := by decide
theorem cert_e1130046209338 : check e1130046209338 [[],[.under]] .smaller = true := by decide
def e1130046209434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1130046209434 : Closed e1130046209434 ∧ code e1130046209434 = 5528092720538 := by decide
theorem cert_e1130046209434 : check e1130046209434 [[],[.under]] .smaller = true := by decide
def e1130046212974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1130046212974 : Closed e1130046212974 ∧ code e1130046212974 = 5528092724078 := by decide
theorem cert_e1130046212974 : check e1130046212974 [[],[.under]] .smaller = true := by decide
def e1130046212982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1130046212982 : Closed e1130046212982 ∧ code e1130046212982 = 5528092724086 := by decide
theorem cert_e1130046212982 : check e1130046212982 [[],[.under]] .smaller = true := by decide
def e1130046213038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1130046213038 : Closed e1130046213038 ∧ code e1130046213038 = 5528092724142 := by decide
theorem cert_e1130046213038 : check e1130046213038 [[],[.under]] .smaller = true := by decide
def e1130046213050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1130046213050 : Closed e1130046213050 ∧ code e1130046213050 = 5528092724154 := by decide
theorem cert_e1130046213050 : check e1130046213050 [[],[.under]] .smaller = true := by decide
def e1130046213078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1130046213078 : Closed e1130046213078 ∧ code e1130046213078 = 5528092724182 := by decide
theorem cert_e1130046213078 : check e1130046213078 [[],[.under]] .smaller = true := by decide
def e1130046213082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1130046213082 : Closed e1130046213082 ∧ code e1130046213082 = 5528092724186 := by decide
theorem cert_e1130046213082 : check e1130046213082 [[],[.under]] .smaller = true := by decide
def e1130046213358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1130046213358 : Closed e1130046213358 ∧ code e1130046213358 = 5528092724462 := by decide
theorem cert_e1130046213358 : check e1130046213358 [[],[.under]] .smaller = true := by decide
def e1130046213366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1130046213366 : Closed e1130046213366 ∧ code e1130046213366 = 5528092724470 := by decide
theorem cert_e1130046213366 : check e1130046213366 [[],[.under]] .smaller = true := by decide
def e1130046213742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1130046213742 : Closed e1130046213742 ∧ code e1130046213742 = 5528092724846 := by decide
theorem cert_e1130046213742 : check e1130046213742 [[],[.under]] .smaller = true := by decide
def e1130046213754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1130046213754 : Closed e1130046213754 ∧ code e1130046213754 = 5528092724858 := by decide
theorem cert_e1130046213754 : check e1130046213754 [[],[.under]] .smaller = true := by decide
def e1130046213942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1130046213942 : Closed e1130046213942 ∧ code e1130046213942 = 5528092725046 := by decide
theorem cert_e1130046213942 : check e1130046213942 [[],[.under]] .smaller = true := by decide
def e1130046213946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1130046213946 : Closed e1130046213946 ∧ code e1130046213946 = 5528092725050 := by decide
theorem cert_e1130046213946 : check e1130046213946 [[],[.under]] .smaller = true := by decide
def e1130046219694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1130046219694 : Closed e1130046219694 ∧ code e1130046219694 = 5528092730798 := by decide
theorem cert_e1130046219694 : check e1130046219694 [[],[.under]] .smaller = true := by decide
def e1130046219706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1130046219706 : Closed e1130046219706 ∧ code e1130046219706 = 5528092730810 := by decide
theorem cert_e1130046219706 : check e1130046219706 [[],[.under]] .smaller = true := by decide
def e1130046219754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1130046219754 : Closed e1130046219754 ∧ code e1130046219754 = 5528092730858 := by decide
theorem cert_e1130046219754 : check e1130046219754 [[],[.under]] .smaller = true := by decide
def e1130046219886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1130046219886 : Closed e1130046219886 ∧ code e1130046219886 = 5528092730990 := by decide
theorem cert_e1130046219886 : check e1130046219886 [[],[.under]] .smaller = true := by decide
def e1130046219898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1130046219898 : Closed e1130046219898 ∧ code e1130046219898 = 5528092731002 := by decide
theorem cert_e1130046219898 : check e1130046219898 [[],[.under]] .smaller = true := by decide
def e1130046220186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1130046220186 : Closed e1130046220186 ∧ code e1130046220186 = 5528092731290 := by decide
theorem cert_e1130046220186 : check e1130046220186 [[],[.under]] .smaller = true := by decide
def e1130046223062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1130046223062 : Closed e1130046223062 ∧ code e1130046223062 = 5528092734166 := by decide
theorem cert_e1130046223062 : check e1130046223062 [[],[.under]] .smaller = true := by decide
def e1130046223066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1130046223066 : Closed e1130046223066 ∧ code e1130046223066 = 5528092734170 := by decide
theorem cert_e1130046223066 : check e1130046223066 [[],[.under]] .smaller = true := by decide
def e1130046223082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1130046223082 : Closed e1130046223082 ∧ code e1130046223082 = 5528092734186 := by decide
theorem cert_e1130046223082 : check e1130046223082 [[],[.under]] .smaller = true := by decide
def e1130046223158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1130046223158 : Closed e1130046223158 ∧ code e1130046223158 = 5528092734262 := by decide
theorem cert_e1130046223158 : check e1130046223158 [[],[.under]] .smaller = true := by decide
end Blc.Floor42
