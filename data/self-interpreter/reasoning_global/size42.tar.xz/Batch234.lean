import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211275253686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211275253686 : Closed e1211275253686 ∧ code e1211275253686 = 5609321764790 := by decide
theorem cert_e1211275253686 : check e1211275253686 [[],[]] .chain = true := by decide
def e1211275255022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211275255022 : Closed e1211275255022 ∧ code e1211275255022 = 5609321766126 := by decide
theorem cert_e1211275255022 : check e1211275255022 [[],[]] .chain = true := by decide
def e1211275255030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211275255030 : Closed e1211275255030 ∧ code e1211275255030 = 5609321766134 := by decide
theorem cert_e1211275255030 : check e1211275255030 [[],[]] .chain = true := by decide
def e1211275255414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211275255414 : Closed e1211275255414 ∧ code e1211275255414 = 5609321766518 := by decide
theorem cert_e1211275255414 : check e1211275255414 [[],[]] .chain = true := by decide
def e1211275266926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211275266926 : Closed e1211275266926 ∧ code e1211275266926 = 5609321778030 := by decide
theorem cert_e1211275266926 : check e1211275266926 [[],[]] .chain = true := by decide
def e1211275266934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211275266934 : Closed e1211275266934 ∧ code e1211275266934 = 5609321778038 := by decide
theorem cert_e1211275266934 : check e1211275266934 [[],[]] .chain = true := by decide
def e1211275266990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211275266990 : Closed e1211275266990 ∧ code e1211275266990 = 5609321778094 := by decide
theorem cert_e1211275266990 : check e1211275266990 [[],[]] .chain = true := by decide
def e1211275267002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211275267002 : Closed e1211275267002 ∧ code e1211275267002 = 5609321778106 := by decide
theorem cert_e1211275267002 : check e1211275267002 [[],[]] .chain = true := by decide
def e1211275267030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211275267030 : Closed e1211275267030 ∧ code e1211275267030 = 5609321778134 := by decide
theorem cert_e1211275267030 : check e1211275267030 [[],[]] .chain = true := by decide
def e1211275267034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211275267034 : Closed e1211275267034 ∧ code e1211275267034 = 5609321778138 := by decide
theorem cert_e1211275267034 : check e1211275267034 [[],[]] .chain = true := by decide
def e1211275267310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211275267310 : Closed e1211275267310 ∧ code e1211275267310 = 5609321778414 := by decide
theorem cert_e1211275267310 : check e1211275267310 [[],[]] .chain = true := by decide
def e1211275267318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211275267318 : Closed e1211275267318 ∧ code e1211275267318 = 5609321778422 := by decide
theorem cert_e1211275267318 : check e1211275267318 [[],[]] .chain = true := by decide
def e1211275267694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211275267694 : Closed e1211275267694 ∧ code e1211275267694 = 5609321778798 := by decide
theorem cert_e1211275267694 : check e1211275267694 [[],[]] .chain = true := by decide
def e1211275267706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211275267706 : Closed e1211275267706 ∧ code e1211275267706 = 5609321778810 := by decide
theorem cert_e1211275267706 : check e1211275267706 [[],[]] .chain = true := by decide
def e1211275267894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211275267894 : Closed e1211275267894 ∧ code e1211275267894 = 5609321778998 := by decide
theorem cert_e1211275267894 : check e1211275267894 [[],[]] .chain = true := by decide
def e1211275267898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211275267898 : Closed e1211275267898 ∧ code e1211275267898 = 5609321779002 := by decide
theorem cert_e1211275267898 : check e1211275267898 [[],[]] .chain = true := by decide
def e1211275273654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211275273654 : Closed e1211275273654 ∧ code e1211275273654 = 5609321784758 := by decide
theorem cert_e1211275273654 : check e1211275273654 [[],[]] .chain = true := by decide
def e1211275273686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211275273686 : Closed e1211275273686 ∧ code e1211275273686 = 5609321784790 := by decide
theorem cert_e1211275273686 : check e1211275273686 [[],[]] .chain = true := by decide
def e1211275273690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211275273690 : Closed e1211275273690 ∧ code e1211275273690 = 5609321784794 := by decide
theorem cert_e1211275273690 : check e1211275273690 [[],[]] .chain = true := by decide
def e1211275273846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211275273846 : Closed e1211275273846 ∧ code e1211275273846 = 5609321784950 := by decide
theorem cert_e1211275273846 : check e1211275273846 [[],[]] .chain = true := by decide
def e1211275274038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211275274038 : Closed e1211275274038 ∧ code e1211275274038 = 5609321785142 := by decide
theorem cert_e1211275274038 : check e1211275274038 [[],[]] .chain = true := by decide
def e1211275274042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211275274042 : Closed e1211275274042 ∧ code e1211275274042 = 5609321785146 := by decide
theorem cert_e1211275274042 : check e1211275274042 [[],[]] .chain = true := by decide
def e1211275610990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211275610990 : Closed e1211275610990 ∧ code e1211275610990 = 5609322122094 := by decide
theorem cert_e1211275610990 : check e1211275610990 [[],[]] .sourceHead = true := by decide
def e1211275610998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211275610998 : Closed e1211275610998 ∧ code e1211275610998 = 5609322122102 := by decide
theorem cert_e1211275610998 : check e1211275610998 [[],[]] .sourceHead = true := by decide
def e1211275611054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211275611054 : Closed e1211275611054 ∧ code e1211275611054 = 5609322122158 := by decide
theorem cert_e1211275611054 : check e1211275611054 [[],[]] .sourceHead = true := by decide
def e1211275611066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211275611066 : Closed e1211275611066 ∧ code e1211275611066 = 5609322122170 := by decide
theorem cert_e1211275611066 : check e1211275611066 [[],[]] .sourceHead = true := by decide
def e1211275611094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211275611094 : Closed e1211275611094 ∧ code e1211275611094 = 5609322122198 := by decide
theorem cert_e1211275611094 : check e1211275611094 [[],[]] .sourceHead = true := by decide
def e1211275611098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211275611098 : Closed e1211275611098 ∧ code e1211275611098 = 5609322122202 := by decide
theorem cert_e1211275611098 : check e1211275611098 [[],[]] .sourceHead = true := by decide
def e1211275611374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211275611374 : Closed e1211275611374 ∧ code e1211275611374 = 5609322122478 := by decide
theorem cert_e1211275611374 : check e1211275611374 [[],[]] .sourceHead = true := by decide
def e1211275611382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211275611382 : Closed e1211275611382 ∧ code e1211275611382 = 5609322122486 := by decide
theorem cert_e1211275611382 : check e1211275611382 [[],[]] .sourceHead = true := by decide
def e1211275611758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211275611758 : Closed e1211275611758 ∧ code e1211275611758 = 5609322122862 := by decide
theorem cert_e1211275611758 : check e1211275611758 [[],[]] .sourceHead = true := by decide
def e1211275611770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211275611770 : Closed e1211275611770 ∧ code e1211275611770 = 5609322122874 := by decide
theorem cert_e1211275611770 : check e1211275611770 [[],[]] .sourceHead = true := by decide
def e1211275611958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211275611958 : Closed e1211275611958 ∧ code e1211275611958 = 5609322123062 := by decide
theorem cert_e1211275611958 : check e1211275611958 [[],[]] .sourceHead = true := by decide
def e1211275611962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211275611962 : Closed e1211275611962 ∧ code e1211275611962 = 5609322123066 := by decide
theorem cert_e1211275611962 : check e1211275611962 [[],[]] .sourceHead = true := by decide
def e1211276209630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e1211276209630 : Closed e1211276209630 ∧ code e1211276209630 = 5609322720734 := by decide
theorem cert_e1211276209630 : check e1211276209630 [[],[]] .sourceHead = true := by decide
def e1211276209646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e1211276209646 : Closed e1211276209646 ∧ code e1211276209646 = 5609322720750 := by decide
theorem cert_e1211276209646 : check e1211276209646 [[],[]] .sourceHead = true := by decide
def e1211276210014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e1211276210014 : Closed e1211276210014 ∧ code e1211276210014 = 5609322721118 := by decide
theorem cert_e1211276210014 : check e1211276210014 [[],[]] .sourceHead = true := by decide
def e1211276210042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e1211276210042 : Closed e1211276210042 ∧ code e1211276210042 = 5609322721146 := by decide
theorem cert_e1211276210042 : check e1211276210042 [[],[]] .sourceHead = true := by decide
def e1211276210094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e1211276210094 : Closed e1211276210094 ∧ code e1211276210094 = 5609322721198 := by decide
theorem cert_e1211276210094 : check e1211276210094 [[],[]] .sourceHead = true := by decide
def e1211276210106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e1211276210106 : Closed e1211276210106 ∧ code e1211276210106 = 5609322721210 := by decide
theorem cert_e1211276210106 : check e1211276210106 [[],[]] .sourceHead = true := by decide
def e1211276211166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211276211166 : Closed e1211276211166 ∧ code e1211276211166 = 5609322722270 := by decide
theorem cert_e1211276211166 : check e1211276211166 [[],[]] .sourceHead = true := by decide
def e1211276211182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211276211182 : Closed e1211276211182 ∧ code e1211276211182 = 5609322722286 := by decide
theorem cert_e1211276211182 : check e1211276211182 [[],[]] .sourceHead = true := by decide
def e1211276213470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211276213470 : Closed e1211276213470 ∧ code e1211276213470 = 5609322724574 := by decide
theorem cert_e1211276213470 : check e1211276213470 [[],[]] .sourceHead = true := by decide
def e1211276213498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211276213498 : Closed e1211276213498 ∧ code e1211276213498 = 5609322724602 := by decide
theorem cert_e1211276213498 : check e1211276213498 [[],[]] .sourceHead = true := by decide
def e1211276213870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211276213870 : Closed e1211276213870 ∧ code e1211276213870 = 5609322724974 := by decide
theorem cert_e1211276213870 : check e1211276213870 [[],[]] .sourceHead = true := by decide
def e1211276213882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211276213882 : Closed e1211276213882 ∧ code e1211276213882 = 5609322724986 := by decide
theorem cert_e1211276213882 : check e1211276213882 [[],[]] .sourceHead = true := by decide
def e1211276242286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211276242286 : Closed e1211276242286 ∧ code e1211276242286 = 5609322753390 := by decide
theorem cert_e1211276242286 : check e1211276242286 [[],[]] .sourceHead = true := by decide
def e1211276242294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211276242294 : Closed e1211276242294 ∧ code e1211276242294 = 5609322753398 := by decide
theorem cert_e1211276242294 : check e1211276242294 [[],[]] .sourceHead = true := by decide
def e1211276242350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211276242350 : Closed e1211276242350 ∧ code e1211276242350 = 5609322753454 := by decide
theorem cert_e1211276242350 : check e1211276242350 [[],[]] .sourceHead = true := by decide
def e1211276242362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211276242362 : Closed e1211276242362 ∧ code e1211276242362 = 5609322753466 := by decide
theorem cert_e1211276242362 : check e1211276242362 [[],[]] .sourceHead = true := by decide
def e1211276242390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211276242390 : Closed e1211276242390 ∧ code e1211276242390 = 5609322753494 := by decide
theorem cert_e1211276242390 : check e1211276242390 [[],[]] .sourceHead = true := by decide
def e1211276242394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211276242394 : Closed e1211276242394 ∧ code e1211276242394 = 5609322753498 := by decide
theorem cert_e1211276242394 : check e1211276242394 [[],[]] .sourceHead = true := by decide
def e1211276242606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211276242606 : Closed e1211276242606 ∧ code e1211276242606 = 5609322753710 := by decide
theorem cert_e1211276242606 : check e1211276242606 [[],[]] .sourceHead = true := by decide
def e1211276242618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211276242618 : Closed e1211276242618 ∧ code e1211276242618 = 5609322753722 := by decide
theorem cert_e1211276242618 : check e1211276242618 [[],[]] .sourceHead = true := by decide
def e1211276242666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211276242666 : Closed e1211276242666 ∧ code e1211276242666 = 5609322753770 := by decide
theorem cert_e1211276242666 : check e1211276242666 [[],[]] .sourceHead = true := by decide
def e1211276242774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211276242774 : Closed e1211276242774 ∧ code e1211276242774 = 5609322753878 := by decide
theorem cert_e1211276242774 : check e1211276242774 [[],[]] .sourceHead = true := by decide
def e1211276242778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211276242778 : Closed e1211276242778 ∧ code e1211276242778 = 5609322753882 := by decide
theorem cert_e1211276242778 : check e1211276242778 [[],[]] .sourceHead = true := by decide
def e1211276242794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211276242794 : Closed e1211276242794 ∧ code e1211276242794 = 5609322753898 := by decide
theorem cert_e1211276242794 : check e1211276242794 [[],[]] .sourceHead = true := by decide
def e1211276243822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211276243822 : Closed e1211276243822 ∧ code e1211276243822 = 5609322754926 := by decide
theorem cert_e1211276243822 : check e1211276243822 [[],[]] .sourceHead = true := by decide
def e1211276243830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211276243830 : Closed e1211276243830 ∧ code e1211276243830 = 5609322754934 := by decide
theorem cert_e1211276243830 : check e1211276243830 [[],[]] .sourceHead = true := by decide
def e1211276243886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211276243886 : Closed e1211276243886 ∧ code e1211276243886 = 5609322754990 := by decide
theorem cert_e1211276243886 : check e1211276243886 [[],[]] .sourceHead = true := by decide
def e1211276243898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211276243898 : Closed e1211276243898 ∧ code e1211276243898 = 5609322755002 := by decide
theorem cert_e1211276243898 : check e1211276243898 [[],[]] .sourceHead = true := by decide
def e1211276243926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211276243926 : Closed e1211276243926 ∧ code e1211276243926 = 5609322755030 := by decide
theorem cert_e1211276243926 : check e1211276243926 [[],[]] .sourceHead = true := by decide
def e1211276243930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211276243930 : Closed e1211276243930 ∧ code e1211276243930 = 5609322755034 := by decide
theorem cert_e1211276243930 : check e1211276243930 [[],[]] .sourceHead = true := by decide
def e1211276244206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211276244206 : Closed e1211276244206 ∧ code e1211276244206 = 5609322755310 := by decide
theorem cert_e1211276244206 : check e1211276244206 [[],[]] .sourceHead = true := by decide
def e1211276244214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211276244214 : Closed e1211276244214 ∧ code e1211276244214 = 5609322755318 := by decide
theorem cert_e1211276244214 : check e1211276244214 [[],[]] .sourceHead = true := by decide
def e1211276244590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211276244590 : Closed e1211276244590 ∧ code e1211276244590 = 5609322755694 := by decide
theorem cert_e1211276244590 : check e1211276244590 [[],[]] .sourceHead = true := by decide
def e1211276244602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211276244602 : Closed e1211276244602 ∧ code e1211276244602 = 5609322755706 := by decide
theorem cert_e1211276244602 : check e1211276244602 [[],[]] .sourceHead = true := by decide
def e1211276244790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211276244790 : Closed e1211276244790 ∧ code e1211276244790 = 5609322755894 := by decide
theorem cert_e1211276244790 : check e1211276244790 [[],[]] .sourceHead = true := by decide
def e1211276244794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211276244794 : Closed e1211276244794 ∧ code e1211276244794 = 5609322755898 := by decide
theorem cert_e1211276244794 : check e1211276244794 [[],[]] .sourceHead = true := by decide
def e1211276245422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211276245422 : Closed e1211276245422 ∧ code e1211276245422 = 5609322756526 := by decide
theorem cert_e1211276245422 : check e1211276245422 [[],[]] .sourceHead = true := by decide
def e1211276245434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211276245434 : Closed e1211276245434 ∧ code e1211276245434 = 5609322756538 := by decide
theorem cert_e1211276245434 : check e1211276245434 [[],[]] .sourceHead = true := by decide
def e1211276245482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211276245482 : Closed e1211276245482 ∧ code e1211276245482 = 5609322756586 := by decide
theorem cert_e1211276245482 : check e1211276245482 [[],[]] .sourceHead = true := by decide
def e1211276245614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211276245614 : Closed e1211276245614 ∧ code e1211276245614 = 5609322756718 := by decide
theorem cert_e1211276245614 : check e1211276245614 [[],[]] .sourceHead = true := by decide
def e1211276245626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211276245626 : Closed e1211276245626 ∧ code e1211276245626 = 5609322756730 := by decide
theorem cert_e1211276245626 : check e1211276245626 [[],[]] .sourceHead = true := by decide
def e1211276245914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211276245914 : Closed e1211276245914 ∧ code e1211276245914 = 5609322757018 := by decide
theorem cert_e1211276245914 : check e1211276245914 [[],[]] .sourceHead = true := by decide
def e1211276246230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211276246230 : Closed e1211276246230 ∧ code e1211276246230 = 5609322757334 := by decide
theorem cert_e1211276246230 : check e1211276246230 [[],[]] .sourceHead = true := by decide
def e1211276246234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211276246234 : Closed e1211276246234 ∧ code e1211276246234 = 5609322757338 := by decide
theorem cert_e1211276246234 : check e1211276246234 [[],[]] .sourceHead = true := by decide
def e1211276246250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211276246250 : Closed e1211276246250 ∧ code e1211276246250 = 5609322757354 := by decide
theorem cert_e1211276246250 : check e1211276246250 [[],[]] .sourceHead = true := by decide
def e1211276246326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211276246326 : Closed e1211276246326 ∧ code e1211276246326 = 5609322757430 := by decide
theorem cert_e1211276246326 : check e1211276246326 [[],[]] .sourceHead = true := by decide
def e1211276246330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211276246330 : Closed e1211276246330 ∧ code e1211276246330 = 5609322757434 := by decide
theorem cert_e1211276246330 : check e1211276246330 [[],[]] .sourceHead = true := by decide
def e1211276246426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211276246426 : Closed e1211276246426 ∧ code e1211276246426 = 5609322757530 := by decide
theorem cert_e1211276246426 : check e1211276246426 [[],[]] .sourceHead = true := by decide
def e1211276248030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211276248030 : Closed e1211276248030 ∧ code e1211276248030 = 5609322759134 := by decide
theorem cert_e1211276248030 : check e1211276248030 [[],[]] .sourceHead = true := by decide
def e1211276248046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211276248046 : Closed e1211276248046 ∧ code e1211276248046 = 5609322759150 := by decide
theorem cert_e1211276248046 : check e1211276248046 [[],[]] .sourceHead = true := by decide
def e1211276249966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211276249966 : Closed e1211276249966 ∧ code e1211276249966 = 5609322761070 := by decide
theorem cert_e1211276249966 : check e1211276249966 [[],[]] .sourceHead = true := by decide
def e1211276249974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211276249974 : Closed e1211276249974 ∧ code e1211276249974 = 5609322761078 := by decide
theorem cert_e1211276249974 : check e1211276249974 [[],[]] .sourceHead = true := by decide
def e1211276250030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211276250030 : Closed e1211276250030 ∧ code e1211276250030 = 5609322761134 := by decide
theorem cert_e1211276250030 : check e1211276250030 [[],[]] .sourceHead = true := by decide
def e1211276250042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211276250042 : Closed e1211276250042 ∧ code e1211276250042 = 5609322761146 := by decide
theorem cert_e1211276250042 : check e1211276250042 [[],[]] .sourceHead = true := by decide
def e1211276250070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211276250070 : Closed e1211276250070 ∧ code e1211276250070 = 5609322761174 := by decide
theorem cert_e1211276250070 : check e1211276250070 [[],[]] .sourceHead = true := by decide
def e1211276250074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211276250074 : Closed e1211276250074 ∧ code e1211276250074 = 5609322761178 := by decide
theorem cert_e1211276250074 : check e1211276250074 [[],[]] .sourceHead = true := by decide
def e1211276250350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211276250350 : Closed e1211276250350 ∧ code e1211276250350 = 5609322761454 := by decide
theorem cert_e1211276250350 : check e1211276250350 [[],[]] .sourceHead = true := by decide
def e1211276250358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211276250358 : Closed e1211276250358 ∧ code e1211276250358 = 5609322761462 := by decide
theorem cert_e1211276250358 : check e1211276250358 [[],[]] .sourceHead = true := by decide
def e1211276250734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211276250734 : Closed e1211276250734 ∧ code e1211276250734 = 5609322761838 := by decide
theorem cert_e1211276250734 : check e1211276250734 [[],[]] .sourceHead = true := by decide
def e1211276250746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211276250746 : Closed e1211276250746 ∧ code e1211276250746 = 5609322761850 := by decide
theorem cert_e1211276250746 : check e1211276250746 [[],[]] .sourceHead = true := by decide
def e1211276250934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211276250934 : Closed e1211276250934 ∧ code e1211276250934 = 5609322762038 := by decide
theorem cert_e1211276250934 : check e1211276250934 [[],[]] .sourceHead = true := by decide
def e1211276250938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211276250938 : Closed e1211276250938 ∧ code e1211276250938 = 5609322762042 := by decide
theorem cert_e1211276250938 : check e1211276250938 [[],[]] .sourceHead = true := by decide
def e1211276255710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e1211276255710 : Closed e1211276255710 ∧ code e1211276255710 = 5609322766814 := by decide
theorem cert_e1211276255710 : check e1211276255710 [[],[]] .sourceHead = true := by decide
def e1211276255734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e1211276255734 : Closed e1211276255734 ∧ code e1211276255734 = 5609322766838 := by decide
theorem cert_e1211276255734 : check e1211276255734 [[],[]] .sourceHead = true := by decide
def e1211276256686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e1211276256686 : Closed e1211276256686 ∧ code e1211276256686 = 5609322767790 := by decide
theorem cert_e1211276256686 : check e1211276256686 [[],[]] .sourceHead = true := by decide
def e1211276256698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e1211276256698 : Closed e1211276256698 ∧ code e1211276256698 = 5609322767802 := by decide
theorem cert_e1211276256698 : check e1211276256698 [[],[]] .sourceHead = true := by decide
def e1211276256746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e1211276256746 : Closed e1211276256746 ∧ code e1211276256746 = 5609322767850 := by decide
theorem cert_e1211276256746 : check e1211276256746 [[],[]] .sourceHead = true := by decide
def e1211276256878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211276256878 : Closed e1211276256878 ∧ code e1211276256878 = 5609322767982 := by decide
theorem cert_e1211276256878 : check e1211276256878 [[],[]] .sourceHead = true := by decide
def e1211276256890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211276256890 : Closed e1211276256890 ∧ code e1211276256890 = 5609322767994 := by decide
theorem cert_e1211276256890 : check e1211276256890 [[],[]] .sourceHead = true := by decide
def e1211276257178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211276257178 : Closed e1211276257178 ∧ code e1211276257178 = 5609322768282 := by decide
theorem cert_e1211276257178 : check e1211276257178 [[],[]] .sourceHead = true := by decide
def e1211276259566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211276259566 : Closed e1211276259566 ∧ code e1211276259566 = 5609322770670 := by decide
theorem cert_e1211276259566 : check e1211276259566 [[],[]] .sourceHead = true := by decide
def e1211276259574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211276259574 : Closed e1211276259574 ∧ code e1211276259574 = 5609322770678 := by decide
theorem cert_e1211276259574 : check e1211276259574 [[],[]] .sourceHead = true := by decide
def e1211276260054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211276260054 : Closed e1211276260054 ∧ code e1211276260054 = 5609322771158 := by decide
theorem cert_e1211276260054 : check e1211276260054 [[],[]] .sourceHead = true := by decide
def e1211276260058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211276260058 : Closed e1211276260058 ∧ code e1211276260058 = 5609322771162 := by decide
theorem cert_e1211276260058 : check e1211276260058 [[],[]] .sourceHead = true := by decide
def e1211276260074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211276260074 : Closed e1211276260074 ∧ code e1211276260074 = 5609322771178 := by decide
theorem cert_e1211276260074 : check e1211276260074 [[],[]] .sourceHead = true := by decide
def e1211276260150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211276260150 : Closed e1211276260150 ∧ code e1211276260150 = 5609322771254 := by decide
theorem cert_e1211276260150 : check e1211276260150 [[],[]] .sourceHead = true := by decide
def e1211276260154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211276260154 : Closed e1211276260154 ∧ code e1211276260154 = 5609322771258 := by decide
theorem cert_e1211276260154 : check e1211276260154 [[],[]] .sourceHead = true := by decide
def e1211276260250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211276260250 : Closed e1211276260250 ∧ code e1211276260250 = 5609322771354 := by decide
theorem cert_e1211276260250 : check e1211276260250 [[],[]] .sourceHead = true := by decide
def e1211276397422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211276397422 : Closed e1211276397422 ∧ code e1211276397422 = 5609322908526 := by decide
theorem cert_e1211276397422 : check e1211276397422 [[],[]] .sourceHead = true := by decide
def e1211276397430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211276397430 : Closed e1211276397430 ∧ code e1211276397430 = 5609322908534 := by decide
theorem cert_e1211276397430 : check e1211276397430 [[],[]] .sourceHead = true := by decide
def e1211276397486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211276397486 : Closed e1211276397486 ∧ code e1211276397486 = 5609322908590 := by decide
theorem cert_e1211276397486 : check e1211276397486 [[],[]] .sourceHead = true := by decide
def e1211276397498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211276397498 : Closed e1211276397498 ∧ code e1211276397498 = 5609322908602 := by decide
theorem cert_e1211276397498 : check e1211276397498 [[],[]] .sourceHead = true := by decide
def e1211276397526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211276397526 : Closed e1211276397526 ∧ code e1211276397526 = 5609322908630 := by decide
theorem cert_e1211276397526 : check e1211276397526 [[],[]] .sourceHead = true := by decide
def e1211276397530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211276397530 : Closed e1211276397530 ∧ code e1211276397530 = 5609322908634 := by decide
theorem cert_e1211276397530 : check e1211276397530 [[],[]] .sourceHead = true := by decide
def e1211276397806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211276397806 : Closed e1211276397806 ∧ code e1211276397806 = 5609322908910 := by decide
theorem cert_e1211276397806 : check e1211276397806 [[],[]] .sourceHead = true := by decide
def e1211276397814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211276397814 : Closed e1211276397814 ∧ code e1211276397814 = 5609322908918 := by decide
theorem cert_e1211276397814 : check e1211276397814 [[],[]] .sourceHead = true := by decide
def e1211276398190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211276398190 : Closed e1211276398190 ∧ code e1211276398190 = 5609322909294 := by decide
theorem cert_e1211276398190 : check e1211276398190 [[],[]] .sourceHead = true := by decide
def e1211276398202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211276398202 : Closed e1211276398202 ∧ code e1211276398202 = 5609322909306 := by decide
theorem cert_e1211276398202 : check e1211276398202 [[],[]] .sourceHead = true := by decide
def e1211276398390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211276398390 : Closed e1211276398390 ∧ code e1211276398390 = 5609322909494 := by decide
theorem cert_e1211276398390 : check e1211276398390 [[],[]] .sourceHead = true := by decide
def e1211276398394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211276398394 : Closed e1211276398394 ∧ code e1211276398394 = 5609322909498 := by decide
theorem cert_e1211276398394 : check e1211276398394 [[],[]] .sourceHead = true := by decide
def e1211277293302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 1)))))
theorem wire_e1211277293302 : Closed e1211277293302 ∧ code e1211277293302 = 5609323804406 := by decide
def e1211277293434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))) (.var 0)))))
theorem wire_e1211277293434 : Closed e1211277293434 ∧ code e1211277293434 = 5609323804538 := by decide
theorem cert_e1211277293434 : check e1211277293434 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277293494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 1)))))
theorem wire_e1211277293494 : Closed e1211277293494 ∧ code e1211277293494 = 5609323804598 := by decide
def e1211277293498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))) (.var 0)))))
theorem wire_e1211277293498 : Closed e1211277293498 ∧ code e1211277293498 = 5609323804602 := by decide
theorem cert_e1211277293498 : check e1211277293498 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277294326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 1)))))
theorem wire_e1211277294326 : Closed e1211277294326 ∧ code e1211277294326 = 5609323805430 := by decide
def e1211277294550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 1)))))
theorem wire_e1211277294550 : Closed e1211277294550 ∧ code e1211277294550 = 5609323805654 := by decide
private def t_e1211277294550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 1)))))
theorem cert_e1211277294550 : ¬ IsSelfInterpreter e1211277294550 :=
  wSource (t := t_e1211277294550) (replay_sound (ps := []) (t := e1211277294550) (by decide)) (by decide)
def e1211277294970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))) (.var 0)))))
theorem wire_e1211277294970 : Closed e1211277294970 ∧ code e1211277294970 = 5609323806074 := by decide
theorem cert_e1211277294970 : check e1211277294970 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277295082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))) (.var 0)))))
theorem wire_e1211277295082 : Closed e1211277295082 ∧ code e1211277295082 = 5609323806186 := by decide
theorem cert_e1211277295082 : check e1211277295082 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277295286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e1211277295286 : Closed e1211277295286 ∧ code e1211277295286 = 5609323806390 := by decide
def e1211277295290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e1211277295290 : Closed e1211277295290 ∧ code e1211277295290 = 5609323806394 := by decide
theorem cert_e1211277295290 : check e1211277295290 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277295318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e1211277295318 : Closed e1211277295318 ∧ code e1211277295318 = 5609323806422 := by decide
private def t_e1211277295318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 1)))))
theorem cert_e1211277295318 : ¬ IsSelfInterpreter e1211277295318 :=
  wSource (t := t_e1211277295318) (replay_sound (ps := []) (t := e1211277295318) (by decide)) (by decide)
def e1211277295338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e1211277295338 : Closed e1211277295338 ∧ code e1211277295338 = 5609323806442 := by decide
theorem cert_e1211277295338 : check e1211277295338 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277299446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 1)))))
theorem wire_e1211277299446 : Closed e1211277299446 ∧ code e1211277299446 = 5609323810550 := by decide
theorem cert_e1211277299446 : check e1211277299446 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e1211277299578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))) (.var 0)))))
theorem wire_e1211277299578 : Closed e1211277299578 ∧ code e1211277299578 = 5609323810682 := by decide
theorem cert_e1211277299578 : check e1211277299578 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277299638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 1)))))
theorem wire_e1211277299638 : Closed e1211277299638 ∧ code e1211277299638 = 5609323810742 := by decide
theorem cert_e1211277299638 : check e1211277299638 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under]] .identityHead = true := by decide
def e1211277299642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))) (.var 0)))))
theorem wire_e1211277299642 : Closed e1211277299642 ∧ code e1211277299642 = 5609323810746 := by decide
theorem cert_e1211277299642 : check e1211277299642 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277305590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 1)))))
theorem wire_e1211277305590 : Closed e1211277305590 ∧ code e1211277305590 = 5609323816694 := by decide
theorem cert_e1211277305590 : check e1211277305590 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211277305814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 1)))))
theorem wire_e1211277305814 : Closed e1211277305814 ∧ code e1211277305814 = 5609323816918 := by decide
theorem cert_e1211277305814 : check e1211277305814 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e1211277308794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))) (.var 0)))))
theorem wire_e1211277308794 : Closed e1211277308794 ∧ code e1211277308794 = 5609323819898 := by decide
theorem cert_e1211277308794 : check e1211277308794 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277308906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))) (.var 0)))))
theorem wire_e1211277308906 : Closed e1211277308906 ∧ code e1211277308906 = 5609323820010 := by decide
theorem cert_e1211277308906 : check e1211277308906 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277310390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e1211277310390 : Closed e1211277310390 ∧ code e1211277310390 = 5609323821494 := by decide
def e1211277310394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e1211277310394 : Closed e1211277310394 ∧ code e1211277310394 = 5609323821498 := by decide
theorem cert_e1211277310394 : check e1211277310394 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277310422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e1211277310422 : Closed e1211277310422 ∧ code e1211277310422 = 5609323821526 := by decide
def e1211277310442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e1211277310442 : Closed e1211277310442 ∧ code e1211277310442 = 5609323821546 := by decide
theorem cert_e1211277310442 : check e1211277310442 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1211277314926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211277314926 : Closed e1211277314926 ∧ code e1211277314926 = 5609323826030 := by decide
theorem cert_e1211277314926 : check e1211277314926 [[],[],[.under,.left]] .chain = true := by decide
def e1211277314934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211277314934 : Closed e1211277314934 ∧ code e1211277314934 = 5609323826038 := by decide
theorem cert_e1211277314934 : check e1211277314934 [[],[],[.under,.left]] .chain = true := by decide
def e1211277314990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211277314990 : Closed e1211277314990 ∧ code e1211277314990 = 5609323826094 := by decide
theorem cert_e1211277314990 : check e1211277314990 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211277315002 : Closed e1211277315002 ∧ code e1211277315002 = 5609323826106 := by decide
theorem cert_e1211277315002 : check e1211277315002 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211277315030 : Closed e1211277315030 ∧ code e1211277315030 = 5609323826134 := by decide
theorem cert_e1211277315030 : check e1211277315030 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211277315034 : Closed e1211277315034 ∧ code e1211277315034 = 5609323826138 := by decide
theorem cert_e1211277315034 : check e1211277315034 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211277315310 : Closed e1211277315310 ∧ code e1211277315310 = 5609323826414 := by decide
theorem cert_e1211277315310 : check e1211277315310 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211277315318 : Closed e1211277315318 ∧ code e1211277315318 = 5609323826422 := by decide
theorem cert_e1211277315318 : check e1211277315318 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211277315694 : Closed e1211277315694 ∧ code e1211277315694 = 5609323826798 := by decide
theorem cert_e1211277315694 : check e1211277315694 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211277315706 : Closed e1211277315706 ∧ code e1211277315706 = 5609323826810 := by decide
theorem cert_e1211277315706 : check e1211277315706 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211277315894 : Closed e1211277315894 ∧ code e1211277315894 = 5609323826998 := by decide
theorem cert_e1211277315894 : check e1211277315894 [[],[],[.under,.left]] .chain = true := by decide
def e1211277315898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211277315898 : Closed e1211277315898 ∧ code e1211277315898 = 5609323827002 := by decide
theorem cert_e1211277315898 : check e1211277315898 [[],[],[.under,.left]] .chain = true := by decide
end Blc.Floor42
