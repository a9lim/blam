import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1194672458710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1194672458710 : Closed e1194672458710 ∧ code e1194672458710 = 5592718969814 := by decide
theorem cert_e1194672458710 : check e1194672458710 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672458714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1194672458714 : Closed e1194672458714 ∧ code e1194672458714 = 5592718969818 := by decide
theorem cert_e1194672458714 : check e1194672458714 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672458990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1194672458990 : Closed e1194672458990 ∧ code e1194672458990 = 5592718970094 := by decide
theorem cert_e1194672458990 : check e1194672458990 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672458998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1194672458998 : Closed e1194672458998 ∧ code e1194672458998 = 5592718970102 := by decide
theorem cert_e1194672458998 : check e1194672458998 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672459374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1194672459374 : Closed e1194672459374 ∧ code e1194672459374 = 5592718970478 := by decide
theorem cert_e1194672459374 : check e1194672459374 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672459386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1194672459386 : Closed e1194672459386 ∧ code e1194672459386 = 5592718970490 := by decide
theorem cert_e1194672459386 : check e1194672459386 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672459574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194672459574 : Closed e1194672459574 ∧ code e1194672459574 = 5592718970678 := by decide
theorem cert_e1194672459574 : check e1194672459574 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672459578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194672459578 : Closed e1194672459578 ∧ code e1194672459578 = 5592718970682 := by decide
theorem cert_e1194672459578 : check e1194672459578 [[],[.left],[],[.under]] .smaller = true := by decide
def e1194672467054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1194672467054 : Closed e1194672467054 ∧ code e1194672467054 = 5592718978158 := by decide
theorem cert_e1194672467054 : check e1194672467054 [[],[.left],[]] .chain = true := by decide
def e1194672467066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1194672467066 : Closed e1194672467066 ∧ code e1194672467066 = 5592718978170 := by decide
theorem cert_e1194672467066 : check e1194672467066 [[],[.left],[]] .chain = true := by decide
def e1194672467230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1194672467230 : Closed e1194672467230 ∧ code e1194672467230 = 5592718978334 := by decide
theorem cert_e1194672467230 : check e1194672467230 [[],[.left],[]] .chain = true := by decide
def e1194672467398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1194672467398 : Closed e1194672467398 ∧ code e1194672467398 = 5592718978502 := by decide
theorem cert_e1194672467398 : check e1194672467398 [[],[.left],[]] .chain = true := by decide
def e1194672467738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1194672467738 : Closed e1194672467738 ∧ code e1194672467738 = 5592718978842 := by decide
theorem cert_e1194672467738 : check e1194672467738 [[],[.left],[]] .chain = true := by decide
def e1194672467782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1194672467782 : Closed e1194672467782 ∧ code e1194672467782 = 5592718978886 := by decide
theorem cert_e1194672467782 : check e1194672467782 [[],[.left],[]] .chain = true := by decide
def e1194672468766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1194672468766 : Closed e1194672468766 ∧ code e1194672468766 = 5592718979870 := by decide
theorem cert_e1194672468766 : check e1194672468766 [[],[.left],[]] .chain = true := by decide
def e1194672468934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1194672468934 : Closed e1194672468934 ∧ code e1194672468934 = 5592718980038 := by decide
theorem cert_e1194672468934 : check e1194672468934 [[],[.left],[]] .chain = true := by decide
def e1194672471238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1194672471238 : Closed e1194672471238 ∧ code e1194672471238 = 5592718982342 := by decide
theorem cert_e1194672471238 : check e1194672471238 [[],[.left],[]] .chain = true := by decide
def e1194672494134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1194672494134 : Closed e1194672494134 ∧ code e1194672494134 = 5592719005238 := by decide
theorem cert_e1194672494134 : check e1194672494134 [[],[.left],[]] .chain = true := by decide
def e1194672494138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1194672494138 : Closed e1194672494138 ∧ code e1194672494138 = 5592719005242 := by decide
theorem cert_e1194672494138 : check e1194672494138 [[],[.left],[]] .chain = true := by decide
def e1194672494222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1194672494222 : Closed e1194672494222 ∧ code e1194672494222 = 5592719005326 := by decide
theorem cert_e1194672494222 : check e1194672494222 [[],[.left],[]] .chain = true := by decide
def e1194672494278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1194672494278 : Closed e1194672494278 ∧ code e1194672494278 = 5592719005382 := by decide
theorem cert_e1194672494278 : check e1194672494278 [[],[.left],[]] .chain = true := by decide
def e1194672494362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1194672494362 : Closed e1194672494362 ∧ code e1194672494362 = 5592719005466 := by decide
theorem cert_e1194672494362 : check e1194672494362 [[],[.left],[]] .chain = true := by decide
def e1194672494406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1194672494406 : Closed e1194672494406 ∧ code e1194672494406 = 5592719005510 := by decide
theorem cert_e1194672494406 : check e1194672494406 [[],[.left],[]] .chain = true := by decide
def e1194672494990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1194672494990 : Closed e1194672494990 ∧ code e1194672494990 = 5592719006094 := by decide
theorem cert_e1194672494990 : check e1194672494990 [[],[.left],[]] .chain = true := by decide
def e1194672495046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1194672495046 : Closed e1194672495046 ∧ code e1194672495046 = 5592719006150 := by decide
theorem cert_e1194672495046 : check e1194672495046 [[],[.left],[]] .chain = true := by decide
def e1194672495814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1194672495814 : Closed e1194672495814 ∧ code e1194672495814 = 5592719006918 := by decide
theorem cert_e1194672495814 : check e1194672495814 [[],[.left],[]] .chain = true := by decide
def e1194673592558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1194673592558 : Closed e1194673592558 ∧ code e1194673592558 = 5592720103662 := by decide
theorem cert_e1194673592558 : check e1194673592558 [[],[.left],[],[]] .chain = true := by decide
def e1194673592566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1194673592566 : Closed e1194673592566 ∧ code e1194673592566 = 5592720103670 := by decide
theorem cert_e1194673592566 : check e1194673592566 [[],[.left],[],[]] .chain = true := by decide
def e1194673593118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1194673593118 : Closed e1194673593118 ∧ code e1194673593118 = 5592720104222 := by decide
theorem cert_e1194673593118 : check e1194673593118 [[],[.left],[],[]] .chain = true := by decide
def e1194673593230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1194673593230 : Closed e1194673593230 ∧ code e1194673593230 = 5592720104334 := by decide
theorem cert_e1194673593230 : check e1194673593230 [[],[.left],[],[]] .chain = true := by decide
def e1194673593454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1194673593454 : Closed e1194673593454 ∧ code e1194673593454 = 5592720104558 := by decide
theorem cert_e1194673593454 : check e1194673593454 [[],[.left],[],[]] .chain = true := by decide
def e1194673593466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1194673593466 : Closed e1194673593466 ∧ code e1194673593466 = 5592720104570 := by decide
theorem cert_e1194673593466 : check e1194673593466 [[],[.left],[],[]] .chain = true := by decide
def e1194673593630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1194673593630 : Closed e1194673593630 ∧ code e1194673593630 = 5592720104734 := by decide
theorem cert_e1194673593630 : check e1194673593630 [[],[.left],[],[]] .chain = true := by decide
def e1194673593798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1194673593798 : Closed e1194673593798 ∧ code e1194673593798 = 5592720104902 := by decide
theorem cert_e1194673593798 : check e1194673593798 [[],[.left],[],[]] .chain = true := by decide
def e1194673593910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1194673593910 : Closed e1194673593910 ∧ code e1194673593910 = 5592720105014 := by decide
theorem cert_e1194673593910 : check e1194673593910 [[],[.left],[],[]] .chain = true := by decide
def e1194673593914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1194673593914 : Closed e1194673593914 ∧ code e1194673593914 = 5592720105018 := by decide
theorem cert_e1194673593914 : check e1194673593914 [[],[.left],[],[]] .chain = true := by decide
def e1194673593998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1194673593998 : Closed e1194673593998 ∧ code e1194673593998 = 5592720105102 := by decide
theorem cert_e1194673593998 : check e1194673593998 [[],[.left],[],[]] .chain = true := by decide
def e1194673594054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1194673594054 : Closed e1194673594054 ∧ code e1194673594054 = 5592720105158 := by decide
theorem cert_e1194673594054 : check e1194673594054 [[],[.left],[],[]] .chain = true := by decide
def e1194673596190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1194673596190 : Closed e1194673596190 ∧ code e1194673596190 = 5592720107294 := by decide
theorem cert_e1194673596190 : check e1194673596190 [[],[.left],[],[]] .chain = true := by decide
def e1194673596302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1194673596302 : Closed e1194673596302 ∧ code e1194673596302 = 5592720107406 := by decide
theorem cert_e1194673596302 : check e1194673596302 [[],[.left],[],[]] .chain = true := by decide
def e1194673599262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1194673599262 : Closed e1194673599262 ∧ code e1194673599262 = 5592720110366 := by decide
theorem cert_e1194673599262 : check e1194673599262 [[],[.left],[],[]] .chain = true := by decide
def e1194673599430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1194673599430 : Closed e1194673599430 ∧ code e1194673599430 = 5592720110534 := by decide
theorem cert_e1194673599430 : check e1194673599430 [[],[.left],[],[]] .chain = true := by decide
def e1194673600910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1194673600910 : Closed e1194673600910 ∧ code e1194673600910 = 5592720112014 := by decide
theorem cert_e1194673600910 : check e1194673600910 [[],[.left],[],[]] .chain = true := by decide
def e1194673600966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1194673600966 : Closed e1194673600966 ∧ code e1194673600966 = 5592720112070 := by decide
theorem cert_e1194673600966 : check e1194673600966 [[],[.left],[],[]] .chain = true := by decide
def e1194678294238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1194678294238 : Closed e1194678294238 ∧ code e1194678294238 = 5592724805342 := by decide
theorem cert_e1194678294238 : check e1194678294238 [[],[.left]] .chain = true := by decide
def e1194678294262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1194678294262 : Closed e1194678294262 ∧ code e1194678294262 = 5592724805366 := by decide
theorem cert_e1194678294262 : check e1194678294262 [[],[.left]] .chain = true := by decide
def e1194678294366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1194678294366 : Closed e1194678294366 ∧ code e1194678294366 = 5592724805470 := by decide
theorem cert_e1194678294366 : check e1194678294366 [[],[.left]] .chain = true := by decide
def e1194678294394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1194678294394 : Closed e1194678294394 ∧ code e1194678294394 = 5592724805498 := by decide
theorem cert_e1194678294394 : check e1194678294394 [[],[.left]] .chain = true := by decide
def e1194678294486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1194678294486 : Closed e1194678294486 ∧ code e1194678294486 = 5592724805590 := by decide
theorem cert_e1194678294486 : check e1194678294486 [[],[.left]] .chain = true := by decide
def e1194678294490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1194678294490 : Closed e1194678294490 ∧ code e1194678294490 = 5592724805594 := by decide
theorem cert_e1194678294490 : check e1194678294490 [[],[.left]] .chain = true := by decide
def e1194678295006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1194678295006 : Closed e1194678295006 ∧ code e1194678295006 = 5592724806110 := by decide
theorem cert_e1194678295006 : check e1194678295006 [[],[.left]] .chain = true := by decide
def e1194678295030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1194678295030 : Closed e1194678295030 ∧ code e1194678295030 = 5592724806134 := by decide
theorem cert_e1194678295030 : check e1194678295030 [[],[.left]] .chain = true := by decide
def e1194678295774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1194678295774 : Closed e1194678295774 ∧ code e1194678295774 = 5592724806878 := by decide
theorem cert_e1194678295774 : check e1194678295774 [[],[.left]] .chain = true := by decide
def e1194678295802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1194678295802 : Closed e1194678295802 ∧ code e1194678295802 = 5592724806906 := by decide
theorem cert_e1194678295802 : check e1194678295802 [[],[.left]] .chain = true := by decide
def e1194678296374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1194678296374 : Closed e1194678296374 ∧ code e1194678296374 = 5592724807478 := by decide
theorem cert_e1194678296374 : check e1194678296374 [[],[.left]] .chain = true := by decide
def e1194678296378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1194678296378 : Closed e1194678296378 ∧ code e1194678296378 = 5592724807482 := by decide
theorem cert_e1194678296378 : check e1194678296378 [[],[.left]] .chain = true := by decide
def e1194678311150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1194678311150 : Closed e1194678311150 ∧ code e1194678311150 = 5592724822254 := by decide
theorem cert_e1194678311150 : check e1194678311150 [[],[.left]] .chain = true := by decide
def e1194678311158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1194678311158 : Closed e1194678311158 ∧ code e1194678311158 = 5592724822262 := by decide
theorem cert_e1194678311158 : check e1194678311158 [[],[.left]] .chain = true := by decide
def e1194678311710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1194678311710 : Closed e1194678311710 ∧ code e1194678311710 = 5592724822814 := by decide
theorem cert_e1194678311710 : check e1194678311710 [[],[.left]] .chain = true := by decide
def e1194678311822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1194678311822 : Closed e1194678311822 ∧ code e1194678311822 = 5592724822926 := by decide
theorem cert_e1194678311822 : check e1194678311822 [[],[.left]] .chain = true := by decide
def e1194678312046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1194678312046 : Closed e1194678312046 ∧ code e1194678312046 = 5592724823150 := by decide
theorem cert_e1194678312046 : check e1194678312046 [[],[.left]] .chain = true := by decide
def e1194678312058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1194678312058 : Closed e1194678312058 ∧ code e1194678312058 = 5592724823162 := by decide
theorem cert_e1194678312058 : check e1194678312058 [[],[.left]] .chain = true := by decide
def e1194678312222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1194678312222 : Closed e1194678312222 ∧ code e1194678312222 = 5592724823326 := by decide
theorem cert_e1194678312222 : check e1194678312222 [[],[.left]] .chain = true := by decide
def e1194678312390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1194678312390 : Closed e1194678312390 ∧ code e1194678312390 = 5592724823494 := by decide
theorem cert_e1194678312390 : check e1194678312390 [[],[.left]] .chain = true := by decide
def e1194678312502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1194678312502 : Closed e1194678312502 ∧ code e1194678312502 = 5592724823606 := by decide
theorem cert_e1194678312502 : check e1194678312502 [[],[.left]] .chain = true := by decide
def e1194678312506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1194678312506 : Closed e1194678312506 ∧ code e1194678312506 = 5592724823610 := by decide
theorem cert_e1194678312506 : check e1194678312506 [[],[.left]] .chain = true := by decide
def e1194678312590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1194678312590 : Closed e1194678312590 ∧ code e1194678312590 = 5592724823694 := by decide
theorem cert_e1194678312590 : check e1194678312590 [[],[.left]] .chain = true := by decide
def e1194678312646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1194678312646 : Closed e1194678312646 ∧ code e1194678312646 = 5592724823750 := by decide
theorem cert_e1194678312646 : check e1194678312646 [[],[.left]] .chain = true := by decide
def e1194678314782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1194678314782 : Closed e1194678314782 ∧ code e1194678314782 = 5592724825886 := by decide
theorem cert_e1194678314782 : check e1194678314782 [[],[.left]] .chain = true := by decide
def e1194678314894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1194678314894 : Closed e1194678314894 ∧ code e1194678314894 = 5592724825998 := by decide
theorem cert_e1194678314894 : check e1194678314894 [[],[.left]] .chain = true := by decide
def e1194678317854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1194678317854 : Closed e1194678317854 ∧ code e1194678317854 = 5592724828958 := by decide
theorem cert_e1194678317854 : check e1194678317854 [[],[.left]] .chain = true := by decide
def e1194678318022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1194678318022 : Closed e1194678318022 ∧ code e1194678318022 = 5592724829126 := by decide
theorem cert_e1194678318022 : check e1194678318022 [[],[.left]] .chain = true := by decide
def e1194678319502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1194678319502 : Closed e1194678319502 ∧ code e1194678319502 = 5592724830606 := by decide
theorem cert_e1194678319502 : check e1194678319502 [[],[.left]] .chain = true := by decide
def e1194678319558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1194678319558 : Closed e1194678319558 ∧ code e1194678319558 = 5592724830662 := by decide
theorem cert_e1194678319558 : check e1194678319558 [[],[.left]] .chain = true := by decide
def e1194809210906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809210906 : Closed e1194809210906 ∧ code e1194809210906 = 5592855722010 := by decide
theorem cert_e1194809210906 : check e1194809210906 [[]] .width = true := by decide
def e1194809219098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809219098 : Closed e1194809219098 ∧ code e1194809219098 = 5592855730202 := by decide
theorem cert_e1194809219098 : check e1194809219098 [[]] .width = true := by decide
def e1194809276442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809276442 : Closed e1194809276442 ∧ code e1194809276442 = 5592855787546 := by decide
theorem cert_e1194809276442 : check e1194809276442 [[]] .width = true := by decide
def e1194809288730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809288730 : Closed e1194809288730 ∧ code e1194809288730 = 5592855799834 := by decide
theorem cert_e1194809288730 : check e1194809288730 [[]] .width = true := by decide
def e1194809317402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809317402 : Closed e1194809317402 ∧ code e1194809317402 = 5592855828506 := by decide
theorem cert_e1194809317402 : check e1194809317402 [[]] .width = true := by decide
def e1194809321498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809321498 : Closed e1194809321498 ∧ code e1194809321498 = 5592855832602 := by decide
theorem cert_e1194809321498 : check e1194809321498 [[]] .width = true := by decide
def e1194809604122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809604122 : Closed e1194809604122 ∧ code e1194809604122 = 5592856115226 := by decide
theorem cert_e1194809604122 : check e1194809604122 [[]] .width = true := by decide
def e1194809612314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809612314 : Closed e1194809612314 ∧ code e1194809612314 = 5592856123418 := by decide
theorem cert_e1194809612314 : check e1194809612314 [[]] .width = true := by decide
def e1194809997338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194809997338 : Closed e1194809997338 ∧ code e1194809997338 = 5592856508442 := by decide
theorem cert_e1194809997338 : check e1194809997338 [[]] .width = true := by decide
def e1194810009626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194810009626 : Closed e1194810009626 ∧ code e1194810009626 = 5592856520730 := by decide
theorem cert_e1194810009626 : check e1194810009626 [[]] .width = true := by decide
def e1194810202138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194810202138 : Closed e1194810202138 ∧ code e1194810202138 = 5592856713242 := by decide
theorem cert_e1194810202138 : check e1194810202138 [[]] .width = true := by decide
def e1194810206234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1194810206234 : Closed e1194810206234 ∧ code e1194810206234 = 5592856717338 := by decide
theorem cert_e1194810206234 : check e1194810206234 [[]] .width = true := by decide
def e1194823036270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1194823036270 : Closed e1194823036270 ∧ code e1194823036270 = 5592869547374 := by decide
theorem cert_e1194823036270 : check e1194823036270 [[],[.left]] .chain = true := by decide
def e1194823036278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1194823036278 : Closed e1194823036278 ∧ code e1194823036278 = 5592869547382 := by decide
theorem cert_e1194823036278 : check e1194823036278 [[],[.left]] .chain = true := by decide
def e1194823036334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1194823036334 : Closed e1194823036334 ∧ code e1194823036334 = 5592869547438 := by decide
theorem cert_e1194823036334 : check e1194823036334 [[],[.left]] .chain = true := by decide
def e1194823036346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1194823036346 : Closed e1194823036346 ∧ code e1194823036346 = 5592869547450 := by decide
theorem cert_e1194823036346 : check e1194823036346 [[],[.left]] .chain = true := by decide
def e1194823036374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1194823036374 : Closed e1194823036374 ∧ code e1194823036374 = 5592869547478 := by decide
theorem cert_e1194823036374 : check e1194823036374 [[],[.left]] .chain = true := by decide
def e1194823036378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1194823036378 : Closed e1194823036378 ∧ code e1194823036378 = 5592869547482 := by decide
theorem cert_e1194823036378 : check e1194823036378 [[],[.left]] .chain = true := by decide
def e1194823036590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1194823036590 : Closed e1194823036590 ∧ code e1194823036590 = 5592869547694 := by decide
theorem cert_e1194823036590 : check e1194823036590 [[],[.left]] .chain = true := by decide
def e1194823036602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1194823036602 : Closed e1194823036602 ∧ code e1194823036602 = 5592869547706 := by decide
theorem cert_e1194823036602 : check e1194823036602 [[],[.left]] .chain = true := by decide
def e1194823036650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1194823036650 : Closed e1194823036650 ∧ code e1194823036650 = 5592869547754 := by decide
theorem cert_e1194823036650 : check e1194823036650 [[],[.left]] .chain = true := by decide
def e1194823036758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1194823036758 : Closed e1194823036758 ∧ code e1194823036758 = 5592869547862 := by decide
theorem cert_e1194823036758 : check e1194823036758 [[],[.left]] .chain = true := by decide
def e1194823036762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1194823036762 : Closed e1194823036762 ∧ code e1194823036762 = 5592869547866 := by decide
theorem cert_e1194823036762 : check e1194823036762 [[],[.left]] .chain = true := by decide
def e1194823036778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1194823036778 : Closed e1194823036778 ∧ code e1194823036778 = 5592869547882 := by decide
theorem cert_e1194823036778 : check e1194823036778 [[],[.left]] .chain = true := by decide
def e1194823037806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1194823037806 : Closed e1194823037806 ∧ code e1194823037806 = 5592869548910 := by decide
theorem cert_e1194823037806 : check e1194823037806 [[],[.left]] .chain = true := by decide
def e1194823037814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1194823037814 : Closed e1194823037814 ∧ code e1194823037814 = 5592869548918 := by decide
theorem cert_e1194823037814 : check e1194823037814 [[],[.left]] .chain = true := by decide
def e1194823037870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1194823037870 : Closed e1194823037870 ∧ code e1194823037870 = 5592869548974 := by decide
theorem cert_e1194823037870 : check e1194823037870 [[],[.left]] .chain = true := by decide
def e1194823037882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1194823037882 : Closed e1194823037882 ∧ code e1194823037882 = 5592869548986 := by decide
theorem cert_e1194823037882 : check e1194823037882 [[],[.left]] .chain = true := by decide
def e1194823037910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1194823037910 : Closed e1194823037910 ∧ code e1194823037910 = 5592869549014 := by decide
theorem cert_e1194823037910 : check e1194823037910 [[],[.left]] .chain = true := by decide
def e1194823037914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1194823037914 : Closed e1194823037914 ∧ code e1194823037914 = 5592869549018 := by decide
theorem cert_e1194823037914 : check e1194823037914 [[],[.left]] .chain = true := by decide
def e1194823038190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1194823038190 : Closed e1194823038190 ∧ code e1194823038190 = 5592869549294 := by decide
theorem cert_e1194823038190 : check e1194823038190 [[],[.left]] .chain = true := by decide
def e1194823038198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1194823038198 : Closed e1194823038198 ∧ code e1194823038198 = 5592869549302 := by decide
theorem cert_e1194823038198 : check e1194823038198 [[],[.left]] .chain = true := by decide
def e1194823038574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194823038574 : Closed e1194823038574 ∧ code e1194823038574 = 5592869549678 := by decide
theorem cert_e1194823038574 : check e1194823038574 [[],[.left]] .chain = true := by decide
def e1194823038586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194823038586 : Closed e1194823038586 ∧ code e1194823038586 = 5592869549690 := by decide
theorem cert_e1194823038586 : check e1194823038586 [[],[.left]] .chain = true := by decide
def e1194823038774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194823038774 : Closed e1194823038774 ∧ code e1194823038774 = 5592869549878 := by decide
theorem cert_e1194823038774 : check e1194823038774 [[],[.left]] .chain = true := by decide
def e1194823038778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194823038778 : Closed e1194823038778 ∧ code e1194823038778 = 5592869549882 := by decide
theorem cert_e1194823038778 : check e1194823038778 [[],[.left]] .chain = true := by decide
def e1194823039406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1194823039406 : Closed e1194823039406 ∧ code e1194823039406 = 5592869550510 := by decide
theorem cert_e1194823039406 : check e1194823039406 [[],[.left]] .chain = true := by decide
def e1194823039418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1194823039418 : Closed e1194823039418 ∧ code e1194823039418 = 5592869550522 := by decide
theorem cert_e1194823039418 : check e1194823039418 [[],[.left]] .chain = true := by decide
def e1194823039466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e1194823039466 : Closed e1194823039466 ∧ code e1194823039466 = 5592869550570 := by decide
theorem cert_e1194823039466 : check e1194823039466 [[],[.left]] .chain = true := by decide
def e1194823039598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e1194823039598 : Closed e1194823039598 ∧ code e1194823039598 = 5592869550702 := by decide
theorem cert_e1194823039598 : check e1194823039598 [[],[.left]] .chain = true := by decide
def e1194823039610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e1194823039610 : Closed e1194823039610 ∧ code e1194823039610 = 5592869550714 := by decide
theorem cert_e1194823039610 : check e1194823039610 [[],[.left]] .chain = true := by decide
def e1194823039898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e1194823039898 : Closed e1194823039898 ∧ code e1194823039898 = 5592869551002 := by decide
theorem cert_e1194823039898 : check e1194823039898 [[],[.left]] .chain = true := by decide
def e1194823040214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e1194823040214 : Closed e1194823040214 ∧ code e1194823040214 = 5592869551318 := by decide
theorem cert_e1194823040214 : check e1194823040214 [[],[.left]] .chain = true := by decide
def e1194823040218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e1194823040218 : Closed e1194823040218 ∧ code e1194823040218 = 5592869551322 := by decide
theorem cert_e1194823040218 : check e1194823040218 [[],[.left]] .chain = true := by decide
def e1194823040234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e1194823040234 : Closed e1194823040234 ∧ code e1194823040234 = 5592869551338 := by decide
theorem cert_e1194823040234 : check e1194823040234 [[],[.left]] .chain = true := by decide
def e1194823040310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e1194823040310 : Closed e1194823040310 ∧ code e1194823040310 = 5592869551414 := by decide
theorem cert_e1194823040310 : check e1194823040310 [[],[.left]] .chain = true := by decide
def e1194823040314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e1194823040314 : Closed e1194823040314 ∧ code e1194823040314 = 5592869551418 := by decide
theorem cert_e1194823040314 : check e1194823040314 [[],[.left]] .chain = true := by decide
def e1194823040410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e1194823040410 : Closed e1194823040410 ∧ code e1194823040410 = 5592869551514 := by decide
theorem cert_e1194823040410 : check e1194823040410 [[],[.left]] .chain = true := by decide
def e1194823043950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194823043950 : Closed e1194823043950 ∧ code e1194823043950 = 5592869555054 := by decide
theorem cert_e1194823043950 : check e1194823043950 [[],[.left]] .chain = true := by decide
def e1194823043958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194823043958 : Closed e1194823043958 ∧ code e1194823043958 = 5592869555062 := by decide
theorem cert_e1194823043958 : check e1194823043958 [[],[.left]] .chain = true := by decide
def e1194823044014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194823044014 : Closed e1194823044014 ∧ code e1194823044014 = 5592869555118 := by decide
theorem cert_e1194823044014 : check e1194823044014 [[],[.left]] .chain = true := by decide
def e1194823044026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194823044026 : Closed e1194823044026 ∧ code e1194823044026 = 5592869555130 := by decide
theorem cert_e1194823044026 : check e1194823044026 [[],[.left]] .chain = true := by decide
def e1194823044054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194823044054 : Closed e1194823044054 ∧ code e1194823044054 = 5592869555158 := by decide
theorem cert_e1194823044054 : check e1194823044054 [[],[.left]] .chain = true := by decide
def e1194823044058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194823044058 : Closed e1194823044058 ∧ code e1194823044058 = 5592869555162 := by decide
theorem cert_e1194823044058 : check e1194823044058 [[],[.left]] .chain = true := by decide
def e1194823044334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194823044334 : Closed e1194823044334 ∧ code e1194823044334 = 5592869555438 := by decide
theorem cert_e1194823044334 : check e1194823044334 [[],[.left]] .chain = true := by decide
def e1194823044342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194823044342 : Closed e1194823044342 ∧ code e1194823044342 = 5592869555446 := by decide
theorem cert_e1194823044342 : check e1194823044342 [[],[.left]] .chain = true := by decide
def e1194823044718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194823044718 : Closed e1194823044718 ∧ code e1194823044718 = 5592869555822 := by decide
theorem cert_e1194823044718 : check e1194823044718 [[],[.left]] .chain = true := by decide
def e1194823044730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194823044730 : Closed e1194823044730 ∧ code e1194823044730 = 5592869555834 := by decide
theorem cert_e1194823044730 : check e1194823044730 [[],[.left]] .chain = true := by decide
def e1194823044918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194823044918 : Closed e1194823044918 ∧ code e1194823044918 = 5592869556022 := by decide
theorem cert_e1194823044918 : check e1194823044918 [[],[.left]] .chain = true := by decide
def e1194823044922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194823044922 : Closed e1194823044922 ∧ code e1194823044922 = 5592869556026 := by decide
theorem cert_e1194823044922 : check e1194823044922 [[],[.left]] .chain = true := by decide
def e1194823050670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1194823050670 : Closed e1194823050670 ∧ code e1194823050670 = 5592869561774 := by decide
theorem cert_e1194823050670 : check e1194823050670 [[],[.left]] .chain = true := by decide
def e1194823050682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1194823050682 : Closed e1194823050682 ∧ code e1194823050682 = 5592869561786 := by decide
theorem cert_e1194823050682 : check e1194823050682 [[],[.left]] .chain = true := by decide
def e1194823050730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1194823050730 : Closed e1194823050730 ∧ code e1194823050730 = 5592869561834 := by decide
theorem cert_e1194823050730 : check e1194823050730 [[],[.left]] .chain = true := by decide
def e1194823050862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1194823050862 : Closed e1194823050862 ∧ code e1194823050862 = 5592869561966 := by decide
theorem cert_e1194823050862 : check e1194823050862 [[],[.left]] .chain = true := by decide
def e1194823050874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1194823050874 : Closed e1194823050874 ∧ code e1194823050874 = 5592869561978 := by decide
theorem cert_e1194823050874 : check e1194823050874 [[],[.left]] .chain = true := by decide
def e1194823051162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1194823051162 : Closed e1194823051162 ∧ code e1194823051162 = 5592869562266 := by decide
theorem cert_e1194823051162 : check e1194823051162 [[],[.left]] .chain = true := by decide
def e1194823054038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1194823054038 : Closed e1194823054038 ∧ code e1194823054038 = 5592869565142 := by decide
theorem cert_e1194823054038 : check e1194823054038 [[],[.left]] .chain = true := by decide
def e1194823054042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1194823054042 : Closed e1194823054042 ∧ code e1194823054042 = 5592869565146 := by decide
theorem cert_e1194823054042 : check e1194823054042 [[],[.left]] .chain = true := by decide
def e1194823054058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1194823054058 : Closed e1194823054058 ∧ code e1194823054058 = 5592869565162 := by decide
theorem cert_e1194823054058 : check e1194823054058 [[],[.left]] .chain = true := by decide
def e1194823054134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1194823054134 : Closed e1194823054134 ∧ code e1194823054134 = 5592869565238 := by decide
theorem cert_e1194823054134 : check e1194823054134 [[],[.left]] .chain = true := by decide
def e1194823054138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1194823054138 : Closed e1194823054138 ∧ code e1194823054138 = 5592869565242 := by decide
theorem cert_e1194823054138 : check e1194823054138 [[],[.left]] .chain = true := by decide
def e1194823054234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1194823054234 : Closed e1194823054234 ∧ code e1194823054234 = 5592869565338 := by decide
theorem cert_e1194823054234 : check e1194823054234 [[],[.left]] .chain = true := by decide
def e1194823191406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194823191406 : Closed e1194823191406 ∧ code e1194823191406 = 5592869702510 := by decide
theorem cert_e1194823191406 : check e1194823191406 [[],[.left]] .chain = true := by decide
def e1194823191414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194823191414 : Closed e1194823191414 ∧ code e1194823191414 = 5592869702518 := by decide
theorem cert_e1194823191414 : check e1194823191414 [[],[.left]] .chain = true := by decide
def e1194823191470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1194823191470 : Closed e1194823191470 ∧ code e1194823191470 = 5592869702574 := by decide
theorem cert_e1194823191470 : check e1194823191470 [[],[.left]] .chain = true := by decide
def e1194823191482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1194823191482 : Closed e1194823191482 ∧ code e1194823191482 = 5592869702586 := by decide
theorem cert_e1194823191482 : check e1194823191482 [[],[.left]] .chain = true := by decide
def e1194823191510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1194823191510 : Closed e1194823191510 ∧ code e1194823191510 = 5592869702614 := by decide
theorem cert_e1194823191510 : check e1194823191510 [[],[.left]] .chain = true := by decide
def e1194823191514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1194823191514 : Closed e1194823191514 ∧ code e1194823191514 = 5592869702618 := by decide
theorem cert_e1194823191514 : check e1194823191514 [[],[.left]] .chain = true := by decide
def e1194823191790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1194823191790 : Closed e1194823191790 ∧ code e1194823191790 = 5592869702894 := by decide
theorem cert_e1194823191790 : check e1194823191790 [[],[.left]] .chain = true := by decide
def e1194823191798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1194823191798 : Closed e1194823191798 ∧ code e1194823191798 = 5592869702902 := by decide
theorem cert_e1194823191798 : check e1194823191798 [[],[.left]] .chain = true := by decide
def e1194823192174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1194823192174 : Closed e1194823192174 ∧ code e1194823192174 = 5592869703278 := by decide
theorem cert_e1194823192174 : check e1194823192174 [[],[.left]] .chain = true := by decide
def e1194823192186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1194823192186 : Closed e1194823192186 ∧ code e1194823192186 = 5592869703290 := by decide
theorem cert_e1194823192186 : check e1194823192186 [[],[.left]] .chain = true := by decide
def e1194823192374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1194823192374 : Closed e1194823192374 ∧ code e1194823192374 = 5592869703478 := by decide
theorem cert_e1194823192374 : check e1194823192374 [[],[.left]] .chain = true := by decide
def e1194823192378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1194823192378 : Closed e1194823192378 ∧ code e1194823192378 = 5592869703482 := by decide
theorem cert_e1194823192378 : check e1194823192378 [[],[.left]] .chain = true := by decide
def e1194823781230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1194823781230 : Closed e1194823781230 ∧ code e1194823781230 = 5592870292334 := by decide
theorem cert_e1194823781230 : check e1194823781230 [[],[.left],[.left]] .smaller = true := by decide
def e1194823781238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1194823781238 : Closed e1194823781238 ∧ code e1194823781238 = 5592870292342 := by decide
theorem cert_e1194823781238 : check e1194823781238 [[],[.left],[.left]] .smaller = true := by decide
end Blc.Floor42
