import Batch069
import ExtraBase
namespace Blc.Floor42.Extra069
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1195779382714 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem ex_e1195779382714 : ¬ IsSelfInterpreter e1195779382714 := by
  intro he
  have hp := replay_sound (t := e1195779382714) (u := t_e1195779382714) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 0)) (.var 1))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 1)) (SO.var 2)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 0)) (SO.var 1)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779382714
private def t_e1195779382746 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem ex_e1195779382746 : ¬ IsSelfInterpreter e1195779382746 := by
  intro he
  have hp := replay_sound (t := e1195779382746) (u := t_e1195779382746) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779382746
private def t_e1195779383002 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem ex_e1195779383002 : ¬ IsSelfInterpreter e1195779383002 := by
  intro he
  have hp := replay_sound (t := e1195779383002) (u := t_e1195779383002) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 1) (.var 0)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779383002
private def t_e1195779389914 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem ex_e1195779389914 : ¬ IsSelfInterpreter e1195779389914 := by
  intro he
  have hp := replay_sound (t := e1195779389914) (u := t_e1195779389914) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.app (.var 0) (.var 0)))) (SO.app (SO.app (SO.var 2) (SO.app (SO.var 1) (SO.var 1))) (SO.var 0)) (SO.app (SO.var 1) (SO.app (SO.var 0) (SO.var 0))) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779389914
private def t_e1195779754938 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem ex_e1195779754938 : ¬ IsSelfInterpreter e1195779754938 := by
  intro he
  have hp := replay_sound (t := e1195779754938) (u := t_e1195779754938) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 0)) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779754938
private def t_e1195779754970 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem ex_e1195779754970 : ¬ IsSelfInterpreter e1195779754970 := by
  intro he
  have hp := replay_sound (t := e1195779754970) (u := t_e1195779754970) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.app (SO.var 2) (SO.var 1)) (SO.var 0)) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779754970
private def t_e1195779755246 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem ex_e1195779755246 : ¬ IsSelfInterpreter e1195779755246 := by
  intro he
  have hp := replay_sound (t := e1195779755246) (u := t_e1195779755246) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 0) (.var 1))) (SO.app (SO.var 0) (SO.app (SO.var 1) (SO.var 2))) (SO.app (SO.var 0) (SO.var 1)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779755246
private def t_e1195779755254 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem ex_e1195779755254 : ¬ IsSelfInterpreter e1195779755254 := by
  intro he
  have hp := replay_sound (t := e1195779755254) (u := t_e1195779755254) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.app (SO.var 0) (SO.app (SO.var 0) (SO.var 0))) (SO.var 0))) (so_closed_lam (by decide) (SO.lam (g := (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (r := (.var 0)) (SO.app (SO.var 1) (SO.lam (g := (.app (.var 0) (.var 1))) (r := (.app (.var 1) (.var 0))) (SO.app (SO.var 0) (SO.app (SO.var 2) (SO.var 1))) (SO.app (SO.var 1) (SO.var 0)) (by decide) (by rfl))) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1195779755254
private def t_e1195779755830 : Term := (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))
theorem ex_e1195779755830 : ¬ IsSelfInterpreter e1195779755830 := by
  intro he
  have hp := replay_sound (t := (call e1195779755830 (.lam (.lam (.var 1))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := t_e1195779755830) (ps := [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.right],[.left,.right],[.left,.right,.right,.left],[.left,.right,.right,.left,.right],[.left],[],[.left],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.right],[.left,.right],[.left,.right,.right,.left],[.left],[],[.left],[],[.left],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 1))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [])) (u := (.lam (.lam (.var 0)))) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := Layouts.mismatch_sound 12 hr (by decide)
  exact (by decide : ¬ Layouts.mismatch 12 t_e1195779755830 (.lam (.lam (.var 0))) = false) hz
#print axioms ex_e1195779755830
private def t_e1195779755834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.var 0))))
theorem ex_e1195779755834 : ¬ IsSelfInterpreter e1195779755834 := by
  intro he
  have hp := replay_sound (t := (call e1195779755834 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := t_e1195779755834) (ps := [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.right,.under,.right],[.left,.left,.left],[.left,.left],[.left,.left,.right,.under,.right],[.left,.left],[.left],[.left,.right,.under,.right],[.left],[.left,.right,.right,.under],[.left],[],[.right,.under,.right],[.left,.left],[.left],[.left,.right,.under,.right],[.left],[],[]]) (by decide)
  have hq := replay_sound (t := (want (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [])) (u := (.var 0)) (ps := [[.left],[]]) (by decide)
  have hr := expected he (by decide) hp hq (by decide)
  have hz := SelfintKnot.occ_betas_zero hr 0 (by decide)
  exact (by decide : ¬ occ 0 (.var 0) = 0) hz
#print axioms ex_e1195779755834
end Blc.Floor42.Extra069
