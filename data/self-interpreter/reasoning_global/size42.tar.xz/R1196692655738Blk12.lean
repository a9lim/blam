import R1196692655738Data
namespace Certgen.R1196692655738
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl144 : FloorIndex.rangeOK validState 144 6 = true := by decide +kernel
end Certgen.R1196692655738
