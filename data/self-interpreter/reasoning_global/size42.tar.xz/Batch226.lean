import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211211135094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211211135094 : Closed e1211211135094 ∧ code e1211211135094 = 5609257646198 := by decide
theorem cert_e1211211135094 : check e1211211135094 [[],[]] .chain = true := by decide
def e1211211135338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211211135338 : Closed e1211211135338 ∧ code e1211211135338 = 5609257646442 := by decide
theorem cert_e1211211135338 : check e1211211135338 [[],[]] .chain = true := by decide
def e1211211135362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e1211211135362 : Closed e1211211135362 ∧ code e1211211135362 = 5609257646466 := by decide
theorem cert_e1211211135362 : check e1211211135362 [[],[]] .chain = true := by decide
def e1211211135374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211211135374 : Closed e1211211135374 ∧ code e1211211135374 = 5609257646478 := by decide
theorem cert_e1211211135374 : check e1211211135374 [[],[]] .chain = true := by decide
def e1211211135386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211211135386 : Closed e1211211135386 ∧ code e1211211135386 = 5609257646490 := by decide
theorem cert_e1211211135386 : check e1211211135386 [[],[]] .chain = true := by decide
def e1211211135430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211211135430 : Closed e1211211135430 ∧ code e1211211135430 = 5609257646534 := by decide
theorem cert_e1211211135430 : check e1211211135430 [[],[]] .chain = true := by decide
def e1211211136054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e1211211136054 : Closed e1211211136054 ∧ code e1211211136054 = 5609257647158 := by decide
theorem cert_e1211211136054 : check e1211211136054 [[],[]] .sourceHead = true := by decide
def e1211211136058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e1211211136058 : Closed e1211211136058 ∧ code e1211211136058 = 5609257647162 := by decide
theorem cert_e1211211136058 : check e1211211136058 [[],[]] .sourceHead = true := by decide
def e1211211136198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211211136198 : Closed e1211211136198 ∧ code e1211211136198 = 5609257647302 := by decide
theorem cert_e1211211136198 : check e1211211136198 [[],[]] .sourceHead = true := by decide
def e1211212258238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e1211212258238 : Closed e1211212258238 ∧ code e1211212258238 = 5609258769342 := by decide
theorem cert_e1211212258238 : check e1211212258238 [[],[],[.under,.under]] .three = true := by decide
def e1211212258286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e1211212258286 : Closed e1211212258286 ∧ code e1211212258286 = 5609258769390 := by decide
theorem cert_e1211212258286 : check e1211212258286 [[],[],[.under,.under]] .three = true := by decide
def e1211212259006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e1211212259006 : Closed e1211212259006 ∧ code e1211212259006 = 5609258770110 := by decide
theorem cert_e1211212259006 : check e1211212259006 [[],[],[.under,.under]] .three = true := by decide
def e1211212259066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e1211212259066 : Closed e1211212259066 ∧ code e1211212259066 = 5609258770170 := by decide
theorem cert_e1211212259066 : check e1211212259066 [[],[],[.under,.under]] .three = true := by decide
def e1211212259246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e1211212259246 : Closed e1211212259246 ∧ code e1211212259246 = 5609258770350 := by decide
theorem cert_e1211212259246 : check e1211212259246 [[],[],[.under,.under]] .three = true := by decide
def e1211212259258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e1211212259258 : Closed e1211212259258 ∧ code e1211212259258 = 5609258770362 := by decide
theorem cert_e1211212259258 : check e1211212259258 [[],[],[.under,.under]] .three = true := by decide
def e1211212261310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211212261310 : Closed e1211212261310 ∧ code e1211212261310 = 5609258772414 := by decide
theorem cert_e1211212261310 : check e1211212261310 [[],[],[.under,.under]] .three = true := by decide
def e1211212261358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211212261358 : Closed e1211212261358 ∧ code e1211212261358 = 5609258772462 := by decide
theorem cert_e1211212261358 : check e1211212261358 [[],[],[.under,.under]] .three = true := by decide
def e1211212265918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211212265918 : Closed e1211212265918 ∧ code e1211212265918 = 5609258777022 := by decide
theorem cert_e1211212265918 : check e1211212265918 [[],[],[.under,.under]] .three = true := by decide
def e1211212265978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211212265978 : Closed e1211212265978 ∧ code e1211212265978 = 5609258777082 := by decide
theorem cert_e1211212265978 : check e1211212265978 [[],[],[.under,.under]] .three = true := by decide
def e1211212267118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211212267118 : Closed e1211212267118 ∧ code e1211212267118 = 5609258778222 := by decide
theorem cert_e1211212267118 : check e1211212267118 [[],[],[.under,.under]] .three = true := by decide
def e1211212267130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211212267130 : Closed e1211212267130 ∧ code e1211212267130 = 5609258778234 := by decide
theorem cert_e1211212267130 : check e1211212267130 [[],[],[.under,.under]] .three = true := by decide
def e1211212323550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211212323550 : Closed e1211212323550 ∧ code e1211212323550 = 5609258834654 := by decide
private def t_e1211212323550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem cert_e1211212323550 : ¬ IsSelfInterpreter e1211212323550 :=
  wSource (t := t_e1211212323550) (replay_sound (ps := []) (t := e1211212323550) (by decide)) (by decide)
def e1211212323574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211212323574 : Closed e1211212323574 ∧ code e1211212323574 = 5609258834678 := by decide
private def t_e1211212323574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem cert_e1211212323574 : ¬ IsSelfInterpreter e1211212323574 :=
  wSource (t := t_e1211212323574) (replay_sound (ps := []) (t := e1211212323574) (by decide)) (by decide)
def e1211212323678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211212323678 : Closed e1211212323678 ∧ code e1211212323678 = 5609258834782 := by decide
theorem cert_e1211212323678 : check e1211212323678 [[],[],[.under,.under]] .three = true := by decide
def e1211212323694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211212323694 : Closed e1211212323694 ∧ code e1211212323694 = 5609258834798 := by decide
theorem cert_e1211212323694 : check e1211212323694 [[],[]] .chain = true := by decide
def e1211212323702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211212323702 : Closed e1211212323702 ∧ code e1211212323702 = 5609258834806 := by decide
theorem cert_e1211212323702 : check e1211212323702 [[],[]] .chain = true := by decide
def e1211212323706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211212323706 : Closed e1211212323706 ∧ code e1211212323706 = 5609258834810 := by decide
theorem cert_e1211212323706 : check e1211212323706 [[],[],[.under,.under]] .three = true := by decide
def e1211212323766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211212323766 : Closed e1211212323766 ∧ code e1211212323766 = 5609258834870 := by decide
theorem cert_e1211212323766 : check e1211212323766 [[],[]] .chain = true := by decide
def e1211212323798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211212323798 : Closed e1211212323798 ∧ code e1211212323798 = 5609258834902 := by decide
private def t_e1211212323798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem cert_e1211212323798 : ¬ IsSelfInterpreter e1211212323798 :=
  wSource (t := t_e1211212323798) (replay_sound (ps := []) (t := e1211212323798) (by decide)) (by decide)
def e1211212323802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211212323802 : Closed e1211212323802 ∧ code e1211212323802 = 5609258834906 := by decide
private def t_e1211212323802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem cert_e1211212323802 : ¬ IsSelfInterpreter e1211212323802 :=
  wSource (t := t_e1211212323802) (replay_sound (ps := []) (t := e1211212323802) (by decide)) (by decide)
def e1211212324190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211212324190 : Closed e1211212324190 ∧ code e1211212324190 = 5609258835294 := by decide
theorem cert_e1211212324190 : check e1211212324190 [[],[],[.under,.under]] .three = true := by decide
def e1211212324206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211212324206 : Closed e1211212324206 ∧ code e1211212324206 = 5609258835310 := by decide
theorem cert_e1211212324206 : check e1211212324206 [[],[]] .chain = true := by decide
def e1211212324214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211212324214 : Closed e1211212324214 ∧ code e1211212324214 = 5609258835318 := by decide
theorem cert_e1211212324214 : check e1211212324214 [[],[]] .chain = true := by decide
def e1211212324218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211212324218 : Closed e1211212324218 ∧ code e1211212324218 = 5609258835322 := by decide
theorem cert_e1211212324218 : check e1211212324218 [[],[],[.under,.under]] .three = true := by decide
def e1211212324270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211212324270 : Closed e1211212324270 ∧ code e1211212324270 = 5609258835374 := by decide
theorem cert_e1211212324270 : check e1211212324270 [[],[]] .chain = true := by decide
def e1211212324282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211212324282 : Closed e1211212324282 ∧ code e1211212324282 = 5609258835386 := by decide
theorem cert_e1211212324282 : check e1211212324282 [[],[]] .chain = true := by decide
def e1211212324310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211212324310 : Closed e1211212324310 ∧ code e1211212324310 = 5609258835414 := by decide
theorem cert_e1211212324310 : check e1211212324310 [[],[]] .chain = true := by decide
def e1211212324314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211212324314 : Closed e1211212324314 ∧ code e1211212324314 = 5609258835418 := by decide
theorem cert_e1211212324314 : check e1211212324314 [[],[]] .chain = true := by decide
def e1211212324330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211212324330 : Closed e1211212324330 ∧ code e1211212324330 = 5609258835434 := by decide
theorem cert_e1211212324330 : check e1211212324330 [[],[],[.under,.under]] .three = true := by decide
def e1211212324534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211212324534 : Closed e1211212324534 ∧ code e1211212324534 = 5609258835638 := by decide
theorem cert_e1211212324534 : check e1211212324534 [[],[]] .chain = true := by decide
def e1211212324566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211212324566 : Closed e1211212324566 ∧ code e1211212324566 = 5609258835670 := by decide
theorem cert_e1211212324566 : check e1211212324566 [[],[]] .chain = true := by decide
def e1211212324570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211212324570 : Closed e1211212324570 ∧ code e1211212324570 = 5609258835674 := by decide
theorem cert_e1211212324570 : check e1211212324570 [[],[]] .chain = true := by decide
def e1211212324694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211212324694 : Closed e1211212324694 ∧ code e1211212324694 = 5609258835798 := by decide
private def t_e1211212324694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem cert_e1211212324694 : ¬ IsSelfInterpreter e1211212324694 :=
  wSource (t := t_e1211212324694) (replay_sound (ps := []) (t := e1211212324694) (by decide)) (by decide)
def e1211212324698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211212324698 : Closed e1211212324698 ∧ code e1211212324698 = 5609258835802 := by decide
private def t_e1211212324698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem cert_e1211212324698 : ¬ IsSelfInterpreter e1211212324698 :=
  wSource (t := t_e1211212324698) (replay_sound (ps := []) (t := e1211212324698) (by decide)) (by decide)
def e1211212324714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211212324714 : Closed e1211212324714 ∧ code e1211212324714 = 5609258835818 := by decide
theorem cert_e1211212324714 : check e1211212324714 [[],[],[.under,.under]] .three = true := by decide
def e1211212325854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211212325854 : Closed e1211212325854 ∧ code e1211212325854 = 5609258836958 := by decide
theorem cert_e1211212325854 : check e1211212325854 [[],[],[.under,.under]] .three = true := by decide
def e1211212325870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211212325870 : Closed e1211212325870 ∧ code e1211212325870 = 5609258836974 := by decide
theorem cert_e1211212325870 : check e1211212325870 [[],[],[.under,.under]] .three = true := by decide
def e1211212326622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211212326622 : Closed e1211212326622 ∧ code e1211212326622 = 5609258837726 := by decide
theorem cert_e1211212326622 : check e1211212326622 [[],[],[.under,.under]] .three = true := by decide
def e1211212326646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211212326646 : Closed e1211212326646 ∧ code e1211212326646 = 5609258837750 := by decide
private def t_e1211212326646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem cert_e1211212326646 : ¬ IsSelfInterpreter e1211212326646 :=
  wSource (t := t_e1211212326646) (replay_sound (ps := []) (t := e1211212326646) (by decide)) (by decide)
def e1211212326750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211212326750 : Closed e1211212326750 ∧ code e1211212326750 = 5609258837854 := by decide
theorem cert_e1211212326750 : check e1211212326750 [[],[],[.under,.under]] .three = true := by decide
def e1211212326766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211212326766 : Closed e1211212326766 ∧ code e1211212326766 = 5609258837870 := by decide
theorem cert_e1211212326766 : check e1211212326766 [[],[]] .chain = true := by decide
def e1211212326774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211212326774 : Closed e1211212326774 ∧ code e1211212326774 = 5609258837878 := by decide
theorem cert_e1211212326774 : check e1211212326774 [[],[]] .chain = true := by decide
def e1211212326778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211212326778 : Closed e1211212326778 ∧ code e1211212326778 = 5609258837882 := by decide
theorem cert_e1211212326778 : check e1211212326778 [[],[],[.under,.under]] .three = true := by decide
def e1211212326838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211212326838 : Closed e1211212326838 ∧ code e1211212326838 = 5609258837942 := by decide
theorem cert_e1211212326838 : check e1211212326838 [[],[]] .chain = true := by decide
def e1211212326870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211212326870 : Closed e1211212326870 ∧ code e1211212326870 = 5609258837974 := by decide
private def t_e1211212326870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem cert_e1211212326870 : ¬ IsSelfInterpreter e1211212326870 :=
  wSource (t := t_e1211212326870) (replay_sound (ps := []) (t := e1211212326870) (by decide)) (by decide)
def e1211212326874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211212326874 : Closed e1211212326874 ∧ code e1211212326874 = 5609258837978 := by decide
theorem cert_e1211212326874 : check e1211212326874 [[],[],[.under,.under]] .three = true := by decide
def e1211212327390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211212327390 : Closed e1211212327390 ∧ code e1211212327390 = 5609258838494 := by decide
private def t_e1211212327390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem cert_e1211212327390 : ¬ IsSelfInterpreter e1211212327390 :=
  wSource (t := t_e1211212327390) (replay_sound (ps := []) (t := e1211212327390) (by decide)) (by decide)
def e1211212327414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211212327414 : Closed e1211212327414 ∧ code e1211212327414 = 5609258838518 := by decide
private def t_e1211212327414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem cert_e1211212327414 : ¬ IsSelfInterpreter e1211212327414 :=
  wSource (t := t_e1211212327414) (replay_sound (ps := []) (t := e1211212327414) (by decide)) (by decide)
def e1211212328158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211212328158 : Closed e1211212328158 ∧ code e1211212328158 = 5609258839262 := by decide
theorem cert_e1211212328158 : check e1211212328158 [[],[],[.under,.under]] .three = true := by decide
def e1211212328174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211212328174 : Closed e1211212328174 ∧ code e1211212328174 = 5609258839278 := by decide
theorem cert_e1211212328174 : check e1211212328174 [[],[]] .chain = true := by decide
def e1211212328182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211212328182 : Closed e1211212328182 ∧ code e1211212328182 = 5609258839286 := by decide
theorem cert_e1211212328182 : check e1211212328182 [[],[]] .chain = true := by decide
def e1211212328186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211212328186 : Closed e1211212328186 ∧ code e1211212328186 = 5609258839290 := by decide
theorem cert_e1211212328186 : check e1211212328186 [[],[],[.under,.under]] .three = true := by decide
def e1211212328510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211212328510 : Closed e1211212328510 ∧ code e1211212328510 = 5609258839614 := by decide
theorem cert_e1211212328510 : check e1211212328510 [[],[],[.under,.under]] .three = true := by decide
def e1211212328566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211212328566 : Closed e1211212328566 ∧ code e1211212328566 = 5609258839670 := by decide
theorem cert_e1211212328566 : check e1211212328566 [[],[]] .chain = true := by decide
def e1211212328734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211212328734 : Closed e1211212328734 ∧ code e1211212328734 = 5609258839838 := by decide
private def t_e1211212328734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem cert_e1211212328734 : ¬ IsSelfInterpreter e1211212328734 :=
  wSource (t := t_e1211212328734) (replay_sound (ps := []) (t := e1211212328734) (by decide)) (by decide)
def e1211212328758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212328758 : Closed e1211212328758 ∧ code e1211212328758 = 5609258839862 := by decide
private def t_e1211212328758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211212328758 : ¬ IsSelfInterpreter e1211212328758 :=
  wSource (t := t_e1211212328758) (replay_sound (ps := []) (t := e1211212328758) (by decide)) (by decide)
def e1211212328762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212328762 : Closed e1211212328762 ∧ code e1211212328762 = 5609258839866 := by decide
private def t_e1211212328762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211212328762 : ¬ IsSelfInterpreter e1211212328762 :=
  wSource (t := t_e1211212328762) (replay_sound (ps := []) (t := e1211212328762) (by decide)) (by decide)
def e1211212329454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e1211212329454 : Closed e1211212329454 ∧ code e1211212329454 = 5609258840558 := by decide
theorem cert_e1211212329454 : check e1211212329454 [[],[]] .chain = true := by decide
def e1211212329822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211212329822 : Closed e1211212329822 ∧ code e1211212329822 = 5609258840926 := by decide
theorem cert_e1211212329822 : check e1211212329822 [[],[],[.under,.under]] .three = true := by decide
def e1211212329838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211212329838 : Closed e1211212329838 ∧ code e1211212329838 = 5609258840942 := by decide
theorem cert_e1211212329838 : check e1211212329838 [[],[]] .chain = true := by decide
def e1211212329846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211212329846 : Closed e1211212329846 ∧ code e1211212329846 = 5609258840950 := by decide
theorem cert_e1211212329846 : check e1211212329846 [[],[]] .chain = true := by decide
def e1211212329850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211212329850 : Closed e1211212329850 ∧ code e1211212329850 = 5609258840954 := by decide
theorem cert_e1211212329850 : check e1211212329850 [[],[],[.under,.under]] .three = true := by decide
def e1211212329902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211212329902 : Closed e1211212329902 ∧ code e1211212329902 = 5609258841006 := by decide
theorem cert_e1211212329902 : check e1211212329902 [[],[]] .chain = true := by decide
def e1211212329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211212329914 : Closed e1211212329914 ∧ code e1211212329914 = 5609258841018 := by decide
theorem cert_e1211212329914 : check e1211212329914 [[],[]] .chain = true := by decide
def e1211212329942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211212329942 : Closed e1211212329942 ∧ code e1211212329942 = 5609258841046 := by decide
theorem cert_e1211212329942 : check e1211212329942 [[],[]] .chain = true := by decide
def e1211212329946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211212329946 : Closed e1211212329946 ∧ code e1211212329946 = 5609258841050 := by decide
theorem cert_e1211212329946 : check e1211212329946 [[],[]] .chain = true := by decide
def e1211212329962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211212329962 : Closed e1211212329962 ∧ code e1211212329962 = 5609258841066 := by decide
theorem cert_e1211212329962 : check e1211212329962 [[],[],[.under,.under]] .three = true := by decide
def e1211212330206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211212330206 : Closed e1211212330206 ∧ code e1211212330206 = 5609258841310 := by decide
theorem cert_e1211212330206 : check e1211212330206 [[],[],[.under,.under]] .three = true := by decide
def e1211212330222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211212330222 : Closed e1211212330222 ∧ code e1211212330222 = 5609258841326 := by decide
theorem cert_e1211212330222 : check e1211212330222 [[],[]] .chain = true := by decide
def e1211212330230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211212330230 : Closed e1211212330230 ∧ code e1211212330230 = 5609258841334 := by decide
theorem cert_e1211212330230 : check e1211212330230 [[],[]] .chain = true := by decide
def e1211212330234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211212330234 : Closed e1211212330234 ∧ code e1211212330234 = 5609258841338 := by decide
theorem cert_e1211212330234 : check e1211212330234 [[],[],[.under,.under]] .three = true := by decide
def e1211212330606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211212330606 : Closed e1211212330606 ∧ code e1211212330606 = 5609258841710 := by decide
theorem cert_e1211212330606 : check e1211212330606 [[],[]] .chain = true := by decide
def e1211212330618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211212330618 : Closed e1211212330618 ∧ code e1211212330618 = 5609258841722 := by decide
theorem cert_e1211212330618 : check e1211212330618 [[],[]] .chain = true := by decide
def e1211212330782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e1211212330782 : Closed e1211212330782 ∧ code e1211212330782 = 5609258841886 := by decide
theorem cert_e1211212330782 : check e1211212330782 [[],[]] .chain = true := by decide
def e1211212330806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212330806 : Closed e1211212330806 ∧ code e1211212330806 = 5609258841910 := by decide
theorem cert_e1211212330806 : check e1211212330806 [[],[]] .chain = true := by decide
def e1211212330810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212330810 : Closed e1211212330810 ∧ code e1211212330810 = 5609258841914 := by decide
theorem cert_e1211212330810 : check e1211212330810 [[],[]] .chain = true := by decide
def e1211212330906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212330906 : Closed e1211212330906 ∧ code e1211212330906 = 5609258842010 := by decide
theorem cert_e1211212330906 : check e1211212330906 [[],[],[.under,.under]] .three = true := by decide
def e1211212331230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1211212331230 : Closed e1211212331230 ∧ code e1211212331230 = 5609258842334 := by decide
theorem cert_e1211212331230 : check e1211212331230 [[],[],[.under,.under]] .three = true := by decide
def e1211212331246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211212331246 : Closed e1211212331246 ∧ code e1211212331246 = 5609258842350 := by decide
theorem cert_e1211212331246 : check e1211212331246 [[],[]] .chain = true := by decide
def e1211212331254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211212331254 : Closed e1211212331254 ∧ code e1211212331254 = 5609258842358 := by decide
theorem cert_e1211212331254 : check e1211212331254 [[],[]] .chain = true := by decide
def e1211212331258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1211212331258 : Closed e1211212331258 ∧ code e1211212331258 = 5609258842362 := by decide
theorem cert_e1211212331258 : check e1211212331258 [[],[],[.under,.under]] .three = true := by decide
def e1211212331446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211212331446 : Closed e1211212331446 ∧ code e1211212331446 = 5609258842550 := by decide
theorem cert_e1211212331446 : check e1211212331446 [[],[]] .chain = true := by decide
def e1211212331478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211212331478 : Closed e1211212331478 ∧ code e1211212331478 = 5609258842582 := by decide
theorem cert_e1211212331478 : check e1211212331478 [[],[]] .chain = true := by decide
def e1211212331482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211212331482 : Closed e1211212331482 ∧ code e1211212331482 = 5609258842586 := by decide
theorem cert_e1211212331482 : check e1211212331482 [[],[]] .chain = true := by decide
def e1211212331582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1211212331582 : Closed e1211212331582 ∧ code e1211212331582 = 5609258842686 := by decide
theorem cert_e1211212331582 : check e1211212331582 [[],[],[.under,.under]] .three = true := by decide
def e1211212331638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211212331638 : Closed e1211212331638 ∧ code e1211212331638 = 5609258842742 := by decide
theorem cert_e1211212331638 : check e1211212331638 [[],[]] .chain = true := by decide
def e1211212331806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211212331806 : Closed e1211212331806 ∧ code e1211212331806 = 5609258842910 := by decide
theorem cert_e1211212331806 : check e1211212331806 [[],[]] .chain = true := by decide
def e1211212331830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212331830 : Closed e1211212331830 ∧ code e1211212331830 = 5609258842934 := by decide
theorem cert_e1211212331830 : check e1211212331830 [[],[]] .chain = true := by decide
def e1211212331834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212331834 : Closed e1211212331834 ∧ code e1211212331834 = 5609258842938 := by decide
theorem cert_e1211212331834 : check e1211212331834 [[],[]] .chain = true := by decide
def e1211212331918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211212331918 : Closed e1211212331918 ∧ code e1211212331918 = 5609258843022 := by decide
theorem cert_e1211212331918 : check e1211212331918 [[],[]] .chain = true := by decide
def e1211212331974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1211212331974 : Closed e1211212331974 ∧ code e1211212331974 = 5609258843078 := by decide
theorem cert_e1211212331974 : check e1211212331974 [[],[],[.under,.under]] .three = true := by decide
def e1211212332142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e1211212332142 : Closed e1211212332142 ∧ code e1211212332142 = 5609258843246 := by decide
theorem cert_e1211212332142 : check e1211212332142 [[],[],[.under,.under]] .three = true := by decide
def e1211212332154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e1211212332154 : Closed e1211212332154 ∧ code e1211212332154 = 5609258843258 := by decide
theorem cert_e1211212332154 : check e1211212332154 [[],[],[.under,.under]] .three = true := by decide
def e1211212332246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211212332246 : Closed e1211212332246 ∧ code e1211212332246 = 5609258843350 := by decide
private def t_e1211212332246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem cert_e1211212332246 : ¬ IsSelfInterpreter e1211212332246 :=
  wSource (t := t_e1211212332246) (replay_sound (ps := []) (t := e1211212332246) (by decide)) (by decide)
def e1211212332250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211212332250 : Closed e1211212332250 ∧ code e1211212332250 = 5609258843354 := by decide
theorem cert_e1211212332250 : check e1211212332250 [[],[],[.under,.under]] .three = true := by decide
def e1211212332266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211212332266 : Closed e1211212332266 ∧ code e1211212332266 = 5609258843370 := by decide
theorem cert_e1211212332266 : check e1211212332266 [[],[],[.under,.under]] .three = true := by decide
def e1211212332318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e1211212332318 : Closed e1211212332318 ∧ code e1211212332318 = 5609258843422 := by decide
private def t_e1211212332318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem cert_e1211212332318 : ¬ IsSelfInterpreter e1211212332318 :=
  wSource (t := t_e1211212332318) (replay_sound (ps := []) (t := e1211212332318) (by decide)) (by decide)
def e1211212332342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211212332342 : Closed e1211212332342 ∧ code e1211212332342 = 5609258843446 := by decide
private def t_e1211212332342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211212332342 : ¬ IsSelfInterpreter e1211212332342 :=
  wSource (t := t_e1211212332342) (replay_sound (ps := []) (t := e1211212332342) (by decide)) (by decide)
def e1211212332346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211212332346 : Closed e1211212332346 ∧ code e1211212332346 = 5609258843450 := by decide
private def t_e1211212332346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211212332346 : ¬ IsSelfInterpreter e1211212332346 :=
  wSource (t := t_e1211212332346) (replay_sound (ps := []) (t := e1211212332346) (by decide)) (by decide)
def e1211212332442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211212332442 : Closed e1211212332442 ∧ code e1211212332442 = 5609258843546 := by decide
theorem cert_e1211212332442 : check e1211212332442 [[],[],[.under,.under]] .three = true := by decide
def e1211212332486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e1211212332486 : Closed e1211212332486 ∧ code e1211212332486 = 5609258843590 := by decide
theorem cert_e1211212332486 : check e1211212332486 [[],[],[.under,.under]] .three = true := by decide
def e1211212335038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e1211212335038 : Closed e1211212335038 ∧ code e1211212335038 = 5609258846142 := by decide
theorem cert_e1211212335038 : check e1211212335038 [[],[],[.under,.under]] .three = true := by decide
def e1211212335086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e1211212335086 : Closed e1211212335086 ∧ code e1211212335086 = 5609258846190 := by decide
theorem cert_e1211212335086 : check e1211212335086 [[],[],[.under,.under]] .three = true := by decide
def e1211212338910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e1211212338910 : Closed e1211212338910 ∧ code e1211212338910 = 5609258850014 := by decide
theorem cert_e1211212338910 : check e1211212338910 [[],[],[.under,.under]] .three = true := by decide
def e1211212338934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e1211212338934 : Closed e1211212338934 ∧ code e1211212338934 = 5609258850038 := by decide
private def t_e1211212338934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem cert_e1211212338934 : ¬ IsSelfInterpreter e1211212338934 :=
  wSource (t := t_e1211212338934) (replay_sound (ps := []) (t := e1211212338934) (by decide)) (by decide)
def e1211212339038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e1211212339038 : Closed e1211212339038 ∧ code e1211212339038 = 5609258850142 := by decide
theorem cert_e1211212339038 : check e1211212339038 [[],[],[.under,.under]] .three = true := by decide
def e1211212339054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211212339054 : Closed e1211212339054 ∧ code e1211212339054 = 5609258850158 := by decide
theorem cert_e1211212339054 : check e1211212339054 [[],[]] .chain = true := by decide
def e1211212339062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211212339062 : Closed e1211212339062 ∧ code e1211212339062 = 5609258850166 := by decide
theorem cert_e1211212339062 : check e1211212339062 [[],[]] .chain = true := by decide
def e1211212339066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e1211212339066 : Closed e1211212339066 ∧ code e1211212339066 = 5609258850170 := by decide
theorem cert_e1211212339066 : check e1211212339066 [[],[],[.under,.under]] .three = true := by decide
def e1211212339126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211212339126 : Closed e1211212339126 ∧ code e1211212339126 = 5609258850230 := by decide
theorem cert_e1211212339126 : check e1211212339126 [[],[]] .chain = true := by decide
def e1211212339158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e1211212339158 : Closed e1211212339158 ∧ code e1211212339158 = 5609258850262 := by decide
private def t_e1211212339158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem cert_e1211212339158 : ¬ IsSelfInterpreter e1211212339158 :=
  wSource (t := t_e1211212339158) (replay_sound (ps := []) (t := e1211212339158) (by decide)) (by decide)
def e1211212339162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e1211212339162 : Closed e1211212339162 ∧ code e1211212339162 = 5609258850266 := by decide
theorem cert_e1211212339162 : check e1211212339162 [[],[],[.under,.under]] .three = true := by decide
def e1211212339678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211212339678 : Closed e1211212339678 ∧ code e1211212339678 = 5609258850782 := by decide
theorem cert_e1211212339678 : check e1211212339678 [[],[],[.under,.under]] .three = true := by decide
def e1211212339702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211212339702 : Closed e1211212339702 ∧ code e1211212339702 = 5609258850806 := by decide
theorem cert_e1211212339702 : check e1211212339702 [[],[],[.under,.under]] .three = true := by decide
def e1211212340446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211212340446 : Closed e1211212340446 ∧ code e1211212340446 = 5609258851550 := by decide
theorem cert_e1211212340446 : check e1211212340446 [[],[],[.under,.under]] .three = true := by decide
def e1211212340462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212340462 : Closed e1211212340462 ∧ code e1211212340462 = 5609258851566 := by decide
theorem cert_e1211212340462 : check e1211212340462 [[],[]] .chain = true := by decide
def e1211212340470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212340470 : Closed e1211212340470 ∧ code e1211212340470 = 5609258851574 := by decide
theorem cert_e1211212340470 : check e1211212340470 [[],[]] .chain = true := by decide
def e1211212340474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211212340474 : Closed e1211212340474 ∧ code e1211212340474 = 5609258851578 := by decide
theorem cert_e1211212340474 : check e1211212340474 [[],[],[.under,.under]] .three = true := by decide
def e1211212340798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e1211212340798 : Closed e1211212340798 ∧ code e1211212340798 = 5609258851902 := by decide
theorem cert_e1211212340798 : check e1211212340798 [[],[],[.under,.under]] .three = true := by decide
def e1211212340854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211212340854 : Closed e1211212340854 ∧ code e1211212340854 = 5609258851958 := by decide
theorem cert_e1211212340854 : check e1211212340854 [[],[]] .chain = true := by decide
def e1211212341022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e1211212341022 : Closed e1211212341022 ∧ code e1211212341022 = 5609258852126 := by decide
theorem cert_e1211212341022 : check e1211212341022 [[],[],[.under,.under]] .three = true := by decide
def e1211212341046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212341046 : Closed e1211212341046 ∧ code e1211212341046 = 5609258852150 := by decide
theorem cert_e1211212341046 : check e1211212341046 [[],[],[.under,.under]] .three = true := by decide
def e1211212341050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212341050 : Closed e1211212341050 ∧ code e1211212341050 = 5609258852154 := by decide
theorem cert_e1211212341050 : check e1211212341050 [[],[],[.under,.under]] .three = true := by decide
def e1211212350398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e1211212350398 : Closed e1211212350398 ∧ code e1211212350398 = 5609258861502 := by decide
theorem cert_e1211212350398 : check e1211212350398 [[],[],[.under,.under]] .three = true := by decide
def e1211212350430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211212350430 : Closed e1211212350430 ∧ code e1211212350430 = 5609258861534 := by decide
theorem cert_e1211212350430 : check e1211212350430 [[],[]] .chain = true := by decide
def e1211212350446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211212350446 : Closed e1211212350446 ∧ code e1211212350446 = 5609258861550 := by decide
theorem cert_e1211212350446 : check e1211212350446 [[],[]] .chain = true := by decide
def e1211212350454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e1211212350454 : Closed e1211212350454 ∧ code e1211212350454 = 5609258861558 := by decide
theorem cert_e1211212350454 : check e1211212350454 [[],[],[.under,.under]] .three = true := by decide
def e1211212352350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e1211212352350 : Closed e1211212352350 ∧ code e1211212352350 = 5609258863454 := by decide
theorem cert_e1211212352350 : check e1211212352350 [[],[],[.under,.under]] .three = true := by decide
def e1211212352366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211212352366 : Closed e1211212352366 ∧ code e1211212352366 = 5609258863470 := by decide
theorem cert_e1211212352366 : check e1211212352366 [[],[]] .chain = true := by decide
def e1211212352374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211212352374 : Closed e1211212352374 ∧ code e1211212352374 = 5609258863478 := by decide
theorem cert_e1211212352374 : check e1211212352374 [[],[]] .chain = true := by decide
def e1211212352378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e1211212352378 : Closed e1211212352378 ∧ code e1211212352378 = 5609258863482 := by decide
theorem cert_e1211212352378 : check e1211212352378 [[],[],[.under,.under]] .three = true := by decide
def e1211212352430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211212352430 : Closed e1211212352430 ∧ code e1211212352430 = 5609258863534 := by decide
theorem cert_e1211212352430 : check e1211212352430 [[],[]] .chain = true := by decide
def e1211212352442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211212352442 : Closed e1211212352442 ∧ code e1211212352442 = 5609258863546 := by decide
theorem cert_e1211212352442 : check e1211212352442 [[],[]] .chain = true := by decide
def e1211212352470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211212352470 : Closed e1211212352470 ∧ code e1211212352470 = 5609258863574 := by decide
theorem cert_e1211212352470 : check e1211212352470 [[],[]] .chain = true := by decide
def e1211212352474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211212352474 : Closed e1211212352474 ∧ code e1211212352474 = 5609258863578 := by decide
theorem cert_e1211212352474 : check e1211212352474 [[],[]] .chain = true := by decide
def e1211212352490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e1211212352490 : Closed e1211212352490 ∧ code e1211212352490 = 5609258863594 := by decide
theorem cert_e1211212352490 : check e1211212352490 [[],[],[.under,.under]] .three = true := by decide
def e1211212352734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211212352734 : Closed e1211212352734 ∧ code e1211212352734 = 5609258863838 := by decide
theorem cert_e1211212352734 : check e1211212352734 [[],[],[.under,.under]] .three = true := by decide
def e1211212352750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211212352750 : Closed e1211212352750 ∧ code e1211212352750 = 5609258863854 := by decide
theorem cert_e1211212352750 : check e1211212352750 [[],[]] .chain = true := by decide
def e1211212352758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211212352758 : Closed e1211212352758 ∧ code e1211212352758 = 5609258863862 := by decide
theorem cert_e1211212352758 : check e1211212352758 [[],[]] .chain = true := by decide
def e1211212352762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211212352762 : Closed e1211212352762 ∧ code e1211212352762 = 5609258863866 := by decide
theorem cert_e1211212352762 : check e1211212352762 [[],[],[.under,.under]] .three = true := by decide
def e1211212353134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211212353134 : Closed e1211212353134 ∧ code e1211212353134 = 5609258864238 := by decide
theorem cert_e1211212353134 : check e1211212353134 [[],[]] .chain = true := by decide
def e1211212353146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211212353146 : Closed e1211212353146 ∧ code e1211212353146 = 5609258864250 := by decide
theorem cert_e1211212353146 : check e1211212353146 [[],[]] .chain = true := by decide
def e1211212353310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e1211212353310 : Closed e1211212353310 ∧ code e1211212353310 = 5609258864414 := by decide
theorem cert_e1211212353310 : check e1211212353310 [[],[]] .chain = true := by decide
def e1211212353334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211212353334 : Closed e1211212353334 ∧ code e1211212353334 = 5609258864438 := by decide
theorem cert_e1211212353334 : check e1211212353334 [[],[]] .chain = true := by decide
def e1211212353338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211212353338 : Closed e1211212353338 ∧ code e1211212353338 = 5609258864442 := by decide
theorem cert_e1211212353338 : check e1211212353338 [[],[]] .chain = true := by decide
def e1211212353434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211212353434 : Closed e1211212353434 ∧ code e1211212353434 = 5609258864538 := by decide
theorem cert_e1211212353434 : check e1211212353434 [[],[],[.under,.under]] .three = true := by decide
def e1211212358126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211212358126 : Closed e1211212358126 ∧ code e1211212358126 = 5609258869230 := by decide
theorem cert_e1211212358126 : check e1211212358126 [[],[]] .chain = true := by decide
def e1211212359094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211212359094 : Closed e1211212359094 ∧ code e1211212359094 = 5609258870198 := by decide
theorem cert_e1211212359094 : check e1211212359094 [[],[]] .chain = true := by decide
def e1211212359126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211212359126 : Closed e1211212359126 ∧ code e1211212359126 = 5609258870230 := by decide
theorem cert_e1211212359126 : check e1211212359126 [[],[]] .chain = true := by decide
def e1211212359130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211212359130 : Closed e1211212359130 ∧ code e1211212359130 = 5609258870234 := by decide
theorem cert_e1211212359130 : check e1211212359130 [[],[]] .chain = true := by decide
end Blc.Floor42
