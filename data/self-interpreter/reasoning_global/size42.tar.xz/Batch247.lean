import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211298276986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211298276986 : Closed e1211298276986 ∧ code e1211298276986 = 5609344788090 := by decide
theorem cert_e1211298276986 : check e1211298276986 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298277274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211298277274 : Closed e1211298277274 ∧ code e1211298277274 = 5609344788378 := by decide
theorem cert_e1211298277274 : check e1211298277274 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298277310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e1211298277310 : Closed e1211298277310 ∧ code e1211298277310 = 5609344788414 := by decide
theorem cert_e1211298277310 : check e1211298277310 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298277358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e1211298277358 : Closed e1211298277358 ∧ code e1211298277358 = 5609344788462 := by decide
theorem cert_e1211298277358 : check e1211298277358 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e1211298280150 : Closed e1211298280150 ∧ code e1211298280150 = 5609344791254 := by decide
theorem cert_e1211298280150 : check e1211298280150 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e1211298280154 : Closed e1211298280154 ∧ code e1211298280154 = 5609344791258 := by decide
theorem cert_e1211298280154 : check e1211298280154 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e1211298280170 : Closed e1211298280170 ∧ code e1211298280170 = 5609344791274 := by decide
theorem cert_e1211298280170 : check e1211298280170 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211298280246 : Closed e1211298280246 ∧ code e1211298280246 = 5609344791350 := by decide
theorem cert_e1211298280246 : check e1211298280246 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211298280250 : Closed e1211298280250 ∧ code e1211298280250 = 5609344791354 := by decide
theorem cert_e1211298280250 : check e1211298280250 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e1211298280346 : Closed e1211298280346 ∧ code e1211298280346 = 5609344791450 := by decide
theorem cert_e1211298280346 : check e1211298280346 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e1211298280382 : Closed e1211298280382 ∧ code e1211298280382 = 5609344791486 := by decide
theorem cert_e1211298280382 : check e1211298280382 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298280438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e1211298280438 : Closed e1211298280438 ∧ code e1211298280438 = 5609344791542 := by decide
theorem cert_e1211298280438 : check e1211298280438 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298281918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 4))))))))))
theorem wire_e1211298281918 : Closed e1211298281918 ∧ code e1211298281918 = 5609344793022 := by decide
theorem cert_e1211298281918 : check e1211298281918 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298281978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.var 0))))))))))
theorem wire_e1211298281978 : Closed e1211298281978 ∧ code e1211298281978 = 5609344793082 := by decide
theorem cert_e1211298281978 : check e1211298281978 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298282718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211298282718 : Closed e1211298282718 ∧ code e1211298282718 = 5609344793822 := by decide
theorem cert_e1211298282718 : check e1211298282718 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298282734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211298282734 : Closed e1211298282734 ∧ code e1211298282734 = 5609344793838 := by decide
theorem cert_e1211298282734 : check e1211298282734 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298282742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211298282742 : Closed e1211298282742 ∧ code e1211298282742 = 5609344793846 := by decide
theorem cert_e1211298282742 : check e1211298282742 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298282746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211298282746 : Closed e1211298282746 ∧ code e1211298282746 = 5609344793850 := by decide
theorem cert_e1211298282746 : check e1211298282746 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298395614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e1211298395614 : Closed e1211298395614 ∧ code e1211298395614 = 5609344906718 := by decide
theorem cert_e1211298395614 : check e1211298395614 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298395630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e1211298395630 : Closed e1211298395630 ∧ code e1211298395630 = 5609344906734 := by decide
theorem cert_e1211298395630 : check e1211298395630 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298395870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e1211298395870 : Closed e1211298395870 ∧ code e1211298395870 = 5609344906974 := by decide
theorem cert_e1211298395870 : check e1211298395870 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298395886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e1211298395886 : Closed e1211298395886 ∧ code e1211298395886 = 5609344906990 := by decide
theorem cert_e1211298395886 : check e1211298395886 [[],[]] .chain = true := by decide
def e1211298395894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e1211298395894 : Closed e1211298395894 ∧ code e1211298395894 = 5609344906998 := by decide
theorem cert_e1211298395894 : check e1211298395894 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298395998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e1211298395998 : Closed e1211298395998 ∧ code e1211298395998 = 5609344907102 := by decide
theorem cert_e1211298395998 : check e1211298395998 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298396014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e1211298396014 : Closed e1211298396014 ∧ code e1211298396014 = 5609344907118 := by decide
theorem cert_e1211298396014 : check e1211298396014 [[],[]] .chain = true := by decide
def e1211298396022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e1211298396022 : Closed e1211298396022 ∧ code e1211298396022 = 5609344907126 := by decide
theorem cert_e1211298396022 : check e1211298396022 [[],[]] .chain = true := by decide
def e1211298396026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e1211298396026 : Closed e1211298396026 ∧ code e1211298396026 = 5609344907130 := by decide
theorem cert_e1211298396026 : check e1211298396026 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298396078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e1211298396078 : Closed e1211298396078 ∧ code e1211298396078 = 5609344907182 := by decide
theorem cert_e1211298396078 : check e1211298396078 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298396086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e1211298396086 : Closed e1211298396086 ∧ code e1211298396086 = 5609344907190 := by decide
theorem cert_e1211298396086 : check e1211298396086 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298396090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e1211298396090 : Closed e1211298396090 ∧ code e1211298396090 = 5609344907194 := by decide
theorem cert_e1211298396090 : check e1211298396090 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298396894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1211298396894 : Closed e1211298396894 ∧ code e1211298396894 = 5609344907998 := by decide
theorem cert_e1211298396894 : check e1211298396894 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298396910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e1211298396910 : Closed e1211298396910 ∧ code e1211298396910 = 5609344908014 := by decide
theorem cert_e1211298396910 : check e1211298396910 [[],[]] .chain = true := by decide
def e1211298396918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1211298396918 : Closed e1211298396918 ∧ code e1211298396918 = 5609344908022 := by decide
theorem cert_e1211298396918 : check e1211298396918 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1211298397022 : Closed e1211298397022 ∧ code e1211298397022 = 5609344908126 := by decide
private def t_e1211298397022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem cert_e1211298397022 : ¬ IsSelfInterpreter e1211298397022 :=
  wSource (t := t_e1211298397022) (replay_sound (ps := []) (t := e1211298397022) (by decide)) (by decide)
def e1211298397050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1211298397050 : Closed e1211298397050 ∧ code e1211298397050 = 5609344908154 := by decide
private def t_e1211298397050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem cert_e1211298397050 : ¬ IsSelfInterpreter e1211298397050 :=
  wSource (t := t_e1211298397050) (replay_sound (ps := []) (t := e1211298397050) (by decide)) (by decide)
def e1211298397102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e1211298397102 : Closed e1211298397102 ∧ code e1211298397102 = 5609344908206 := by decide
theorem cert_e1211298397102 : check e1211298397102 [[],[]] .chain = true := by decide
def e1211298397114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e1211298397114 : Closed e1211298397114 ∧ code e1211298397114 = 5609344908218 := by decide
theorem cert_e1211298397114 : check e1211298397114 [[],[]] .chain = true := by decide
def e1211298397142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1211298397142 : Closed e1211298397142 ∧ code e1211298397142 = 5609344908246 := by decide
private def t_e1211298397142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem cert_e1211298397142 : ¬ IsSelfInterpreter e1211298397142 :=
  wSource (t := t_e1211298397142) (replay_sound (ps := []) (t := e1211298397142) (by decide)) (by decide)
def e1211298397146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1211298397146 : Closed e1211298397146 ∧ code e1211298397146 = 5609344908250 := by decide
private def t_e1211298397146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem cert_e1211298397146 : ¬ IsSelfInterpreter e1211298397146 :=
  wSource (t := t_e1211298397146) (replay_sound (ps := []) (t := e1211298397146) (by decide)) (by decide)
def e1211298397534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1211298397534 : Closed e1211298397534 ∧ code e1211298397534 = 5609344908638 := by decide
theorem cert_e1211298397534 : check e1211298397534 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211298397550 : Closed e1211298397550 ∧ code e1211298397550 = 5609344908654 := by decide
theorem cert_e1211298397550 : check e1211298397550 [[],[]] .chain = true := by decide
def e1211298397558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211298397558 : Closed e1211298397558 ∧ code e1211298397558 = 5609344908662 := by decide
theorem cert_e1211298397558 : check e1211298397558 [[],[]] .chain = true := by decide
def e1211298397562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1211298397562 : Closed e1211298397562 ∧ code e1211298397562 = 5609344908666 := by decide
theorem cert_e1211298397562 : check e1211298397562 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211298397614 : Closed e1211298397614 ∧ code e1211298397614 = 5609344908718 := by decide
theorem cert_e1211298397614 : check e1211298397614 [[],[]] .chain = true := by decide
def e1211298397626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211298397626 : Closed e1211298397626 ∧ code e1211298397626 = 5609344908730 := by decide
theorem cert_e1211298397626 : check e1211298397626 [[],[]] .chain = true := by decide
def e1211298397654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211298397654 : Closed e1211298397654 ∧ code e1211298397654 = 5609344908758 := by decide
theorem cert_e1211298397654 : check e1211298397654 [[],[]] .chain = true := by decide
def e1211298397658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211298397658 : Closed e1211298397658 ∧ code e1211298397658 = 5609344908762 := by decide
theorem cert_e1211298397658 : check e1211298397658 [[],[]] .chain = true := by decide
def e1211298397674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1211298397674 : Closed e1211298397674 ∧ code e1211298397674 = 5609344908778 := by decide
theorem cert_e1211298397674 : check e1211298397674 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211298397870 : Closed e1211298397870 ∧ code e1211298397870 = 5609344908974 := by decide
theorem cert_e1211298397870 : check e1211298397870 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211298397878 : Closed e1211298397878 ∧ code e1211298397878 = 5609344908982 := by decide
theorem cert_e1211298397878 : check e1211298397878 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211298397882 : Closed e1211298397882 ∧ code e1211298397882 = 5609344908986 := by decide
theorem cert_e1211298397882 : check e1211298397882 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298397910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211298397910 : Closed e1211298397910 ∧ code e1211298397910 = 5609344909014 := by decide
private def t_e1211298397910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem cert_e1211298397910 : ¬ IsSelfInterpreter e1211298397910 :=
  wSource (t := t_e1211298397910) (replay_sound (ps := []) (t := e1211298397910) (by decide)) (by decide)
def e1211298397914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211298397914 : Closed e1211298397914 ∧ code e1211298397914 = 5609344909018 := by decide
private def t_e1211298397914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem cert_e1211298397914 : ¬ IsSelfInterpreter e1211298397914 :=
  wSource (t := t_e1211298397914) (replay_sound (ps := []) (t := e1211298397914) (by decide)) (by decide)
def e1211298397930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211298397930 : Closed e1211298397930 ∧ code e1211298397930 = 5609344909034 := by decide
theorem cert_e1211298397930 : check e1211298397930 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298401758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1211298401758 : Closed e1211298401758 ∧ code e1211298401758 = 5609344912862 := by decide
theorem cert_e1211298401758 : check e1211298401758 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298401774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1211298401774 : Closed e1211298401774 ∧ code e1211298401774 = 5609344912878 := by decide
theorem cert_e1211298401774 : check e1211298401774 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e1211298402014 : Closed e1211298402014 ∧ code e1211298402014 = 5609344913118 := by decide
theorem cert_e1211298402014 : check e1211298402014 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e1211298402030 : Closed e1211298402030 ∧ code e1211298402030 = 5609344913134 := by decide
theorem cert_e1211298402030 : check e1211298402030 [[],[]] .chain = true := by decide
def e1211298402038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e1211298402038 : Closed e1211298402038 ∧ code e1211298402038 = 5609344913142 := by decide
theorem cert_e1211298402038 : check e1211298402038 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1211298402142 : Closed e1211298402142 ∧ code e1211298402142 = 5609344913246 := by decide
theorem cert_e1211298402142 : check e1211298402142 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e1211298402158 : Closed e1211298402158 ∧ code e1211298402158 = 5609344913262 := by decide
theorem cert_e1211298402158 : check e1211298402158 [[],[]] .chain = true := by decide
def e1211298402166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e1211298402166 : Closed e1211298402166 ∧ code e1211298402166 = 5609344913270 := by decide
theorem cert_e1211298402166 : check e1211298402166 [[],[]] .chain = true := by decide
def e1211298402170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1211298402170 : Closed e1211298402170 ∧ code e1211298402170 = 5609344913274 := by decide
theorem cert_e1211298402170 : check e1211298402170 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1211298402222 : Closed e1211298402222 ∧ code e1211298402222 = 5609344913326 := by decide
theorem cert_e1211298402222 : check e1211298402222 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e1211298402230 : Closed e1211298402230 ∧ code e1211298402230 = 5609344913334 := by decide
theorem cert_e1211298402230 : check e1211298402230 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298402234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1211298402234 : Closed e1211298402234 ∧ code e1211298402234 = 5609344913338 := by decide
theorem cert_e1211298402234 : check e1211298402234 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298403294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211298403294 : Closed e1211298403294 ∧ code e1211298403294 = 5609344914398 := by decide
theorem cert_e1211298403294 : check e1211298403294 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298403310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211298403310 : Closed e1211298403310 ∧ code e1211298403310 = 5609344914414 := by decide
theorem cert_e1211298403310 : check e1211298403310 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298404830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211298404830 : Closed e1211298404830 ∧ code e1211298404830 = 5609344915934 := by decide
theorem cert_e1211298404830 : check e1211298404830 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298404846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211298404846 : Closed e1211298404846 ∧ code e1211298404846 = 5609344915950 := by decide
theorem cert_e1211298404846 : check e1211298404846 [[],[]] .chain = true := by decide
def e1211298404854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211298404854 : Closed e1211298404854 ∧ code e1211298404854 = 5609344915958 := by decide
theorem cert_e1211298404854 : check e1211298404854 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298405598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211298405598 : Closed e1211298405598 ∧ code e1211298405598 = 5609344916702 := by decide
theorem cert_e1211298405598 : check e1211298405598 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298405614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211298405614 : Closed e1211298405614 ∧ code e1211298405614 = 5609344916718 := by decide
theorem cert_e1211298405614 : check e1211298405614 [[],[]] .chain = true := by decide
def e1211298405622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211298405622 : Closed e1211298405622 ∧ code e1211298405622 = 5609344916726 := by decide
theorem cert_e1211298405622 : check e1211298405622 [[],[]] .chain = true := by decide
def e1211298405626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211298405626 : Closed e1211298405626 ∧ code e1211298405626 = 5609344916730 := by decide
theorem cert_e1211298405626 : check e1211298405626 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298405998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298405998 : Closed e1211298405998 ∧ code e1211298405998 = 5609344917102 := by decide
theorem cert_e1211298405998 : check e1211298405998 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298406006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211298406006 : Closed e1211298406006 ∧ code e1211298406006 = 5609344917110 := by decide
theorem cert_e1211298406006 : check e1211298406006 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298406010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298406010 : Closed e1211298406010 ∧ code e1211298406010 = 5609344917114 := by decide
theorem cert_e1211298406010 : check e1211298406010 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298407390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e1211298407390 : Closed e1211298407390 ∧ code e1211298407390 = 5609344918494 := by decide
theorem cert_e1211298407390 : check e1211298407390 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298407406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e1211298407406 : Closed e1211298407406 ∧ code e1211298407406 = 5609344918510 := by decide
theorem cert_e1211298407406 : check e1211298407406 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298408158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1211298408158 : Closed e1211298408158 ∧ code e1211298408158 = 5609344919262 := by decide
theorem cert_e1211298408158 : check e1211298408158 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298408174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e1211298408174 : Closed e1211298408174 ∧ code e1211298408174 = 5609344919278 := by decide
theorem cert_e1211298408174 : check e1211298408174 [[],[]] .chain = true := by decide
def e1211298408182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1211298408182 : Closed e1211298408182 ∧ code e1211298408182 = 5609344919286 := by decide
theorem cert_e1211298408182 : check e1211298408182 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298408286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1211298408286 : Closed e1211298408286 ∧ code e1211298408286 = 5609344919390 := by decide
theorem cert_e1211298408286 : check e1211298408286 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298408314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1211298408314 : Closed e1211298408314 ∧ code e1211298408314 = 5609344919418 := by decide
private def t_e1211298408314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem cert_e1211298408314 : ¬ IsSelfInterpreter e1211298408314 :=
  wSource (t := t_e1211298408314) (replay_sound (ps := []) (t := e1211298408314) (by decide)) (by decide)
def e1211298408366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e1211298408366 : Closed e1211298408366 ∧ code e1211298408366 = 5609344919470 := by decide
theorem cert_e1211298408366 : check e1211298408366 [[],[]] .chain = true := by decide
def e1211298408378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e1211298408378 : Closed e1211298408378 ∧ code e1211298408378 = 5609344919482 := by decide
theorem cert_e1211298408378 : check e1211298408378 [[],[]] .chain = true := by decide
def e1211298408406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1211298408406 : Closed e1211298408406 ∧ code e1211298408406 = 5609344919510 := by decide
theorem cert_e1211298408406 : check e1211298408406 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298408410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1211298408410 : Closed e1211298408410 ∧ code e1211298408410 = 5609344919514 := by decide
private def t_e1211298408410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem cert_e1211298408410 : ¬ IsSelfInterpreter e1211298408410 :=
  wSource (t := t_e1211298408410) (replay_sound (ps := []) (t := e1211298408410) (by decide)) (by decide)
def e1211298408926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211298408926 : Closed e1211298408926 ∧ code e1211298408926 = 5609344920030 := by decide
theorem cert_e1211298408926 : check e1211298408926 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298408942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211298408942 : Closed e1211298408942 ∧ code e1211298408942 = 5609344920046 := by decide
theorem cert_e1211298408942 : check e1211298408942 [[],[]] .chain = true := by decide
def e1211298408950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211298408950 : Closed e1211298408950 ∧ code e1211298408950 = 5609344920054 := by decide
theorem cert_e1211298408950 : check e1211298408950 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298409694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211298409694 : Closed e1211298409694 ∧ code e1211298409694 = 5609344920798 := by decide
private def t_e1211298409694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem cert_e1211298409694 : ¬ IsSelfInterpreter e1211298409694 :=
  wSource (t := t_e1211298409694) (replay_sound (ps := []) (t := e1211298409694) (by decide)) (by decide)
def e1211298409722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211298409722 : Closed e1211298409722 ∧ code e1211298409722 = 5609344920826 := by decide
private def t_e1211298409722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem cert_e1211298409722 : ¬ IsSelfInterpreter e1211298409722 :=
  wSource (t := t_e1211298409722) (replay_sound (ps := []) (t := e1211298409722) (by decide)) (by decide)
def e1211298410046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e1211298410046 : Closed e1211298410046 ∧ code e1211298410046 = 5609344921150 := by decide
theorem cert_e1211298410046 : check e1211298410046 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298410094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298410094 : Closed e1211298410094 ∧ code e1211298410094 = 5609344921198 := by decide
theorem cert_e1211298410094 : check e1211298410094 [[],[]] .chain = true := by decide
def e1211298410106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298410106 : Closed e1211298410106 ∧ code e1211298410106 = 5609344921210 := by decide
theorem cert_e1211298410106 : check e1211298410106 [[],[]] .chain = true := by decide
def e1211298410270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e1211298410270 : Closed e1211298410270 ∧ code e1211298410270 = 5609344921374 := by decide
private def t_e1211298410270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem cert_e1211298410270 : ¬ IsSelfInterpreter e1211298410270 :=
  wSource (t := t_e1211298410270) (replay_sound (ps := []) (t := e1211298410270) (by decide)) (by decide)
def e1211298410294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211298410294 : Closed e1211298410294 ∧ code e1211298410294 = 5609344921398 := by decide
private def t_e1211298410294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211298410294 : ¬ IsSelfInterpreter e1211298410294 :=
  wSource (t := t_e1211298410294) (replay_sound (ps := []) (t := e1211298410294) (by decide)) (by decide)
def e1211298410298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211298410298 : Closed e1211298410298 ∧ code e1211298410298 = 5609344921402 := by decide
private def t_e1211298410298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211298410298 : ¬ IsSelfInterpreter e1211298410298 :=
  wSource (t := t_e1211298410298) (replay_sound (ps := []) (t := e1211298410298) (by decide)) (by decide)
def e1211298410974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1211298410974 : Closed e1211298410974 ∧ code e1211298410974 = 5609344922078 := by decide
theorem cert_e1211298410974 : check e1211298410974 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298410998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1211298410998 : Closed e1211298410998 ∧ code e1211298410998 = 5609344922102 := by decide
theorem cert_e1211298410998 : check e1211298410998 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298411358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1211298411358 : Closed e1211298411358 ∧ code e1211298411358 = 5609344922462 := by decide
theorem cert_e1211298411358 : check e1211298411358 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298411374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211298411374 : Closed e1211298411374 ∧ code e1211298411374 = 5609344922478 := by decide
theorem cert_e1211298411374 : check e1211298411374 [[],[]] .chain = true := by decide
def e1211298411382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211298411382 : Closed e1211298411382 ∧ code e1211298411382 = 5609344922486 := by decide
theorem cert_e1211298411382 : check e1211298411382 [[],[]] .chain = true := by decide
def e1211298411386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1211298411386 : Closed e1211298411386 ∧ code e1211298411386 = 5609344922490 := by decide
theorem cert_e1211298411386 : check e1211298411386 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298411438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211298411438 : Closed e1211298411438 ∧ code e1211298411438 = 5609344922542 := by decide
theorem cert_e1211298411438 : check e1211298411438 [[],[]] .chain = true := by decide
def e1211298411450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211298411450 : Closed e1211298411450 ∧ code e1211298411450 = 5609344922554 := by decide
theorem cert_e1211298411450 : check e1211298411450 [[],[]] .chain = true := by decide
def e1211298411478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211298411478 : Closed e1211298411478 ∧ code e1211298411478 = 5609344922582 := by decide
theorem cert_e1211298411478 : check e1211298411478 [[],[]] .chain = true := by decide
def e1211298411482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211298411482 : Closed e1211298411482 ∧ code e1211298411482 = 5609344922586 := by decide
theorem cert_e1211298411482 : check e1211298411482 [[],[]] .chain = true := by decide
def e1211298411498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1211298411498 : Closed e1211298411498 ∧ code e1211298411498 = 5609344922602 := by decide
theorem cert_e1211298411498 : check e1211298411498 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298411742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211298411742 : Closed e1211298411742 ∧ code e1211298411742 = 5609344922846 := by decide
theorem cert_e1211298411742 : check e1211298411742 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298411758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211298411758 : Closed e1211298411758 ∧ code e1211298411758 = 5609344922862 := by decide
theorem cert_e1211298411758 : check e1211298411758 [[],[]] .chain = true := by decide
def e1211298411766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211298411766 : Closed e1211298411766 ∧ code e1211298411766 = 5609344922870 := by decide
theorem cert_e1211298411766 : check e1211298411766 [[],[]] .chain = true := by decide
def e1211298411770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211298411770 : Closed e1211298411770 ∧ code e1211298411770 = 5609344922874 := by decide
theorem cert_e1211298411770 : check e1211298411770 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1211298412094 : Closed e1211298412094 ∧ code e1211298412094 = 5609344923198 := by decide
theorem cert_e1211298412094 : check e1211298412094 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298412142 : Closed e1211298412142 ∧ code e1211298412142 = 5609344923246 := by decide
theorem cert_e1211298412142 : check e1211298412142 [[],[]] .chain = true := by decide
def e1211298412154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298412154 : Closed e1211298412154 ∧ code e1211298412154 = 5609344923258 := by decide
theorem cert_e1211298412154 : check e1211298412154 [[],[]] .chain = true := by decide
def e1211298412342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211298412342 : Closed e1211298412342 ∧ code e1211298412342 = 5609344923446 := by decide
theorem cert_e1211298412342 : check e1211298412342 [[],[]] .chain = true := by decide
def e1211298412346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211298412346 : Closed e1211298412346 ∧ code e1211298412346 = 5609344923450 := by decide
theorem cert_e1211298412346 : check e1211298412346 [[],[]] .chain = true := by decide
def e1211298412430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1211298412430 : Closed e1211298412430 ∧ code e1211298412430 = 5609344923534 := by decide
theorem cert_e1211298412430 : check e1211298412430 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298412442 : Closed e1211298412442 ∧ code e1211298412442 = 5609344923546 := by decide
theorem cert_e1211298412442 : check e1211298412442 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e1211298412782 : Closed e1211298412782 ∧ code e1211298412782 = 5609344923886 := by decide
theorem cert_e1211298412782 : check e1211298412782 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e1211298412790 : Closed e1211298412790 ∧ code e1211298412790 = 5609344923894 := by decide
theorem cert_e1211298412790 : check e1211298412790 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211298412974 : Closed e1211298412974 ∧ code e1211298412974 = 5609344924078 := by decide
theorem cert_e1211298412974 : check e1211298412974 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211298412982 : Closed e1211298412982 ∧ code e1211298412982 = 5609344924086 := by decide
theorem cert_e1211298412982 : check e1211298412982 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298412986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211298412986 : Closed e1211298412986 ∧ code e1211298412986 = 5609344924090 := by decide
theorem cert_e1211298412986 : check e1211298412986 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211298413014 : Closed e1211298413014 ∧ code e1211298413014 = 5609344924118 := by decide
theorem cert_e1211298413014 : check e1211298413014 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211298413018 : Closed e1211298413018 ∧ code e1211298413018 = 5609344924122 := by decide
private def t_e1211298413018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem cert_e1211298413018 : ¬ IsSelfInterpreter e1211298413018 :=
  wSource (t := t_e1211298413018) (replay_sound (ps := []) (t := e1211298413018) (by decide)) (by decide)
def e1211298413034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211298413034 : Closed e1211298413034 ∧ code e1211298413034 = 5609344924138 := by decide
theorem cert_e1211298413034 : check e1211298413034 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211298413166 : Closed e1211298413166 ∧ code e1211298413166 = 5609344924270 := by decide
theorem cert_e1211298413166 : check e1211298413166 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211298413174 : Closed e1211298413174 ∧ code e1211298413174 = 5609344924278 := by decide
theorem cert_e1211298413174 : check e1211298413174 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211298413178 : Closed e1211298413178 ∧ code e1211298413178 = 5609344924282 := by decide
theorem cert_e1211298413178 : check e1211298413178 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e1211298413342 : Closed e1211298413342 ∧ code e1211298413342 = 5609344924446 := by decide
private def t_e1211298413342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem cert_e1211298413342 : ¬ IsSelfInterpreter e1211298413342 :=
  wSource (t := t_e1211298413342) (replay_sound (ps := []) (t := e1211298413342) (by decide)) (by decide)
def e1211298413366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211298413366 : Closed e1211298413366 ∧ code e1211298413366 = 5609344924470 := by decide
private def t_e1211298413366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211298413366 : ¬ IsSelfInterpreter e1211298413366 :=
  wSource (t := t_e1211298413366) (replay_sound (ps := []) (t := e1211298413366) (by decide)) (by decide)
def e1211298413370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211298413370 : Closed e1211298413370 ∧ code e1211298413370 = 5609344924474 := by decide
private def t_e1211298413370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211298413370 : ¬ IsSelfInterpreter e1211298413370 :=
  wSource (t := t_e1211298413370) (replay_sound (ps := []) (t := e1211298413370) (by decide)) (by decide)
def e1211298413454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e1211298413454 : Closed e1211298413454 ∧ code e1211298413454 = 5609344924558 := by decide
theorem cert_e1211298413454 : check e1211298413454 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298413466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211298413466 : Closed e1211298413466 ∧ code e1211298413466 = 5609344924570 := by decide
theorem cert_e1211298413466 : check e1211298413466 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211298417518 : Closed e1211298417518 ∧ code e1211298417518 = 5609344928622 := by decide
theorem cert_e1211298417518 : check e1211298417518 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211298417526 : Closed e1211298417526 ∧ code e1211298417526 = 5609344928630 := by decide
theorem cert_e1211298417526 : check e1211298417526 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211298417582 : Closed e1211298417582 ∧ code e1211298417582 = 5609344928686 := by decide
theorem cert_e1211298417582 : check e1211298417582 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211298417594 : Closed e1211298417594 ∧ code e1211298417594 = 5609344928698 := by decide
theorem cert_e1211298417594 : check e1211298417594 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211298417622 : Closed e1211298417622 ∧ code e1211298417622 = 5609344928726 := by decide
theorem cert_e1211298417622 : check e1211298417622 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211298417626 : Closed e1211298417626 ∧ code e1211298417626 = 5609344928730 := by decide
theorem cert_e1211298417626 : check e1211298417626 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211298417902 : Closed e1211298417902 ∧ code e1211298417902 = 5609344929006 := by decide
theorem cert_e1211298417902 : check e1211298417902 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298417910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211298417910 : Closed e1211298417910 ∧ code e1211298417910 = 5609344929014 := by decide
theorem cert_e1211298417910 : check e1211298417910 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298418286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211298418286 : Closed e1211298418286 ∧ code e1211298418286 = 5609344929390 := by decide
theorem cert_e1211298418286 : check e1211298418286 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298418298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211298418298 : Closed e1211298418298 ∧ code e1211298418298 = 5609344929402 := by decide
theorem cert_e1211298418298 : check e1211298418298 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298418486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211298418486 : Closed e1211298418486 ∧ code e1211298418486 = 5609344929590 := by decide
theorem cert_e1211298418486 : check e1211298418486 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298418490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211298418490 : Closed e1211298418490 ∧ code e1211298418490 = 5609344929594 := by decide
theorem cert_e1211298418490 : check e1211298418490 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298418622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e1211298418622 : Closed e1211298418622 ∧ code e1211298418622 = 5609344929726 := by decide
theorem cert_e1211298418622 : check e1211298418622 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298418654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e1211298418654 : Closed e1211298418654 ∧ code e1211298418654 = 5609344929758 := by decide
theorem cert_e1211298418654 : check e1211298418654 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211298426334 : Closed e1211298426334 ∧ code e1211298426334 = 5609344937438 := by decide
theorem cert_e1211298426334 : check e1211298426334 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211298426350 : Closed e1211298426350 ∧ code e1211298426350 = 5609344937454 := by decide
theorem cert_e1211298426350 : check e1211298426350 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1211298426590 : Closed e1211298426590 ∧ code e1211298426590 = 5609344937694 := by decide
theorem cert_e1211298426590 : check e1211298426590 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1211298426606 : Closed e1211298426606 ∧ code e1211298426606 = 5609344937710 := by decide
theorem cert_e1211298426606 : check e1211298426606 [[],[]] .chain = true := by decide
def e1211298426614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1211298426614 : Closed e1211298426614 ∧ code e1211298426614 = 5609344937718 := by decide
theorem cert_e1211298426614 : check e1211298426614 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211298426718 : Closed e1211298426718 ∧ code e1211298426718 = 5609344937822 := by decide
theorem cert_e1211298426718 : check e1211298426718 [[],[],[.under],[.under,.under]] .three = true := by decide
def e1211298426734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1211298426734 : Closed e1211298426734 ∧ code e1211298426734 = 5609344937838 := by decide
theorem cert_e1211298426734 : check e1211298426734 [[],[]] .chain = true := by decide
def e1211298426742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1211298426742 : Closed e1211298426742 ∧ code e1211298426742 = 5609344937846 := by decide
theorem cert_e1211298426742 : check e1211298426742 [[],[]] .chain = true := by decide
end Blc.Floor42
