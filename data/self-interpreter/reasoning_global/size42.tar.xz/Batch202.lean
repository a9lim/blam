import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205106562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205106562 : Closed e1211205106562 ∧ code e1211205106562 = 5609251617666 := by decide
theorem cert_e1211205106562 : check e1211205106562 [[],[]] .chain = true := by decide
def e1211205106574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211205106574 : Closed e1211205106574 ∧ code e1211205106574 = 5609251617678 := by decide
theorem cert_e1211205106574 : check e1211205106574 [[],[]] .chain = true := by decide
def e1211205106586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205106586 : Closed e1211205106586 ∧ code e1211205106586 = 5609251617690 := by decide
theorem cert_e1211205106586 : check e1211205106586 [[],[]] .chain = true := by decide
def e1211205106710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211205106710 : Closed e1211205106710 ∧ code e1211205106710 = 5609251617814 := by decide
theorem cert_e1211205106710 : check e1211205106710 [[],[]] .chain = true := by decide
def e1211205106714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211205106714 : Closed e1211205106714 ∧ code e1211205106714 = 5609251617818 := by decide
theorem cert_e1211205106714 : check e1211205106714 [[],[]] .chain = true := by decide
def e1211205106758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211205106758 : Closed e1211205106758 ∧ code e1211205106758 = 5609251617862 := by decide
theorem cert_e1211205106758 : check e1211205106758 [[],[]] .chain = true := by decide
def e1211205106786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211205106786 : Closed e1211205106786 ∧ code e1211205106786 = 5609251617890 := by decide
theorem cert_e1211205106786 : check e1211205106786 [[],[]] .chain = true := by decide
def e1211205106798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211205106798 : Closed e1211205106798 ∧ code e1211205106798 = 5609251617902 := by decide
theorem cert_e1211205106798 : checkPay e1211205106798 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[.left,.left],[.left],[]] = true := by decide
def e1211205106806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 1))))))
theorem wire_e1211205106806 : Closed e1211205106806 ∧ code e1211205106806 = 5609251617910 := by decide
theorem cert_e1211205106806 : check e1211205106806 [[],[]] .chain = true := by decide
def e1211205106810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211205106810 : Closed e1211205106810 ∧ code e1211205106810 = 5609251617914 := by decide
theorem cert_e1211205106810 : checkPay e1211205106810 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e1211205106902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e1211205106902 : Closed e1211205106902 ∧ code e1211205106902 = 5609251618006 := by decide
theorem cert_e1211205106902 : check e1211205106902 [[],[]] .chain = true := by decide
def e1211205106906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e1211205106906 : Closed e1211205106906 ∧ code e1211205106906 = 5609251618010 := by decide
theorem cert_e1211205106906 : check e1211205106906 [[],[]] .chain = true := by decide
def e1211205106922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e1211205106922 : Closed e1211205106922 ∧ code e1211205106922 = 5609251618026 := by decide
theorem cert_e1211205106922 : check e1211205106922 [[],[]] .chain = true := by decide
def e1211205106950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 1))))))))
theorem wire_e1211205106950 : Closed e1211205106950 ∧ code e1211205106950 = 5609251618054 := by decide
theorem cert_e1211205106950 : check e1211205106950 [[],[]] .chain = true := by decide
def e1211205106974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211205106974 : Closed e1211205106974 ∧ code e1211205106974 = 5609251618078 := by decide
theorem cert_e1211205106974 : checkPay e1211205106974 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1211205106998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205106998 : Closed e1211205106998 ∧ code e1211205106998 = 5609251618102 := by decide
theorem cert_e1211205106998 : check e1211205106998 [[],[]] .chain = true := by decide
def e1211205107002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205107002 : Closed e1211205107002 ∧ code e1211205107002 = 5609251618106 := by decide
theorem cert_e1211205107002 : check e1211205107002 [[],[]] .chain = true := by decide
def e1211205107074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205107074 : Closed e1211205107074 ∧ code e1211205107074 = 5609251618178 := by decide
theorem cert_e1211205107074 : check e1211205107074 [[],[]] .chain = true := by decide
def e1211205107086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e1211205107086 : Closed e1211205107086 ∧ code e1211205107086 = 5609251618190 := by decide
theorem cert_e1211205107086 : check e1211205107086 [[],[]] .chain = true := by decide
def e1211205107098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205107098 : Closed e1211205107098 ∧ code e1211205107098 = 5609251618202 := by decide
theorem cert_e1211205107098 : check e1211205107098 [[],[]] .chain = true := by decide
def e1211205107142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211205107142 : Closed e1211205107142 ∧ code e1211205107142 = 5609251618246 := by decide
theorem cert_e1211205107142 : checkPay e1211205107142 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e1211205107838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e1211205107838 : Closed e1211205107838 ∧ code e1211205107838 = 5609251618942 := by decide
theorem cert_e1211205107838 : check e1211205107838 [[],[]] .chain = true := by decide
def e1211205108702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1211205108702 : Closed e1211205108702 ∧ code e1211205108702 = 5609251619806 := by decide
theorem cert_e1211205108702 : check e1211205108702 [[],[]] .chain = true := by decide
def e1211205108706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211205108706 : Closed e1211205108706 ∧ code e1211205108706 = 5609251619810 := by decide
theorem cert_e1211205108706 : check e1211205108706 [[],[]] .chain = true := by decide
def e1211205108718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1211205108718 : Closed e1211205108718 ∧ code e1211205108718 = 5609251619822 := by decide
theorem cert_e1211205108718 : check e1211205108718 [[],[]] .chain = true := by decide
def e1211205110638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1211205110638 : Closed e1211205110638 ∧ code e1211205110638 = 5609251621742 := by decide
theorem cert_e1211205110638 : check e1211205110638 [[],[]] .chain = true := by decide
def e1211205110646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1211205110646 : Closed e1211205110646 ∧ code e1211205110646 = 5609251621750 := by decide
theorem cert_e1211205110646 : check e1211205110646 [[],[]] .chain = true := by decide
def e1211205110702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1211205110702 : Closed e1211205110702 ∧ code e1211205110702 = 5609251621806 := by decide
theorem cert_e1211205110702 : check e1211205110702 [[],[]] .chain = true := by decide
def e1211205110714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1211205110714 : Closed e1211205110714 ∧ code e1211205110714 = 5609251621818 := by decide
theorem cert_e1211205110714 : check e1211205110714 [[],[]] .chain = true := by decide
def e1211205110742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1211205110742 : Closed e1211205110742 ∧ code e1211205110742 = 5609251621846 := by decide
theorem cert_e1211205110742 : check e1211205110742 [[],[]] .chain = true := by decide
def e1211205110746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1211205110746 : Closed e1211205110746 ∧ code e1211205110746 = 5609251621850 := by decide
theorem cert_e1211205110746 : check e1211205110746 [[],[]] .chain = true := by decide
def e1211205111022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1211205111022 : Closed e1211205111022 ∧ code e1211205111022 = 5609251622126 := by decide
theorem cert_e1211205111022 : check e1211205111022 [[],[]] .chain = true := by decide
def e1211205111030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1211205111030 : Closed e1211205111030 ∧ code e1211205111030 = 5609251622134 := by decide
theorem cert_e1211205111030 : check e1211205111030 [[],[]] .chain = true := by decide
def e1211205111406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205111406 : Closed e1211205111406 ∧ code e1211205111406 = 5609251622510 := by decide
theorem cert_e1211205111406 : check e1211205111406 [[],[]] .chain = true := by decide
def e1211205111418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205111418 : Closed e1211205111418 ∧ code e1211205111418 = 5609251622522 := by decide
theorem cert_e1211205111418 : check e1211205111418 [[],[]] .chain = true := by decide
def e1211205111558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205111558 : Closed e1211205111558 ∧ code e1211205111558 = 5609251622662 := by decide
theorem cert_e1211205111558 : check e1211205111558 [[],[]] .chain = true := by decide
def e1211205111582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e1211205111582 : Closed e1211205111582 ∧ code e1211205111582 = 5609251622686 := by decide
theorem cert_e1211205111582 : checkPay e1211205111582 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e1211205111606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205111606 : Closed e1211205111606 ∧ code e1211205111606 = 5609251622710 := by decide
theorem cert_e1211205111606 : check e1211205111606 [[],[]] .chain = true := by decide
def e1211205111610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205111610 : Closed e1211205111610 ∧ code e1211205111610 = 5609251622714 := by decide
theorem cert_e1211205111610 : check e1211205111610 [[],[]] .chain = true := by decide
def e1211205116382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211205116382 : Closed e1211205116382 ∧ code e1211205116382 = 5609251627486 := by decide
theorem cert_e1211205116382 : check e1211205116382 [[],[]] .chain = true := by decide
def e1211205116406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211205116406 : Closed e1211205116406 ∧ code e1211205116406 = 5609251627510 := by decide
theorem cert_e1211205116406 : check e1211205116406 [[],[]] .chain = true := by decide
def e1211205117358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211205117358 : Closed e1211205117358 ∧ code e1211205117358 = 5609251628462 := by decide
theorem cert_e1211205117358 : check e1211205117358 [[],[]] .chain = true := by decide
def e1211205117370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211205117370 : Closed e1211205117370 ∧ code e1211205117370 = 5609251628474 := by decide
theorem cert_e1211205117370 : check e1211205117370 [[],[]] .chain = true := by decide
def e1211205117418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211205117418 : Closed e1211205117418 ∧ code e1211205117418 = 5609251628522 := by decide
theorem cert_e1211205117418 : check e1211205117418 [[],[]] .chain = true := by decide
def e1211205117550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205117550 : Closed e1211205117550 ∧ code e1211205117550 = 5609251628654 := by decide
theorem cert_e1211205117550 : check e1211205117550 [[],[]] .chain = true := by decide
def e1211205117562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205117562 : Closed e1211205117562 ∧ code e1211205117562 = 5609251628666 := by decide
theorem cert_e1211205117562 : check e1211205117562 [[],[]] .chain = true := by decide
def e1211205117726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211205117726 : Closed e1211205117726 ∧ code e1211205117726 = 5609251628830 := by decide
theorem cert_e1211205117726 : check e1211205117726 [[],[]] .chain = true := by decide
def e1211205117826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205117826 : Closed e1211205117826 ∧ code e1211205117826 = 5609251628930 := by decide
theorem cert_e1211205117826 : check e1211205117826 [[],[]] .chain = true := by decide
def e1211205117838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211205117838 : Closed e1211205117838 ∧ code e1211205117838 = 5609251628942 := by decide
theorem cert_e1211205117838 : check e1211205117838 [[],[]] .chain = true := by decide
def e1211205117850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205117850 : Closed e1211205117850 ∧ code e1211205117850 = 5609251628954 := by decide
theorem cert_e1211205117850 : check e1211205117850 [[],[]] .chain = true := by decide
def e1211205120030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211205120030 : Closed e1211205120030 ∧ code e1211205120030 = 5609251631134 := by decide
theorem cert_e1211205120030 : check e1211205120030 [[],[]] .chain = true := by decide
def e1211205120198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211205120198 : Closed e1211205120198 ∧ code e1211205120198 = 5609251631302 := by decide
theorem cert_e1211205120198 : checkPay e1211205120198 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e1211205120222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211205120222 : Closed e1211205120222 ∧ code e1211205120222 = 5609251631326 := by decide
theorem cert_e1211205120222 : checkPay e1211205120222 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e1211205120226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211205120226 : Closed e1211205120226 ∧ code e1211205120226 = 5609251631330 := by decide
theorem cert_e1211205120226 : check e1211205120226 [[],[]] .chain = true := by decide
def e1211205120238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211205120238 : Closed e1211205120238 ∧ code e1211205120238 = 5609251631342 := by decide
theorem cert_e1211205120238 : check e1211205120238 [[],[]] .chain = true := by decide
def e1211205120246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211205120246 : Closed e1211205120246 ∧ code e1211205120246 = 5609251631350 := by decide
theorem cert_e1211205120246 : check e1211205120246 [[],[]] .chain = true := by decide
def e1211205120250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211205120250 : Closed e1211205120250 ∧ code e1211205120250 = 5609251631354 := by decide
theorem cert_e1211205120250 : checkPay e1211205120250 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under,.right,.under]] = true := by decide
def e1211205120726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211205120726 : Closed e1211205120726 ∧ code e1211205120726 = 5609251631830 := by decide
theorem cert_e1211205120726 : check e1211205120726 [[],[]] .chain = true := by decide
def e1211205120730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211205120730 : Closed e1211205120730 ∧ code e1211205120730 = 5609251631834 := by decide
theorem cert_e1211205120730 : check e1211205120730 [[],[]] .chain = true := by decide
def e1211205120746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211205120746 : Closed e1211205120746 ∧ code e1211205120746 = 5609251631850 := by decide
theorem cert_e1211205120746 : check e1211205120746 [[],[]] .chain = true := by decide
def e1211205120774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205120774 : Closed e1211205120774 ∧ code e1211205120774 = 5609251631878 := by decide
theorem cert_e1211205120774 : check e1211205120774 [[],[]] .chain = true := by decide
def e1211205120798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211205120798 : Closed e1211205120798 ∧ code e1211205120798 = 5609251631902 := by decide
theorem cert_e1211205120798 : checkPay e1211205120798 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e1211205120822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205120822 : Closed e1211205120822 ∧ code e1211205120822 = 5609251631926 := by decide
theorem cert_e1211205120822 : check e1211205120822 [[],[]] .chain = true := by decide
def e1211205120826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205120826 : Closed e1211205120826 ∧ code e1211205120826 = 5609251631930 := by decide
theorem cert_e1211205120826 : check e1211205120826 [[],[]] .chain = true := by decide
def e1211205120898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205120898 : Closed e1211205120898 ∧ code e1211205120898 = 5609251632002 := by decide
theorem cert_e1211205120898 : check e1211205120898 [[],[]] .chain = true := by decide
def e1211205120910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211205120910 : Closed e1211205120910 ∧ code e1211205120910 = 5609251632014 := by decide
theorem cert_e1211205120910 : check e1211205120910 [[],[]] .chain = true := by decide
def e1211205120922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205120922 : Closed e1211205120922 ∧ code e1211205120922 = 5609251632026 := by decide
theorem cert_e1211205120922 : check e1211205120922 [[],[]] .chain = true := by decide
def e1211205120966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211205120966 : Closed e1211205120966 ∧ code e1211205120966 = 5609251632070 := by decide
theorem cert_e1211205120966 : checkPay e1211205120966 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under,.right]] = true := by decide
def e1211205124718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205124718 : Closed e1211205124718 ∧ code e1211205124718 = 5609251635822 := by decide
theorem cert_e1211205124718 : check e1211205124718 [[],[]] .chain = true := by decide
def e1211205124730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205124730 : Closed e1211205124730 ∧ code e1211205124730 = 5609251635834 := by decide
theorem cert_e1211205124730 : check e1211205124730 [[],[]] .chain = true := by decide
def e1211205125998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e1211205125998 : Closed e1211205125998 ∧ code e1211205125998 = 5609251637102 := by decide
theorem cert_e1211205125998 : check e1211205125998 [[],[]] .chain = true := by decide
def e1211205126010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e1211205126010 : Closed e1211205126010 ∧ code e1211205126010 = 5609251637114 := by decide
theorem cert_e1211205126010 : check e1211205126010 [[],[]] .chain = true := by decide
def e1211205126106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e1211205126106 : Closed e1211205126106 ∧ code e1211205126106 = 5609251637210 := by decide
theorem cert_e1211205126106 : check e1211205126106 [[],[]] .chain = true := by decide
def e1211205127406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211205127406 : Closed e1211205127406 ∧ code e1211205127406 = 5609251638510 := by decide
theorem cert_e1211205127406 : check e1211205127406 [[],[]] .chain = true := by decide
def e1211205127414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211205127414 : Closed e1211205127414 ∧ code e1211205127414 = 5609251638518 := by decide
theorem cert_e1211205127414 : check e1211205127414 [[],[]] .chain = true := by decide
def e1211205127790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205127790 : Closed e1211205127790 ∧ code e1211205127790 = 5609251638894 := by decide
theorem cert_e1211205127790 : check e1211205127790 [[],[]] .chain = true := by decide
def e1211205127802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205127802 : Closed e1211205127802 ∧ code e1211205127802 = 5609251638906 := by decide
theorem cert_e1211205127802 : check e1211205127802 [[],[]] .chain = true := by decide
def e1211205127990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205127990 : Closed e1211205127990 ∧ code e1211205127990 = 5609251639094 := by decide
theorem cert_e1211205127990 : check e1211205127990 [[],[]] .chain = true := by decide
def e1211205127994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205127994 : Closed e1211205127994 ∧ code e1211205127994 = 5609251639098 := by decide
theorem cert_e1211205127994 : check e1211205127994 [[],[]] .chain = true := by decide
def e1211205129902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e1211205129902 : Closed e1211205129902 ∧ code e1211205129902 = 5609251641006 := by decide
theorem cert_e1211205129902 : check e1211205129902 [[],[]] .chain = true := by decide
def e1211205129914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e1211205129914 : Closed e1211205129914 ∧ code e1211205129914 = 5609251641018 := by decide
theorem cert_e1211205129914 : check e1211205129914 [[],[]] .chain = true := by decide
def e1211205129962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e1211205129962 : Closed e1211205129962 ∧ code e1211205129962 = 5609251641066 := by decide
theorem cert_e1211205129962 : check e1211205129962 [[],[]] .chain = true := by decide
def e1211205130154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e1211205130154 : Closed e1211205130154 ∧ code e1211205130154 = 5609251641258 := by decide
theorem cert_e1211205130154 : check e1211205130154 [[],[]] .chain = true := by decide
def e1211205130286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e1211205130286 : Closed e1211205130286 ∧ code e1211205130286 = 5609251641390 := by decide
theorem cert_e1211205130286 : check e1211205130286 [[],[]] .chain = true := by decide
def e1211205130478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e1211205130478 : Closed e1211205130478 ∧ code e1211205130478 = 5609251641582 := by decide
theorem cert_e1211205130478 : check e1211205130478 [[],[]] .chain = true := by decide
def e1211205130486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211205130486 : Closed e1211205130486 ∧ code e1211205130486 = 5609251641590 := by decide
theorem cert_e1211205130486 : check e1211205130486 [[],[]] .chain = true := by decide
def e1211205130670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e1211205130670 : Closed e1211205130670 ∧ code e1211205130670 = 5609251641774 := by decide
theorem cert_e1211205130670 : check e1211205130670 [[],[]] .chain = true := by decide
def e1211205130682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211205130682 : Closed e1211205130682 ∧ code e1211205130682 = 5609251641786 := by decide
theorem cert_e1211205130682 : check e1211205130682 [[],[]] .chain = true := by decide
def e1211205130730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211205130730 : Closed e1211205130730 ∧ code e1211205130730 = 5609251641834 := by decide
theorem cert_e1211205130730 : check e1211205130730 [[],[]] .chain = true := by decide
def e1211205130862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205130862 : Closed e1211205130862 ∧ code e1211205130862 = 5609251641966 := by decide
theorem cert_e1211205130862 : check e1211205130862 [[],[]] .chain = true := by decide
def e1211205130874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205130874 : Closed e1211205130874 ∧ code e1211205130874 = 5609251641978 := by decide
theorem cert_e1211205130874 : check e1211205130874 [[],[]] .chain = true := by decide
def e1211205131038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e1211205131038 : Closed e1211205131038 ∧ code e1211205131038 = 5609251642142 := by decide
theorem cert_e1211205131038 : check e1211205131038 [[],[]] .chain = true := by decide
def e1211205131138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205131138 : Closed e1211205131138 ∧ code e1211205131138 = 5609251642242 := by decide
theorem cert_e1211205131138 : check e1211205131138 [[],[]] .chain = true := by decide
def e1211205131150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211205131150 : Closed e1211205131150 ∧ code e1211205131150 = 5609251642254 := by decide
theorem cert_e1211205131150 : check e1211205131150 [[],[]] .chain = true := by decide
def e1211205131162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205131162 : Closed e1211205131162 ∧ code e1211205131162 = 5609251642266 := by decide
theorem cert_e1211205131162 : check e1211205131162 [[],[]] .chain = true := by decide
def e1211205131374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211205131374 : Closed e1211205131374 ∧ code e1211205131374 = 5609251642478 := by decide
theorem cert_e1211205131374 : check e1211205131374 [[],[]] .chain = true := by decide
def e1211205131386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211205131386 : Closed e1211205131386 ∧ code e1211205131386 = 5609251642490 := by decide
theorem cert_e1211205131386 : check e1211205131386 [[],[]] .chain = true := by decide
def e1211205131550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e1211205131550 : Closed e1211205131550 ∧ code e1211205131550 = 5609251642654 := by decide
theorem cert_e1211205131550 : check e1211205131550 [[],[]] .chain = true := by decide
def e1211205131718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211205131718 : Closed e1211205131718 ∧ code e1211205131718 = 5609251642822 := by decide
theorem cert_e1211205131718 : check e1211205131718 [[],[]] .chain = true := by decide
def e1211205131786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205131786 : Closed e1211205131786 ∧ code e1211205131786 = 5609251642890 := by decide
theorem cert_e1211205131786 : check e1211205131786 [[],[]] .chain = true := by decide
def e1211205131830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211205131830 : Closed e1211205131830 ∧ code e1211205131830 = 5609251642934 := by decide
theorem cert_e1211205131830 : check e1211205131830 [[],[]] .chain = true := by decide
def e1211205131834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211205131834 : Closed e1211205131834 ∧ code e1211205131834 = 5609251642938 := by decide
theorem cert_e1211205131834 : check e1211205131834 [[],[]] .chain = true := by decide
def e1211205131882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e1211205131882 : Closed e1211205131882 ∧ code e1211205131882 = 5609251642986 := by decide
theorem cert_e1211205131882 : check e1211205131882 [[],[]] .chain = true := by decide
def e1211205131906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e1211205131906 : Closed e1211205131906 ∧ code e1211205131906 = 5609251643010 := by decide
theorem cert_e1211205131906 : check e1211205131906 [[],[]] .chain = true := by decide
def e1211205131918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211205131918 : Closed e1211205131918 ∧ code e1211205131918 = 5609251643022 := by decide
theorem cert_e1211205131918 : check e1211205131918 [[],[]] .chain = true := by decide
def e1211205131930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205131930 : Closed e1211205131930 ∧ code e1211205131930 = 5609251643034 := by decide
theorem cert_e1211205131930 : check e1211205131930 [[],[]] .chain = true := by decide
def e1211205131974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211205131974 : Closed e1211205131974 ∧ code e1211205131974 = 5609251643078 := by decide
theorem cert_e1211205131974 : check e1211205131974 [[],[]] .chain = true := by decide
def e1211205132766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1211205132766 : Closed e1211205132766 ∧ code e1211205132766 = 5609251643870 := by decide
theorem cert_e1211205132766 : check e1211205132766 [[],[]] .chain = true := by decide
def e1211205132790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1211205132790 : Closed e1211205132790 ∧ code e1211205132790 = 5609251643894 := by decide
theorem cert_e1211205132790 : check e1211205132790 [[],[]] .chain = true := by decide
def e1211205133742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1211205133742 : Closed e1211205133742 ∧ code e1211205133742 = 5609251644846 := by decide
theorem cert_e1211205133742 : check e1211205133742 [[],[]] .chain = true := by decide
def e1211205133754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1211205133754 : Closed e1211205133754 ∧ code e1211205133754 = 5609251644858 := by decide
theorem cert_e1211205133754 : check e1211205133754 [[],[]] .chain = true := by decide
def e1211205133802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1211205133802 : Closed e1211205133802 ∧ code e1211205133802 = 5609251644906 := by decide
theorem cert_e1211205133802 : check e1211205133802 [[],[]] .chain = true := by decide
def e1211205133934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1211205133934 : Closed e1211205133934 ∧ code e1211205133934 = 5609251645038 := by decide
theorem cert_e1211205133934 : check e1211205133934 [[],[]] .chain = true := by decide
def e1211205133946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1211205133946 : Closed e1211205133946 ∧ code e1211205133946 = 5609251645050 := by decide
theorem cert_e1211205133946 : check e1211205133946 [[],[]] .chain = true := by decide
def e1211205134110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211205134110 : Closed e1211205134110 ∧ code e1211205134110 = 5609251645214 := by decide
theorem cert_e1211205134110 : check e1211205134110 [[],[]] .chain = true := by decide
def e1211205134210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205134210 : Closed e1211205134210 ∧ code e1211205134210 = 5609251645314 := by decide
theorem cert_e1211205134210 : check e1211205134210 [[],[]] .chain = true := by decide
def e1211205134222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211205134222 : Closed e1211205134222 ∧ code e1211205134222 = 5609251645326 := by decide
theorem cert_e1211205134222 : check e1211205134222 [[],[]] .chain = true := by decide
def e1211205134234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205134234 : Closed e1211205134234 ∧ code e1211205134234 = 5609251645338 := by decide
theorem cert_e1211205134234 : check e1211205134234 [[],[]] .chain = true := by decide
def e1211205137182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211205137182 : Closed e1211205137182 ∧ code e1211205137182 = 5609251648286 := by decide
theorem cert_e1211205137182 : check e1211205137182 [[],[]] .chain = true := by decide
def e1211205137350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211205137350 : Closed e1211205137350 ∧ code e1211205137350 = 5609251648454 := by decide
theorem cert_e1211205137350 : check e1211205137350 [[],[]] .chain = true := by decide
def e1211205138550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e1211205138550 : Closed e1211205138550 ∧ code e1211205138550 = 5609251649654 := by decide
theorem cert_e1211205138550 : check e1211205138550 [[],[]] .chain = true := by decide
def e1211205138794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e1211205138794 : Closed e1211205138794 ∧ code e1211205138794 = 5609251649898 := by decide
theorem cert_e1211205138794 : check e1211205138794 [[],[]] .chain = true := by decide
def e1211205138818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205138818 : Closed e1211205138818 ∧ code e1211205138818 = 5609251649922 := by decide
theorem cert_e1211205138818 : check e1211205138818 [[],[]] .chain = true := by decide
def e1211205138830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205138830 : Closed e1211205138830 ∧ code e1211205138830 = 5609251649934 := by decide
theorem cert_e1211205138830 : check e1211205138830 [[],[]] .chain = true := by decide
def e1211205138842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205138842 : Closed e1211205138842 ∧ code e1211205138842 = 5609251649946 := by decide
theorem cert_e1211205138842 : check e1211205138842 [[],[]] .chain = true := by decide
def e1211205138886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205138886 : Closed e1211205138886 ∧ code e1211205138886 = 5609251649990 := by decide
theorem cert_e1211205138886 : check e1211205138886 [[],[]] .chain = true := by decide
def e1211205140602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.lam (.var 3)))))) (.var 0))))))
theorem wire_e1211205140602 : Closed e1211205140602 ∧ code e1211205140602 = 5609251651706 := by decide
theorem cert_e1211205140602 : check e1211205140602 [[],[]] .chain = true := by decide
def e1211205140790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205140790 : Closed e1211205140790 ∧ code e1211205140790 = 5609251651894 := by decide
theorem cert_e1211205140790 : check e1211205140790 [[],[]] .chain = true := by decide
def e1211205140794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205140794 : Closed e1211205140794 ∧ code e1211205140794 = 5609251651898 := by decide
theorem cert_e1211205140794 : check e1211205140794 [[],[]] .chain = true := by decide
def e1211205140890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205140890 : Closed e1211205140890 ∧ code e1211205140890 = 5609251651994 := by decide
theorem cert_e1211205140890 : check e1211205140890 [[],[]] .chain = true := by decide
def e1211205140934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.lam (.var 1)))))))
theorem wire_e1211205140934 : Closed e1211205140934 ∧ code e1211205140934 = 5609251652038 := by decide
theorem cert_e1211205140934 : check e1211205140934 [[],[]] .chain = true := by decide
def e1211205141274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211205141274 : Closed e1211205141274 ∧ code e1211205141274 = 5609251652378 := by decide
theorem cert_e1211205141274 : checkPay e1211205141274 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.left,.right],[.under,.under,.left,.right]] = true := by decide
def e1211205141318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211205141318 : Closed e1211205141318 ∧ code e1211205141318 = 5609251652422 := by decide
theorem cert_e1211205141318 : checkPay e1211205141318 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211205141358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e1211205141358 : Closed e1211205141358 ∧ code e1211205141358 = 5609251652462 := by decide
theorem cert_e1211205141358 : checkPay e1211205141358 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.left,.right],[.under,.under,.left,.right]] = true := by decide
def e1211205141370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e1211205141370 : Closed e1211205141370 ∧ code e1211205141370 = 5609251652474 := by decide
theorem cert_e1211205141370 : checkPay e1211205141370 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211205141386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e1211205141386 : Closed e1211205141386 ∧ code e1211205141386 = 5609251652490 := by decide
theorem cert_e1211205141386 : check e1211205141386 [[],[]] .chain = true := by decide
def e1211205141422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e1211205141422 : Closed e1211205141422 ∧ code e1211205141422 = 5609251652526 := by decide
theorem cert_e1211205141422 : checkPay e1211205141422 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.right,.under]] = true := by decide
def e1211205141430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e1211205141430 : Closed e1211205141430 ∧ code e1211205141430 = 5609251652534 := by decide
theorem cert_e1211205141430 : check e1211205141430 [[],[]] .chain = true := by decide
def e1211205141434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e1211205141434 : Closed e1211205141434 ∧ code e1211205141434 = 5609251652538 := by decide
theorem cert_e1211205141434 : check e1211205141434 [[],[]] .chain = true := by decide
def e1211205141466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e1211205141466 : Closed e1211205141466 ∧ code e1211205141466 = 5609251652570 := by decide
theorem cert_e1211205141466 : check e1211205141466 [[],[]] .chain = true := by decide
def e1211205141482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e1211205141482 : Closed e1211205141482 ∧ code e1211205141482 = 5609251652586 := by decide
theorem cert_e1211205141482 : checkPay e1211205141482 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e1211205141702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211205141702 : Closed e1211205141702 ∧ code e1211205141702 = 5609251652806 := by decide
theorem cert_e1211205141702 : check e1211205141702 [[],[]] .chain = true := by decide
def e1211205142030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.lam (.var 2))))))))
theorem wire_e1211205142030 : Closed e1211205142030 ∧ code e1211205142030 = 5609251653134 := by decide
theorem cert_e1211205142030 : check e1211205142030 [[],[]] .chain = true := by decide
def e1211205142042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211205142042 : Closed e1211205142042 ∧ code e1211205142042 = 5609251653146 := by decide
theorem cert_e1211205142042 : checkPay e1211205142042 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211205142114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211205142114 : Closed e1211205142114 ∧ code e1211205142114 = 5609251653218 := by decide
theorem cert_e1211205142114 : check e1211205142114 [[],[]] .chain = true := by decide
def e1211205142126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211205142126 : Closed e1211205142126 ∧ code e1211205142126 = 5609251653230 := by decide
theorem cert_e1211205142126 : checkPay e1211205142126 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211205142134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211205142134 : Closed e1211205142134 ∧ code e1211205142134 = 5609251653238 := by decide
theorem cert_e1211205142134 : check e1211205142134 [[],[]] .chain = true := by decide
def e1211205142138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211205142138 : Closed e1211205142138 ∧ code e1211205142138 = 5609251653242 := by decide
theorem cert_e1211205142138 : checkPay e1211205142138 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right]] = true := by decide
def e1211205142326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205142326 : Closed e1211205142326 ∧ code e1211205142326 = 5609251653430 := by decide
theorem cert_e1211205142326 : check e1211205142326 [[],[]] .chain = true := by decide
def e1211205142330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205142330 : Closed e1211205142330 ∧ code e1211205142330 = 5609251653434 := by decide
theorem cert_e1211205142330 : check e1211205142330 [[],[]] .chain = true := by decide
def e1211205142426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205142426 : Closed e1211205142426 ∧ code e1211205142426 = 5609251653530 := by decide
theorem cert_e1211205142426 : checkPay e1211205142426 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e1211205143382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e1211205143382 : Closed e1211205143382 ∧ code e1211205143382 = 5609251654486 := by decide
theorem cert_e1211205143382 : check e1211205143382 [[],[]] .chain = true := by decide
def e1211205143386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e1211205143386 : Closed e1211205143386 ∧ code e1211205143386 = 5609251654490 := by decide
theorem cert_e1211205143386 : check e1211205143386 [[],[]] .chain = true := by decide
def e1211205143402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e1211205143402 : Closed e1211205143402 ∧ code e1211205143402 = 5609251654506 := by decide
theorem cert_e1211205143402 : check e1211205143402 [[],[]] .chain = true := by decide
def e1211205143466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e1211205143466 : Closed e1211205143466 ∧ code e1211205143466 = 5609251654570 := by decide
theorem cert_e1211205143466 : check e1211205143466 [[],[]] .chain = true := by decide
def e1211205143574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e1211205143574 : Closed e1211205143574 ∧ code e1211205143574 = 5609251654678 := by decide
theorem cert_e1211205143574 : check e1211205143574 [[],[]] .chain = true := by decide
def e1211205143578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 0))))))
theorem wire_e1211205143578 : Closed e1211205143578 ∧ code e1211205143578 = 5609251654682 := by decide
theorem cert_e1211205143578 : check e1211205143578 [[],[]] .chain = true := by decide
def e1211205143622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.lam (.var 1)))))))
theorem wire_e1211205143622 : Closed e1211205143622 ∧ code e1211205143622 = 5609251654726 := by decide
theorem cert_e1211205143622 : check e1211205143622 [[],[]] .chain = true := by decide
def e1211205143650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.lam (.var 0)))))))
theorem wire_e1211205143650 : Closed e1211205143650 ∧ code e1211205143650 = 5609251654754 := by decide
theorem cert_e1211205143650 : check e1211205143650 [[],[]] .chain = true := by decide
def e1211205143662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e1211205143662 : Closed e1211205143662 ∧ code e1211205143662 = 5609251654766 := by decide
theorem cert_e1211205143662 : checkPay e1211205143662 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right,.left,.left],[.under,.under,.right,.left],[.under,.under,.right]] = true := by decide
end Blc.Floor42
