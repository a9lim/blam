import Batch260
import ExtraBase
namespace Blc.Floor42.Extra260
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1211584953466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem ex_e1211584953466 : ¬ IsSelfInterpreter e1211584953466 := by
  intro he
  have hp := replay_sound (t := e1211584953466) (u := t_e1211584953466) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.var 0))) (so_closed_lam (by decide) (SO.app (SO.var 0) (SO.lam (g := (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (r := (.app (.var 0) (.lam (.var 1)))) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (SO.app (SO.app (SO.var 1) (SO.app (SO.var 2) (so_dead (by decide) (SO.var 3)))) (SO.var 0)) (SO.app (SO.var 0) (SO.app (SO.var 1) (so_dead (by decide) (SO.var 2)))) (by decide) (by rfl)) (SO.app (SO.var 0) (so_dead (by decide) (SO.var 1))) (by decide) (by rfl)))))
#print axioms ex_e1211584953466
end Blc.Floor42.Extra260
