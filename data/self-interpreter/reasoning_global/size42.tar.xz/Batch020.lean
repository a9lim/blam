import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e350577092458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e350577092458 : Closed e350577092458 ∧ code e350577092458 = 4748623603562 := by decide
theorem cert_e350577092458 : check e350577092458 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577093082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e350577093082 : Closed e350577093082 ∧ code e350577093082 = 4748623604186 := by decide
theorem cert_e350577093082 : check e350577093082 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577093850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350577093850 : Closed e350577093850 ∧ code e350577093850 = 4748623604954 := by decide
theorem cert_e350577093850 : check e350577093850 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577093866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350577093866 : Closed e350577093866 ∧ code e350577093866 = 4748623604970 := by decide
theorem cert_e350577093866 : check e350577093866 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577095514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e350577095514 : Closed e350577095514 ∧ code e350577095514 = 4748623606618 := by decide
theorem cert_e350577095514 : check e350577095514 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577095530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e350577095530 : Closed e350577095530 ∧ code e350577095530 = 4748623606634 := by decide
theorem cert_e350577095530 : check e350577095530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577095594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e350577095594 : Closed e350577095594 ∧ code e350577095594 = 4748623606698 := by decide
theorem cert_e350577095594 : check e350577095594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577095898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350577095898 : Closed e350577095898 ∧ code e350577095898 = 4748623607002 := by decide
theorem cert_e350577095898 : check e350577095898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577095914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350577095914 : Closed e350577095914 ∧ code e350577095914 = 4748623607018 := by decide
theorem cert_e350577095914 : check e350577095914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577096298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e350577096298 : Closed e350577096298 ∧ code e350577096298 = 4748623607402 := by decide
theorem cert_e350577096298 : check e350577096298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577122170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.var 0)))
theorem wire_e350577122170 : Closed e350577122170 ∧ code e350577122170 = 4748623633274 := by decide
theorem cert_e350577122170 : check e350577122170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577122266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.var 0)))
theorem wire_e350577122266 : Closed e350577122266 ∧ code e350577122266 = 4748623633370 := by decide
theorem cert_e350577122266 : check e350577122266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577122682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e350577122682 : Closed e350577122682 ∧ code e350577122682 = 4748623633786 := by decide
theorem cert_e350577122682 : check e350577122682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577122746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e350577122746 : Closed e350577122746 ∧ code e350577122746 = 4748623633850 := by decide
theorem cert_e350577122746 : check e350577122746 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577122778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e350577122778 : Closed e350577122778 ∧ code e350577122778 = 4748623633882 := by decide
theorem cert_e350577122778 : check e350577122778 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577122794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e350577122794 : Closed e350577122794 ∧ code e350577122794 = 4748623633898 := by decide
theorem cert_e350577122794 : check e350577122794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577123034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))) (.var 0)))
theorem wire_e350577123034 : Closed e350577123034 ∧ code e350577123034 = 4748623634138 := by decide
theorem cert_e350577123034 : check e350577123034 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577123162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350577123162 : Closed e350577123162 ∧ code e350577123162 = 4748623634266 := by decide
theorem cert_e350577123162 : check e350577123162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577123178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350577123178 : Closed e350577123178 ∧ code e350577123178 = 4748623634282 := by decide
theorem cert_e350577123178 : check e350577123178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577125242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e350577125242 : Closed e350577125242 ∧ code e350577125242 = 4748623636346 := by decide
theorem cert_e350577125242 : check e350577125242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577125338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e350577125338 : Closed e350577125338 ∧ code e350577125338 = 4748623636442 := by decide
theorem cert_e350577125338 : check e350577125338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577128314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e350577128314 : Closed e350577128314 ∧ code e350577128314 = 4748623639418 := by decide
theorem cert_e350577128314 : check e350577128314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577128378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e350577128378 : Closed e350577128378 ∧ code e350577128378 = 4748623639482 := by decide
theorem cert_e350577128378 : check e350577128378 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577128410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e350577128410 : Closed e350577128410 ∧ code e350577128410 = 4748623639514 := by decide
theorem cert_e350577128410 : check e350577128410 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577128426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e350577128426 : Closed e350577128426 ∧ code e350577128426 = 4748623639530 := by decide
theorem cert_e350577128426 : check e350577128426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577129946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))) (.var 0)))
theorem wire_e350577129946 : Closed e350577129946 ∧ code e350577129946 = 4748623641050 := by decide
theorem cert_e350577129946 : check e350577129946 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577130714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350577130714 : Closed e350577130714 ∧ code e350577130714 = 4748623641818 := by decide
theorem cert_e350577130714 : check e350577130714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577130730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350577130730 : Closed e350577130730 ∧ code e350577130730 = 4748623641834 := by decide
theorem cert_e350577130730 : check e350577130730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577175930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e350577175930 : Closed e350577175930 ∧ code e350577175930 = 4748623687034 := by decide
theorem cert_e350577175930 : check e350577175930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577175994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e350577175994 : Closed e350577175994 ∧ code e350577175994 = 4748623687098 := by decide
theorem cert_e350577175994 : check e350577175994 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577176026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e350577176026 : Closed e350577176026 ∧ code e350577176026 = 4748623687130 := by decide
theorem cert_e350577176026 : check e350577176026 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577176042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e350577176042 : Closed e350577176042 ∧ code e350577176042 = 4748623687146 := by decide
theorem cert_e350577176042 : check e350577176042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577176250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e350577176250 : Closed e350577176250 ∧ code e350577176250 = 4748623687354 := by decide
theorem cert_e350577176250 : check e350577176250 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577176298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e350577176298 : Closed e350577176298 ∧ code e350577176298 = 4748623687402 := by decide
theorem cert_e350577176298 : check e350577176298 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577176410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350577176410 : Closed e350577176410 ∧ code e350577176410 = 4748623687514 := by decide
theorem cert_e350577176410 : check e350577176410 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577176426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350577176426 : Closed e350577176426 ∧ code e350577176426 = 4748623687530 := by decide
theorem cert_e350577176426 : check e350577176426 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577176490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e350577176490 : Closed e350577176490 ∧ code e350577176490 = 4748623687594 := by decide
theorem cert_e350577176490 : check e350577176490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577177466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e350577177466 : Closed e350577177466 ∧ code e350577177466 = 4748623688570 := by decide
theorem cert_e350577177466 : check e350577177466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577177530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e350577177530 : Closed e350577177530 ∧ code e350577177530 = 4748623688634 := by decide
theorem cert_e350577177530 : check e350577177530 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577177562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e350577177562 : Closed e350577177562 ∧ code e350577177562 = 4748623688666 := by decide
theorem cert_e350577177562 : check e350577177562 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577177578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e350577177578 : Closed e350577177578 ∧ code e350577177578 = 4748623688682 := by decide
theorem cert_e350577177578 : check e350577177578 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577179066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e350577179066 : Closed e350577179066 ∧ code e350577179066 = 4748623690170 := by decide
theorem cert_e350577179066 : check e350577179066 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577179114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e350577179114 : Closed e350577179114 ∧ code e350577179114 = 4748623690218 := by decide
theorem cert_e350577179114 : check e350577179114 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577179866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350577179866 : Closed e350577179866 ∧ code e350577179866 = 4748623690970 := by decide
theorem cert_e350577179866 : check e350577179866 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577179882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350577179882 : Closed e350577179882 ∧ code e350577179882 = 4748623690986 := by decide
theorem cert_e350577179882 : check e350577179882 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577180266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e350577180266 : Closed e350577180266 ∧ code e350577180266 = 4748623691370 := by decide
theorem cert_e350577180266 : check e350577180266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577202906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.var 0)))
theorem wire_e350577202906 : Closed e350577202906 ∧ code e350577202906 = 4748623714010 := by decide
theorem cert_e350577202906 : check e350577202906 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577203034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350577203034 : Closed e350577203034 ∧ code e350577203034 = 4748623714138 := by decide
theorem cert_e350577203034 : check e350577203034 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577203050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350577203050 : Closed e350577203050 ∧ code e350577203050 = 4748623714154 := by decide
theorem cert_e350577203050 : check e350577203050 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577203674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.var 0)))
theorem wire_e350577203674 : Closed e350577203674 ∧ code e350577203674 = 4748623714778 := by decide
theorem cert_e350577203674 : check e350577203674 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577204442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350577204442 : Closed e350577204442 ∧ code e350577204442 = 4748623715546 := by decide
theorem cert_e350577204442 : check e350577204442 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577204458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350577204458 : Closed e350577204458 ∧ code e350577204458 = 4748623715562 := by decide
theorem cert_e350577204458 : check e350577204458 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577216346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e350577216346 : Closed e350577216346 ∧ code e350577216346 = 4748623727450 := by decide
theorem cert_e350577216346 : check e350577216346 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577216362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e350577216362 : Closed e350577216362 ∧ code e350577216362 = 4748623727466 := by decide
theorem cert_e350577216362 : check e350577216362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577216426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e350577216426 : Closed e350577216426 ∧ code e350577216426 = 4748623727530 := by decide
theorem cert_e350577216426 : check e350577216426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577216730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e350577216730 : Closed e350577216730 ∧ code e350577216730 = 4748623727834 := by decide
theorem cert_e350577216730 : check e350577216730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577216746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e350577216746 : Closed e350577216746 ∧ code e350577216746 = 4748623727850 := by decide
theorem cert_e350577216746 : check e350577216746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577217130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e350577217130 : Closed e350577217130 ∧ code e350577217130 = 4748623728234 := by decide
theorem cert_e350577217130 : check e350577217130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578118074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e350578118074 : Closed e350578118074 ∧ code e350578118074 = 4748624629178 := by decide
theorem cert_e350578118074 : check e350578118074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578118106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e350578118106 : Closed e350578118106 ∧ code e350578118106 = 4748624629210 := by decide
theorem cert_e350578118106 : check e350578118106 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578118330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e350578118330 : Closed e350578118330 ∧ code e350578118330 = 4748624629434 := by decide
theorem cert_e350578118330 : check e350578118330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578118378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e350578118378 : Closed e350578118378 ∧ code e350578118378 = 4748624629482 := by decide
theorem cert_e350578118378 : check e350578118378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578118490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e350578118490 : Closed e350578118490 ∧ code e350578118490 = 4748624629594 := by decide
theorem cert_e350578118490 : check e350578118490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578118506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e350578118506 : Closed e350578118506 ∧ code e350578118506 = 4748624629610 := by decide
theorem cert_e350578118506 : check e350578118506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578123706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.var 0)))
theorem wire_e350578123706 : Closed e350578123706 ∧ code e350578123706 = 4748624634810 := by decide
theorem cert_e350578123706 : check e350578123706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578123738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.var 0)))
theorem wire_e350578123738 : Closed e350578123738 ∧ code e350578123738 = 4748624634842 := by decide
theorem cert_e350578123738 : check e350578123738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578125946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.var 0)))
theorem wire_e350578125946 : Closed e350578125946 ∧ code e350578125946 = 4748624637050 := by decide
theorem cert_e350578125946 : check e350578125946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578126278 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.var 1))))
theorem wire_e350578126278 : Closed e350578126278 ∧ code e350578126278 = 4748624637382 := by decide
theorem cert_e350578126278 : check e350578126278 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578126394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e350578126394 : Closed e350578126394 ∧ code e350578126394 = 4748624637498 := by decide
theorem cert_e350578126394 : check e350578126394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578126534 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e350578126534 : Closed e350578126534 ∧ code e350578126534 = 4748624637638 := by decide
theorem cert_e350578126534 : check e350578126534 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578127290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e350578127290 : Closed e350578127290 ∧ code e350578127290 = 4748624638394 := by decide
theorem cert_e350578127290 : check e350578127290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578127338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.var 0)))
theorem wire_e350578127338 : Closed e350578127338 ∧ code e350578127338 = 4748624638442 := by decide
theorem cert_e350578127338 : check e350578127338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578127994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.var 0)))
theorem wire_e350578127994 : Closed e350578127994 ∧ code e350578127994 = 4748624639098 := by decide
theorem cert_e350578127994 : check e350578127994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578128326 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.var 1))))
theorem wire_e350578128326 : Closed e350578128326 ∧ code e350578128326 = 4748624639430 := by decide
theorem cert_e350578128326 : check e350578128326 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578128666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578128666 : Closed e350578128666 ∧ code e350578128666 = 4748624639770 := by decide
theorem cert_e350578128666 : check e350578128666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578128710 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578128710 : Closed e350578128710 ∧ code e350578128710 = 4748624639814 := by decide
theorem cert_e350578128710 : check e350578128710 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578129114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e350578129114 : Closed e350578129114 ∧ code e350578129114 = 4748624640218 := by decide
theorem cert_e350578129114 : check e350578129114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578129130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e350578129130 : Closed e350578129130 ∧ code e350578129130 = 4748624640234 := by decide
theorem cert_e350578129130 : check e350578129130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578129466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e350578129466 : Closed e350578129466 ∧ code e350578129466 = 4748624640570 := by decide
theorem cert_e350578129466 : check e350578129466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578129606 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e350578129606 : Closed e350578129606 ∧ code e350578129606 = 4748624640710 := by decide
theorem cert_e350578129606 : check e350578129606 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578129690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578129690 : Closed e350578129690 ∧ code e350578129690 = 4748624640794 := by decide
theorem cert_e350578129690 : check e350578129690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578129734 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578129734 : Closed e350578129734 ∧ code e350578129734 = 4748624640838 := by decide
theorem cert_e350578129734 : check e350578129734 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578132666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e350578132666 : Closed e350578132666 ∧ code e350578132666 = 4748624643770 := by decide
theorem cert_e350578132666 : check e350578132666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578132714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e350578132714 : Closed e350578132714 ∧ code e350578132714 = 4748624643818 := by decide
theorem cert_e350578132714 : check e350578132714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578132906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e350578132906 : Closed e350578132906 ∧ code e350578132906 = 4748624644010 := by decide
theorem cert_e350578132906 : check e350578132906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578135482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e350578135482 : Closed e350578135482 ∧ code e350578135482 = 4748624646586 := by decide
theorem cert_e350578135482 : check e350578135482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578135530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))) (.var 0)))
theorem wire_e350578135530 : Closed e350578135530 ∧ code e350578135530 = 4748624646634 := by decide
theorem cert_e350578135530 : check e350578135530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578136186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))) (.var 0)))
theorem wire_e350578136186 : Closed e350578136186 ∧ code e350578136186 = 4748624647290 := by decide
theorem cert_e350578136186 : check e350578136186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578136518 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.var 1))))
theorem wire_e350578136518 : Closed e350578136518 ∧ code e350578136518 = 4748624647622 := by decide
theorem cert_e350578136518 : check e350578136518 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578136858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578136858 : Closed e350578136858 ∧ code e350578136858 = 4748624647962 := by decide
theorem cert_e350578136858 : check e350578136858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578136902 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578136902 : Closed e350578136902 ∧ code e350578136902 = 4748624648006 := by decide
theorem cert_e350578136902 : check e350578136902 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578138218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e350578138218 : Closed e350578138218 ∧ code e350578138218 = 4748624649322 := by decide
theorem cert_e350578138218 : check e350578138218 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578138394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578138394 : Closed e350578138394 ∧ code e350578138394 = 4748624649498 := by decide
theorem cert_e350578138394 : check e350578138394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578138438 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578138438 : Closed e350578138438 ∧ code e350578138438 = 4748624649542 := by decide
theorem cert_e350578138438 : check e350578138438 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578139994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e350578139994 : Closed e350578139994 ∧ code e350578139994 = 4748624651098 := by decide
theorem cert_e350578139994 : check e350578139994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578140010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e350578140010 : Closed e350578140010 ∧ code e350578140010 = 4748624651114 := by decide
theorem cert_e350578140010 : check e350578140010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578140074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e350578140074 : Closed e350578140074 ∧ code e350578140074 = 4748624651178 := by decide
theorem cert_e350578140074 : check e350578140074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578141402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e350578141402 : Closed e350578141402 ∧ code e350578141402 = 4748624652506 := by decide
theorem cert_e350578141402 : check e350578141402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578141418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e350578141418 : Closed e350578141418 ∧ code e350578141418 = 4748624652522 := by decide
theorem cert_e350578141418 : check e350578141418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578141754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e350578141754 : Closed e350578141754 ∧ code e350578141754 = 4748624652858 := by decide
theorem cert_e350578141754 : check e350578141754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578141894 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e350578141894 : Closed e350578141894 ∧ code e350578141894 = 4748624652998 := by decide
theorem cert_e350578141894 : check e350578141894 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578141978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578141978 : Closed e350578141978 ∧ code e350578141978 = 4748624653082 := by decide
theorem cert_e350578141978 : check e350578141978 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578142022 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578142022 : Closed e350578142022 ∧ code e350578142022 = 4748624653126 := by decide
theorem cert_e350578142022 : check e350578142022 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578142314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e350578142314 : Closed e350578142314 ∧ code e350578142314 = 4748624653418 := by decide
theorem cert_e350578142314 : check e350578142314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578142490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578142490 : Closed e350578142490 ∧ code e350578142490 = 4748624653594 := by decide
theorem cert_e350578142490 : check e350578142490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578142534 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578142534 : Closed e350578142534 ∧ code e350578142534 = 4748624653638 := by decide
theorem cert_e350578142534 : check e350578142534 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578160570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e350578160570 : Closed e350578160570 ∧ code e350578160570 = 4748624671674 := by decide
theorem cert_e350578160570 : check e350578160570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578160602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e350578160602 : Closed e350578160602 ∧ code e350578160602 = 4748624671706 := by decide
theorem cert_e350578160602 : check e350578160602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578162106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e350578162106 : Closed e350578162106 ∧ code e350578162106 = 4748624673210 := by decide
theorem cert_e350578162106 : check e350578162106 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578162154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e350578162154 : Closed e350578162154 ∧ code e350578162154 = 4748624673258 := by decide
theorem cert_e350578162154 : check e350578162154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578162906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e350578162906 : Closed e350578162906 ∧ code e350578162906 = 4748624674010 := by decide
theorem cert_e350578162906 : check e350578162906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578162922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e350578162922 : Closed e350578162922 ∧ code e350578162922 = 4748624674026 := by decide
theorem cert_e350578162922 : check e350578162922 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578172858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.var 0)))
theorem wire_e350578172858 : Closed e350578172858 ∧ code e350578172858 = 4748624683962 := by decide
theorem cert_e350578172858 : check e350578172858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578172890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.var 0)))
theorem wire_e350578172890 : Closed e350578172890 ∧ code e350578172890 = 4748624683994 := by decide
theorem cert_e350578172890 : check e350578172890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578175098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.var 0)))
theorem wire_e350578175098 : Closed e350578175098 ∧ code e350578175098 = 4748624686202 := by decide
theorem cert_e350578175098 : check e350578175098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578175430 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.var 1))))
theorem wire_e350578175430 : Closed e350578175430 ∧ code e350578175430 = 4748624686534 := by decide
theorem cert_e350578175430 : check e350578175430 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578175546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e350578175546 : Closed e350578175546 ∧ code e350578175546 = 4748624686650 := by decide
theorem cert_e350578175546 : check e350578175546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578175686 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e350578175686 : Closed e350578175686 ∧ code e350578175686 = 4748624686790 := by decide
theorem cert_e350578175686 : check e350578175686 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578176442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.var 0)))
theorem wire_e350578176442 : Closed e350578176442 ∧ code e350578176442 = 4748624687546 := by decide
theorem cert_e350578176442 : check e350578176442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578176490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.var 0)))
theorem wire_e350578176490 : Closed e350578176490 ∧ code e350578176490 = 4748624687594 := by decide
theorem cert_e350578176490 : check e350578176490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578177146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.var 0)))
theorem wire_e350578177146 : Closed e350578177146 ∧ code e350578177146 = 4748624688250 := by decide
theorem cert_e350578177146 : check e350578177146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578177478 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.var 1))))
theorem wire_e350578177478 : Closed e350578177478 ∧ code e350578177478 = 4748624688582 := by decide
theorem cert_e350578177478 : check e350578177478 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578177818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578177818 : Closed e350578177818 ∧ code e350578177818 = 4748624688922 := by decide
theorem cert_e350578177818 : check e350578177818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578177862 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578177862 : Closed e350578177862 ∧ code e350578177862 = 4748624688966 := by decide
theorem cert_e350578177862 : check e350578177862 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578178266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.var 0)))
theorem wire_e350578178266 : Closed e350578178266 ∧ code e350578178266 = 4748624689370 := by decide
theorem cert_e350578178266 : check e350578178266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578178282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e350578178282 : Closed e350578178282 ∧ code e350578178282 = 4748624689386 := by decide
theorem cert_e350578178282 : check e350578178282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578178618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e350578178618 : Closed e350578178618 ∧ code e350578178618 = 4748624689722 := by decide
theorem cert_e350578178618 : check e350578178618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578178758 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e350578178758 : Closed e350578178758 ∧ code e350578178758 = 4748624689862 := by decide
theorem cert_e350578178758 : check e350578178758 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578178842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578178842 : Closed e350578178842 ∧ code e350578178842 = 4748624689946 := by decide
theorem cert_e350578178842 : check e350578178842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578178886 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578178886 : Closed e350578178886 ∧ code e350578178886 = 4748624689990 := by decide
theorem cert_e350578178886 : check e350578178886 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578187386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350578187386 : Closed e350578187386 ∧ code e350578187386 = 4748624698490 := by decide
theorem cert_e350578187386 : check e350578187386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578187718 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350578187718 : Closed e350578187718 ∧ code e350578187718 = 4748624698822 := by decide
theorem cert_e350578187718 : check e350578187718 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578187834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350578187834 : Closed e350578187834 ∧ code e350578187834 = 4748624698938 := by decide
theorem cert_e350578187834 : check e350578187834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578187974 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350578187974 : Closed e350578187974 ∧ code e350578187974 = 4748624699078 := by decide
theorem cert_e350578187974 : check e350578187974 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578199674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350578199674 : Closed e350578199674 ∧ code e350578199674 = 4748624710778 := by decide
theorem cert_e350578199674 : check e350578199674 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578200006 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350578200006 : Closed e350578200006 ∧ code e350578200006 = 4748624711110 := by decide
theorem cert_e350578200006 : check e350578200006 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578200346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578200346 : Closed e350578200346 ∧ code e350578200346 = 4748624711450 := by decide
theorem cert_e350578200346 : check e350578200346 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578200390 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578200390 : Closed e350578200390 ∧ code e350578200390 = 4748624711494 := by decide
theorem cert_e350578200390 : check e350578200390 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578206266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e350578206266 : Closed e350578206266 ∧ code e350578206266 = 4748624717370 := by decide
theorem cert_e350578206266 : check e350578206266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578206406 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.var 1))))
theorem wire_e350578206406 : Closed e350578206406 ∧ code e350578206406 = 4748624717510 := by decide
theorem cert_e350578206406 : check e350578206406 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578206490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578206490 : Closed e350578206490 ∧ code e350578206490 = 4748624717594 := by decide
theorem cert_e350578206490 : check e350578206490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578206534 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578206534 : Closed e350578206534 ∧ code e350578206534 = 4748624717638 := by decide
theorem cert_e350578206534 : check e350578206534 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578219450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e350578219450 : Closed e350578219450 ∧ code e350578219450 = 4748624730554 := by decide
theorem cert_e350578219450 : check e350578219450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578219498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e350578219498 : Closed e350578219498 ∧ code e350578219498 = 4748624730602 := by decide
theorem cert_e350578219498 : check e350578219498 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578220650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e350578220650 : Closed e350578220650 ∧ code e350578220650 = 4748624731754 := by decide
theorem cert_e350578220650 : check e350578220650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578225594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))) (.var 0)))
theorem wire_e350578225594 : Closed e350578225594 ∧ code e350578225594 = 4748624736698 := by decide
theorem cert_e350578225594 : check e350578225594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578225642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))) (.var 0)))
theorem wire_e350578225642 : Closed e350578225642 ∧ code e350578225642 = 4748624736746 := by decide
theorem cert_e350578225642 : check e350578225642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578226298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))) (.var 0)))
theorem wire_e350578226298 : Closed e350578226298 ∧ code e350578226298 = 4748624737402 := by decide
theorem cert_e350578226298 : check e350578226298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578226630 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.var 1))))
theorem wire_e350578226630 : Closed e350578226630 ∧ code e350578226630 = 4748624737734 := by decide
theorem cert_e350578226630 : check e350578226630 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578226970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578226970 : Closed e350578226970 ∧ code e350578226970 = 4748624738074 := by decide
theorem cert_e350578226970 : check e350578226970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578227014 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578227014 : Closed e350578227014 ∧ code e350578227014 = 4748624738118 := by decide
theorem cert_e350578227014 : check e350578227014 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578228330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e350578228330 : Closed e350578228330 ∧ code e350578228330 = 4748624739434 := by decide
theorem cert_e350578228330 : check e350578228330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578228506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e350578228506 : Closed e350578228506 ∧ code e350578228506 = 4748624739610 := by decide
theorem cert_e350578228506 : check e350578228506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578228550 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e350578228550 : Closed e350578228550 ∧ code e350578228550 = 4748624739654 := by decide
theorem cert_e350578228550 : check e350578228550 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578232442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e350578232442 : Closed e350578232442 ∧ code e350578232442 = 4748624743546 := by decide
theorem cert_e350578232442 : check e350578232442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578232774 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.var 1))))
theorem wire_e350578232774 : Closed e350578232774 ∧ code e350578232774 = 4748624743878 := by decide
theorem cert_e350578232774 : check e350578232774 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578233114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578233114 : Closed e350578233114 ∧ code e350578233114 = 4748624744218 := by decide
theorem cert_e350578233114 : check e350578233114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578233158 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578233158 : Closed e350578233158 ∧ code e350578233158 = 4748624744262 := by decide
theorem cert_e350578233158 : check e350578233158 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578242330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350578242330 : Closed e350578242330 ∧ code e350578242330 = 4748624753434 := by decide
theorem cert_e350578242330 : check e350578242330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350578242374 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350578242374 : Closed e350578242374 ∧ code e350578242374 = 4748624753478 := by decide
theorem cert_e350578242374 : check e350578242374 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor42
