import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e417048391222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e417048391222 : Closed e417048391222 ∧ code e417048391222 = 4815094902326 := by decide
theorem cert_e417048391222 : check e417048391222 [] .sourceHead = true := by decide
def e417048391226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e417048391226 : Closed e417048391226 ∧ code e417048391226 = 4815094902330 := by decide
theorem cert_e417048391226 : check e417048391226 [] .sourceHead = true := by decide
def e417048391310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e417048391310 : Closed e417048391310 ∧ code e417048391310 = 4815094902414 := by decide
theorem cert_e417048391310 : check e417048391310 [] .sourceHead = true := by decide
def e417048391366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e417048391366 : Closed e417048391366 ∧ code e417048391366 = 4815094902470 := by decide
theorem cert_e417048391366 : check e417048391366 [] .sourceHead = true := by decide
def e417048392110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e417048392110 : Closed e417048392110 ∧ code e417048392110 = 4815094903214 := by decide
theorem cert_e417048392110 : check e417048392110 [] .sourceHead = true := by decide
def e417048392122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e417048392122 : Closed e417048392122 ∧ code e417048392122 = 4815094903226 := by decide
theorem cert_e417048392122 : check e417048392122 [] .sourceHead = true := by decide
def e417048392170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e417048392170 : Closed e417048392170 ∧ code e417048392170 = 4815094903274 := by decide
theorem cert_e417048392170 : check e417048392170 [] .sourceHead = true := by decide
def e417048392814 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e417048392814 : Closed e417048392814 ∧ code e417048392814 = 4815094903918 := by decide
theorem cert_e417048392814 : check e417048392814 [] .sourceHead = true := by decide
def e417048392826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e417048392826 : Closed e417048392826 ∧ code e417048392826 = 4815094903930 := by decide
theorem cert_e417048392826 : check e417048392826 [] .sourceHead = true := by decide
def e417048392990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e417048392990 : Closed e417048392990 ∧ code e417048392990 = 4815094904094 := by decide
theorem cert_e417048392990 : check e417048392990 [] .sourceHead = true := by decide
def e417048393158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e417048393158 : Closed e417048393158 ∧ code e417048393158 = 4815094904262 := by decide
theorem cert_e417048393158 : check e417048393158 [] .sourceHead = true := by decide
def e417048393498 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e417048393498 : Closed e417048393498 ∧ code e417048393498 = 4815094904602 := by decide
theorem cert_e417048393498 : check e417048393498 [] .sourceHead = true := by decide
def e417048393542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e417048393542 : Closed e417048393542 ∧ code e417048393542 = 4815094904646 := by decide
theorem cert_e417048393542 : check e417048393542 [] .sourceHead = true := by decide
def e417048393942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e417048393942 : Closed e417048393942 ∧ code e417048393942 = 4815094905046 := by decide
theorem cert_e417048393942 : check e417048393942 [] .sourceHead = true := by decide
def e417048393946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e417048393946 : Closed e417048393946 ∧ code e417048393946 = 4815094905050 := by decide
theorem cert_e417048393946 : check e417048393946 [] .sourceHead = true := by decide
def e417048393962 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e417048393962 : Closed e417048393962 ∧ code e417048393962 = 4815094905066 := by decide
theorem cert_e417048393962 : check e417048393962 [] .sourceHead = true := by decide
def e417048394294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e417048394294 : Closed e417048394294 ∧ code e417048394294 = 4815094905398 := by decide
theorem cert_e417048394294 : check e417048394294 [] .sourceHead = true := by decide
def e417048394298 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e417048394298 : Closed e417048394298 ∧ code e417048394298 = 4815094905402 := by decide
theorem cert_e417048394298 : check e417048394298 [] .sourceHead = true := by decide
def e417048394382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e417048394382 : Closed e417048394382 ∧ code e417048394382 = 4815094905486 := by decide
theorem cert_e417048394382 : check e417048394382 [] .sourceHead = true := by decide
def e417048394438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e417048394438 : Closed e417048394438 ∧ code e417048394438 = 4815094905542 := by decide
theorem cert_e417048394438 : check e417048394438 [] .sourceHead = true := by decide
def e417048394522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e417048394522 : Closed e417048394522 ∧ code e417048394522 = 4815094905626 := by decide
theorem cert_e417048394522 : check e417048394522 [] .sourceHead = true := by decide
def e417048394566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e417048394566 : Closed e417048394566 ∧ code e417048394566 = 4815094905670 := by decide
theorem cert_e417048394566 : check e417048394566 [] .sourceHead = true := by decide
def e417048399086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e417048399086 : Closed e417048399086 ∧ code e417048399086 = 4815094910190 := by decide
theorem cert_e417048399086 : check e417048399086 [] .sourceHead = true := by decide
def e417048399094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e417048399094 : Closed e417048399094 ∧ code e417048399094 = 4815094910198 := by decide
theorem cert_e417048399094 : check e417048399094 [] .sourceHead = true := by decide
def e417048399470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e417048399470 : Closed e417048399470 ∧ code e417048399470 = 4815094910574 := by decide
theorem cert_e417048399470 : check e417048399470 [] .sourceHead = true := by decide
def e417048399482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e417048399482 : Closed e417048399482 ∧ code e417048399482 = 4815094910586 := by decide
theorem cert_e417048399482 : check e417048399482 [] .sourceHead = true := by decide
def e417048399670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e417048399670 : Closed e417048399670 ∧ code e417048399670 = 4815094910774 := by decide
theorem cert_e417048399670 : check e417048399670 [] .sourceHead = true := by decide
def e417048399674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e417048399674 : Closed e417048399674 ∧ code e417048399674 = 4815094910778 := by decide
theorem cert_e417048399674 : check e417048399674 [] .sourceHead = true := by decide
def e417048402158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e417048402158 : Closed e417048402158 ∧ code e417048402158 = 4815094913262 := by decide
theorem cert_e417048402158 : check e417048402158 [] .sourceHead = true := by decide
def e417048402166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e417048402166 : Closed e417048402166 ∧ code e417048402166 = 4815094913270 := by decide
theorem cert_e417048402166 : check e417048402166 [] .sourceHead = true := by decide
def e417048402718 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e417048402718 : Closed e417048402718 ∧ code e417048402718 = 4815094913822 := by decide
theorem cert_e417048402718 : check e417048402718 [] .sourceHead = true := by decide
def e417048402830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e417048402830 : Closed e417048402830 ∧ code e417048402830 = 4815094913934 := by decide
theorem cert_e417048402830 : check e417048402830 [] .sourceHead = true := by decide
def e417048403054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e417048403054 : Closed e417048403054 ∧ code e417048403054 = 4815094914158 := by decide
theorem cert_e417048403054 : check e417048403054 [] .sourceHead = true := by decide
def e417048403066 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e417048403066 : Closed e417048403066 ∧ code e417048403066 = 4815094914170 := by decide
theorem cert_e417048403066 : check e417048403066 [] .sourceHead = true := by decide
def e417048403230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e417048403230 : Closed e417048403230 ∧ code e417048403230 = 4815094914334 := by decide
theorem cert_e417048403230 : check e417048403230 [] .sourceHead = true := by decide
def e417048403398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e417048403398 : Closed e417048403398 ∧ code e417048403398 = 4815094914502 := by decide
theorem cert_e417048403398 : check e417048403398 [] .sourceHead = true := by decide
def e417048403510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e417048403510 : Closed e417048403510 ∧ code e417048403510 = 4815094914614 := by decide
theorem cert_e417048403510 : check e417048403510 [] .sourceHead = true := by decide
def e417048403514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e417048403514 : Closed e417048403514 ∧ code e417048403514 = 4815094914618 := by decide
theorem cert_e417048403514 : check e417048403514 [] .sourceHead = true := by decide
def e417048403598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e417048403598 : Closed e417048403598 ∧ code e417048403598 = 4815094914702 := by decide
theorem cert_e417048403598 : check e417048403598 [] .sourceHead = true := by decide
def e417048403654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e417048403654 : Closed e417048403654 ∧ code e417048403654 = 4815094914758 := by decide
theorem cert_e417048403654 : check e417048403654 [] .sourceHead = true := by decide
def e417048405790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e417048405790 : Closed e417048405790 ∧ code e417048405790 = 4815094916894 := by decide
theorem cert_e417048405790 : check e417048405790 [] .sourceHead = true := by decide
def e417048405902 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e417048405902 : Closed e417048405902 ∧ code e417048405902 = 4815094917006 := by decide
theorem cert_e417048405902 : check e417048405902 [] .sourceHead = true := by decide
def e417048408862 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e417048408862 : Closed e417048408862 ∧ code e417048408862 = 4815094919966 := by decide
theorem cert_e417048408862 : check e417048408862 [] .sourceHead = true := by decide
def e417048409030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e417048409030 : Closed e417048409030 ∧ code e417048409030 = 4815094920134 := by decide
theorem cert_e417048409030 : check e417048409030 [] .sourceHead = true := by decide
def e417048410510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e417048410510 : Closed e417048410510 ∧ code e417048410510 = 4815094921614 := by decide
theorem cert_e417048410510 : check e417048410510 [] .sourceHead = true := by decide
def e417048410566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e417048410566 : Closed e417048410566 ∧ code e417048410566 = 4815094921670 := by decide
theorem cert_e417048410566 : check e417048410566 [] .sourceHead = true := by decide
def e417048413806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e417048413806 : Closed e417048413806 ∧ code e417048413806 = 4815094924910 := by decide
theorem cert_e417048413806 : check e417048413806 [] .sourceHead = true := by decide
def e417048413818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e417048413818 : Closed e417048413818 ∧ code e417048413818 = 4815094924922 := by decide
theorem cert_e417048413818 : check e417048413818 [] .sourceHead = true := by decide
def e417048414106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e417048414106 : Closed e417048414106 ∧ code e417048414106 = 4815094925210 := by decide
theorem cert_e417048414106 : check e417048414106 [] .sourceHead = true := by decide
def e417048415342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e417048415342 : Closed e417048415342 ∧ code e417048415342 = 4815094926446 := by decide
theorem cert_e417048415342 : check e417048415342 [] .sourceHead = true := by decide
def e417048415354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e417048415354 : Closed e417048415354 ∧ code e417048415354 = 4815094926458 := by decide
theorem cert_e417048415354 : check e417048415354 [] .sourceHead = true := by decide
def e417048415518 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e417048415518 : Closed e417048415518 ∧ code e417048415518 = 4815094926622 := by decide
theorem cert_e417048415518 : check e417048415518 [] .sourceHead = true := by decide
def e417048415686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e417048415686 : Closed e417048415686 ∧ code e417048415686 = 4815094926790 := by decide
theorem cert_e417048415686 : check e417048415686 [] .sourceHead = true := by decide
def e417048416026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e417048416026 : Closed e417048416026 ∧ code e417048416026 = 4815094927130 := by decide
theorem cert_e417048416026 : check e417048416026 [] .sourceHead = true := by decide
def e417048416070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e417048416070 : Closed e417048416070 ∧ code e417048416070 = 4815094927174 := by decide
theorem cert_e417048416070 : check e417048416070 [] .sourceHead = true := by decide
def e417048417054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e417048417054 : Closed e417048417054 ∧ code e417048417054 = 4815094928158 := by decide
theorem cert_e417048417054 : check e417048417054 [] .sourceHead = true := by decide
def e417048417222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e417048417222 : Closed e417048417222 ∧ code e417048417222 = 4815094928326 := by decide
theorem cert_e417048417222 : check e417048417222 [] .sourceHead = true := by decide
def e417048419526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e417048419526 : Closed e417048419526 ∧ code e417048419526 = 4815094930630 := by decide
theorem cert_e417048419526 : check e417048419526 [] .sourceHead = true := by decide
def e417048421174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e417048421174 : Closed e417048421174 ∧ code e417048421174 = 4815094932278 := by decide
theorem cert_e417048421174 : check e417048421174 [] .sourceHead = true := by decide
def e417048421178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e417048421178 : Closed e417048421178 ∧ code e417048421178 = 4815094932282 := by decide
theorem cert_e417048421178 : check e417048421178 [] .sourceHead = true := by decide
def e417048421274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e417048421274 : Closed e417048421274 ∧ code e417048421274 = 4815094932378 := by decide
theorem cert_e417048421274 : check e417048421274 [] .sourceHead = true := by decide
def e417048421942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e417048421942 : Closed e417048421942 ∧ code e417048421942 = 4815094933046 := by decide
theorem cert_e417048421942 : check e417048421942 [] .sourceHead = true := by decide
def e417048421946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e417048421946 : Closed e417048421946 ∧ code e417048421946 = 4815094933050 := by decide
theorem cert_e417048421946 : check e417048421946 [] .sourceHead = true := by decide
def e417048422030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e417048422030 : Closed e417048422030 ∧ code e417048422030 = 4815094933134 := by decide
theorem cert_e417048422030 : check e417048422030 [] .sourceHead = true := by decide
def e417048422086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e417048422086 : Closed e417048422086 ∧ code e417048422086 = 4815094933190 := by decide
theorem cert_e417048422086 : check e417048422086 [] .sourceHead = true := by decide
def e417048422170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e417048422170 : Closed e417048422170 ∧ code e417048422170 = 4815094933274 := by decide
theorem cert_e417048422170 : check e417048422170 [] .sourceHead = true := by decide
def e417048422214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e417048422214 : Closed e417048422214 ∧ code e417048422214 = 4815094933318 := by decide
theorem cert_e417048422214 : check e417048422214 [] .sourceHead = true := by decide
def e417048422798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e417048422798 : Closed e417048422798 ∧ code e417048422798 = 4815094933902 := by decide
theorem cert_e417048422798 : check e417048422798 [] .sourceHead = true := by decide
def e417048422854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e417048422854 : Closed e417048422854 ∧ code e417048422854 = 4815094933958 := by decide
theorem cert_e417048422854 : check e417048422854 [] .sourceHead = true := by decide
def e417048423622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e417048423622 : Closed e417048423622 ∧ code e417048423622 = 4815094934726 := by decide
theorem cert_e417048423622 : check e417048423622 [] .sourceHead = true := by decide
def e417048434398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e417048434398 : Closed e417048434398 ∧ code e417048434398 = 4815094945502 := by decide
theorem cert_e417048434398 : check e417048434398 [] .sourceHead = true := by decide
def e417048434422 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e417048434422 : Closed e417048434422 ∧ code e417048434422 = 4815094945526 := by decide
theorem cert_e417048434422 : check e417048434422 [] .sourceHead = true := by decide
def e417048434526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e417048434526 : Closed e417048434526 ∧ code e417048434526 = 4815094945630 := by decide
theorem cert_e417048434526 : check e417048434526 [] .sourceHead = true := by decide
def e417048434554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e417048434554 : Closed e417048434554 ∧ code e417048434554 = 4815094945658 := by decide
theorem cert_e417048434554 : check e417048434554 [] .sourceHead = true := by decide
def e417048434646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e417048434646 : Closed e417048434646 ∧ code e417048434646 = 4815094945750 := by decide
theorem cert_e417048434646 : check e417048434646 [] .sourceHead = true := by decide
def e417048434650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e417048434650 : Closed e417048434650 ∧ code e417048434650 = 4815094945754 := by decide
theorem cert_e417048434650 : check e417048434650 [] .sourceHead = true := by decide
def e417048435166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e417048435166 : Closed e417048435166 ∧ code e417048435166 = 4815094946270 := by decide
theorem cert_e417048435166 : check e417048435166 [] .sourceHead = true := by decide
def e417048435190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e417048435190 : Closed e417048435190 ∧ code e417048435190 = 4815094946294 := by decide
theorem cert_e417048435190 : check e417048435190 [] .sourceHead = true := by decide
def e417048435934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e417048435934 : Closed e417048435934 ∧ code e417048435934 = 4815094947038 := by decide
theorem cert_e417048435934 : check e417048435934 [] .sourceHead = true := by decide
def e417048435962 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e417048435962 : Closed e417048435962 ∧ code e417048435962 = 4815094947066 := by decide
theorem cert_e417048435962 : check e417048435962 [] .sourceHead = true := by decide
def e417048436534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e417048436534 : Closed e417048436534 ∧ code e417048436534 = 4815094947638 := by decide
theorem cert_e417048436534 : check e417048436534 [] .sourceHead = true := by decide
def e417048436538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e417048436538 : Closed e417048436538 ∧ code e417048436538 = 4815094947642 := by decide
theorem cert_e417048436538 : check e417048436538 [] .sourceHead = true := by decide
def e417048451310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e417048451310 : Closed e417048451310 ∧ code e417048451310 = 4815094962414 := by decide
theorem cert_e417048451310 : check e417048451310 [] .sourceHead = true := by decide
def e417048451318 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e417048451318 : Closed e417048451318 ∧ code e417048451318 = 4815094962422 := by decide
theorem cert_e417048451318 : check e417048451318 [] .sourceHead = true := by decide
def e417048451870 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e417048451870 : Closed e417048451870 ∧ code e417048451870 = 4815094962974 := by decide
theorem cert_e417048451870 : check e417048451870 [] .sourceHead = true := by decide
def e417048451982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e417048451982 : Closed e417048451982 ∧ code e417048451982 = 4815094963086 := by decide
theorem cert_e417048451982 : check e417048451982 [] .sourceHead = true := by decide
def e417048452206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e417048452206 : Closed e417048452206 ∧ code e417048452206 = 4815094963310 := by decide
theorem cert_e417048452206 : check e417048452206 [] .sourceHead = true := by decide
def e417048452218 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e417048452218 : Closed e417048452218 ∧ code e417048452218 = 4815094963322 := by decide
theorem cert_e417048452218 : check e417048452218 [] .sourceHead = true := by decide
def e417048452382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e417048452382 : Closed e417048452382 ∧ code e417048452382 = 4815094963486 := by decide
theorem cert_e417048452382 : check e417048452382 [] .sourceHead = true := by decide
def e417048452550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e417048452550 : Closed e417048452550 ∧ code e417048452550 = 4815094963654 := by decide
theorem cert_e417048452550 : check e417048452550 [] .sourceHead = true := by decide
def e417048452662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e417048452662 : Closed e417048452662 ∧ code e417048452662 = 4815094963766 := by decide
theorem cert_e417048452662 : check e417048452662 [] .sourceHead = true := by decide
def e417048452666 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e417048452666 : Closed e417048452666 ∧ code e417048452666 = 4815094963770 := by decide
theorem cert_e417048452666 : check e417048452666 [] .sourceHead = true := by decide
def e417048452750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e417048452750 : Closed e417048452750 ∧ code e417048452750 = 4815094963854 := by decide
theorem cert_e417048452750 : check e417048452750 [] .sourceHead = true := by decide
def e417048452806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e417048452806 : Closed e417048452806 ∧ code e417048452806 = 4815094963910 := by decide
theorem cert_e417048452806 : check e417048452806 [] .sourceHead = true := by decide
def e417048454942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e417048454942 : Closed e417048454942 ∧ code e417048454942 = 4815094966046 := by decide
theorem cert_e417048454942 : check e417048454942 [] .sourceHead = true := by decide
def e417048455054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e417048455054 : Closed e417048455054 ∧ code e417048455054 = 4815094966158 := by decide
theorem cert_e417048455054 : check e417048455054 [] .sourceHead = true := by decide
def e417048458014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e417048458014 : Closed e417048458014 ∧ code e417048458014 = 4815094969118 := by decide
theorem cert_e417048458014 : check e417048458014 [] .sourceHead = true := by decide
def e417048458182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e417048458182 : Closed e417048458182 ∧ code e417048458182 = 4815094969286 := by decide
theorem cert_e417048458182 : check e417048458182 [] .sourceHead = true := by decide
def e417048459662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e417048459662 : Closed e417048459662 ∧ code e417048459662 = 4815094970766 := by decide
theorem cert_e417048459662 : check e417048459662 [] .sourceHead = true := by decide
def e417048459718 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e417048459718 : Closed e417048459718 ∧ code e417048459718 = 4815094970822 := by decide
theorem cert_e417048459718 : check e417048459718 [] .sourceHead = true := by decide
def e417048497006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e417048497006 : Closed e417048497006 ∧ code e417048497006 = 4815095008110 := by decide
theorem cert_e417048497006 : check e417048497006 [] .sourceHead = true := by decide
def e417048497014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e417048497014 : Closed e417048497014 ∧ code e417048497014 = 4815095008118 := by decide
theorem cert_e417048497014 : check e417048497014 [] .sourceHead = true := by decide
def e417048497070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e417048497070 : Closed e417048497070 ∧ code e417048497070 = 4815095008174 := by decide
theorem cert_e417048497070 : check e417048497070 [] .sourceHead = true := by decide
def e417048497082 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e417048497082 : Closed e417048497082 ∧ code e417048497082 = 4815095008186 := by decide
theorem cert_e417048497082 : check e417048497082 [] .sourceHead = true := by decide
def e417048497110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e417048497110 : Closed e417048497110 ∧ code e417048497110 = 4815095008214 := by decide
theorem cert_e417048497110 : check e417048497110 [] .sourceHead = true := by decide
def e417048497114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e417048497114 : Closed e417048497114 ∧ code e417048497114 = 4815095008218 := by decide
theorem cert_e417048497114 : check e417048497114 [] .sourceHead = true := by decide
def e417048497390 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e417048497390 : Closed e417048497390 ∧ code e417048497390 = 4815095008494 := by decide
theorem cert_e417048497390 : check e417048497390 [] .sourceHead = true := by decide
def e417048497398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e417048497398 : Closed e417048497398 ∧ code e417048497398 = 4815095008502 := by decide
theorem cert_e417048497398 : check e417048497398 [] .sourceHead = true := by decide
def e417048497774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e417048497774 : Closed e417048497774 ∧ code e417048497774 = 4815095008878 := by decide
theorem cert_e417048497774 : check e417048497774 [] .sourceHead = true := by decide
def e417048497786 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e417048497786 : Closed e417048497786 ∧ code e417048497786 = 4815095008890 := by decide
theorem cert_e417048497786 : check e417048497786 [] .sourceHead = true := by decide
def e417048497974 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e417048497974 : Closed e417048497974 ∧ code e417048497974 = 4815095009078 := by decide
theorem cert_e417048497974 : check e417048497974 [] .sourceHead = true := by decide
def e417048497978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e417048497978 : Closed e417048497978 ∧ code e417048497978 = 4815095009082 := by decide
theorem cert_e417048497978 : check e417048497978 [] .sourceHead = true := by decide
def e417048505454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e417048505454 : Closed e417048505454 ∧ code e417048505454 = 4815095016558 := by decide
theorem cert_e417048505454 : check e417048505454 [] .sourceHead = true := by decide
def e417048505466 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e417048505466 : Closed e417048505466 ∧ code e417048505466 = 4815095016570 := by decide
theorem cert_e417048505466 : check e417048505466 [] .sourceHead = true := by decide
def e417048505630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e417048505630 : Closed e417048505630 ∧ code e417048505630 = 4815095016734 := by decide
theorem cert_e417048505630 : check e417048505630 [] .sourceHead = true := by decide
def e417048505798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e417048505798 : Closed e417048505798 ∧ code e417048505798 = 4815095016902 := by decide
theorem cert_e417048505798 : check e417048505798 [] .sourceHead = true := by decide
def e417048506138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e417048506138 : Closed e417048506138 ∧ code e417048506138 = 4815095017242 := by decide
theorem cert_e417048506138 : check e417048506138 [] .sourceHead = true := by decide
def e417048506182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e417048506182 : Closed e417048506182 ∧ code e417048506182 = 4815095017286 := by decide
theorem cert_e417048506182 : check e417048506182 [] .sourceHead = true := by decide
def e417048507166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e417048507166 : Closed e417048507166 ∧ code e417048507166 = 4815095018270 := by decide
theorem cert_e417048507166 : check e417048507166 [] .sourceHead = true := by decide
def e417048507334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e417048507334 : Closed e417048507334 ∧ code e417048507334 = 4815095018438 := by decide
theorem cert_e417048507334 : check e417048507334 [] .sourceHead = true := by decide
def e417048509638 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e417048509638 : Closed e417048509638 ∧ code e417048509638 = 4815095020742 := by decide
theorem cert_e417048509638 : check e417048509638 [] .sourceHead = true := by decide
def e417048532534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e417048532534 : Closed e417048532534 ∧ code e417048532534 = 4815095043638 := by decide
theorem cert_e417048532534 : check e417048532534 [] .sourceHead = true := by decide
def e417048532538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e417048532538 : Closed e417048532538 ∧ code e417048532538 = 4815095043642 := by decide
theorem cert_e417048532538 : check e417048532538 [] .sourceHead = true := by decide
def e417048532622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e417048532622 : Closed e417048532622 ∧ code e417048532622 = 4815095043726 := by decide
theorem cert_e417048532622 : check e417048532622 [] .sourceHead = true := by decide
def e417048532678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e417048532678 : Closed e417048532678 ∧ code e417048532678 = 4815095043782 := by decide
theorem cert_e417048532678 : check e417048532678 [] .sourceHead = true := by decide
def e417048532762 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e417048532762 : Closed e417048532762 ∧ code e417048532762 = 4815095043866 := by decide
theorem cert_e417048532762 : check e417048532762 [] .sourceHead = true := by decide
def e417048532806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e417048532806 : Closed e417048532806 ∧ code e417048532806 = 4815095043910 := by decide
theorem cert_e417048532806 : check e417048532806 [] .sourceHead = true := by decide
def e417048533390 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e417048533390 : Closed e417048533390 ∧ code e417048533390 = 4815095044494 := by decide
theorem cert_e417048533390 : check e417048533390 [] .sourceHead = true := by decide
def e417048533446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e417048533446 : Closed e417048533446 ∧ code e417048533446 = 4815095044550 := by decide
theorem cert_e417048533446 : check e417048533446 [] .sourceHead = true := by decide
def e417048534214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e417048534214 : Closed e417048534214 ∧ code e417048534214 = 4815095045318 := by decide
theorem cert_e417048534214 : check e417048534214 [] .sourceHead = true := by decide
def e417049630958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e417049630958 : Closed e417049630958 ∧ code e417049630958 = 4815096142062 := by decide
theorem cert_e417049630958 : check e417049630958 [] .sourceHead = true := by decide
def e417049630966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e417049630966 : Closed e417049630966 ∧ code e417049630966 = 4815096142070 := by decide
theorem cert_e417049630966 : check e417049630966 [] .sourceHead = true := by decide
def e417049631518 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e417049631518 : Closed e417049631518 ∧ code e417049631518 = 4815096142622 := by decide
theorem cert_e417049631518 : check e417049631518 [] .sourceHead = true := by decide
def e417049631630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e417049631630 : Closed e417049631630 ∧ code e417049631630 = 4815096142734 := by decide
theorem cert_e417049631630 : check e417049631630 [] .sourceHead = true := by decide
def e417049631854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e417049631854 : Closed e417049631854 ∧ code e417049631854 = 4815096142958 := by decide
theorem cert_e417049631854 : check e417049631854 [] .sourceHead = true := by decide
def e417049631866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e417049631866 : Closed e417049631866 ∧ code e417049631866 = 4815096142970 := by decide
theorem cert_e417049631866 : check e417049631866 [] .sourceHead = true := by decide
def e417049632030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e417049632030 : Closed e417049632030 ∧ code e417049632030 = 4815096143134 := by decide
theorem cert_e417049632030 : check e417049632030 [] .sourceHead = true := by decide
def e417049632198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e417049632198 : Closed e417049632198 ∧ code e417049632198 = 4815096143302 := by decide
theorem cert_e417049632198 : check e417049632198 [] .sourceHead = true := by decide
def e417049632310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e417049632310 : Closed e417049632310 ∧ code e417049632310 = 4815096143414 := by decide
theorem cert_e417049632310 : check e417049632310 [] .sourceHead = true := by decide
def e417049632314 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e417049632314 : Closed e417049632314 ∧ code e417049632314 = 4815096143418 := by decide
theorem cert_e417049632314 : check e417049632314 [] .sourceHead = true := by decide
def e417049632398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e417049632398 : Closed e417049632398 ∧ code e417049632398 = 4815096143502 := by decide
theorem cert_e417049632398 : check e417049632398 [] .sourceHead = true := by decide
def e417049632454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e417049632454 : Closed e417049632454 ∧ code e417049632454 = 4815096143558 := by decide
theorem cert_e417049632454 : check e417049632454 [] .sourceHead = true := by decide
def e417049634590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e417049634590 : Closed e417049634590 ∧ code e417049634590 = 4815096145694 := by decide
theorem cert_e417049634590 : check e417049634590 [] .sourceHead = true := by decide
def e417049634702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e417049634702 : Closed e417049634702 ∧ code e417049634702 = 4815096145806 := by decide
theorem cert_e417049634702 : check e417049634702 [] .sourceHead = true := by decide
def e417049637662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e417049637662 : Closed e417049637662 ∧ code e417049637662 = 4815096148766 := by decide
theorem cert_e417049637662 : check e417049637662 [] .sourceHead = true := by decide
def e417049637830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e417049637830 : Closed e417049637830 ∧ code e417049637830 = 4815096148934 := by decide
theorem cert_e417049637830 : check e417049637830 [] .sourceHead = true := by decide
def e417049639310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e417049639310 : Closed e417049639310 ∧ code e417049639310 = 4815096150414 := by decide
theorem cert_e417049639310 : check e417049639310 [] .sourceHead = true := by decide
def e417049639366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e417049639366 : Closed e417049639366 ∧ code e417049639366 = 4815096150470 := by decide
theorem cert_e417049639366 : check e417049639366 [] .sourceHead = true := by decide
def e431113334982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431113334982 : Closed e431113334982 ∧ code e431113334982 = 4829159846086 := by decide
theorem cert_e431113334982 : check e431113334982 [] .sourceHead = true := by decide
def e431113351366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431113351366 : Closed e431113351366 ∧ code e431113351366 = 4829159862470 := by decide
theorem cert_e431113351366 : check e431113351366 [] .sourceHead = true := by decide
def e431113466054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431113466054 : Closed e431113466054 ∧ code e431113466054 = 4829159977158 := by decide
theorem cert_e431113466054 : check e431113466054 [] .sourceHead = true := by decide
def e431113490630 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431113490630 : Closed e431113490630 ∧ code e431113490630 = 4829160001734 := by decide
theorem cert_e431113490630 : check e431113490630 [] .sourceHead = true := by decide
def e431113547974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431113547974 : Closed e431113547974 ∧ code e431113547974 = 4829160059078 := by decide
theorem cert_e431113547974 : check e431113547974 [] .sourceHead = true := by decide
def e431113556166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431113556166 : Closed e431113556166 ∧ code e431113556166 = 4829160067270 := by decide
theorem cert_e431113556166 : check e431113556166 [] .sourceHead = true := by decide
def e431114121414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431114121414 : Closed e431114121414 ∧ code e431114121414 = 4829160632518 := by decide
theorem cert_e431114121414 : check e431114121414 [] .sourceHead = true := by decide
def e431114137798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431114137798 : Closed e431114137798 ∧ code e431114137798 = 4829160648902 := by decide
theorem cert_e431114137798 : check e431114137798 [] .sourceHead = true := by decide
def e431114907846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431114907846 : Closed e431114907846 ∧ code e431114907846 = 4829161418950 := by decide
theorem cert_e431114907846 : check e431114907846 [] .sourceHead = true := by decide
def e431114932422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431114932422 : Closed e431114932422 ∧ code e431114932422 = 4829161443526 := by decide
theorem cert_e431114932422 : check e431114932422 [] .sourceHead = true := by decide
def e431115317446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431115317446 : Closed e431115317446 ∧ code e431115317446 = 4829161828550 := by decide
theorem cert_e431115317446 : check e431115317446 [] .sourceHead = true := by decide
def e431115325638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e431115325638 : Closed e431115325638 ∧ code e431115325638 = 4829161836742 := by decide
theorem cert_e431115325638 : check e431115325638 [] .sourceHead = true := by decide
end Blc.Floor42
