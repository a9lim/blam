import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186396086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211186396086 : Closed e1211186396086 ∧ code e1211186396086 = 5609232907190 := by decide
theorem cert_e1211186396086 : check e1211186396086 [[],[]] .smaller = true := by decide
def e1211186396118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1211186396118 : Closed e1211186396118 ∧ code e1211186396118 = 5609232907222 := by decide
theorem cert_e1211186396118 : check e1211186396118 [[],[]] .three = true := by decide
def e1211186396122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1211186396122 : Closed e1211186396122 ∧ code e1211186396122 = 5609232907226 := by decide
theorem cert_e1211186396122 : check e1211186396122 [[],[]] .three = true := by decide
def e1211186396246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211186396246 : Closed e1211186396246 ∧ code e1211186396246 = 5609232907350 := by decide
theorem cert_e1211186396246 : check e1211186396246 [[],[]] .three = true := by decide
def e1211186396250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211186396250 : Closed e1211186396250 ∧ code e1211186396250 = 5609232907354 := by decide
theorem cert_e1211186396250 : check e1211186396250 [[],[]] .three = true := by decide
def e1211186396438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186396438 : Closed e1211186396438 ∧ code e1211186396438 = 5609232907542 := by decide
theorem cert_e1211186396438 : check e1211186396438 [[],[]] .three = true := by decide
def e1211186396514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186396514 : Closed e1211186396514 ∧ code e1211186396514 = 5609232907618 := by decide
theorem cert_e1211186396514 : check e1211186396514 [[],[]] .three = true := by decide
def e1211186396526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211186396526 : Closed e1211186396526 ∧ code e1211186396526 = 5609232907630 := by decide
theorem cert_e1211186396526 : check e1211186396526 [[],[]] .three = true := by decide
def e1211186396534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211186396534 : Closed e1211186396534 ∧ code e1211186396534 = 5609232907638 := by decide
theorem cert_e1211186396534 : check e1211186396534 [[],[]] .three = true := by decide
def e1211186396554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186396554 : Closed e1211186396554 ∧ code e1211186396554 = 5609232907658 := by decide
theorem cert_e1211186396554 : check e1211186396554 [[],[]] .three = true := by decide
def e1211186396578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186396578 : Closed e1211186396578 ∧ code e1211186396578 = 5609232907682 := by decide
theorem cert_e1211186396578 : check e1211186396578 [[],[]] .three = true := by decide
def e1211186396590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211186396590 : Closed e1211186396590 ∧ code e1211186396590 = 5609232907694 := by decide
theorem cert_e1211186396590 : check e1211186396590 [[],[]] .three = true := by decide
def e1211186396598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e1211186396598 : Closed e1211186396598 ∧ code e1211186396598 = 5609232907702 := by decide
theorem cert_e1211186396598 : check e1211186396598 [[],[]] .three = true := by decide
def e1211186396602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211186396602 : Closed e1211186396602 ∧ code e1211186396602 = 5609232907706 := by decide
theorem cert_e1211186396602 : check e1211186396602 [[],[]] .three = true := by decide
def e1211186396630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211186396630 : Closed e1211186396630 ∧ code e1211186396630 = 5609232907734 := by decide
theorem cert_e1211186396630 : check e1211186396630 [[],[]] .three = true := by decide
def e1211186396634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211186396634 : Closed e1211186396634 ∧ code e1211186396634 = 5609232907738 := by decide
theorem cert_e1211186396634 : check e1211186396634 [[],[]] .three = true := by decide
def e1211186398558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1211186398558 : Closed e1211186398558 ∧ code e1211186398558 = 5609232909662 := by decide
theorem cert_e1211186398558 : check e1211186398558 [[],[]] .three = true := by decide
def e1211186398574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211186398574 : Closed e1211186398574 ∧ code e1211186398574 = 5609232909678 := by decide
theorem cert_e1211186398574 : check e1211186398574 [[],[]] .smaller = true := by decide
def e1211186398582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211186398582 : Closed e1211186398582 ∧ code e1211186398582 = 5609232909686 := by decide
theorem cert_e1211186398582 : check e1211186398582 [[],[]] .smaller = true := by decide
def e1211186398586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1211186398586 : Closed e1211186398586 ∧ code e1211186398586 = 5609232909690 := by decide
theorem cert_e1211186398586 : check e1211186398586 [[],[]] .three = true := by decide
def e1211186398638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211186398638 : Closed e1211186398638 ∧ code e1211186398638 = 5609232909742 := by decide
theorem cert_e1211186398638 : check e1211186398638 [[],[]] .smaller = true := by decide
def e1211186398650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211186398650 : Closed e1211186398650 ∧ code e1211186398650 = 5609232909754 := by decide
theorem cert_e1211186398650 : check e1211186398650 [[],[]] .smaller = true := by decide
def e1211186398678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211186398678 : Closed e1211186398678 ∧ code e1211186398678 = 5609232909782 := by decide
theorem cert_e1211186398678 : check e1211186398678 [[],[]] .smaller = true := by decide
def e1211186398682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211186398682 : Closed e1211186398682 ∧ code e1211186398682 = 5609232909786 := by decide
theorem cert_e1211186398682 : check e1211186398682 [[],[]] .smaller = true := by decide
def e1211186398698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1211186398698 : Closed e1211186398698 ∧ code e1211186398698 = 5609232909802 := by decide
theorem cert_e1211186398698 : check e1211186398698 [[],[]] .three = true := by decide
def e1211186398894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211186398894 : Closed e1211186398894 ∧ code e1211186398894 = 5609232909998 := by decide
theorem cert_e1211186398894 : check e1211186398894 [[],[]] .smaller = true := by decide
def e1211186398906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211186398906 : Closed e1211186398906 ∧ code e1211186398906 = 5609232910010 := by decide
theorem cert_e1211186398906 : check e1211186398906 [[],[]] .smaller = true := by decide
def e1211186398954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211186398954 : Closed e1211186398954 ∧ code e1211186398954 = 5609232910058 := by decide
theorem cert_e1211186398954 : check e1211186398954 [[],[]] .smaller = true := by decide
def e1211186399146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211186399146 : Closed e1211186399146 ∧ code e1211186399146 = 5609232910250 := by decide
theorem cert_e1211186399146 : check e1211186399146 [[],[]] .smaller = true := by decide
def e1211186401630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e1211186401630 : Closed e1211186401630 ∧ code e1211186401630 = 5609232912734 := by decide
theorem cert_e1211186401630 : check e1211186401630 [[],[]] .three = true := by decide
def e1211186401646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211186401646 : Closed e1211186401646 ∧ code e1211186401646 = 5609232912750 := by decide
theorem cert_e1211186401646 : check e1211186401646 [[],[]] .smaller = true := by decide
def e1211186401654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211186401654 : Closed e1211186401654 ∧ code e1211186401654 = 5609232912758 := by decide
theorem cert_e1211186401654 : check e1211186401654 [[],[]] .smaller = true := by decide
def e1211186401658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e1211186401658 : Closed e1211186401658 ∧ code e1211186401658 = 5609232912762 := by decide
theorem cert_e1211186401658 : check e1211186401658 [[],[]] .three = true := by decide
def e1211186401710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211186401710 : Closed e1211186401710 ∧ code e1211186401710 = 5609232912814 := by decide
theorem cert_e1211186401710 : check e1211186401710 [[],[]] .smaller = true := by decide
def e1211186401722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211186401722 : Closed e1211186401722 ∧ code e1211186401722 = 5609232912826 := by decide
theorem cert_e1211186401722 : check e1211186401722 [[],[]] .smaller = true := by decide
def e1211186401770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1211186401770 : Closed e1211186401770 ∧ code e1211186401770 = 5609232912874 := by decide
theorem cert_e1211186401770 : check e1211186401770 [[],[]] .smaller = true := by decide
def e1211186402398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e1211186402398 : Closed e1211186402398 ∧ code e1211186402398 = 5609232913502 := by decide
theorem cert_e1211186402398 : check e1211186402398 [[],[]] .three = true := by decide
def e1211186402414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186402414 : Closed e1211186402414 ∧ code e1211186402414 = 5609232913518 := by decide
theorem cert_e1211186402414 : check e1211186402414 [[],[]] .smaller = true := by decide
def e1211186402426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186402426 : Closed e1211186402426 ∧ code e1211186402426 = 5609232913530 := by decide
theorem cert_e1211186402426 : check e1211186402426 [[],[]] .smaller = true := by decide
def e1211186402590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186402590 : Closed e1211186402590 ∧ code e1211186402590 = 5609232913694 := by decide
theorem cert_e1211186402590 : check e1211186402590 [[],[]] .smaller = true := by decide
def e1211186402758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186402758 : Closed e1211186402758 ∧ code e1211186402758 = 5609232913862 := by decide
theorem cert_e1211186402758 : check e1211186402758 [[],[]] .smaller = true := by decide
def e1211186402782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e1211186402782 : Closed e1211186402782 ∧ code e1211186402782 = 5609232913886 := by decide
theorem cert_e1211186402782 : check e1211186402782 [[],[]] .three = true := by decide
def e1211186402786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e1211186402786 : Closed e1211186402786 ∧ code e1211186402786 = 5609232913890 := by decide
theorem cert_e1211186402786 : check e1211186402786 [[],[]] .three = true := by decide
def e1211186402798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e1211186402798 : Closed e1211186402798 ∧ code e1211186402798 = 5609232913902 := by decide
theorem cert_e1211186402798 : check e1211186402798 [[],[]] .three = true := by decide
def e1211186402862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211186402862 : Closed e1211186402862 ∧ code e1211186402862 = 5609232913966 := by decide
theorem cert_e1211186402862 : check e1211186402862 [[],[]] .smaller = true := by decide
def e1211186403038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e1211186403038 : Closed e1211186403038 ∧ code e1211186403038 = 5609232914142 := by decide
theorem cert_e1211186403038 : check e1211186403038 [[],[]] .three = true := by decide
def e1211186403042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211186403042 : Closed e1211186403042 ∧ code e1211186403042 = 5609232914146 := by decide
theorem cert_e1211186403042 : check e1211186403042 [[],[]] .smaller = true := by decide
def e1211186403054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e1211186403054 : Closed e1211186403054 ∧ code e1211186403054 = 5609232914158 := by decide
theorem cert_e1211186403054 : check e1211186403054 [[],[]] .smaller = true := by decide
def e1211186403062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e1211186403062 : Closed e1211186403062 ∧ code e1211186403062 = 5609232914166 := by decide
theorem cert_e1211186403062 : check e1211186403062 [[],[]] .three = true := by decide
def e1211186403094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186403094 : Closed e1211186403094 ∧ code e1211186403094 = 5609232914198 := by decide
theorem cert_e1211186403094 : check e1211186403094 [[],[]] .smaller = true := by decide
def e1211186403098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186403098 : Closed e1211186403098 ∧ code e1211186403098 = 5609232914202 := by decide
theorem cert_e1211186403098 : check e1211186403098 [[],[]] .smaller = true := by decide
def e1211186403142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186403142 : Closed e1211186403142 ∧ code e1211186403142 = 5609232914246 := by decide
theorem cert_e1211186403142 : check e1211186403142 [[],[]] .smaller = true := by decide
def e1211186403166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e1211186403166 : Closed e1211186403166 ∧ code e1211186403166 = 5609232914270 := by decide
theorem cert_e1211186403166 : check e1211186403166 [[],[]] .three = true := by decide
def e1211186403170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186403170 : Closed e1211186403170 ∧ code e1211186403170 = 5609232914274 := by decide
theorem cert_e1211186403170 : check e1211186403170 [[],[]] .smaller = true := by decide
def e1211186403182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e1211186403182 : Closed e1211186403182 ∧ code e1211186403182 = 5609232914286 := by decide
theorem cert_e1211186403182 : check e1211186403182 [[],[]] .smaller = true := by decide
def e1211186403190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e1211186403190 : Closed e1211186403190 ∧ code e1211186403190 = 5609232914294 := by decide
theorem cert_e1211186403190 : check e1211186403190 [[],[]] .smaller = true := by decide
def e1211186403194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e1211186403194 : Closed e1211186403194 ∧ code e1211186403194 = 5609232914298 := by decide
theorem cert_e1211186403194 : check e1211186403194 [[],[]] .three = true := by decide
def e1211186403210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186403210 : Closed e1211186403210 ∧ code e1211186403210 = 5609232914314 := by decide
theorem cert_e1211186403210 : check e1211186403210 [[],[]] .three = true := by decide
def e1211186403234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186403234 : Closed e1211186403234 ∧ code e1211186403234 = 5609232914338 := by decide
theorem cert_e1211186403234 : check e1211186403234 [[],[]] .three = true := by decide
def e1211186403246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e1211186403246 : Closed e1211186403246 ∧ code e1211186403246 = 5609232914350 := by decide
theorem cert_e1211186403246 : check e1211186403246 [[],[]] .three = true := by decide
def e1211186403254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e1211186403254 : Closed e1211186403254 ∧ code e1211186403254 = 5609232914358 := by decide
theorem cert_e1211186403254 : check e1211186403254 [[],[]] .three = true := by decide
def e1211186403258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e1211186403258 : Closed e1211186403258 ∧ code e1211186403258 = 5609232914362 := by decide
theorem cert_e1211186403258 : check e1211186403258 [[],[]] .three = true := by decide
def e1211186403502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211186403502 : Closed e1211186403502 ∧ code e1211186403502 = 5609232914606 := by decide
theorem cert_e1211186403502 : check e1211186403502 [[],[]] .smaller = true := by decide
def e1211186403514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211186403514 : Closed e1211186403514 ∧ code e1211186403514 = 5609232914618 := by decide
theorem cert_e1211186403514 : check e1211186403514 [[],[]] .smaller = true := by decide
def e1211186403886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211186403886 : Closed e1211186403886 ∧ code e1211186403886 = 5609232914990 := by decide
theorem cert_e1211186403886 : check e1211186403886 [[],[]] .smaller = true := by decide
def e1211186404062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1211186404062 : Closed e1211186404062 ∧ code e1211186404062 = 5609232915166 := by decide
theorem cert_e1211186404062 : check e1211186404062 [[],[]] .three = true := by decide
def e1211186404066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211186404066 : Closed e1211186404066 ∧ code e1211186404066 = 5609232915170 := by decide
theorem cert_e1211186404066 : check e1211186404066 [[],[]] .smaller = true := by decide
def e1211186404078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e1211186404078 : Closed e1211186404078 ∧ code e1211186404078 = 5609232915182 := by decide
theorem cert_e1211186404078 : check e1211186404078 [[],[]] .smaller = true := by decide
def e1211186404086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1211186404086 : Closed e1211186404086 ∧ code e1211186404086 = 5609232915190 := by decide
theorem cert_e1211186404086 : check e1211186404086 [[],[]] .three = true := by decide
def e1211186404190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1211186404190 : Closed e1211186404190 ∧ code e1211186404190 = 5609232915294 := by decide
theorem cert_e1211186404190 : check e1211186404190 [[],[]] .three = true := by decide
def e1211186404218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1211186404218 : Closed e1211186404218 ∧ code e1211186404218 = 5609232915322 := by decide
theorem cert_e1211186404218 : check e1211186404218 [[],[]] .three = true := by decide
def e1211186404234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186404234 : Closed e1211186404234 ∧ code e1211186404234 = 5609232915338 := by decide
theorem cert_e1211186404234 : check e1211186404234 [[],[]] .smaller = true := by decide
def e1211186404258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186404258 : Closed e1211186404258 ∧ code e1211186404258 = 5609232915362 := by decide
theorem cert_e1211186404258 : check e1211186404258 [[],[]] .smaller = true := by decide
def e1211186404270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e1211186404270 : Closed e1211186404270 ∧ code e1211186404270 = 5609232915374 := by decide
theorem cert_e1211186404270 : check e1211186404270 [[],[]] .smaller = true := by decide
def e1211186404282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e1211186404282 : Closed e1211186404282 ∧ code e1211186404282 = 5609232915386 := by decide
theorem cert_e1211186404282 : check e1211186404282 [[],[]] .smaller = true := by decide
def e1211186404310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1211186404310 : Closed e1211186404310 ∧ code e1211186404310 = 5609232915414 := by decide
theorem cert_e1211186404310 : check e1211186404310 [[],[]] .three = true := by decide
def e1211186404314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1211186404314 : Closed e1211186404314 ∧ code e1211186404314 = 5609232915418 := by decide
theorem cert_e1211186404314 : check e1211186404314 [[],[]] .three = true := by decide
def e1211186404438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211186404438 : Closed e1211186404438 ∧ code e1211186404438 = 5609232915542 := by decide
theorem cert_e1211186404438 : check e1211186404438 [[],[]] .smaller = true := by decide
def e1211186404442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211186404442 : Closed e1211186404442 ∧ code e1211186404442 = 5609232915546 := by decide
theorem cert_e1211186404442 : check e1211186404442 [[],[]] .smaller = true := by decide
def e1211186404458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211186404458 : Closed e1211186404458 ∧ code e1211186404458 = 5609232915562 := by decide
theorem cert_e1211186404458 : check e1211186404458 [[],[]] .smaller = true := by decide
def e1211186404630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186404630 : Closed e1211186404630 ∧ code e1211186404630 = 5609232915734 := by decide
theorem cert_e1211186404630 : check e1211186404630 [[],[]] .smaller = true := by decide
def e1211186404634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186404634 : Closed e1211186404634 ∧ code e1211186404634 = 5609232915738 := by decide
theorem cert_e1211186404634 : check e1211186404634 [[],[]] .smaller = true := by decide
def e1211186404678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186404678 : Closed e1211186404678 ∧ code e1211186404678 = 5609232915782 := by decide
theorem cert_e1211186404678 : check e1211186404678 [[],[]] .smaller = true := by decide
def e1211186404702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1211186404702 : Closed e1211186404702 ∧ code e1211186404702 = 5609232915806 := by decide
theorem cert_e1211186404702 : check e1211186404702 [[],[]] .three = true := by decide
def e1211186404706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186404706 : Closed e1211186404706 ∧ code e1211186404706 = 5609232915810 := by decide
theorem cert_e1211186404706 : check e1211186404706 [[],[]] .smaller = true := by decide
def e1211186404718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211186404718 : Closed e1211186404718 ∧ code e1211186404718 = 5609232915822 := by decide
theorem cert_e1211186404718 : check e1211186404718 [[],[]] .smaller = true := by decide
def e1211186404726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211186404726 : Closed e1211186404726 ∧ code e1211186404726 = 5609232915830 := by decide
theorem cert_e1211186404726 : check e1211186404726 [[],[]] .smaller = true := by decide
def e1211186404730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1211186404730 : Closed e1211186404730 ∧ code e1211186404730 = 5609232915834 := by decide
theorem cert_e1211186404730 : check e1211186404730 [[],[]] .three = true := by decide
def e1211186404746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186404746 : Closed e1211186404746 ∧ code e1211186404746 = 5609232915850 := by decide
theorem cert_e1211186404746 : check e1211186404746 [[],[]] .smaller = true := by decide
def e1211186404770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186404770 : Closed e1211186404770 ∧ code e1211186404770 = 5609232915874 := by decide
theorem cert_e1211186404770 : check e1211186404770 [[],[]] .smaller = true := by decide
def e1211186404782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211186404782 : Closed e1211186404782 ∧ code e1211186404782 = 5609232915886 := by decide
theorem cert_e1211186404782 : check e1211186404782 [[],[]] .smaller = true := by decide
def e1211186404794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211186404794 : Closed e1211186404794 ∧ code e1211186404794 = 5609232915898 := by decide
theorem cert_e1211186404794 : check e1211186404794 [[],[]] .smaller = true := by decide
def e1211186404822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211186404822 : Closed e1211186404822 ∧ code e1211186404822 = 5609232915926 := by decide
theorem cert_e1211186404822 : check e1211186404822 [[],[]] .smaller = true := by decide
def e1211186404826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211186404826 : Closed e1211186404826 ∧ code e1211186404826 = 5609232915930 := by decide
theorem cert_e1211186404826 : check e1211186404826 [[],[]] .smaller = true := by decide
def e1211186404842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1211186404842 : Closed e1211186404842 ∧ code e1211186404842 = 5609232915946 := by decide
theorem cert_e1211186404842 : check e1211186404842 [[],[]] .three = true := by decide
def e1211186404906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e1211186404906 : Closed e1211186404906 ∧ code e1211186404906 = 5609232916010 := by decide
theorem cert_e1211186404906 : check e1211186404906 [[],[]] .three = true := by decide
def e1211186405002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186405002 : Closed e1211186405002 ∧ code e1211186405002 = 5609232916106 := by decide
theorem cert_e1211186405002 : check e1211186405002 [[],[]] .three = true := by decide
def e1211186405026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186405026 : Closed e1211186405026 ∧ code e1211186405026 = 5609232916130 := by decide
theorem cert_e1211186405026 : check e1211186405026 [[],[]] .three = true := by decide
def e1211186405038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e1211186405038 : Closed e1211186405038 ∧ code e1211186405038 = 5609232916142 := by decide
theorem cert_e1211186405038 : check e1211186405038 [[],[]] .three = true := by decide
def e1211186405046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211186405046 : Closed e1211186405046 ∧ code e1211186405046 = 5609232916150 := by decide
theorem cert_e1211186405046 : check e1211186405046 [[],[]] .three = true := by decide
def e1211186405050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e1211186405050 : Closed e1211186405050 ∧ code e1211186405050 = 5609232916154 := by decide
theorem cert_e1211186405050 : check e1211186405050 [[],[]] .three = true := by decide
def e1211186405078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211186405078 : Closed e1211186405078 ∧ code e1211186405078 = 5609232916182 := by decide
theorem cert_e1211186405078 : check e1211186405078 [[],[]] .three = true := by decide
def e1211186405082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211186405082 : Closed e1211186405082 ∧ code e1211186405082 = 5609232916186 := by decide
theorem cert_e1211186405082 : check e1211186405082 [[],[]] .three = true := by decide
def e1211186405098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e1211186405098 : Closed e1211186405098 ∧ code e1211186405098 = 5609232916202 := by decide
theorem cert_e1211186405098 : check e1211186405098 [[],[]] .three = true := by decide
def e1211186406070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211186406070 : Closed e1211186406070 ∧ code e1211186406070 = 5609232917174 := by decide
theorem cert_e1211186406070 : check e1211186406070 [[],[]] .smaller = true := by decide
def e1211186406102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211186406102 : Closed e1211186406102 ∧ code e1211186406102 = 5609232917206 := by decide
theorem cert_e1211186406102 : check e1211186406102 [[],[]] .smaller = true := by decide
def e1211186406106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211186406106 : Closed e1211186406106 ∧ code e1211186406106 = 5609232917210 := by decide
theorem cert_e1211186406106 : check e1211186406106 [[],[]] .smaller = true := by decide
def e1211186406230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211186406230 : Closed e1211186406230 ∧ code e1211186406230 = 5609232917334 := by decide
theorem cert_e1211186406230 : check e1211186406230 [[],[]] .smaller = true := by decide
def e1211186406234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211186406234 : Closed e1211186406234 ∧ code e1211186406234 = 5609232917338 := by decide
theorem cert_e1211186406234 : check e1211186406234 [[],[]] .smaller = true := by decide
def e1211186406250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211186406250 : Closed e1211186406250 ∧ code e1211186406250 = 5609232917354 := by decide
theorem cert_e1211186406250 : check e1211186406250 [[],[]] .smaller = true := by decide
def e1211186406314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211186406314 : Closed e1211186406314 ∧ code e1211186406314 = 5609232917418 := by decide
theorem cert_e1211186406314 : check e1211186406314 [[],[]] .smaller = true := by decide
def e1211186407606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211186407606 : Closed e1211186407606 ∧ code e1211186407606 = 5609232918710 := by decide
theorem cert_e1211186407606 : check e1211186407606 [[],[]] .smaller = true := by decide
def e1211186407638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211186407638 : Closed e1211186407638 ∧ code e1211186407638 = 5609232918742 := by decide
theorem cert_e1211186407638 : check e1211186407638 [[],[]] .smaller = true := by decide
def e1211186407642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211186407642 : Closed e1211186407642 ∧ code e1211186407642 = 5609232918746 := by decide
theorem cert_e1211186407642 : check e1211186407642 [[],[]] .smaller = true := by decide
def e1211186407658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211186407658 : Closed e1211186407658 ∧ code e1211186407658 = 5609232918762 := by decide
theorem cert_e1211186407658 : check e1211186407658 [[],[]] .smaller = true := by decide
def e1211186407990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186407990 : Closed e1211186407990 ∧ code e1211186407990 = 5609232919094 := by decide
theorem cert_e1211186407990 : check e1211186407990 [[],[]] .smaller = true := by decide
def e1211186407994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186407994 : Closed e1211186407994 ∧ code e1211186407994 = 5609232919098 := by decide
theorem cert_e1211186407994 : check e1211186407994 [[],[]] .smaller = true := by decide
def e1211186408078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186408078 : Closed e1211186408078 ∧ code e1211186408078 = 5609232919182 := by decide
theorem cert_e1211186408078 : check e1211186408078 [[],[]] .smaller = true := by decide
def e1211186408134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186408134 : Closed e1211186408134 ∧ code e1211186408134 = 5609232919238 := by decide
theorem cert_e1211186408134 : check e1211186408134 [[],[]] .smaller = true := by decide
def e1211186408158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e1211186408158 : Closed e1211186408158 ∧ code e1211186408158 = 5609232919262 := by decide
theorem cert_e1211186408158 : check e1211186408158 [[],[]] .three = true := by decide
def e1211186408182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e1211186408182 : Closed e1211186408182 ∧ code e1211186408182 = 5609232919286 := by decide
theorem cert_e1211186408182 : check e1211186408182 [[],[]] .three = true := by decide
def e1211186408214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186408214 : Closed e1211186408214 ∧ code e1211186408214 = 5609232919318 := by decide
theorem cert_e1211186408214 : check e1211186408214 [[],[]] .smaller = true := by decide
def e1211186408218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186408218 : Closed e1211186408218 ∧ code e1211186408218 = 5609232919322 := by decide
theorem cert_e1211186408218 : check e1211186408218 [[],[]] .smaller = true := by decide
def e1211186408262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186408262 : Closed e1211186408262 ∧ code e1211186408262 = 5609232919366 := by decide
theorem cert_e1211186408262 : check e1211186408262 [[],[]] .smaller = true := by decide
def e1211186408286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e1211186408286 : Closed e1211186408286 ∧ code e1211186408286 = 5609232919390 := by decide
theorem cert_e1211186408286 : check e1211186408286 [[],[]] .three = true := by decide
def e1211186408290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186408290 : Closed e1211186408290 ∧ code e1211186408290 = 5609232919394 := by decide
theorem cert_e1211186408290 : check e1211186408290 [[],[]] .smaller = true := by decide
def e1211186408302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e1211186408302 : Closed e1211186408302 ∧ code e1211186408302 = 5609232919406 := by decide
theorem cert_e1211186408302 : check e1211186408302 [[],[]] .smaller = true := by decide
def e1211186408310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e1211186408310 : Closed e1211186408310 ∧ code e1211186408310 = 5609232919414 := by decide
theorem cert_e1211186408310 : check e1211186408310 [[],[]] .smaller = true := by decide
def e1211186408314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e1211186408314 : Closed e1211186408314 ∧ code e1211186408314 = 5609232919418 := by decide
theorem cert_e1211186408314 : check e1211186408314 [[],[]] .three = true := by decide
def e1211186408374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e1211186408374 : Closed e1211186408374 ∧ code e1211186408374 = 5609232919478 := by decide
theorem cert_e1211186408374 : check e1211186408374 [[],[]] .smaller = true := by decide
def e1211186408406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e1211186408406 : Closed e1211186408406 ∧ code e1211186408406 = 5609232919510 := by decide
theorem cert_e1211186408406 : check e1211186408406 [[],[]] .three = true := by decide
def e1211186408410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e1211186408410 : Closed e1211186408410 ∧ code e1211186408410 = 5609232919514 := by decide
theorem cert_e1211186408410 : check e1211186408410 [[],[]] .three = true := by decide
def e1211186408534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211186408534 : Closed e1211186408534 ∧ code e1211186408534 = 5609232919638 := by decide
theorem cert_e1211186408534 : check e1211186408534 [[],[]] .smaller = true := by decide
def e1211186408538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211186408538 : Closed e1211186408538 ∧ code e1211186408538 = 5609232919642 := by decide
theorem cert_e1211186408538 : check e1211186408538 [[],[]] .smaller = true := by decide
def e1211186408554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211186408554 : Closed e1211186408554 ∧ code e1211186408554 = 5609232919658 := by decide
theorem cert_e1211186408554 : check e1211186408554 [[],[]] .smaller = true := by decide
def e1211186408726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186408726 : Closed e1211186408726 ∧ code e1211186408726 = 5609232919830 := by decide
theorem cert_e1211186408726 : check e1211186408726 [[],[]] .smaller = true := by decide
def e1211186408730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186408730 : Closed e1211186408730 ∧ code e1211186408730 = 5609232919834 := by decide
theorem cert_e1211186408730 : check e1211186408730 [[],[]] .smaller = true := by decide
def e1211186408774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186408774 : Closed e1211186408774 ∧ code e1211186408774 = 5609232919878 := by decide
theorem cert_e1211186408774 : check e1211186408774 [[],[]] .smaller = true := by decide
def e1211186408798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e1211186408798 : Closed e1211186408798 ∧ code e1211186408798 = 5609232919902 := by decide
theorem cert_e1211186408798 : check e1211186408798 [[],[]] .three = true := by decide
def e1211186408802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186408802 : Closed e1211186408802 ∧ code e1211186408802 = 5609232919906 := by decide
theorem cert_e1211186408802 : check e1211186408802 [[],[]] .smaller = true := by decide
def e1211186408814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e1211186408814 : Closed e1211186408814 ∧ code e1211186408814 = 5609232919918 := by decide
theorem cert_e1211186408814 : check e1211186408814 [[],[]] .smaller = true := by decide
def e1211186408822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e1211186408822 : Closed e1211186408822 ∧ code e1211186408822 = 5609232919926 := by decide
theorem cert_e1211186408822 : check e1211186408822 [[],[]] .smaller = true := by decide
def e1211186408826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e1211186408826 : Closed e1211186408826 ∧ code e1211186408826 = 5609232919930 := by decide
theorem cert_e1211186408826 : check e1211186408826 [[],[]] .three = true := by decide
def e1211186408842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186408842 : Closed e1211186408842 ∧ code e1211186408842 = 5609232919946 := by decide
theorem cert_e1211186408842 : check e1211186408842 [[],[]] .smaller = true := by decide
def e1211186408866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186408866 : Closed e1211186408866 ∧ code e1211186408866 = 5609232919970 := by decide
theorem cert_e1211186408866 : check e1211186408866 [[],[]] .smaller = true := by decide
def e1211186408878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e1211186408878 : Closed e1211186408878 ∧ code e1211186408878 = 5609232919982 := by decide
theorem cert_e1211186408878 : check e1211186408878 [[],[]] .smaller = true := by decide
def e1211186408890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e1211186408890 : Closed e1211186408890 ∧ code e1211186408890 = 5609232919994 := by decide
theorem cert_e1211186408890 : check e1211186408890 [[],[]] .smaller = true := by decide
def e1211186408918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e1211186408918 : Closed e1211186408918 ∧ code e1211186408918 = 5609232920022 := by decide
theorem cert_e1211186408918 : check e1211186408918 [[],[]] .smaller = true := by decide
def e1211186408922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e1211186408922 : Closed e1211186408922 ∧ code e1211186408922 = 5609232920026 := by decide
theorem cert_e1211186408922 : check e1211186408922 [[],[]] .smaller = true := by decide
def e1211186408938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e1211186408938 : Closed e1211186408938 ∧ code e1211186408938 = 5609232920042 := by decide
theorem cert_e1211186408938 : check e1211186408938 [[],[]] .three = true := by decide
def e1211186409142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211186409142 : Closed e1211186409142 ∧ code e1211186409142 = 5609232920246 := by decide
theorem cert_e1211186409142 : check e1211186409142 [[],[]] .smaller = true := by decide
def e1211186409174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211186409174 : Closed e1211186409174 ∧ code e1211186409174 = 5609232920278 := by decide
theorem cert_e1211186409174 : check e1211186409174 [[],[]] .smaller = true := by decide
def e1211186409178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211186409178 : Closed e1211186409178 ∧ code e1211186409178 = 5609232920282 := by decide
theorem cert_e1211186409178 : check e1211186409178 [[],[]] .smaller = true := by decide
def e1211186409302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211186409302 : Closed e1211186409302 ∧ code e1211186409302 = 5609232920406 := by decide
theorem cert_e1211186409302 : check e1211186409302 [[],[]] .three = true := by decide
def e1211186409306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211186409306 : Closed e1211186409306 ∧ code e1211186409306 = 5609232920410 := by decide
theorem cert_e1211186409306 : check e1211186409306 [[],[]] .three = true := by decide
def e1211186409322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211186409322 : Closed e1211186409322 ∧ code e1211186409322 = 5609232920426 := by decide
theorem cert_e1211186409322 : check e1211186409322 [[],[]] .three = true := by decide
def e1211186409814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211186409814 : Closed e1211186409814 ∧ code e1211186409814 = 5609232920918 := by decide
theorem cert_e1211186409814 : check e1211186409814 [[],[]] .three = true := by decide
def e1211186409818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211186409818 : Closed e1211186409818 ∧ code e1211186409818 = 5609232920922 := by decide
theorem cert_e1211186409818 : check e1211186409818 [[],[]] .three = true := by decide
def e1211186409834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211186409834 : Closed e1211186409834 ∧ code e1211186409834 = 5609232920938 := by decide
theorem cert_e1211186409834 : check e1211186409834 [[],[]] .three = true := by decide
def e1211186410582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211186410582 : Closed e1211186410582 ∧ code e1211186410582 = 5609232921686 := by decide
theorem cert_e1211186410582 : check e1211186410582 [[],[]] .three = true := by decide
end Blc.Floor42
