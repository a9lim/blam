import Tables
import Batch127
namespace Blc.Floor42.Grades127
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1209571601294 : ¬ IsSelfInterpreter e1209571601294 := cutM15_2 (by decide)
#print axioms ex_e1209571601294
end Blc.Floor42.Grades127
