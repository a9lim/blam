import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211584857542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211584857542 : Closed e1211584857542 ∧ code e1211584857542 = 5609631368646 := by decide
def e1211584857646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211584857646 : Closed e1211584857646 ∧ code e1211584857646 = 5609631368750 := by decide
theorem cert_e1211584857646 : check e1211584857646 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584857826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211584857826 : Closed e1211584857826 ∧ code e1211584857826 = 5609631368930 := by decide
theorem cert_e1211584857826 : check e1211584857826 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e1211584857838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211584857838 : Closed e1211584857838 ∧ code e1211584857838 = 5609631368942 := by decide
theorem cert_e1211584857838 : check e1211584857838 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584857994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211584857994 : Closed e1211584857994 ∧ code e1211584857994 = 5609631369098 := by decide
theorem cert_e1211584857994 : check e1211584857994 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e1211584858018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211584858018 : Closed e1211584858018 ∧ code e1211584858018 = 5609631369122 := by decide
theorem cert_e1211584858018 : check e1211584858018 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e1211584858030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211584858030 : Closed e1211584858030 ∧ code e1211584858030 = 5609631369134 := by decide
theorem cert_e1211584858030 : check e1211584858030 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584858042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211584858042 : Closed e1211584858042 ∧ code e1211584858042 = 5609631369146 := by decide
def e1211584859502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211584859502 : Closed e1211584859502 ∧ code e1211584859502 = 5609631370606 := by decide
theorem cert_e1211584859502 : check e1211584859502 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584859510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211584859510 : Closed e1211584859510 ∧ code e1211584859510 = 5609631370614 := by decide
theorem cert_e1211584859510 : check e1211584859510 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584859566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211584859566 : Closed e1211584859566 ∧ code e1211584859566 = 5609631370670 := by decide
theorem cert_e1211584859566 : check e1211584859566 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584859578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211584859578 : Closed e1211584859578 ∧ code e1211584859578 = 5609631370682 := by decide
theorem cert_e1211584859578 : check e1211584859578 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584859606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211584859606 : Closed e1211584859606 ∧ code e1211584859606 = 5609631370710 := by decide
theorem cert_e1211584859606 : check e1211584859606 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584859610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211584859610 : Closed e1211584859610 ∧ code e1211584859610 = 5609631370714 := by decide
theorem cert_e1211584859610 : check e1211584859610 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584859822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211584859822 : Closed e1211584859822 ∧ code e1211584859822 = 5609631370926 := by decide
theorem cert_e1211584859822 : check e1211584859822 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584859834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211584859834 : Closed e1211584859834 ∧ code e1211584859834 = 5609631370938 := by decide
theorem cert_e1211584859834 : check e1211584859834 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e1211584859882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211584859882 : Closed e1211584859882 ∧ code e1211584859882 = 5609631370986 := by decide
private def t_e1211584859882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem cert_e1211584859882 : ¬ IsSelfInterpreter e1211584859882 :=
  wSource (t := t_e1211584859882) (replay_sound (ps := []) (t := e1211584859882) (by decide)) (by decide)
def e1211584859990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211584859990 : Closed e1211584859990 ∧ code e1211584859990 = 5609631371094 := by decide
theorem cert_e1211584859990 : check e1211584859990 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211584859994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211584859994 : Closed e1211584859994 ∧ code e1211584859994 = 5609631371098 := by decide
theorem cert_e1211584859994 : check e1211584859994 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211584860010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211584860010 : Closed e1211584860010 ∧ code e1211584860010 = 5609631371114 := by decide
private def t_e1211584860010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem cert_e1211584860010 : ¬ IsSelfInterpreter e1211584860010 :=
  wSource (t := t_e1211584860010) (replay_sound (ps := []) (t := e1211584860010) (by decide)) (by decide)
def e1211584860270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211584860270 : Closed e1211584860270 ∧ code e1211584860270 = 5609631371374 := by decide
theorem cert_e1211584860270 : check e1211584860270 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584860446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211584860446 : Closed e1211584860446 ∧ code e1211584860446 = 5609631371550 := by decide
theorem cert_e1211584860446 : check e1211584860446 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584860642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211584860642 : Closed e1211584860642 ∧ code e1211584860642 = 5609631371746 := by decide
theorem cert_e1211584860642 : check e1211584860642 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584860654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e1211584860654 : Closed e1211584860654 ∧ code e1211584860654 = 5609631371758 := by decide
theorem cert_e1211584860654 : check e1211584860654 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e1211584861038 : Closed e1211584861038 ∧ code e1211584861038 = 5609631372142 := by decide
theorem cert_e1211584861038 : check e1211584861038 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e1211584861046 : Closed e1211584861046 ∧ code e1211584861046 = 5609631372150 := by decide
theorem cert_e1211584861046 : check e1211584861046 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e1211584861102 : Closed e1211584861102 ∧ code e1211584861102 = 5609631372206 := by decide
theorem cert_e1211584861102 : check e1211584861102 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e1211584861114 : Closed e1211584861114 ∧ code e1211584861114 = 5609631372218 := by decide
theorem cert_e1211584861114 : check e1211584861114 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e1211584861142 : Closed e1211584861142 ∧ code e1211584861142 = 5609631372246 := by decide
theorem cert_e1211584861142 : check e1211584861142 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e1211584861146 : Closed e1211584861146 ∧ code e1211584861146 = 5609631372250 := by decide
theorem cert_e1211584861146 : check e1211584861146 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584861422 : Closed e1211584861422 ∧ code e1211584861422 = 5609631372526 := by decide
theorem cert_e1211584861422 : check e1211584861422 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584861430 : Closed e1211584861430 ∧ code e1211584861430 = 5609631372534 := by decide
theorem cert_e1211584861430 : check e1211584861430 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584861806 : Closed e1211584861806 ∧ code e1211584861806 = 5609631372910 := by decide
theorem cert_e1211584861806 : check e1211584861806 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584861818 : Closed e1211584861818 ∧ code e1211584861818 = 5609631372922 := by decide
theorem cert_e1211584861818 : check e1211584861818 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584861958 : Closed e1211584861958 ∧ code e1211584861958 = 5609631373062 := by decide
theorem cert_e1211584861958 : check e1211584861958 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584861982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e1211584861982 : Closed e1211584861982 ∧ code e1211584861982 = 5609631373086 := by decide
theorem cert_e1211584861982 : check e1211584861982 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584862006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584862006 : Closed e1211584862006 ∧ code e1211584862006 = 5609631373110 := by decide
theorem cert_e1211584862006 : check e1211584862006 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584862010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584862010 : Closed e1211584862010 ∧ code e1211584862010 = 5609631373114 := by decide
theorem cert_e1211584862010 : check e1211584862010 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584862638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e1211584862638 : Closed e1211584862638 ∧ code e1211584862638 = 5609631373742 := by decide
private def t_e1211584862638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem cert_e1211584862638 : ¬ IsSelfInterpreter e1211584862638 :=
  wSource (t := t_e1211584862638) (replay_sound (ps := []) (t := e1211584862638) (by decide)) (by decide)
def e1211584862650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e1211584862650 : Closed e1211584862650 ∧ code e1211584862650 = 5609631373754 := by decide
private def t_e1211584862650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem cert_e1211584862650 : ¬ IsSelfInterpreter e1211584862650 :=
  wSource (t := t_e1211584862650) (replay_sound (ps := []) (t := e1211584862650) (by decide)) (by decide)
def e1211584862698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e1211584862698 : Closed e1211584862698 ∧ code e1211584862698 = 5609631373802 := by decide
private def t_e1211584862698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem cert_e1211584862698 : ¬ IsSelfInterpreter e1211584862698 :=
  wSource (t := t_e1211584862698) (replay_sound (ps := []) (t := e1211584862698) (by decide)) (by decide)
def e1211584862830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e1211584862830 : Closed e1211584862830 ∧ code e1211584862830 = 5609631373934 := by decide
private def t_e1211584862830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem cert_e1211584862830 : ¬ IsSelfInterpreter e1211584862830 :=
  wSource (t := t_e1211584862830) (replay_sound (ps := []) (t := e1211584862830) (by decide)) (by decide)
def e1211584862842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e1211584862842 : Closed e1211584862842 ∧ code e1211584862842 = 5609631373946 := by decide
private def t_e1211584862842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem cert_e1211584862842 : ¬ IsSelfInterpreter e1211584862842 :=
  wSource (t := t_e1211584862842) (replay_sound (ps := []) (t := e1211584862842) (by decide)) (by decide)
def e1211584863130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211584863130 : Closed e1211584863130 ∧ code e1211584863130 = 5609631374234 := by decide
private def t_e1211584863130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem cert_e1211584863130 : ¬ IsSelfInterpreter e1211584863130 :=
  wSource (t := t_e1211584863130) (replay_sound (ps := []) (t := e1211584863130) (by decide)) (by decide)
def e1211584863258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211584863258 : Closed e1211584863258 ∧ code e1211584863258 = 5609631374362 := by decide
private def t_e1211584863258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem cert_e1211584863258 : ¬ IsSelfInterpreter e1211584863258 :=
  wSource (t := t_e1211584863258) (replay_sound (ps := []) (t := e1211584863258) (by decide)) (by decide)
def e1211584863302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211584863302 : Closed e1211584863302 ∧ code e1211584863302 = 5609631374406 := by decide
private def t_e1211584863302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem cert_e1211584863302 : ¬ IsSelfInterpreter e1211584863302 :=
  wSource (t := t_e1211584863302) (replay_sound (ps := []) (t := e1211584863302) (by decide)) (by decide)
def e1211584863330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211584863330 : Closed e1211584863330 ∧ code e1211584863330 = 5609631374434 := by decide
private def t_e1211584863330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem cert_e1211584863330 : ¬ IsSelfInterpreter e1211584863330 :=
  wSource (t := t_e1211584863330) (replay_sound (ps := []) (t := e1211584863330) (by decide)) (by decide)
def e1211584863342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211584863342 : Closed e1211584863342 ∧ code e1211584863342 = 5609631374446 := by decide
private def t_e1211584863342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem cert_e1211584863342 : ¬ IsSelfInterpreter e1211584863342 :=
  wSource (t := t_e1211584863342) (replay_sound (ps := []) (t := e1211584863342) (by decide)) (by decide)
def e1211584863354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211584863354 : Closed e1211584863354 ∧ code e1211584863354 = 5609631374458 := by decide
private def t_e1211584863354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem cert_e1211584863354 : ¬ IsSelfInterpreter e1211584863354 :=
  wSource (t := t_e1211584863354) (replay_sound (ps := []) (t := e1211584863354) (by decide)) (by decide)
def e1211584863446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211584863446 : Closed e1211584863446 ∧ code e1211584863446 = 5609631374550 := by decide
private def t_e1211584863446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1211584863446 : ¬ IsSelfInterpreter e1211584863446 :=
  wSource (t := t_e1211584863446) (replay_sound (ps := []) (t := e1211584863446) (by decide)) (by decide)
def e1211584863450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211584863450 : Closed e1211584863450 ∧ code e1211584863450 = 5609631374554 := by decide
private def t_e1211584863450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem cert_e1211584863450 : ¬ IsSelfInterpreter e1211584863450 :=
  wSource (t := t_e1211584863450) (replay_sound (ps := []) (t := e1211584863450) (by decide)) (by decide)
def e1211584863466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211584863466 : Closed e1211584863466 ∧ code e1211584863466 = 5609631374570 := by decide
private def t_e1211584863466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem cert_e1211584863466 : ¬ IsSelfInterpreter e1211584863466 :=
  wSource (t := t_e1211584863466) (replay_sound (ps := []) (t := e1211584863466) (by decide)) (by decide)
def e1211584863494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584863494 : Closed e1211584863494 ∧ code e1211584863494 = 5609631374598 := by decide
private def t_e1211584863494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem cert_e1211584863494 : ¬ IsSelfInterpreter e1211584863494 :=
  wSource (t := t_e1211584863494) (replay_sound (ps := []) (t := e1211584863494) (by decide)) (by decide)
def e1211584863518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211584863518 : Closed e1211584863518 ∧ code e1211584863518 = 5609631374622 := by decide
private def t_e1211584863518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem cert_e1211584863518 : ¬ IsSelfInterpreter e1211584863518 :=
  wSource (t := t_e1211584863518) (replay_sound (ps := []) (t := e1211584863518) (by decide)) (by decide)
def e1211584863542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584863542 : Closed e1211584863542 ∧ code e1211584863542 = 5609631374646 := by decide
private def t_e1211584863542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211584863542 : ¬ IsSelfInterpreter e1211584863542 :=
  wSource (t := t_e1211584863542) (replay_sound (ps := []) (t := e1211584863542) (by decide)) (by decide)
def e1211584863546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584863546 : Closed e1211584863546 ∧ code e1211584863546 = 5609631374650 := by decide
private def t_e1211584863546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211584863546 : ¬ IsSelfInterpreter e1211584863546 :=
  wSource (t := t_e1211584863546) (replay_sound (ps := []) (t := e1211584863546) (by decide)) (by decide)
def e1211584863642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211584863642 : Closed e1211584863642 ∧ code e1211584863642 = 5609631374746 := by decide
private def t_e1211584863642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e1211584863642 : ¬ IsSelfInterpreter e1211584863642 :=
  wSource (t := t_e1211584863642) (replay_sound (ps := []) (t := e1211584863642) (by decide)) (by decide)
def e1211584863686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211584863686 : Closed e1211584863686 ∧ code e1211584863686 = 5609631374790 := by decide
private def t_e1211584863686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem cert_e1211584863686 : ¬ IsSelfInterpreter e1211584863686 :=
  wSource (t := t_e1211584863686) (replay_sound (ps := []) (t := e1211584863686) (by decide)) (by decide)
def e1211584864470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e1211584864470 : Closed e1211584864470 ∧ code e1211584864470 = 5609631375574 := by decide
theorem cert_e1211584864470 : check e1211584864470 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584864474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e1211584864474 : Closed e1211584864474 ∧ code e1211584864474 = 5609631375578 := by decide
theorem cert_e1211584864474 : check e1211584864474 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584864822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211584864822 : Closed e1211584864822 ∧ code e1211584864822 = 5609631375926 := by decide
theorem cert_e1211584864822 : check e1211584864822 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584864826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211584864826 : Closed e1211584864826 ∧ code e1211584864826 = 5609631375930 := by decide
theorem cert_e1211584864826 : check e1211584864826 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584864910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211584864910 : Closed e1211584864910 ∧ code e1211584864910 = 5609631376014 := by decide
theorem cert_e1211584864910 : check e1211584864910 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584864966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211584864966 : Closed e1211584864966 ∧ code e1211584864966 = 5609631376070 := by decide
theorem cert_e1211584864966 : check e1211584864966 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584865046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211584865046 : Closed e1211584865046 ∧ code e1211584865046 = 5609631376150 := by decide
theorem cert_e1211584865046 : check e1211584865046 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584865122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211584865122 : Closed e1211584865122 ∧ code e1211584865122 = 5609631376226 := by decide
theorem cert_e1211584865122 : check e1211584865122 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584865134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e1211584865134 : Closed e1211584865134 ∧ code e1211584865134 = 5609631376238 := by decide
theorem cert_e1211584865134 : check e1211584865134 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584865142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e1211584865142 : Closed e1211584865142 ∧ code e1211584865142 = 5609631376246 := by decide
theorem cert_e1211584865142 : check e1211584865142 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584865162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211584865162 : Closed e1211584865162 ∧ code e1211584865162 = 5609631376266 := by decide
theorem cert_e1211584865162 : check e1211584865162 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e1211584865186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211584865186 : Closed e1211584865186 ∧ code e1211584865186 = 5609631376290 := by decide
theorem cert_e1211584865186 : check e1211584865186 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e1211584865198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211584865198 : Closed e1211584865198 ∧ code e1211584865198 = 5609631376302 := by decide
theorem cert_e1211584865198 : check e1211584865198 [[],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584865210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211584865210 : Closed e1211584865210 ∧ code e1211584865210 = 5609631376314 := by decide
def e1211584865238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211584865238 : Closed e1211584865238 ∧ code e1211584865238 = 5609631376342 := by decide
theorem cert_e1211584865238 : check e1211584865238 [[],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1211584865242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211584865242 : Closed e1211584865242 ∧ code e1211584865242 = 5609631376346 := by decide
def e1211584865974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211584865974 : Closed e1211584865974 ∧ code e1211584865974 = 5609631377078 := by decide
theorem cert_e1211584865974 : check e1211584865974 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211584866006 : Closed e1211584866006 ∧ code e1211584866006 = 5609631377110 := by decide
theorem cert_e1211584866006 : check e1211584866006 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211584866010 : Closed e1211584866010 ∧ code e1211584866010 = 5609631377114 := by decide
theorem cert_e1211584866010 : check e1211584866010 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e1211584866134 : Closed e1211584866134 ∧ code e1211584866134 = 5609631377238 := by decide
theorem cert_e1211584866134 : check e1211584866134 [[],[],[],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211584866138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e1211584866138 : Closed e1211584866138 ∧ code e1211584866138 = 5609631377242 := by decide
theorem cert_e1211584866138 : check e1211584866138 [[],[],[],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e1211584866154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e1211584866154 : Closed e1211584866154 ∧ code e1211584866154 = 5609631377258 := by decide
private def t_e1211584866154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem cert_e1211584866154 : ¬ IsSelfInterpreter e1211584866154 :=
  wSource (t := t_e1211584866154) (replay_sound (ps := []) (t := e1211584866154) (by decide)) (by decide)
def e1211584866358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211584866358 : Closed e1211584866358 ∧ code e1211584866358 = 5609631377462 := by decide
theorem cert_e1211584866358 : check e1211584866358 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584866446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211584866446 : Closed e1211584866446 ∧ code e1211584866446 = 5609631377550 := by decide
theorem cert_e1211584866446 : check e1211584866446 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584866530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211584866530 : Closed e1211584866530 ∧ code e1211584866530 = 5609631377634 := by decide
theorem cert_e1211584866530 : check e1211584866530 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584866542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211584866542 : Closed e1211584866542 ∧ code e1211584866542 = 5609631377646 := by decide
theorem cert_e1211584866542 : check e1211584866542 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211584866550 : Closed e1211584866550 ∧ code e1211584866550 = 5609631377654 := by decide
theorem cert_e1211584866550 : check e1211584866550 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211584866742 : Closed e1211584866742 ∧ code e1211584866742 = 5609631377846 := by decide
theorem cert_e1211584866742 : check e1211584866742 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211584866774 : Closed e1211584866774 ∧ code e1211584866774 = 5609631377878 := by decide
theorem cert_e1211584866774 : check e1211584866774 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211584866778 : Closed e1211584866778 ∧ code e1211584866778 = 5609631377882 := by decide
theorem cert_e1211584866778 : check e1211584866778 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584866934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211584866934 : Closed e1211584866934 ∧ code e1211584866934 = 5609631378038 := by decide
theorem cert_e1211584866934 : check e1211584866934 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584867078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584867078 : Closed e1211584867078 ∧ code e1211584867078 = 5609631378182 := by decide
theorem cert_e1211584867078 : check e1211584867078 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e1211584867102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211584867102 : Closed e1211584867102 ∧ code e1211584867102 = 5609631378206 := by decide
theorem cert_e1211584867102 : check e1211584867102 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584867126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584867126 : Closed e1211584867126 ∧ code e1211584867126 = 5609631378230 := by decide
theorem cert_e1211584867126 : check e1211584867126 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584867130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584867130 : Closed e1211584867130 ∧ code e1211584867130 = 5609631378234 := by decide
theorem cert_e1211584867130 : check e1211584867130 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584867214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211584867214 : Closed e1211584867214 ∧ code e1211584867214 = 5609631378318 := by decide
theorem cert_e1211584867214 : check e1211584867214 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e1211584867354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211584867354 : Closed e1211584867354 ∧ code e1211584867354 = 5609631378458 := by decide
private def t_e1211584867354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem cert_e1211584867354 : ¬ IsSelfInterpreter e1211584867354 :=
  wSource (t := t_e1211584867354) (replay_sound (ps := []) (t := e1211584867354) (by decide)) (by decide)
def e1211584867398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211584867398 : Closed e1211584867398 ∧ code e1211584867398 = 5609631378502 := by decide
private def t_e1211584867398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 1))))))))
theorem cert_e1211584867398 : ¬ IsSelfInterpreter e1211584867398 :=
  wSource (t := t_e1211584867398) (replay_sound (ps := []) (t := e1211584867398) (by decide)) (by decide)
def e1211584867426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211584867426 : Closed e1211584867426 ∧ code e1211584867426 = 5609631378530 := by decide
private def t_e1211584867426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 0))))))))
theorem cert_e1211584867426 : ¬ IsSelfInterpreter e1211584867426 :=
  wSource (t := t_e1211584867426) (replay_sound (ps := []) (t := e1211584867426) (by decide)) (by decide)
def e1211584867438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211584867438 : Closed e1211584867438 ∧ code e1211584867438 = 5609631378542 := by decide
private def t_e1211584867438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem cert_e1211584867438 : ¬ IsSelfInterpreter e1211584867438 :=
  wSource (t := t_e1211584867438) (replay_sound (ps := []) (t := e1211584867438) (by decide)) (by decide)
def e1211584867450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211584867450 : Closed e1211584867450 ∧ code e1211584867450 = 5609631378554 := by decide
private def t_e1211584867450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem cert_e1211584867450 : ¬ IsSelfInterpreter e1211584867450 :=
  wSource (t := t_e1211584867450) (replay_sound (ps := []) (t := e1211584867450) (by decide)) (by decide)
def e1211584867542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211584867542 : Closed e1211584867542 ∧ code e1211584867542 = 5609631378646 := by decide
private def t_e1211584867542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e1211584867542 : ¬ IsSelfInterpreter e1211584867542 :=
  wSource (t := t_e1211584867542) (replay_sound (ps := []) (t := e1211584867542) (by decide)) (by decide)
def e1211584867546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211584867546 : Closed e1211584867546 ∧ code e1211584867546 = 5609631378650 := by decide
private def t_e1211584867546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem cert_e1211584867546 : ¬ IsSelfInterpreter e1211584867546 :=
  wSource (t := t_e1211584867546) (replay_sound (ps := []) (t := e1211584867546) (by decide)) (by decide)
def e1211584867562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211584867562 : Closed e1211584867562 ∧ code e1211584867562 = 5609631378666 := by decide
private def t_e1211584867562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem cert_e1211584867562 : ¬ IsSelfInterpreter e1211584867562 :=
  wSource (t := t_e1211584867562) (replay_sound (ps := []) (t := e1211584867562) (by decide)) (by decide)
def e1211584867590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211584867590 : Closed e1211584867590 ∧ code e1211584867590 = 5609631378694 := by decide
private def t_e1211584867590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem cert_e1211584867590 : ¬ IsSelfInterpreter e1211584867590 :=
  wSource (t := t_e1211584867590) (replay_sound (ps := []) (t := e1211584867590) (by decide)) (by decide)
def e1211584867614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211584867614 : Closed e1211584867614 ∧ code e1211584867614 = 5609631378718 := by decide
private def t_e1211584867614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem cert_e1211584867614 : ¬ IsSelfInterpreter e1211584867614 :=
  wSource (t := t_e1211584867614) (replay_sound (ps := []) (t := e1211584867614) (by decide)) (by decide)
def e1211584867638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211584867638 : Closed e1211584867638 ∧ code e1211584867638 = 5609631378742 := by decide
private def t_e1211584867638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e1211584867638 : ¬ IsSelfInterpreter e1211584867638 :=
  wSource (t := t_e1211584867638) (replay_sound (ps := []) (t := e1211584867638) (by decide)) (by decide)
def e1211584867642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211584867642 : Closed e1211584867642 ∧ code e1211584867642 = 5609631378746 := by decide
private def t_e1211584867642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e1211584867642 : ¬ IsSelfInterpreter e1211584867642 :=
  wSource (t := t_e1211584867642) (replay_sound (ps := []) (t := e1211584867642) (by decide)) (by decide)
def e1211584867738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211584867738 : Closed e1211584867738 ∧ code e1211584867738 = 5609631378842 := by decide
private def t_e1211584867738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e1211584867738 : ¬ IsSelfInterpreter e1211584867738 :=
  wSource (t := t_e1211584867738) (replay_sound (ps := []) (t := e1211584867738) (by decide)) (by decide)
def e1211584867782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211584867782 : Closed e1211584867782 ∧ code e1211584867782 = 5609631378886 := by decide
private def t_e1211584867782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem cert_e1211584867782 : ¬ IsSelfInterpreter e1211584867782 :=
  wSource (t := t_e1211584867782) (replay_sound (ps := []) (t := e1211584867782) (by decide)) (by decide)
def e1211584867894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211584867894 : Closed e1211584867894 ∧ code e1211584867894 = 5609631378998 := by decide
private def t_e1211584867894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem cert_e1211584867894 : ¬ IsSelfInterpreter e1211584867894 :=
  wSource (t := t_e1211584867894) (replay_sound (ps := []) (t := e1211584867894) (by decide)) (by decide)
def e1211584867898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211584867898 : Closed e1211584867898 ∧ code e1211584867898 = 5609631379002 := by decide
private def t_e1211584867898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem cert_e1211584867898 : ¬ IsSelfInterpreter e1211584867898 :=
  wSource (t := t_e1211584867898) (replay_sound (ps := []) (t := e1211584867898) (by decide)) (by decide)
def e1211584867982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211584867982 : Closed e1211584867982 ∧ code e1211584867982 = 5609631379086 := by decide
private def t_e1211584867982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem cert_e1211584867982 : ¬ IsSelfInterpreter e1211584867982 :=
  wSource (t := t_e1211584867982) (replay_sound (ps := []) (t := e1211584867982) (by decide)) (by decide)
def e1211584868038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211584868038 : Closed e1211584868038 ∧ code e1211584868038 = 5609631379142 := by decide
private def t_e1211584868038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem cert_e1211584868038 : ¬ IsSelfInterpreter e1211584868038 :=
  wSource (t := t_e1211584868038) (replay_sound (ps := []) (t := e1211584868038) (by decide)) (by decide)
def e1211584873454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 2)))))))
theorem wire_e1211584873454 : Closed e1211584873454 ∧ code e1211584873454 = 5609631384558 := by decide
theorem cert_e1211584873454 : check e1211584873454 [[],[],[],[]] .sourceHead = true := by decide
def e1211584873462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 1)))))))
theorem wire_e1211584873462 : Closed e1211584873462 ∧ code e1211584873462 = 5609631384566 := by decide
theorem cert_e1211584873462 : check e1211584873462 [[],[],[],[]] .sourceHead = true := by decide
def e1211584875758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584875758 : Closed e1211584875758 ∧ code e1211584875758 = 5609631386862 := by decide
theorem cert_e1211584875758 : check e1211584875758 [[],[],[],[]] .sourceHead = true := by decide
def e1211584875766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584875766 : Closed e1211584875766 ∧ code e1211584875766 = 5609631386870 := by decide
theorem cert_e1211584875766 : check e1211584875766 [[],[],[],[]] .sourceHead = true := by decide
def e1211584876318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 3))))))))
theorem wire_e1211584876318 : Closed e1211584876318 ∧ code e1211584876318 = 5609631387422 := by decide
theorem cert_e1211584876318 : check e1211584876318 [[],[],[],[]] .sourceHead = true := by decide
def e1211584876430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 2))))))))
theorem wire_e1211584876430 : Closed e1211584876430 ∧ code e1211584876430 = 5609631387534 := by decide
theorem cert_e1211584876430 : check e1211584876430 [[],[],[],[]] .sourceHead = true := by decide
def e1211584880174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e1211584880174 : Closed e1211584880174 ∧ code e1211584880174 = 5609631391278 := by decide
theorem cert_e1211584880174 : check e1211584880174 [[],[],[],[]] .sourceHead = true := by decide
def e1211584880366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e1211584880366 : Closed e1211584880366 ∧ code e1211584880366 = 5609631391470 := by decide
theorem cert_e1211584880366 : check e1211584880366 [[],[],[],[]] .sourceHead = true := by decide
def e1211584880374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e1211584880374 : Closed e1211584880374 ∧ code e1211584880374 = 5609631391478 := by decide
theorem cert_e1211584880374 : check e1211584880374 [[],[],[],[]] .sourceHead = true := by decide
def e1211584880406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e1211584880406 : Closed e1211584880406 ∧ code e1211584880406 = 5609631391510 := by decide
theorem cert_e1211584880406 : check e1211584880406 [[],[],[],[]] .sourceHead = true := by decide
def e1211584880502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e1211584880502 : Closed e1211584880502 ∧ code e1211584880502 = 5609631391606 := by decide
theorem cert_e1211584880502 : check e1211584880502 [[],[],[],[]] .sourceHead = true := by decide
def e1211584882462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211584882462 : Closed e1211584882462 ∧ code e1211584882462 = 5609631393566 := by decide
theorem cert_e1211584882462 : check e1211584882462 [[],[],[],[]] .sourceHead = true := by decide
def e1211584882574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211584882574 : Closed e1211584882574 ∧ code e1211584882574 = 5609631393678 := by decide
theorem cert_e1211584882574 : check e1211584882574 [[],[],[],[]] .sourceHead = true := by decide
def e1211584886846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 4)))))))))
theorem wire_e1211584886846 : Closed e1211584886846 ∧ code e1211584886846 = 5609631397950 := by decide
theorem cert_e1211584886846 : check e1211584886846 [[],[],[],[]] .sourceHead = true := by decide
def e1211584887266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211584887266 : Closed e1211584887266 ∧ code e1211584887266 = 5609631398370 := by decide
theorem cert_e1211584887266 : check e1211584887266 [[],[],[],[]] .sourceHead = true := by decide
def e1211584887278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e1211584887278 : Closed e1211584887278 ∧ code e1211584887278 = 5609631398382 := by decide
theorem cert_e1211584887278 : check e1211584887278 [[],[],[],[]] .sourceHead = true := by decide
def e1211584887838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 3)))))))))
theorem wire_e1211584887838 : Closed e1211584887838 ∧ code e1211584887838 = 5609631398942 := by decide
theorem cert_e1211584887838 : check e1211584887838 [[],[],[],[]] .sourceHead = true := by decide
def e1211584888034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211584888034 : Closed e1211584888034 ∧ code e1211584888034 = 5609631399138 := by decide
theorem cert_e1211584888034 : check e1211584888034 [[],[],[],[]] .sourceHead = true := by decide
def e1211584888046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584888046 : Closed e1211584888046 ∧ code e1211584888046 = 5609631399150 := by decide
theorem cert_e1211584888046 : check e1211584888046 [[],[],[],[]] .sourceHead = true := by decide
def e1211584888054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584888054 : Closed e1211584888054 ∧ code e1211584888054 = 5609631399158 := by decide
theorem cert_e1211584888054 : check e1211584888054 [[],[],[],[]] .sourceHead = true := by decide
def e1211584895854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e1211584895854 : Closed e1211584895854 ∧ code e1211584895854 = 5609631406958 := by decide
theorem cert_e1211584895854 : check e1211584895854 [[],[],[],[]] .sourceHead = true := by decide
def e1211584895862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e1211584895862 : Closed e1211584895862 ∧ code e1211584895862 = 5609631406966 := by decide
theorem cert_e1211584895862 : check e1211584895862 [[],[],[],[]] .sourceHead = true := by decide
def e1211584895926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e1211584895926 : Closed e1211584895926 ∧ code e1211584895926 = 5609631407030 := by decide
theorem cert_e1211584895926 : check e1211584895926 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e1211584896366 : Closed e1211584896366 ∧ code e1211584896366 = 5609631407470 := by decide
theorem cert_e1211584896366 : check e1211584896366 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e1211584896374 : Closed e1211584896374 ∧ code e1211584896374 = 5609631407478 := by decide
theorem cert_e1211584896374 : check e1211584896374 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e1211584896430 : Closed e1211584896430 ∧ code e1211584896430 = 5609631407534 := by decide
theorem cert_e1211584896430 : check e1211584896430 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e1211584896442 : Closed e1211584896442 ∧ code e1211584896442 = 5609631407546 := by decide
theorem cert_e1211584896442 : check e1211584896442 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e1211584896470 : Closed e1211584896470 ∧ code e1211584896470 = 5609631407574 := by decide
theorem cert_e1211584896470 : check e1211584896470 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e1211584896474 : Closed e1211584896474 ∧ code e1211584896474 = 5609631407578 := by decide
theorem cert_e1211584896474 : check e1211584896474 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e1211584896694 : Closed e1211584896694 ∧ code e1211584896694 = 5609631407798 := by decide
theorem cert_e1211584896694 : check e1211584896694 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e1211584896726 : Closed e1211584896726 ∧ code e1211584896726 = 5609631407830 := by decide
theorem cert_e1211584896726 : check e1211584896726 [[],[],[],[]] .sourceHead = true := by decide
def e1211584896730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e1211584896730 : Closed e1211584896730 ∧ code e1211584896730 = 5609631407834 := by decide
theorem cert_e1211584896730 : check e1211584896730 [[],[],[],[]] .sourceHead = true := by decide
def e1211584898926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e1211584898926 : Closed e1211584898926 ∧ code e1211584898926 = 5609631410030 := by decide
theorem cert_e1211584898926 : check e1211584898926 [[],[],[],[]] .sourceHead = true := by decide
def e1211584898934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e1211584898934 : Closed e1211584898934 ∧ code e1211584898934 = 5609631410038 := by decide
theorem cert_e1211584898934 : check e1211584898934 [[],[],[],[]] .sourceHead = true := by decide
def e1211584898998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e1211584898998 : Closed e1211584898998 ∧ code e1211584898998 = 5609631410102 := by decide
theorem cert_e1211584898998 : check e1211584898998 [[],[],[],[]] .sourceHead = true := by decide
def e1211584900334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211584900334 : Closed e1211584900334 ∧ code e1211584900334 = 5609631411438 := by decide
theorem cert_e1211584900334 : check e1211584900334 [[],[],[],[]] .sourceHead = true := by decide
def e1211584900342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211584900342 : Closed e1211584900342 ∧ code e1211584900342 = 5609631411446 := by decide
theorem cert_e1211584900342 : check e1211584900342 [[],[],[],[]] .sourceHead = true := by decide
def e1211584900726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e1211584900726 : Closed e1211584900726 ∧ code e1211584900726 = 5609631411830 := by decide
theorem cert_e1211584900726 : check e1211584900726 [[],[],[],[]] .sourceHead = true := by decide
def e1211584901230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2)))))))
theorem wire_e1211584901230 : Closed e1211584901230 ∧ code e1211584901230 = 5609631412334 := by decide
theorem cert_e1211584901230 : check e1211584901230 [[],[],[],[]] .sourceHead = true := by decide
def e1211584901406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3))))))))
theorem wire_e1211584901406 : Closed e1211584901406 ∧ code e1211584901406 = 5609631412510 := by decide
theorem cert_e1211584901406 : check e1211584901406 [[],[],[],[]] .sourceHead = true := by decide
def e1211584901602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0))))))))
theorem wire_e1211584901602 : Closed e1211584901602 ∧ code e1211584901602 = 5609631412706 := by decide
theorem cert_e1211584901602 : check e1211584901602 [[],[],[],[]] .sourceHead = true := by decide
def e1211584901614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211584901614 : Closed e1211584901614 ∧ code e1211584901614 = 5609631412718 := by decide
theorem cert_e1211584901614 : check e1211584901614 [[],[],[],[]] .sourceHead = true := by decide
def e1211584901998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211584901998 : Closed e1211584901998 ∧ code e1211584901998 = 5609631413102 := by decide
theorem cert_e1211584901998 : check e1211584901998 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e1211584902006 : Closed e1211584902006 ∧ code e1211584902006 = 5609631413110 := by decide
theorem cert_e1211584902006 : check e1211584902006 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211584902062 : Closed e1211584902062 ∧ code e1211584902062 = 5609631413166 := by decide
theorem cert_e1211584902062 : check e1211584902062 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e1211584902074 : Closed e1211584902074 ∧ code e1211584902074 = 5609631413178 := by decide
theorem cert_e1211584902074 : check e1211584902074 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e1211584902102 : Closed e1211584902102 ∧ code e1211584902102 = 5609631413206 := by decide
theorem cert_e1211584902102 : check e1211584902102 [[],[],[],[]] .sourceHead = true := by decide
def e1211584902106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e1211584902106 : Closed e1211584902106 ∧ code e1211584902106 = 5609631413210 := by decide
theorem cert_e1211584902106 : check e1211584902106 [[],[],[],[]] .sourceHead = true := by decide
end Blc.Floor42
