import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211182305166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1211182305166 : Closed e1211182305166 ∧ code e1211182305166 = 5609228816270 := by decide
theorem cert_e1211182305166 : check e1211182305166 [[],[]] .smaller = true := by decide
def e1211182305178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182305178 : Closed e1211182305178 ∧ code e1211182305178 = 5609228816282 := by decide
theorem cert_e1211182305178 : check e1211182305178 [[],[]] .smaller = true := by decide
def e1211182305222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.lam (.var 1))))))))))
theorem wire_e1211182305222 : Closed e1211182305222 ∧ code e1211182305222 = 5609228816326 := by decide
theorem cert_e1211182305222 : check e1211182305222 [[],[]] .three = true := by decide
def e1211182309854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1211182309854 : Closed e1211182309854 ∧ code e1211182309854 = 5609228820958 := by decide
theorem cert_e1211182309854 : check e1211182309854 [[],[]] .smaller = true := by decide
def e1211182309878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1211182309878 : Closed e1211182309878 ∧ code e1211182309878 = 5609228820982 := by decide
theorem cert_e1211182309878 : check e1211182309878 [[],[]] .smaller = true := by decide
def e1211182310830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1211182310830 : Closed e1211182310830 ∧ code e1211182310830 = 5609228821934 := by decide
theorem cert_e1211182310830 : check e1211182310830 [[],[]] .smaller = true := by decide
def e1211182310842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1211182310842 : Closed e1211182310842 ∧ code e1211182310842 = 5609228821946 := by decide
theorem cert_e1211182310842 : check e1211182310842 [[],[]] .smaller = true := by decide
def e1211182310890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1211182310890 : Closed e1211182310890 ∧ code e1211182310890 = 5609228821994 := by decide
theorem cert_e1211182310890 : check e1211182310890 [[],[]] .smaller = true := by decide
def e1211182310974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211182310974 : Closed e1211182310974 ∧ code e1211182310974 = 5609228822078 := by decide
theorem cert_e1211182310974 : check e1211182310974 [[],[]] .smaller = true := by decide
def e1211182311022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211182311022 : Closed e1211182311022 ∧ code e1211182311022 = 5609228822126 := by decide
theorem cert_e1211182311022 : check e1211182311022 [[],[]] .smaller = true := by decide
def e1211182311034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211182311034 : Closed e1211182311034 ∧ code e1211182311034 = 5609228822138 := by decide
theorem cert_e1211182311034 : check e1211182311034 [[],[]] .smaller = true := by decide
def e1211182311322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182311322 : Closed e1211182311322 ∧ code e1211182311322 = 5609228822426 := by decide
theorem cert_e1211182311322 : check e1211182311322 [[],[]] .smaller = true := by decide
def e1211182311358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 4)))))))))
theorem wire_e1211182311358 : Closed e1211182311358 ∧ code e1211182311358 = 5609228822462 := by decide
theorem cert_e1211182311358 : check e1211182311358 [[],[]] .three = true := by decide
def e1211182311366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211182311366 : Closed e1211182311366 ∧ code e1211182311366 = 5609228822470 := by decide
theorem cert_e1211182311366 : check e1211182311366 [[],[]] .smaller = true := by decide
def e1211182311406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 4) (.var 2)))))))))
theorem wire_e1211182311406 : Closed e1211182311406 ∧ code e1211182311406 = 5609228822510 := by decide
theorem cert_e1211182311406 : check e1211182311406 [[],[]] .three = true := by decide
def e1211182313710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182313710 : Closed e1211182313710 ∧ code e1211182313710 = 5609228824814 := by decide
theorem cert_e1211182313710 : check e1211182313710 [[],[]] .smaller = true := by decide
def e1211182313718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182313718 : Closed e1211182313718 ∧ code e1211182313718 = 5609228824822 := by decide
theorem cert_e1211182313718 : check e1211182313718 [[],[]] .smaller = true := by decide
def e1211182314198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211182314198 : Closed e1211182314198 ∧ code e1211182314198 = 5609228825302 := by decide
theorem cert_e1211182314198 : check e1211182314198 [[],[]] .smaller = true := by decide
def e1211182314202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211182314202 : Closed e1211182314202 ∧ code e1211182314202 = 5609228825306 := by decide
theorem cert_e1211182314202 : check e1211182314202 [[],[]] .smaller = true := by decide
def e1211182314218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211182314218 : Closed e1211182314218 ∧ code e1211182314218 = 5609228825322 := by decide
theorem cert_e1211182314218 : check e1211182314218 [[],[]] .smaller = true := by decide
def e1211182314270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211182314270 : Closed e1211182314270 ∧ code e1211182314270 = 5609228825374 := by decide
theorem cert_e1211182314270 : check e1211182314270 [[],[]] .smaller = true := by decide
def e1211182314294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182314294 : Closed e1211182314294 ∧ code e1211182314294 = 5609228825398 := by decide
theorem cert_e1211182314294 : check e1211182314294 [[],[]] .smaller = true := by decide
def e1211182314298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182314298 : Closed e1211182314298 ∧ code e1211182314298 = 5609228825402 := by decide
theorem cert_e1211182314298 : check e1211182314298 [[],[]] .smaller = true := by decide
def e1211182314394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182314394 : Closed e1211182314394 ∧ code e1211182314394 = 5609228825498 := by decide
theorem cert_e1211182314394 : check e1211182314394 [[],[]] .smaller = true := by decide
def e1211182314430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 4)))))))))
theorem wire_e1211182314430 : Closed e1211182314430 ∧ code e1211182314430 = 5609228825534 := by decide
theorem cert_e1211182314430 : check e1211182314430 [[],[]] .three = true := by decide
def e1211182314438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211182314438 : Closed e1211182314438 ∧ code e1211182314438 = 5609228825542 := by decide
theorem cert_e1211182314438 : check e1211182314438 [[],[]] .smaller = true := by decide
def e1211182314462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211182314462 : Closed e1211182314462 ∧ code e1211182314462 = 5609228825566 := by decide
theorem cert_e1211182314462 : check e1211182314462 [[],[]] .smaller = true := by decide
def e1211182314478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211182314478 : Closed e1211182314478 ∧ code e1211182314478 = 5609228825582 := by decide
theorem cert_e1211182314478 : check e1211182314478 [[],[]] .smaller = true := by decide
def e1211182314486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 4) (.var 1)))))))))
theorem wire_e1211182314486 : Closed e1211182314486 ∧ code e1211182314486 = 5609228825590 := by decide
theorem cert_e1211182314486 : check e1211182314486 [[],[]] .three = true := by decide
def e1211182315638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182315638 : Closed e1211182315638 ∧ code e1211182315638 = 5609228826742 := by decide
theorem cert_e1211182315638 : check e1211182315638 [[],[]] .smaller = true := by decide
def e1211182315882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e1211182315882 : Closed e1211182315882 ∧ code e1211182315882 = 5609228826986 := by decide
theorem cert_e1211182315882 : check e1211182315882 [[],[]] .smaller = true := by decide
def e1211182315918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211182315918 : Closed e1211182315918 ∧ code e1211182315918 = 5609228827022 := by decide
theorem cert_e1211182315918 : check e1211182315918 [[],[]] .smaller = true := by decide
def e1211182315930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182315930 : Closed e1211182315930 ∧ code e1211182315930 = 5609228827034 := by decide
theorem cert_e1211182315930 : check e1211182315930 [[],[]] .smaller = true := by decide
def e1211182315974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211182315974 : Closed e1211182315974 ∧ code e1211182315974 = 5609228827078 := by decide
theorem cert_e1211182315974 : check e1211182315974 [[],[]] .smaller = true := by decide
def e1211182316014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211182316014 : Closed e1211182316014 ∧ code e1211182316014 = 5609228827118 := by decide
theorem cert_e1211182316014 : check e1211182316014 [[],[]] .smaller = true := by decide
def e1211182316742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211182316742 : Closed e1211182316742 ∧ code e1211182316742 = 5609228827846 := by decide
theorem cert_e1211182316742 : check e1211182316742 [[],[]] .three = true := by decide
def e1211182316782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182316782 : Closed e1211182316782 ∧ code e1211182316782 = 5609228827886 := by decide
theorem cert_e1211182316782 : check e1211182316782 [[],[]] .three = true := by decide
def e1211182316790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182316790 : Closed e1211182316790 ∧ code e1211182316790 = 5609228827894 := by decide
theorem cert_e1211182316790 : check e1211182316790 [[],[]] .three = true := by decide
def e1211182319478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))))
theorem wire_e1211182319478 : Closed e1211182319478 ∧ code e1211182319478 = 5609228830582 := by decide
theorem cert_e1211182319478 : check e1211182319478 [[],[]] .smaller = true := by decide
def e1211182319542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))))
theorem wire_e1211182319542 : Closed e1211182319542 ∧ code e1211182319542 = 5609228830646 := by decide
theorem cert_e1211182319542 : check e1211182319542 [[],[]] .smaller = true := by decide
def e1211182319546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))))
theorem wire_e1211182319546 : Closed e1211182319546 ∧ code e1211182319546 = 5609228830650 := by decide
theorem cert_e1211182319546 : check e1211182319546 [[],[]] .smaller = true := by decide
def e1211182320862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182320862 : Closed e1211182320862 ∧ code e1211182320862 = 5609228831966 := by decide
theorem cert_e1211182320862 : check e1211182320862 [[],[]] .smaller = true := by decide
def e1211182320878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182320878 : Closed e1211182320878 ∧ code e1211182320878 = 5609228831982 := by decide
theorem cert_e1211182320878 : check e1211182320878 [[],[]] .smaller = true := by decide
def e1211182320886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182320886 : Closed e1211182320886 ∧ code e1211182320886 = 5609228831990 := by decide
theorem cert_e1211182320886 : check e1211182320886 [[],[]] .smaller = true := by decide
def e1211182320890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182320890 : Closed e1211182320890 ∧ code e1211182320890 = 5609228831994 := by decide
theorem cert_e1211182320890 : check e1211182320890 [[],[]] .smaller = true := by decide
def e1211182321262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182321262 : Closed e1211182321262 ∧ code e1211182321262 = 5609228832366 := by decide
theorem cert_e1211182321262 : check e1211182321262 [[],[]] .smaller = true := by decide
def e1211182321274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182321274 : Closed e1211182321274 ∧ code e1211182321274 = 5609228832378 := by decide
theorem cert_e1211182321274 : check e1211182321274 [[],[]] .smaller = true := by decide
def e1211182321462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182321462 : Closed e1211182321462 ∧ code e1211182321462 = 5609228832566 := by decide
theorem cert_e1211182321462 : check e1211182321462 [[],[]] .smaller = true := by decide
def e1211182321466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182321466 : Closed e1211182321466 ∧ code e1211182321466 = 5609228832570 := by decide
theorem cert_e1211182321466 : check e1211182321466 [[],[]] .smaller = true := by decide
def e1211182321562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182321562 : Closed e1211182321562 ∧ code e1211182321562 = 5609228832666 := by decide
theorem cert_e1211182321562 : check e1211182321562 [[],[]] .smaller = true := by decide
def e1211182323382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))))
theorem wire_e1211182323382 : Closed e1211182323382 ∧ code e1211182323382 = 5609228834486 := by decide
theorem cert_e1211182323382 : check e1211182323382 [[],[]] .smaller = true := by decide
def e1211182323414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))))
theorem wire_e1211182323414 : Closed e1211182323414 ∧ code e1211182323414 = 5609228834518 := by decide
theorem cert_e1211182323414 : check e1211182323414 [[],[]] .smaller = true := by decide
def e1211182323418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))))
theorem wire_e1211182323418 : Closed e1211182323418 ∧ code e1211182323418 = 5609228834522 := by decide
theorem cert_e1211182323418 : check e1211182323418 [[],[]] .smaller = true := by decide
def e1211182323542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e1211182323542 : Closed e1211182323542 ∧ code e1211182323542 = 5609228834646 := by decide
theorem cert_e1211182323542 : check e1211182323542 [[],[]] .smaller = true := by decide
def e1211182323546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e1211182323546 : Closed e1211182323546 ∧ code e1211182323546 = 5609228834650 := by decide
theorem cert_e1211182323546 : check e1211182323546 [[],[]] .smaller = true := by decide
def e1211182323562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e1211182323562 : Closed e1211182323562 ∧ code e1211182323562 = 5609228834666 := by decide
theorem cert_e1211182323562 : check e1211182323562 [[],[]] .smaller = true := by decide
def e1211182323934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e1211182323934 : Closed e1211182323934 ∧ code e1211182323934 = 5609228835038 := by decide
theorem cert_e1211182323934 : check e1211182323934 [[],[]] .smaller = true := by decide
def e1211182323950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e1211182323950 : Closed e1211182323950 ∧ code e1211182323950 = 5609228835054 := by decide
theorem cert_e1211182323950 : check e1211182323950 [[],[]] .smaller = true := by decide
def e1211182323958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e1211182323958 : Closed e1211182323958 ∧ code e1211182323958 = 5609228835062 := by decide
theorem cert_e1211182323958 : check e1211182323958 [[],[]] .smaller = true := by decide
def e1211182323962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e1211182323962 : Closed e1211182323962 ∧ code e1211182323962 = 5609228835066 := by decide
theorem cert_e1211182323962 : check e1211182323962 [[],[]] .smaller = true := by decide
def e1211182324150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e1211182324150 : Closed e1211182324150 ∧ code e1211182324150 = 5609228835254 := by decide
theorem cert_e1211182324150 : check e1211182324150 [[],[]] .smaller = true := by decide
def e1211182324182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e1211182324182 : Closed e1211182324182 ∧ code e1211182324182 = 5609228835286 := by decide
theorem cert_e1211182324182 : check e1211182324182 [[],[]] .smaller = true := by decide
def e1211182324186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e1211182324186 : Closed e1211182324186 ∧ code e1211182324186 = 5609228835290 := by decide
theorem cert_e1211182324186 : check e1211182324186 [[],[]] .smaller = true := by decide
def e1211182324286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e1211182324286 : Closed e1211182324286 ∧ code e1211182324286 = 5609228835390 := by decide
theorem cert_e1211182324286 : check e1211182324286 [[],[]] .smaller = true := by decide
def e1211182324342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182324342 : Closed e1211182324342 ∧ code e1211182324342 = 5609228835446 := by decide
theorem cert_e1211182324342 : check e1211182324342 [[],[]] .smaller = true := by decide
def e1211182324510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e1211182324510 : Closed e1211182324510 ∧ code e1211182324510 = 5609228835614 := by decide
theorem cert_e1211182324510 : check e1211182324510 [[],[]] .smaller = true := by decide
def e1211182324534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182324534 : Closed e1211182324534 ∧ code e1211182324534 = 5609228835638 := by decide
theorem cert_e1211182324534 : check e1211182324534 [[],[]] .smaller = true := by decide
def e1211182324538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182324538 : Closed e1211182324538 ∧ code e1211182324538 = 5609228835642 := by decide
theorem cert_e1211182324538 : check e1211182324538 [[],[]] .smaller = true := by decide
def e1211182324622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e1211182324622 : Closed e1211182324622 ∧ code e1211182324622 = 5609228835726 := by decide
theorem cert_e1211182324622 : check e1211182324622 [[],[]] .smaller = true := by decide
def e1211182324670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 4))))))))
theorem wire_e1211182324670 : Closed e1211182324670 ∧ code e1211182324670 = 5609228835774 := by decide
theorem cert_e1211182324670 : check e1211182324670 [[],[]] .three = true := by decide
def e1211182324678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e1211182324678 : Closed e1211182324678 ∧ code e1211182324678 = 5609228835782 := by decide
theorem cert_e1211182324678 : check e1211182324678 [[],[]] .smaller = true := by decide
def e1211182324702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 3))))))))
theorem wire_e1211182324702 : Closed e1211182324702 ∧ code e1211182324702 = 5609228835806 := by decide
theorem cert_e1211182324702 : check e1211182324702 [[],[]] .smaller = true := by decide
def e1211182324718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 4))) (.var 2))))))))
theorem wire_e1211182324718 : Closed e1211182324718 ∧ code e1211182324718 = 5609228835822 := by decide
theorem cert_e1211182324718 : check e1211182324718 [[],[]] .three = true := by decide
def e1211182324846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211182324846 : Closed e1211182324846 ∧ code e1211182324846 = 5609228835950 := by decide
theorem cert_e1211182324846 : check e1211182324846 [[],[]] .smaller = true := by decide
def e1211182324858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e1211182324858 : Closed e1211182324858 ∧ code e1211182324858 = 5609228835962 := by decide
theorem cert_e1211182324858 : check e1211182324858 [[],[]] .smaller = true := by decide
def e1211182324950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e1211182324950 : Closed e1211182324950 ∧ code e1211182324950 = 5609228836054 := by decide
theorem cert_e1211182324950 : check e1211182324950 [[],[]] .smaller = true := by decide
def e1211182324954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e1211182324954 : Closed e1211182324954 ∧ code e1211182324954 = 5609228836058 := by decide
theorem cert_e1211182324954 : check e1211182324954 [[],[]] .smaller = true := by decide
def e1211182324970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e1211182324970 : Closed e1211182324970 ∧ code e1211182324970 = 5609228836074 := by decide
theorem cert_e1211182324970 : check e1211182324970 [[],[]] .smaller = true := by decide
def e1211182325022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e1211182325022 : Closed e1211182325022 ∧ code e1211182325022 = 5609228836126 := by decide
theorem cert_e1211182325022 : check e1211182325022 [[],[]] .smaller = true := by decide
def e1211182325046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182325046 : Closed e1211182325046 ∧ code e1211182325046 = 5609228836150 := by decide
theorem cert_e1211182325046 : check e1211182325046 [[],[]] .smaller = true := by decide
def e1211182325050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182325050 : Closed e1211182325050 ∧ code e1211182325050 = 5609228836154 := by decide
theorem cert_e1211182325050 : check e1211182325050 [[],[]] .smaller = true := by decide
def e1211182325146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182325146 : Closed e1211182325146 ∧ code e1211182325146 = 5609228836250 := by decide
theorem cert_e1211182325146 : check e1211182325146 [[],[]] .smaller = true := by decide
def e1211182325182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 4))))))))
theorem wire_e1211182325182 : Closed e1211182325182 ∧ code e1211182325182 = 5609228836286 := by decide
theorem cert_e1211182325182 : check e1211182325182 [[],[]] .three = true := by decide
def e1211182325190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e1211182325190 : Closed e1211182325190 ∧ code e1211182325190 = 5609228836294 := by decide
theorem cert_e1211182325190 : check e1211182325190 [[],[]] .smaller = true := by decide
def e1211182325214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e1211182325214 : Closed e1211182325214 ∧ code e1211182325214 = 5609228836318 := by decide
theorem cert_e1211182325214 : check e1211182325214 [[],[]] .smaller = true := by decide
def e1211182325230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e1211182325230 : Closed e1211182325230 ∧ code e1211182325230 = 5609228836334 := by decide
theorem cert_e1211182325230 : check e1211182325230 [[],[]] .smaller = true := by decide
def e1211182325238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 4))) (.var 1))))))))
theorem wire_e1211182325238 : Closed e1211182325238 ∧ code e1211182325238 = 5609228836342 := by decide
theorem cert_e1211182325238 : check e1211182325238 [[],[]] .three = true := by decide
def e1211182325302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e1211182325302 : Closed e1211182325302 ∧ code e1211182325302 = 5609228836406 := by decide
theorem cert_e1211182325302 : check e1211182325302 [[],[]] .smaller = true := by decide
def e1211182325306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e1211182325306 : Closed e1211182325306 ∧ code e1211182325306 = 5609228836410 := by decide
theorem cert_e1211182325306 : check e1211182325306 [[],[]] .smaller = true := by decide
def e1211182325390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e1211182325390 : Closed e1211182325390 ∧ code e1211182325390 = 5609228836494 := by decide
theorem cert_e1211182325390 : check e1211182325390 [[],[]] .smaller = true := by decide
def e1211182325438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 4))))))))
theorem wire_e1211182325438 : Closed e1211182325438 ∧ code e1211182325438 = 5609228836542 := by decide
theorem cert_e1211182325438 : check e1211182325438 [[],[]] .three = true := by decide
def e1211182325446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e1211182325446 : Closed e1211182325446 ∧ code e1211182325446 = 5609228836550 := by decide
theorem cert_e1211182325446 : check e1211182325446 [[],[]] .smaller = true := by decide
def e1211182325470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e1211182325470 : Closed e1211182325470 ∧ code e1211182325470 = 5609228836574 := by decide
theorem cert_e1211182325470 : check e1211182325470 [[],[]] .smaller = true := by decide
def e1211182325494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e1211182325494 : Closed e1211182325494 ∧ code e1211182325494 = 5609228836598 := by decide
theorem cert_e1211182325494 : check e1211182325494 [[],[]] .smaller = true := by decide
def e1211182325498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 4))) (.var 0))))))))
theorem wire_e1211182325498 : Closed e1211182325498 ∧ code e1211182325498 = 5609228836602 := by decide
theorem cert_e1211182325498 : check e1211182325498 [[],[]] .three = true := by decide
def e1211182325530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e1211182325530 : Closed e1211182325530 ∧ code e1211182325530 = 5609228836634 := by decide
theorem cert_e1211182325530 : check e1211182325530 [[],[]] .smaller = true := by decide
def e1211182325574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e1211182325574 : Closed e1211182325574 ∧ code e1211182325574 = 5609228836678 := by decide
theorem cert_e1211182325574 : check e1211182325574 [[],[]] .smaller = true := by decide
def e1211182325598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 3))))))))
theorem wire_e1211182325598 : Closed e1211182325598 ∧ code e1211182325598 = 5609228836702 := by decide
theorem cert_e1211182325598 : check e1211182325598 [[],[]] .smaller = true := by decide
def e1211182325614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e1211182325614 : Closed e1211182325614 ∧ code e1211182325614 = 5609228836718 := by decide
theorem cert_e1211182325614 : check e1211182325614 [[],[]] .smaller = true := by decide
def e1211182325622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e1211182325622 : Closed e1211182325622 ∧ code e1211182325622 = 5609228836726 := by decide
theorem cert_e1211182325622 : check e1211182325622 [[],[]] .smaller = true := by decide
def e1211182325626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 3))) (.var 0))))))))
theorem wire_e1211182325626 : Closed e1211182325626 ∧ code e1211182325626 = 5609228836730 := by decide
theorem cert_e1211182325626 : check e1211182325626 [[],[]] .smaller = true := by decide
def e1211182325678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 0))) (.var 2))))))))
theorem wire_e1211182325678 : Closed e1211182325678 ∧ code e1211182325678 = 5609228836782 := by decide
theorem cert_e1211182325678 : check e1211182325678 [[],[]] .three = true := by decide
def e1211182325686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 1))) (.var 1))))))))
theorem wire_e1211182325686 : Closed e1211182325686 ∧ code e1211182325686 = 5609228836790 := by decide
theorem cert_e1211182325686 : check e1211182325686 [[],[]] .three = true := by decide
def e1211182325690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 2))) (.var 0))))))))
theorem wire_e1211182325690 : Closed e1211182325690 ∧ code e1211182325690 = 5609228836794 := by decide
theorem cert_e1211182325690 : check e1211182325690 [[],[]] .three = true := by decide
def e1211182326254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e1211182326254 : Closed e1211182326254 ∧ code e1211182326254 = 5609228837358 := by decide
theorem cert_e1211182326254 : check e1211182326254 [[],[]] .smaller = true := by decide
def e1211182327222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211182327222 : Closed e1211182327222 ∧ code e1211182327222 = 5609228838326 := by decide
theorem cert_e1211182327222 : check e1211182327222 [[],[]] .smaller = true := by decide
def e1211182327254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211182327254 : Closed e1211182327254 ∧ code e1211182327254 = 5609228838358 := by decide
theorem cert_e1211182327254 : check e1211182327254 [[],[]] .smaller = true := by decide
def e1211182327258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211182327258 : Closed e1211182327258 ∧ code e1211182327258 = 5609228838362 := by decide
theorem cert_e1211182327258 : check e1211182327258 [[],[]] .smaller = true := by decide
def e1211182327358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1211182327358 : Closed e1211182327358 ∧ code e1211182327358 = 5609228838462 := by decide
theorem cert_e1211182327358 : check e1211182327358 [[],[]] .smaller = true := by decide
def e1211182327414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211182327414 : Closed e1211182327414 ∧ code e1211182327414 = 5609228838518 := by decide
theorem cert_e1211182327414 : check e1211182327414 [[],[]] .smaller = true := by decide
def e1211182327582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e1211182327582 : Closed e1211182327582 ∧ code e1211182327582 = 5609228838686 := by decide
theorem cert_e1211182327582 : check e1211182327582 [[],[]] .smaller = true := by decide
def e1211182327606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182327606 : Closed e1211182327606 ∧ code e1211182327606 = 5609228838710 := by decide
theorem cert_e1211182327606 : check e1211182327606 [[],[]] .smaller = true := by decide
def e1211182327610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182327610 : Closed e1211182327610 ∧ code e1211182327610 = 5609228838714 := by decide
theorem cert_e1211182327610 : check e1211182327610 [[],[]] .smaller = true := by decide
def e1211182327694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e1211182327694 : Closed e1211182327694 ∧ code e1211182327694 = 5609228838798 := by decide
theorem cert_e1211182327694 : check e1211182327694 [[],[]] .smaller = true := by decide
def e1211182327742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 4)))))))))
theorem wire_e1211182327742 : Closed e1211182327742 ∧ code e1211182327742 = 5609228838846 := by decide
theorem cert_e1211182327742 : check e1211182327742 [[],[]] .three = true := by decide
def e1211182327750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1211182327750 : Closed e1211182327750 ∧ code e1211182327750 = 5609228838854 := by decide
theorem cert_e1211182327750 : check e1211182327750 [[],[]] .smaller = true := by decide
def e1211182327774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 3)))))))))
theorem wire_e1211182327774 : Closed e1211182327774 ∧ code e1211182327774 = 5609228838878 := by decide
theorem cert_e1211182327774 : check e1211182327774 [[],[]] .smaller = true := by decide
def e1211182327790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 4) (.var 2)))))))))
theorem wire_e1211182327790 : Closed e1211182327790 ∧ code e1211182327790 = 5609228838894 := by decide
theorem cert_e1211182327790 : check e1211182327790 [[],[]] .three = true := by decide
def e1211182330094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1211182330094 : Closed e1211182330094 ∧ code e1211182330094 = 5609228841198 := by decide
theorem cert_e1211182330094 : check e1211182330094 [[],[]] .smaller = true := by decide
def e1211182330102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1211182330102 : Closed e1211182330102 ∧ code e1211182330102 = 5609228841206 := by decide
theorem cert_e1211182330102 : check e1211182330102 [[],[]] .smaller = true := by decide
def e1211182330582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1211182330582 : Closed e1211182330582 ∧ code e1211182330582 = 5609228841686 := by decide
theorem cert_e1211182330582 : check e1211182330582 [[],[]] .smaller = true := by decide
def e1211182330586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e1211182330586 : Closed e1211182330586 ∧ code e1211182330586 = 5609228841690 := by decide
theorem cert_e1211182330586 : check e1211182330586 [[],[]] .smaller = true := by decide
def e1211182330602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e1211182330602 : Closed e1211182330602 ∧ code e1211182330602 = 5609228841706 := by decide
theorem cert_e1211182330602 : check e1211182330602 [[],[]] .smaller = true := by decide
def e1211182330654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e1211182330654 : Closed e1211182330654 ∧ code e1211182330654 = 5609228841758 := by decide
theorem cert_e1211182330654 : check e1211182330654 [[],[]] .smaller = true := by decide
def e1211182330678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211182330678 : Closed e1211182330678 ∧ code e1211182330678 = 5609228841782 := by decide
theorem cert_e1211182330678 : check e1211182330678 [[],[]] .smaller = true := by decide
def e1211182330682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211182330682 : Closed e1211182330682 ∧ code e1211182330682 = 5609228841786 := by decide
theorem cert_e1211182330682 : check e1211182330682 [[],[]] .smaller = true := by decide
def e1211182330778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e1211182330778 : Closed e1211182330778 ∧ code e1211182330778 = 5609228841882 := by decide
theorem cert_e1211182330778 : check e1211182330778 [[],[]] .smaller = true := by decide
def e1211182330814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 4)))))))))
theorem wire_e1211182330814 : Closed e1211182330814 ∧ code e1211182330814 = 5609228841918 := by decide
theorem cert_e1211182330814 : check e1211182330814 [[],[]] .three = true := by decide
def e1211182330822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e1211182330822 : Closed e1211182330822 ∧ code e1211182330822 = 5609228841926 := by decide
theorem cert_e1211182330822 : check e1211182330822 [[],[]] .smaller = true := by decide
def e1211182330846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1211182330846 : Closed e1211182330846 ∧ code e1211182330846 = 5609228841950 := by decide
theorem cert_e1211182330846 : check e1211182330846 [[],[]] .smaller = true := by decide
def e1211182330862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1211182330862 : Closed e1211182330862 ∧ code e1211182330862 = 5609228841966 := by decide
theorem cert_e1211182330862 : check e1211182330862 [[],[]] .smaller = true := by decide
def e1211182330870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 4) (.var 1)))))))))
theorem wire_e1211182330870 : Closed e1211182330870 ∧ code e1211182330870 = 5609228841974 := by decide
theorem cert_e1211182330870 : check e1211182330870 [[],[]] .three = true := by decide
def e1211182332302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e1211182332302 : Closed e1211182332302 ∧ code e1211182332302 = 5609228843406 := by decide
theorem cert_e1211182332302 : check e1211182332302 [[],[]] .smaller = true := by decide
def e1211182332350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 4)))))))))
theorem wire_e1211182332350 : Closed e1211182332350 ∧ code e1211182332350 = 5609228843454 := by decide
theorem cert_e1211182332350 : check e1211182332350 [[],[]] .three = true := by decide
def e1211182332358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e1211182332358 : Closed e1211182332358 ∧ code e1211182332358 = 5609228843462 := by decide
theorem cert_e1211182332358 : check e1211182332358 [[],[]] .smaller = true := by decide
def e1211182332382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211182332382 : Closed e1211182332382 ∧ code e1211182332382 = 5609228843486 := by decide
theorem cert_e1211182332382 : check e1211182332382 [[],[]] .smaller = true := by decide
def e1211182332406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211182332406 : Closed e1211182332406 ∧ code e1211182332406 = 5609228843510 := by decide
theorem cert_e1211182332406 : check e1211182332406 [[],[]] .smaller = true := by decide
def e1211182332410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 4) (.var 0)))))))))
theorem wire_e1211182332410 : Closed e1211182332410 ∧ code e1211182332410 = 5609228843514 := by decide
theorem cert_e1211182332410 : check e1211182332410 [[],[]] .three = true := by decide
def e1211182333126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211182333126 : Closed e1211182333126 ∧ code e1211182333126 = 5609228844230 := by decide
theorem cert_e1211182333126 : check e1211182333126 [[],[]] .smaller = true := by decide
def e1211182333150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211182333150 : Closed e1211182333150 ∧ code e1211182333150 = 5609228844254 := by decide
theorem cert_e1211182333150 : check e1211182333150 [[],[]] .smaller = true := by decide
def e1211182333166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211182333166 : Closed e1211182333166 ∧ code e1211182333166 = 5609228844270 := by decide
theorem cert_e1211182333166 : check e1211182333166 [[],[]] .smaller = true := by decide
def e1211182333174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211182333174 : Closed e1211182333174 ∧ code e1211182333174 = 5609228844278 := by decide
theorem cert_e1211182333174 : check e1211182333174 [[],[]] .smaller = true := by decide
def e1211182333178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211182333178 : Closed e1211182333178 ∧ code e1211182333178 = 5609228844282 := by decide
theorem cert_e1211182333178 : check e1211182333178 [[],[]] .smaller = true := by decide
def e1211182333550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182333550 : Closed e1211182333550 ∧ code e1211182333550 = 5609228844654 := by decide
theorem cert_e1211182333550 : check e1211182333550 [[],[]] .three = true := by decide
def e1211182333558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182333558 : Closed e1211182333558 ∧ code e1211182333558 = 5609228844662 := by decide
theorem cert_e1211182333558 : check e1211182333558 [[],[]] .three = true := by decide
def e1211182333562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182333562 : Closed e1211182333562 ∧ code e1211182333562 = 5609228844666 := by decide
theorem cert_e1211182333562 : check e1211182333562 [[],[]] .three = true := by decide
def e1211182334902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e1211182334902 : Closed e1211182334902 ∧ code e1211182334902 = 5609228846006 := by decide
theorem cert_e1211182334902 : check e1211182334902 [[],[]] .smaller = true := by decide
def e1211182334906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e1211182334906 : Closed e1211182334906 ∧ code e1211182334906 = 5609228846010 := by decide
theorem cert_e1211182334906 : check e1211182334906 [[],[]] .smaller = true := by decide
def e1211182334938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e1211182334938 : Closed e1211182334938 ∧ code e1211182334938 = 5609228846042 := by decide
theorem cert_e1211182334938 : check e1211182334938 [[],[]] .smaller = true := by decide
def e1211182335598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211182335598 : Closed e1211182335598 ∧ code e1211182335598 = 5609228846702 := by decide
theorem cert_e1211182335598 : check e1211182335598 [[],[]] .smaller = true := by decide
def e1211182335606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211182335606 : Closed e1211182335606 ∧ code e1211182335606 = 5609228846710 := by decide
theorem cert_e1211182335606 : check e1211182335606 [[],[]] .smaller = true := by decide
def e1211182335610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211182335610 : Closed e1211182335610 ∧ code e1211182335610 = 5609228846714 := by decide
theorem cert_e1211182335610 : check e1211182335610 [[],[]] .smaller = true := by decide
def e1211182335798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211182335798 : Closed e1211182335798 ∧ code e1211182335798 = 5609228846902 := by decide
theorem cert_e1211182335798 : check e1211182335798 [[],[]] .smaller = true := by decide
def e1211182335802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211182335802 : Closed e1211182335802 ∧ code e1211182335802 = 5609228846906 := by decide
theorem cert_e1211182335802 : check e1211182335802 [[],[]] .smaller = true := by decide
def e1211182335898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211182335898 : Closed e1211182335898 ∧ code e1211182335898 = 5609228847002 := by decide
theorem cert_e1211182335898 : check e1211182335898 [[],[]] .smaller = true := by decide
def e1211182336854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e1211182336854 : Closed e1211182336854 ∧ code e1211182336854 = 5609228847958 := by decide
theorem cert_e1211182336854 : check e1211182336854 [[],[]] .smaller = true := by decide
def e1211182336858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e1211182336858 : Closed e1211182336858 ∧ code e1211182336858 = 5609228847962 := by decide
theorem cert_e1211182336858 : check e1211182336858 [[],[]] .smaller = true := by decide
def e1211182336874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e1211182336874 : Closed e1211182336874 ∧ code e1211182336874 = 5609228847978 := by decide
theorem cert_e1211182336874 : check e1211182336874 [[],[]] .smaller = true := by decide
def e1211182336938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e1211182336938 : Closed e1211182336938 ∧ code e1211182336938 = 5609228848042 := by decide
theorem cert_e1211182336938 : check e1211182336938 [[],[]] .smaller = true := by decide
def e1211182337134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e1211182337134 : Closed e1211182337134 ∧ code e1211182337134 = 5609228848238 := by decide
theorem cert_e1211182337134 : check e1211182337134 [[],[]] .smaller = true := by decide
end Blc.Floor42
