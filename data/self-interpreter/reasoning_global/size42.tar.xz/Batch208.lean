import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211205540250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205540250 : Closed e1211205540250 ∧ code e1211205540250 = 5609252051354 := by decide
theorem cert_e1211205540250 : check e1211205540250 [[],[]] .chain = true := by decide
def e1211205540294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205540294 : Closed e1211205540294 ∧ code e1211205540294 = 5609252051398 := by decide
theorem cert_e1211205540294 : check e1211205540294 [[],[]] .chain = true := by decide
def e1211205540918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e1211205540918 : Closed e1211205540918 ∧ code e1211205540918 = 5609252052022 := by decide
theorem cert_e1211205540918 : check e1211205540918 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205540922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e1211205540922 : Closed e1211205540922 ∧ code e1211205540922 = 5609252052026 := by decide
theorem cert_e1211205540922 : check e1211205540922 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205541062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211205541062 : Closed e1211205541062 ∧ code e1211205541062 = 5609252052166 := by decide
theorem cert_e1211205541062 : check e1211205541062 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e1211205542326 : Closed e1211205542326 ∧ code e1211205542326 = 5609252053430 := by decide
theorem cert_e1211205542326 : check e1211205542326 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e1211205542330 : Closed e1211205542330 ∧ code e1211205542330 = 5609252053434 := by decide
theorem cert_e1211205542330 : check e1211205542330 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e1211205542358 : Closed e1211205542358 ∧ code e1211205542358 = 5609252053462 := by decide
theorem cert_e1211205542358 : check e1211205542358 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e1211205542378 : Closed e1211205542378 ∧ code e1211205542378 = 5609252053482 := by decide
theorem cert_e1211205542378 : check e1211205542378 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211205542710 : Closed e1211205542710 ∧ code e1211205542710 = 5609252053814 := by decide
theorem cert_e1211205542710 : check e1211205542710 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211205542714 : Closed e1211205542714 ∧ code e1211205542714 = 5609252053818 := by decide
theorem cert_e1211205542714 : check e1211205542714 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205542810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211205542810 : Closed e1211205542810 ∧ code e1211205542810 = 5609252053914 := by decide
theorem cert_e1211205542810 : check e1211205542810 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205543478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211205543478 : Closed e1211205543478 ∧ code e1211205543478 = 5609252054582 := by decide
theorem cert_e1211205543478 : check e1211205543478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205543482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e1211205543482 : Closed e1211205543482 ∧ code e1211205543482 = 5609252054586 := by decide
theorem cert_e1211205543482 : check e1211205543482 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205543566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211205543566 : Closed e1211205543566 ∧ code e1211205543566 = 5609252054670 := by decide
theorem cert_e1211205543566 : check e1211205543566 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205543622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e1211205543622 : Closed e1211205543622 ∧ code e1211205543622 = 5609252054726 := by decide
theorem cert_e1211205543622 : check e1211205543622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205543706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211205543706 : Closed e1211205543706 ∧ code e1211205543706 = 5609252054810 := by decide
theorem cert_e1211205543706 : check e1211205543706 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205543750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211205543750 : Closed e1211205543750 ∧ code e1211205543750 = 5609252054854 := by decide
theorem cert_e1211205543750 : check e1211205543750 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205544046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e1211205544046 : Closed e1211205544046 ∧ code e1211205544046 = 5609252055150 := by decide
theorem cert_e1211205544046 : check e1211205544046 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205544058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e1211205544058 : Closed e1211205544058 ∧ code e1211205544058 = 5609252055162 := by decide
theorem cert_e1211205544058 : check e1211205544058 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205544334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211205544334 : Closed e1211205544334 ∧ code e1211205544334 = 5609252055438 := by decide
theorem cert_e1211205544334 : check e1211205544334 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205544390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211205544390 : Closed e1211205544390 ∧ code e1211205544390 = 5609252055494 := by decide
theorem cert_e1211205544390 : check e1211205544390 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205545014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e1211205545014 : Closed e1211205545014 ∧ code e1211205545014 = 5609252056118 := by decide
theorem cert_e1211205545014 : check e1211205545014 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205545018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e1211205545018 : Closed e1211205545018 ∧ code e1211205545018 = 5609252056122 := by decide
theorem cert_e1211205545018 : check e1211205545018 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205545158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211205545158 : Closed e1211205545158 ∧ code e1211205545158 = 5609252056262 := by decide
theorem cert_e1211205545158 : check e1211205545158 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205552094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e1211205552094 : Closed e1211205552094 ∧ code e1211205552094 = 5609252063198 := by decide
theorem cert_e1211205552094 : check e1211205552094 [[],[]] .chain = true := by decide
def e1211205555934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e1211205555934 : Closed e1211205555934 ∧ code e1211205555934 = 5609252067038 := by decide
theorem cert_e1211205555934 : check e1211205555934 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205555950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e1211205555950 : Closed e1211205555950 ∧ code e1211205555950 = 5609252067054 := by decide
theorem cert_e1211205555950 : check e1211205555950 [[],[]] .chain = true := by decide
def e1211205555958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e1211205555958 : Closed e1211205555958 ∧ code e1211205555958 = 5609252067062 := by decide
theorem cert_e1211205555958 : check e1211205555958 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205556062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e1211205556062 : Closed e1211205556062 ∧ code e1211205556062 = 5609252067166 := by decide
theorem cert_e1211205556062 : check e1211205556062 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205556078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e1211205556078 : Closed e1211205556078 ∧ code e1211205556078 = 5609252067182 := by decide
theorem cert_e1211205556078 : check e1211205556078 [[],[]] .chain = true := by decide
def e1211205556086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e1211205556086 : Closed e1211205556086 ∧ code e1211205556086 = 5609252067190 := by decide
theorem cert_e1211205556086 : check e1211205556086 [[],[]] .chain = true := by decide
def e1211205556090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e1211205556090 : Closed e1211205556090 ∧ code e1211205556090 = 5609252067194 := by decide
theorem cert_e1211205556090 : check e1211205556090 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205556142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e1211205556142 : Closed e1211205556142 ∧ code e1211205556142 = 5609252067246 := by decide
theorem cert_e1211205556142 : check e1211205556142 [[],[]] .chain = true := by decide
def e1211205556150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e1211205556150 : Closed e1211205556150 ∧ code e1211205556150 = 5609252067254 := by decide
theorem cert_e1211205556150 : check e1211205556150 [[],[]] .chain = true := by decide
def e1211205556154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e1211205556154 : Closed e1211205556154 ∧ code e1211205556154 = 5609252067258 := by decide
theorem cert_e1211205556154 : check e1211205556154 [[],[]] .chain = true := by decide
def e1211205556182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e1211205556182 : Closed e1211205556182 ∧ code e1211205556182 = 5609252067286 := by decide
theorem cert_e1211205556182 : check e1211205556182 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205556186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e1211205556186 : Closed e1211205556186 ∧ code e1211205556186 = 5609252067290 := by decide
theorem cert_e1211205556186 : check e1211205556186 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205556702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e1211205556702 : Closed e1211205556702 ∧ code e1211205556702 = 5609252067806 := by decide
theorem cert_e1211205556702 : check e1211205556702 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205556718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e1211205556718 : Closed e1211205556718 ∧ code e1211205556718 = 5609252067822 := by decide
theorem cert_e1211205556718 : check e1211205556718 [[],[]] .chain = true := by decide
def e1211205556726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e1211205556726 : Closed e1211205556726 ∧ code e1211205556726 = 5609252067830 := by decide
theorem cert_e1211205556726 : check e1211205556726 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205557470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205557470 : Closed e1211205557470 ∧ code e1211205557470 = 5609252068574 := by decide
theorem cert_e1211205557470 : check e1211205557470 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205557486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205557486 : Closed e1211205557486 ∧ code e1211205557486 = 5609252068590 := by decide
theorem cert_e1211205557486 : check e1211205557486 [[],[]] .chain = true := by decide
def e1211205557494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205557494 : Closed e1211205557494 ∧ code e1211205557494 = 5609252068598 := by decide
theorem cert_e1211205557494 : check e1211205557494 [[],[]] .chain = true := by decide
def e1211205557498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205557498 : Closed e1211205557498 ∧ code e1211205557498 = 5609252068602 := by decide
theorem cert_e1211205557498 : check e1211205557498 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205557786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211205557786 : Closed e1211205557786 ∧ code e1211205557786 = 5609252068890 := by decide
theorem cert_e1211205557786 : check e1211205557786 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205557822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e1211205557822 : Closed e1211205557822 ∧ code e1211205557822 = 5609252068926 := by decide
theorem cert_e1211205557822 : check e1211205557822 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205557870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205557870 : Closed e1211205557870 ∧ code e1211205557870 = 5609252068974 := by decide
theorem cert_e1211205557870 : check e1211205557870 [[],[]] .chain = true := by decide
def e1211205557878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205557878 : Closed e1211205557878 ∧ code e1211205557878 = 5609252068982 := by decide
theorem cert_e1211205557878 : check e1211205557878 [[],[]] .chain = true := by decide
def e1211205557882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205557882 : Closed e1211205557882 ∧ code e1211205557882 = 5609252068986 := by decide
theorem cert_e1211205557882 : check e1211205557882 [[],[]] .chain = true := by decide
def e1211205558046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e1211205558046 : Closed e1211205558046 ∧ code e1211205558046 = 5609252069150 := by decide
theorem cert_e1211205558046 : check e1211205558046 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205558070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205558070 : Closed e1211205558070 ∧ code e1211205558070 = 5609252069174 := by decide
theorem cert_e1211205558070 : check e1211205558070 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205558074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205558074 : Closed e1211205558074 ∧ code e1211205558074 = 5609252069178 := by decide
theorem cert_e1211205558074 : check e1211205558074 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1211205572278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e1211205572278 : Closed e1211205572278 ∧ code e1211205572278 = 5609252083382 := by decide
theorem cert_e1211205572278 : check e1211205572278 [[],[]] .chain = true := by decide
def e1211205572310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e1211205572310 : Closed e1211205572310 ∧ code e1211205572310 = 5609252083414 := by decide
theorem cert_e1211205572310 : check e1211205572310 [[],[]] .chain = true := by decide
def e1211205572314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e1211205572314 : Closed e1211205572314 ∧ code e1211205572314 = 5609252083418 := by decide
theorem cert_e1211205572314 : check e1211205572314 [[],[]] .chain = true := by decide
def e1211205572438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211205572438 : Closed e1211205572438 ∧ code e1211205572438 = 5609252083542 := by decide
theorem cert_e1211205572438 : check e1211205572438 [[],[]] .chain = true := by decide
def e1211205572442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211205572442 : Closed e1211205572442 ∧ code e1211205572442 = 5609252083546 := by decide
theorem cert_e1211205572442 : check e1211205572442 [[],[]] .chain = true := by decide
def e1211205572458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211205572458 : Closed e1211205572458 ∧ code e1211205572458 = 5609252083562 := by decide
theorem cert_e1211205572458 : check e1211205572458 [[],[]] .chain = true := by decide
def e1211205572662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)))))))
theorem wire_e1211205572662 : Closed e1211205572662 ∧ code e1211205572662 = 5609252083766 := by decide
theorem cert_e1211205572662 : check e1211205572662 [[],[]] .chain = true := by decide
def e1211205572750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))))))))
theorem wire_e1211205572750 : Closed e1211205572750 ∧ code e1211205572750 = 5609252083854 := by decide
theorem cert_e1211205572750 : check e1211205572750 [[],[]] .chain = true := by decide
def e1211205572834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211205572834 : Closed e1211205572834 ∧ code e1211205572834 = 5609252083938 := by decide
theorem cert_e1211205572834 : check e1211205572834 [[],[]] .chain = true := by decide
def e1211205572846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e1211205572846 : Closed e1211205572846 ∧ code e1211205572846 = 5609252083950 := by decide
theorem cert_e1211205572846 : check e1211205572846 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205572854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e1211205572854 : Closed e1211205572854 ∧ code e1211205572854 = 5609252083958 := by decide
theorem cert_e1211205572854 : check e1211205572854 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205573046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e1211205573046 : Closed e1211205573046 ∧ code e1211205573046 = 5609252084150 := by decide
theorem cert_e1211205573046 : check e1211205573046 [[],[]] .chain = true := by decide
def e1211205573078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e1211205573078 : Closed e1211205573078 ∧ code e1211205573078 = 5609252084182 := by decide
theorem cert_e1211205573078 : check e1211205573078 [[],[]] .chain = true := by decide
def e1211205573082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e1211205573082 : Closed e1211205573082 ∧ code e1211205573082 = 5609252084186 := by decide
theorem cert_e1211205573082 : check e1211205573082 [[],[]] .chain = true := by decide
def e1211205573238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e1211205573238 : Closed e1211205573238 ∧ code e1211205573238 = 5609252084342 := by decide
theorem cert_e1211205573238 : check e1211205573238 [[],[]] .chain = true := by decide
def e1211205573382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205573382 : Closed e1211205573382 ∧ code e1211205573382 = 5609252084486 := by decide
theorem cert_e1211205573382 : check e1211205573382 [[],[]] .chain = true := by decide
def e1211205573406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e1211205573406 : Closed e1211205573406 ∧ code e1211205573406 = 5609252084510 := by decide
theorem cert_e1211205573406 : check e1211205573406 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205573430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205573430 : Closed e1211205573430 ∧ code e1211205573430 = 5609252084534 := by decide
theorem cert_e1211205573430 : check e1211205573430 [[],[]] .chain = true := by decide
def e1211205573434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205573434 : Closed e1211205573434 ∧ code e1211205573434 = 5609252084538 := by decide
theorem cert_e1211205573434 : check e1211205573434 [[],[]] .chain = true := by decide
def e1211205573518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e1211205573518 : Closed e1211205573518 ∧ code e1211205573518 = 5609252084622 := by decide
theorem cert_e1211205573518 : check e1211205573518 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205573654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211205573654 : Closed e1211205573654 ∧ code e1211205573654 = 5609252084758 := by decide
theorem cert_e1211205573654 : check e1211205573654 [[],[]] .chain = true := by decide
def e1211205573658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211205573658 : Closed e1211205573658 ∧ code e1211205573658 = 5609252084762 := by decide
theorem cert_e1211205573658 : check e1211205573658 [[],[]] .chain = true := by decide
def e1211205573702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211205573702 : Closed e1211205573702 ∧ code e1211205573702 = 5609252084806 := by decide
theorem cert_e1211205573702 : check e1211205573702 [[],[]] .chain = true := by decide
def e1211205573730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211205573730 : Closed e1211205573730 ∧ code e1211205573730 = 5609252084834 := by decide
theorem cert_e1211205573730 : check e1211205573730 [[],[]] .chain = true := by decide
def e1211205573742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211205573742 : Closed e1211205573742 ∧ code e1211205573742 = 5609252084846 := by decide
theorem cert_e1211205573742 : check e1211205573742 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205573750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211205573750 : Closed e1211205573750 ∧ code e1211205573750 = 5609252084854 := by decide
theorem cert_e1211205573750 : check e1211205573750 [[],[]] .chain = true := by decide
def e1211205573754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211205573754 : Closed e1211205573754 ∧ code e1211205573754 = 5609252084858 := by decide
theorem cert_e1211205573754 : check e1211205573754 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205573846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211205573846 : Closed e1211205573846 ∧ code e1211205573846 = 5609252084950 := by decide
theorem cert_e1211205573846 : check e1211205573846 [[],[]] .chain = true := by decide
def e1211205573850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e1211205573850 : Closed e1211205573850 ∧ code e1211205573850 = 5609252084954 := by decide
theorem cert_e1211205573850 : check e1211205573850 [[],[]] .chain = true := by decide
def e1211205573866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e1211205573866 : Closed e1211205573866 ∧ code e1211205573866 = 5609252084970 := by decide
theorem cert_e1211205573866 : check e1211205573866 [[],[]] .chain = true := by decide
def e1211205573894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))))))))
theorem wire_e1211205573894 : Closed e1211205573894 ∧ code e1211205573894 = 5609252084998 := by decide
theorem cert_e1211205573894 : check e1211205573894 [[],[]] .chain = true := by decide
def e1211205573918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211205573918 : Closed e1211205573918 ∧ code e1211205573918 = 5609252085022 := by decide
theorem cert_e1211205573918 : check e1211205573918 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205573942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e1211205573942 : Closed e1211205573942 ∧ code e1211205573942 = 5609252085046 := by decide
theorem cert_e1211205573942 : check e1211205573942 [[],[]] .chain = true := by decide
def e1211205573946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e1211205573946 : Closed e1211205573946 ∧ code e1211205573946 = 5609252085050 := by decide
theorem cert_e1211205573946 : check e1211205573946 [[],[]] .chain = true := by decide
def e1211205574018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e1211205574018 : Closed e1211205574018 ∧ code e1211205574018 = 5609252085122 := by decide
theorem cert_e1211205574018 : check e1211205574018 [[],[]] .chain = true := by decide
def e1211205574030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))))))
theorem wire_e1211205574030 : Closed e1211205574030 ∧ code e1211205574030 = 5609252085134 := by decide
theorem cert_e1211205574030 : check e1211205574030 [[],[]] .chain = true := by decide
def e1211205574042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211205574042 : Closed e1211205574042 ∧ code e1211205574042 = 5609252085146 := by decide
theorem cert_e1211205574042 : check e1211205574042 [[],[]] .chain = true := by decide
def e1211205574086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211205574086 : Closed e1211205574086 ∧ code e1211205574086 = 5609252085190 := by decide
theorem cert_e1211205574086 : check e1211205574086 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205574198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211205574198 : Closed e1211205574198 ∧ code e1211205574198 = 5609252085302 := by decide
theorem cert_e1211205574198 : check e1211205574198 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205574202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211205574202 : Closed e1211205574202 ∧ code e1211205574202 = 5609252085306 := by decide
theorem cert_e1211205574202 : check e1211205574202 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205574286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211205574286 : Closed e1211205574286 ∧ code e1211205574286 = 5609252085390 := by decide
theorem cert_e1211205574286 : check e1211205574286 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205574342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211205574342 : Closed e1211205574342 ∧ code e1211205574342 = 5609252085446 := by decide
theorem cert_e1211205574342 : check e1211205574342 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205574718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.var 4))))))))))
theorem wire_e1211205574718 : Closed e1211205574718 ∧ code e1211205574718 = 5609252085822 := by decide
theorem cert_e1211205574718 : check e1211205574718 [[],[]] .chain = true := by decide
def e1211205575138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e1211205575138 : Closed e1211205575138 ∧ code e1211205575138 = 5609252086242 := by decide
theorem cert_e1211205575138 : check e1211205575138 [[],[]] .chain = true := by decide
def e1211205575150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e1211205575150 : Closed e1211205575150 ∧ code e1211205575150 = 5609252086254 := by decide
theorem cert_e1211205575150 : check e1211205575150 [[],[]] .chain = true := by decide
def e1211205576118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e1211205576118 : Closed e1211205576118 ∧ code e1211205576118 = 5609252087222 := by decide
theorem cert_e1211205576118 : check e1211205576118 [[],[]] .chain = true := by decide
def e1211205576150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e1211205576150 : Closed e1211205576150 ∧ code e1211205576150 = 5609252087254 := by decide
theorem cert_e1211205576150 : check e1211205576150 [[],[]] .chain = true := by decide
def e1211205576154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e1211205576154 : Closed e1211205576154 ∧ code e1211205576154 = 5609252087258 := by decide
theorem cert_e1211205576154 : check e1211205576154 [[],[]] .chain = true := by decide
def e1211205576310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205576310 : Closed e1211205576310 ∧ code e1211205576310 = 5609252087414 := by decide
theorem cert_e1211205576310 : check e1211205576310 [[],[]] .chain = true := by decide
def e1211205576454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))))))))
theorem wire_e1211205576454 : Closed e1211205576454 ∧ code e1211205576454 = 5609252087558 := by decide
theorem cert_e1211205576454 : check e1211205576454 [[],[]] .chain = true := by decide
def e1211205576478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e1211205576478 : Closed e1211205576478 ∧ code e1211205576478 = 5609252087582 := by decide
theorem cert_e1211205576478 : check e1211205576478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205576502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205576502 : Closed e1211205576502 ∧ code e1211205576502 = 5609252087606 := by decide
theorem cert_e1211205576502 : check e1211205576502 [[],[]] .chain = true := by decide
def e1211205576506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205576506 : Closed e1211205576506 ∧ code e1211205576506 = 5609252087610 := by decide
theorem cert_e1211205576506 : check e1211205576506 [[],[]] .chain = true := by decide
def e1211205576590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e1211205576590 : Closed e1211205576590 ∧ code e1211205576590 = 5609252087694 := by decide
theorem cert_e1211205576590 : check e1211205576590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205578782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 3))))))))))
theorem wire_e1211205578782 : Closed e1211205578782 ∧ code e1211205578782 = 5609252089886 := by decide
theorem cert_e1211205578782 : check e1211205578782 [[],[]] .chain = true := by decide
def e1211205578950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e1211205578950 : Closed e1211205578950 ∧ code e1211205578950 = 5609252090054 := by decide
theorem cert_e1211205578950 : check e1211205578950 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205578974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211205578974 : Closed e1211205578974 ∧ code e1211205578974 = 5609252090078 := by decide
theorem cert_e1211205578974 : check e1211205578974 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205578978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e1211205578978 : Closed e1211205578978 ∧ code e1211205578978 = 5609252090082 := by decide
theorem cert_e1211205578978 : check e1211205578978 [[],[]] .chain = true := by decide
def e1211205578990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205578990 : Closed e1211205578990 ∧ code e1211205578990 = 5609252090094 := by decide
theorem cert_e1211205578990 : check e1211205578990 [[],[]] .chain = true := by decide
def e1211205578998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205578998 : Closed e1211205578998 ∧ code e1211205578998 = 5609252090102 := by decide
theorem cert_e1211205578998 : check e1211205578998 [[],[]] .chain = true := by decide
def e1211205579002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211205579002 : Closed e1211205579002 ∧ code e1211205579002 = 5609252090106 := by decide
theorem cert_e1211205579002 : check e1211205579002 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205579478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e1211205579478 : Closed e1211205579478 ∧ code e1211205579478 = 5609252090582 := by decide
theorem cert_e1211205579478 : check e1211205579478 [[],[]] .chain = true := by decide
def e1211205579482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e1211205579482 : Closed e1211205579482 ∧ code e1211205579482 = 5609252090586 := by decide
theorem cert_e1211205579482 : check e1211205579482 [[],[]] .chain = true := by decide
def e1211205579498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e1211205579498 : Closed e1211205579498 ∧ code e1211205579498 = 5609252090602 := by decide
theorem cert_e1211205579498 : check e1211205579498 [[],[]] .chain = true := by decide
def e1211205579526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))))))))
theorem wire_e1211205579526 : Closed e1211205579526 ∧ code e1211205579526 = 5609252090630 := by decide
theorem cert_e1211205579526 : check e1211205579526 [[],[]] .chain = true := by decide
def e1211205579550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211205579550 : Closed e1211205579550 ∧ code e1211205579550 = 5609252090654 := by decide
theorem cert_e1211205579550 : check e1211205579550 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205579574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205579574 : Closed e1211205579574 ∧ code e1211205579574 = 5609252090678 := by decide
theorem cert_e1211205579574 : check e1211205579574 [[],[]] .chain = true := by decide
def e1211205579578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205579578 : Closed e1211205579578 ∧ code e1211205579578 = 5609252090682 := by decide
theorem cert_e1211205579578 : check e1211205579578 [[],[]] .chain = true := by decide
def e1211205579650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e1211205579650 : Closed e1211205579650 ∧ code e1211205579650 = 5609252090754 := by decide
theorem cert_e1211205579650 : check e1211205579650 [[],[]] .chain = true := by decide
def e1211205579662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e1211205579662 : Closed e1211205579662 ∧ code e1211205579662 = 5609252090766 := by decide
theorem cert_e1211205579662 : check e1211205579662 [[],[]] .chain = true := by decide
def e1211205579674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211205579674 : Closed e1211205579674 ∧ code e1211205579674 = 5609252090778 := by decide
theorem cert_e1211205579674 : check e1211205579674 [[],[]] .chain = true := by decide
def e1211205579718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211205579718 : Closed e1211205579718 ∧ code e1211205579718 = 5609252090822 := by decide
theorem cert_e1211205579718 : check e1211205579718 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205580910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205580910 : Closed e1211205580910 ∧ code e1211205580910 = 5609252092014 := by decide
theorem cert_e1211205580910 : check e1211205580910 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205580922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205580922 : Closed e1211205580922 ∧ code e1211205580922 = 5609252092026 := by decide
theorem cert_e1211205580922 : check e1211205580922 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205581198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e1211205581198 : Closed e1211205581198 ∧ code e1211205581198 = 5609252092302 := by decide
theorem cert_e1211205581198 : check e1211205581198 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205581254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e1211205581254 : Closed e1211205581254 ∧ code e1211205581254 = 5609252092358 := by decide
theorem cert_e1211205581254 : check e1211205581254 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205616606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e1211205616606 : Closed e1211205616606 ∧ code e1211205616606 = 5609252127710 := by decide
theorem cert_e1211205616606 : check e1211205616606 [[],[]] .chain = true := by decide
def e1211205616622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e1211205616622 : Closed e1211205616622 ∧ code e1211205616622 = 5609252127726 := by decide
theorem cert_e1211205616622 : check e1211205616622 [[],[]] .chain = true := by decide
def e1211205618542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1211205618542 : Closed e1211205618542 ∧ code e1211205618542 = 5609252129646 := by decide
theorem cert_e1211205618542 : check e1211205618542 [[],[]] .chain = true := by decide
def e1211205618550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1211205618550 : Closed e1211205618550 ∧ code e1211205618550 = 5609252129654 := by decide
theorem cert_e1211205618550 : check e1211205618550 [[],[]] .chain = true := by decide
def e1211205618606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1211205618606 : Closed e1211205618606 ∧ code e1211205618606 = 5609252129710 := by decide
theorem cert_e1211205618606 : check e1211205618606 [[],[]] .chain = true := by decide
def e1211205618614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e1211205618614 : Closed e1211205618614 ∧ code e1211205618614 = 5609252129718 := by decide
theorem cert_e1211205618614 : check e1211205618614 [[],[]] .chain = true := by decide
def e1211205618618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1211205618618 : Closed e1211205618618 ∧ code e1211205618618 = 5609252129722 := by decide
theorem cert_e1211205618618 : check e1211205618618 [[],[]] .chain = true := by decide
def e1211205618646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1211205618646 : Closed e1211205618646 ∧ code e1211205618646 = 5609252129750 := by decide
theorem cert_e1211205618646 : check e1211205618646 [[],[]] .chain = true := by decide
def e1211205618650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1211205618650 : Closed e1211205618650 ∧ code e1211205618650 = 5609252129754 := by decide
theorem cert_e1211205618650 : check e1211205618650 [[],[]] .chain = true := by decide
def e1211205618926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211205618926 : Closed e1211205618926 ∧ code e1211205618926 = 5609252130030 := by decide
theorem cert_e1211205618926 : check e1211205618926 [[],[]] .chain = true := by decide
def e1211205618934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211205618934 : Closed e1211205618934 ∧ code e1211205618934 = 5609252130038 := by decide
theorem cert_e1211205618934 : check e1211205618934 [[],[]] .chain = true := by decide
def e1211205619226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e1211205619226 : Closed e1211205619226 ∧ code e1211205619226 = 5609252130330 := by decide
theorem cert_e1211205619226 : check e1211205619226 [[],[],[.under,.under,.left]] .width = true := by decide
def e1211205619262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e1211205619262 : Closed e1211205619262 ∧ code e1211205619262 = 5609252130366 := by decide
theorem cert_e1211205619262 : check e1211205619262 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205619310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211205619310 : Closed e1211205619310 ∧ code e1211205619310 = 5609252130414 := by decide
theorem cert_e1211205619310 : check e1211205619310 [[],[]] .chain = true := by decide
def e1211205619318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211205619318 : Closed e1211205619318 ∧ code e1211205619318 = 5609252130422 := by decide
theorem cert_e1211205619318 : check e1211205619318 [[],[]] .chain = true := by decide
def e1211205619322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211205619322 : Closed e1211205619322 ∧ code e1211205619322 = 5609252130426 := by decide
theorem cert_e1211205619322 : check e1211205619322 [[],[]] .chain = true := by decide
def e1211205619510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211205619510 : Closed e1211205619510 ∧ code e1211205619510 = 5609252130614 := by decide
theorem cert_e1211205619510 : check e1211205619510 [[],[]] .chain = true := by decide
def e1211205619514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211205619514 : Closed e1211205619514 ∧ code e1211205619514 = 5609252130618 := by decide
theorem cert_e1211205619514 : check e1211205619514 [[],[]] .chain = true := by decide
def e1211205619598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e1211205619598 : Closed e1211205619598 ∧ code e1211205619598 = 5609252130702 := by decide
theorem cert_e1211205619598 : check e1211205619598 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1211205626710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e1211205626710 : Closed e1211205626710 ∧ code e1211205626710 = 5609252137814 := by decide
theorem cert_e1211205626710 : check e1211205626710 [[],[]] .chain = true := by decide
def e1211205626714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e1211205626714 : Closed e1211205626714 ∧ code e1211205626714 = 5609252137818 := by decide
theorem cert_e1211205626714 : check e1211205626714 [[],[]] .chain = true := by decide
def e1211205626730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e1211205626730 : Closed e1211205626730 ∧ code e1211205626730 = 5609252137834 := by decide
theorem cert_e1211205626730 : check e1211205626730 [[],[]] .chain = true := by decide
def e1211205626794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e1211205626794 : Closed e1211205626794 ∧ code e1211205626794 = 5609252137898 := by decide
theorem cert_e1211205626794 : check e1211205626794 [[],[]] .chain = true := by decide
def e1211205626902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211205626902 : Closed e1211205626902 ∧ code e1211205626902 = 5609252138006 := by decide
theorem cert_e1211205626902 : check e1211205626902 [[],[]] .chain = true := by decide
def e1211205626906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211205626906 : Closed e1211205626906 ∧ code e1211205626906 = 5609252138010 := by decide
theorem cert_e1211205626906 : check e1211205626906 [[],[]] .chain = true := by decide
def e1211205626950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211205626950 : Closed e1211205626950 ∧ code e1211205626950 = 5609252138054 := by decide
theorem cert_e1211205626950 : check e1211205626950 [[],[]] .chain = true := by decide
def e1211205626978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211205626978 : Closed e1211205626978 ∧ code e1211205626978 = 5609252138082 := by decide
theorem cert_e1211205626978 : check e1211205626978 [[],[]] .chain = true := by decide
def e1211205626990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211205626990 : Closed e1211205626990 ∧ code e1211205626990 = 5609252138094 := by decide
theorem cert_e1211205626990 : check e1211205626990 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205626998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e1211205626998 : Closed e1211205626998 ∧ code e1211205626998 = 5609252138102 := by decide
theorem cert_e1211205626998 : check e1211205626998 [[],[]] .chain = true := by decide
def e1211205627002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211205627002 : Closed e1211205627002 ∧ code e1211205627002 = 5609252138106 := by decide
theorem cert_e1211205627002 : check e1211205627002 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1211205627094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e1211205627094 : Closed e1211205627094 ∧ code e1211205627094 = 5609252138198 := by decide
theorem cert_e1211205627094 : check e1211205627094 [[],[]] .chain = true := by decide
end Blc.Floor42
