import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e305815883574 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e305815883574 : Closed e305815883574 ∧ code e305815883574 = 4703862394678 := by decide
theorem cert_e305815883574 : check e305815883574 [[.under]] .sourceHead = true := by decide
def e305815883578 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e305815883578 : Closed e305815883578 ∧ code e305815883578 = 4703862394682 := by decide
theorem cert_e305815883578 : check e305815883578 [[.under]] .sourceHead = true := by decide
def e350063805210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350063805210 : Closed e350063805210 ∧ code e350063805210 = 4748110316314 := by decide
theorem cert_e350063805210 : check e350063805210 [[.under,.left]] .width = true := by decide
def e350063870746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350063870746 : Closed e350063870746 ∧ code e350063870746 = 4748110381850 := by decide
theorem cert_e350063870746 : check e350063870746 [[.under,.left]] .width = true := by decide
def e350064329498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350064329498 : Closed e350064329498 ∧ code e350064329498 = 4748110840602 := by decide
theorem cert_e350064329498 : check e350064329498 [[.under,.left]] .width = true := by decide
def e350064427802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350064427802 : Closed e350064427802 ∧ code e350064427802 = 4748110938906 := by decide
theorem cert_e350064427802 : check e350064427802 [[.under,.left]] .width = true := by decide
def e350064657178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350064657178 : Closed e350064657178 ∧ code e350064657178 = 4748111168282 := by decide
theorem cert_e350064657178 : check e350064657178 [[.under,.left]] .width = true := by decide
def e350064689946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350064689946 : Closed e350064689946 ∧ code e350064689946 = 4748111201050 := by decide
theorem cert_e350064689946 : check e350064689946 [[.under,.left]] .width = true := by decide
def e350066950938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350066950938 : Closed e350066950938 ∧ code e350066950938 = 4748113462042 := by decide
theorem cert_e350066950938 : check e350066950938 [[.under,.left]] .width = true := by decide
def e350067016474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350067016474 : Closed e350067016474 ∧ code e350067016474 = 4748113527578 := by decide
theorem cert_e350067016474 : check e350067016474 [[.under,.left]] .width = true := by decide
def e350070096666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350070096666 : Closed e350070096666 ∧ code e350070096666 = 4748116607770 := by decide
theorem cert_e350070096666 : check e350070096666 [[.under,.left]] .width = true := by decide
def e350070194970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350070194970 : Closed e350070194970 ∧ code e350070194970 = 4748116706074 := by decide
theorem cert_e350070194970 : check e350070194970 [[.under,.left]] .width = true := by decide
def e350071735066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350071735066 : Closed e350071735066 ∧ code e350071735066 = 4748118246170 := by decide
theorem cert_e350071735066 : check e350071735066 [[.under,.left]] .width = true := by decide
def e350071767834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e350071767834 : Closed e350071767834 ∧ code e350071767834 = 4748118278938 := by decide
theorem cert_e350071767834 : check e350071767834 [[.under,.left]] .width = true := by decide
def e350241338810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e350241338810 : Closed e350241338810 ∧ code e350241338810 = 4748287849914 := by decide
theorem cert_e350241338810 : check e350241338810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241338842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e350241338842 : Closed e350241338842 ∧ code e350241338842 = 4748287849946 := by decide
theorem cert_e350241338842 : check e350241338842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241339066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e350241339066 : Closed e350241339066 ∧ code e350241339066 = 4748287850170 := by decide
theorem cert_e350241339066 : check e350241339066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241339114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e350241339114 : Closed e350241339114 ∧ code e350241339114 = 4748287850218 := by decide
theorem cert_e350241339114 : check e350241339114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241339226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e350241339226 : Closed e350241339226 ∧ code e350241339226 = 4748287850330 := by decide
theorem cert_e350241339226 : check e350241339226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241339242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e350241339242 : Closed e350241339242 ∧ code e350241339242 = 4748287850346 := by decide
theorem cert_e350241339242 : check e350241339242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241340090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e350241340090 : Closed e350241340090 ∧ code e350241340090 = 4748287851194 := by decide
theorem cert_e350241340090 : check e350241340090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241340138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e350241340138 : Closed e350241340138 ∧ code e350241340138 = 4748287851242 := by decide
theorem cert_e350241340138 : check e350241340138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241340330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e350241340330 : Closed e350241340330 ∧ code e350241340330 = 4748287851434 := by decide
theorem cert_e350241340330 : check e350241340330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241340762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e350241340762 : Closed e350241340762 ∧ code e350241340762 = 4748287851866 := by decide
theorem cert_e350241340762 : check e350241340762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241340778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e350241340778 : Closed e350241340778 ∧ code e350241340778 = 4748287851882 := by decide
theorem cert_e350241340778 : check e350241340778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241340842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e350241340842 : Closed e350241340842 ∧ code e350241340842 = 4748287851946 := by decide
theorem cert_e350241340842 : check e350241340842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241344954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e350241344954 : Closed e350241344954 ∧ code e350241344954 = 4748287856058 := by decide
theorem cert_e350241344954 : check e350241344954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241344986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e350241344986 : Closed e350241344986 ∧ code e350241344986 = 4748287856090 := by decide
theorem cert_e350241344986 : check e350241344986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241345210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e350241345210 : Closed e350241345210 ∧ code e350241345210 = 4748287856314 := by decide
theorem cert_e350241345210 : check e350241345210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241345258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e350241345258 : Closed e350241345258 ∧ code e350241345258 = 4748287856362 := by decide
theorem cert_e350241345258 : check e350241345258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241345370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e350241345370 : Closed e350241345370 ∧ code e350241345370 = 4748287856474 := by decide
theorem cert_e350241345370 : check e350241345370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241345386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e350241345386 : Closed e350241345386 ∧ code e350241345386 = 4748287856490 := by decide
theorem cert_e350241345386 : check e350241345386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241346490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e350241346490 : Closed e350241346490 ∧ code e350241346490 = 4748287857594 := by decide
theorem cert_e350241346490 : check e350241346490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241346522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e350241346522 : Closed e350241346522 ∧ code e350241346522 = 4748287857626 := by decide
theorem cert_e350241346522 : check e350241346522 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241348026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e350241348026 : Closed e350241348026 ∧ code e350241348026 = 4748287859130 := by decide
theorem cert_e350241348026 : check e350241348026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241348074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e350241348074 : Closed e350241348074 ∧ code e350241348074 = 4748287859178 := by decide
theorem cert_e350241348074 : check e350241348074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241348826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e350241348826 : Closed e350241348826 ∧ code e350241348826 = 4748287859930 := by decide
theorem cert_e350241348826 : check e350241348826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241348842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e350241348842 : Closed e350241348842 ∧ code e350241348842 = 4748287859946 := by decide
theorem cert_e350241348842 : check e350241348842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241351354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e350241351354 : Closed e350241351354 ∧ code e350241351354 = 4748287862458 := by decide
theorem cert_e350241351354 : check e350241351354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241351402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e350241351402 : Closed e350241351402 ∧ code e350241351402 = 4748287862506 := by decide
theorem cert_e350241351402 : check e350241351402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241351594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e350241351594 : Closed e350241351594 ∧ code e350241351594 = 4748287862698 := by decide
theorem cert_e350241351594 : check e350241351594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241352122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e350241352122 : Closed e350241352122 ∧ code e350241352122 = 4748287863226 := by decide
theorem cert_e350241352122 : check e350241352122 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241352170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e350241352170 : Closed e350241352170 ∧ code e350241352170 = 4748287863274 := by decide
theorem cert_e350241352170 : check e350241352170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241353322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e350241353322 : Closed e350241353322 ∧ code e350241353322 = 4748287864426 := by decide
theorem cert_e350241353322 : check e350241353322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241354586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e350241354586 : Closed e350241354586 ∧ code e350241354586 = 4748287865690 := by decide
theorem cert_e350241354586 : check e350241354586 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241354602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e350241354602 : Closed e350241354602 ∧ code e350241354602 = 4748287865706 := by decide
theorem cert_e350241354602 : check e350241354602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241354666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e350241354666 : Closed e350241354666 ∧ code e350241354666 = 4748287865770 := by decide
theorem cert_e350241354666 : check e350241354666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241354970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e350241354970 : Closed e350241354970 ∧ code e350241354970 = 4748287866074 := by decide
theorem cert_e350241354970 : check e350241354970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241354986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e350241354986 : Closed e350241354986 ∧ code e350241354986 = 4748287866090 := by decide
theorem cert_e350241354986 : check e350241354986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241355370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e350241355370 : Closed e350241355370 ∧ code e350241355370 = 4748287866474 := by decide
theorem cert_e350241355370 : check e350241355370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241369530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e350241369530 : Closed e350241369530 ∧ code e350241369530 = 4748287880634 := by decide
theorem cert_e350241369530 : check e350241369530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241369562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e350241369562 : Closed e350241369562 ∧ code e350241369562 = 4748287880666 := by decide
theorem cert_e350241369562 : check e350241369562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241369786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e350241369786 : Closed e350241369786 ∧ code e350241369786 = 4748287880890 := by decide
theorem cert_e350241369786 : check e350241369786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241369834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e350241369834 : Closed e350241369834 ∧ code e350241369834 = 4748287880938 := by decide
theorem cert_e350241369834 : check e350241369834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241369946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350241369946 : Closed e350241369946 ∧ code e350241369946 = 4748287881050 := by decide
theorem cert_e350241369946 : check e350241369946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241369962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350241369962 : Closed e350241369962 ∧ code e350241369962 = 4748287881066 := by decide
theorem cert_e350241369962 : check e350241369962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241371066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e350241371066 : Closed e350241371066 ∧ code e350241371066 = 4748287882170 := by decide
theorem cert_e350241371066 : check e350241371066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241371098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e350241371098 : Closed e350241371098 ∧ code e350241371098 = 4748287882202 := by decide
theorem cert_e350241371098 : check e350241371098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241372602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e350241372602 : Closed e350241372602 ∧ code e350241372602 = 4748287883706 := by decide
theorem cert_e350241372602 : check e350241372602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241372650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e350241372650 : Closed e350241372650 ∧ code e350241372650 = 4748287883754 := by decide
theorem cert_e350241372650 : check e350241372650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241373402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350241373402 : Closed e350241373402 ∧ code e350241373402 = 4748287884506 := by decide
theorem cert_e350241373402 : check e350241373402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241373418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350241373418 : Closed e350241373418 ∧ code e350241373418 = 4748287884522 := by decide
theorem cert_e350241373418 : check e350241373418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241396410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e350241396410 : Closed e350241396410 ∧ code e350241396410 = 4748287907514 := by decide
theorem cert_e350241396410 : check e350241396410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241396458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e350241396458 : Closed e350241396458 ∧ code e350241396458 = 4748287907562 := by decide
theorem cert_e350241396458 : check e350241396458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241396650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e350241396650 : Closed e350241396650 ∧ code e350241396650 = 4748287907754 := by decide
theorem cert_e350241396650 : check e350241396650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241397178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e350241397178 : Closed e350241397178 ∧ code e350241397178 = 4748287908282 := by decide
theorem cert_e350241397178 : check e350241397178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241397226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e350241397226 : Closed e350241397226 ∧ code e350241397226 = 4748287908330 := by decide
theorem cert_e350241397226 : check e350241397226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241398378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e350241398378 : Closed e350241398378 ∧ code e350241398378 = 4748287909482 := by decide
theorem cert_e350241398378 : check e350241398378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241409882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350241409882 : Closed e350241409882 ∧ code e350241409882 = 4748287920986 := by decide
theorem cert_e350241409882 : check e350241409882 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241409898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350241409898 : Closed e350241409898 ∧ code e350241409898 = 4748287921002 := by decide
theorem cert_e350241409898 : check e350241409898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241409962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e350241409962 : Closed e350241409962 ∧ code e350241409962 = 4748287921066 := by decide
theorem cert_e350241409962 : check e350241409962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241410266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350241410266 : Closed e350241410266 ∧ code e350241410266 = 4748287921370 := by decide
theorem cert_e350241410266 : check e350241410266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241410282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350241410282 : Closed e350241410282 ∧ code e350241410282 = 4748287921386 := by decide
theorem cert_e350241410282 : check e350241410282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241410666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e350241410666 : Closed e350241410666 ∧ code e350241410666 = 4748287921770 := by decide
theorem cert_e350241410666 : check e350241410666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241959354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e350241959354 : Closed e350241959354 ∧ code e350241959354 = 4748288470458 := by decide
theorem cert_e350241959354 : check e350241959354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241959386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e350241959386 : Closed e350241959386 ∧ code e350241959386 = 4748288470490 := by decide
theorem cert_e350241959386 : check e350241959386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241959610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e350241959610 : Closed e350241959610 ∧ code e350241959610 = 4748288470714 := by decide
theorem cert_e350241959610 : check e350241959610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241959658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e350241959658 : Closed e350241959658 ∧ code e350241959658 = 4748288470762 := by decide
theorem cert_e350241959658 : check e350241959658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241959770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350241959770 : Closed e350241959770 ∧ code e350241959770 = 4748288470874 := by decide
theorem cert_e350241959770 : check e350241959770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241959786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350241959786 : Closed e350241959786 ∧ code e350241959786 = 4748288470890 := by decide
theorem cert_e350241959786 : check e350241959786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241960890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e350241960890 : Closed e350241960890 ∧ code e350241960890 = 4748288471994 := by decide
theorem cert_e350241960890 : check e350241960890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241960922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e350241960922 : Closed e350241960922 ∧ code e350241960922 = 4748288472026 := by decide
theorem cert_e350241960922 : check e350241960922 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241962426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e350241962426 : Closed e350241962426 ∧ code e350241962426 = 4748288473530 := by decide
theorem cert_e350241962426 : check e350241962426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241962474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e350241962474 : Closed e350241962474 ∧ code e350241962474 = 4748288473578 := by decide
theorem cert_e350241962474 : check e350241962474 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241963226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350241963226 : Closed e350241963226 ∧ code e350241963226 = 4748288474330 := by decide
theorem cert_e350241963226 : check e350241963226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350241963242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350241963242 : Closed e350241963242 ∧ code e350241963242 = 4748288474346 := by decide
theorem cert_e350241963242 : check e350241963242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350244318650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e350244318650 : Closed e350244318650 ∧ code e350244318650 = 4748290829754 := by decide
theorem cert_e350244318650 : check e350244318650 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244318682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e350244318682 : Closed e350244318682 ∧ code e350244318682 = 4748290829786 := by decide
theorem cert_e350244318682 : check e350244318682 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244318906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e350244318906 : Closed e350244318906 ∧ code e350244318906 = 4748290830010 := by decide
theorem cert_e350244318906 : check e350244318906 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244318954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e350244318954 : Closed e350244318954 ∧ code e350244318954 = 4748290830058 := by decide
theorem cert_e350244318954 : check e350244318954 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244319066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350244319066 : Closed e350244319066 ∧ code e350244319066 = 4748290830170 := by decide
theorem cert_e350244319066 : check e350244319066 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244319082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350244319082 : Closed e350244319082 ∧ code e350244319082 = 4748290830186 := by decide
theorem cert_e350244319082 : check e350244319082 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244320186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e350244320186 : Closed e350244320186 ∧ code e350244320186 = 4748290831290 := by decide
theorem cert_e350244320186 : check e350244320186 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244320218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e350244320218 : Closed e350244320218 ∧ code e350244320218 = 4748290831322 := by decide
theorem cert_e350244320218 : check e350244320218 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244321722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e350244321722 : Closed e350244321722 ∧ code e350244321722 = 4748290832826 := by decide
theorem cert_e350244321722 : check e350244321722 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244321770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e350244321770 : Closed e350244321770 ∧ code e350244321770 = 4748290832874 := by decide
theorem cert_e350244321770 : check e350244321770 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244322522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350244322522 : Closed e350244322522 ∧ code e350244322522 = 4748290833626 := by decide
theorem cert_e350244322522 : check e350244322522 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350244322538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350244322538 : Closed e350244322538 ∧ code e350244322538 = 4748290833642 := by decide
theorem cert_e350244322538 : check e350244322538 [[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577060730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))) (.var 0)))
theorem wire_e350577060730 : Closed e350577060730 ∧ code e350577060730 = 4748623571834 := by decide
theorem cert_e350577060730 : check e350577060730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577060826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))) (.var 0)))
theorem wire_e350577060826 : Closed e350577060826 ∧ code e350577060826 = 4748623571930 := by decide
theorem cert_e350577060826 : check e350577060826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577061242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))) (.var 0)))
theorem wire_e350577061242 : Closed e350577061242 ∧ code e350577061242 = 4748623572346 := by decide
theorem cert_e350577061242 : check e350577061242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577061306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e350577061306 : Closed e350577061306 ∧ code e350577061306 = 4748623572410 := by decide
theorem cert_e350577061306 : check e350577061306 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577061338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e350577061338 : Closed e350577061338 ∧ code e350577061338 = 4748623572442 := by decide
theorem cert_e350577061338 : check e350577061338 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577061354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))) (.var 0)))
theorem wire_e350577061354 : Closed e350577061354 ∧ code e350577061354 = 4748623572458 := by decide
theorem cert_e350577061354 : check e350577061354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577061594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e350577061594 : Closed e350577061594 ∧ code e350577061594 = 4748623572698 := by decide
theorem cert_e350577061594 : check e350577061594 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577061722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350577061722 : Closed e350577061722 ∧ code e350577061722 = 4748623572826 := by decide
theorem cert_e350577061722 : check e350577061722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577061738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350577061738 : Closed e350577061738 ∧ code e350577061738 = 4748623572842 := by decide
theorem cert_e350577061738 : check e350577061738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577063290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))) (.var 0)))
theorem wire_e350577063290 : Closed e350577063290 ∧ code e350577063290 = 4748623574394 := by decide
theorem cert_e350577063290 : check e350577063290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577063354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e350577063354 : Closed e350577063354 ∧ code e350577063354 = 4748623574458 := by decide
theorem cert_e350577063354 : check e350577063354 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577063386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e350577063386 : Closed e350577063386 ∧ code e350577063386 = 4748623574490 := by decide
theorem cert_e350577063386 : check e350577063386 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577063402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))) (.var 0)))
theorem wire_e350577063402 : Closed e350577063402 ∧ code e350577063402 = 4748623574506 := by decide
theorem cert_e350577063402 : check e350577063402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577063610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e350577063610 : Closed e350577063610 ∧ code e350577063610 = 4748623574714 := by decide
theorem cert_e350577063610 : check e350577063610 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577063658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e350577063658 : Closed e350577063658 ∧ code e350577063658 = 4748623574762 := by decide
theorem cert_e350577063658 : check e350577063658 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577063770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350577063770 : Closed e350577063770 ∧ code e350577063770 = 4748623574874 := by decide
theorem cert_e350577063770 : check e350577063770 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577063786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350577063786 : Closed e350577063786 ∧ code e350577063786 = 4748623574890 := by decide
theorem cert_e350577063786 : check e350577063786 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577063850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e350577063850 : Closed e350577063850 ∧ code e350577063850 = 4748623574954 := by decide
theorem cert_e350577063850 : check e350577063850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577064666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e350577064666 : Closed e350577064666 ∧ code e350577064666 = 4748623575770 := by decide
theorem cert_e350577064666 : check e350577064666 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577064794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350577064794 : Closed e350577064794 ∧ code e350577064794 = 4748623575898 := by decide
theorem cert_e350577064794 : check e350577064794 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577064810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350577064810 : Closed e350577064810 ∧ code e350577064810 = 4748623575914 := by decide
theorem cert_e350577064810 : check e350577064810 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577065306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e350577065306 : Closed e350577065306 ∧ code e350577065306 = 4748623576410 := by decide
theorem cert_e350577065306 : check e350577065306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577065322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e350577065322 : Closed e350577065322 ∧ code e350577065322 = 4748623576426 := by decide
theorem cert_e350577065322 : check e350577065322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577065386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e350577065386 : Closed e350577065386 ∧ code e350577065386 = 4748623576490 := by decide
theorem cert_e350577065386 : check e350577065386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577073018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))) (.var 0)))
theorem wire_e350577073018 : Closed e350577073018 ∧ code e350577073018 = 4748623584122 := by decide
theorem cert_e350577073018 : check e350577073018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577073114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e350577073114 : Closed e350577073114 ∧ code e350577073114 = 4748623584218 := by decide
theorem cert_e350577073114 : check e350577073114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577073530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))) (.var 0)))
theorem wire_e350577073530 : Closed e350577073530 ∧ code e350577073530 = 4748623584634 := by decide
theorem cert_e350577073530 : check e350577073530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577073594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e350577073594 : Closed e350577073594 ∧ code e350577073594 = 4748623584698 := by decide
theorem cert_e350577073594 : check e350577073594 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577073626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e350577073626 : Closed e350577073626 ∧ code e350577073626 = 4748623584730 := by decide
theorem cert_e350577073626 : check e350577073626 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577073642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e350577073642 : Closed e350577073642 ∧ code e350577073642 = 4748623584746 := by decide
theorem cert_e350577073642 : check e350577073642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577073882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e350577073882 : Closed e350577073882 ∧ code e350577073882 = 4748623584986 := by decide
theorem cert_e350577073882 : check e350577073882 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577074010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e350577074010 : Closed e350577074010 ∧ code e350577074010 = 4748623585114 := by decide
theorem cert_e350577074010 : check e350577074010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577074026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e350577074026 : Closed e350577074026 ∧ code e350577074026 = 4748623585130 := by decide
theorem cert_e350577074026 : check e350577074026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577076090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))) (.var 0)))
theorem wire_e350577076090 : Closed e350577076090 ∧ code e350577076090 = 4748623587194 := by decide
theorem cert_e350577076090 : check e350577076090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577076186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))) (.var 0)))
theorem wire_e350577076186 : Closed e350577076186 ∧ code e350577076186 = 4748623587290 := by decide
theorem cert_e350577076186 : check e350577076186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577079162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))) (.var 0)))
theorem wire_e350577079162 : Closed e350577079162 ∧ code e350577079162 = 4748623590266 := by decide
theorem cert_e350577079162 : check e350577079162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577079226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e350577079226 : Closed e350577079226 ∧ code e350577079226 = 4748623590330 := by decide
theorem cert_e350577079226 : check e350577079226 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577079258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e350577079258 : Closed e350577079258 ∧ code e350577079258 = 4748623590362 := by decide
theorem cert_e350577079258 : check e350577079258 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577079274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))) (.var 0)))
theorem wire_e350577079274 : Closed e350577079274 ∧ code e350577079274 = 4748623590378 := by decide
theorem cert_e350577079274 : check e350577079274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577080794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e350577080794 : Closed e350577080794 ∧ code e350577080794 = 4748623591898 := by decide
theorem cert_e350577080794 : check e350577080794 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577081562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350577081562 : Closed e350577081562 ∧ code e350577081562 = 4748623592666 := by decide
theorem cert_e350577081562 : check e350577081562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577081578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350577081578 : Closed e350577081578 ∧ code e350577081578 = 4748623592682 := by decide
theorem cert_e350577081578 : check e350577081578 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577085818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))) (.var 0)))
theorem wire_e350577085818 : Closed e350577085818 ∧ code e350577085818 = 4748623596922 := by decide
theorem cert_e350577085818 : check e350577085818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577085882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e350577085882 : Closed e350577085882 ∧ code e350577085882 = 4748623596986 := by decide
theorem cert_e350577085882 : check e350577085882 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577085914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e350577085914 : Closed e350577085914 ∧ code e350577085914 = 4748623597018 := by decide
theorem cert_e350577085914 : check e350577085914 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577085930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e350577085930 : Closed e350577085930 ∧ code e350577085930 = 4748623597034 := by decide
theorem cert_e350577085930 : check e350577085930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577086138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e350577086138 : Closed e350577086138 ∧ code e350577086138 = 4748623597242 := by decide
theorem cert_e350577086138 : check e350577086138 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577086186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e350577086186 : Closed e350577086186 ∧ code e350577086186 = 4748623597290 := by decide
theorem cert_e350577086186 : check e350577086186 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577086298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e350577086298 : Closed e350577086298 ∧ code e350577086298 = 4748623597402 := by decide
theorem cert_e350577086298 : check e350577086298 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577086314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e350577086314 : Closed e350577086314 ∧ code e350577086314 = 4748623597418 := by decide
theorem cert_e350577086314 : check e350577086314 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577086378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e350577086378 : Closed e350577086378 ∧ code e350577086378 = 4748623597482 := by decide
theorem cert_e350577086378 : check e350577086378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577087354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))) (.var 0)))
theorem wire_e350577087354 : Closed e350577087354 ∧ code e350577087354 = 4748623598458 := by decide
theorem cert_e350577087354 : check e350577087354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577087418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e350577087418 : Closed e350577087418 ∧ code e350577087418 = 4748623598522 := by decide
theorem cert_e350577087418 : check e350577087418 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577087450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e350577087450 : Closed e350577087450 ∧ code e350577087450 = 4748623598554 := by decide
theorem cert_e350577087450 : check e350577087450 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577087466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))) (.var 0)))
theorem wire_e350577087466 : Closed e350577087466 ∧ code e350577087466 = 4748623598570 := by decide
theorem cert_e350577087466 : check e350577087466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577088954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e350577088954 : Closed e350577088954 ∧ code e350577088954 = 4748623600058 := by decide
theorem cert_e350577088954 : check e350577088954 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577089002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e350577089002 : Closed e350577089002 ∧ code e350577089002 = 4748623600106 := by decide
theorem cert_e350577089002 : check e350577089002 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577089754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e350577089754 : Closed e350577089754 ∧ code e350577089754 = 4748623600858 := by decide
theorem cert_e350577089754 : check e350577089754 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577089770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e350577089770 : Closed e350577089770 ∧ code e350577089770 = 4748623600874 := by decide
theorem cert_e350577089770 : check e350577089770 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577090154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e350577090154 : Closed e350577090154 ∧ code e350577090154 = 4748623601258 := by decide
theorem cert_e350577090154 : check e350577090154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e350577092314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e350577092314 : Closed e350577092314 ∧ code e350577092314 = 4748623603418 := by decide
theorem cert_e350577092314 : check e350577092314 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e350577092442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e350577092442 : Closed e350577092442 ∧ code e350577092442 = 4748623603546 := by decide
theorem cert_e350577092442 : check e350577092442 [[.under,.left],[.under,.left]] .smaller = true := by decide
end Blc.Floor42
