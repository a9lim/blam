import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211589746542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e1211589746542 : Closed e1211589746542 ∧ code e1211589746542 = 5609636257646 := by decide
private def t_e1211589746542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem cert_e1211589746542 : ¬ IsSelfInterpreter e1211589746542 :=
  wSource (t := t_e1211589746542) (replay_sound (ps := []) (t := e1211589746542) (by decide)) (by decide)
def e1211589746550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e1211589746550 : Closed e1211589746550 ∧ code e1211589746550 = 5609636257654 := by decide
private def t_e1211589746550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem cert_e1211589746550 : ¬ IsSelfInterpreter e1211589746550 :=
  wSource (t := t_e1211589746550) (replay_sound (ps := []) (t := e1211589746550) (by decide)) (by decide)
def e1211589748510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e1211589748510 : Closed e1211589748510 ∧ code e1211589748510 = 5609636259614 := by decide
theorem cert_e1211589748510 : check e1211589748510 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211589748622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e1211589748622 : Closed e1211589748622 ∧ code e1211589748622 = 5609636259726 := by decide
theorem cert_e1211589748622 : check e1211589748622 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211589751582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e1211589751582 : Closed e1211589751582 ∧ code e1211589751582 = 5609636262686 := by decide
theorem cert_e1211589751582 : checkPay e1211589751582 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e1211589751750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e1211589751750 : Closed e1211589751750 ∧ code e1211589751750 = 5609636262854 := by decide
theorem cert_e1211589751750 : check e1211589751750 [[],[],[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e1211589751774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211589751774 : Closed e1211589751774 ∧ code e1211589751774 = 5609636262878 := by decide
private def t_e1211589751774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem cert_e1211589751774 : ¬ IsSelfInterpreter e1211589751774 :=
  wSource (t := t_e1211589751774) (replay_sound (ps := []) (t := e1211589751774) (by decide)) (by decide)
def e1211589751790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211589751790 : Closed e1211589751790 ∧ code e1211589751790 = 5609636262894 := by decide
private def t_e1211589751790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem cert_e1211589751790 : ¬ IsSelfInterpreter e1211589751790 :=
  wSource (t := t_e1211589751790) (replay_sound (ps := []) (t := e1211589751790) (by decide)) (by decide)
def e1211589753230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e1211589753230 : Closed e1211589753230 ∧ code e1211589753230 = 5609636264334 := by decide
theorem cert_e1211589753230 : check e1211589753230 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211589753286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e1211589753286 : Closed e1211589753286 ∧ code e1211589753286 = 5609636264390 := by decide
theorem cert_e1211589753286 : check e1211589753286 [[],[],[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e1211589753310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e1211589753310 : Closed e1211589753310 ∧ code e1211589753310 = 5609636264414 := by decide
private def t_e1211589753310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem cert_e1211589753310 : ¬ IsSelfInterpreter e1211589753310 :=
  wSource (t := t_e1211589753310) (replay_sound (ps := []) (t := e1211589753310) (by decide)) (by decide)
def e1211589753334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e1211589753334 : Closed e1211589753334 ∧ code e1211589753334 = 5609636264438 := by decide
private def t_e1211589753334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem cert_e1211589753334 : ¬ IsSelfInterpreter e1211589753334 :=
  wSource (t := t_e1211589753334) (replay_sound (ps := []) (t := e1211589753334) (by decide)) (by decide)
def e1211589754094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211589754094 : Closed e1211589754094 ∧ code e1211589754094 = 5609636265198 := by decide
private def t_e1211589754094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211589754094 : ¬ IsSelfInterpreter e1211589754094 :=
  wSource (t := t_e1211589754094) (replay_sound (ps := []) (t := e1211589754094) (by decide)) (by decide)
def e1211589754102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211589754102 : Closed e1211589754102 ∧ code e1211589754102 = 5609636265206 := by decide
private def t_e1211589754102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211589754102 : ¬ IsSelfInterpreter e1211589754102 :=
  wSource (t := t_e1211589754102) (replay_sound (ps := []) (t := e1211589754102) (by decide)) (by decide)
def e1211589811054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1211589811054 : Closed e1211589811054 ∧ code e1211589811054 = 5609636322158 := by decide
private def t_e1211589811054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem cert_e1211589811054 : ¬ IsSelfInterpreter e1211589811054 :=
  wSource (t := t_e1211589811054) (replay_sound (ps := []) (t := e1211589811054) (by decide)) (by decide)
def e1211589811062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1211589811062 : Closed e1211589811062 ∧ code e1211589811062 = 5609636322166 := by decide
private def t_e1211589811062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem cert_e1211589811062 : ¬ IsSelfInterpreter e1211589811062 :=
  wSource (t := t_e1211589811062) (replay_sound (ps := []) (t := e1211589811062) (by decide)) (by decide)
def e1211589811126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1211589811126 : Closed e1211589811126 ∧ code e1211589811126 = 5609636322230 := by decide
private def t_e1211589811126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem cert_e1211589811126 : ¬ IsSelfInterpreter e1211589811126 :=
  wSource (t := t_e1211589811126) (replay_sound (ps := []) (t := e1211589811126) (by decide)) (by decide)
def e1211589811566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211589811566 : Closed e1211589811566 ∧ code e1211589811566 = 5609636322670 := by decide
private def t_e1211589811566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem cert_e1211589811566 : ¬ IsSelfInterpreter e1211589811566 :=
  wSource (t := t_e1211589811566) (replay_sound (ps := []) (t := e1211589811566) (by decide)) (by decide)
def e1211589811574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211589811574 : Closed e1211589811574 ∧ code e1211589811574 = 5609636322678 := by decide
private def t_e1211589811574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem cert_e1211589811574 : ¬ IsSelfInterpreter e1211589811574 :=
  wSource (t := t_e1211589811574) (replay_sound (ps := []) (t := e1211589811574) (by decide)) (by decide)
def e1211589811630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211589811630 : Closed e1211589811630 ∧ code e1211589811630 = 5609636322734 := by decide
private def t_e1211589811630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem cert_e1211589811630 : ¬ IsSelfInterpreter e1211589811630 :=
  wSource (t := t_e1211589811630) (replay_sound (ps := []) (t := e1211589811630) (by decide)) (by decide)
def e1211589811642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211589811642 : Closed e1211589811642 ∧ code e1211589811642 = 5609636322746 := by decide
private def t_e1211589811642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem cert_e1211589811642 : ¬ IsSelfInterpreter e1211589811642 :=
  wSource (t := t_e1211589811642) (replay_sound (ps := []) (t := e1211589811642) (by decide)) (by decide)
def e1211589811670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211589811670 : Closed e1211589811670 ∧ code e1211589811670 = 5609636322774 := by decide
private def t_e1211589811670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e1211589811670 : ¬ IsSelfInterpreter e1211589811670 :=
  wSource (t := t_e1211589811670) (replay_sound (ps := []) (t := e1211589811670) (by decide)) (by decide)
def e1211589811674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211589811674 : Closed e1211589811674 ∧ code e1211589811674 = 5609636322778 := by decide
private def t_e1211589811674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e1211589811674 : ¬ IsSelfInterpreter e1211589811674 :=
  wSource (t := t_e1211589811674) (replay_sound (ps := []) (t := e1211589811674) (by decide)) (by decide)
def e1211589811894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1211589811894 : Closed e1211589811894 ∧ code e1211589811894 = 5609636322998 := by decide
private def t_e1211589811894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem cert_e1211589811894 : ¬ IsSelfInterpreter e1211589811894 :=
  wSource (t := t_e1211589811894) (replay_sound (ps := []) (t := e1211589811894) (by decide)) (by decide)
def e1211589811926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1211589811926 : Closed e1211589811926 ∧ code e1211589811926 = 5609636323030 := by decide
private def t_e1211589811926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem cert_e1211589811926 : ¬ IsSelfInterpreter e1211589811926 :=
  wSource (t := t_e1211589811926) (replay_sound (ps := []) (t := e1211589811926) (by decide)) (by decide)
def e1211589811930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1211589811930 : Closed e1211589811930 ∧ code e1211589811930 = 5609636323034 := by decide
private def t_e1211589811930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem cert_e1211589811930 : ¬ IsSelfInterpreter e1211589811930 :=
  wSource (t := t_e1211589811930) (replay_sound (ps := []) (t := e1211589811930) (by decide)) (by decide)
def e1211589814126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1211589814126 : Closed e1211589814126 ∧ code e1211589814126 = 5609636325230 := by decide
private def t_e1211589814126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem cert_e1211589814126 : ¬ IsSelfInterpreter e1211589814126 :=
  wSource (t := t_e1211589814126) (replay_sound (ps := []) (t := e1211589814126) (by decide)) (by decide)
def e1211589814134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1211589814134 : Closed e1211589814134 ∧ code e1211589814134 = 5609636325238 := by decide
private def t_e1211589814134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem cert_e1211589814134 : ¬ IsSelfInterpreter e1211589814134 :=
  wSource (t := t_e1211589814134) (replay_sound (ps := []) (t := e1211589814134) (by decide)) (by decide)
def e1211589814198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1211589814198 : Closed e1211589814198 ∧ code e1211589814198 = 5609636325302 := by decide
private def t_e1211589814198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem cert_e1211589814198 : ¬ IsSelfInterpreter e1211589814198 :=
  wSource (t := t_e1211589814198) (replay_sound (ps := []) (t := e1211589814198) (by decide)) (by decide)
def e1211589815534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211589815534 : Closed e1211589815534 ∧ code e1211589815534 = 5609636326638 := by decide
private def t_e1211589815534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211589815534 : ¬ IsSelfInterpreter e1211589815534 :=
  wSource (t := t_e1211589815534) (replay_sound (ps := []) (t := e1211589815534) (by decide)) (by decide)
def e1211589815542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211589815542 : Closed e1211589815542 ∧ code e1211589815542 = 5609636326646 := by decide
private def t_e1211589815542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211589815542 : ¬ IsSelfInterpreter e1211589815542 :=
  wSource (t := t_e1211589815542) (replay_sound (ps := []) (t := e1211589815542) (by decide)) (by decide)
def e1211589815926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211589815926 : Closed e1211589815926 ∧ code e1211589815926 = 5609636327030 := by decide
private def t_e1211589815926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem cert_e1211589815926 : ¬ IsSelfInterpreter e1211589815926 :=
  wSource (t := t_e1211589815926) (replay_sound (ps := []) (t := e1211589815926) (by decide)) (by decide)
def e1211589817198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211589817198 : Closed e1211589817198 ∧ code e1211589817198 = 5609636328302 := by decide
private def t_e1211589817198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem cert_e1211589817198 : ¬ IsSelfInterpreter e1211589817198 :=
  wSource (t := t_e1211589817198) (replay_sound (ps := []) (t := e1211589817198) (by decide)) (by decide)
def e1211589817206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211589817206 : Closed e1211589817206 ∧ code e1211589817206 = 5609636328310 := by decide
private def t_e1211589817206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem cert_e1211589817206 : ¬ IsSelfInterpreter e1211589817206 :=
  wSource (t := t_e1211589817206) (replay_sound (ps := []) (t := e1211589817206) (by decide)) (by decide)
def e1211589817262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211589817262 : Closed e1211589817262 ∧ code e1211589817262 = 5609636328366 := by decide
private def t_e1211589817262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem cert_e1211589817262 : ¬ IsSelfInterpreter e1211589817262 :=
  wSource (t := t_e1211589817262) (replay_sound (ps := []) (t := e1211589817262) (by decide)) (by decide)
def e1211589817274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211589817274 : Closed e1211589817274 ∧ code e1211589817274 = 5609636328378 := by decide
private def t_e1211589817274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem cert_e1211589817274 : ¬ IsSelfInterpreter e1211589817274 :=
  wSource (t := t_e1211589817274) (replay_sound (ps := []) (t := e1211589817274) (by decide)) (by decide)
def e1211589817302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211589817302 : Closed e1211589817302 ∧ code e1211589817302 = 5609636328406 := by decide
private def t_e1211589817302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem cert_e1211589817302 : ¬ IsSelfInterpreter e1211589817302 :=
  wSource (t := t_e1211589817302) (replay_sound (ps := []) (t := e1211589817302) (by decide)) (by decide)
def e1211589817306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211589817306 : Closed e1211589817306 ∧ code e1211589817306 = 5609636328410 := by decide
private def t_e1211589817306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem cert_e1211589817306 : ¬ IsSelfInterpreter e1211589817306 :=
  wSource (t := t_e1211589817306) (replay_sound (ps := []) (t := e1211589817306) (by decide)) (by decide)
def e1211589817582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211589817582 : Closed e1211589817582 ∧ code e1211589817582 = 5609636328686 := by decide
private def t_e1211589817582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211589817582 : ¬ IsSelfInterpreter e1211589817582 :=
  wSource (t := t_e1211589817582) (replay_sound (ps := []) (t := e1211589817582) (by decide)) (by decide)
def e1211589817590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211589817590 : Closed e1211589817590 ∧ code e1211589817590 = 5609636328694 := by decide
private def t_e1211589817590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211589817590 : ¬ IsSelfInterpreter e1211589817590 :=
  wSource (t := t_e1211589817590) (replay_sound (ps := []) (t := e1211589817590) (by decide)) (by decide)
def e1211589817966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211589817966 : Closed e1211589817966 ∧ code e1211589817966 = 5609636329070 := by decide
private def t_e1211589817966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211589817966 : ¬ IsSelfInterpreter e1211589817966 :=
  wSource (t := t_e1211589817966) (replay_sound (ps := []) (t := e1211589817966) (by decide)) (by decide)
def e1211589817978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211589817978 : Closed e1211589817978 ∧ code e1211589817978 = 5609636329082 := by decide
private def t_e1211589817978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211589817978 : ¬ IsSelfInterpreter e1211589817978 :=
  wSource (t := t_e1211589817978) (replay_sound (ps := []) (t := e1211589817978) (by decide)) (by decide)
def e1211589818166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211589818166 : Closed e1211589818166 ∧ code e1211589818166 = 5609636329270 := by decide
private def t_e1211589818166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211589818166 : ¬ IsSelfInterpreter e1211589818166 :=
  wSource (t := t_e1211589818166) (replay_sound (ps := []) (t := e1211589818166) (by decide)) (by decide)
def e1211589818170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211589818170 : Closed e1211589818170 ∧ code e1211589818170 = 5609636329274 := by decide
private def t_e1211589818170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211589818170 : ¬ IsSelfInterpreter e1211589818170 :=
  wSource (t := t_e1211589818170) (replay_sound (ps := []) (t := e1211589818170) (by decide)) (by decide)
def e1211589818806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1211589818806 : Closed e1211589818806 ∧ code e1211589818806 = 5609636329910 := by decide
private def t_e1211589818806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem cert_e1211589818806 : ¬ IsSelfInterpreter e1211589818806 :=
  wSource (t := t_e1211589818806) (replay_sound (ps := []) (t := e1211589818806) (by decide)) (by decide)
def e1211589818838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1211589818838 : Closed e1211589818838 ∧ code e1211589818838 = 5609636329942 := by decide
private def t_e1211589818838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem cert_e1211589818838 : ¬ IsSelfInterpreter e1211589818838 :=
  wSource (t := t_e1211589818838) (replay_sound (ps := []) (t := e1211589818838) (by decide)) (by decide)
def e1211589818842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1211589818842 : Closed e1211589818842 ∧ code e1211589818842 = 5609636329946 := by decide
private def t_e1211589818842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem cert_e1211589818842 : ¬ IsSelfInterpreter e1211589818842 :=
  wSource (t := t_e1211589818842) (replay_sound (ps := []) (t := e1211589818842) (by decide)) (by decide)
def e1211589818998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1211589818998 : Closed e1211589818998 ∧ code e1211589818998 = 5609636330102 := by decide
private def t_e1211589818998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem cert_e1211589818998 : ¬ IsSelfInterpreter e1211589818998 :=
  wSource (t := t_e1211589818998) (replay_sound (ps := []) (t := e1211589818998) (by decide)) (by decide)
def e1211589819190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211589819190 : Closed e1211589819190 ∧ code e1211589819190 = 5609636330294 := by decide
private def t_e1211589819190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211589819190 : ¬ IsSelfInterpreter e1211589819190 :=
  wSource (t := t_e1211589819190) (replay_sound (ps := []) (t := e1211589819190) (by decide)) (by decide)
def e1211589819194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211589819194 : Closed e1211589819194 ∧ code e1211589819194 = 5609636330298 := by decide
private def t_e1211589819194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211589819194 : ¬ IsSelfInterpreter e1211589819194 :=
  wSource (t := t_e1211589819194) (replay_sound (ps := []) (t := e1211589819194) (by decide)) (by decide)
def e1211589826414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e1211589826414 : Closed e1211589826414 ∧ code e1211589826414 = 5609636337518 := by decide
private def t_e1211589826414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem cert_e1211589826414 : ¬ IsSelfInterpreter e1211589826414 :=
  wSource (t := t_e1211589826414) (replay_sound (ps := []) (t := e1211589826414) (by decide)) (by decide)
def e1211589826422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e1211589826422 : Closed e1211589826422 ∧ code e1211589826422 = 5609636337526 := by decide
private def t_e1211589826422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem cert_e1211589826422 : ¬ IsSelfInterpreter e1211589826422 :=
  wSource (t := t_e1211589826422) (replay_sound (ps := []) (t := e1211589826422) (by decide)) (by decide)
def e1211589826486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e1211589826486 : Closed e1211589826486 ∧ code e1211589826486 = 5609636337590 := by decide
private def t_e1211589826486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem cert_e1211589826486 : ¬ IsSelfInterpreter e1211589826486 :=
  wSource (t := t_e1211589826486) (replay_sound (ps := []) (t := e1211589826486) (by decide)) (by decide)
def e1211589827822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211589827822 : Closed e1211589827822 ∧ code e1211589827822 = 5609636338926 := by decide
private def t_e1211589827822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211589827822 : ¬ IsSelfInterpreter e1211589827822 :=
  wSource (t := t_e1211589827822) (replay_sound (ps := []) (t := e1211589827822) (by decide)) (by decide)
def e1211589827830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211589827830 : Closed e1211589827830 ∧ code e1211589827830 = 5609636338934 := by decide
private def t_e1211589827830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211589827830 : ¬ IsSelfInterpreter e1211589827830 :=
  wSource (t := t_e1211589827830) (replay_sound (ps := []) (t := e1211589827830) (by decide)) (by decide)
def e1211589828214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211589828214 : Closed e1211589828214 ∧ code e1211589828214 = 5609636339318 := by decide
private def t_e1211589828214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem cert_e1211589828214 : ¬ IsSelfInterpreter e1211589828214 :=
  wSource (t := t_e1211589828214) (replay_sound (ps := []) (t := e1211589828214) (by decide)) (by decide)
def e1211589839726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211589839726 : Closed e1211589839726 ∧ code e1211589839726 = 5609636350830 := by decide
private def t_e1211589839726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e1211589839726 : ¬ IsSelfInterpreter e1211589839726 :=
  wSource (t := t_e1211589839726) (replay_sound (ps := []) (t := e1211589839726) (by decide)) (by decide)
def e1211589839734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211589839734 : Closed e1211589839734 ∧ code e1211589839734 = 5609636350838 := by decide
private def t_e1211589839734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e1211589839734 : ¬ IsSelfInterpreter e1211589839734 :=
  wSource (t := t_e1211589839734) (replay_sound (ps := []) (t := e1211589839734) (by decide)) (by decide)
def e1211589839790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211589839790 : Closed e1211589839790 ∧ code e1211589839790 = 5609636350894 := by decide
private def t_e1211589839790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e1211589839790 : ¬ IsSelfInterpreter e1211589839790 :=
  wSource (t := t_e1211589839790) (replay_sound (ps := []) (t := e1211589839790) (by decide)) (by decide)
def e1211589839802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211589839802 : Closed e1211589839802 ∧ code e1211589839802 = 5609636350906 := by decide
private def t_e1211589839802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e1211589839802 : ¬ IsSelfInterpreter e1211589839802 :=
  wSource (t := t_e1211589839802) (replay_sound (ps := []) (t := e1211589839802) (by decide)) (by decide)
def e1211589839830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211589839830 : Closed e1211589839830 ∧ code e1211589839830 = 5609636350934 := by decide
private def t_e1211589839830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e1211589839830 : ¬ IsSelfInterpreter e1211589839830 :=
  wSource (t := t_e1211589839830) (replay_sound (ps := []) (t := e1211589839830) (by decide)) (by decide)
def e1211589839834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211589839834 : Closed e1211589839834 ∧ code e1211589839834 = 5609636350938 := by decide
private def t_e1211589839834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e1211589839834 : ¬ IsSelfInterpreter e1211589839834 :=
  wSource (t := t_e1211589839834) (replay_sound (ps := []) (t := e1211589839834) (by decide)) (by decide)
def e1211589840110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211589840110 : Closed e1211589840110 ∧ code e1211589840110 = 5609636351214 := by decide
private def t_e1211589840110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211589840110 : ¬ IsSelfInterpreter e1211589840110 :=
  wSource (t := t_e1211589840110) (replay_sound (ps := []) (t := e1211589840110) (by decide)) (by decide)
def e1211589840118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211589840118 : Closed e1211589840118 ∧ code e1211589840118 = 5609636351222 := by decide
private def t_e1211589840118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211589840118 : ¬ IsSelfInterpreter e1211589840118 :=
  wSource (t := t_e1211589840118) (replay_sound (ps := []) (t := e1211589840118) (by decide)) (by decide)
def e1211589840494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211589840494 : Closed e1211589840494 ∧ code e1211589840494 = 5609636351598 := by decide
private def t_e1211589840494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211589840494 : ¬ IsSelfInterpreter e1211589840494 :=
  wSource (t := t_e1211589840494) (replay_sound (ps := []) (t := e1211589840494) (by decide)) (by decide)
def e1211589840506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211589840506 : Closed e1211589840506 ∧ code e1211589840506 = 5609636351610 := by decide
private def t_e1211589840506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211589840506 : ¬ IsSelfInterpreter e1211589840506 :=
  wSource (t := t_e1211589840506) (replay_sound (ps := []) (t := e1211589840506) (by decide)) (by decide)
def e1211589840694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211589840694 : Closed e1211589840694 ∧ code e1211589840694 = 5609636351798 := by decide
private def t_e1211589840694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211589840694 : ¬ IsSelfInterpreter e1211589840694 :=
  wSource (t := t_e1211589840694) (replay_sound (ps := []) (t := e1211589840694) (by decide)) (by decide)
def e1211589840698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211589840698 : Closed e1211589840698 ∧ code e1211589840698 = 5609636351802 := by decide
private def t_e1211589840698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211589840698 : ¬ IsSelfInterpreter e1211589840698 :=
  wSource (t := t_e1211589840698) (replay_sound (ps := []) (t := e1211589840698) (by decide)) (by decide)
def e1211589846454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e1211589846454 : Closed e1211589846454 ∧ code e1211589846454 = 5609636357558 := by decide
private def t_e1211589846454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem cert_e1211589846454 : ¬ IsSelfInterpreter e1211589846454 :=
  wSource (t := t_e1211589846454) (replay_sound (ps := []) (t := e1211589846454) (by decide)) (by decide)
def e1211589846486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e1211589846486 : Closed e1211589846486 ∧ code e1211589846486 = 5609636357590 := by decide
private def t_e1211589846486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem cert_e1211589846486 : ¬ IsSelfInterpreter e1211589846486 :=
  wSource (t := t_e1211589846486) (replay_sound (ps := []) (t := e1211589846486) (by decide)) (by decide)
def e1211589846490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e1211589846490 : Closed e1211589846490 ∧ code e1211589846490 = 5609636357594 := by decide
private def t_e1211589846490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem cert_e1211589846490 : ¬ IsSelfInterpreter e1211589846490 :=
  wSource (t := t_e1211589846490) (replay_sound (ps := []) (t := e1211589846490) (by decide)) (by decide)
def e1211589846646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e1211589846646 : Closed e1211589846646 ∧ code e1211589846646 = 5609636357750 := by decide
private def t_e1211589846646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem cert_e1211589846646 : ¬ IsSelfInterpreter e1211589846646 :=
  wSource (t := t_e1211589846646) (replay_sound (ps := []) (t := e1211589846646) (by decide)) (by decide)
def e1211589846838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211589846838 : Closed e1211589846838 ∧ code e1211589846838 = 5609636357942 := by decide
private def t_e1211589846838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211589846838 : ¬ IsSelfInterpreter e1211589846838 :=
  wSource (t := t_e1211589846838) (replay_sound (ps := []) (t := e1211589846838) (by decide)) (by decide)
def e1211589846842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211589846842 : Closed e1211589846842 ∧ code e1211589846842 = 5609636357946 := by decide
private def t_e1211589846842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211589846842 : ¬ IsSelfInterpreter e1211589846842 :=
  wSource (t := t_e1211589846842) (replay_sound (ps := []) (t := e1211589846842) (by decide)) (by decide)
def e1211590183790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211590183790 : Closed e1211590183790 ∧ code e1211590183790 = 5609636694894 := by decide
private def t_e1211590183790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e1211590183790 : ¬ IsSelfInterpreter e1211590183790 :=
  wSource (t := t_e1211590183790) (replay_sound (ps := []) (t := e1211590183790) (by decide)) (by decide)
def e1211590183798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211590183798 : Closed e1211590183798 ∧ code e1211590183798 = 5609636694902 := by decide
private def t_e1211590183798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e1211590183798 : ¬ IsSelfInterpreter e1211590183798 :=
  wSource (t := t_e1211590183798) (replay_sound (ps := []) (t := e1211590183798) (by decide)) (by decide)
def e1211590183854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211590183854 : Closed e1211590183854 ∧ code e1211590183854 = 5609636694958 := by decide
private def t_e1211590183854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e1211590183854 : ¬ IsSelfInterpreter e1211590183854 :=
  wSource (t := t_e1211590183854) (replay_sound (ps := []) (t := e1211590183854) (by decide)) (by decide)
def e1211590183866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211590183866 : Closed e1211590183866 ∧ code e1211590183866 = 5609636694970 := by decide
private def t_e1211590183866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e1211590183866 : ¬ IsSelfInterpreter e1211590183866 :=
  wSource (t := t_e1211590183866) (replay_sound (ps := []) (t := e1211590183866) (by decide)) (by decide)
def e1211590183894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211590183894 : Closed e1211590183894 ∧ code e1211590183894 = 5609636694998 := by decide
private def t_e1211590183894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e1211590183894 : ¬ IsSelfInterpreter e1211590183894 :=
  wSource (t := t_e1211590183894) (replay_sound (ps := []) (t := e1211590183894) (by decide)) (by decide)
def e1211590183898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211590183898 : Closed e1211590183898 ∧ code e1211590183898 = 5609636695002 := by decide
private def t_e1211590183898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e1211590183898 : ¬ IsSelfInterpreter e1211590183898 :=
  wSource (t := t_e1211590183898) (replay_sound (ps := []) (t := e1211590183898) (by decide)) (by decide)
def e1211590184174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211590184174 : Closed e1211590184174 ∧ code e1211590184174 = 5609636695278 := by decide
private def t_e1211590184174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211590184174 : ¬ IsSelfInterpreter e1211590184174 :=
  wSource (t := t_e1211590184174) (replay_sound (ps := []) (t := e1211590184174) (by decide)) (by decide)
def e1211590184182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211590184182 : Closed e1211590184182 ∧ code e1211590184182 = 5609636695286 := by decide
private def t_e1211590184182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211590184182 : ¬ IsSelfInterpreter e1211590184182 :=
  wSource (t := t_e1211590184182) (replay_sound (ps := []) (t := e1211590184182) (by decide)) (by decide)
def e1211590184558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211590184558 : Closed e1211590184558 ∧ code e1211590184558 = 5609636695662 := by decide
private def t_e1211590184558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211590184558 : ¬ IsSelfInterpreter e1211590184558 :=
  wSource (t := t_e1211590184558) (replay_sound (ps := []) (t := e1211590184558) (by decide)) (by decide)
def e1211590184570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211590184570 : Closed e1211590184570 ∧ code e1211590184570 = 5609636695674 := by decide
private def t_e1211590184570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211590184570 : ¬ IsSelfInterpreter e1211590184570 :=
  wSource (t := t_e1211590184570) (replay_sound (ps := []) (t := e1211590184570) (by decide)) (by decide)
def e1211590184758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211590184758 : Closed e1211590184758 ∧ code e1211590184758 = 5609636695862 := by decide
private def t_e1211590184758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211590184758 : ¬ IsSelfInterpreter e1211590184758 :=
  wSource (t := t_e1211590184758) (replay_sound (ps := []) (t := e1211590184758) (by decide)) (by decide)
def e1211590184762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211590184762 : Closed e1211590184762 ∧ code e1211590184762 = 5609636695866 := by decide
private def t_e1211590184762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211590184762 : ¬ IsSelfInterpreter e1211590184762 :=
  wSource (t := t_e1211590184762) (replay_sound (ps := []) (t := e1211590184762) (by decide)) (by decide)
def e1211590773614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1211590773614 : Closed e1211590773614 ∧ code e1211590773614 = 5609637284718 := by decide
theorem cert_e1211590773614 : check e1211590773614 [[],[],[],[]] .chain = true := by decide
def e1211590773622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1211590773622 : Closed e1211590773622 ∧ code e1211590773622 = 5609637284726 := by decide
theorem cert_e1211590773622 : check e1211590773622 [[],[],[],[]] .chain = true := by decide
def e1211590773678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1211590773678 : Closed e1211590773678 ∧ code e1211590773678 = 5609637284782 := by decide
theorem cert_e1211590773678 : check e1211590773678 [[],[],[],[]] .chain = true := by decide
def e1211590773690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1211590773690 : Closed e1211590773690 ∧ code e1211590773690 = 5609637284794 := by decide
theorem cert_e1211590773690 : check e1211590773690 [[],[],[],[]] .chain = true := by decide
def e1211590773718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1211590773718 : Closed e1211590773718 ∧ code e1211590773718 = 5609637284822 := by decide
theorem cert_e1211590773718 : check e1211590773718 [[],[],[],[]] .chain = true := by decide
def e1211590773722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1211590773722 : Closed e1211590773722 ∧ code e1211590773722 = 5609637284826 := by decide
theorem cert_e1211590773722 : check e1211590773722 [[],[],[],[]] .chain = true := by decide
def e1211590773998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1211590773998 : Closed e1211590773998 ∧ code e1211590773998 = 5609637285102 := by decide
theorem cert_e1211590773998 : check e1211590773998 [[],[],[],[]] .chain = true := by decide
def e1211590774006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1211590774006 : Closed e1211590774006 ∧ code e1211590774006 = 5609637285110 := by decide
theorem cert_e1211590774006 : check e1211590774006 [[],[],[],[]] .chain = true := by decide
def e1211590774382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1211590774382 : Closed e1211590774382 ∧ code e1211590774382 = 5609637285486 := by decide
theorem cert_e1211590774382 : check e1211590774382 [[],[],[],[]] .chain = true := by decide
def e1211590774394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1211590774394 : Closed e1211590774394 ∧ code e1211590774394 = 5609637285498 := by decide
theorem cert_e1211590774394 : check e1211590774394 [[],[],[],[]] .chain = true := by decide
def e1211590774582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1211590774582 : Closed e1211590774582 ∧ code e1211590774582 = 5609637285686 := by decide
theorem cert_e1211590774582 : check e1211590774582 [[],[],[],[]] .chain = true := by decide
def e1211590774586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1211590774586 : Closed e1211590774586 ∧ code e1211590774586 = 5609637285690 := by decide
theorem cert_e1211590774586 : check e1211590774586 [[],[],[],[]] .chain = true := by decide
def e1211590782430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1211590782430 : Closed e1211590782430 ∧ code e1211590782430 = 5609637293534 := by decide
theorem cert_e1211590782430 : check e1211590782430 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211590782446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1211590782446 : Closed e1211590782446 ∧ code e1211590782446 = 5609637293550 := by decide
theorem cert_e1211590782446 : check e1211590782446 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211590782814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1211590782814 : Closed e1211590782814 ∧ code e1211590782814 = 5609637293918 := by decide
theorem cert_e1211590782814 : check e1211590782814 [[],[],[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1211590782842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1211590782842 : Closed e1211590782842 ∧ code e1211590782842 = 5609637293946 := by decide
private def t_e1211590782842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem cert_e1211590782842 : ¬ IsSelfInterpreter e1211590782842 :=
  wSource (t := t_e1211590782842) (replay_sound (ps := []) (t := e1211590782842) (by decide)) (by decide)
def e1211590782894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1211590782894 : Closed e1211590782894 ∧ code e1211590782894 = 5609637293998 := by decide
theorem cert_e1211590782894 : check e1211590782894 [[],[],[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e1211590782906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1211590782906 : Closed e1211590782906 ∧ code e1211590782906 = 5609637294010 := by decide
private def t_e1211590782906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem cert_e1211590782906 : ¬ IsSelfInterpreter e1211590782906 :=
  wSource (t := t_e1211590782906) (replay_sound (ps := []) (t := e1211590782906) (by decide)) (by decide)
def e1211590783966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1211590783966 : Closed e1211590783966 ∧ code e1211590783966 = 5609637295070 := by decide
theorem cert_e1211590783966 : check e1211590783966 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211590783982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1211590783982 : Closed e1211590783982 ∧ code e1211590783982 = 5609637295086 := by decide
theorem cert_e1211590783982 : check e1211590783982 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e1211590786270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1211590786270 : Closed e1211590786270 ∧ code e1211590786270 = 5609637297374 := by decide
theorem cert_e1211590786270 : check e1211590786270 [[],[],[],[],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1211590786298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1211590786298 : Closed e1211590786298 ∧ code e1211590786298 = 5609637297402 := by decide
theorem cert_e1211590786298 : check e1211590786298 [[],[],[],[],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e1211590786670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211590786670 : Closed e1211590786670 ∧ code e1211590786670 = 5609637297774 := by decide
theorem cert_e1211590786670 : check e1211590786670 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e1211590786682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211590786682 : Closed e1211590786682 ∧ code e1211590786682 = 5609637297786 := by decide
def e1211590815086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1211590815086 : Closed e1211590815086 ∧ code e1211590815086 = 5609637326190 := by decide
private def t_e1211590815086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem cert_e1211590815086 : ¬ IsSelfInterpreter e1211590815086 :=
  wSource (t := t_e1211590815086) (replay_sound (ps := []) (t := e1211590815086) (by decide)) (by decide)
def e1211590815094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1211590815094 : Closed e1211590815094 ∧ code e1211590815094 = 5609637326198 := by decide
private def t_e1211590815094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem cert_e1211590815094 : ¬ IsSelfInterpreter e1211590815094 :=
  wSource (t := t_e1211590815094) (replay_sound (ps := []) (t := e1211590815094) (by decide)) (by decide)
def e1211590815150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1211590815150 : Closed e1211590815150 ∧ code e1211590815150 = 5609637326254 := by decide
private def t_e1211590815150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem cert_e1211590815150 : ¬ IsSelfInterpreter e1211590815150 :=
  wSource (t := t_e1211590815150) (replay_sound (ps := []) (t := e1211590815150) (by decide)) (by decide)
def e1211590815162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1211590815162 : Closed e1211590815162 ∧ code e1211590815162 = 5609637326266 := by decide
private def t_e1211590815162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem cert_e1211590815162 : ¬ IsSelfInterpreter e1211590815162 :=
  wSource (t := t_e1211590815162) (replay_sound (ps := []) (t := e1211590815162) (by decide)) (by decide)
def e1211590815190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1211590815190 : Closed e1211590815190 ∧ code e1211590815190 = 5609637326294 := by decide
private def t_e1211590815190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e1211590815190 : ¬ IsSelfInterpreter e1211590815190 :=
  wSource (t := t_e1211590815190) (replay_sound (ps := []) (t := e1211590815190) (by decide)) (by decide)
def e1211590815194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1211590815194 : Closed e1211590815194 ∧ code e1211590815194 = 5609637326298 := by decide
private def t_e1211590815194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e1211590815194 : ¬ IsSelfInterpreter e1211590815194 :=
  wSource (t := t_e1211590815194) (replay_sound (ps := []) (t := e1211590815194) (by decide)) (by decide)
def e1211590815406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1211590815406 : Closed e1211590815406 ∧ code e1211590815406 = 5609637326510 := by decide
private def t_e1211590815406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem cert_e1211590815406 : ¬ IsSelfInterpreter e1211590815406 :=
  wSource (t := t_e1211590815406) (replay_sound (ps := []) (t := e1211590815406) (by decide)) (by decide)
def e1211590815418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1211590815418 : Closed e1211590815418 ∧ code e1211590815418 = 5609637326522 := by decide
private def t_e1211590815418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem cert_e1211590815418 : ¬ IsSelfInterpreter e1211590815418 :=
  wSource (t := t_e1211590815418) (replay_sound (ps := []) (t := e1211590815418) (by decide)) (by decide)
def e1211590815466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1211590815466 : Closed e1211590815466 ∧ code e1211590815466 = 5609637326570 := by decide
private def t_e1211590815466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem cert_e1211590815466 : ¬ IsSelfInterpreter e1211590815466 :=
  wSource (t := t_e1211590815466) (replay_sound (ps := []) (t := e1211590815466) (by decide)) (by decide)
def e1211590815574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1211590815574 : Closed e1211590815574 ∧ code e1211590815574 = 5609637326678 := by decide
private def t_e1211590815574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem cert_e1211590815574 : ¬ IsSelfInterpreter e1211590815574 :=
  wSource (t := t_e1211590815574) (replay_sound (ps := []) (t := e1211590815574) (by decide)) (by decide)
def e1211590815578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1211590815578 : Closed e1211590815578 ∧ code e1211590815578 = 5609637326682 := by decide
private def t_e1211590815578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem cert_e1211590815578 : ¬ IsSelfInterpreter e1211590815578 :=
  wSource (t := t_e1211590815578) (replay_sound (ps := []) (t := e1211590815578) (by decide)) (by decide)
def e1211590815594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1211590815594 : Closed e1211590815594 ∧ code e1211590815594 = 5609637326698 := by decide
private def t_e1211590815594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem cert_e1211590815594 : ¬ IsSelfInterpreter e1211590815594 :=
  wSource (t := t_e1211590815594) (replay_sound (ps := []) (t := e1211590815594) (by decide)) (by decide)
def e1211590816622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1211590816622 : Closed e1211590816622 ∧ code e1211590816622 = 5609637327726 := by decide
private def t_e1211590816622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem cert_e1211590816622 : ¬ IsSelfInterpreter e1211590816622 :=
  wSource (t := t_e1211590816622) (replay_sound (ps := []) (t := e1211590816622) (by decide)) (by decide)
def e1211590816630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1211590816630 : Closed e1211590816630 ∧ code e1211590816630 = 5609637327734 := by decide
private def t_e1211590816630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem cert_e1211590816630 : ¬ IsSelfInterpreter e1211590816630 :=
  wSource (t := t_e1211590816630) (replay_sound (ps := []) (t := e1211590816630) (by decide)) (by decide)
def e1211590816686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1211590816686 : Closed e1211590816686 ∧ code e1211590816686 = 5609637327790 := by decide
private def t_e1211590816686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem cert_e1211590816686 : ¬ IsSelfInterpreter e1211590816686 :=
  wSource (t := t_e1211590816686) (replay_sound (ps := []) (t := e1211590816686) (by decide)) (by decide)
def e1211590816698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1211590816698 : Closed e1211590816698 ∧ code e1211590816698 = 5609637327802 := by decide
private def t_e1211590816698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem cert_e1211590816698 : ¬ IsSelfInterpreter e1211590816698 :=
  wSource (t := t_e1211590816698) (replay_sound (ps := []) (t := e1211590816698) (by decide)) (by decide)
def e1211590816726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1211590816726 : Closed e1211590816726 ∧ code e1211590816726 = 5609637327830 := by decide
private def t_e1211590816726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem cert_e1211590816726 : ¬ IsSelfInterpreter e1211590816726 :=
  wSource (t := t_e1211590816726) (replay_sound (ps := []) (t := e1211590816726) (by decide)) (by decide)
def e1211590816730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1211590816730 : Closed e1211590816730 ∧ code e1211590816730 = 5609637327834 := by decide
private def t_e1211590816730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem cert_e1211590816730 : ¬ IsSelfInterpreter e1211590816730 :=
  wSource (t := t_e1211590816730) (replay_sound (ps := []) (t := e1211590816730) (by decide)) (by decide)
def e1211590817006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1211590817006 : Closed e1211590817006 ∧ code e1211590817006 = 5609637328110 := by decide
private def t_e1211590817006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem cert_e1211590817006 : ¬ IsSelfInterpreter e1211590817006 :=
  wSource (t := t_e1211590817006) (replay_sound (ps := []) (t := e1211590817006) (by decide)) (by decide)
def e1211590817014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1211590817014 : Closed e1211590817014 ∧ code e1211590817014 = 5609637328118 := by decide
private def t_e1211590817014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem cert_e1211590817014 : ¬ IsSelfInterpreter e1211590817014 :=
  wSource (t := t_e1211590817014) (replay_sound (ps := []) (t := e1211590817014) (by decide)) (by decide)
def e1211590817390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211590817390 : Closed e1211590817390 ∧ code e1211590817390 = 5609637328494 := by decide
private def t_e1211590817390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211590817390 : ¬ IsSelfInterpreter e1211590817390 :=
  wSource (t := t_e1211590817390) (replay_sound (ps := []) (t := e1211590817390) (by decide)) (by decide)
def e1211590817402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211590817402 : Closed e1211590817402 ∧ code e1211590817402 = 5609637328506 := by decide
private def t_e1211590817402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211590817402 : ¬ IsSelfInterpreter e1211590817402 :=
  wSource (t := t_e1211590817402) (replay_sound (ps := []) (t := e1211590817402) (by decide)) (by decide)
def e1211590817590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211590817590 : Closed e1211590817590 ∧ code e1211590817590 = 5609637328694 := by decide
private def t_e1211590817590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211590817590 : ¬ IsSelfInterpreter e1211590817590 :=
  wSource (t := t_e1211590817590) (replay_sound (ps := []) (t := e1211590817590) (by decide)) (by decide)
def e1211590817594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211590817594 : Closed e1211590817594 ∧ code e1211590817594 = 5609637328698 := by decide
private def t_e1211590817594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211590817594 : ¬ IsSelfInterpreter e1211590817594 :=
  wSource (t := t_e1211590817594) (replay_sound (ps := []) (t := e1211590817594) (by decide)) (by decide)
def e1211590818222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1211590818222 : Closed e1211590818222 ∧ code e1211590818222 = 5609637329326 := by decide
private def t_e1211590818222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem cert_e1211590818222 : ¬ IsSelfInterpreter e1211590818222 :=
  wSource (t := t_e1211590818222) (replay_sound (ps := []) (t := e1211590818222) (by decide)) (by decide)
def e1211590818234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1211590818234 : Closed e1211590818234 ∧ code e1211590818234 = 5609637329338 := by decide
private def t_e1211590818234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem cert_e1211590818234 : ¬ IsSelfInterpreter e1211590818234 :=
  wSource (t := t_e1211590818234) (replay_sound (ps := []) (t := e1211590818234) (by decide)) (by decide)
def e1211590818282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1211590818282 : Closed e1211590818282 ∧ code e1211590818282 = 5609637329386 := by decide
private def t_e1211590818282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem cert_e1211590818282 : ¬ IsSelfInterpreter e1211590818282 :=
  wSource (t := t_e1211590818282) (replay_sound (ps := []) (t := e1211590818282) (by decide)) (by decide)
def e1211590818414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1211590818414 : Closed e1211590818414 ∧ code e1211590818414 = 5609637329518 := by decide
private def t_e1211590818414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem cert_e1211590818414 : ¬ IsSelfInterpreter e1211590818414 :=
  wSource (t := t_e1211590818414) (replay_sound (ps := []) (t := e1211590818414) (by decide)) (by decide)
def e1211590818426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1211590818426 : Closed e1211590818426 ∧ code e1211590818426 = 5609637329530 := by decide
private def t_e1211590818426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem cert_e1211590818426 : ¬ IsSelfInterpreter e1211590818426 :=
  wSource (t := t_e1211590818426) (replay_sound (ps := []) (t := e1211590818426) (by decide)) (by decide)
def e1211590818714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211590818714 : Closed e1211590818714 ∧ code e1211590818714 = 5609637329818 := by decide
private def t_e1211590818714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211590818714 : ¬ IsSelfInterpreter e1211590818714 :=
  wSource (t := t_e1211590818714) (replay_sound (ps := []) (t := e1211590818714) (by decide)) (by decide)
def e1211590819030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1211590819030 : Closed e1211590819030 ∧ code e1211590819030 = 5609637330134 := by decide
private def t_e1211590819030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem cert_e1211590819030 : ¬ IsSelfInterpreter e1211590819030 :=
  wSource (t := t_e1211590819030) (replay_sound (ps := []) (t := e1211590819030) (by decide)) (by decide)
def e1211590819034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1211590819034 : Closed e1211590819034 ∧ code e1211590819034 = 5609637330138 := by decide
private def t_e1211590819034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem cert_e1211590819034 : ¬ IsSelfInterpreter e1211590819034 :=
  wSource (t := t_e1211590819034) (replay_sound (ps := []) (t := e1211590819034) (by decide)) (by decide)
def e1211590819050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1211590819050 : Closed e1211590819050 ∧ code e1211590819050 = 5609637330154 := by decide
private def t_e1211590819050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem cert_e1211590819050 : ¬ IsSelfInterpreter e1211590819050 :=
  wSource (t := t_e1211590819050) (replay_sound (ps := []) (t := e1211590819050) (by decide)) (by decide)
def e1211590819126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1211590819126 : Closed e1211590819126 ∧ code e1211590819126 = 5609637330230 := by decide
private def t_e1211590819126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem cert_e1211590819126 : ¬ IsSelfInterpreter e1211590819126 :=
  wSource (t := t_e1211590819126) (replay_sound (ps := []) (t := e1211590819126) (by decide)) (by decide)
def e1211590819130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1211590819130 : Closed e1211590819130 ∧ code e1211590819130 = 5609637330234 := by decide
private def t_e1211590819130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem cert_e1211590819130 : ¬ IsSelfInterpreter e1211590819130 :=
  wSource (t := t_e1211590819130) (replay_sound (ps := []) (t := e1211590819130) (by decide)) (by decide)
def e1211590819226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1211590819226 : Closed e1211590819226 ∧ code e1211590819226 = 5609637330330 := by decide
private def t_e1211590819226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem cert_e1211590819226 : ¬ IsSelfInterpreter e1211590819226 :=
  wSource (t := t_e1211590819226) (replay_sound (ps := []) (t := e1211590819226) (by decide)) (by decide)
def e1211590820830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1211590820830 : Closed e1211590820830 ∧ code e1211590820830 = 5609637331934 := by decide
private def t_e1211590820830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem cert_e1211590820830 : ¬ IsSelfInterpreter e1211590820830 :=
  wSource (t := t_e1211590820830) (replay_sound (ps := []) (t := e1211590820830) (by decide)) (by decide)
def e1211590820846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1211590820846 : Closed e1211590820846 ∧ code e1211590820846 = 5609637331950 := by decide
private def t_e1211590820846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem cert_e1211590820846 : ¬ IsSelfInterpreter e1211590820846 :=
  wSource (t := t_e1211590820846) (replay_sound (ps := []) (t := e1211590820846) (by decide)) (by decide)
def e1211590822766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1211590822766 : Closed e1211590822766 ∧ code e1211590822766 = 5609637333870 := by decide
private def t_e1211590822766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e1211590822766 : ¬ IsSelfInterpreter e1211590822766 :=
  wSource (t := t_e1211590822766) (replay_sound (ps := []) (t := e1211590822766) (by decide)) (by decide)
def e1211590822774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1211590822774 : Closed e1211590822774 ∧ code e1211590822774 = 5609637333878 := by decide
private def t_e1211590822774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e1211590822774 : ¬ IsSelfInterpreter e1211590822774 :=
  wSource (t := t_e1211590822774) (replay_sound (ps := []) (t := e1211590822774) (by decide)) (by decide)
def e1211590822830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1211590822830 : Closed e1211590822830 ∧ code e1211590822830 = 5609637333934 := by decide
private def t_e1211590822830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e1211590822830 : ¬ IsSelfInterpreter e1211590822830 :=
  wSource (t := t_e1211590822830) (replay_sound (ps := []) (t := e1211590822830) (by decide)) (by decide)
def e1211590822842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1211590822842 : Closed e1211590822842 ∧ code e1211590822842 = 5609637333946 := by decide
private def t_e1211590822842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e1211590822842 : ¬ IsSelfInterpreter e1211590822842 :=
  wSource (t := t_e1211590822842) (replay_sound (ps := []) (t := e1211590822842) (by decide)) (by decide)
def e1211590822870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1211590822870 : Closed e1211590822870 ∧ code e1211590822870 = 5609637333974 := by decide
private def t_e1211590822870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e1211590822870 : ¬ IsSelfInterpreter e1211590822870 :=
  wSource (t := t_e1211590822870) (replay_sound (ps := []) (t := e1211590822870) (by decide)) (by decide)
def e1211590822874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1211590822874 : Closed e1211590822874 ∧ code e1211590822874 = 5609637333978 := by decide
private def t_e1211590822874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e1211590822874 : ¬ IsSelfInterpreter e1211590822874 :=
  wSource (t := t_e1211590822874) (replay_sound (ps := []) (t := e1211590822874) (by decide)) (by decide)
def e1211590823150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1211590823150 : Closed e1211590823150 ∧ code e1211590823150 = 5609637334254 := by decide
private def t_e1211590823150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e1211590823150 : ¬ IsSelfInterpreter e1211590823150 :=
  wSource (t := t_e1211590823150) (replay_sound (ps := []) (t := e1211590823150) (by decide)) (by decide)
def e1211590823158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1211590823158 : Closed e1211590823158 ∧ code e1211590823158 = 5609637334262 := by decide
private def t_e1211590823158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e1211590823158 : ¬ IsSelfInterpreter e1211590823158 :=
  wSource (t := t_e1211590823158) (replay_sound (ps := []) (t := e1211590823158) (by decide)) (by decide)
def e1211590823534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1211590823534 : Closed e1211590823534 ∧ code e1211590823534 = 5609637334638 := by decide
private def t_e1211590823534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e1211590823534 : ¬ IsSelfInterpreter e1211590823534 :=
  wSource (t := t_e1211590823534) (replay_sound (ps := []) (t := e1211590823534) (by decide)) (by decide)
def e1211590823546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1211590823546 : Closed e1211590823546 ∧ code e1211590823546 = 5609637334650 := by decide
private def t_e1211590823546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e1211590823546 : ¬ IsSelfInterpreter e1211590823546 :=
  wSource (t := t_e1211590823546) (replay_sound (ps := []) (t := e1211590823546) (by decide)) (by decide)
def e1211590823734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1211590823734 : Closed e1211590823734 ∧ code e1211590823734 = 5609637334838 := by decide
private def t_e1211590823734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e1211590823734 : ¬ IsSelfInterpreter e1211590823734 :=
  wSource (t := t_e1211590823734) (replay_sound (ps := []) (t := e1211590823734) (by decide)) (by decide)
def e1211590823738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1211590823738 : Closed e1211590823738 ∧ code e1211590823738 = 5609637334842 := by decide
private def t_e1211590823738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e1211590823738 : ¬ IsSelfInterpreter e1211590823738 :=
  wSource (t := t_e1211590823738) (replay_sound (ps := []) (t := e1211590823738) (by decide)) (by decide)
end Blc.Floor42
