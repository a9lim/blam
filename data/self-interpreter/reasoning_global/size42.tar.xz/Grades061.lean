import Tables
import Batch061
namespace Blc.Floor42.Grades061
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1131212266358 : ¬ IsSelfInterpreter e1131212266358 := cutM6_2 (by decide)
#print axioms ex_e1131212266358
theorem ex_e1131212266870 : ¬ IsSelfInterpreter e1131212266870 := cutM6_2 (by decide)
#print axioms ex_e1131212266870
theorem ex_e1131193765486 : ¬ IsSelfInterpreter e1131193765486 := cutM13_0 (by decide)
#print axioms ex_e1131193765486
end Blc.Floor42.Grades061
