import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1402312569954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312569954 : Closed e1402312569954 ∧ code e1402312569954 = 5800359081058 := by decide
theorem cert_e1402312569954 : check e1402312569954 [[.left],[.left]] .chain = true := by decide
def e1402312570118 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312570118 : Closed e1402312570118 ∧ code e1402312570118 = 5800359081222 := by decide
theorem cert_e1402312570118 : check e1402312570118 [[.left],[.left]] .chain = true := by decide
def e1402312570242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312570242 : Closed e1402312570242 ∧ code e1402312570242 = 5800359081346 := by decide
theorem cert_e1402312570242 : check e1402312570242 [[.left],[.left]] .chain = true := by decide
def e1402312570498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312570498 : Closed e1402312570498 ∧ code e1402312570498 = 5800359081602 := by decide
theorem cert_e1402312570498 : check e1402312570498 [[.left],[.left]] .chain = true := by decide
def e1402312642274 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312642274 : Closed e1402312642274 ∧ code e1402312642274 = 5800359153378 := by decide
theorem cert_e1402312642274 : check e1402312642274 [[.left],[.left]] .chain = true := by decide
def e1402312642402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312642402 : Closed e1402312642402 ∧ code e1402312642402 = 5800359153506 := by decide
theorem cert_e1402312642402 : check e1402312642402 [[.left],[.left]] .chain = true := by decide
def e1402312648418 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312648418 : Closed e1402312648418 ∧ code e1402312648418 = 5800359159522 := by decide
theorem cert_e1402312648418 : check e1402312648418 [[.left],[.left]] .chain = true := by decide
def e1402312648610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402312648610 : Closed e1402312648610 ∧ code e1402312648610 = 5800359159714 := by decide
theorem cert_e1402312648610 : check e1402312648610 [[.left],[.left]] .chain = true := by decide
def e1402312650266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312650266 : Closed e1402312650266 ∧ code e1402312650266 = 5800359161370 := by decide
theorem cert_e1402312650266 : check e1402312650266 [[.left]] .chain = true := by decide
def e1402312651618 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312651618 : Closed e1402312651618 ∧ code e1402312651618 = 5800359162722 := by decide
theorem cert_e1402312651618 : check e1402312651618 [[.left],[.left]] .chain = true := by decide
def e1402312651682 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402312651682 : Closed e1402312651682 ∧ code e1402312651682 = 5800359162786 := by decide
theorem cert_e1402312651682 : check e1402312651682 [[.left],[.left]] .chain = true := by decide
def e1402312652314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312652314 : Closed e1402312652314 ∧ code e1402312652314 = 5800359163418 := by decide
theorem cert_e1402312652314 : check e1402312652314 [[.left]] .chain = true := by decide
def e1402312691426 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312691426 : Closed e1402312691426 ∧ code e1402312691426 = 5800359202530 := by decide
theorem cert_e1402312691426 : check e1402312691426 [[.left],[.left]] .chain = true := by decide
def e1402312691554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312691554 : Closed e1402312691554 ∧ code e1402312691554 = 5800359202658 := by decide
theorem cert_e1402312691554 : check e1402312691554 [[.left],[.left]] .chain = true := by decide
def e1402312700386 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402312700386 : Closed e1402312700386 ∧ code e1402312700386 = 5800359211490 := by decide
theorem cert_e1402312700386 : check e1402312700386 [[.left],[.left]] .chain = true := by decide
def e1402312701702 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312701702 : Closed e1402312701702 ∧ code e1402312701702 = 5800359212806 := by decide
theorem cert_e1402312701702 : check e1402312701702 [[.left],[.left]] .chain = true := by decide
def e1402312702178 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312702178 : Closed e1402312702178 ∧ code e1402312702178 = 5800359213282 := by decide
theorem cert_e1402312702178 : check e1402312702178 [[.left],[.left]] .chain = true := by decide
def e1402312702726 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312702726 : Closed e1402312702726 ∧ code e1402312702726 = 5800359213830 := by decide
theorem cert_e1402312702726 : check e1402312702726 [[.left],[.left]] .chain = true := by decide
def e1402312705762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312705762 : Closed e1402312705762 ∧ code e1402312705762 = 5800359216866 := by decide
theorem cert_e1402312705762 : check e1402312705762 [[.left],[.left]] .chain = true := by decide
def e1402312705954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312705954 : Closed e1402312705954 ∧ code e1402312705954 = 5800359217058 := by decide
theorem cert_e1402312705954 : check e1402312705954 [[.left],[.left]] .chain = true := by decide
def e1402312708578 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402312708578 : Closed e1402312708578 ∧ code e1402312708578 = 5800359219682 := by decide
theorem cert_e1402312708578 : check e1402312708578 [[.left],[.left]] .chain = true := by decide
def e1402312709894 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312709894 : Closed e1402312709894 ∧ code e1402312709894 = 5800359220998 := by decide
theorem cert_e1402312709894 : check e1402312709894 [[.left],[.left]] .chain = true := by decide
def e1402312711042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312711042 : Closed e1402312711042 ∧ code e1402312711042 = 5800359222146 := by decide
theorem cert_e1402312711042 : check e1402312711042 [[.left],[.left]] .chain = true := by decide
def e1402312711266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312711266 : Closed e1402312711266 ∧ code e1402312711266 = 5800359222370 := by decide
theorem cert_e1402312711266 : check e1402312711266 [[.left],[.left]] .chain = true := by decide
def e1402312711430 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312711430 : Closed e1402312711430 ∧ code e1402312711430 = 5800359222534 := by decide
theorem cert_e1402312711430 : check e1402312711430 [[.left],[.left]] .chain = true := by decide
def e1402312711554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312711554 : Closed e1402312711554 ∧ code e1402312711554 = 5800359222658 := by decide
theorem cert_e1402312711554 : check e1402312711554 [[.left],[.left]] .chain = true := by decide
def e1402312713058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402312713058 : Closed e1402312713058 ∧ code e1402312713058 = 5800359224162 := by decide
theorem cert_e1402312713058 : check e1402312713058 [[.left],[.left]] .chain = true := by decide
def e1402312713122 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312713122 : Closed e1402312713122 ∧ code e1402312713122 = 5800359224226 := by decide
theorem cert_e1402312713122 : check e1402312713122 [[.left],[.left]] .chain = true := by decide
def e1402312714466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312714466 : Closed e1402312714466 ∧ code e1402312714466 = 5800359225570 := by decide
theorem cert_e1402312714466 : check e1402312714466 [[.left],[.left]] .chain = true := by decide
def e1402312715014 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312715014 : Closed e1402312715014 ∧ code e1402312715014 = 5800359226118 := by decide
theorem cert_e1402312715014 : check e1402312715014 [[.left],[.left]] .chain = true := by decide
def e1402312715362 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312715362 : Closed e1402312715362 ∧ code e1402312715362 = 5800359226466 := by decide
theorem cert_e1402312715362 : check e1402312715362 [[.left],[.left]] .chain = true := by decide
def e1402312715526 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312715526 : Closed e1402312715526 ∧ code e1402312715526 = 5800359226630 := by decide
theorem cert_e1402312715526 : check e1402312715526 [[.left],[.left]] .chain = true := by decide
def e1402312715650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312715650 : Closed e1402312715650 ∧ code e1402312715650 = 5800359226754 := by decide
theorem cert_e1402312715650 : check e1402312715650 [[.left],[.left]] .chain = true := by decide
def e1402312749538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402312749538 : Closed e1402312749538 ∧ code e1402312749538 = 5800359260642 := by decide
theorem cert_e1402312749538 : check e1402312749538 [[.left],[.left]] .chain = true := by decide
def e1402312750854 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312750854 : Closed e1402312750854 ∧ code e1402312750854 = 5800359261958 := by decide
theorem cert_e1402312750854 : check e1402312750854 [[.left],[.left]] .chain = true := by decide
def e1402312751330 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402312751330 : Closed e1402312751330 ∧ code e1402312751330 = 5800359262434 := by decide
theorem cert_e1402312751330 : check e1402312751330 [[.left],[.left]] .chain = true := by decide
def e1402312751878 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312751878 : Closed e1402312751878 ∧ code e1402312751878 = 5800359262982 := by decide
theorem cert_e1402312751878 : check e1402312751878 [[.left],[.left]] .chain = true := by decide
def e1402312793626 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312793626 : Closed e1402312793626 ∧ code e1402312793626 = 5800359304730 := by decide
theorem cert_e1402312793626 : check e1402312793626 [[.left]] .chain = true := by decide
def e1402312798690 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402312798690 : Closed e1402312798690 ∧ code e1402312798690 = 5800359309794 := by decide
theorem cert_e1402312798690 : check e1402312798690 [[.left],[.left]] .chain = true := by decide
def e1402312800006 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312800006 : Closed e1402312800006 ∧ code e1402312800006 = 5800359311110 := by decide
theorem cert_e1402312800006 : check e1402312800006 [[.left],[.left]] .chain = true := by decide
def e1402312801154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312801154 : Closed e1402312801154 ∧ code e1402312801154 = 5800359312258 := by decide
theorem cert_e1402312801154 : check e1402312801154 [[.left],[.left]] .chain = true := by decide
def e1402312801378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402312801378 : Closed e1402312801378 ∧ code e1402312801378 = 5800359312482 := by decide
theorem cert_e1402312801378 : check e1402312801378 [[.left],[.left]] .chain = true := by decide
def e1402312801542 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312801542 : Closed e1402312801542 ∧ code e1402312801542 = 5800359312646 := by decide
theorem cert_e1402312801542 : check e1402312801542 [[.left],[.left]] .chain = true := by decide
def e1402312801666 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312801666 : Closed e1402312801666 ∧ code e1402312801666 = 5800359312770 := by decide
theorem cert_e1402312801666 : check e1402312801666 [[.left],[.left]] .chain = true := by decide
def e1402312814790 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402312814790 : Closed e1402312814790 ∧ code e1402312814790 = 5800359325894 := by decide
theorem cert_e1402312814790 : check e1402312814790 [[.left]] .chain = true := by decide
def e1402312822298 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312822298 : Closed e1402312822298 ∧ code e1402312822298 = 5800359333402 := by decide
theorem cert_e1402312822298 : check e1402312822298 [[.left]] .chain = true := by decide
def e1402312825058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402312825058 : Closed e1402312825058 ∧ code e1402312825058 = 5800359336162 := by decide
theorem cert_e1402312825058 : check e1402312825058 [[.left],[.left]] .chain = true := by decide
def e1402312825606 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312825606 : Closed e1402312825606 ∧ code e1402312825606 = 5800359336710 := by decide
theorem cert_e1402312825606 : check e1402312825606 [[.left],[.left]] .chain = true := by decide
def e1402312825954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402312825954 : Closed e1402312825954 ∧ code e1402312825954 = 5800359337058 := by decide
theorem cert_e1402312825954 : check e1402312825954 [[.left],[.left]] .chain = true := by decide
def e1402312826118 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312826118 : Closed e1402312826118 ∧ code e1402312826118 = 5800359337222 := by decide
theorem cert_e1402312826118 : check e1402312826118 [[.left],[.left]] .chain = true := by decide
def e1402312826242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312826242 : Closed e1402312826242 ∧ code e1402312826242 = 5800359337346 := by decide
theorem cert_e1402312826242 : check e1402312826242 [[.left],[.left]] .chain = true := by decide
def e1402312831174 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402312831174 : Closed e1402312831174 ∧ code e1402312831174 = 5800359342278 := by decide
theorem cert_e1402312831174 : check e1402312831174 [[.left]] .chain = true := by decide
def e1402312877794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402312877794 : Closed e1402312877794 ∧ code e1402312877794 = 5800359388898 := by decide
theorem cert_e1402312877794 : check e1402312877794 [[.left],[.left]] .chain = true := by decide
def e1402312877986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402312877986 : Closed e1402312877986 ∧ code e1402312877986 = 5800359389090 := by decide
theorem cert_e1402312877986 : check e1402312877986 [[.left],[.left]] .chain = true := by decide
def e1402312879642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312879642 : Closed e1402312879642 ∧ code e1402312879642 = 5800359390746 := by decide
theorem cert_e1402312879642 : check e1402312879642 [[.left]] .chain = true := by decide
def e1402312882594 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402312882594 : Closed e1402312882594 ∧ code e1402312882594 = 5800359393698 := by decide
theorem cert_e1402312882594 : check e1402312882594 [[.left],[.left]] .chain = true := by decide
def e1402312882714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312882714 : Closed e1402312882714 ∧ code e1402312882714 = 5800359393818 := by decide
theorem cert_e1402312882714 : check e1402312882714 [[.left]] .chain = true := by decide
def e1402312902370 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e1402312902370 : Closed e1402312902370 ∧ code e1402312902370 = 5800359413474 := by decide
theorem cert_e1402312902370 : check e1402312902370 [[.left],[.left]] .chain = true := by decide
def e1402312902562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312902562 : Closed e1402312902562 ∧ code e1402312902562 = 5800359413666 := by decide
theorem cert_e1402312902562 : check e1402312902562 [[.left],[.left]] .chain = true := by decide
def e1402312905186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))) (.lam (.var 0)))
theorem wire_e1402312905186 : Closed e1402312905186 ∧ code e1402312905186 = 5800359416290 := by decide
theorem cert_e1402312905186 : check e1402312905186 [[.left],[.left]] .chain = true := by decide
def e1402312906502 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312906502 : Closed e1402312906502 ∧ code e1402312906502 = 5800359417606 := by decide
theorem cert_e1402312906502 : check e1402312906502 [[.left],[.left]] .chain = true := by decide
def e1402312907650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312907650 : Closed e1402312907650 ∧ code e1402312907650 = 5800359418754 := by decide
theorem cert_e1402312907650 : check e1402312907650 [[.left],[.left]] .chain = true := by decide
def e1402312907874 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312907874 : Closed e1402312907874 ∧ code e1402312907874 = 5800359418978 := by decide
theorem cert_e1402312907874 : check e1402312907874 [[.left],[.left]] .chain = true := by decide
def e1402312908038 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312908038 : Closed e1402312908038 ∧ code e1402312908038 = 5800359419142 := by decide
theorem cert_e1402312908038 : check e1402312908038 [[.left],[.left]] .chain = true := by decide
def e1402312908162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312908162 : Closed e1402312908162 ∧ code e1402312908162 = 5800359419266 := by decide
theorem cert_e1402312908162 : check e1402312908162 [[.left],[.left]] .chain = true := by decide
def e1402312911746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312911746 : Closed e1402312911746 ∧ code e1402312911746 = 5800359422850 := by decide
theorem cert_e1402312911746 : check e1402312911746 [[.left],[.left]] .chain = true := by decide
def e1402312912514 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312912514 : Closed e1402312912514 ∧ code e1402312912514 = 5800359423618 := by decide
theorem cert_e1402312912514 : check e1402312912514 [[.left],[.left]] .chain = true := by decide
def e1402312913314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402312913314 : Closed e1402312913314 ∧ code e1402312913314 = 5800359424418 := by decide
theorem cert_e1402312913314 : check e1402312913314 [[.left],[.left]] .chain = true := by decide
def e1402312914018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312914018 : Closed e1402312914018 ∧ code e1402312914018 = 5800359425122 := by decide
theorem cert_e1402312914018 : check e1402312914018 [[.left],[.left]] .chain = true := by decide
def e1402312914182 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402312914182 : Closed e1402312914182 ∧ code e1402312914182 = 5800359425286 := by decide
theorem cert_e1402312914182 : check e1402312914182 [[.left],[.left]] .chain = true := by decide
def e1402312914306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312914306 : Closed e1402312914306 ∧ code e1402312914306 = 5800359425410 := by decide
theorem cert_e1402312914306 : check e1402312914306 [[.left],[.left]] .chain = true := by decide
def e1402312914562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e1402312914562 : Closed e1402312914562 ∧ code e1402312914562 = 5800359425666 := by decide
theorem cert_e1402312914562 : check e1402312914562 [[.left],[.left]] .chain = true := by decide
def e1402312924698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312924698 : Closed e1402312924698 ∧ code e1402312924698 = 5800359435802 := by decide
theorem cert_e1402312924698 : check e1402312924698 [[.left]] .chain = true := by decide
def e1402312929762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402312929762 : Closed e1402312929762 ∧ code e1402312929762 = 5800359440866 := by decide
theorem cert_e1402312929762 : check e1402312929762 [[.left],[.left]] .chain = true := by decide
def e1402312931078 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312931078 : Closed e1402312931078 ∧ code e1402312931078 = 5800359442182 := by decide
theorem cert_e1402312931078 : check e1402312931078 [[.left],[.left]] .chain = true := by decide
def e1402312932226 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312932226 : Closed e1402312932226 ∧ code e1402312932226 = 5800359443330 := by decide
theorem cert_e1402312932226 : check e1402312932226 [[.left],[.left]] .chain = true := by decide
def e1402312932450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402312932450 : Closed e1402312932450 ∧ code e1402312932450 = 5800359443554 := by decide
theorem cert_e1402312932450 : check e1402312932450 [[.left],[.left]] .chain = true := by decide
def e1402312932614 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312932614 : Closed e1402312932614 ∧ code e1402312932614 = 5800359443718 := by decide
theorem cert_e1402312932614 : check e1402312932614 [[.left],[.left]] .chain = true := by decide
def e1402312932738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312932738 : Closed e1402312932738 ∧ code e1402312932738 = 5800359443842 := by decide
theorem cert_e1402312932738 : check e1402312932738 [[.left],[.left]] .chain = true := by decide
def e1402312945862 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402312945862 : Closed e1402312945862 ∧ code e1402312945862 = 5800359456966 := by decide
theorem cert_e1402312945862 : check e1402312945862 [[.left]] .chain = true := by decide
def e1402312956802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312956802 : Closed e1402312956802 ∧ code e1402312956802 = 5800359467906 := by decide
theorem cert_e1402312956802 : check e1402312956802 [[.left],[.left]] .chain = true := by decide
def e1402312957570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312957570 : Closed e1402312957570 ∧ code e1402312957570 = 5800359468674 := by decide
theorem cert_e1402312957570 : check e1402312957570 [[.left],[.left]] .chain = true := by decide
def e1402312967706 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312967706 : Closed e1402312967706 ∧ code e1402312967706 = 5800359478810 := by decide
theorem cert_e1402312967706 : check e1402312967706 [[.left]] .chain = true := by decide
def e1402312969314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402312969314 : Closed e1402312969314 ∧ code e1402312969314 = 5800359480418 := by decide
theorem cert_e1402312969314 : check e1402312969314 [[.left],[.left]] .chain = true := by decide
def e1402312969478 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402312969478 : Closed e1402312969478 ∧ code e1402312969478 = 5800359480582 := by decide
theorem cert_e1402312969478 : check e1402312969478 [[.left],[.left]] .chain = true := by decide
def e1402312969602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312969602 : Closed e1402312969602 ∧ code e1402312969602 = 5800359480706 := by decide
theorem cert_e1402312969602 : check e1402312969602 [[.left],[.left]] .chain = true := by decide
def e1402312969858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402312969858 : Closed e1402312969858 ∧ code e1402312969858 = 5800359480962 := by decide
theorem cert_e1402312969858 : check e1402312969858 [[.left],[.left]] .chain = true := by decide
def e1402312970438 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402312970438 : Closed e1402312970438 ∧ code e1402312970438 = 5800359481542 := by decide
theorem cert_e1402312970438 : check e1402312970438 [[.left]] .chain = true := by decide
def e1402312995682 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402312995682 : Closed e1402312995682 ∧ code e1402312995682 = 5800359506786 := by decide
theorem cert_e1402312995682 : check e1402312995682 [[.left],[.left]] .chain = true := by decide
def e1402312995746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402312995746 : Closed e1402312995746 ∧ code e1402312995746 = 5800359506850 := by decide
theorem cert_e1402312995746 : check e1402312995746 [[.left],[.left]] .chain = true := by decide
def e1402312996378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312996378 : Closed e1402312996378 ∧ code e1402312996378 = 5800359507482 := by decide
theorem cert_e1402312996378 : check e1402312996378 [[.left]] .chain = true := by decide
def e1402312997282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402312997282 : Closed e1402312997282 ∧ code e1402312997282 = 5800359508386 := by decide
theorem cert_e1402312997282 : check e1402312997282 [[.left],[.left]] .chain = true := by decide
def e1402312997402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402312997402 : Closed e1402312997402 ∧ code e1402312997402 = 5800359508506 := by decide
theorem cert_e1402312997402 : check e1402312997402 [[.left]] .chain = true := by decide
def e1402313007970 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e1402313007970 : Closed e1402313007970 ∧ code e1402313007970 = 5800359519074 := by decide
theorem cert_e1402313007970 : check e1402313007970 [[.left],[.left]] .chain = true := by decide
def e1402313008034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402313008034 : Closed e1402313008034 ∧ code e1402313008034 = 5800359519138 := by decide
theorem cert_e1402313008034 : check e1402313008034 [[.left],[.left]] .chain = true := by decide
def e1402313009378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402313009378 : Closed e1402313009378 ∧ code e1402313009378 = 5800359520482 := by decide
theorem cert_e1402313009378 : check e1402313009378 [[.left],[.left]] .chain = true := by decide
def e1402313009926 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.var 1))))
theorem wire_e1402313009926 : Closed e1402313009926 ∧ code e1402313009926 = 5800359521030 := by decide
theorem cert_e1402313009926 : check e1402313009926 [[.left],[.left]] .chain = true := by decide
def e1402313010274 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402313010274 : Closed e1402313010274 ∧ code e1402313010274 = 5800359521378 := by decide
theorem cert_e1402313010274 : check e1402313010274 [[.left],[.left]] .chain = true := by decide
def e1402313010438 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402313010438 : Closed e1402313010438 ∧ code e1402313010438 = 5800359521542 := by decide
theorem cert_e1402313010438 : check e1402313010438 [[.left],[.left]] .chain = true := by decide
def e1402313010562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402313010562 : Closed e1402313010562 ∧ code e1402313010562 = 5800359521666 := by decide
theorem cert_e1402313010562 : check e1402313010562 [[.left],[.left]] .chain = true := by decide
def e1402313011618 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e1402313011618 : Closed e1402313011618 ∧ code e1402313011618 = 5800359522722 := by decide
theorem cert_e1402313011618 : check e1402313011618 [[.left],[.left]] .chain = true := by decide
def e1402313012322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402313012322 : Closed e1402313012322 ∧ code e1402313012322 = 5800359523426 := by decide
theorem cert_e1402313012322 : check e1402313012322 [[.left],[.left]] .chain = true := by decide
def e1402313012486 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.var 1))))
theorem wire_e1402313012486 : Closed e1402313012486 ∧ code e1402313012486 = 5800359523590 := by decide
theorem cert_e1402313012486 : check e1402313012486 [[.left],[.left]] .chain = true := by decide
def e1402313012610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e1402313012610 : Closed e1402313012610 ∧ code e1402313012610 = 5800359523714 := by decide
theorem cert_e1402313012610 : check e1402313012610 [[.left],[.left]] .chain = true := by decide
def e1402313012866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e1402313012866 : Closed e1402313012866 ∧ code e1402313012866 = 5800359523970 := by decide
theorem cert_e1402313012866 : check e1402313012866 [[.left],[.left]] .chain = true := by decide
def e1402313018906 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402313018906 : Closed e1402313018906 ∧ code e1402313018906 = 5800359530010 := by decide
theorem cert_e1402313018906 : check e1402313018906 [[.left]] .chain = true := by decide
def e1402313021666 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402313021666 : Closed e1402313021666 ∧ code e1402313021666 = 5800359532770 := by decide
theorem cert_e1402313021666 : check e1402313021666 [[.left],[.left]] .chain = true := by decide
def e1402313022214 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313022214 : Closed e1402313022214 ∧ code e1402313022214 = 5800359533318 := by decide
theorem cert_e1402313022214 : check e1402313022214 [[.left],[.left]] .chain = true := by decide
def e1402313022562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402313022562 : Closed e1402313022562 ∧ code e1402313022562 = 5800359533666 := by decide
theorem cert_e1402313022562 : check e1402313022562 [[.left],[.left]] .chain = true := by decide
def e1402313022726 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313022726 : Closed e1402313022726 ∧ code e1402313022726 = 5800359533830 := by decide
theorem cert_e1402313022726 : check e1402313022726 [[.left],[.left]] .chain = true := by decide
def e1402313022850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313022850 : Closed e1402313022850 ∧ code e1402313022850 = 5800359533954 := by decide
theorem cert_e1402313022850 : check e1402313022850 [[.left],[.left]] .chain = true := by decide
def e1402313027782 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402313027782 : Closed e1402313027782 ∧ code e1402313027782 = 5800359538886 := by decide
theorem cert_e1402313027782 : check e1402313027782 [[.left]] .chain = true := by decide
def e1402313033242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402313033242 : Closed e1402313033242 ∧ code e1402313033242 = 5800359544346 := by decide
theorem cert_e1402313033242 : check e1402313033242 [[.left]] .chain = true := by decide
def e1402313034850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402313034850 : Closed e1402313034850 ∧ code e1402313034850 = 5800359545954 := by decide
theorem cert_e1402313034850 : check e1402313034850 [[.left],[.left]] .chain = true := by decide
def e1402313035014 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313035014 : Closed e1402313035014 ∧ code e1402313035014 = 5800359546118 := by decide
theorem cert_e1402313035014 : check e1402313035014 [[.left],[.left]] .chain = true := by decide
def e1402313035138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313035138 : Closed e1402313035138 ∧ code e1402313035138 = 5800359546242 := by decide
theorem cert_e1402313035138 : check e1402313035138 [[.left],[.left]] .chain = true := by decide
def e1402313035394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313035394 : Closed e1402313035394 ∧ code e1402313035394 = 5800359546498 := by decide
theorem cert_e1402313035394 : check e1402313035394 [[.left],[.left]] .chain = true := by decide
def e1402313035974 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e1402313035974 : Closed e1402313035974 ∧ code e1402313035974 = 5800359547078 := by decide
theorem cert_e1402313035974 : check e1402313035974 [[.left]] .chain = true := by decide
def e1402313207266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402313207266 : Closed e1402313207266 ∧ code e1402313207266 = 5800359718370 := by decide
theorem cert_e1402313207266 : check e1402313207266 [[.left],[.left]] .chain = true := by decide
def e1402313207650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402313207650 : Closed e1402313207650 ∧ code e1402313207650 = 5800359718754 := by decide
theorem cert_e1402313207650 : check e1402313207650 [[.left],[.left]] .chain = true := by decide
def e1402313209314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402313209314 : Closed e1402313209314 ∧ code e1402313209314 = 5800359720418 := by decide
theorem cert_e1402313209314 : check e1402313209314 [[.left],[.left]] .chain = true := by decide
def e1402313209762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402313209762 : Closed e1402313209762 ∧ code e1402313209762 = 5800359720866 := by decide
theorem cert_e1402313209762 : check e1402313209762 [[.left],[.left]] .chain = true := by decide
def e1402313211234 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402313211234 : Closed e1402313211234 ∧ code e1402313211234 = 5800359722338 := by decide
theorem cert_e1402313211234 : check e1402313211234 [[.left],[.left]] .chain = true := by decide
def e1402313211298 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e1402313211298 : Closed e1402313211298 ∧ code e1402313211298 = 5800359722402 := by decide
theorem cert_e1402313211298 : check e1402313211298 [[.left],[.left]] .chain = true := by decide
def e1402313219554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402313219554 : Closed e1402313219554 ∧ code e1402313219554 = 5800359730658 := by decide
theorem cert_e1402313219554 : check e1402313219554 [[.left],[.left]] .chain = true := by decide
def e1402313219938 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402313219938 : Closed e1402313219938 ∧ code e1402313219938 = 5800359731042 := by decide
theorem cert_e1402313219938 : check e1402313219938 [[.left],[.left]] .chain = true := by decide
def e1402313231842 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402313231842 : Closed e1402313231842 ∧ code e1402313231842 = 5800359742946 := by decide
theorem cert_e1402313231842 : check e1402313231842 [[.left],[.left]] .chain = true := by decide
def e1402313232290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402313232290 : Closed e1402313232290 ∧ code e1402313232290 = 5800359743394 := by decide
theorem cert_e1402313232290 : check e1402313232290 [[.left],[.left]] .chain = true := by decide
def e1402313241442 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402313241442 : Closed e1402313241442 ∧ code e1402313241442 = 5800359752546 := by decide
theorem cert_e1402313241442 : check e1402313241442 [[.left],[.left]] .chain = true := by decide
def e1402313241506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e1402313241506 : Closed e1402313241506 ∧ code e1402313241506 = 5800359752610 := by decide
theorem cert_e1402313241506 : check e1402313241506 [[.left],[.left]] .chain = true := by decide
def e1402313477858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402313477858 : Closed e1402313477858 ∧ code e1402313477858 = 5800359988962 := by decide
theorem cert_e1402313477858 : check e1402313477858 [[.left],[.left]] .chain = true := by decide
def e1402313477986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402313477986 : Closed e1402313477986 ∧ code e1402313477986 = 5800359989090 := by decide
theorem cert_e1402313477986 : check e1402313477986 [[.left],[.left]] .chain = true := by decide
def e1402313486818 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402313486818 : Closed e1402313486818 ∧ code e1402313486818 = 5800359997922 := by decide
theorem cert_e1402313486818 : check e1402313486818 [[.left],[.left]] .chain = true := by decide
def e1402313488134 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313488134 : Closed e1402313488134 ∧ code e1402313488134 = 5800359999238 := by decide
theorem cert_e1402313488134 : check e1402313488134 [[.left],[.left]] .chain = true := by decide
def e1402313488610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402313488610 : Closed e1402313488610 ∧ code e1402313488610 = 5800359999714 := by decide
theorem cert_e1402313488610 : check e1402313488610 [[.left],[.left]] .chain = true := by decide
def e1402313489158 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313489158 : Closed e1402313489158 ∧ code e1402313489158 = 5800360000262 := by decide
theorem cert_e1402313489158 : check e1402313489158 [[.left],[.left]] .chain = true := by decide
def e1402313492194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e1402313492194 : Closed e1402313492194 ∧ code e1402313492194 = 5800360003298 := by decide
theorem cert_e1402313492194 : check e1402313492194 [[.left],[.left]] .chain = true := by decide
def e1402313492386 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402313492386 : Closed e1402313492386 ∧ code e1402313492386 = 5800360003490 := by decide
theorem cert_e1402313492386 : check e1402313492386 [[.left],[.left]] .chain = true := by decide
def e1402313495010 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.var 0)))
theorem wire_e1402313495010 : Closed e1402313495010 ∧ code e1402313495010 = 5800360006114 := by decide
theorem cert_e1402313495010 : check e1402313495010 [[.left],[.left]] .chain = true := by decide
def e1402313496326 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313496326 : Closed e1402313496326 ∧ code e1402313496326 = 5800360007430 := by decide
theorem cert_e1402313496326 : check e1402313496326 [[.left],[.left]] .chain = true := by decide
def e1402313497474 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313497474 : Closed e1402313497474 ∧ code e1402313497474 = 5800360008578 := by decide
theorem cert_e1402313497474 : check e1402313497474 [[.left],[.left]] .chain = true := by decide
def e1402313497698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402313497698 : Closed e1402313497698 ∧ code e1402313497698 = 5800360008802 := by decide
theorem cert_e1402313497698 : check e1402313497698 [[.left],[.left]] .chain = true := by decide
def e1402313497862 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313497862 : Closed e1402313497862 ∧ code e1402313497862 = 5800360008966 := by decide
theorem cert_e1402313497862 : check e1402313497862 [[.left],[.left]] .chain = true := by decide
def e1402313497986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313497986 : Closed e1402313497986 ∧ code e1402313497986 = 5800360009090 := by decide
theorem cert_e1402313497986 : check e1402313497986 [[.left],[.left]] .chain = true := by decide
def e1402313499490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e1402313499490 : Closed e1402313499490 ∧ code e1402313499490 = 5800360010594 := by decide
theorem cert_e1402313499490 : check e1402313499490 [[.left],[.left]] .chain = true := by decide
def e1402313499554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e1402313499554 : Closed e1402313499554 ∧ code e1402313499554 = 5800360010658 := by decide
theorem cert_e1402313499554 : check e1402313499554 [[.left],[.left]] .chain = true := by decide
def e1402313500898 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.var 0)))
theorem wire_e1402313500898 : Closed e1402313500898 ∧ code e1402313500898 = 5800360012002 := by decide
theorem cert_e1402313500898 : check e1402313500898 [[.left],[.left]] .chain = true := by decide
def e1402313501446 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313501446 : Closed e1402313501446 ∧ code e1402313501446 = 5800360012550 := by decide
theorem cert_e1402313501446 : check e1402313501446 [[.left],[.left]] .chain = true := by decide
def e1402313501794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.var 0)))
theorem wire_e1402313501794 : Closed e1402313501794 ∧ code e1402313501794 = 5800360012898 := by decide
theorem cert_e1402313501794 : check e1402313501794 [[.left],[.left]] .chain = true := by decide
def e1402313501958 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313501958 : Closed e1402313501958 ∧ code e1402313501958 = 5800360013062 := by decide
theorem cert_e1402313501958 : check e1402313501958 [[.left],[.left]] .chain = true := by decide
def e1402313502082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313502082 : Closed e1402313502082 ∧ code e1402313502082 = 5800360013186 := by decide
theorem cert_e1402313502082 : check e1402313502082 [[.left],[.left]] .chain = true := by decide
def e1402313535970 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402313535970 : Closed e1402313535970 ∧ code e1402313535970 = 5800360047074 := by decide
theorem cert_e1402313535970 : check e1402313535970 [[.left],[.left]] .chain = true := by decide
def e1402313537286 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313537286 : Closed e1402313537286 ∧ code e1402313537286 = 5800360048390 := by decide
theorem cert_e1402313537286 : check e1402313537286 [[.left],[.left]] .chain = true := by decide
def e1402313537762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.var 0)))
theorem wire_e1402313537762 : Closed e1402313537762 ∧ code e1402313537762 = 5800360048866 := by decide
theorem cert_e1402313537762 : check e1402313537762 [[.left],[.left]] .chain = true := by decide
def e1402313538310 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313538310 : Closed e1402313538310 ∧ code e1402313538310 = 5800360049414 := by decide
theorem cert_e1402313538310 : check e1402313538310 [[.left],[.left]] .chain = true := by decide
def e1402313580058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1402313580058 : Closed e1402313580058 ∧ code e1402313580058 = 5800360091162 := by decide
theorem cert_e1402313580058 : check e1402313580058 [[.left]] .chain = true := by decide
def e1402313585122 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.var 0)))
theorem wire_e1402313585122 : Closed e1402313585122 ∧ code e1402313585122 = 5800360096226 := by decide
theorem cert_e1402313585122 : check e1402313585122 [[.left],[.left]] .chain = true := by decide
def e1402313586438 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 1))))
theorem wire_e1402313586438 : Closed e1402313586438 ∧ code e1402313586438 = 5800360097542 := by decide
theorem cert_e1402313586438 : check e1402313586438 [[.left],[.left]] .chain = true := by decide
def e1402313587586 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e1402313587586 : Closed e1402313587586 ∧ code e1402313587586 = 5800360098690 := by decide
theorem cert_e1402313587586 : check e1402313587586 [[.left],[.left]] .chain = true := by decide
def e1402313587810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.var 0)))
theorem wire_e1402313587810 : Closed e1402313587810 ∧ code e1402313587810 = 5800360098914 := by decide
theorem cert_e1402313587810 : check e1402313587810 [[.left],[.left]] .chain = true := by decide
end Blc.Floor42
