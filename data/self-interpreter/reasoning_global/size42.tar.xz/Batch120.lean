import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1209056606234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209056606234 : Closed e1209056606234 ∧ code e1209056606234 = 5607103117338 := by decide
theorem cert_e1209056606234 : check e1209056606234 [[]] .width = true := by decide
def e1209056614426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209056614426 : Closed e1209056614426 ∧ code e1209056614426 = 5607103125530 := by decide
theorem cert_e1209056614426 : check e1209056614426 [[]] .width = true := by decide
def e1209056849434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056849434 : Closed e1209056849434 ∧ code e1209056849434 = 5607103360538 := by decide
theorem cert_e1209056849434 : check e1209056849434 [[]] .width = true := by decide
def e1209056851482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056851482 : Closed e1209056851482 ∧ code e1209056851482 = 5607103362586 := by decide
theorem cert_e1209056851482 : check e1209056851482 [[]] .width = true := by decide
def e1209056867866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209056867866 : Closed e1209056867866 ∧ code e1209056867866 = 5607103378970 := by decide
theorem cert_e1209056867866 : check e1209056867866 [[]] .width = true := by decide
def e1209057179674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057179674 : Closed e1209057179674 ∧ code e1209057179674 = 5607103690778 := by decide
theorem cert_e1209057179674 : check e1209057179674 [[]] .width = true := by decide
def e1209057209882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057209882 : Closed e1209057209882 ∧ code e1209057209882 = 5607103720986 := by decide
theorem cert_e1209057209882 : check e1209057209882 [[]] .width = true := by decide
def e1209057211930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057211930 : Closed e1209057211930 ∧ code e1209057211930 = 5607103723034 := by decide
theorem cert_e1209057211930 : check e1209057211930 [[]] .width = true := by decide
def e1209057263814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209057263814 : Closed e1209057263814 ∧ code e1209057263814 = 5607103774918 := by decide
theorem cert_e1209057263814 : check e1209057263814 [[]] .width = true := by decide
def e1209057294362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057294362 : Closed e1209057294362 ∧ code e1209057294362 = 5607103805466 := by decide
theorem cert_e1209057294362 : check e1209057294362 [[]] .width = true := by decide
def e1209057310234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057310234 : Closed e1209057310234 ∧ code e1209057310234 = 5607103821338 := by decide
theorem cert_e1209057310234 : check e1209057310234 [[]] .width = true := by decide
def e1209057329350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209057329350 : Closed e1209057329350 ∧ code e1209057329350 = 5607103840454 := by decide
theorem cert_e1209057329350 : check e1209057329350 [[]] .width = true := by decide
def e1209057523738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057523738 : Closed e1209057523738 ∧ code e1209057523738 = 5607104034842 := by decide
theorem cert_e1209057523738 : check e1209057523738 [[]] .width = true := by decide
def e1209057536026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057536026 : Closed e1209057536026 ∧ code e1209057536026 = 5607104047130 := by decide
theorem cert_e1209057536026 : check e1209057536026 [[]] .width = true := by decide
def e1209057635866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057635866 : Closed e1209057635866 ∧ code e1209057635866 = 5607104146970 := by decide
theorem cert_e1209057635866 : check e1209057635866 [[]] .width = true := by decide
def e1209057637914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057637914 : Closed e1209057637914 ∧ code e1209057637914 = 5607104149018 := by decide
theorem cert_e1209057637914 : check e1209057637914 [[]] .width = true := by decide
def e1209057652250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057652250 : Closed e1209057652250 ∧ code e1209057652250 = 5607104163354 := by decide
theorem cert_e1209057652250 : check e1209057652250 [[]] .width = true := by decide
def e1209057655322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057655322 : Closed e1209057655322 ∧ code e1209057655322 = 5607104166426 := by decide
private def t_e1209057655322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209057655322 : ¬ IsSelfInterpreter e1209057655322 :=
  wSource (t := t_e1209057655322) (replay_sound (ps := []) (t := e1209057655322) (by decide)) (by decide)
def e1209057662490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057662490 : Closed e1209057662490 ∧ code e1209057662490 = 5607104173594 := by decide
theorem cert_e1209057662490 : check e1209057662490 [[]] .width = true := by decide
def e1209057663514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057663514 : Closed e1209057663514 ∧ code e1209057663514 = 5607104174618 := by decide
private def t_e1209057663514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209057663514 : ¬ IsSelfInterpreter e1209057663514 :=
  wSource (t := t_e1209057663514) (replay_sound (ps := []) (t := e1209057663514) (by decide)) (by decide)
def e1209057703962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057703962 : Closed e1209057703962 ∧ code e1209057703962 = 5607104215066 := by decide
theorem cert_e1209057703962 : check e1209057703962 [[]] .width = true := by decide
def e1209057734170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057734170 : Closed e1209057734170 ∧ code e1209057734170 = 5607104245274 := by decide
theorem cert_e1209057734170 : check e1209057734170 [[]] .width = true := by decide
def e1209057736218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057736218 : Closed e1209057736218 ∧ code e1209057736218 = 5607104247322 := by decide
theorem cert_e1209057736218 : check e1209057736218 [[]] .width = true := by decide
def e1209057788102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209057788102 : Closed e1209057788102 ∧ code e1209057788102 = 5607104299206 := by decide
theorem cert_e1209057788102 : check e1209057788102 [[]] .width = true := by decide
def e1209057832474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057832474 : Closed e1209057832474 ∧ code e1209057832474 = 5607104343578 := by decide
private def t_e1209057832474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209057832474 : ¬ IsSelfInterpreter e1209057832474 :=
  wSource (t := t_e1209057832474) (replay_sound (ps := []) (t := e1209057832474) (by decide)) (by decide)
def e1209057835546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057835546 : Closed e1209057835546 ∧ code e1209057835546 = 5607104346650 := by decide
private def t_e1209057835546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209057835546 : ¬ IsSelfInterpreter e1209057835546 :=
  wSource (t := t_e1209057835546) (replay_sound (ps := []) (t := e1209057835546) (by decide)) (by decide)
def e1209057875994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057875994 : Closed e1209057875994 ∧ code e1209057875994 = 5607104387098 := by decide
theorem cert_e1209057875994 : check e1209057875994 [[]] .width = true := by decide
def e1209057883674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057883674 : Closed e1209057883674 ∧ code e1209057883674 = 5607104394778 := by decide
private def t_e1209057883674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209057883674 : ¬ IsSelfInterpreter e1209057883674 :=
  wSource (t := t_e1209057883674) (replay_sound (ps := []) (t := e1209057883674) (by decide)) (by decide)
def e1209057884698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209057884698 : Closed e1209057884698 ∧ code e1209057884698 = 5607104395802 := by decide
private def t_e1209057884698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209057884698 : ¬ IsSelfInterpreter e1209057884698 :=
  wSource (t := t_e1209057884698) (replay_sound (ps := []) (t := e1209057884698) (by decide)) (by decide)
def e1209057886406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209057886406 : Closed e1209057886406 ∧ code e1209057886406 = 5607104397510 := by decide
theorem cert_e1209057886406 : check e1209057886406 [[]] .width = true := by decide
def e1209057990682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057990682 : Closed e1209057990682 ∧ code e1209057990682 = 5607104501786 := by decide
theorem cert_e1209057990682 : check e1209057990682 [[]] .width = true := by decide
def e1209057994778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209057994778 : Closed e1209057994778 ∧ code e1209057994778 = 5607104505882 := by decide
theorem cert_e1209057994778 : check e1209057994778 [[]] .width = true := by decide
def e1209058047514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209058047514 : Closed e1209058047514 ∧ code e1209058047514 = 5607104558618 := by decide
theorem cert_e1209058047514 : check e1209058047514 [[]] .width = true := by decide
def e1209058055706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209058055706 : Closed e1209058055706 ∧ code e1209058055706 = 5607104566810 := by decide
theorem cert_e1209058055706 : check e1209058055706 [[]] .width = true := by decide
def e1209058056730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209058056730 : Closed e1209058056730 ∧ code e1209058056730 = 5607104567834 := by decide
private def t_e1209058056730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209058056730 : ¬ IsSelfInterpreter e1209058056730 :=
  wSource (t := t_e1209058056730) (replay_sound (ps := []) (t := e1209058056730) (by decide)) (by decide)
def e1209058080794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209058080794 : Closed e1209058080794 ∧ code e1209058080794 = 5607104591898 := by decide
theorem cert_e1209058080794 : check e1209058080794 [[]] .width = true := by decide
def e1209058096666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209058096666 : Closed e1209058096666 ∧ code e1209058096666 = 5607104607770 := by decide
theorem cert_e1209058096666 : check e1209058096666 [[]] .width = true := by decide
def e1209058115782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209058115782 : Closed e1209058115782 ∧ code e1209058115782 = 5607104626886 := by decide
theorem cert_e1209058115782 : check e1209058115782 [[]] .width = true := by decide
def e1209058138138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209058138138 : Closed e1209058138138 ∧ code e1209058138138 = 5607104649242 := by decide
theorem cert_e1209058138138 : check e1209058138138 [[]] .width = true := by decide
def e1209058145818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209058145818 : Closed e1209058145818 ∧ code e1209058145818 = 5607104656922 := by decide
private def t_e1209058145818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209058145818 : ¬ IsSelfInterpreter e1209058145818 :=
  wSource (t := t_e1209058145818) (replay_sound (ps := []) (t := e1209058145818) (by decide)) (by decide)
def e1209058146842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209058146842 : Closed e1209058146842 ∧ code e1209058146842 = 5607104657946 := by decide
private def t_e1209058146842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209058146842 : ¬ IsSelfInterpreter e1209058146842 :=
  wSource (t := t_e1209058146842) (replay_sound (ps := []) (t := e1209058146842) (by decide)) (by decide)
def e1209058148550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209058148550 : Closed e1209058148550 ∧ code e1209058148550 = 5607104659654 := by decide
theorem cert_e1209058148550 : check e1209058148550 [[]] .width = true := by decide
def e1209059995162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209059995162 : Closed e1209059995162 ∧ code e1209059995162 = 5607106506266 := by decide
theorem cert_e1209059995162 : check e1209059995162 [[]] .width = true := by decide
def e1209059997210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209059997210 : Closed e1209059997210 ∧ code e1209059997210 = 5607106508314 := by decide
theorem cert_e1209059997210 : check e1209059997210 [[]] .width = true := by decide
def e1209060013594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209060013594 : Closed e1209060013594 ∧ code e1209060013594 = 5607106524698 := by decide
theorem cert_e1209060013594 : check e1209060013594 [[]] .width = true := by decide
def e1209060325402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209060325402 : Closed e1209060325402 ∧ code e1209060325402 = 5607106836506 := by decide
theorem cert_e1209060325402 : check e1209060325402 [[]] .width = true := by decide
def e1209060355610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209060355610 : Closed e1209060355610 ∧ code e1209060355610 = 5607106866714 := by decide
theorem cert_e1209060355610 : check e1209060355610 [[]] .width = true := by decide
def e1209060357658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209060357658 : Closed e1209060357658 ∧ code e1209060357658 = 5607106868762 := by decide
theorem cert_e1209060357658 : check e1209060357658 [[]] .width = true := by decide
def e1209060409542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209060409542 : Closed e1209060409542 ∧ code e1209060409542 = 5607106920646 := by decide
theorem cert_e1209060409542 : check e1209060409542 [[]] .width = true := by decide
def e1209060440090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209060440090 : Closed e1209060440090 ∧ code e1209060440090 = 5607106951194 := by decide
theorem cert_e1209060440090 : check e1209060440090 [[]] .width = true := by decide
def e1209060455962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209060455962 : Closed e1209060455962 ∧ code e1209060455962 = 5607106967066 := by decide
theorem cert_e1209060455962 : check e1209060455962 [[]] .width = true := by decide
def e1209060475078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209060475078 : Closed e1209060475078 ∧ code e1209060475078 = 5607106986182 := by decide
theorem cert_e1209060475078 : check e1209060475078 [[]] .width = true := by decide
def e1209063403034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063403034 : Closed e1209063403034 ∧ code e1209063403034 = 5607109914138 := by decide
theorem cert_e1209063403034 : check e1209063403034 [[]] .width = true := by decide
def e1209063405082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063405082 : Closed e1209063405082 ∧ code e1209063405082 = 5607109916186 := by decide
theorem cert_e1209063405082 : check e1209063405082 [[]] .width = true := by decide
def e1209063419418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063419418 : Closed e1209063419418 ∧ code e1209063419418 = 5607109930522 := by decide
theorem cert_e1209063419418 : check e1209063419418 [[]] .width = true := by decide
def e1209063422490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063422490 : Closed e1209063422490 ∧ code e1209063422490 = 5607109933594 := by decide
private def t_e1209063422490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209063422490 : ¬ IsSelfInterpreter e1209063422490 :=
  wSource (t := t_e1209063422490) (replay_sound (ps := []) (t := e1209063422490) (by decide)) (by decide)
def e1209063429658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063429658 : Closed e1209063429658 ∧ code e1209063429658 = 5607109940762 := by decide
theorem cert_e1209063429658 : check e1209063429658 [[]] .width = true := by decide
def e1209063430682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063430682 : Closed e1209063430682 ∧ code e1209063430682 = 5607109941786 := by decide
private def t_e1209063430682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209063430682 : ¬ IsSelfInterpreter e1209063430682 :=
  wSource (t := t_e1209063430682) (replay_sound (ps := []) (t := e1209063430682) (by decide)) (by decide)
def e1209063471130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209063471130 : Closed e1209063471130 ∧ code e1209063471130 = 5607109982234 := by decide
theorem cert_e1209063471130 : check e1209063471130 [[]] .width = true := by decide
def e1209063501338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063501338 : Closed e1209063501338 ∧ code e1209063501338 = 5607110012442 := by decide
theorem cert_e1209063501338 : check e1209063501338 [[]] .width = true := by decide
def e1209063503386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063503386 : Closed e1209063503386 ∧ code e1209063503386 = 5607110014490 := by decide
theorem cert_e1209063503386 : check e1209063503386 [[]] .width = true := by decide
def e1209063555270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209063555270 : Closed e1209063555270 ∧ code e1209063555270 = 5607110066374 := by decide
theorem cert_e1209063555270 : check e1209063555270 [[]] .width = true := by decide
def e1209063599642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063599642 : Closed e1209063599642 ∧ code e1209063599642 = 5607110110746 := by decide
theorem cert_e1209063599642 : check e1209063599642 [[]] .width = true := by decide
def e1209063602714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063602714 : Closed e1209063602714 ∧ code e1209063602714 = 5607110113818 := by decide
theorem cert_e1209063602714 : check e1209063602714 [[]] .width = true := by decide
def e1209063643162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209063643162 : Closed e1209063643162 ∧ code e1209063643162 = 5607110154266 := by decide
theorem cert_e1209063643162 : check e1209063643162 [[]] .width = true := by decide
def e1209063650842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063650842 : Closed e1209063650842 ∧ code e1209063650842 = 5607110161946 := by decide
theorem cert_e1209063650842 : check e1209063650842 [[]] .width = true := by decide
def e1209063651866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209063651866 : Closed e1209063651866 ∧ code e1209063651866 = 5607110162970 := by decide
theorem cert_e1209063651866 : check e1209063651866 [[]] .width = true := by decide
def e1209063653574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209063653574 : Closed e1209063653574 ∧ code e1209063653574 = 5607110164678 := by decide
theorem cert_e1209063653574 : check e1209063653574 [[]] .width = true := by decide
def e1209065125402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209065125402 : Closed e1209065125402 ∧ code e1209065125402 = 5607111636506 := by decide
theorem cert_e1209065125402 : check e1209065125402 [[]] .width = true := by decide
def e1209065133594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209065133594 : Closed e1209065133594 ∧ code e1209065133594 = 5607111644698 := by decide
theorem cert_e1209065133594 : check e1209065133594 [[]] .width = true := by decide
def e1209065134618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209065134618 : Closed e1209065134618 ∧ code e1209065134618 = 5607111645722 := by decide
private def t_e1209065134618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1209065134618 : ¬ IsSelfInterpreter e1209065134618 :=
  wSource (t := t_e1209065134618) (replay_sound (ps := []) (t := e1209065134618) (by decide)) (by decide)
def e1209065158682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209065158682 : Closed e1209065158682 ∧ code e1209065158682 = 5607111669786 := by decide
theorem cert_e1209065158682 : check e1209065158682 [[]] .width = true := by decide
def e1209065174554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209065174554 : Closed e1209065174554 ∧ code e1209065174554 = 5607111685658 := by decide
theorem cert_e1209065174554 : check e1209065174554 [[]] .width = true := by decide
def e1209065193670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209065193670 : Closed e1209065193670 ∧ code e1209065193670 = 5607111704774 := by decide
theorem cert_e1209065193670 : check e1209065193670 [[]] .width = true := by decide
def e1209065216026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1209065216026 : Closed e1209065216026 ∧ code e1209065216026 = 5607111727130 := by decide
theorem cert_e1209065216026 : check e1209065216026 [[]] .width = true := by decide
def e1209065223706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209065223706 : Closed e1209065223706 ∧ code e1209065223706 = 5607111734810 := by decide
theorem cert_e1209065223706 : check e1209065223706 [[]] .width = true := by decide
def e1209065224730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1209065224730 : Closed e1209065224730 ∧ code e1209065224730 = 5607111735834 := by decide
theorem cert_e1209065224730 : check e1209065224730 [[]] .width = true := by decide
def e1209065226438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1209065226438 : Closed e1209065226438 ∧ code e1209065226438 = 5607111737542 := by decide
theorem cert_e1209065226438 : check e1209065226438 [[]] .width = true := by decide
def e1209066937198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1209066937198 : Closed e1209066937198 ∧ code e1209066937198 = 5607113448302 := by decide
theorem cert_e1209066937198 : check e1209066937198 [[],[]] .chain = true := by decide
def e1209066937206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1209066937206 : Closed e1209066937206 ∧ code e1209066937206 = 5607113448310 := by decide
theorem cert_e1209066937206 : check e1209066937206 [[],[]] .chain = true := by decide
def e1209066937270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1209066937270 : Closed e1209066937270 ∧ code e1209066937270 = 5607113448374 := by decide
theorem cert_e1209066937270 : check e1209066937270 [[],[]] .chain = true := by decide
def e1209066937710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1209066937710 : Closed e1209066937710 ∧ code e1209066937710 = 5607113448814 := by decide
theorem cert_e1209066937710 : check e1209066937710 [[],[]] .chain = true := by decide
def e1209066937718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1209066937718 : Closed e1209066937718 ∧ code e1209066937718 = 5607113448822 := by decide
theorem cert_e1209066937718 : check e1209066937718 [[],[]] .chain = true := by decide
def e1209066937774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1209066937774 : Closed e1209066937774 ∧ code e1209066937774 = 5607113448878 := by decide
theorem cert_e1209066937774 : check e1209066937774 [[],[]] .chain = true := by decide
def e1209066937786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1209066937786 : Closed e1209066937786 ∧ code e1209066937786 = 5607113448890 := by decide
theorem cert_e1209066937786 : check e1209066937786 [[],[]] .chain = true := by decide
def e1209066937814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1209066937814 : Closed e1209066937814 ∧ code e1209066937814 = 5607113448918 := by decide
theorem cert_e1209066937814 : check e1209066937814 [[],[]] .chain = true := by decide
def e1209066937818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1209066937818 : Closed e1209066937818 ∧ code e1209066937818 = 5607113448922 := by decide
theorem cert_e1209066937818 : check e1209066937818 [[],[]] .chain = true := by decide
def e1209066938038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1209066938038 : Closed e1209066938038 ∧ code e1209066938038 = 5607113449142 := by decide
theorem cert_e1209066938038 : check e1209066938038 [[],[]] .chain = true := by decide
def e1209066938070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1209066938070 : Closed e1209066938070 ∧ code e1209066938070 = 5607113449174 := by decide
theorem cert_e1209066938070 : check e1209066938070 [[],[]] .chain = true := by decide
def e1209066938074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1209066938074 : Closed e1209066938074 ∧ code e1209066938074 = 5607113449178 := by decide
theorem cert_e1209066938074 : check e1209066938074 [[],[]] .chain = true := by decide
def e1209066940270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1209066940270 : Closed e1209066940270 ∧ code e1209066940270 = 5607113451374 := by decide
theorem cert_e1209066940270 : check e1209066940270 [[],[]] .chain = true := by decide
def e1209066940278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1209066940278 : Closed e1209066940278 ∧ code e1209066940278 = 5607113451382 := by decide
theorem cert_e1209066940278 : check e1209066940278 [[],[]] .chain = true := by decide
def e1209066940342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1209066940342 : Closed e1209066940342 ∧ code e1209066940342 = 5607113451446 := by decide
theorem cert_e1209066940342 : check e1209066940342 [[],[]] .chain = true := by decide
def e1209066941678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209066941678 : Closed e1209066941678 ∧ code e1209066941678 = 5607113452782 := by decide
theorem cert_e1209066941678 : check e1209066941678 [[],[]] .chain = true := by decide
def e1209066941686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209066941686 : Closed e1209066941686 ∧ code e1209066941686 = 5607113452790 := by decide
theorem cert_e1209066941686 : check e1209066941686 [[],[]] .chain = true := by decide
def e1209066942070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209066942070 : Closed e1209066942070 ∧ code e1209066942070 = 5607113453174 := by decide
theorem cert_e1209066942070 : check e1209066942070 [[],[]] .chain = true := by decide
def e1209066943342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1209066943342 : Closed e1209066943342 ∧ code e1209066943342 = 5607113454446 := by decide
theorem cert_e1209066943342 : check e1209066943342 [[],[]] .chain = true := by decide
def e1209066943350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1209066943350 : Closed e1209066943350 ∧ code e1209066943350 = 5607113454454 := by decide
theorem cert_e1209066943350 : check e1209066943350 [[],[]] .chain = true := by decide
def e1209066943406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1209066943406 : Closed e1209066943406 ∧ code e1209066943406 = 5607113454510 := by decide
theorem cert_e1209066943406 : check e1209066943406 [[],[]] .chain = true := by decide
def e1209066943418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1209066943418 : Closed e1209066943418 ∧ code e1209066943418 = 5607113454522 := by decide
theorem cert_e1209066943418 : check e1209066943418 [[],[]] .chain = true := by decide
def e1209066943446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1209066943446 : Closed e1209066943446 ∧ code e1209066943446 = 5607113454550 := by decide
theorem cert_e1209066943446 : check e1209066943446 [[],[]] .chain = true := by decide
def e1209066943450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1209066943450 : Closed e1209066943450 ∧ code e1209066943450 = 5607113454554 := by decide
theorem cert_e1209066943450 : check e1209066943450 [[],[]] .chain = true := by decide
def e1209066943726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1209066943726 : Closed e1209066943726 ∧ code e1209066943726 = 5607113454830 := by decide
theorem cert_e1209066943726 : check e1209066943726 [[],[]] .chain = true := by decide
def e1209066943734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1209066943734 : Closed e1209066943734 ∧ code e1209066943734 = 5607113454838 := by decide
theorem cert_e1209066943734 : check e1209066943734 [[],[]] .chain = true := by decide
def e1209066944110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1209066944110 : Closed e1209066944110 ∧ code e1209066944110 = 5607113455214 := by decide
theorem cert_e1209066944110 : check e1209066944110 [[],[]] .chain = true := by decide
def e1209066944122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1209066944122 : Closed e1209066944122 ∧ code e1209066944122 = 5607113455226 := by decide
theorem cert_e1209066944122 : check e1209066944122 [[],[]] .chain = true := by decide
def e1209066944310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209066944310 : Closed e1209066944310 ∧ code e1209066944310 = 5607113455414 := by decide
theorem cert_e1209066944310 : check e1209066944310 [[],[]] .chain = true := by decide
def e1209066944314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209066944314 : Closed e1209066944314 ∧ code e1209066944314 = 5607113455418 := by decide
theorem cert_e1209066944314 : check e1209066944314 [[],[]] .chain = true := by decide
def e1209066944950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1209066944950 : Closed e1209066944950 ∧ code e1209066944950 = 5607113456054 := by decide
theorem cert_e1209066944950 : check e1209066944950 [[],[]] .chain = true := by decide
def e1209066944982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1209066944982 : Closed e1209066944982 ∧ code e1209066944982 = 5607113456086 := by decide
theorem cert_e1209066944982 : check e1209066944982 [[],[]] .chain = true := by decide
def e1209066944986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1209066944986 : Closed e1209066944986 ∧ code e1209066944986 = 5607113456090 := by decide
theorem cert_e1209066944986 : check e1209066944986 [[],[]] .chain = true := by decide
def e1209066945142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1209066945142 : Closed e1209066945142 ∧ code e1209066945142 = 5607113456246 := by decide
theorem cert_e1209066945142 : check e1209066945142 [[],[]] .chain = true := by decide
def e1209066945334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1209066945334 : Closed e1209066945334 ∧ code e1209066945334 = 5607113456438 := by decide
theorem cert_e1209066945334 : check e1209066945334 [[],[]] .chain = true := by decide
def e1209066945338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1209066945338 : Closed e1209066945338 ∧ code e1209066945338 = 5607113456442 := by decide
theorem cert_e1209066945338 : check e1209066945338 [[],[]] .chain = true := by decide
def e1209066952558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1209066952558 : Closed e1209066952558 ∧ code e1209066952558 = 5607113463662 := by decide
theorem cert_e1209066952558 : check e1209066952558 [[],[]] .chain = true := by decide
def e1209066952566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1209066952566 : Closed e1209066952566 ∧ code e1209066952566 = 5607113463670 := by decide
theorem cert_e1209066952566 : check e1209066952566 [[],[]] .chain = true := by decide
def e1209066952630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1209066952630 : Closed e1209066952630 ∧ code e1209066952630 = 5607113463734 := by decide
theorem cert_e1209066952630 : check e1209066952630 [[],[]] .chain = true := by decide
def e1209066953966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1209066953966 : Closed e1209066953966 ∧ code e1209066953966 = 5607113465070 := by decide
theorem cert_e1209066953966 : check e1209066953966 [[],[]] .chain = true := by decide
def e1209066953974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1209066953974 : Closed e1209066953974 ∧ code e1209066953974 = 5607113465078 := by decide
theorem cert_e1209066953974 : check e1209066953974 [[],[]] .chain = true := by decide
def e1209066954358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1209066954358 : Closed e1209066954358 ∧ code e1209066954358 = 5607113465462 := by decide
theorem cert_e1209066954358 : check e1209066954358 [[],[]] .chain = true := by decide
def e1209066965870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209066965870 : Closed e1209066965870 ∧ code e1209066965870 = 5607113476974 := by decide
theorem cert_e1209066965870 : check e1209066965870 [[],[]] .chain = true := by decide
def e1209066965878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209066965878 : Closed e1209066965878 ∧ code e1209066965878 = 5607113476982 := by decide
theorem cert_e1209066965878 : check e1209066965878 [[],[]] .chain = true := by decide
def e1209066965934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209066965934 : Closed e1209066965934 ∧ code e1209066965934 = 5607113477038 := by decide
theorem cert_e1209066965934 : check e1209066965934 [[],[]] .chain = true := by decide
def e1209066965946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209066965946 : Closed e1209066965946 ∧ code e1209066965946 = 5607113477050 := by decide
theorem cert_e1209066965946 : check e1209066965946 [[],[]] .chain = true := by decide
def e1209066965974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209066965974 : Closed e1209066965974 ∧ code e1209066965974 = 5607113477078 := by decide
theorem cert_e1209066965974 : check e1209066965974 [[],[]] .chain = true := by decide
def e1209066965978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209066965978 : Closed e1209066965978 ∧ code e1209066965978 = 5607113477082 := by decide
theorem cert_e1209066965978 : check e1209066965978 [[],[]] .chain = true := by decide
def e1209066966254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209066966254 : Closed e1209066966254 ∧ code e1209066966254 = 5607113477358 := by decide
theorem cert_e1209066966254 : check e1209066966254 [[],[]] .chain = true := by decide
def e1209066966262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209066966262 : Closed e1209066966262 ∧ code e1209066966262 = 5607113477366 := by decide
theorem cert_e1209066966262 : check e1209066966262 [[],[]] .chain = true := by decide
def e1209066966638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209066966638 : Closed e1209066966638 ∧ code e1209066966638 = 5607113477742 := by decide
theorem cert_e1209066966638 : check e1209066966638 [[],[]] .chain = true := by decide
def e1209066966650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209066966650 : Closed e1209066966650 ∧ code e1209066966650 = 5607113477754 := by decide
theorem cert_e1209066966650 : check e1209066966650 [[],[]] .chain = true := by decide
def e1209066966838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209066966838 : Closed e1209066966838 ∧ code e1209066966838 = 5607113477942 := by decide
theorem cert_e1209066966838 : check e1209066966838 [[],[]] .chain = true := by decide
def e1209066966842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209066966842 : Closed e1209066966842 ∧ code e1209066966842 = 5607113477946 := by decide
theorem cert_e1209066966842 : check e1209066966842 [[],[]] .chain = true := by decide
def e1209066972598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1209066972598 : Closed e1209066972598 ∧ code e1209066972598 = 5607113483702 := by decide
theorem cert_e1209066972598 : check e1209066972598 [[],[]] .chain = true := by decide
def e1209066972630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1209066972630 : Closed e1209066972630 ∧ code e1209066972630 = 5607113483734 := by decide
theorem cert_e1209066972630 : check e1209066972630 [[],[]] .chain = true := by decide
def e1209066972634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1209066972634 : Closed e1209066972634 ∧ code e1209066972634 = 5607113483738 := by decide
theorem cert_e1209066972634 : check e1209066972634 [[],[]] .chain = true := by decide
def e1209066972790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1209066972790 : Closed e1209066972790 ∧ code e1209066972790 = 5607113483894 := by decide
theorem cert_e1209066972790 : check e1209066972790 [[],[]] .chain = true := by decide
def e1209066972982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1209066972982 : Closed e1209066972982 ∧ code e1209066972982 = 5607113484086 := by decide
theorem cert_e1209066972982 : check e1209066972982 [[],[]] .chain = true := by decide
def e1209066972986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1209066972986 : Closed e1209066972986 ∧ code e1209066972986 = 5607113484090 := by decide
theorem cert_e1209066972986 : check e1209066972986 [[],[]] .chain = true := by decide
def e1209067309934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1209067309934 : Closed e1209067309934 ∧ code e1209067309934 = 5607113821038 := by decide
theorem cert_e1209067309934 : check e1209067309934 [[],[],[.under,.left]] .chain = true := by decide
def e1209067309942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1209067309942 : Closed e1209067309942 ∧ code e1209067309942 = 5607113821046 := by decide
theorem cert_e1209067309942 : check e1209067309942 [[],[],[.under,.left]] .chain = true := by decide
def e1209067309998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1209067309998 : Closed e1209067309998 ∧ code e1209067309998 = 5607113821102 := by decide
theorem cert_e1209067309998 : check e1209067309998 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1209067310010 : Closed e1209067310010 ∧ code e1209067310010 = 5607113821114 := by decide
theorem cert_e1209067310010 : check e1209067310010 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1209067310038 : Closed e1209067310038 ∧ code e1209067310038 = 5607113821142 := by decide
theorem cert_e1209067310038 : check e1209067310038 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1209067310042 : Closed e1209067310042 ∧ code e1209067310042 = 5607113821146 := by decide
theorem cert_e1209067310042 : check e1209067310042 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1209067310318 : Closed e1209067310318 ∧ code e1209067310318 = 5607113821422 := by decide
theorem cert_e1209067310318 : check e1209067310318 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1209067310326 : Closed e1209067310326 ∧ code e1209067310326 = 5607113821430 := by decide
theorem cert_e1209067310326 : check e1209067310326 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1209067310702 : Closed e1209067310702 ∧ code e1209067310702 = 5607113821806 := by decide
theorem cert_e1209067310702 : check e1209067310702 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1209067310714 : Closed e1209067310714 ∧ code e1209067310714 = 5607113821818 := by decide
theorem cert_e1209067310714 : check e1209067310714 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1209067310902 : Closed e1209067310902 ∧ code e1209067310902 = 5607113822006 := by decide
theorem cert_e1209067310902 : check e1209067310902 [[],[],[.under,.left]] .chain = true := by decide
def e1209067310906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1209067310906 : Closed e1209067310906 ∧ code e1209067310906 = 5607113822010 := by decide
theorem cert_e1209067310906 : check e1209067310906 [[],[],[.under,.left]] .chain = true := by decide
def e1209083669870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1209083669870 : Closed e1209083669870 ∧ code e1209083669870 = 5607130180974 := by decide
theorem cert_e1209083669870 : check e1209083669870 [[],[]] .chain = true := by decide
def e1209083669878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1209083669878 : Closed e1209083669878 ∧ code e1209083669878 = 5607130180982 := by decide
theorem cert_e1209083669878 : check e1209083669878 [[],[]] .chain = true := by decide
def e1209083669934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1209083669934 : Closed e1209083669934 ∧ code e1209083669934 = 5607130181038 := by decide
theorem cert_e1209083669934 : check e1209083669934 [[],[]] .chain = true := by decide
def e1209083669946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1209083669946 : Closed e1209083669946 ∧ code e1209083669946 = 5607130181050 := by decide
theorem cert_e1209083669946 : check e1209083669946 [[],[]] .chain = true := by decide
def e1209083669974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1209083669974 : Closed e1209083669974 ∧ code e1209083669974 = 5607130181078 := by decide
theorem cert_e1209083669974 : check e1209083669974 [[],[]] .chain = true := by decide
def e1209083669978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1209083669978 : Closed e1209083669978 ∧ code e1209083669978 = 5607130181082 := by decide
theorem cert_e1209083669978 : check e1209083669978 [[],[]] .chain = true := by decide
def e1209083670190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1209083670190 : Closed e1209083670190 ∧ code e1209083670190 = 5607130181294 := by decide
theorem cert_e1209083670190 : check e1209083670190 [[],[]] .chain = true := by decide
def e1209083670202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1209083670202 : Closed e1209083670202 ∧ code e1209083670202 = 5607130181306 := by decide
theorem cert_e1209083670202 : check e1209083670202 [[],[]] .chain = true := by decide
def e1209083670250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1209083670250 : Closed e1209083670250 ∧ code e1209083670250 = 5607130181354 := by decide
theorem cert_e1209083670250 : check e1209083670250 [[],[]] .chain = true := by decide
def e1209083670358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1209083670358 : Closed e1209083670358 ∧ code e1209083670358 = 5607130181462 := by decide
theorem cert_e1209083670358 : check e1209083670358 [[],[]] .chain = true := by decide
end Blc.Floor42
