import Batch044
import ExtraBase
namespace Blc.Floor42.Extra044
open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38
set_option maxRecDepth 30000
set_option maxHeartbeats 6000000
private def t_e1124576878042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem ex_e1124576878042 : ¬ IsSelfInterpreter e1124576878042 := by
  intro he
  have hp := replay_sound (t := e1124576878042) (u := t_e1124576878042) (ps := []) (by decide)
  apply selfInterpreter_not_so (reductSI hp he)
  exact (SO.app (so_closed_lam (by decide) (SO.lam (g := (.app (.app (.var 1) (.var 0)) (.var 1))) (r := (.var 0)) (SO.app (SO.app (SO.var 1) (SO.var 0)) (SO.var 1)) (SO.var 0) (by decide) (by rfl))) (so_closed_lam (by decide) (SO.lam (g := (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))) (r := (.var 0)) (SO.lam (g := (.app (.var 1) (.var 0))) (r := (.app (.app (.var 0) (.var 1)) (.var 0))) (SO.app (SO.app (SO.app (SO.var 1) (SO.var 2)) (SO.var 1)) (SO.var 0)) (SO.app (SO.app (SO.var 0) (SO.var 1)) (SO.var 0)) (by decide) (by rfl)) (SO.var 0) (by decide) (by rfl))))
#print axioms ex_e1124576878042
end Blc.Floor42.Extra044
