import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196349918126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196349918126 : Closed e1196349918126 ∧ code e1196349918126 = 5594396429230 := by decide
theorem cert_e1196349918126 : check e1196349918126 [[],[.left],[]] .chain = true := by decide
def e1196349918138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196349918138 : Closed e1196349918138 ∧ code e1196349918138 = 5594396429242 := by decide
theorem cert_e1196349918138 : check e1196349918138 [[],[.left],[]] .chain = true := by decide
def e1196349918166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196349918166 : Closed e1196349918166 ∧ code e1196349918166 = 5594396429270 := by decide
theorem cert_e1196349918166 : check e1196349918166 [[],[.left],[]] .chain = true := by decide
def e1196349918170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196349918170 : Closed e1196349918170 ∧ code e1196349918170 = 5594396429274 := by decide
theorem cert_e1196349918170 : check e1196349918170 [[],[.left],[]] .chain = true := by decide
def e1196349918446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196349918446 : Closed e1196349918446 ∧ code e1196349918446 = 5594396429550 := by decide
theorem cert_e1196349918446 : check e1196349918446 [[],[.left],[]] .chain = true := by decide
def e1196349918454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196349918454 : Closed e1196349918454 ∧ code e1196349918454 = 5594396429558 := by decide
theorem cert_e1196349918454 : check e1196349918454 [[],[.left],[]] .chain = true := by decide
def e1196349918830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196349918830 : Closed e1196349918830 ∧ code e1196349918830 = 5594396429934 := by decide
theorem cert_e1196349918830 : check e1196349918830 [[],[.left],[]] .chain = true := by decide
def e1196349918842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196349918842 : Closed e1196349918842 ∧ code e1196349918842 = 5594396429946 := by decide
theorem cert_e1196349918842 : check e1196349918842 [[],[.left],[]] .chain = true := by decide
def e1196349919030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196349919030 : Closed e1196349919030 ∧ code e1196349919030 = 5594396430134 := by decide
theorem cert_e1196349919030 : check e1196349919030 [[],[.left],[]] .chain = true := by decide
def e1196349919034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196349919034 : Closed e1196349919034 ∧ code e1196349919034 = 5594396430138 := by decide
theorem cert_e1196349919034 : check e1196349919034 [[],[.left],[]] .chain = true := by decide
def e1196349927150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e1196349927150 : Closed e1196349927150 ∧ code e1196349927150 = 5594396438254 := by decide
theorem cert_e1196349927150 : check e1196349927150 [[],[.left],[]] .sourceHead = true := by decide
def e1196349927278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e1196349927278 : Closed e1196349927278 ∧ code e1196349927278 = 5594396438382 := by decide
theorem cert_e1196349927278 : check e1196349927278 [[],[.left],[]] .sourceHead = true := by decide
def e1196349927286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e1196349927286 : Closed e1196349927286 ∧ code e1196349927286 = 5594396438390 := by decide
theorem cert_e1196349927286 : check e1196349927286 [[],[.left],[]] .sourceHead = true := by decide
def e1196349929966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e1196349929966 : Closed e1196349929966 ∧ code e1196349929966 = 5594396441070 := by decide
theorem cert_e1196349929966 : check e1196349929966 [[],[.left],[]] .sourceHead = true := by decide
def e1196349930734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e1196349930734 : Closed e1196349930734 ∧ code e1196349930734 = 5594396441838 := by decide
theorem cert_e1196349930734 : check e1196349930734 [[],[.left],[]] .sourceHead = true := by decide
def e1196349930742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e1196349930742 : Closed e1196349930742 ∧ code e1196349930742 = 5594396441846 := by decide
theorem cert_e1196349930742 : check e1196349930742 [[],[.left],[]] .sourceHead = true := by decide
def e1196349953774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e1196349953774 : Closed e1196349953774 ∧ code e1196349953774 = 5594396464878 := by decide
theorem cert_e1196349953774 : check e1196349953774 [[],[.left],[],[.under]] .smaller = true := by decide
def e1196349953966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e1196349953966 : Closed e1196349953966 ∧ code e1196349953966 = 5594396465070 := by decide
theorem cert_e1196349953966 : check e1196349953966 [[],[.left],[],[.under]] .smaller = true := by decide
def e1196349953978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e1196349953978 : Closed e1196349953978 ∧ code e1196349953978 = 5594396465082 := by decide
theorem cert_e1196349953978 : check e1196349953978 [[],[.left],[],[.under]] .smaller = true := by decide
def e1196349954542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e1196349954542 : Closed e1196349954542 ∧ code e1196349954542 = 5594396465646 := by decide
theorem cert_e1196349954542 : check e1196349954542 [[],[.left],[],[.under]] .smaller = true := by decide
def e1196349955694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e1196349955694 : Closed e1196349955694 ∧ code e1196349955694 = 5594396466798 := by decide
theorem cert_e1196349955694 : check e1196349955694 [[],[.left],[],[.under]] .smaller = true := by decide
def e1196349955706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e1196349955706 : Closed e1196349955706 ∧ code e1196349955706 = 5594396466810 := by decide
theorem cert_e1196349955706 : check e1196349955706 [[],[.left],[],[.under]] .smaller = true := by decide
def e1196349967214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196349967214 : Closed e1196349967214 ∧ code e1196349967214 = 5594396478318 := by decide
theorem cert_e1196349967214 : check e1196349967214 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196349967222 : Closed e1196349967222 ∧ code e1196349967222 = 5594396478326 := by decide
theorem cert_e1196349967222 : check e1196349967222 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196349967278 : Closed e1196349967278 ∧ code e1196349967278 = 5594396478382 := by decide
theorem cert_e1196349967278 : check e1196349967278 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196349967290 : Closed e1196349967290 ∧ code e1196349967290 = 5594396478394 := by decide
theorem cert_e1196349967290 : check e1196349967290 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196349967318 : Closed e1196349967318 ∧ code e1196349967318 = 5594396478422 := by decide
theorem cert_e1196349967318 : check e1196349967318 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196349967322 : Closed e1196349967322 ∧ code e1196349967322 = 5594396478426 := by decide
theorem cert_e1196349967322 : check e1196349967322 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196349967598 : Closed e1196349967598 ∧ code e1196349967598 = 5594396478702 := by decide
theorem cert_e1196349967598 : check e1196349967598 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196349967606 : Closed e1196349967606 ∧ code e1196349967606 = 5594396478710 := by decide
theorem cert_e1196349967606 : check e1196349967606 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196349967982 : Closed e1196349967982 ∧ code e1196349967982 = 5594396479086 := by decide
theorem cert_e1196349967982 : check e1196349967982 [[],[.left],[],[.under]] .three = true := by decide
def e1196349967994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196349967994 : Closed e1196349967994 ∧ code e1196349967994 = 5594396479098 := by decide
theorem cert_e1196349967994 : check e1196349967994 [[],[.left],[],[.under]] .three = true := by decide
def e1196349968182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196349968182 : Closed e1196349968182 ∧ code e1196349968182 = 5594396479286 := by decide
theorem cert_e1196349968182 : check e1196349968182 [[],[.left],[],[.under]] .three = true := by decide
def e1196349968186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196349968186 : Closed e1196349968186 ∧ code e1196349968186 = 5594396479290 := by decide
theorem cert_e1196349968186 : check e1196349968186 [[],[.left],[],[.under]] .three = true := by decide
def e1196350507886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e1196350507886 : Closed e1196350507886 ∧ code e1196350507886 = 5594397018990 := by decide
theorem cert_e1196350507886 : check e1196350507886 [[],[.left],[],[]] .smaller = true := by decide
def e1196350507894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e1196350507894 : Closed e1196350507894 ∧ code e1196350507894 = 5594397018998 := by decide
theorem cert_e1196350507894 : check e1196350507894 [[],[.left],[],[]] .smaller = true := by decide
def e1196350507950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e1196350507950 : Closed e1196350507950 ∧ code e1196350507950 = 5594397019054 := by decide
theorem cert_e1196350507950 : check e1196350507950 [[],[.left],[],[]] .smaller = true := by decide
def e1196350507962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e1196350507962 : Closed e1196350507962 ∧ code e1196350507962 = 5594397019066 := by decide
theorem cert_e1196350507962 : check e1196350507962 [[],[.left],[],[]] .smaller = true := by decide
def e1196350507990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e1196350507990 : Closed e1196350507990 ∧ code e1196350507990 = 5594397019094 := by decide
theorem cert_e1196350507990 : check e1196350507990 [[],[.left],[],[]] .smaller = true := by decide
def e1196350507994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e1196350507994 : Closed e1196350507994 ∧ code e1196350507994 = 5594397019098 := by decide
theorem cert_e1196350507994 : check e1196350507994 [[],[.left],[],[]] .smaller = true := by decide
def e1196350508270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196350508270 : Closed e1196350508270 ∧ code e1196350508270 = 5594397019374 := by decide
theorem cert_e1196350508270 : check e1196350508270 [[],[.left],[],[]] .smaller = true := by decide
def e1196350508278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196350508278 : Closed e1196350508278 ∧ code e1196350508278 = 5594397019382 := by decide
theorem cert_e1196350508278 : check e1196350508278 [[],[.left],[],[]] .smaller = true := by decide
def e1196350508654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e1196350508654 : Closed e1196350508654 ∧ code e1196350508654 = 5594397019758 := by decide
theorem cert_e1196350508654 : check e1196350508654 [[],[.left],[],[]] .smaller = true := by decide
def e1196350508666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e1196350508666 : Closed e1196350508666 ∧ code e1196350508666 = 5594397019770 := by decide
theorem cert_e1196350508666 : check e1196350508666 [[],[.left],[],[]] .smaller = true := by decide
def e1196350508854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196350508854 : Closed e1196350508854 ∧ code e1196350508854 = 5594397019958 := by decide
theorem cert_e1196350508854 : check e1196350508854 [[],[.left],[],[]] .smaller = true := by decide
def e1196350508858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196350508858 : Closed e1196350508858 ∧ code e1196350508858 = 5594397019962 := by decide
theorem cert_e1196350508858 : check e1196350508858 [[],[.left],[],[]] .smaller = true := by decide
def e1196584688494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1196584688494 : Closed e1196584688494 ∧ code e1196584688494 = 5594631199598 := by decide
theorem cert_e1196584688494 : check e1196584688494 [[],[.left],[]] .sourceHead = true := by decide
def e1196584688502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1196584688502 : Closed e1196584688502 ∧ code e1196584688502 = 5594631199606 := by decide
theorem cert_e1196584688502 : check e1196584688502 [[],[.left],[]] .sourceHead = true := by decide
def e1196584688566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1196584688566 : Closed e1196584688566 ∧ code e1196584688566 = 5594631199670 := by decide
theorem cert_e1196584688566 : check e1196584688566 [[],[.left],[]] .sourceHead = true := by decide
def e1196584689006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1196584689006 : Closed e1196584689006 ∧ code e1196584689006 = 5594631200110 := by decide
theorem cert_e1196584689006 : check e1196584689006 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196584689014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1196584689014 : Closed e1196584689014 ∧ code e1196584689014 = 5594631200118 := by decide
theorem cert_e1196584689014 : check e1196584689014 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196584689070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1196584689070 : Closed e1196584689070 ∧ code e1196584689070 = 5594631200174 := by decide
def e1196584689082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1196584689082 : Closed e1196584689082 ∧ code e1196584689082 = 5594631200186 := by decide
def e1196584689110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1196584689110 : Closed e1196584689110 ∧ code e1196584689110 = 5594631200214 := by decide
theorem cert_e1196584689110 : check e1196584689110 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196584689114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1196584689114 : Closed e1196584689114 ∧ code e1196584689114 = 5594631200218 := by decide
def e1196584689334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1196584689334 : Closed e1196584689334 ∧ code e1196584689334 = 5594631200438 := by decide
theorem cert_e1196584689334 : check e1196584689334 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584689366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1196584689366 : Closed e1196584689366 ∧ code e1196584689366 = 5594631200470 := by decide
theorem cert_e1196584689366 : check e1196584689366 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196584689370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1196584689370 : Closed e1196584689370 ∧ code e1196584689370 = 5594631200474 := by decide
def e1196584691566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1196584691566 : Closed e1196584691566 ∧ code e1196584691566 = 5594631202670 := by decide
theorem cert_e1196584691566 : check e1196584691566 [[],[.left],[]] .sourceHead = true := by decide
def e1196584691574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1196584691574 : Closed e1196584691574 ∧ code e1196584691574 = 5594631202678 := by decide
theorem cert_e1196584691574 : check e1196584691574 [[],[.left],[]] .sourceHead = true := by decide
def e1196584691638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1196584691638 : Closed e1196584691638 ∧ code e1196584691638 = 5594631202742 := by decide
theorem cert_e1196584691638 : check e1196584691638 [[],[.left],[]] .sourceHead = true := by decide
def e1196584692974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196584692974 : Closed e1196584692974 ∧ code e1196584692974 = 5594631204078 := by decide
theorem cert_e1196584692974 : check e1196584692974 [[],[.left],[]] .sourceHead = true := by decide
def e1196584692982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196584692982 : Closed e1196584692982 ∧ code e1196584692982 = 5594631204086 := by decide
theorem cert_e1196584692982 : check e1196584692982 [[],[.left],[]] .sourceHead = true := by decide
def e1196584693366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196584693366 : Closed e1196584693366 ∧ code e1196584693366 = 5594631204470 := by decide
theorem cert_e1196584693366 : check e1196584693366 [[],[.left],[]] .sourceHead = true := by decide
def e1196584694638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1196584694638 : Closed e1196584694638 ∧ code e1196584694638 = 5594631205742 := by decide
theorem cert_e1196584694638 : check e1196584694638 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584694646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1196584694646 : Closed e1196584694646 ∧ code e1196584694646 = 5594631205750 := by decide
theorem cert_e1196584694646 : check e1196584694646 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584694702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1196584694702 : Closed e1196584694702 ∧ code e1196584694702 = 5594631205806 := by decide
theorem cert_e1196584694702 : check e1196584694702 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e1196584694714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1196584694714 : Closed e1196584694714 ∧ code e1196584694714 = 5594631205818 := by decide
def e1196584694742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1196584694742 : Closed e1196584694742 ∧ code e1196584694742 = 5594631205846 := by decide
theorem cert_e1196584694742 : check e1196584694742 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584694746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1196584694746 : Closed e1196584694746 ∧ code e1196584694746 = 5594631205850 := by decide
def e1196584695022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196584695022 : Closed e1196584695022 ∧ code e1196584695022 = 5594631206126 := by decide
theorem cert_e1196584695022 : check e1196584695022 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584695030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196584695030 : Closed e1196584695030 ∧ code e1196584695030 = 5594631206134 := by decide
theorem cert_e1196584695030 : check e1196584695030 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584695406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196584695406 : Closed e1196584695406 ∧ code e1196584695406 = 5594631206510 := by decide
def e1196584695418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196584695418 : Closed e1196584695418 ∧ code e1196584695418 = 5594631206522 := by decide
def e1196584695606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196584695606 : Closed e1196584695606 ∧ code e1196584695606 = 5594631206710 := by decide
theorem cert_e1196584695606 : check e1196584695606 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584695610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196584695610 : Closed e1196584695610 ∧ code e1196584695610 = 5594631206714 := by decide
theorem cert_e1196584695610 : check e1196584695610 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584696246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1196584696246 : Closed e1196584696246 ∧ code e1196584696246 = 5594631207350 := by decide
theorem cert_e1196584696246 : check e1196584696246 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584696278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1196584696278 : Closed e1196584696278 ∧ code e1196584696278 = 5594631207382 := by decide
theorem cert_e1196584696278 : check e1196584696278 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1196584696282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1196584696282 : Closed e1196584696282 ∧ code e1196584696282 = 5594631207386 := by decide
def e1196584696438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196584696438 : Closed e1196584696438 ∧ code e1196584696438 = 5594631207542 := by decide
theorem cert_e1196584696438 : checkPay e1196584696438 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196584696630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196584696630 : Closed e1196584696630 ∧ code e1196584696630 = 5594631207734 := by decide
theorem cert_e1196584696630 : check e1196584696630 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584696634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196584696634 : Closed e1196584696634 ∧ code e1196584696634 = 5594631207738 := by decide
theorem cert_e1196584696634 : check e1196584696634 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584703854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1196584703854 : Closed e1196584703854 ∧ code e1196584703854 = 5594631214958 := by decide
theorem cert_e1196584703854 : check e1196584703854 [[],[.left],[]] .sourceHead = true := by decide
def e1196584703862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1196584703862 : Closed e1196584703862 ∧ code e1196584703862 = 5594631214966 := by decide
theorem cert_e1196584703862 : check e1196584703862 [[],[.left],[]] .sourceHead = true := by decide
def e1196584703926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1196584703926 : Closed e1196584703926 ∧ code e1196584703926 = 5594631215030 := by decide
theorem cert_e1196584703926 : check e1196584703926 [[],[.left],[]] .sourceHead = true := by decide
def e1196584705262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1196584705262 : Closed e1196584705262 ∧ code e1196584705262 = 5594631216366 := by decide
theorem cert_e1196584705262 : check e1196584705262 [[],[.left],[]] .sourceHead = true := by decide
def e1196584705270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1196584705270 : Closed e1196584705270 ∧ code e1196584705270 = 5594631216374 := by decide
theorem cert_e1196584705270 : check e1196584705270 [[],[.left],[]] .sourceHead = true := by decide
def e1196584705654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1196584705654 : Closed e1196584705654 ∧ code e1196584705654 = 5594631216758 := by decide
theorem cert_e1196584705654 : check e1196584705654 [[],[.left],[]] .sourceHead = true := by decide
def e1196584717166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196584717166 : Closed e1196584717166 ∧ code e1196584717166 = 5594631228270 := by decide
theorem cert_e1196584717166 : check e1196584717166 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584717174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196584717174 : Closed e1196584717174 ∧ code e1196584717174 = 5594631228278 := by decide
theorem cert_e1196584717174 : check e1196584717174 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e1196584717230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196584717230 : Closed e1196584717230 ∧ code e1196584717230 = 5594631228334 := by decide
theorem cert_e1196584717230 : checkPay e1196584717230 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e1196584717242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196584717242 : Closed e1196584717242 ∧ code e1196584717242 = 5594631228346 := by decide
theorem cert_e1196584717242 : check e1196584717242 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584717270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196584717270 : Closed e1196584717270 ∧ code e1196584717270 = 5594631228374 := by decide
theorem cert_e1196584717270 : check e1196584717270 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584717274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196584717274 : Closed e1196584717274 ∧ code e1196584717274 = 5594631228378 := by decide
theorem cert_e1196584717274 : check e1196584717274 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1196584717550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196584717550 : Closed e1196584717550 ∧ code e1196584717550 = 5594631228654 := by decide
theorem cert_e1196584717550 : checkPay e1196584717550 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under],[.under,.under,.under,.right,.right,.right,.right]] = true := by decide
def e1196584717558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196584717558 : Closed e1196584717558 ∧ code e1196584717558 = 5594631228662 := by decide
theorem cert_e1196584717558 : checkPay e1196584717558 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right,.right,.left],[.under,.under,.right,.right],[.under,.under,.right,.right,.under,.right,.right]] = true := by decide
def e1196584717934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196584717934 : Closed e1196584717934 ∧ code e1196584717934 = 5594631229038 := by decide
theorem cert_e1196584717934 : checkPay e1196584717934 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [] = true := by decide
def e1196584717946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196584717946 : Closed e1196584717946 ∧ code e1196584717946 = 5594631229050 := by decide
theorem cert_e1196584717946 : check e1196584717946 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584718134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196584718134 : Closed e1196584718134 ∧ code e1196584718134 = 5594631229238 := by decide
theorem cert_e1196584718134 : check e1196584718134 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584718138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196584718138 : Closed e1196584718138 ∧ code e1196584718138 = 5594631229242 := by decide
theorem cert_e1196584718138 : check e1196584718138 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1196584723894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1196584723894 : Closed e1196584723894 ∧ code e1196584723894 = 5594631234998 := by decide
theorem cert_e1196584723894 : check e1196584723894 [[],[.left],[],[.under]] .three = true := by decide
def e1196584723926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1196584723926 : Closed e1196584723926 ∧ code e1196584723926 = 5594631235030 := by decide
theorem cert_e1196584723926 : check e1196584723926 [[],[.left],[],[.under]] .three = true := by decide
def e1196584723930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1196584723930 : Closed e1196584723930 ∧ code e1196584723930 = 5594631235034 := by decide
theorem cert_e1196584723930 : check e1196584723930 [[],[.left],[],[.under]] .three = true := by decide
def e1196584724086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1196584724086 : Closed e1196584724086 ∧ code e1196584724086 = 5594631235190 := by decide
theorem cert_e1196584724086 : check e1196584724086 [[],[.left],[],[.under]] .three = true := by decide
def e1196584724278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1196584724278 : Closed e1196584724278 ∧ code e1196584724278 = 5594631235382 := by decide
theorem cert_e1196584724278 : check e1196584724278 [[],[.left],[],[.under]] .three = true := by decide
def e1196584724282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1196584724282 : Closed e1196584724282 ∧ code e1196584724282 = 5594631235386 := by decide
theorem cert_e1196584724282 : check e1196584724282 [[],[.left],[],[.under]] .three = true := by decide
def e1196585061230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196585061230 : Closed e1196585061230 ∧ code e1196585061230 = 5594631572334 := by decide
theorem cert_e1196585061230 : check e1196585061230 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e1196585061238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196585061238 : Closed e1196585061238 ∧ code e1196585061238 = 5594631572342 := by decide
private def t_e1196585061238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1196585061238 : ¬ IsSelfInterpreter e1196585061238 :=
  wSource (t := t_e1196585061238) (replay_sound (ps := []) (t := e1196585061238) (by decide)) (by decide)
def e1196585061294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196585061294 : Closed e1196585061294 ∧ code e1196585061294 = 5594631572398 := by decide
theorem cert_e1196585061294 : check e1196585061294 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e1196585061306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196585061306 : Closed e1196585061306 ∧ code e1196585061306 = 5594631572410 := by decide
theorem cert_e1196585061306 : check e1196585061306 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e1196585061334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196585061334 : Closed e1196585061334 ∧ code e1196585061334 = 5594631572438 := by decide
private def t_e1196585061334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1196585061334 : ¬ IsSelfInterpreter e1196585061334 :=
  wSource (t := t_e1196585061334) (replay_sound (ps := []) (t := e1196585061334) (by decide)) (by decide)
def e1196585061338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196585061338 : Closed e1196585061338 ∧ code e1196585061338 = 5594631572442 := by decide
def e1196585061614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196585061614 : Closed e1196585061614 ∧ code e1196585061614 = 5594631572718 := by decide
theorem cert_e1196585061614 : check e1196585061614 [[],[.left],[],[],[.under],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1196585061622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196585061622 : Closed e1196585061622 ∧ code e1196585061622 = 5594631572726 := by decide
def e1196585061998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196585061998 : Closed e1196585061998 ∧ code e1196585061998 = 5594631573102 := by decide
def e1196585062010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196585062010 : Closed e1196585062010 ∧ code e1196585062010 = 5594631573114 := by decide
theorem cert_e1196585062010 : check e1196585062010 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e1196585062198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196585062198 : Closed e1196585062198 ∧ code e1196585062198 = 5594631573302 := by decide
theorem cert_e1196585062198 : check e1196585062198 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1196585062202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196585062202 : Closed e1196585062202 ∧ code e1196585062202 = 5594631573306 := by decide
def e1196685351646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e1196685351646 : Closed e1196685351646 ∧ code e1196685351646 = 5594731862750 := by decide
theorem cert_e1196685351646 : check e1196685351646 [[],[.left],[]] .three = true := by decide
def e1196685351670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e1196685351670 : Closed e1196685351670 ∧ code e1196685351670 = 5594731862774 := by decide
theorem cert_e1196685351670 : check e1196685351670 [[],[.left],[]] .three = true := by decide
def e1196685351774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e1196685351774 : Closed e1196685351774 ∧ code e1196685351774 = 5594731862878 := by decide
theorem cert_e1196685351774 : check e1196685351774 [[],[.left],[]] .three = true := by decide
def e1196685351790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e1196685351790 : Closed e1196685351790 ∧ code e1196685351790 = 5594731862894 := by decide
theorem cert_e1196685351790 : check e1196685351790 [[],[.left],[]] .smaller = true := by decide
def e1196685351798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e1196685351798 : Closed e1196685351798 ∧ code e1196685351798 = 5594731862902 := by decide
theorem cert_e1196685351798 : check e1196685351798 [[],[.left],[]] .smaller = true := by decide
def e1196685351802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1196685351802 : Closed e1196685351802 ∧ code e1196685351802 = 5594731862906 := by decide
theorem cert_e1196685351802 : check e1196685351802 [[],[.left],[]] .three = true := by decide
def e1196685351862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e1196685351862 : Closed e1196685351862 ∧ code e1196685351862 = 5594731862966 := by decide
theorem cert_e1196685351862 : check e1196685351862 [[],[.left],[]] .smaller = true := by decide
def e1196685351894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1196685351894 : Closed e1196685351894 ∧ code e1196685351894 = 5594731862998 := by decide
theorem cert_e1196685351894 : check e1196685351894 [[],[.left],[]] .three = true := by decide
def e1196685351898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1196685351898 : Closed e1196685351898 ∧ code e1196685351898 = 5594731863002 := by decide
theorem cert_e1196685351898 : check e1196685351898 [[],[.left],[]] .three = true := by decide
def e1196685352286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1196685352286 : Closed e1196685352286 ∧ code e1196685352286 = 5594731863390 := by decide
theorem cert_e1196685352286 : check e1196685352286 [[],[.left],[]] .three = true := by decide
def e1196685352302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1196685352302 : Closed e1196685352302 ∧ code e1196685352302 = 5594731863406 := by decide
theorem cert_e1196685352302 : check e1196685352302 [[],[.left],[]] .smaller = true := by decide
def e1196685352310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1196685352310 : Closed e1196685352310 ∧ code e1196685352310 = 5594731863414 := by decide
theorem cert_e1196685352310 : check e1196685352310 [[],[.left],[]] .smaller = true := by decide
def e1196685352314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1196685352314 : Closed e1196685352314 ∧ code e1196685352314 = 5594731863418 := by decide
theorem cert_e1196685352314 : check e1196685352314 [[],[.left],[]] .three = true := by decide
def e1196685352366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1196685352366 : Closed e1196685352366 ∧ code e1196685352366 = 5594731863470 := by decide
theorem cert_e1196685352366 : check e1196685352366 [[],[.left],[]] .smaller = true := by decide
def e1196685352378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1196685352378 : Closed e1196685352378 ∧ code e1196685352378 = 5594731863482 := by decide
theorem cert_e1196685352378 : check e1196685352378 [[],[.left],[]] .smaller = true := by decide
def e1196685352406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1196685352406 : Closed e1196685352406 ∧ code e1196685352406 = 5594731863510 := by decide
theorem cert_e1196685352406 : check e1196685352406 [[],[.left],[]] .smaller = true := by decide
def e1196685352410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1196685352410 : Closed e1196685352410 ∧ code e1196685352410 = 5594731863514 := by decide
theorem cert_e1196685352410 : check e1196685352410 [[],[.left],[]] .smaller = true := by decide
def e1196685352426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1196685352426 : Closed e1196685352426 ∧ code e1196685352426 = 5594731863530 := by decide
theorem cert_e1196685352426 : check e1196685352426 [[],[.left],[]] .three = true := by decide
def e1196685352630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1196685352630 : Closed e1196685352630 ∧ code e1196685352630 = 5594731863734 := by decide
theorem cert_e1196685352630 : check e1196685352630 [[],[.left],[]] .smaller = true := by decide
def e1196685352662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1196685352662 : Closed e1196685352662 ∧ code e1196685352662 = 5594731863766 := by decide
theorem cert_e1196685352662 : check e1196685352662 [[],[.left],[]] .smaller = true := by decide
def e1196685352666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1196685352666 : Closed e1196685352666 ∧ code e1196685352666 = 5594731863770 := by decide
theorem cert_e1196685352666 : check e1196685352666 [[],[.left],[]] .smaller = true := by decide
def e1196685352790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1196685352790 : Closed e1196685352790 ∧ code e1196685352790 = 5594731863894 := by decide
theorem cert_e1196685352790 : check e1196685352790 [[],[.left],[]] .three = true := by decide
def e1196685352794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1196685352794 : Closed e1196685352794 ∧ code e1196685352794 = 5594731863898 := by decide
theorem cert_e1196685352794 : check e1196685352794 [[],[.left],[]] .three = true := by decide
def e1196685352810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1196685352810 : Closed e1196685352810 ∧ code e1196685352810 = 5594731863914 := by decide
theorem cert_e1196685352810 : check e1196685352810 [[],[.left],[]] .three = true := by decide
def e1196685354718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1196685354718 : Closed e1196685354718 ∧ code e1196685354718 = 5594731865822 := by decide
theorem cert_e1196685354718 : check e1196685354718 [[],[.left],[]] .three = true := by decide
def e1196685354742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1196685354742 : Closed e1196685354742 ∧ code e1196685354742 = 5594731865846 := by decide
theorem cert_e1196685354742 : check e1196685354742 [[],[.left],[]] .three = true := by decide
def e1196685354846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1196685354846 : Closed e1196685354846 ∧ code e1196685354846 = 5594731865950 := by decide
theorem cert_e1196685354846 : check e1196685354846 [[],[.left],[]] .three = true := by decide
def e1196685354862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e1196685354862 : Closed e1196685354862 ∧ code e1196685354862 = 5594731865966 := by decide
theorem cert_e1196685354862 : check e1196685354862 [[],[.left],[]] .smaller = true := by decide
def e1196685354870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e1196685354870 : Closed e1196685354870 ∧ code e1196685354870 = 5594731865974 := by decide
theorem cert_e1196685354870 : check e1196685354870 [[],[.left],[]] .smaller = true := by decide
def e1196685354874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1196685354874 : Closed e1196685354874 ∧ code e1196685354874 = 5594731865978 := by decide
theorem cert_e1196685354874 : check e1196685354874 [[],[.left],[]] .three = true := by decide
def e1196685354934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e1196685354934 : Closed e1196685354934 ∧ code e1196685354934 = 5594731866038 := by decide
theorem cert_e1196685354934 : check e1196685354934 [[],[.left],[]] .smaller = true := by decide
def e1196685354966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1196685354966 : Closed e1196685354966 ∧ code e1196685354966 = 5594731866070 := by decide
theorem cert_e1196685354966 : check e1196685354966 [[],[.left],[]] .three = true := by decide
def e1196685354970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1196685354970 : Closed e1196685354970 ∧ code e1196685354970 = 5594731866074 := by decide
theorem cert_e1196685354970 : check e1196685354970 [[],[.left],[]] .three = true := by decide
def e1196685355486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1196685355486 : Closed e1196685355486 ∧ code e1196685355486 = 5594731866590 := by decide
theorem cert_e1196685355486 : check e1196685355486 [[],[.left],[]] .three = true := by decide
def e1196685355510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1196685355510 : Closed e1196685355510 ∧ code e1196685355510 = 5594731866614 := by decide
theorem cert_e1196685355510 : check e1196685355510 [[],[.left],[]] .three = true := by decide
def e1196685356254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1196685356254 : Closed e1196685356254 ∧ code e1196685356254 = 5594731867358 := by decide
theorem cert_e1196685356254 : check e1196685356254 [[],[.left],[]] .three = true := by decide
def e1196685356270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1196685356270 : Closed e1196685356270 ∧ code e1196685356270 = 5594731867374 := by decide
theorem cert_e1196685356270 : check e1196685356270 [[],[.left],[]] .smaller = true := by decide
def e1196685356278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1196685356278 : Closed e1196685356278 ∧ code e1196685356278 = 5594731867382 := by decide
theorem cert_e1196685356278 : check e1196685356278 [[],[.left],[]] .smaller = true := by decide
def e1196685356282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1196685356282 : Closed e1196685356282 ∧ code e1196685356282 = 5594731867386 := by decide
theorem cert_e1196685356282 : check e1196685356282 [[],[.left],[]] .three = true := by decide
def e1196685356662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1196685356662 : Closed e1196685356662 ∧ code e1196685356662 = 5594731867766 := by decide
theorem cert_e1196685356662 : check e1196685356662 [[],[.left],[]] .smaller = true := by decide
def e1196685356854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1196685356854 : Closed e1196685356854 ∧ code e1196685356854 = 5594731867958 := by decide
theorem cert_e1196685356854 : check e1196685356854 [[],[.left],[]] .three = true := by decide
def e1196685356858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1196685356858 : Closed e1196685356858 ∧ code e1196685356858 = 5594731867962 := by decide
theorem cert_e1196685356858 : check e1196685356858 [[],[.left],[]] .three = true := by decide
end Blc.Floor42
