import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e378393448246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e378393448246 : Closed e378393448246 ∧ code e378393448246 = 4776439959350 := by decide
theorem cert_e378393448246 : check e378393448246 [] .sourceHead = true := by decide
def e378393448250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e378393448250 : Closed e378393448250 ∧ code e378393448250 = 4776439959354 := by decide
theorem cert_e378393448250 : check e378393448250 [] .sourceHead = true := by decide
def e378393454006 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e378393454006 : Closed e378393454006 ∧ code e378393454006 = 4776439965110 := by decide
theorem cert_e378393454006 : check e378393454006 [] .sourceHead = true := by decide
def e378393454038 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e378393454038 : Closed e378393454038 ∧ code e378393454038 = 4776439965142 := by decide
theorem cert_e378393454038 : check e378393454038 [] .sourceHead = true := by decide
def e378393454042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e378393454042 : Closed e378393454042 ∧ code e378393454042 = 4776439965146 := by decide
theorem cert_e378393454042 : check e378393454042 [] .sourceHead = true := by decide
def e378393454198 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e378393454198 : Closed e378393454198 ∧ code e378393454198 = 4776439965302 := by decide
theorem cert_e378393454198 : check e378393454198 [] .sourceHead = true := by decide
def e378393454390 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e378393454390 : Closed e378393454390 ∧ code e378393454390 = 4776439965494 := by decide
theorem cert_e378393454390 : check e378393454390 [] .sourceHead = true := by decide
def e378393454394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e378393454394 : Closed e378393454394 ∧ code e378393454394 = 4776439965498 := by decide
theorem cert_e378393454394 : check e378393454394 [] .sourceHead = true := by decide
def e378393791342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e378393791342 : Closed e378393791342 ∧ code e378393791342 = 4776440302446 := by decide
theorem cert_e378393791342 : check e378393791342 [] .sourceHead = true := by decide
def e378393791350 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e378393791350 : Closed e378393791350 ∧ code e378393791350 = 4776440302454 := by decide
theorem cert_e378393791350 : check e378393791350 [] .sourceHead = true := by decide
def e378393791406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e378393791406 : Closed e378393791406 ∧ code e378393791406 = 4776440302510 := by decide
theorem cert_e378393791406 : check e378393791406 [] .sourceHead = true := by decide
def e378393791418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e378393791418 : Closed e378393791418 ∧ code e378393791418 = 4776440302522 := by decide
theorem cert_e378393791418 : check e378393791418 [] .sourceHead = true := by decide
def e378393791446 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e378393791446 : Closed e378393791446 ∧ code e378393791446 = 4776440302550 := by decide
theorem cert_e378393791446 : check e378393791446 [] .sourceHead = true := by decide
def e378393791450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e378393791450 : Closed e378393791450 ∧ code e378393791450 = 4776440302554 := by decide
theorem cert_e378393791450 : check e378393791450 [] .sourceHead = true := by decide
def e378393791726 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e378393791726 : Closed e378393791726 ∧ code e378393791726 = 4776440302830 := by decide
theorem cert_e378393791726 : check e378393791726 [] .sourceHead = true := by decide
def e378393791734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e378393791734 : Closed e378393791734 ∧ code e378393791734 = 4776440302838 := by decide
theorem cert_e378393791734 : check e378393791734 [] .sourceHead = true := by decide
def e378393792110 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e378393792110 : Closed e378393792110 ∧ code e378393792110 = 4776440303214 := by decide
theorem cert_e378393792110 : check e378393792110 [] .sourceHead = true := by decide
def e378393792122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e378393792122 : Closed e378393792122 ∧ code e378393792122 = 4776440303226 := by decide
theorem cert_e378393792122 : check e378393792122 [] .sourceHead = true := by decide
def e378393792310 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e378393792310 : Closed e378393792310 ∧ code e378393792310 = 4776440303414 := by decide
theorem cert_e378393792310 : check e378393792310 [] .sourceHead = true := by decide
def e378393792314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e378393792314 : Closed e378393792314 ∧ code e378393792314 = 4776440303418 := by decide
theorem cert_e378393792314 : check e378393792314 [] .sourceHead = true := by decide
def e378429880346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378429880346 : Closed e378429880346 ∧ code e378429880346 = 4776476391450 := by decide
theorem cert_e378429880346 : check e378429880346 [] .sourceHead = true := by decide
def e378429888538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378429888538 : Closed e378429888538 ∧ code e378429888538 = 4776476399642 := by decide
theorem cert_e378429888538 : check e378429888538 [] .sourceHead = true := by decide
def e378429945882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378429945882 : Closed e378429945882 ∧ code e378429945882 = 4776476456986 := by decide
theorem cert_e378429945882 : check e378429945882 [] .sourceHead = true := by decide
def e378429958170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378429958170 : Closed e378429958170 ∧ code e378429958170 = 4776476469274 := by decide
theorem cert_e378429958170 : check e378429958170 [] .sourceHead = true := by decide
def e378429986842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378429986842 : Closed e378429986842 ∧ code e378429986842 = 4776476497946 := by decide
theorem cert_e378429986842 : check e378429986842 [] .sourceHead = true := by decide
def e378429990938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378429990938 : Closed e378429990938 ∧ code e378429990938 = 4776476502042 := by decide
theorem cert_e378429990938 : check e378429990938 [] .sourceHead = true := by decide
def e378430273562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378430273562 : Closed e378430273562 ∧ code e378430273562 = 4776476784666 := by decide
theorem cert_e378430273562 : check e378430273562 [] .sourceHead = true := by decide
def e378430281754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378430281754 : Closed e378430281754 ∧ code e378430281754 = 4776476792858 := by decide
theorem cert_e378430281754 : check e378430281754 [] .sourceHead = true := by decide
def e378430666778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378430666778 : Closed e378430666778 ∧ code e378430666778 = 4776477177882 := by decide
theorem cert_e378430666778 : check e378430666778 [] .sourceHead = true := by decide
def e378430679066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378430679066 : Closed e378430679066 ∧ code e378430679066 = 4776477190170 := by decide
theorem cert_e378430679066 : check e378430679066 [] .sourceHead = true := by decide
def e378430871578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378430871578 : Closed e378430871578 ∧ code e378430871578 = 4776477382682 := by decide
theorem cert_e378430871578 : check e378430871578 [] .sourceHead = true := by decide
def e378430875674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378430875674 : Closed e378430875674 ∧ code e378430875674 = 4776477386778 := by decide
theorem cert_e378430875674 : check e378430875674 [] .sourceHead = true := by decide
def e379569233434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569233434 : Closed e379569233434 ∧ code e379569233434 = 4777615744538 := by decide
theorem cert_e379569233434 : check e379569233434 [] .sourceHead = true := by decide
def e379569239578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569239578 : Closed e379569239578 ∧ code e379569239578 = 4777615750682 := by decide
theorem cert_e379569239578 : check e379569239578 [] .sourceHead = true := by decide
def e379569266202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569266202 : Closed e379569266202 ∧ code e379569266202 = 4777615777306 := by decide
theorem cert_e379569266202 : check e379569266202 [] .sourceHead = true := by decide
def e379569273370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569273370 : Closed e379569273370 ∧ code e379569273370 = 4777615784474 := by decide
theorem cert_e379569273370 : check e379569273370 [] .sourceHead = true := by decide
def e379569296922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569296922 : Closed e379569296922 ∧ code e379569296922 = 4777615808026 := by decide
theorem cert_e379569296922 : check e379569296922 [] .sourceHead = true := by decide
def e379569297946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569297946 : Closed e379569297946 ∧ code e379569297946 = 4777615809050 := by decide
theorem cert_e379569297946 : check e379569297946 [] .sourceHead = true := by decide
def e379569430042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569430042 : Closed e379569430042 ∧ code e379569430042 = 4777615941146 := by decide
theorem cert_e379569430042 : check e379569430042 [] .sourceHead = true := by decide
def e379569436186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569436186 : Closed e379569436186 ∧ code e379569436186 = 4777615947290 := by decide
theorem cert_e379569436186 : check e379569436186 [] .sourceHead = true := by decide
def e379569626650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569626650 : Closed e379569626650 ∧ code e379569626650 = 4777616137754 := by decide
theorem cert_e379569626650 : check e379569626650 [] .sourceHead = true := by decide
def e379569633818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569633818 : Closed e379569633818 ∧ code e379569633818 = 4777616144922 := by decide
theorem cert_e379569633818 : check e379569633818 [] .sourceHead = true := by decide
def e379569780250 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569780250 : Closed e379569780250 ∧ code e379569780250 = 4777616291354 := by decide
theorem cert_e379569780250 : check e379569780250 [] .sourceHead = true := by decide
def e379569781274 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379569781274 : Closed e379569781274 ∧ code e379569781274 = 4777616292378 := by decide
theorem cert_e379569781274 : check e379569781274 [] .sourceHead = true := by decide
def e379573562906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573562906 : Closed e379573562906 ∧ code e379573562906 = 4777620074010 := by decide
theorem cert_e379573562906 : check e379573562906 [] .sourceHead = true := by decide
def e379573564954 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573564954 : Closed e379573564954 ∧ code e379573564954 = 4777620076058 := by decide
theorem cert_e379573564954 : check e379573564954 [] .sourceHead = true := by decide
def e379573706266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573706266 : Closed e379573706266 ∧ code e379573706266 = 4777620217370 := by decide
theorem cert_e379573706266 : check e379573706266 [] .sourceHead = true := by decide
def e379573727430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379573727430 : Closed e379573727430 ∧ code e379573727430 = 4777620238534 := by decide
theorem cert_e379573727430 : check e379573727430 [] .sourceHead = true := by decide
def e379573734938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573734938 : Closed e379573734938 ∧ code e379573734938 = 4777620246042 := by decide
theorem cert_e379573734938 : check e379573734938 [] .sourceHead = true := by decide
def e379573743814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379573743814 : Closed e379573743814 ∧ code e379573743814 = 4777620254918 := by decide
theorem cert_e379573743814 : check e379573743814 [] .sourceHead = true := by decide
def e379573792282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573792282 : Closed e379573792282 ∧ code e379573792282 = 4777620303386 := by decide
theorem cert_e379573792282 : check e379573792282 [] .sourceHead = true := by decide
def e379573795354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573795354 : Closed e379573795354 ∧ code e379573795354 = 4777620306458 := by decide
theorem cert_e379573795354 : check e379573795354 [] .sourceHead = true := by decide
def e379573837338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573837338 : Closed e379573837338 ∧ code e379573837338 = 4777620348442 := by decide
theorem cert_e379573837338 : check e379573837338 [] .sourceHead = true := by decide
def e379573858502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379573858502 : Closed e379573858502 ∧ code e379573858502 = 4777620369606 := by decide
theorem cert_e379573858502 : check e379573858502 [] .sourceHead = true := by decide
def e379573880346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573880346 : Closed e379573880346 ∧ code e379573880346 = 4777620391450 := by decide
theorem cert_e379573880346 : check e379573880346 [] .sourceHead = true := by decide
def e379573883078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379573883078 : Closed e379573883078 ∧ code e379573883078 = 4777620394182 := by decide
theorem cert_e379573883078 : check e379573883078 [] .sourceHead = true := by decide
def e379573909018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573909018 : Closed e379573909018 ∧ code e379573909018 = 4777620420122 := by decide
theorem cert_e379573909018 : check e379573909018 [] .sourceHead = true := by decide
def e379573910042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573910042 : Closed e379573910042 ∧ code e379573910042 = 4777620421146 := by decide
theorem cert_e379573910042 : check e379573910042 [] .sourceHead = true := by decide
def e379573931546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573931546 : Closed e379573931546 ∧ code e379573931546 = 4777620442650 := by decide
theorem cert_e379573931546 : check e379573931546 [] .sourceHead = true := by decide
def e379573940422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379573940422 : Closed e379573940422 ∧ code e379573940422 = 4777620451526 := by decide
theorem cert_e379573940422 : check e379573940422 [] .sourceHead = true := by decide
def e379573945882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379573945882 : Closed e379573945882 ∧ code e379573945882 = 4777620456986 := by decide
theorem cert_e379573945882 : check e379573945882 [] .sourceHead = true := by decide
def e379573948614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379573948614 : Closed e379573948614 ∧ code e379573948614 = 4777620459718 := by decide
theorem cert_e379573948614 : check e379573948614 [] .sourceHead = true := by decide
def e379574492698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379574492698 : Closed e379574492698 ∧ code e379574492698 = 4777621003802 := by decide
theorem cert_e379574492698 : check e379574492698 [] .sourceHead = true := by decide
def e379574513862 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379574513862 : Closed e379574513862 ∧ code e379574513862 = 4777621024966 := by decide
theorem cert_e379574513862 : check e379574513862 [] .sourceHead = true := by decide
def e379574521370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379574521370 : Closed e379574521370 ∧ code e379574521370 = 4777621032474 := by decide
theorem cert_e379574521370 : check e379574521370 [] .sourceHead = true := by decide
def e379574530246 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379574530246 : Closed e379574530246 ∧ code e379574530246 = 4777621041350 := by decide
theorem cert_e379574530246 : check e379574530246 [] .sourceHead = true := by decide
def e379575279130 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379575279130 : Closed e379575279130 ∧ code e379575279130 = 4777621790234 := by decide
theorem cert_e379575279130 : check e379575279130 [] .sourceHead = true := by decide
def e379575300294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379575300294 : Closed e379575300294 ∧ code e379575300294 = 4777621811398 := by decide
theorem cert_e379575300294 : check e379575300294 [] .sourceHead = true := by decide
def e379575322138 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379575322138 : Closed e379575322138 ∧ code e379575322138 = 4777621833242 := by decide
theorem cert_e379575322138 : check e379575322138 [] .sourceHead = true := by decide
def e379575324870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379575324870 : Closed e379575324870 ∧ code e379575324870 = 4777621835974 := by decide
theorem cert_e379575324870 : check e379575324870 [] .sourceHead = true := by decide
def e379575701018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379575701018 : Closed e379575701018 ∧ code e379575701018 = 4777622212122 := by decide
theorem cert_e379575701018 : check e379575701018 [] .sourceHead = true := by decide
def e379575709894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379575709894 : Closed e379575709894 ∧ code e379575709894 = 4777622220998 := by decide
theorem cert_e379575709894 : check e379575709894 [] .sourceHead = true := by decide
def e379575715354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e379575715354 : Closed e379575715354 ∧ code e379575715354 = 4777622226458 := by decide
theorem cert_e379575715354 : check e379575715354 [] .sourceHead = true := by decide
def e379575718086 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e379575718086 : Closed e379575718086 ∧ code e379575718086 = 4777622229190 := by decide
theorem cert_e379575718086 : check e379575718086 [] .sourceHead = true := by decide
def e379618110830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e379618110830 : Closed e379618110830 ∧ code e379618110830 = 4777664621934 := by decide
theorem cert_e379618110830 : check e379618110830 [] .sourceHead = true := by decide
def e379618110838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e379618110838 : Closed e379618110838 ∧ code e379618110838 = 4777664621942 := by decide
theorem cert_e379618110838 : check e379618110838 [] .sourceHead = true := by decide
def e379618110894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e379618110894 : Closed e379618110894 ∧ code e379618110894 = 4777664621998 := by decide
theorem cert_e379618110894 : check e379618110894 [] .sourceHead = true := by decide
def e379618110906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e379618110906 : Closed e379618110906 ∧ code e379618110906 = 4777664622010 := by decide
theorem cert_e379618110906 : check e379618110906 [] .sourceHead = true := by decide
def e379618110934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e379618110934 : Closed e379618110934 ∧ code e379618110934 = 4777664622038 := by decide
theorem cert_e379618110934 : check e379618110934 [] .sourceHead = true := by decide
def e379618110938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e379618110938 : Closed e379618110938 ∧ code e379618110938 = 4777664622042 := by decide
theorem cert_e379618110938 : check e379618110938 [] .sourceHead = true := by decide
def e379618111150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e379618111150 : Closed e379618111150 ∧ code e379618111150 = 4777664622254 := by decide
theorem cert_e379618111150 : check e379618111150 [] .sourceHead = true := by decide
def e379618111162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e379618111162 : Closed e379618111162 ∧ code e379618111162 = 4777664622266 := by decide
theorem cert_e379618111162 : check e379618111162 [] .sourceHead = true := by decide
def e379618111210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e379618111210 : Closed e379618111210 ∧ code e379618111210 = 4777664622314 := by decide
theorem cert_e379618111210 : check e379618111210 [] .sourceHead = true := by decide
def e379618111318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e379618111318 : Closed e379618111318 ∧ code e379618111318 = 4777664622422 := by decide
theorem cert_e379618111318 : check e379618111318 [] .sourceHead = true := by decide
def e379618111322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e379618111322 : Closed e379618111322 ∧ code e379618111322 = 4777664622426 := by decide
theorem cert_e379618111322 : check e379618111322 [] .sourceHead = true := by decide
def e379618111338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e379618111338 : Closed e379618111338 ∧ code e379618111338 = 4777664622442 := by decide
theorem cert_e379618111338 : check e379618111338 [] .sourceHead = true := by decide
def e379618112366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e379618112366 : Closed e379618112366 ∧ code e379618112366 = 4777664623470 := by decide
theorem cert_e379618112366 : check e379618112366 [] .sourceHead = true := by decide
def e379618112374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e379618112374 : Closed e379618112374 ∧ code e379618112374 = 4777664623478 := by decide
theorem cert_e379618112374 : check e379618112374 [] .sourceHead = true := by decide
def e379618112430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e379618112430 : Closed e379618112430 ∧ code e379618112430 = 4777664623534 := by decide
theorem cert_e379618112430 : check e379618112430 [] .sourceHead = true := by decide
def e379618112442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e379618112442 : Closed e379618112442 ∧ code e379618112442 = 4777664623546 := by decide
theorem cert_e379618112442 : check e379618112442 [] .sourceHead = true := by decide
def e379618112470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e379618112470 : Closed e379618112470 ∧ code e379618112470 = 4777664623574 := by decide
theorem cert_e379618112470 : check e379618112470 [] .sourceHead = true := by decide
def e379618112474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e379618112474 : Closed e379618112474 ∧ code e379618112474 = 4777664623578 := by decide
theorem cert_e379618112474 : check e379618112474 [] .sourceHead = true := by decide
def e379618112750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e379618112750 : Closed e379618112750 ∧ code e379618112750 = 4777664623854 := by decide
theorem cert_e379618112750 : check e379618112750 [] .sourceHead = true := by decide
def e379618112758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e379618112758 : Closed e379618112758 ∧ code e379618112758 = 4777664623862 := by decide
theorem cert_e379618112758 : check e379618112758 [] .sourceHead = true := by decide
def e379618113134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e379618113134 : Closed e379618113134 ∧ code e379618113134 = 4777664624238 := by decide
theorem cert_e379618113134 : check e379618113134 [] .sourceHead = true := by decide
def e379618113146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e379618113146 : Closed e379618113146 ∧ code e379618113146 = 4777664624250 := by decide
theorem cert_e379618113146 : check e379618113146 [] .sourceHead = true := by decide
def e379618113334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e379618113334 : Closed e379618113334 ∧ code e379618113334 = 4777664624438 := by decide
theorem cert_e379618113334 : check e379618113334 [] .sourceHead = true := by decide
def e379618113338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e379618113338 : Closed e379618113338 ∧ code e379618113338 = 4777664624442 := by decide
theorem cert_e379618113338 : check e379618113338 [] .sourceHead = true := by decide
def e379618113966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e379618113966 : Closed e379618113966 ∧ code e379618113966 = 4777664625070 := by decide
theorem cert_e379618113966 : check e379618113966 [] .sourceHead = true := by decide
def e379618113978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e379618113978 : Closed e379618113978 ∧ code e379618113978 = 4777664625082 := by decide
theorem cert_e379618113978 : check e379618113978 [] .sourceHead = true := by decide
def e379618114026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e379618114026 : Closed e379618114026 ∧ code e379618114026 = 4777664625130 := by decide
theorem cert_e379618114026 : check e379618114026 [] .sourceHead = true := by decide
def e379618114158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e379618114158 : Closed e379618114158 ∧ code e379618114158 = 4777664625262 := by decide
theorem cert_e379618114158 : check e379618114158 [] .sourceHead = true := by decide
def e379618114170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e379618114170 : Closed e379618114170 ∧ code e379618114170 = 4777664625274 := by decide
theorem cert_e379618114170 : check e379618114170 [] .sourceHead = true := by decide
def e379618114458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e379618114458 : Closed e379618114458 ∧ code e379618114458 = 4777664625562 := by decide
theorem cert_e379618114458 : check e379618114458 [] .sourceHead = true := by decide
def e379618114774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e379618114774 : Closed e379618114774 ∧ code e379618114774 = 4777664625878 := by decide
theorem cert_e379618114774 : check e379618114774 [] .sourceHead = true := by decide
def e379618114778 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e379618114778 : Closed e379618114778 ∧ code e379618114778 = 4777664625882 := by decide
theorem cert_e379618114778 : check e379618114778 [] .sourceHead = true := by decide
def e379618114794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e379618114794 : Closed e379618114794 ∧ code e379618114794 = 4777664625898 := by decide
theorem cert_e379618114794 : check e379618114794 [] .sourceHead = true := by decide
def e379618114870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e379618114870 : Closed e379618114870 ∧ code e379618114870 = 4777664625974 := by decide
theorem cert_e379618114870 : check e379618114870 [] .sourceHead = true := by decide
def e379618114874 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e379618114874 : Closed e379618114874 ∧ code e379618114874 = 4777664625978 := by decide
theorem cert_e379618114874 : check e379618114874 [] .sourceHead = true := by decide
def e379618114970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e379618114970 : Closed e379618114970 ∧ code e379618114970 = 4777664626074 := by decide
theorem cert_e379618114970 : check e379618114970 [] .sourceHead = true := by decide
def e379618118510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e379618118510 : Closed e379618118510 ∧ code e379618118510 = 4777664629614 := by decide
theorem cert_e379618118510 : check e379618118510 [] .sourceHead = true := by decide
def e379618118518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e379618118518 : Closed e379618118518 ∧ code e379618118518 = 4777664629622 := by decide
theorem cert_e379618118518 : check e379618118518 [] .sourceHead = true := by decide
def e379618118574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e379618118574 : Closed e379618118574 ∧ code e379618118574 = 4777664629678 := by decide
theorem cert_e379618118574 : check e379618118574 [] .sourceHead = true := by decide
def e379618118586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e379618118586 : Closed e379618118586 ∧ code e379618118586 = 4777664629690 := by decide
theorem cert_e379618118586 : check e379618118586 [] .sourceHead = true := by decide
def e379618118614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e379618118614 : Closed e379618118614 ∧ code e379618118614 = 4777664629718 := by decide
theorem cert_e379618118614 : check e379618118614 [] .sourceHead = true := by decide
def e379618118618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e379618118618 : Closed e379618118618 ∧ code e379618118618 = 4777664629722 := by decide
theorem cert_e379618118618 : check e379618118618 [] .sourceHead = true := by decide
def e379618118894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e379618118894 : Closed e379618118894 ∧ code e379618118894 = 4777664629998 := by decide
theorem cert_e379618118894 : check e379618118894 [] .sourceHead = true := by decide
def e379618118902 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e379618118902 : Closed e379618118902 ∧ code e379618118902 = 4777664630006 := by decide
theorem cert_e379618118902 : check e379618118902 [] .sourceHead = true := by decide
def e379618119278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e379618119278 : Closed e379618119278 ∧ code e379618119278 = 4777664630382 := by decide
theorem cert_e379618119278 : check e379618119278 [] .sourceHead = true := by decide
def e379618119290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e379618119290 : Closed e379618119290 ∧ code e379618119290 = 4777664630394 := by decide
theorem cert_e379618119290 : check e379618119290 [] .sourceHead = true := by decide
def e379618119478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e379618119478 : Closed e379618119478 ∧ code e379618119478 = 4777664630582 := by decide
theorem cert_e379618119478 : check e379618119478 [] .sourceHead = true := by decide
def e379618119482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e379618119482 : Closed e379618119482 ∧ code e379618119482 = 4777664630586 := by decide
theorem cert_e379618119482 : check e379618119482 [] .sourceHead = true := by decide
def e379618125230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e379618125230 : Closed e379618125230 ∧ code e379618125230 = 4777664636334 := by decide
theorem cert_e379618125230 : check e379618125230 [] .sourceHead = true := by decide
def e379618125242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e379618125242 : Closed e379618125242 ∧ code e379618125242 = 4777664636346 := by decide
theorem cert_e379618125242 : check e379618125242 [] .sourceHead = true := by decide
def e379618125290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e379618125290 : Closed e379618125290 ∧ code e379618125290 = 4777664636394 := by decide
theorem cert_e379618125290 : check e379618125290 [] .sourceHead = true := by decide
def e379618125422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e379618125422 : Closed e379618125422 ∧ code e379618125422 = 4777664636526 := by decide
theorem cert_e379618125422 : check e379618125422 [] .sourceHead = true := by decide
def e379618125434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e379618125434 : Closed e379618125434 ∧ code e379618125434 = 4777664636538 := by decide
theorem cert_e379618125434 : check e379618125434 [] .sourceHead = true := by decide
def e379618125722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e379618125722 : Closed e379618125722 ∧ code e379618125722 = 4777664636826 := by decide
theorem cert_e379618125722 : check e379618125722 [] .sourceHead = true := by decide
def e379618128598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e379618128598 : Closed e379618128598 ∧ code e379618128598 = 4777664639702 := by decide
theorem cert_e379618128598 : check e379618128598 [] .sourceHead = true := by decide
def e379618128602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e379618128602 : Closed e379618128602 ∧ code e379618128602 = 4777664639706 := by decide
theorem cert_e379618128602 : check e379618128602 [] .sourceHead = true := by decide
def e379618128618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e379618128618 : Closed e379618128618 ∧ code e379618128618 = 4777664639722 := by decide
theorem cert_e379618128618 : check e379618128618 [] .sourceHead = true := by decide
def e379618128694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e379618128694 : Closed e379618128694 ∧ code e379618128694 = 4777664639798 := by decide
theorem cert_e379618128694 : check e379618128694 [] .sourceHead = true := by decide
def e379618128698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e379618128698 : Closed e379618128698 ∧ code e379618128698 = 4777664639802 := by decide
theorem cert_e379618128698 : check e379618128698 [] .sourceHead = true := by decide
def e379618128794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e379618128794 : Closed e379618128794 ∧ code e379618128794 = 4777664639898 := by decide
theorem cert_e379618128794 : check e379618128794 [] .sourceHead = true := by decide
def e379618265966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e379618265966 : Closed e379618265966 ∧ code e379618265966 = 4777664777070 := by decide
theorem cert_e379618265966 : check e379618265966 [] .sourceHead = true := by decide
def e379618265974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e379618265974 : Closed e379618265974 ∧ code e379618265974 = 4777664777078 := by decide
theorem cert_e379618265974 : check e379618265974 [] .sourceHead = true := by decide
def e379618266030 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e379618266030 : Closed e379618266030 ∧ code e379618266030 = 4777664777134 := by decide
theorem cert_e379618266030 : check e379618266030 [] .sourceHead = true := by decide
def e379618266042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e379618266042 : Closed e379618266042 ∧ code e379618266042 = 4777664777146 := by decide
theorem cert_e379618266042 : check e379618266042 [] .sourceHead = true := by decide
def e379618266070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e379618266070 : Closed e379618266070 ∧ code e379618266070 = 4777664777174 := by decide
theorem cert_e379618266070 : check e379618266070 [] .sourceHead = true := by decide
def e379618266074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e379618266074 : Closed e379618266074 ∧ code e379618266074 = 4777664777178 := by decide
theorem cert_e379618266074 : check e379618266074 [] .sourceHead = true := by decide
def e379618266350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e379618266350 : Closed e379618266350 ∧ code e379618266350 = 4777664777454 := by decide
theorem cert_e379618266350 : check e379618266350 [] .sourceHead = true := by decide
def e379618266358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e379618266358 : Closed e379618266358 ∧ code e379618266358 = 4777664777462 := by decide
theorem cert_e379618266358 : check e379618266358 [] .sourceHead = true := by decide
def e379618266734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e379618266734 : Closed e379618266734 ∧ code e379618266734 = 4777664777838 := by decide
theorem cert_e379618266734 : check e379618266734 [] .sourceHead = true := by decide
def e379618266746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e379618266746 : Closed e379618266746 ∧ code e379618266746 = 4777664777850 := by decide
theorem cert_e379618266746 : check e379618266746 [] .sourceHead = true := by decide
def e379618266934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e379618266934 : Closed e379618266934 ∧ code e379618266934 = 4777664778038 := by decide
theorem cert_e379618266934 : check e379618266934 [] .sourceHead = true := by decide
def e379618266938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e379618266938 : Closed e379618266938 ∧ code e379618266938 = 4777664778042 := by decide
theorem cert_e379618266938 : check e379618266938 [] .sourceHead = true := by decide
def e379618855790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e379618855790 : Closed e379618855790 ∧ code e379618855790 = 4777665366894 := by decide
theorem cert_e379618855790 : check e379618855790 [] .sourceHead = true := by decide
def e379618855798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e379618855798 : Closed e379618855798 ∧ code e379618855798 = 4777665366902 := by decide
theorem cert_e379618855798 : check e379618855798 [] .sourceHead = true := by decide
def e379618855854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e379618855854 : Closed e379618855854 ∧ code e379618855854 = 4777665366958 := by decide
theorem cert_e379618855854 : check e379618855854 [] .sourceHead = true := by decide
def e379618855866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e379618855866 : Closed e379618855866 ∧ code e379618855866 = 4777665366970 := by decide
theorem cert_e379618855866 : check e379618855866 [] .sourceHead = true := by decide
def e379618855894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e379618855894 : Closed e379618855894 ∧ code e379618855894 = 4777665366998 := by decide
theorem cert_e379618855894 : check e379618855894 [] .sourceHead = true := by decide
def e379618855898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e379618855898 : Closed e379618855898 ∧ code e379618855898 = 4777665367002 := by decide
theorem cert_e379618855898 : check e379618855898 [] .sourceHead = true := by decide
def e379618856174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e379618856174 : Closed e379618856174 ∧ code e379618856174 = 4777665367278 := by decide
theorem cert_e379618856174 : check e379618856174 [] .sourceHead = true := by decide
def e379618856182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e379618856182 : Closed e379618856182 ∧ code e379618856182 = 4777665367286 := by decide
theorem cert_e379618856182 : check e379618856182 [] .sourceHead = true := by decide
def e379618856558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e379618856558 : Closed e379618856558 ∧ code e379618856558 = 4777665367662 := by decide
theorem cert_e379618856558 : check e379618856558 [] .sourceHead = true := by decide
def e379618856570 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e379618856570 : Closed e379618856570 ∧ code e379618856570 = 4777665367674 := by decide
theorem cert_e379618856570 : check e379618856570 [] .sourceHead = true := by decide
def e379618856758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e379618856758 : Closed e379618856758 ∧ code e379618856758 = 4777665367862 := by decide
theorem cert_e379618856758 : check e379618856758 [] .sourceHead = true := by decide
def e379618856762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e379618856762 : Closed e379618856762 ∧ code e379618856762 = 4777665367866 := by decide
theorem cert_e379618856762 : check e379618856762 [] .sourceHead = true := by decide
def e379702041310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e379702041310 : Closed e379702041310 ∧ code e379702041310 = 4777748552414 := by decide
theorem cert_e379702041310 : check e379702041310 [] .sourceHead = true := by decide
def e379702041334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e379702041334 : Closed e379702041334 ∧ code e379702041334 = 4777748552438 := by decide
theorem cert_e379702041334 : check e379702041334 [] .sourceHead = true := by decide
end Blc.Floor42
