import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211186486394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186486394 : Closed e1211186486394 ∧ code e1211186486394 = 5609232997498 := by decide
theorem cert_e1211186486394 : check e1211186486394 [[],[]] .smaller = true := by decide
def e1211186486558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186486558 : Closed e1211186486558 ∧ code e1211186486558 = 5609232997662 := by decide
theorem cert_e1211186486558 : check e1211186486558 [[],[]] .smaller = true := by decide
def e1211186486726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186486726 : Closed e1211186486726 ∧ code e1211186486726 = 5609232997830 := by decide
theorem cert_e1211186486726 : check e1211186486726 [[],[]] .smaller = true := by decide
def e1211186486750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 3)))))))
theorem wire_e1211186486750 : Closed e1211186486750 ∧ code e1211186486750 = 5609232997854 := by decide
theorem cert_e1211186486750 : check e1211186486750 [[],[]] .three = true := by decide
def e1211186486766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 3)) (.var 2)))))))
theorem wire_e1211186486766 : Closed e1211186486766 ∧ code e1211186486766 = 5609232997870 := by decide
theorem cert_e1211186486766 : check e1211186486766 [[],[]] .three = true := by decide
def e1211186486838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e1211186486838 : Closed e1211186486838 ∧ code e1211186486838 = 5609232997942 := by decide
theorem cert_e1211186486838 : check e1211186486838 [[],[]] .smaller = true := by decide
def e1211186486842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e1211186486842 : Closed e1211186486842 ∧ code e1211186486842 = 5609232997946 := by decide
theorem cert_e1211186486842 : check e1211186486842 [[],[]] .smaller = true := by decide
def e1211186486890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e1211186486890 : Closed e1211186486890 ∧ code e1211186486890 = 5609232997994 := by decide
theorem cert_e1211186486890 : check e1211186486890 [[],[]] .smaller = true := by decide
def e1211186486926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e1211186486926 : Closed e1211186486926 ∧ code e1211186486926 = 5609232998030 := by decide
theorem cert_e1211186486926 : check e1211186486926 [[],[]] .smaller = true := by decide
def e1211186486938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186486938 : Closed e1211186486938 ∧ code e1211186486938 = 5609232998042 := by decide
theorem cert_e1211186486938 : check e1211186486938 [[],[]] .smaller = true := by decide
def e1211186486982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e1211186486982 : Closed e1211186486982 ∧ code e1211186486982 = 5609232998086 := by decide
theorem cert_e1211186486982 : check e1211186486982 [[],[]] .smaller = true := by decide
def e1211186487006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 3)))))))
theorem wire_e1211186487006 : Closed e1211186487006 ∧ code e1211186487006 = 5609232998110 := by decide
theorem cert_e1211186487006 : check e1211186487006 [[],[]] .three = true := by decide
def e1211186487030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 3)) (.var 1)))))))
theorem wire_e1211186487030 : Closed e1211186487030 ∧ code e1211186487030 = 5609232998134 := by decide
theorem cert_e1211186487030 : check e1211186487030 [[],[]] .three = true := by decide
def e1211186487066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186487066 : Closed e1211186487066 ∧ code e1211186487066 = 5609232998170 := by decide
theorem cert_e1211186487066 : check e1211186487066 [[],[]] .three = true := by decide
def e1211186487110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186487110 : Closed e1211186487110 ∧ code e1211186487110 = 5609232998214 := by decide
theorem cert_e1211186487110 : check e1211186487110 [[],[]] .three = true := by decide
def e1211186487134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 3)))))))
theorem wire_e1211186487134 : Closed e1211186487134 ∧ code e1211186487134 = 5609232998238 := by decide
theorem cert_e1211186487134 : check e1211186487134 [[],[]] .three = true := by decide
def e1211186487150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 1)) (.var 2)))))))
theorem wire_e1211186487150 : Closed e1211186487150 ∧ code e1211186487150 = 5609232998254 := by decide
theorem cert_e1211186487150 : check e1211186487150 [[],[]] .three = true := by decide
def e1211186487158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 2)) (.var 1)))))))
theorem wire_e1211186487158 : Closed e1211186487158 ∧ code e1211186487158 = 5609232998262 := by decide
theorem cert_e1211186487158 : check e1211186487158 [[],[]] .three = true := by decide
def e1211186487162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 3)) (.var 0)))))))
theorem wire_e1211186487162 : Closed e1211186487162 ∧ code e1211186487162 = 5609232998266 := by decide
theorem cert_e1211186487162 : check e1211186487162 [[],[]] .three = true := by decide
def e1211186491742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e1211186491742 : Closed e1211186491742 ∧ code e1211186491742 = 5609233002846 := by decide
theorem cert_e1211186491742 : check e1211186491742 [[],[]] .three = true := by decide
def e1211186491758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e1211186491758 : Closed e1211186491758 ∧ code e1211186491758 = 5609233002862 := by decide
theorem cert_e1211186491758 : check e1211186491758 [[],[]] .smaller = true := by decide
def e1211186491766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e1211186491766 : Closed e1211186491766 ∧ code e1211186491766 = 5609233002870 := by decide
theorem cert_e1211186491766 : check e1211186491766 [[],[]] .smaller = true := by decide
def e1211186491770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e1211186491770 : Closed e1211186491770 ∧ code e1211186491770 = 5609233002874 := by decide
theorem cert_e1211186491770 : check e1211186491770 [[],[]] .three = true := by decide
def e1211186491822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186491822 : Closed e1211186491822 ∧ code e1211186491822 = 5609233002926 := by decide
theorem cert_e1211186491822 : check e1211186491822 [[],[]] .smaller = true := by decide
def e1211186491834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186491834 : Closed e1211186491834 ∧ code e1211186491834 = 5609233002938 := by decide
theorem cert_e1211186491834 : check e1211186491834 [[],[]] .smaller = true := by decide
def e1211186491882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186491882 : Closed e1211186491882 ∧ code e1211186491882 = 5609233002986 := by decide
theorem cert_e1211186491882 : check e1211186491882 [[],[]] .smaller = true := by decide
def e1211186492510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e1211186492510 : Closed e1211186492510 ∧ code e1211186492510 = 5609233003614 := by decide
theorem cert_e1211186492510 : check e1211186492510 [[],[]] .three = true := by decide
def e1211186492526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e1211186492526 : Closed e1211186492526 ∧ code e1211186492526 = 5609233003630 := by decide
theorem cert_e1211186492526 : check e1211186492526 [[],[]] .smaller = true := by decide
def e1211186492538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e1211186492538 : Closed e1211186492538 ∧ code e1211186492538 = 5609233003642 := by decide
theorem cert_e1211186492538 : check e1211186492538 [[],[]] .smaller = true := by decide
def e1211186492702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e1211186492702 : Closed e1211186492702 ∧ code e1211186492702 = 5609233003806 := by decide
theorem cert_e1211186492702 : check e1211186492702 [[],[]] .smaller = true := by decide
def e1211186492870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e1211186492870 : Closed e1211186492870 ∧ code e1211186492870 = 5609233003974 := by decide
theorem cert_e1211186492870 : check e1211186492870 [[],[]] .smaller = true := by decide
def e1211186492894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e1211186492894 : Closed e1211186492894 ∧ code e1211186492894 = 5609233003998 := by decide
theorem cert_e1211186492894 : check e1211186492894 [[],[]] .three = true := by decide
def e1211186492898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e1211186492898 : Closed e1211186492898 ∧ code e1211186492898 = 5609233004002 := by decide
theorem cert_e1211186492898 : check e1211186492898 [[],[]] .three = true := by decide
def e1211186492910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e1211186492910 : Closed e1211186492910 ∧ code e1211186492910 = 5609233004014 := by decide
theorem cert_e1211186492910 : check e1211186492910 [[],[]] .three = true := by decide
def e1211186492974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211186492974 : Closed e1211186492974 ∧ code e1211186492974 = 5609233004078 := by decide
theorem cert_e1211186492974 : check e1211186492974 [[],[]] .smaller = true := by decide
def e1211186493150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e1211186493150 : Closed e1211186493150 ∧ code e1211186493150 = 5609233004254 := by decide
theorem cert_e1211186493150 : check e1211186493150 [[],[]] .three = true := by decide
def e1211186493154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211186493154 : Closed e1211186493154 ∧ code e1211186493154 = 5609233004258 := by decide
theorem cert_e1211186493154 : check e1211186493154 [[],[]] .smaller = true := by decide
def e1211186493166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e1211186493166 : Closed e1211186493166 ∧ code e1211186493166 = 5609233004270 := by decide
theorem cert_e1211186493166 : check e1211186493166 [[],[]] .smaller = true := by decide
def e1211186493174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e1211186493174 : Closed e1211186493174 ∧ code e1211186493174 = 5609233004278 := by decide
theorem cert_e1211186493174 : check e1211186493174 [[],[]] .three = true := by decide
def e1211186493206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186493206 : Closed e1211186493206 ∧ code e1211186493206 = 5609233004310 := by decide
theorem cert_e1211186493206 : check e1211186493206 [[],[]] .smaller = true := by decide
def e1211186493210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186493210 : Closed e1211186493210 ∧ code e1211186493210 = 5609233004314 := by decide
theorem cert_e1211186493210 : check e1211186493210 [[],[]] .smaller = true := by decide
def e1211186493254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186493254 : Closed e1211186493254 ∧ code e1211186493254 = 5609233004358 := by decide
theorem cert_e1211186493254 : check e1211186493254 [[],[]] .smaller = true := by decide
def e1211186493278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e1211186493278 : Closed e1211186493278 ∧ code e1211186493278 = 5609233004382 := by decide
theorem cert_e1211186493278 : check e1211186493278 [[],[]] .three = true := by decide
def e1211186493282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186493282 : Closed e1211186493282 ∧ code e1211186493282 = 5609233004386 := by decide
theorem cert_e1211186493282 : check e1211186493282 [[],[]] .smaller = true := by decide
def e1211186493294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e1211186493294 : Closed e1211186493294 ∧ code e1211186493294 = 5609233004398 := by decide
theorem cert_e1211186493294 : check e1211186493294 [[],[]] .smaller = true := by decide
def e1211186493302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e1211186493302 : Closed e1211186493302 ∧ code e1211186493302 = 5609233004406 := by decide
theorem cert_e1211186493302 : check e1211186493302 [[],[]] .smaller = true := by decide
def e1211186493306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e1211186493306 : Closed e1211186493306 ∧ code e1211186493306 = 5609233004410 := by decide
theorem cert_e1211186493306 : check e1211186493306 [[],[]] .three = true := by decide
def e1211186493322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186493322 : Closed e1211186493322 ∧ code e1211186493322 = 5609233004426 := by decide
theorem cert_e1211186493322 : check e1211186493322 [[],[]] .three = true := by decide
def e1211186493346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186493346 : Closed e1211186493346 ∧ code e1211186493346 = 5609233004450 := by decide
theorem cert_e1211186493346 : check e1211186493346 [[],[]] .three = true := by decide
def e1211186493358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e1211186493358 : Closed e1211186493358 ∧ code e1211186493358 = 5609233004462 := by decide
theorem cert_e1211186493358 : check e1211186493358 [[],[]] .three = true := by decide
def e1211186493366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e1211186493366 : Closed e1211186493366 ∧ code e1211186493366 = 5609233004470 := by decide
theorem cert_e1211186493366 : check e1211186493366 [[],[]] .three = true := by decide
def e1211186493370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e1211186493370 : Closed e1211186493370 ∧ code e1211186493370 = 5609233004474 := by decide
theorem cert_e1211186493370 : check e1211186493370 [[],[]] .three = true := by decide
def e1211186493614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e1211186493614 : Closed e1211186493614 ∧ code e1211186493614 = 5609233004718 := by decide
theorem cert_e1211186493614 : check e1211186493614 [[],[]] .smaller = true := by decide
def e1211186493626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e1211186493626 : Closed e1211186493626 ∧ code e1211186493626 = 5609233004730 := by decide
theorem cert_e1211186493626 : check e1211186493626 [[],[]] .smaller = true := by decide
def e1211186493998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e1211186493998 : Closed e1211186493998 ∧ code e1211186493998 = 5609233005102 := by decide
theorem cert_e1211186493998 : check e1211186493998 [[],[]] .smaller = true := by decide
def e1211186494174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e1211186494174 : Closed e1211186494174 ∧ code e1211186494174 = 5609233005278 := by decide
theorem cert_e1211186494174 : check e1211186494174 [[],[]] .three = true := by decide
def e1211186494178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e1211186494178 : Closed e1211186494178 ∧ code e1211186494178 = 5609233005282 := by decide
theorem cert_e1211186494178 : check e1211186494178 [[],[]] .smaller = true := by decide
def e1211186494190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e1211186494190 : Closed e1211186494190 ∧ code e1211186494190 = 5609233005294 := by decide
theorem cert_e1211186494190 : check e1211186494190 [[],[]] .smaller = true := by decide
def e1211186494198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e1211186494198 : Closed e1211186494198 ∧ code e1211186494198 = 5609233005302 := by decide
theorem cert_e1211186494198 : check e1211186494198 [[],[]] .three = true := by decide
def e1211186494302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e1211186494302 : Closed e1211186494302 ∧ code e1211186494302 = 5609233005406 := by decide
theorem cert_e1211186494302 : check e1211186494302 [[],[]] .three = true := by decide
def e1211186494330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e1211186494330 : Closed e1211186494330 ∧ code e1211186494330 = 5609233005434 := by decide
theorem cert_e1211186494330 : check e1211186494330 [[],[]] .three = true := by decide
def e1211186494346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186494346 : Closed e1211186494346 ∧ code e1211186494346 = 5609233005450 := by decide
theorem cert_e1211186494346 : check e1211186494346 [[],[]] .smaller = true := by decide
def e1211186494370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186494370 : Closed e1211186494370 ∧ code e1211186494370 = 5609233005474 := by decide
theorem cert_e1211186494370 : check e1211186494370 [[],[]] .smaller = true := by decide
def e1211186494382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e1211186494382 : Closed e1211186494382 ∧ code e1211186494382 = 5609233005486 := by decide
theorem cert_e1211186494382 : check e1211186494382 [[],[]] .smaller = true := by decide
def e1211186494394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e1211186494394 : Closed e1211186494394 ∧ code e1211186494394 = 5609233005498 := by decide
theorem cert_e1211186494394 : check e1211186494394 [[],[]] .smaller = true := by decide
def e1211186494422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e1211186494422 : Closed e1211186494422 ∧ code e1211186494422 = 5609233005526 := by decide
theorem cert_e1211186494422 : check e1211186494422 [[],[]] .three = true := by decide
def e1211186494426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e1211186494426 : Closed e1211186494426 ∧ code e1211186494426 = 5609233005530 := by decide
theorem cert_e1211186494426 : check e1211186494426 [[],[]] .three = true := by decide
def e1211186494550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e1211186494550 : Closed e1211186494550 ∧ code e1211186494550 = 5609233005654 := by decide
theorem cert_e1211186494550 : check e1211186494550 [[],[]] .smaller = true := by decide
def e1211186494554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e1211186494554 : Closed e1211186494554 ∧ code e1211186494554 = 5609233005658 := by decide
theorem cert_e1211186494554 : check e1211186494554 [[],[]] .smaller = true := by decide
def e1211186494570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186494570 : Closed e1211186494570 ∧ code e1211186494570 = 5609233005674 := by decide
theorem cert_e1211186494570 : check e1211186494570 [[],[]] .smaller = true := by decide
def e1211186494742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1211186494742 : Closed e1211186494742 ∧ code e1211186494742 = 5609233005846 := by decide
theorem cert_e1211186494742 : check e1211186494742 [[],[]] .smaller = true := by decide
def e1211186494746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e1211186494746 : Closed e1211186494746 ∧ code e1211186494746 = 5609233005850 := by decide
theorem cert_e1211186494746 : check e1211186494746 [[],[]] .smaller = true := by decide
def e1211186494790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e1211186494790 : Closed e1211186494790 ∧ code e1211186494790 = 5609233005894 := by decide
theorem cert_e1211186494790 : check e1211186494790 [[],[]] .smaller = true := by decide
def e1211186494814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e1211186494814 : Closed e1211186494814 ∧ code e1211186494814 = 5609233005918 := by decide
theorem cert_e1211186494814 : check e1211186494814 [[],[]] .three = true := by decide
def e1211186494818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1211186494818 : Closed e1211186494818 ∧ code e1211186494818 = 5609233005922 := by decide
theorem cert_e1211186494818 : check e1211186494818 [[],[]] .smaller = true := by decide
def e1211186494830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e1211186494830 : Closed e1211186494830 ∧ code e1211186494830 = 5609233005934 := by decide
theorem cert_e1211186494830 : check e1211186494830 [[],[]] .smaller = true := by decide
def e1211186494838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e1211186494838 : Closed e1211186494838 ∧ code e1211186494838 = 5609233005942 := by decide
theorem cert_e1211186494838 : check e1211186494838 [[],[]] .smaller = true := by decide
def e1211186494842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e1211186494842 : Closed e1211186494842 ∧ code e1211186494842 = 5609233005946 := by decide
theorem cert_e1211186494842 : check e1211186494842 [[],[]] .three = true := by decide
def e1211186494858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186494858 : Closed e1211186494858 ∧ code e1211186494858 = 5609233005962 := by decide
theorem cert_e1211186494858 : check e1211186494858 [[],[]] .smaller = true := by decide
def e1211186494882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186494882 : Closed e1211186494882 ∧ code e1211186494882 = 5609233005986 := by decide
theorem cert_e1211186494882 : check e1211186494882 [[],[]] .smaller = true := by decide
def e1211186494894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e1211186494894 : Closed e1211186494894 ∧ code e1211186494894 = 5609233005998 := by decide
theorem cert_e1211186494894 : check e1211186494894 [[],[]] .smaller = true := by decide
def e1211186494906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e1211186494906 : Closed e1211186494906 ∧ code e1211186494906 = 5609233006010 := by decide
theorem cert_e1211186494906 : check e1211186494906 [[],[]] .smaller = true := by decide
def e1211186494934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e1211186494934 : Closed e1211186494934 ∧ code e1211186494934 = 5609233006038 := by decide
theorem cert_e1211186494934 : check e1211186494934 [[],[]] .smaller = true := by decide
def e1211186494938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e1211186494938 : Closed e1211186494938 ∧ code e1211186494938 = 5609233006042 := by decide
theorem cert_e1211186494938 : check e1211186494938 [[],[]] .smaller = true := by decide
def e1211186494954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e1211186494954 : Closed e1211186494954 ∧ code e1211186494954 = 5609233006058 := by decide
theorem cert_e1211186494954 : check e1211186494954 [[],[]] .three = true := by decide
def e1211186495018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e1211186495018 : Closed e1211186495018 ∧ code e1211186495018 = 5609233006122 := by decide
theorem cert_e1211186495018 : check e1211186495018 [[],[]] .three = true := by decide
def e1211186495114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1211186495114 : Closed e1211186495114 ∧ code e1211186495114 = 5609233006218 := by decide
theorem cert_e1211186495114 : check e1211186495114 [[],[]] .three = true := by decide
def e1211186495138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1211186495138 : Closed e1211186495138 ∧ code e1211186495138 = 5609233006242 := by decide
theorem cert_e1211186495138 : check e1211186495138 [[],[]] .three = true := by decide
def e1211186495150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e1211186495150 : Closed e1211186495150 ∧ code e1211186495150 = 5609233006254 := by decide
theorem cert_e1211186495150 : check e1211186495150 [[],[]] .three = true := by decide
def e1211186495158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e1211186495158 : Closed e1211186495158 ∧ code e1211186495158 = 5609233006262 := by decide
theorem cert_e1211186495158 : check e1211186495158 [[],[]] .three = true := by decide
def e1211186495162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e1211186495162 : Closed e1211186495162 ∧ code e1211186495162 = 5609233006266 := by decide
theorem cert_e1211186495162 : check e1211186495162 [[],[]] .three = true := by decide
def e1211186495190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e1211186495190 : Closed e1211186495190 ∧ code e1211186495190 = 5609233006294 := by decide
theorem cert_e1211186495190 : check e1211186495190 [[],[]] .three = true := by decide
def e1211186495194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e1211186495194 : Closed e1211186495194 ∧ code e1211186495194 = 5609233006298 := by decide
theorem cert_e1211186495194 : check e1211186495194 [[],[]] .three = true := by decide
def e1211186495210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e1211186495210 : Closed e1211186495210 ∧ code e1211186495210 = 5609233006314 := by decide
theorem cert_e1211186495210 : check e1211186495210 [[],[]] .three = true := by decide
def e1211186495966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 3)))))))
theorem wire_e1211186495966 : Closed e1211186495966 ∧ code e1211186495966 = 5609233007070 := by decide
theorem cert_e1211186495966 : check e1211186495966 [[],[]] .three = true := by decide
def e1211186495982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e1211186495982 : Closed e1211186495982 ∧ code e1211186495982 = 5609233007086 := by decide
theorem cert_e1211186495982 : check e1211186495982 [[],[]] .smaller = true := by decide
def e1211186495990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e1211186495990 : Closed e1211186495990 ∧ code e1211186495990 = 5609233007094 := by decide
theorem cert_e1211186495990 : check e1211186495990 [[],[]] .smaller = true := by decide
def e1211186495994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 5)))) (.var 0)))))))
theorem wire_e1211186495994 : Closed e1211186495994 ∧ code e1211186495994 = 5609233007098 := by decide
theorem cert_e1211186495994 : check e1211186495994 [[],[]] .three = true := by decide
def e1211186496350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e1211186496350 : Closed e1211186496350 ∧ code e1211186496350 = 5609233007454 := by decide
theorem cert_e1211186496350 : check e1211186496350 [[],[]] .three = true := by decide
def e1211186496366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e1211186496366 : Closed e1211186496366 ∧ code e1211186496366 = 5609233007470 := by decide
theorem cert_e1211186496366 : check e1211186496366 [[],[]] .smaller = true := by decide
def e1211186496378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e1211186496378 : Closed e1211186496378 ∧ code e1211186496378 = 5609233007482 := by decide
theorem cert_e1211186496378 : check e1211186496378 [[],[]] .smaller = true := by decide
def e1211186496430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e1211186496430 : Closed e1211186496430 ∧ code e1211186496430 = 5609233007534 := by decide
theorem cert_e1211186496430 : check e1211186496430 [[],[]] .smaller = true := by decide
def e1211186496490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e1211186496490 : Closed e1211186496490 ∧ code e1211186496490 = 5609233007594 := by decide
theorem cert_e1211186496490 : check e1211186496490 [[],[]] .smaller = true := by decide
def e1211186496734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186496734 : Closed e1211186496734 ∧ code e1211186496734 = 5609233007838 := by decide
theorem cert_e1211186496734 : check e1211186496734 [[],[]] .three = true := by decide
def e1211186496750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e1211186496750 : Closed e1211186496750 ∧ code e1211186496750 = 5609233007854 := by decide
theorem cert_e1211186496750 : check e1211186496750 [[],[]] .smaller = true := by decide
def e1211186496758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e1211186496758 : Closed e1211186496758 ∧ code e1211186496758 = 5609233007862 := by decide
theorem cert_e1211186496758 : check e1211186496758 [[],[]] .smaller = true := by decide
def e1211186496762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e1211186496762 : Closed e1211186496762 ∧ code e1211186496762 = 5609233007866 := by decide
theorem cert_e1211186496762 : check e1211186496762 [[],[]] .three = true := by decide
def e1211186497086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 4))))))))
theorem wire_e1211186497086 : Closed e1211186497086 ∧ code e1211186497086 = 5609233008190 := by decide
theorem cert_e1211186497086 : check e1211186497086 [[],[]] .three = true := by decide
def e1211186497134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e1211186497134 : Closed e1211186497134 ∧ code e1211186497134 = 5609233008238 := by decide
theorem cert_e1211186497134 : check e1211186497134 [[],[]] .smaller = true := by decide
def e1211186497146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e1211186497146 : Closed e1211186497146 ∧ code e1211186497146 = 5609233008250 := by decide
theorem cert_e1211186497146 : check e1211186497146 [[],[]] .smaller = true := by decide
def e1211186497310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e1211186497310 : Closed e1211186497310 ∧ code e1211186497310 = 5609233008414 := by decide
theorem cert_e1211186497310 : check e1211186497310 [[],[]] .smaller = true := by decide
def e1211186497422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e1211186497422 : Closed e1211186497422 ∧ code e1211186497422 = 5609233008526 := by decide
theorem cert_e1211186497422 : check e1211186497422 [[],[]] .smaller = true := by decide
def e1211186497434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e1211186497434 : Closed e1211186497434 ∧ code e1211186497434 = 5609233008538 := by decide
theorem cert_e1211186497434 : check e1211186497434 [[],[]] .smaller = true := by decide
def e1211186497478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.lam (.var 1))))))))
theorem wire_e1211186497478 : Closed e1211186497478 ∧ code e1211186497478 = 5609233008582 := by decide
theorem cert_e1211186497478 : check e1211186497478 [[],[]] .three = true := by decide
def e1211186497502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 3)))))))
theorem wire_e1211186497502 : Closed e1211186497502 ∧ code e1211186497502 = 5609233008606 := by decide
theorem cert_e1211186497502 : check e1211186497502 [[],[]] .three = true := by decide
def e1211186498654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e1211186498654 : Closed e1211186498654 ∧ code e1211186498654 = 5609233009758 := by decide
theorem cert_e1211186498654 : check e1211186498654 [[],[]] .three = true := by decide
def e1211186498670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e1211186498670 : Closed e1211186498670 ∧ code e1211186498670 = 5609233009774 := by decide
theorem cert_e1211186498670 : check e1211186498670 [[],[]] .smaller = true := by decide
def e1211186498682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e1211186498682 : Closed e1211186498682 ∧ code e1211186498682 = 5609233009786 := by decide
theorem cert_e1211186498682 : check e1211186498682 [[],[]] .smaller = true := by decide
def e1211186498846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e1211186498846 : Closed e1211186498846 ∧ code e1211186498846 = 5609233009950 := by decide
theorem cert_e1211186498846 : check e1211186498846 [[],[]] .smaller = true := by decide
def e1211186499014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e1211186499014 : Closed e1211186499014 ∧ code e1211186499014 = 5609233010118 := by decide
theorem cert_e1211186499014 : check e1211186499014 [[],[]] .smaller = true := by decide
def e1211186499038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e1211186499038 : Closed e1211186499038 ∧ code e1211186499038 = 5609233010142 := by decide
theorem cert_e1211186499038 : check e1211186499038 [[],[]] .three = true := by decide
def e1211186499042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.lam (.var 0))))))))
theorem wire_e1211186499042 : Closed e1211186499042 ∧ code e1211186499042 = 5609233010146 := by decide
theorem cert_e1211186499042 : check e1211186499042 [[],[]] .three = true := by decide
def e1211186499054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e1211186499054 : Closed e1211186499054 ∧ code e1211186499054 = 5609233010158 := by decide
theorem cert_e1211186499054 : check e1211186499054 [[],[]] .three = true := by decide
def e1211186499118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e1211186499118 : Closed e1211186499118 ∧ code e1211186499118 = 5609233010222 := by decide
theorem cert_e1211186499118 : check e1211186499118 [[],[]] .smaller = true := by decide
def e1211186499294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e1211186499294 : Closed e1211186499294 ∧ code e1211186499294 = 5609233010398 := by decide
theorem cert_e1211186499294 : check e1211186499294 [[],[]] .three = true := by decide
def e1211186499298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e1211186499298 : Closed e1211186499298 ∧ code e1211186499298 = 5609233010402 := by decide
theorem cert_e1211186499298 : check e1211186499298 [[],[]] .smaller = true := by decide
def e1211186499310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e1211186499310 : Closed e1211186499310 ∧ code e1211186499310 = 5609233010414 := by decide
theorem cert_e1211186499310 : check e1211186499310 [[],[]] .smaller = true := by decide
def e1211186499318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e1211186499318 : Closed e1211186499318 ∧ code e1211186499318 = 5609233010422 := by decide
theorem cert_e1211186499318 : check e1211186499318 [[],[]] .three = true := by decide
def e1211186499350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e1211186499350 : Closed e1211186499350 ∧ code e1211186499350 = 5609233010454 := by decide
theorem cert_e1211186499350 : check e1211186499350 [[],[]] .smaller = true := by decide
def e1211186499354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e1211186499354 : Closed e1211186499354 ∧ code e1211186499354 = 5609233010458 := by decide
theorem cert_e1211186499354 : check e1211186499354 [[],[]] .smaller = true := by decide
def e1211186499398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e1211186499398 : Closed e1211186499398 ∧ code e1211186499398 = 5609233010502 := by decide
theorem cert_e1211186499398 : check e1211186499398 [[],[]] .smaller = true := by decide
def e1211186499422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e1211186499422 : Closed e1211186499422 ∧ code e1211186499422 = 5609233010526 := by decide
theorem cert_e1211186499422 : check e1211186499422 [[],[]] .three = true := by decide
def e1211186499426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e1211186499426 : Closed e1211186499426 ∧ code e1211186499426 = 5609233010530 := by decide
theorem cert_e1211186499426 : check e1211186499426 [[],[]] .smaller = true := by decide
def e1211186499438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e1211186499438 : Closed e1211186499438 ∧ code e1211186499438 = 5609233010542 := by decide
theorem cert_e1211186499438 : check e1211186499438 [[],[]] .smaller = true := by decide
def e1211186499446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e1211186499446 : Closed e1211186499446 ∧ code e1211186499446 = 5609233010550 := by decide
theorem cert_e1211186499446 : check e1211186499446 [[],[]] .smaller = true := by decide
def e1211186499450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e1211186499450 : Closed e1211186499450 ∧ code e1211186499450 = 5609233010554 := by decide
theorem cert_e1211186499450 : check e1211186499450 [[],[]] .three = true := by decide
def e1211186499466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e1211186499466 : Closed e1211186499466 ∧ code e1211186499466 = 5609233010570 := by decide
theorem cert_e1211186499466 : check e1211186499466 [[],[]] .three = true := by decide
def e1211186499490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.lam (.var 0))))))))
theorem wire_e1211186499490 : Closed e1211186499490 ∧ code e1211186499490 = 5609233010594 := by decide
theorem cert_e1211186499490 : check e1211186499490 [[],[]] .three = true := by decide
def e1211186499502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e1211186499502 : Closed e1211186499502 ∧ code e1211186499502 = 5609233010606 := by decide
theorem cert_e1211186499502 : check e1211186499502 [[],[]] .three = true := by decide
def e1211186499510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e1211186499510 : Closed e1211186499510 ∧ code e1211186499510 = 5609233010614 := by decide
theorem cert_e1211186499510 : check e1211186499510 [[],[]] .three = true := by decide
def e1211186499514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e1211186499514 : Closed e1211186499514 ∧ code e1211186499514 = 5609233010618 := by decide
theorem cert_e1211186499514 : check e1211186499514 [[],[]] .three = true := by decide
def e1211186499710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 5)))))))))
theorem wire_e1211186499710 : Closed e1211186499710 ∧ code e1211186499710 = 5609233010814 := by decide
theorem cert_e1211186499710 : check e1211186499710 [[],[]] .three = true := by decide
def e1211186499806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e1211186499806 : Closed e1211186499806 ∧ code e1211186499806 = 5609233010910 := by decide
theorem cert_e1211186499806 : check e1211186499806 [[],[]] .smaller = true := by decide
def e1211186499834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e1211186499834 : Closed e1211186499834 ∧ code e1211186499834 = 5609233010938 := by decide
theorem cert_e1211186499834 : check e1211186499834 [[],[]] .smaller = true := by decide
def e1211186500382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e1211186500382 : Closed e1211186500382 ∧ code e1211186500382 = 5609233011486 := by decide
theorem cert_e1211186500382 : check e1211186500382 [[],[]] .smaller = true := by decide
def e1211186500550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e1211186500550 : Closed e1211186500550 ∧ code e1211186500550 = 5609233011654 := by decide
theorem cert_e1211186500550 : check e1211186500550 [[],[]] .smaller = true := by decide
def e1211186500574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e1211186500574 : Closed e1211186500574 ∧ code e1211186500574 = 5609233011678 := by decide
theorem cert_e1211186500574 : check e1211186500574 [[],[]] .three = true := by decide
def e1211186500578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e1211186500578 : Closed e1211186500578 ∧ code e1211186500578 = 5609233011682 := by decide
theorem cert_e1211186500578 : check e1211186500578 [[],[]] .three = true := by decide
def e1211186500590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e1211186500590 : Closed e1211186500590 ∧ code e1211186500590 = 5609233011694 := by decide
theorem cert_e1211186500590 : check e1211186500590 [[],[]] .three = true := by decide
def e1211186501694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e1211186501694 : Closed e1211186501694 ∧ code e1211186501694 = 5609233012798 := by decide
theorem cert_e1211186501694 : check e1211186501694 [[],[]] .smaller = true := by decide
def e1211186502110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e1211186502110 : Closed e1211186502110 ∧ code e1211186502110 = 5609233013214 := by decide
theorem cert_e1211186502110 : check e1211186502110 [[],[]] .three = true := by decide
def e1211186502114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211186502114 : Closed e1211186502114 ∧ code e1211186502114 = 5609233013218 := by decide
theorem cert_e1211186502114 : check e1211186502114 [[],[]] .smaller = true := by decide
def e1211186502126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e1211186502126 : Closed e1211186502126 ∧ code e1211186502126 = 5609233013230 := by decide
theorem cert_e1211186502126 : check e1211186502126 [[],[]] .smaller = true := by decide
def e1211186502134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e1211186502134 : Closed e1211186502134 ∧ code e1211186502134 = 5609233013238 := by decide
theorem cert_e1211186502134 : check e1211186502134 [[],[]] .three = true := by decide
def e1211186502686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e1211186502686 : Closed e1211186502686 ∧ code e1211186502686 = 5609233013790 := by decide
theorem cert_e1211186502686 : check e1211186502686 [[],[]] .smaller = true := by decide
def e1211186502710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e1211186502710 : Closed e1211186502710 ∧ code e1211186502710 = 5609233013814 := by decide
theorem cert_e1211186502710 : check e1211186502710 [[],[]] .smaller = true := by decide
def e1211186502714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e1211186502714 : Closed e1211186502714 ∧ code e1211186502714 = 5609233013818 := by decide
theorem cert_e1211186502714 : check e1211186502714 [[],[]] .smaller = true := by decide
def e1211186502854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211186502854 : Closed e1211186502854 ∧ code e1211186502854 = 5609233013958 := by decide
theorem cert_e1211186502854 : check e1211186502854 [[],[]] .smaller = true := by decide
def e1211186502878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e1211186502878 : Closed e1211186502878 ∧ code e1211186502878 = 5609233013982 := by decide
theorem cert_e1211186502878 : check e1211186502878 [[],[]] .three = true := by decide
def e1211186502882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211186502882 : Closed e1211186502882 ∧ code e1211186502882 = 5609233013986 := by decide
theorem cert_e1211186502882 : check e1211186502882 [[],[]] .smaller = true := by decide
end Blc.Floor42
