import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205815163370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e1205815163370 : Closed e1205815163370 ∧ code e1205815163370 = 5603861674474 := by decide
theorem cert_e1205815163370 : check e1205815163370 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815163406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e1205815163406 : Closed e1205815163406 ∧ code e1205815163406 = 5603861674510 := by decide
theorem cert_e1205815163406 : check e1205815163406 [[],[]] .chain = true := by decide
def e1205815163418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1205815163418 : Closed e1205815163418 ∧ code e1205815163418 = 5603861674522 := by decide
theorem cert_e1205815163418 : check e1205815163418 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1205815163490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1205815163490 : Closed e1205815163490 ∧ code e1205815163490 = 5603861674594 := by decide
theorem cert_e1205815163490 : check e1205815163490 [[],[]] .chain = true := by decide
def e1205815163502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e1205815163502 : Closed e1205815163502 ∧ code e1205815163502 = 5603861674606 := by decide
theorem cert_e1205815163502 : check e1205815163502 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815163510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1205815163510 : Closed e1205815163510 ∧ code e1205815163510 = 5603861674614 := by decide
theorem cert_e1205815163510 : check e1205815163510 [[],[]] .chain = true := by decide
def e1205815163514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e1205815163514 : Closed e1205815163514 ∧ code e1205815163514 = 5603861674618 := by decide
theorem cert_e1205815163514 : check e1205815163514 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815163702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815163702 : Closed e1205815163702 ∧ code e1205815163702 = 5603861674806 := by decide
theorem cert_e1205815163702 : check e1205815163702 [[],[]] .chain = true := by decide
def e1205815163706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815163706 : Closed e1205815163706 ∧ code e1205815163706 = 5603861674810 := by decide
theorem cert_e1205815163706 : check e1205815163706 [[],[]] .chain = true := by decide
def e1205815163802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815163802 : Closed e1205815163802 ∧ code e1205815163802 = 5603861674906 := by decide
theorem cert_e1205815163802 : check e1205815163802 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815164118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1205815164118 : Closed e1205815164118 ∧ code e1205815164118 = 5603861675222 := by decide
theorem cert_e1205815164118 : check e1205815164118 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815164122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1205815164122 : Closed e1205815164122 ∧ code e1205815164122 = 5603861675226 := by decide
theorem cert_e1205815164122 : check e1205815164122 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815164138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1205815164138 : Closed e1205815164138 ∧ code e1205815164138 = 5603861675242 := by decide
theorem cert_e1205815164138 : check e1205815164138 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815164214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1205815164214 : Closed e1205815164214 ∧ code e1205815164214 = 5603861675318 := by decide
theorem cert_e1205815164214 : check e1205815164214 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815164218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1205815164218 : Closed e1205815164218 ∧ code e1205815164218 = 5603861675322 := by decide
theorem cert_e1205815164218 : check e1205815164218 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815164314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1205815164314 : Closed e1205815164314 ∧ code e1205815164314 = 5603861675418 := by decide
theorem cert_e1205815164314 : check e1205815164314 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e1205815165918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e1205815165918 : Closed e1205815165918 ∧ code e1205815165918 = 5603861677022 := by decide
theorem cert_e1205815165918 : check e1205815165918 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815165934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e1205815165934 : Closed e1205815165934 ∧ code e1205815165934 = 5603861677038 := by decide
theorem cert_e1205815165934 : check e1205815165934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815167766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e1205815167766 : Closed e1205815167766 ∧ code e1205815167766 = 5603861678870 := by decide
theorem cert_e1205815167766 : check e1205815167766 [[],[]] .chain = true := by decide
def e1205815167842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e1205815167842 : Closed e1205815167842 ∧ code e1205815167842 = 5603861678946 := by decide
theorem cert_e1205815167842 : check e1205815167842 [[],[]] .chain = true := by decide
def e1205815167854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1205815167854 : Closed e1205815167854 ∧ code e1205815167854 = 5603861678958 := by decide
theorem cert_e1205815167854 : check e1205815167854 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815167862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1205815167862 : Closed e1205815167862 ∧ code e1205815167862 = 5603861678966 := by decide
theorem cert_e1205815167862 : check e1205815167862 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815167882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815167882 : Closed e1205815167882 ∧ code e1205815167882 = 5603861678986 := by decide
theorem cert_e1205815167882 : check e1205815167882 [[],[]] .chain = true := by decide
def e1205815167906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815167906 : Closed e1205815167906 ∧ code e1205815167906 = 5603861679010 := by decide
theorem cert_e1205815167906 : check e1205815167906 [[],[]] .chain = true := by decide
def e1205815167918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1205815167918 : Closed e1205815167918 ∧ code e1205815167918 = 5603861679022 := by decide
theorem cert_e1205815167918 : check e1205815167918 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815167926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e1205815167926 : Closed e1205815167926 ∧ code e1205815167926 = 5603861679030 := by decide
theorem cert_e1205815167926 : check e1205815167926 [[],[]] .chain = true := by decide
def e1205815167930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1205815167930 : Closed e1205815167930 ∧ code e1205815167930 = 5603861679034 := by decide
theorem cert_e1205815167930 : check e1205815167930 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815167958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1205815167958 : Closed e1205815167958 ∧ code e1205815167958 = 5603861679062 := by decide
theorem cert_e1205815167958 : check e1205815167958 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815167962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1205815167962 : Closed e1205815167962 ∧ code e1205815167962 = 5603861679066 := by decide
theorem cert_e1205815167962 : check e1205815167962 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e1205815168030 : Closed e1205815168030 ∧ code e1205815168030 = 5603861679134 := by decide
theorem cert_e1205815168030 : check e1205815168030 [[],[]] .chain = true := by decide
def e1205815168226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1205815168226 : Closed e1205815168226 ∧ code e1205815168226 = 5603861679330 := by decide
theorem cert_e1205815168226 : check e1205815168226 [[],[]] .chain = true := by decide
def e1205815168238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1205815168238 : Closed e1205815168238 ∧ code e1205815168238 = 5603861679342 := by decide
theorem cert_e1205815168238 : check e1205815168238 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1205815168246 : Closed e1205815168246 ∧ code e1205815168246 = 5603861679350 := by decide
theorem cert_e1205815168246 : check e1205815168246 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815168526 : Closed e1205815168526 ∧ code e1205815168526 = 5603861679630 := by decide
theorem cert_e1205815168526 : check e1205815168526 [[],[]] .chain = true := by decide
def e1205815168538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815168538 : Closed e1205815168538 ∧ code e1205815168538 = 5603861679642 := by decide
theorem cert_e1205815168538 : check e1205815168538 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815168610 : Closed e1205815168610 ∧ code e1205815168610 = 5603861679714 := by decide
theorem cert_e1205815168610 : check e1205815168610 [[],[]] .chain = true := by decide
def e1205815168622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815168622 : Closed e1205815168622 ∧ code e1205815168622 = 5603861679726 := by decide
theorem cert_e1205815168622 : check e1205815168622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815168630 : Closed e1205815168630 ∧ code e1205815168630 = 5603861679734 := by decide
theorem cert_e1205815168630 : check e1205815168630 [[],[]] .chain = true := by decide
def e1205815168634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815168634 : Closed e1205815168634 ∧ code e1205815168634 = 5603861679738 := by decide
theorem cert_e1205815168634 : check e1205815168634 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815168822 : Closed e1205815168822 ∧ code e1205815168822 = 5603861679926 := by decide
theorem cert_e1205815168822 : check e1205815168822 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815168826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815168826 : Closed e1205815168826 ∧ code e1205815168826 = 5603861679930 := by decide
theorem cert_e1205815168826 : check e1205815168826 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815173598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e1205815173598 : Closed e1205815173598 ∧ code e1205815173598 = 5603861684702 := by decide
theorem cert_e1205815173598 : check e1205815173598 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815173622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e1205815173622 : Closed e1205815173622 ∧ code e1205815173622 = 5603861684726 := by decide
theorem cert_e1205815173622 : check e1205815173622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815174538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e1205815174538 : Closed e1205815174538 ∧ code e1205815174538 = 5603861685642 := by decide
theorem cert_e1205815174538 : check e1205815174538 [[],[]] .chain = true := by decide
def e1205815174562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e1205815174562 : Closed e1205815174562 ∧ code e1205815174562 = 5603861685666 := by decide
theorem cert_e1205815174562 : check e1205815174562 [[],[]] .chain = true := by decide
def e1205815174574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e1205815174574 : Closed e1205815174574 ∧ code e1205815174574 = 5603861685678 := by decide
theorem cert_e1205815174574 : check e1205815174574 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815174582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1205815174582 : Closed e1205815174582 ∧ code e1205815174582 = 5603861685686 := by decide
theorem cert_e1205815174582 : check e1205815174582 [[],[]] .chain = true := by decide
def e1205815174586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e1205815174586 : Closed e1205815174586 ∧ code e1205815174586 = 5603861685690 := by decide
theorem cert_e1205815174586 : check e1205815174586 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815174614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1205815174614 : Closed e1205815174614 ∧ code e1205815174614 = 5603861685718 := by decide
theorem cert_e1205815174614 : check e1205815174614 [[],[]] .chain = true := by decide
def e1205815174618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1205815174618 : Closed e1205815174618 ∧ code e1205815174618 = 5603861685722 := by decide
theorem cert_e1205815174618 : check e1205815174618 [[],[]] .chain = true := by decide
def e1205815174634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e1205815174634 : Closed e1205815174634 ∧ code e1205815174634 = 5603861685738 := by decide
theorem cert_e1205815174634 : check e1205815174634 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815174670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e1205815174670 : Closed e1205815174670 ∧ code e1205815174670 = 5603861685774 := by decide
theorem cert_e1205815174670 : check e1205815174670 [[],[]] .chain = true := by decide
def e1205815174682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815174682 : Closed e1205815174682 ∧ code e1205815174682 = 5603861685786 := by decide
theorem cert_e1205815174682 : check e1205815174682 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e1205815174754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e1205815174754 : Closed e1205815174754 ∧ code e1205815174754 = 5603861685858 := by decide
theorem cert_e1205815174754 : check e1205815174754 [[],[]] .chain = true := by decide
def e1205815174766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e1205815174766 : Closed e1205815174766 ∧ code e1205815174766 = 5603861685870 := by decide
theorem cert_e1205815174766 : check e1205815174766 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815174774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1205815174774 : Closed e1205815174774 ∧ code e1205815174774 = 5603861685878 := by decide
theorem cert_e1205815174774 : check e1205815174774 [[],[]] .chain = true := by decide
def e1205815174778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e1205815174778 : Closed e1205815174778 ∧ code e1205815174778 = 5603861685882 := by decide
theorem cert_e1205815174778 : check e1205815174778 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815174966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815174966 : Closed e1205815174966 ∧ code e1205815174966 = 5603861686070 := by decide
theorem cert_e1205815174966 : check e1205815174966 [[],[]] .chain = true := by decide
def e1205815174970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815174970 : Closed e1205815174970 ∧ code e1205815174970 = 5603861686074 := by decide
theorem cert_e1205815174970 : check e1205815174970 [[],[]] .chain = true := by decide
def e1205815175066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815175066 : Closed e1205815175066 ∧ code e1205815175066 = 5603861686170 := by decide
theorem cert_e1205815175066 : check e1205815175066 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e1205815177454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1205815177454 : Closed e1205815177454 ∧ code e1205815177454 = 5603861688558 := by decide
theorem cert_e1205815177454 : check e1205815177454 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815177462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1205815177462 : Closed e1205815177462 ∧ code e1205815177462 = 5603861688566 := by decide
theorem cert_e1205815177462 : check e1205815177462 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815177942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1205815177942 : Closed e1205815177942 ∧ code e1205815177942 = 5603861689046 := by decide
theorem cert_e1205815177942 : check e1205815177942 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815177946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1205815177946 : Closed e1205815177946 ∧ code e1205815177946 = 5603861689050 := by decide
theorem cert_e1205815177946 : check e1205815177946 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815177962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1205815177962 : Closed e1205815177962 ∧ code e1205815177962 = 5603861689066 := by decide
theorem cert_e1205815177962 : check e1205815177962 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815178038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1205815178038 : Closed e1205815178038 ∧ code e1205815178038 = 5603861689142 := by decide
theorem cert_e1205815178038 : check e1205815178038 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815178042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1205815178042 : Closed e1205815178042 ∧ code e1205815178042 = 5603861689146 := by decide
theorem cert_e1205815178042 : check e1205815178042 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815178138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1205815178138 : Closed e1205815178138 ∧ code e1205815178138 = 5603861689242 := by decide
theorem cert_e1205815178138 : check e1205815178138 [[],[],[.under,.under,.left]] .chain = true := by decide
def e1205815225822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1205815225822 : Closed e1205815225822 ∧ code e1205815225822 = 5603861736926 := by decide
theorem cert_e1205815225822 : check e1205815225822 [[],[]] .smaller = true := by decide
def e1205815225838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1205815225838 : Closed e1205815225838 ∧ code e1205815225838 = 5603861736942 := by decide
theorem cert_e1205815225838 : check e1205815225838 [[],[]] .smaller = true := by decide
def e1205815226206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1205815226206 : Closed e1205815226206 ∧ code e1205815226206 = 5603861737310 := by decide
theorem cert_e1205815226206 : check e1205815226206 [[],[]] .smaller = true := by decide
def e1205815226234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1205815226234 : Closed e1205815226234 ∧ code e1205815226234 = 5603861737338 := by decide
theorem cert_e1205815226234 : check e1205815226234 [[],[]] .smaller = true := by decide
def e1205815226286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1205815226286 : Closed e1205815226286 ∧ code e1205815226286 = 5603861737390 := by decide
theorem cert_e1205815226286 : check e1205815226286 [[],[]] .smaller = true := by decide
def e1205815226298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1205815226298 : Closed e1205815226298 ∧ code e1205815226298 = 5603861737402 := by decide
theorem cert_e1205815226298 : check e1205815226298 [[],[]] .smaller = true := by decide
def e1205815227358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1205815227358 : Closed e1205815227358 ∧ code e1205815227358 = 5603861738462 := by decide
theorem cert_e1205815227358 : check e1205815227358 [[],[]] .smaller = true := by decide
def e1205815227374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1205815227374 : Closed e1205815227374 ∧ code e1205815227374 = 5603861738478 := by decide
theorem cert_e1205815227374 : check e1205815227374 [[],[]] .smaller = true := by decide
def e1205815229662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1205815229662 : Closed e1205815229662 ∧ code e1205815229662 = 5603861740766 := by decide
theorem cert_e1205815229662 : check e1205815229662 [[],[]] .smaller = true := by decide
def e1205815229690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e1205815229690 : Closed e1205815229690 ∧ code e1205815229690 = 5603861740794 := by decide
theorem cert_e1205815229690 : check e1205815229690 [[],[]] .smaller = true := by decide
def e1205815230062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205815230062 : Closed e1205815230062 ∧ code e1205815230062 = 5603861741166 := by decide
theorem cert_e1205815230062 : check e1205815230062 [[],[]] .smaller = true := by decide
def e1205815230074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205815230074 : Closed e1205815230074 ∧ code e1205815230074 = 5603861741178 := by decide
theorem cert_e1205815230074 : check e1205815230074 [[],[]] .smaller = true := by decide
def e1205815258478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1205815258478 : Closed e1205815258478 ∧ code e1205815258478 = 5603861769582 := by decide
theorem cert_e1205815258478 : check e1205815258478 [[],[]] .smaller = true := by decide
def e1205815258486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1205815258486 : Closed e1205815258486 ∧ code e1205815258486 = 5603861769590 := by decide
theorem cert_e1205815258486 : check e1205815258486 [[],[]] .smaller = true := by decide
def e1205815258542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1205815258542 : Closed e1205815258542 ∧ code e1205815258542 = 5603861769646 := by decide
theorem cert_e1205815258542 : check e1205815258542 [[],[]] .smaller = true := by decide
def e1205815258554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1205815258554 : Closed e1205815258554 ∧ code e1205815258554 = 5603861769658 := by decide
theorem cert_e1205815258554 : check e1205815258554 [[],[]] .smaller = true := by decide
def e1205815258582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1205815258582 : Closed e1205815258582 ∧ code e1205815258582 = 5603861769686 := by decide
theorem cert_e1205815258582 : check e1205815258582 [[],[]] .smaller = true := by decide
def e1205815258586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1205815258586 : Closed e1205815258586 ∧ code e1205815258586 = 5603861769690 := by decide
theorem cert_e1205815258586 : check e1205815258586 [[],[]] .smaller = true := by decide
def e1205815258798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1205815258798 : Closed e1205815258798 ∧ code e1205815258798 = 5603861769902 := by decide
theorem cert_e1205815258798 : check e1205815258798 [[],[]] .smaller = true := by decide
def e1205815258810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1205815258810 : Closed e1205815258810 ∧ code e1205815258810 = 5603861769914 := by decide
theorem cert_e1205815258810 : check e1205815258810 [[],[]] .smaller = true := by decide
def e1205815258858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1205815258858 : Closed e1205815258858 ∧ code e1205815258858 = 5603861769962 := by decide
theorem cert_e1205815258858 : check e1205815258858 [[],[]] .smaller = true := by decide
def e1205815258966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1205815258966 : Closed e1205815258966 ∧ code e1205815258966 = 5603861770070 := by decide
theorem cert_e1205815258966 : check e1205815258966 [[],[]] .smaller = true := by decide
def e1205815258970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1205815258970 : Closed e1205815258970 ∧ code e1205815258970 = 5603861770074 := by decide
theorem cert_e1205815258970 : check e1205815258970 [[],[]] .smaller = true := by decide
def e1205815258986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1205815258986 : Closed e1205815258986 ∧ code e1205815258986 = 5603861770090 := by decide
theorem cert_e1205815258986 : check e1205815258986 [[],[]] .smaller = true := by decide
def e1205815259614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e1205815259614 : Closed e1205815259614 ∧ code e1205815259614 = 5603861770718 := by decide
theorem cert_e1205815259614 : check e1205815259614 [[],[]] .chain = true := by decide
def e1205815259638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e1205815259638 : Closed e1205815259638 ∧ code e1205815259638 = 5603861770742 := by decide
theorem cert_e1205815259638 : check e1205815259638 [[],[]] .chain = true := by decide
def e1205815260014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1205815260014 : Closed e1205815260014 ∧ code e1205815260014 = 5603861771118 := by decide
theorem cert_e1205815260014 : check e1205815260014 [[],[]] .smaller = true := by decide
def e1205815260022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1205815260022 : Closed e1205815260022 ∧ code e1205815260022 = 5603861771126 := by decide
theorem cert_e1205815260022 : check e1205815260022 [[],[]] .smaller = true := by decide
def e1205815260078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1205815260078 : Closed e1205815260078 ∧ code e1205815260078 = 5603861771182 := by decide
theorem cert_e1205815260078 : check e1205815260078 [[],[]] .smaller = true := by decide
def e1205815260090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1205815260090 : Closed e1205815260090 ∧ code e1205815260090 = 5603861771194 := by decide
theorem cert_e1205815260090 : check e1205815260090 [[],[]] .smaller = true := by decide
def e1205815260118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1205815260118 : Closed e1205815260118 ∧ code e1205815260118 = 5603861771222 := by decide
theorem cert_e1205815260118 : check e1205815260118 [[],[]] .smaller = true := by decide
def e1205815260122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1205815260122 : Closed e1205815260122 ∧ code e1205815260122 = 5603861771226 := by decide
theorem cert_e1205815260122 : check e1205815260122 [[],[]] .smaller = true := by decide
def e1205815260398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205815260398 : Closed e1205815260398 ∧ code e1205815260398 = 5603861771502 := by decide
theorem cert_e1205815260398 : check e1205815260398 [[],[]] .smaller = true := by decide
def e1205815260406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205815260406 : Closed e1205815260406 ∧ code e1205815260406 = 5603861771510 := by decide
theorem cert_e1205815260406 : check e1205815260406 [[],[]] .smaller = true := by decide
def e1205815260734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e1205815260734 : Closed e1205815260734 ∧ code e1205815260734 = 5603861771838 := by decide
theorem cert_e1205815260734 : check e1205815260734 [[],[]] .chain = true := by decide
def e1205815260782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815260782 : Closed e1205815260782 ∧ code e1205815260782 = 5603861771886 := by decide
theorem cert_e1205815260782 : check e1205815260782 [[],[]] .smaller = true := by decide
def e1205815260794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815260794 : Closed e1205815260794 ∧ code e1205815260794 = 5603861771898 := by decide
theorem cert_e1205815260794 : check e1205815260794 [[],[]] .smaller = true := by decide
def e1205815260982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205815260982 : Closed e1205815260982 ∧ code e1205815260982 = 5603861772086 := by decide
theorem cert_e1205815260982 : check e1205815260982 [[],[]] .smaller = true := by decide
def e1205815260986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205815260986 : Closed e1205815260986 ∧ code e1205815260986 = 5603861772090 := by decide
theorem cert_e1205815260986 : check e1205815260986 [[],[]] .smaller = true := by decide
def e1205815261070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e1205815261070 : Closed e1205815261070 ∧ code e1205815261070 = 5603861772174 := by decide
theorem cert_e1205815261070 : check e1205815261070 [[],[]] .chain = true := by decide
def e1205815261406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e1205815261406 : Closed e1205815261406 ∧ code e1205815261406 = 5603861772510 := by decide
theorem cert_e1205815261406 : check e1205815261406 [[],[]] .chain = true := by decide
def e1205815261434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e1205815261434 : Closed e1205815261434 ∧ code e1205815261434 = 5603861772538 := by decide
theorem cert_e1205815261434 : check e1205815261434 [[],[]] .chain = true := by decide
def e1205815261614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1205815261614 : Closed e1205815261614 ∧ code e1205815261614 = 5603861772718 := by decide
theorem cert_e1205815261614 : check e1205815261614 [[],[]] .smaller = true := by decide
def e1205815261626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1205815261626 : Closed e1205815261626 ∧ code e1205815261626 = 5603861772730 := by decide
theorem cert_e1205815261626 : check e1205815261626 [[],[]] .smaller = true := by decide
def e1205815261674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1205815261674 : Closed e1205815261674 ∧ code e1205815261674 = 5603861772778 := by decide
theorem cert_e1205815261674 : check e1205815261674 [[],[]] .smaller = true := by decide
def e1205815261758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e1205815261758 : Closed e1205815261758 ∧ code e1205815261758 = 5603861772862 := by decide
theorem cert_e1205815261758 : check e1205815261758 [[],[]] .chain = true := by decide
def e1205815261806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205815261806 : Closed e1205815261806 ∧ code e1205815261806 = 5603861772910 := by decide
theorem cert_e1205815261806 : check e1205815261806 [[],[]] .smaller = true := by decide
def e1205815261818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205815261818 : Closed e1205815261818 ∧ code e1205815261818 = 5603861772922 := by decide
theorem cert_e1205815261818 : check e1205815261818 [[],[]] .smaller = true := by decide
def e1205815262106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815262106 : Closed e1205815262106 ∧ code e1205815262106 = 5603861773210 := by decide
theorem cert_e1205815262106 : check e1205815262106 [[],[]] .smaller = true := by decide
def e1205815262150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e1205815262150 : Closed e1205815262150 ∧ code e1205815262150 = 5603861773254 := by decide
theorem cert_e1205815262150 : check e1205815262150 [[],[]] .chain = true := by decide
def e1205815262422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1205815262422 : Closed e1205815262422 ∧ code e1205815262422 = 5603861773526 := by decide
theorem cert_e1205815262422 : check e1205815262422 [[],[]] .smaller = true := by decide
def e1205815262426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1205815262426 : Closed e1205815262426 ∧ code e1205815262426 = 5603861773530 := by decide
theorem cert_e1205815262426 : check e1205815262426 [[],[]] .smaller = true := by decide
def e1205815262442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1205815262442 : Closed e1205815262442 ∧ code e1205815262442 = 5603861773546 := by decide
theorem cert_e1205815262442 : check e1205815262442 [[],[]] .smaller = true := by decide
def e1205815262518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205815262518 : Closed e1205815262518 ∧ code e1205815262518 = 5603861773622 := by decide
theorem cert_e1205815262518 : check e1205815262518 [[],[]] .smaller = true := by decide
def e1205815262522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205815262522 : Closed e1205815262522 ∧ code e1205815262522 = 5603861773626 := by decide
theorem cert_e1205815262522 : check e1205815262522 [[],[]] .smaller = true := by decide
def e1205815262618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205815262618 : Closed e1205815262618 ∧ code e1205815262618 = 5603861773722 := by decide
theorem cert_e1205815262618 : check e1205815262618 [[],[]] .smaller = true := by decide
def e1205815262686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e1205815262686 : Closed e1205815262686 ∧ code e1205815262686 = 5603861773790 := by decide
theorem cert_e1205815262686 : check e1205815262686 [[],[]] .chain = true := by decide
def e1205815262702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e1205815262702 : Closed e1205815262702 ∧ code e1205815262702 = 5603861773806 := by decide
theorem cert_e1205815262702 : check e1205815262702 [[],[]] .chain = true := by decide
def e1205815262774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e1205815262774 : Closed e1205815262774 ∧ code e1205815262774 = 5603861773878 := by decide
theorem cert_e1205815262774 : check e1205815262774 [[],[]] .chain = true := by decide
def e1205815262778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e1205815262778 : Closed e1205815262778 ∧ code e1205815262778 = 5603861773882 := by decide
theorem cert_e1205815262778 : check e1205815262778 [[],[]] .chain = true := by decide
def e1205815262862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e1205815262862 : Closed e1205815262862 ∧ code e1205815262862 = 5603861773966 := by decide
theorem cert_e1205815262862 : check e1205815262862 [[],[]] .chain = true := by decide
def e1205815262918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e1205815262918 : Closed e1205815262918 ∧ code e1205815262918 = 5603861774022 := by decide
theorem cert_e1205815262918 : check e1205815262918 [[],[]] .chain = true := by decide
def e1205815262958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e1205815262958 : Closed e1205815262958 ∧ code e1205815262958 = 5603861774062 := by decide
theorem cert_e1205815262958 : check e1205815262958 [[],[]] .chain = true := by decide
def e1205815264222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e1205815264222 : Closed e1205815264222 ∧ code e1205815264222 = 5603861775326 := by decide
theorem cert_e1205815264222 : check e1205815264222 [[],[]] .smaller = true := by decide
def e1205815264238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e1205815264238 : Closed e1205815264238 ∧ code e1205815264238 = 5603861775342 := by decide
theorem cert_e1205815264238 : check e1205815264238 [[],[]] .smaller = true := by decide
def e1205815266158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e1205815266158 : Closed e1205815266158 ∧ code e1205815266158 = 5603861777262 := by decide
theorem cert_e1205815266158 : check e1205815266158 [[],[]] .smaller = true := by decide
def e1205815266166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e1205815266166 : Closed e1205815266166 ∧ code e1205815266166 = 5603861777270 := by decide
theorem cert_e1205815266166 : check e1205815266166 [[],[]] .smaller = true := by decide
def e1205815266222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e1205815266222 : Closed e1205815266222 ∧ code e1205815266222 = 5603861777326 := by decide
theorem cert_e1205815266222 : check e1205815266222 [[],[]] .smaller = true := by decide
def e1205815266234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e1205815266234 : Closed e1205815266234 ∧ code e1205815266234 = 5603861777338 := by decide
theorem cert_e1205815266234 : check e1205815266234 [[],[]] .smaller = true := by decide
def e1205815266262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e1205815266262 : Closed e1205815266262 ∧ code e1205815266262 = 5603861777366 := by decide
theorem cert_e1205815266262 : check e1205815266262 [[],[]] .smaller = true := by decide
def e1205815266266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e1205815266266 : Closed e1205815266266 ∧ code e1205815266266 = 5603861777370 := by decide
theorem cert_e1205815266266 : check e1205815266266 [[],[]] .smaller = true := by decide
def e1205815266542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e1205815266542 : Closed e1205815266542 ∧ code e1205815266542 = 5603861777646 := by decide
theorem cert_e1205815266542 : check e1205815266542 [[],[]] .smaller = true := by decide
def e1205815266550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e1205815266550 : Closed e1205815266550 ∧ code e1205815266550 = 5603861777654 := by decide
theorem cert_e1205815266550 : check e1205815266550 [[],[]] .smaller = true := by decide
def e1205815266878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e1205815266878 : Closed e1205815266878 ∧ code e1205815266878 = 5603861777982 := by decide
theorem cert_e1205815266878 : check e1205815266878 [[],[]] .chain = true := by decide
def e1205815266926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205815266926 : Closed e1205815266926 ∧ code e1205815266926 = 5603861778030 := by decide
theorem cert_e1205815266926 : check e1205815266926 [[],[]] .smaller = true := by decide
def e1205815266938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205815266938 : Closed e1205815266938 ∧ code e1205815266938 = 5603861778042 := by decide
theorem cert_e1205815266938 : check e1205815266938 [[],[]] .smaller = true := by decide
def e1205815267126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e1205815267126 : Closed e1205815267126 ∧ code e1205815267126 = 5603861778230 := by decide
theorem cert_e1205815267126 : check e1205815267126 [[],[]] .smaller = true := by decide
def e1205815267130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e1205815267130 : Closed e1205815267130 ∧ code e1205815267130 = 5603861778234 := by decide
theorem cert_e1205815267130 : check e1205815267130 [[],[]] .smaller = true := by decide
def e1205815267214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e1205815267214 : Closed e1205815267214 ∧ code e1205815267214 = 5603861778318 := by decide
theorem cert_e1205815267214 : check e1205815267214 [[],[]] .chain = true := by decide
def e1205815271902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e1205815271902 : Closed e1205815271902 ∧ code e1205815271902 = 5603861783006 := by decide
theorem cert_e1205815271902 : check e1205815271902 [[],[]] .smaller = true := by decide
def e1205815271926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e1205815271926 : Closed e1205815271926 ∧ code e1205815271926 = 5603861783030 := by decide
theorem cert_e1205815271926 : check e1205815271926 [[],[]] .smaller = true := by decide
def e1205815272878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e1205815272878 : Closed e1205815272878 ∧ code e1205815272878 = 5603861783982 := by decide
theorem cert_e1205815272878 : check e1205815272878 [[],[]] .smaller = true := by decide
def e1205815272890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e1205815272890 : Closed e1205815272890 ∧ code e1205815272890 = 5603861783994 := by decide
theorem cert_e1205815272890 : check e1205815272890 [[],[]] .smaller = true := by decide
def e1205815272938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e1205815272938 : Closed e1205815272938 ∧ code e1205815272938 = 5603861784042 := by decide
theorem cert_e1205815272938 : check e1205815272938 [[],[]] .smaller = true := by decide
def e1205815273022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e1205815273022 : Closed e1205815273022 ∧ code e1205815273022 = 5603861784126 := by decide
theorem cert_e1205815273022 : check e1205815273022 [[],[]] .chain = true := by decide
def e1205815273070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e1205815273070 : Closed e1205815273070 ∧ code e1205815273070 = 5603861784174 := by decide
theorem cert_e1205815273070 : check e1205815273070 [[],[]] .smaller = true := by decide
def e1205815273082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e1205815273082 : Closed e1205815273082 ∧ code e1205815273082 = 5603861784186 := by decide
theorem cert_e1205815273082 : check e1205815273082 [[],[]] .smaller = true := by decide
def e1205815273370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e1205815273370 : Closed e1205815273370 ∧ code e1205815273370 = 5603861784474 := by decide
theorem cert_e1205815273370 : check e1205815273370 [[],[]] .smaller = true := by decide
def e1205815273414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e1205815273414 : Closed e1205815273414 ∧ code e1205815273414 = 5603861784518 := by decide
theorem cert_e1205815273414 : check e1205815273414 [[],[]] .chain = true := by decide
def e1205815275758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e1205815275758 : Closed e1205815275758 ∧ code e1205815275758 = 5603861786862 := by decide
theorem cert_e1205815275758 : check e1205815275758 [[],[]] .smaller = true := by decide
def e1205815275766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e1205815275766 : Closed e1205815275766 ∧ code e1205815275766 = 5603861786870 := by decide
theorem cert_e1205815275766 : check e1205815275766 [[],[]] .smaller = true := by decide
def e1205815276246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e1205815276246 : Closed e1205815276246 ∧ code e1205815276246 = 5603861787350 := by decide
theorem cert_e1205815276246 : check e1205815276246 [[],[]] .smaller = true := by decide
end Blc.Floor42
