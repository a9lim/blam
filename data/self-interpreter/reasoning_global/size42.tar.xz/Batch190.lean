import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1211203746586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e1211203746586 : Closed e1211203746586 ∧ code e1211203746586 = 5609250257690 := by decide
theorem cert_e1211203746586 : check e1211203746586 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203746630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e1211203746630 : Closed e1211203746630 ∧ code e1211203746630 = 5609250257734 := by decide
theorem cert_e1211203746630 : check e1211203746630 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203748086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e1211203748086 : Closed e1211203748086 ∧ code e1211203748086 = 5609250259190 := by decide
theorem cert_e1211203748086 : check e1211203748086 [[],[]] .chain = true := by decide
def e1211203748090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e1211203748090 : Closed e1211203748090 ∧ code e1211203748090 = 5609250259194 := by decide
theorem cert_e1211203748090 : check e1211203748090 [[],[]] .chain = true := by decide
def e1211203748470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203748470 : Closed e1211203748470 ∧ code e1211203748470 = 5609250259574 := by decide
theorem cert_e1211203748470 : check e1211203748470 [[],[]] .chain = true := by decide
def e1211203748662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203748662 : Closed e1211203748662 ∧ code e1211203748662 = 5609250259766 := by decide
theorem cert_e1211203748662 : check e1211203748662 [[],[]] .chain = true := by decide
def e1211203748666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203748666 : Closed e1211203748666 ∧ code e1211203748666 = 5609250259770 := by decide
theorem cert_e1211203748666 : check e1211203748666 [[],[]] .chain = true := by decide
def e1211203748750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e1211203748750 : Closed e1211203748750 ∧ code e1211203748750 = 5609250259854 := by decide
theorem cert_e1211203748750 : check e1211203748750 [[],[]] .chain = true := by decide
def e1211203748806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e1211203748806 : Closed e1211203748806 ∧ code e1211203748806 = 5609250259910 := by decide
theorem cert_e1211203748806 : check e1211203748806 [[],[]] .chain = true := by decide
def e1211203749430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211203749430 : Closed e1211203749430 ∧ code e1211203749430 = 5609250260534 := by decide
theorem cert_e1211203749430 : check e1211203749430 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203749518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211203749518 : Closed e1211203749518 ∧ code e1211203749518 = 5609250260622 := by decide
theorem cert_e1211203749518 : check e1211203749518 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203749614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e1211203749614 : Closed e1211203749614 ∧ code e1211203749614 = 5609250260718 := by decide
theorem cert_e1211203749614 : check e1211203749614 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203749622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e1211203749622 : Closed e1211203749622 ∧ code e1211203749622 = 5609250260726 := by decide
theorem cert_e1211203749622 : check e1211203749622 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203749654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203749654 : Closed e1211203749654 ∧ code e1211203749654 = 5609250260758 := by decide
theorem cert_e1211203749654 : check e1211203749654 [[],[]] .chain = true := by decide
def e1211203749750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e1211203749750 : Closed e1211203749750 ∧ code e1211203749750 = 5609250260854 := by decide
theorem cert_e1211203749750 : check e1211203749750 [[],[]] .chain = true := by decide
def e1211203749770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203749770 : Closed e1211203749770 ∧ code e1211203749770 = 5609250260874 := by decide
theorem cert_e1211203749770 : check e1211203749770 [[],[]] .chain = true := by decide
def e1211203749806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e1211203749806 : Closed e1211203749806 ∧ code e1211203749806 = 5609250260910 := by decide
theorem cert_e1211203749806 : check e1211203749806 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203749814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e1211203749814 : Closed e1211203749814 ∧ code e1211203749814 = 5609250260918 := by decide
theorem cert_e1211203749814 : check e1211203749814 [[],[]] .chain = true := by decide
def e1211203749818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e1211203749818 : Closed e1211203749818 ∧ code e1211203749818 = 5609250260922 := by decide
theorem cert_e1211203749818 : check e1211203749818 [[],[]] .chain = true := by decide
def e1211203749846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e1211203749846 : Closed e1211203749846 ∧ code e1211203749846 = 5609250260950 := by decide
theorem cert_e1211203749846 : check e1211203749846 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203750286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203750286 : Closed e1211203750286 ∧ code e1211203750286 = 5609250261390 := by decide
theorem cert_e1211203750286 : check e1211203750286 [[],[]] .chain = true := by decide
def e1211203750342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203750342 : Closed e1211203750342 ∧ code e1211203750342 = 5609250261446 := by decide
theorem cert_e1211203750342 : check e1211203750342 [[],[]] .chain = true := by decide
def e1211203750942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e1211203750942 : Closed e1211203750942 ∧ code e1211203750942 = 5609250262046 := by decide
theorem cert_e1211203750942 : check e1211203750942 [[],[]] .chain = true := by decide
def e1211203751138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e1211203751138 : Closed e1211203751138 ∧ code e1211203751138 = 5609250262242 := by decide
theorem cert_e1211203751138 : check e1211203751138 [[],[]] .chain = true := by decide
def e1211203751150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e1211203751150 : Closed e1211203751150 ∧ code e1211203751150 = 5609250262254 := by decide
theorem cert_e1211203751150 : check e1211203751150 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203751158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e1211203751158 : Closed e1211203751158 ∧ code e1211203751158 = 5609250262262 := by decide
theorem cert_e1211203751158 : check e1211203751158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211203751438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e1211203751438 : Closed e1211203751438 ∧ code e1211203751438 = 5609250262542 := by decide
theorem cert_e1211203751438 : check e1211203751438 [[],[]] .chain = true := by decide
def e1211203751450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203751450 : Closed e1211203751450 ∧ code e1211203751450 = 5609250262554 := by decide
theorem cert_e1211203751450 : check e1211203751450 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203751522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203751522 : Closed e1211203751522 ∧ code e1211203751522 = 5609250262626 := by decide
theorem cert_e1211203751522 : check e1211203751522 [[],[]] .chain = true := by decide
def e1211203751534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203751534 : Closed e1211203751534 ∧ code e1211203751534 = 5609250262638 := by decide
theorem cert_e1211203751534 : check e1211203751534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e1211203751542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203751542 : Closed e1211203751542 ∧ code e1211203751542 = 5609250262646 := by decide
theorem cert_e1211203751542 : check e1211203751542 [[],[]] .chain = true := by decide
def e1211203751546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203751546 : Closed e1211203751546 ∧ code e1211203751546 = 5609250262650 := by decide
theorem cert_e1211203751546 : check e1211203751546 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203751734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203751734 : Closed e1211203751734 ∧ code e1211203751734 = 5609250262838 := by decide
theorem cert_e1211203751734 : check e1211203751734 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203751738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203751738 : Closed e1211203751738 ∧ code e1211203751738 = 5609250262842 := by decide
theorem cert_e1211203751738 : check e1211203751738 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203753654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e1211203753654 : Closed e1211203753654 ∧ code e1211203753654 = 5609250264758 := by decide
theorem cert_e1211203753654 : check e1211203753654 [[],[]] .chain = true := by decide
def e1211203753686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e1211203753686 : Closed e1211203753686 ∧ code e1211203753686 = 5609250264790 := by decide
theorem cert_e1211203753686 : check e1211203753686 [[],[]] .chain = true := by decide
def e1211203753690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e1211203753690 : Closed e1211203753690 ∧ code e1211203753690 = 5609250264794 := by decide
theorem cert_e1211203753690 : check e1211203753690 [[],[]] .chain = true := by decide
def e1211203753814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211203753814 : Closed e1211203753814 ∧ code e1211203753814 = 5609250264918 := by decide
theorem cert_e1211203753814 : check e1211203753814 [[],[]] .chain = true := by decide
def e1211203753818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211203753818 : Closed e1211203753818 ∧ code e1211203753818 = 5609250264922 := by decide
theorem cert_e1211203753818 : check e1211203753818 [[],[]] .chain = true := by decide
def e1211203753834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211203753834 : Closed e1211203753834 ∧ code e1211203753834 = 5609250264938 := by decide
theorem cert_e1211203753834 : check e1211203753834 [[],[]] .chain = true := by decide
def e1211203754038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e1211203754038 : Closed e1211203754038 ∧ code e1211203754038 = 5609250265142 := by decide
theorem cert_e1211203754038 : check e1211203754038 [[],[]] .chain = true := by decide
def e1211203754126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e1211203754126 : Closed e1211203754126 ∧ code e1211203754126 = 5609250265230 := by decide
theorem cert_e1211203754126 : check e1211203754126 [[],[]] .chain = true := by decide
def e1211203754210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e1211203754210 : Closed e1211203754210 ∧ code e1211203754210 = 5609250265314 := by decide
theorem cert_e1211203754210 : check e1211203754210 [[],[]] .chain = true := by decide
def e1211203754222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e1211203754222 : Closed e1211203754222 ∧ code e1211203754222 = 5609250265326 := by decide
theorem cert_e1211203754222 : check e1211203754222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e1211203754230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e1211203754230 : Closed e1211203754230 ∧ code e1211203754230 = 5609250265334 := by decide
theorem cert_e1211203754230 : check e1211203754230 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203754422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e1211203754422 : Closed e1211203754422 ∧ code e1211203754422 = 5609250265526 := by decide
theorem cert_e1211203754422 : check e1211203754422 [[],[]] .chain = true := by decide
def e1211203754454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e1211203754454 : Closed e1211203754454 ∧ code e1211203754454 = 5609250265558 := by decide
theorem cert_e1211203754454 : check e1211203754454 [[],[]] .chain = true := by decide
def e1211203754458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e1211203754458 : Closed e1211203754458 ∧ code e1211203754458 = 5609250265562 := by decide
theorem cert_e1211203754458 : check e1211203754458 [[],[]] .chain = true := by decide
def e1211203754614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203754614 : Closed e1211203754614 ∧ code e1211203754614 = 5609250265718 := by decide
theorem cert_e1211203754614 : check e1211203754614 [[],[]] .chain = true := by decide
def e1211203754758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203754758 : Closed e1211203754758 ∧ code e1211203754758 = 5609250265862 := by decide
theorem cert_e1211203754758 : check e1211203754758 [[],[]] .chain = true := by decide
def e1211203754782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e1211203754782 : Closed e1211203754782 ∧ code e1211203754782 = 5609250265886 := by decide
theorem cert_e1211203754782 : check e1211203754782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203754806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203754806 : Closed e1211203754806 ∧ code e1211203754806 = 5609250265910 := by decide
theorem cert_e1211203754806 : check e1211203754806 [[],[]] .chain = true := by decide
def e1211203754810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203754810 : Closed e1211203754810 ∧ code e1211203754810 = 5609250265914 := by decide
theorem cert_e1211203754810 : check e1211203754810 [[],[]] .chain = true := by decide
def e1211203754894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e1211203754894 : Closed e1211203754894 ∧ code e1211203754894 = 5609250265998 := by decide
theorem cert_e1211203754894 : check e1211203754894 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203755030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203755030 : Closed e1211203755030 ∧ code e1211203755030 = 5609250266134 := by decide
theorem cert_e1211203755030 : check e1211203755030 [[],[]] .chain = true := by decide
def e1211203755034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203755034 : Closed e1211203755034 ∧ code e1211203755034 = 5609250266138 := by decide
theorem cert_e1211203755034 : check e1211203755034 [[],[]] .chain = true := by decide
def e1211203755078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203755078 : Closed e1211203755078 ∧ code e1211203755078 = 5609250266182 := by decide
theorem cert_e1211203755078 : check e1211203755078 [[],[]] .chain = true := by decide
def e1211203755106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203755106 : Closed e1211203755106 ∧ code e1211203755106 = 5609250266210 := by decide
theorem cert_e1211203755106 : check e1211203755106 [[],[]] .chain = true := by decide
def e1211203755118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203755118 : Closed e1211203755118 ∧ code e1211203755118 = 5609250266222 := by decide
theorem cert_e1211203755118 : check e1211203755118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e1211203755126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203755126 : Closed e1211203755126 ∧ code e1211203755126 = 5609250266230 := by decide
theorem cert_e1211203755126 : check e1211203755126 [[],[]] .chain = true := by decide
def e1211203755130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203755130 : Closed e1211203755130 ∧ code e1211203755130 = 5609250266234 := by decide
theorem cert_e1211203755130 : check e1211203755130 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203755222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203755222 : Closed e1211203755222 ∧ code e1211203755222 = 5609250266326 := by decide
theorem cert_e1211203755222 : check e1211203755222 [[],[]] .chain = true := by decide
def e1211203755226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211203755226 : Closed e1211203755226 ∧ code e1211203755226 = 5609250266330 := by decide
theorem cert_e1211203755226 : check e1211203755226 [[],[]] .chain = true := by decide
def e1211203755242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211203755242 : Closed e1211203755242 ∧ code e1211203755242 = 5609250266346 := by decide
theorem cert_e1211203755242 : check e1211203755242 [[],[]] .chain = true := by decide
def e1211203755270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203755270 : Closed e1211203755270 ∧ code e1211203755270 = 5609250266374 := by decide
theorem cert_e1211203755270 : check e1211203755270 [[],[]] .chain = true := by decide
def e1211203755294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203755294 : Closed e1211203755294 ∧ code e1211203755294 = 5609250266398 := by decide
theorem cert_e1211203755294 : check e1211203755294 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203755318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203755318 : Closed e1211203755318 ∧ code e1211203755318 = 5609250266422 := by decide
theorem cert_e1211203755318 : check e1211203755318 [[],[]] .chain = true := by decide
def e1211203755322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203755322 : Closed e1211203755322 ∧ code e1211203755322 = 5609250266426 := by decide
theorem cert_e1211203755322 : check e1211203755322 [[],[]] .chain = true := by decide
def e1211203755394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203755394 : Closed e1211203755394 ∧ code e1211203755394 = 5609250266498 := by decide
theorem cert_e1211203755394 : check e1211203755394 [[],[]] .chain = true := by decide
def e1211203755406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203755406 : Closed e1211203755406 ∧ code e1211203755406 = 5609250266510 := by decide
theorem cert_e1211203755406 : check e1211203755406 [[],[]] .chain = true := by decide
def e1211203755418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203755418 : Closed e1211203755418 ∧ code e1211203755418 = 5609250266522 := by decide
theorem cert_e1211203755418 : check e1211203755418 [[],[]] .chain = true := by decide
def e1211203755462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203755462 : Closed e1211203755462 ∧ code e1211203755462 = 5609250266566 := by decide
theorem cert_e1211203755462 : check e1211203755462 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203755574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203755574 : Closed e1211203755574 ∧ code e1211203755574 = 5609250266678 := by decide
theorem cert_e1211203755574 : check e1211203755574 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203755578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203755578 : Closed e1211203755578 ∧ code e1211203755578 = 5609250266682 := by decide
theorem cert_e1211203755578 : check e1211203755578 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203755662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e1211203755662 : Closed e1211203755662 ∧ code e1211203755662 = 5609250266766 := by decide
theorem cert_e1211203755662 : check e1211203755662 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203755718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e1211203755718 : Closed e1211203755718 ∧ code e1211203755718 = 5609250266822 := by decide
theorem cert_e1211203755718 : check e1211203755718 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203756094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e1211203756094 : Closed e1211203756094 ∧ code e1211203756094 = 5609250267198 := by decide
theorem cert_e1211203756094 : check e1211203756094 [[],[]] .chain = true := by decide
def e1211203756514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e1211203756514 : Closed e1211203756514 ∧ code e1211203756514 = 5609250267618 := by decide
theorem cert_e1211203756514 : check e1211203756514 [[],[]] .chain = true := by decide
def e1211203756526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e1211203756526 : Closed e1211203756526 ∧ code e1211203756526 = 5609250267630 := by decide
theorem cert_e1211203756526 : check e1211203756526 [[],[]] .chain = true := by decide
def e1211203757494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1211203757494 : Closed e1211203757494 ∧ code e1211203757494 = 5609250268598 := by decide
theorem cert_e1211203757494 : check e1211203757494 [[],[]] .chain = true := by decide
def e1211203757526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1211203757526 : Closed e1211203757526 ∧ code e1211203757526 = 5609250268630 := by decide
theorem cert_e1211203757526 : check e1211203757526 [[],[]] .chain = true := by decide
def e1211203757530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1211203757530 : Closed e1211203757530 ∧ code e1211203757530 = 5609250268634 := by decide
theorem cert_e1211203757530 : check e1211203757530 [[],[]] .chain = true := by decide
def e1211203757686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1211203757686 : Closed e1211203757686 ∧ code e1211203757686 = 5609250268790 := by decide
theorem cert_e1211203757686 : check e1211203757686 [[],[]] .chain = true := by decide
def e1211203757830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203757830 : Closed e1211203757830 ∧ code e1211203757830 = 5609250268934 := by decide
theorem cert_e1211203757830 : check e1211203757830 [[],[]] .chain = true := by decide
def e1211203757854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e1211203757854 : Closed e1211203757854 ∧ code e1211203757854 = 5609250268958 := by decide
theorem cert_e1211203757854 : check e1211203757854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e1211203757878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203757878 : Closed e1211203757878 ∧ code e1211203757878 = 5609250268982 := by decide
theorem cert_e1211203757878 : check e1211203757878 [[],[]] .chain = true := by decide
def e1211203757882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203757882 : Closed e1211203757882 ∧ code e1211203757882 = 5609250268986 := by decide
theorem cert_e1211203757882 : check e1211203757882 [[],[]] .chain = true := by decide
def e1211203757966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e1211203757966 : Closed e1211203757966 ∧ code e1211203757966 = 5609250269070 := by decide
theorem cert_e1211203757966 : check e1211203757966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e1211203760158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e1211203760158 : Closed e1211203760158 ∧ code e1211203760158 = 5609250271262 := by decide
theorem cert_e1211203760158 : check e1211203760158 [[],[]] .chain = true := by decide
def e1211203760326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e1211203760326 : Closed e1211203760326 ∧ code e1211203760326 = 5609250271430 := by decide
theorem cert_e1211203760326 : check e1211203760326 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203760350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e1211203760350 : Closed e1211203760350 ∧ code e1211203760350 = 5609250271454 := by decide
theorem cert_e1211203760350 : check e1211203760350 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203760354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e1211203760354 : Closed e1211203760354 ∧ code e1211203760354 = 5609250271458 := by decide
theorem cert_e1211203760354 : check e1211203760354 [[],[]] .chain = true := by decide
def e1211203760366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e1211203760366 : Closed e1211203760366 ∧ code e1211203760366 = 5609250271470 := by decide
theorem cert_e1211203760366 : check e1211203760366 [[],[]] .chain = true := by decide
def e1211203760374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e1211203760374 : Closed e1211203760374 ∧ code e1211203760374 = 5609250271478 := by decide
theorem cert_e1211203760374 : check e1211203760374 [[],[]] .chain = true := by decide
def e1211203760378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e1211203760378 : Closed e1211203760378 ∧ code e1211203760378 = 5609250271482 := by decide
theorem cert_e1211203760378 : check e1211203760378 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203760854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e1211203760854 : Closed e1211203760854 ∧ code e1211203760854 = 5609250271958 := by decide
theorem cert_e1211203760854 : check e1211203760854 [[],[]] .chain = true := by decide
def e1211203760858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e1211203760858 : Closed e1211203760858 ∧ code e1211203760858 = 5609250271962 := by decide
theorem cert_e1211203760858 : check e1211203760858 [[],[]] .chain = true := by decide
def e1211203760874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e1211203760874 : Closed e1211203760874 ∧ code e1211203760874 = 5609250271978 := by decide
theorem cert_e1211203760874 : check e1211203760874 [[],[]] .chain = true := by decide
def e1211203760902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e1211203760902 : Closed e1211203760902 ∧ code e1211203760902 = 5609250272006 := by decide
theorem cert_e1211203760902 : check e1211203760902 [[],[]] .chain = true := by decide
def e1211203760926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e1211203760926 : Closed e1211203760926 ∧ code e1211203760926 = 5609250272030 := by decide
theorem cert_e1211203760926 : check e1211203760926 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e1211203760950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e1211203760950 : Closed e1211203760950 ∧ code e1211203760950 = 5609250272054 := by decide
theorem cert_e1211203760950 : check e1211203760950 [[],[]] .chain = true := by decide
def e1211203760954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e1211203760954 : Closed e1211203760954 ∧ code e1211203760954 = 5609250272058 := by decide
theorem cert_e1211203760954 : check e1211203760954 [[],[]] .chain = true := by decide
def e1211203761026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e1211203761026 : Closed e1211203761026 ∧ code e1211203761026 = 5609250272130 := by decide
theorem cert_e1211203761026 : check e1211203761026 [[],[]] .chain = true := by decide
def e1211203761038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e1211203761038 : Closed e1211203761038 ∧ code e1211203761038 = 5609250272142 := by decide
theorem cert_e1211203761038 : check e1211203761038 [[],[]] .chain = true := by decide
def e1211203761050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e1211203761050 : Closed e1211203761050 ∧ code e1211203761050 = 5609250272154 := by decide
theorem cert_e1211203761050 : check e1211203761050 [[],[]] .chain = true := by decide
def e1211203761094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e1211203761094 : Closed e1211203761094 ∧ code e1211203761094 = 5609250272198 := by decide
theorem cert_e1211203761094 : check e1211203761094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e1211203762286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e1211203762286 : Closed e1211203762286 ∧ code e1211203762286 = 5609250273390 := by decide
theorem cert_e1211203762286 : check e1211203762286 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203762298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e1211203762298 : Closed e1211203762298 ∧ code e1211203762298 = 5609250273402 := by decide
theorem cert_e1211203762298 : check e1211203762298 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203762574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e1211203762574 : Closed e1211203762574 ∧ code e1211203762574 = 5609250273678 := by decide
theorem cert_e1211203762574 : check e1211203762574 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203762630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e1211203762630 : Closed e1211203762630 ∧ code e1211203762630 = 5609250273734 := by decide
theorem cert_e1211203762630 : check e1211203762630 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203764346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e1211203764346 : Closed e1211203764346 ∧ code e1211203764346 = 5609250275450 := by decide
theorem cert_e1211203764346 : check e1211203764346 [[],[]] .chain = true := by decide
def e1211203764534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203764534 : Closed e1211203764534 ∧ code e1211203764534 = 5609250275638 := by decide
theorem cert_e1211203764534 : check e1211203764534 [[],[]] .chain = true := by decide
def e1211203764538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203764538 : Closed e1211203764538 ∧ code e1211203764538 = 5609250275642 := by decide
theorem cert_e1211203764538 : check e1211203764538 [[],[]] .chain = true := by decide
def e1211203764634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203764634 : Closed e1211203764634 ∧ code e1211203764634 = 5609250275738 := by decide
theorem cert_e1211203764634 : check e1211203764634 [[],[]] .chain = true := by decide
def e1211203764678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e1211203764678 : Closed e1211203764678 ∧ code e1211203764678 = 5609250275782 := by decide
theorem cert_e1211203764678 : check e1211203764678 [[],[]] .chain = true := by decide
def e1211203765018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203765018 : Closed e1211203765018 ∧ code e1211203765018 = 5609250276122 := by decide
theorem cert_e1211203765018 : check e1211203765018 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203765062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203765062 : Closed e1211203765062 ∧ code e1211203765062 = 5609250276166 := by decide
theorem cert_e1211203765062 : check e1211203765062 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203765102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e1211203765102 : Closed e1211203765102 ∧ code e1211203765102 = 5609250276206 := by decide
theorem cert_e1211203765102 : check e1211203765102 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203765114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e1211203765114 : Closed e1211203765114 ∧ code e1211203765114 = 5609250276218 := by decide
theorem cert_e1211203765114 : check e1211203765114 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203765130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203765130 : Closed e1211203765130 ∧ code e1211203765130 = 5609250276234 := by decide
theorem cert_e1211203765130 : check e1211203765130 [[],[]] .chain = true := by decide
def e1211203765166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e1211203765166 : Closed e1211203765166 ∧ code e1211203765166 = 5609250276270 := by decide
theorem cert_e1211203765166 : check e1211203765166 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203765174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e1211203765174 : Closed e1211203765174 ∧ code e1211203765174 = 5609250276278 := by decide
theorem cert_e1211203765174 : check e1211203765174 [[],[]] .chain = true := by decide
def e1211203765178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e1211203765178 : Closed e1211203765178 ∧ code e1211203765178 = 5609250276282 := by decide
theorem cert_e1211203765178 : check e1211203765178 [[],[]] .chain = true := by decide
def e1211203765210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e1211203765210 : Closed e1211203765210 ∧ code e1211203765210 = 5609250276314 := by decide
theorem cert_e1211203765210 : check e1211203765210 [[],[]] .chain = true := by decide
def e1211203765226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e1211203765226 : Closed e1211203765226 ∧ code e1211203765226 = 5609250276330 := by decide
theorem cert_e1211203765226 : check e1211203765226 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e1211203765446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e1211203765446 : Closed e1211203765446 ∧ code e1211203765446 = 5609250276550 := by decide
theorem cert_e1211203765446 : check e1211203765446 [[],[]] .chain = true := by decide
def e1211203765774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e1211203765774 : Closed e1211203765774 ∧ code e1211203765774 = 5609250276878 := by decide
theorem cert_e1211203765774 : check e1211203765774 [[],[]] .chain = true := by decide
def e1211203765786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e1211203765786 : Closed e1211203765786 ∧ code e1211203765786 = 5609250276890 := by decide
theorem cert_e1211203765786 : check e1211203765786 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e1211203765858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e1211203765858 : Closed e1211203765858 ∧ code e1211203765858 = 5609250276962 := by decide
theorem cert_e1211203765858 : check e1211203765858 [[],[]] .chain = true := by decide
def e1211203765870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e1211203765870 : Closed e1211203765870 ∧ code e1211203765870 = 5609250276974 := by decide
theorem cert_e1211203765870 : check e1211203765870 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203765878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e1211203765878 : Closed e1211203765878 ∧ code e1211203765878 = 5609250276982 := by decide
theorem cert_e1211203765878 : check e1211203765878 [[],[]] .chain = true := by decide
def e1211203765882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e1211203765882 : Closed e1211203765882 ∧ code e1211203765882 = 5609250276986 := by decide
theorem cert_e1211203765882 : check e1211203765882 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203766070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203766070 : Closed e1211203766070 ∧ code e1211203766070 = 5609250277174 := by decide
theorem cert_e1211203766070 : check e1211203766070 [[],[]] .chain = true := by decide
def e1211203766074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203766074 : Closed e1211203766074 ∧ code e1211203766074 = 5609250277178 := by decide
theorem cert_e1211203766074 : check e1211203766074 [[],[]] .chain = true := by decide
def e1211203766170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203766170 : Closed e1211203766170 ∧ code e1211203766170 = 5609250277274 := by decide
theorem cert_e1211203766170 : check e1211203766170 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203767126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e1211203767126 : Closed e1211203767126 ∧ code e1211203767126 = 5609250278230 := by decide
theorem cert_e1211203767126 : check e1211203767126 [[],[]] .chain = true := by decide
def e1211203767130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e1211203767130 : Closed e1211203767130 ∧ code e1211203767130 = 5609250278234 := by decide
theorem cert_e1211203767130 : check e1211203767130 [[],[]] .chain = true := by decide
def e1211203767146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e1211203767146 : Closed e1211203767146 ∧ code e1211203767146 = 5609250278250 := by decide
theorem cert_e1211203767146 : check e1211203767146 [[],[]] .chain = true := by decide
def e1211203767210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e1211203767210 : Closed e1211203767210 ∧ code e1211203767210 = 5609250278314 := by decide
theorem cert_e1211203767210 : check e1211203767210 [[],[]] .chain = true := by decide
def e1211203767318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e1211203767318 : Closed e1211203767318 ∧ code e1211203767318 = 5609250278422 := by decide
theorem cert_e1211203767318 : check e1211203767318 [[],[]] .chain = true := by decide
def e1211203767322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e1211203767322 : Closed e1211203767322 ∧ code e1211203767322 = 5609250278426 := by decide
theorem cert_e1211203767322 : check e1211203767322 [[],[]] .chain = true := by decide
def e1211203767366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e1211203767366 : Closed e1211203767366 ∧ code e1211203767366 = 5609250278470 := by decide
theorem cert_e1211203767366 : check e1211203767366 [[],[]] .chain = true := by decide
def e1211203767394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e1211203767394 : Closed e1211203767394 ∧ code e1211203767394 = 5609250278498 := by decide
theorem cert_e1211203767394 : check e1211203767394 [[],[]] .chain = true := by decide
def e1211203767406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e1211203767406 : Closed e1211203767406 ∧ code e1211203767406 = 5609250278510 := by decide
theorem cert_e1211203767406 : check e1211203767406 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203767414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e1211203767414 : Closed e1211203767414 ∧ code e1211203767414 = 5609250278518 := by decide
theorem cert_e1211203767414 : check e1211203767414 [[],[]] .chain = true := by decide
def e1211203767418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e1211203767418 : Closed e1211203767418 ∧ code e1211203767418 = 5609250278522 := by decide
theorem cert_e1211203767418 : check e1211203767418 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203767510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e1211203767510 : Closed e1211203767510 ∧ code e1211203767510 = 5609250278614 := by decide
theorem cert_e1211203767510 : check e1211203767510 [[],[]] .chain = true := by decide
def e1211203767514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e1211203767514 : Closed e1211203767514 ∧ code e1211203767514 = 5609250278618 := by decide
theorem cert_e1211203767514 : check e1211203767514 [[],[]] .chain = true := by decide
def e1211203767530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e1211203767530 : Closed e1211203767530 ∧ code e1211203767530 = 5609250278634 := by decide
theorem cert_e1211203767530 : check e1211203767530 [[],[]] .chain = true := by decide
def e1211203767558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e1211203767558 : Closed e1211203767558 ∧ code e1211203767558 = 5609250278662 := by decide
theorem cert_e1211203767558 : check e1211203767558 [[],[]] .chain = true := by decide
def e1211203767582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e1211203767582 : Closed e1211203767582 ∧ code e1211203767582 = 5609250278686 := by decide
theorem cert_e1211203767582 : check e1211203767582 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e1211203767606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e1211203767606 : Closed e1211203767606 ∧ code e1211203767606 = 5609250278710 := by decide
theorem cert_e1211203767606 : check e1211203767606 [[],[]] .chain = true := by decide
def e1211203767610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e1211203767610 : Closed e1211203767610 ∧ code e1211203767610 = 5609250278714 := by decide
theorem cert_e1211203767610 : check e1211203767610 [[],[]] .chain = true := by decide
def e1211203767682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e1211203767682 : Closed e1211203767682 ∧ code e1211203767682 = 5609250278786 := by decide
theorem cert_e1211203767682 : check e1211203767682 [[],[]] .chain = true := by decide
def e1211203767694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e1211203767694 : Closed e1211203767694 ∧ code e1211203767694 = 5609250278798 := by decide
theorem cert_e1211203767694 : check e1211203767694 [[],[]] .chain = true := by decide
def e1211203767706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e1211203767706 : Closed e1211203767706 ∧ code e1211203767706 = 5609250278810 := by decide
theorem cert_e1211203767706 : check e1211203767706 [[],[]] .chain = true := by decide
def e1211203767750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e1211203767750 : Closed e1211203767750 ∧ code e1211203767750 = 5609250278854 := by decide
theorem cert_e1211203767750 : check e1211203767750 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e1211203767818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e1211203767818 : Closed e1211203767818 ∧ code e1211203767818 = 5609250278922 := by decide
theorem cert_e1211203767818 : check e1211203767818 [[],[]] .chain = true := by decide
def e1211203767862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e1211203767862 : Closed e1211203767862 ∧ code e1211203767862 = 5609250278966 := by decide
theorem cert_e1211203767862 : check e1211203767862 [[],[]] .chain = true := by decide
def e1211203767866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e1211203767866 : Closed e1211203767866 ∧ code e1211203767866 = 5609250278970 := by decide
theorem cert_e1211203767866 : check e1211203767866 [[],[]] .chain = true := by decide
end Blc.Floor42
