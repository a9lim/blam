import Tables
import Batch045
namespace Blc.Floor42.Grades045
open Grades
open Term SelfintLowerBound SelfintControl ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 5000000
theorem ex_e1124661463982 : ¬ IsSelfInterpreter e1124661463982 := cutM2_0 (by decide)
#print axioms ex_e1124661463982
theorem ex_e1124661463918 : ¬ IsSelfInterpreter e1124661463918 := cutM3_0 (by decide)
#print axioms ex_e1124661463918
theorem ex_e1124661463926 : ¬ IsSelfInterpreter e1124661463926 := cutM3_0 (by decide)
#print axioms ex_e1124661463926
theorem ex_e1124660719034 : ¬ IsSelfInterpreter e1124660719034 := cutM6_2 (by decide)
#print axioms ex_e1124660719034
theorem ex_e1124660719066 : ¬ IsSelfInterpreter e1124660719066 := cutM6_2 (by decide)
#print axioms ex_e1124660719066
end Blc.Floor42.Grades045
