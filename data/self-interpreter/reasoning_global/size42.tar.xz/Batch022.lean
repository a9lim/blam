import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e350601968410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e350601968410 : Closed e350601968410 ∧ code e350601968410 = 4748648479514 := by decide
private def t_e350601968410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem cert_e350601968410 : ¬ IsSelfInterpreter e350601968410 :=
  wSource (t := t_e350601968410) (replay_sound (ps := []) (t := e350601968410) (by decide)) (by decide)
def e350601968454 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e350601968454 : Closed e350601968454 ∧ code e350601968454 = 4748648479558 := by decide
private def t_e350601968454 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem cert_e350601968454 : ¬ IsSelfInterpreter e350601968454 :=
  wSource (t := t_e350601968454) (replay_sound (ps := []) (t := e350601968454) (by decide)) (by decide)
def e350601976954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350601976954 : Closed e350601976954 ∧ code e350601976954 = 4748648488058 := by decide
theorem cert_e350601976954 : check e350601976954 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601977286 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350601977286 : Closed e350601977286 ∧ code e350601977286 = 4748648488390 := by decide
theorem cert_e350601977286 : check e350601977286 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e350601977402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350601977402 : Closed e350601977402 ∧ code e350601977402 = 4748648488506 := by decide
theorem cert_e350601977402 : check e350601977402 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e350601977542 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350601977542 : Closed e350601977542 ∧ code e350601977542 = 4748648488646 := by decide
theorem cert_e350601977542 : check e350601977542 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e350601989242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e350601989242 : Closed e350601989242 ∧ code e350601989242 = 4748648500346 := by decide
theorem cert_e350601989242 : checkPay e350601989242 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e350601989574 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e350601989574 : Closed e350601989574 ∧ code e350601989574 = 4748648500678 := by decide
theorem cert_e350601989574 : check e350601989574 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e350601989914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350601989914 : Closed e350601989914 ∧ code e350601989914 = 4748648501018 := by decide
theorem cert_e350601989914 : check e350601989914 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e350601989958 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350601989958 : Closed e350601989958 ∧ code e350601989958 = 4748648501062 := by decide
theorem cert_e350601989958 : check e350601989958 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e350601995834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e350601995834 : Closed e350601995834 ∧ code e350601995834 = 4748648506938 := by decide
theorem cert_e350601995834 : check e350601995834 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e350601995974 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e350601995974 : Closed e350601995974 ∧ code e350601995974 = 4748648507078 := by decide
theorem cert_e350601995974 : check e350601995974 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left]] .chain = true := by decide
def e350601996058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e350601996058 : Closed e350601996058 ∧ code e350601996058 = 4748648507162 := by decide
theorem cert_e350601996058 : check e350601996058 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e350601996102 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e350601996102 : Closed e350601996102 ∧ code e350601996102 = 4748648507206 := by decide
theorem cert_e350601996102 : check e350601996102 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e377979854362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979854362 : Closed e377979854362 ∧ code e377979854362 = 4776026365466 := by decide
theorem cert_e377979854362 : check e377979854362 [] .sourceHead = true := by decide
def e377979860506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979860506 : Closed e377979860506 ∧ code e377979860506 = 4776026371610 := by decide
theorem cert_e377979860506 : check e377979860506 [] .sourceHead = true := by decide
def e377979887130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979887130 : Closed e377979887130 ∧ code e377979887130 = 4776026398234 := by decide
theorem cert_e377979887130 : check e377979887130 [] .sourceHead = true := by decide
def e377979891226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979891226 : Closed e377979891226 ∧ code e377979891226 = 4776026402330 := by decide
theorem cert_e377979891226 : check e377979891226 [] .sourceHead = true := by decide
def e377979893274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979893274 : Closed e377979893274 ∧ code e377979893274 = 4776026404378 := by decide
theorem cert_e377979893274 : check e377979893274 [] .sourceHead = true := by decide
def e377979894298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979894298 : Closed e377979894298 ∧ code e377979894298 = 4776026405402 := by decide
theorem cert_e377979894298 : check e377979894298 [] .sourceHead = true := by decide
def e377979909658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979909658 : Closed e377979909658 ∧ code e377979909658 = 4776026420762 := by decide
theorem cert_e377979909658 : check e377979909658 [] .sourceHead = true := by decide
def e377979917850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979917850 : Closed e377979917850 ∧ code e377979917850 = 4776026428954 := by decide
theorem cert_e377979917850 : check e377979917850 [] .sourceHead = true := by decide
def e377979918874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377979918874 : Closed e377979918874 ∧ code e377979918874 = 4776026429978 := by decide
theorem cert_e377979918874 : check e377979918874 [] .sourceHead = true := by decide
def e377980018202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980018202 : Closed e377980018202 ∧ code e377980018202 = 4776026529306 := by decide
theorem cert_e377980018202 : check e377980018202 [] .sourceHead = true := by decide
def e377980022298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980022298 : Closed e377980022298 ∧ code e377980022298 = 4776026533402 := by decide
theorem cert_e377980022298 : check e377980022298 [] .sourceHead = true := by decide
def e377980024346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980024346 : Closed e377980024346 ∧ code e377980024346 = 4776026535450 := by decide
theorem cert_e377980024346 : check e377980024346 [] .sourceHead = true := by decide
def e377980025370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980025370 : Closed e377980025370 ∧ code e377980025370 = 4776026536474 := by decide
theorem cert_e377980025370 : check e377980025370 [] .sourceHead = true := by decide
def e377980038682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980038682 : Closed e377980038682 ∧ code e377980038682 = 4776026549786 := by decide
theorem cert_e377980038682 : check e377980038682 [] .sourceHead = true := by decide
def e377980041754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980041754 : Closed e377980041754 ∧ code e377980041754 = 4776026552858 := by decide
theorem cert_e377980041754 : check e377980041754 [] .sourceHead = true := by decide
def e377980048922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980048922 : Closed e377980048922 ∧ code e377980048922 = 4776026560026 := by decide
theorem cert_e377980048922 : check e377980048922 [] .sourceHead = true := by decide
def e377980049946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980049946 : Closed e377980049946 ∧ code e377980049946 = 4776026561050 := by decide
theorem cert_e377980049946 : check e377980049946 [] .sourceHead = true := by decide
def e377980054042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980054042 : Closed e377980054042 ∧ code e377980054042 = 4776026565146 := by decide
theorem cert_e377980054042 : check e377980054042 [] .sourceHead = true := by decide
def e377980106266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980106266 : Closed e377980106266 ∧ code e377980106266 = 4776026617370 := by decide
theorem cert_e377980106266 : check e377980106266 [] .sourceHead = true := by decide
def e377980114458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980114458 : Closed e377980114458 ∧ code e377980114458 = 4776026625562 := by decide
theorem cert_e377980114458 : check e377980114458 [] .sourceHead = true := by decide
def e377980115482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980115482 : Closed e377980115482 ∧ code e377980115482 = 4776026626586 := by decide
theorem cert_e377980115482 : check e377980115482 [] .sourceHead = true := by decide
def e377980147226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980147226 : Closed e377980147226 ∧ code e377980147226 = 4776026658330 := by decide
theorem cert_e377980147226 : check e377980147226 [] .sourceHead = true := by decide
def e377980148250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980148250 : Closed e377980148250 ∧ code e377980148250 = 4776026659354 := by decide
theorem cert_e377980148250 : check e377980148250 [] .sourceHead = true := by decide
def e377980152346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980152346 : Closed e377980152346 ∧ code e377980152346 = 4776026663450 := by decide
theorem cert_e377980152346 : check e377980152346 [] .sourceHead = true := by decide
def e377980640794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980640794 : Closed e377980640794 ∧ code e377980640794 = 4776027151898 := by decide
theorem cert_e377980640794 : check e377980640794 [] .sourceHead = true := by decide
def e377980646938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980646938 : Closed e377980646938 ∧ code e377980646938 = 4776027158042 := by decide
theorem cert_e377980646938 : check e377980646938 [] .sourceHead = true := by decide
def e377980673562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980673562 : Closed e377980673562 ∧ code e377980673562 = 4776027184666 := by decide
theorem cert_e377980673562 : check e377980673562 [] .sourceHead = true := by decide
def e377980677658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980677658 : Closed e377980677658 ∧ code e377980677658 = 4776027188762 := by decide
theorem cert_e377980677658 : check e377980677658 [] .sourceHead = true := by decide
def e377980679706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980679706 : Closed e377980679706 ∧ code e377980679706 = 4776027190810 := by decide
theorem cert_e377980679706 : check e377980679706 [] .sourceHead = true := by decide
def e377980680730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980680730 : Closed e377980680730 ∧ code e377980680730 = 4776027191834 := by decide
theorem cert_e377980680730 : check e377980680730 [] .sourceHead = true := by decide
def e377980696090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980696090 : Closed e377980696090 ∧ code e377980696090 = 4776027207194 := by decide
theorem cert_e377980696090 : check e377980696090 [] .sourceHead = true := by decide
def e377980704282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980704282 : Closed e377980704282 ∧ code e377980704282 = 4776027215386 := by decide
theorem cert_e377980704282 : check e377980704282 [] .sourceHead = true := by decide
def e377980705306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980705306 : Closed e377980705306 ∧ code e377980705306 = 4776027216410 := by decide
theorem cert_e377980705306 : check e377980705306 [] .sourceHead = true := by decide
def e377980837402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980837402 : Closed e377980837402 ∧ code e377980837402 = 4776027348506 := by decide
theorem cert_e377980837402 : check e377980837402 [] .sourceHead = true := by decide
def e377980843546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377980843546 : Closed e377980843546 ∧ code e377980843546 = 4776027354650 := by decide
theorem cert_e377980843546 : check e377980843546 [] .sourceHead = true := by decide
def e377981034010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981034010 : Closed e377981034010 ∧ code e377981034010 = 4776027545114 := by decide
theorem cert_e377981034010 : check e377981034010 [] .sourceHead = true := by decide
def e377981038106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981038106 : Closed e377981038106 ∧ code e377981038106 = 4776027549210 := by decide
theorem cert_e377981038106 : check e377981038106 [] .sourceHead = true := by decide
def e377981040154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981040154 : Closed e377981040154 ∧ code e377981040154 = 4776027551258 := by decide
theorem cert_e377981040154 : check e377981040154 [] .sourceHead = true := by decide
def e377981041178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981041178 : Closed e377981041178 ∧ code e377981041178 = 4776027552282 := by decide
theorem cert_e377981041178 : check e377981041178 [] .sourceHead = true := by decide
def e377981138458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981138458 : Closed e377981138458 ∧ code e377981138458 = 4776027649562 := by decide
theorem cert_e377981138458 : check e377981138458 [] .sourceHead = true := by decide
def e377981187610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981187610 : Closed e377981187610 ∧ code e377981187610 = 4776027698714 := by decide
theorem cert_e377981187610 : check e377981187610 [] .sourceHead = true := by decide
def e377981188634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981188634 : Closed e377981188634 ∧ code e377981188634 = 4776027699738 := by decide
theorem cert_e377981188634 : check e377981188634 [] .sourceHead = true := by decide
def e377981459994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981459994 : Closed e377981459994 ∧ code e377981459994 = 4776027971098 := by decide
theorem cert_e377981459994 : check e377981459994 [] .sourceHead = true := by decide
def e377981464090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981464090 : Closed e377981464090 ∧ code e377981464090 = 4776027975194 := by decide
theorem cert_e377981464090 : check e377981464090 [] .sourceHead = true := by decide
def e377981466138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981466138 : Closed e377981466138 ∧ code e377981466138 = 4776027977242 := by decide
theorem cert_e377981466138 : check e377981466138 [] .sourceHead = true := by decide
def e377981467162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981467162 : Closed e377981467162 ∧ code e377981467162 = 4776027978266 := by decide
theorem cert_e377981467162 : check e377981467162 [] .sourceHead = true := by decide
def e377981480474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981480474 : Closed e377981480474 ∧ code e377981480474 = 4776027991578 := by decide
theorem cert_e377981480474 : check e377981480474 [] .sourceHead = true := by decide
def e377981483546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981483546 : Closed e377981483546 ∧ code e377981483546 = 4776027994650 := by decide
theorem cert_e377981483546 : check e377981483546 [] .sourceHead = true := by decide
def e377981490714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981490714 : Closed e377981490714 ∧ code e377981490714 = 4776028001818 := by decide
theorem cert_e377981490714 : check e377981490714 [] .sourceHead = true := by decide
def e377981491738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981491738 : Closed e377981491738 ∧ code e377981491738 = 4776028002842 := by decide
theorem cert_e377981491738 : check e377981491738 [] .sourceHead = true := by decide
def e377981495834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981495834 : Closed e377981495834 ∧ code e377981495834 = 4776028006938 := by decide
theorem cert_e377981495834 : check e377981495834 [] .sourceHead = true := by decide
def e377981558298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981558298 : Closed e377981558298 ∧ code e377981558298 = 4776028069402 := by decide
theorem cert_e377981558298 : check e377981558298 [] .sourceHead = true := by decide
def e377981562394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981562394 : Closed e377981562394 ∧ code e377981562394 = 4776028073498 := by decide
theorem cert_e377981562394 : check e377981562394 [] .sourceHead = true := by decide
def e377981564442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981564442 : Closed e377981564442 ∧ code e377981564442 = 4776028075546 := by decide
theorem cert_e377981564442 : check e377981564442 [] .sourceHead = true := by decide
def e377981565466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981565466 : Closed e377981565466 ∧ code e377981565466 = 4776028076570 := by decide
theorem cert_e377981565466 : check e377981565466 [] .sourceHead = true := by decide
def e377981660698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981660698 : Closed e377981660698 ∧ code e377981660698 = 4776028171802 := by decide
theorem cert_e377981660698 : check e377981660698 [] .sourceHead = true := by decide
def e377981663770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981663770 : Closed e377981663770 ∧ code e377981663770 = 4776028174874 := by decide
theorem cert_e377981663770 : check e377981663770 [] .sourceHead = true := by decide
def e377981711898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981711898 : Closed e377981711898 ∧ code e377981711898 = 4776028223002 := by decide
theorem cert_e377981711898 : check e377981711898 [] .sourceHead = true := by decide
def e377981712922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981712922 : Closed e377981712922 ∧ code e377981712922 = 4776028224026 := by decide
theorem cert_e377981712922 : check e377981712922 [] .sourceHead = true := by decide
def e377981737498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981737498 : Closed e377981737498 ∧ code e377981737498 = 4776028248602 := by decide
theorem cert_e377981737498 : check e377981737498 [] .sourceHead = true := by decide
def e377981875738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981875738 : Closed e377981875738 ∧ code e377981875738 = 4776028386842 := by decide
theorem cert_e377981875738 : check e377981875738 [] .sourceHead = true := by decide
def e377981883930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981883930 : Closed e377981883930 ∧ code e377981883930 = 4776028395034 := by decide
theorem cert_e377981883930 : check e377981883930 [] .sourceHead = true := by decide
def e377981884954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981884954 : Closed e377981884954 ∧ code e377981884954 = 4776028396058 := by decide
theorem cert_e377981884954 : check e377981884954 [] .sourceHead = true := by decide
def e377981924890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981924890 : Closed e377981924890 ∧ code e377981924890 = 4776028435994 := by decide
theorem cert_e377981924890 : check e377981924890 [] .sourceHead = true := by decide
def e377981974042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981974042 : Closed e377981974042 ∧ code e377981974042 = 4776028485146 := by decide
theorem cert_e377981974042 : check e377981974042 [] .sourceHead = true := by decide
def e377981975066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377981975066 : Closed e377981975066 ∧ code e377981975066 = 4776028486170 := by decide
theorem cert_e377981975066 : check e377981975066 [] .sourceHead = true := by decide
def e377982080538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377982080538 : Closed e377982080538 ∧ code e377982080538 = 4776028591642 := by decide
theorem cert_e377982080538 : check e377982080538 [] .sourceHead = true := by decide
def e377982081562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377982081562 : Closed e377982081562 ∧ code e377982081562 = 4776028592666 := by decide
theorem cert_e377982081562 : check e377982081562 [] .sourceHead = true := by decide
def e377982085658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377982085658 : Closed e377982085658 ∧ code e377982085658 = 4776028596762 := by decide
theorem cert_e377982085658 : check e377982085658 [] .sourceHead = true := by decide
def e377982105114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377982105114 : Closed e377982105114 ∧ code e377982105114 = 4776028616218 := by decide
theorem cert_e377982105114 : check e377982105114 [] .sourceHead = true := by decide
def e377982106138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377982106138 : Closed e377982106138 ∧ code e377982106138 = 4776028617242 := by decide
theorem cert_e377982106138 : check e377982106138 [] .sourceHead = true := by decide
def e377982130714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377982130714 : Closed e377982130714 ∧ code e377982130714 = 4776028641818 := by decide
theorem cert_e377982130714 : check e377982130714 [] .sourceHead = true := by decide
def e377983786522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983786522 : Closed e377983786522 ∧ code e377983786522 = 4776030297626 := by decide
theorem cert_e377983786522 : check e377983786522 [] .sourceHead = true := by decide
def e377983792666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983792666 : Closed e377983792666 ∧ code e377983792666 = 4776030303770 := by decide
theorem cert_e377983792666 : check e377983792666 [] .sourceHead = true := by decide
def e377983819290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983819290 : Closed e377983819290 ∧ code e377983819290 = 4776030330394 := by decide
theorem cert_e377983819290 : check e377983819290 [] .sourceHead = true := by decide
def e377983823386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983823386 : Closed e377983823386 ∧ code e377983823386 = 4776030334490 := by decide
theorem cert_e377983823386 : check e377983823386 [] .sourceHead = true := by decide
def e377983825434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983825434 : Closed e377983825434 ∧ code e377983825434 = 4776030336538 := by decide
theorem cert_e377983825434 : check e377983825434 [] .sourceHead = true := by decide
def e377983826458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983826458 : Closed e377983826458 ∧ code e377983826458 = 4776030337562 := by decide
theorem cert_e377983826458 : check e377983826458 [] .sourceHead = true := by decide
def e377983841818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983841818 : Closed e377983841818 ∧ code e377983841818 = 4776030352922 := by decide
theorem cert_e377983841818 : check e377983841818 [] .sourceHead = true := by decide
def e377983850010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983850010 : Closed e377983850010 ∧ code e377983850010 = 4776030361114 := by decide
theorem cert_e377983850010 : check e377983850010 [] .sourceHead = true := by decide
def e377983851034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983851034 : Closed e377983851034 ∧ code e377983851034 = 4776030362138 := by decide
theorem cert_e377983851034 : check e377983851034 [] .sourceHead = true := by decide
def e377983983130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983983130 : Closed e377983983130 ∧ code e377983983130 = 4776030494234 := by decide
theorem cert_e377983983130 : check e377983983130 [] .sourceHead = true := by decide
def e377983989274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377983989274 : Closed e377983989274 ∧ code e377983989274 = 4776030500378 := by decide
theorem cert_e377983989274 : check e377983989274 [] .sourceHead = true := by decide
def e377984179738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984179738 : Closed e377984179738 ∧ code e377984179738 = 4776030690842 := by decide
theorem cert_e377984179738 : check e377984179738 [] .sourceHead = true := by decide
def e377984183834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984183834 : Closed e377984183834 ∧ code e377984183834 = 4776030694938 := by decide
theorem cert_e377984183834 : check e377984183834 [] .sourceHead = true := by decide
def e377984185882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984185882 : Closed e377984185882 ∧ code e377984185882 = 4776030696986 := by decide
theorem cert_e377984185882 : check e377984185882 [] .sourceHead = true := by decide
def e377984186906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984186906 : Closed e377984186906 ∧ code e377984186906 = 4776030698010 := by decide
theorem cert_e377984186906 : check e377984186906 [] .sourceHead = true := by decide
def e377984284186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984284186 : Closed e377984284186 ∧ code e377984284186 = 4776030795290 := by decide
theorem cert_e377984284186 : check e377984284186 [] .sourceHead = true := by decide
def e377984333338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984333338 : Closed e377984333338 ∧ code e377984333338 = 4776030844442 := by decide
theorem cert_e377984333338 : check e377984333338 [] .sourceHead = true := by decide
def e377984334362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377984334362 : Closed e377984334362 ∧ code e377984334362 = 4776030845466 := by decide
theorem cert_e377984334362 : check e377984334362 [] .sourceHead = true := by decide
def e377987227162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987227162 : Closed e377987227162 ∧ code e377987227162 = 4776033738266 := by decide
theorem cert_e377987227162 : check e377987227162 [] .sourceHead = true := by decide
def e377987231258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987231258 : Closed e377987231258 ∧ code e377987231258 = 4776033742362 := by decide
theorem cert_e377987231258 : check e377987231258 [] .sourceHead = true := by decide
def e377987233306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987233306 : Closed e377987233306 ∧ code e377987233306 = 4776033744410 := by decide
theorem cert_e377987233306 : check e377987233306 [] .sourceHead = true := by decide
def e377987234330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987234330 : Closed e377987234330 ∧ code e377987234330 = 4776033745434 := by decide
theorem cert_e377987234330 : check e377987234330 [] .sourceHead = true := by decide
def e377987247642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987247642 : Closed e377987247642 ∧ code e377987247642 = 4776033758746 := by decide
theorem cert_e377987247642 : check e377987247642 [] .sourceHead = true := by decide
def e377987250714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987250714 : Closed e377987250714 ∧ code e377987250714 = 4776033761818 := by decide
theorem cert_e377987250714 : check e377987250714 [] .sourceHead = true := by decide
def e377987257882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987257882 : Closed e377987257882 ∧ code e377987257882 = 4776033768986 := by decide
theorem cert_e377987257882 : check e377987257882 [] .sourceHead = true := by decide
def e377987258906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987258906 : Closed e377987258906 ∧ code e377987258906 = 4776033770010 := by decide
theorem cert_e377987258906 : check e377987258906 [] .sourceHead = true := by decide
def e377987263002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987263002 : Closed e377987263002 ∧ code e377987263002 = 4776033774106 := by decide
theorem cert_e377987263002 : check e377987263002 [] .sourceHead = true := by decide
def e377987325466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987325466 : Closed e377987325466 ∧ code e377987325466 = 4776033836570 := by decide
theorem cert_e377987325466 : check e377987325466 [] .sourceHead = true := by decide
def e377987329562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987329562 : Closed e377987329562 ∧ code e377987329562 = 4776033840666 := by decide
theorem cert_e377987329562 : check e377987329562 [] .sourceHead = true := by decide
def e377987331610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987331610 : Closed e377987331610 ∧ code e377987331610 = 4776033842714 := by decide
theorem cert_e377987331610 : check e377987331610 [] .sourceHead = true := by decide
def e377987332634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987332634 : Closed e377987332634 ∧ code e377987332634 = 4776033843738 := by decide
theorem cert_e377987332634 : check e377987332634 [] .sourceHead = true := by decide
def e377987427866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987427866 : Closed e377987427866 ∧ code e377987427866 = 4776033938970 := by decide
theorem cert_e377987427866 : check e377987427866 [] .sourceHead = true := by decide
def e377987430938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987430938 : Closed e377987430938 ∧ code e377987430938 = 4776033942042 := by decide
theorem cert_e377987430938 : check e377987430938 [] .sourceHead = true := by decide
def e377987479066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987479066 : Closed e377987479066 ∧ code e377987479066 = 4776033990170 := by decide
theorem cert_e377987479066 : check e377987479066 [] .sourceHead = true := by decide
def e377987480090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987480090 : Closed e377987480090 ∧ code e377987480090 = 4776033991194 := by decide
theorem cert_e377987480090 : check e377987480090 [] .sourceHead = true := by decide
def e377987504666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377987504666 : Closed e377987504666 ∧ code e377987504666 = 4776034015770 := by decide
theorem cert_e377987504666 : check e377987504666 [] .sourceHead = true := by decide
def e377988953626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377988953626 : Closed e377988953626 ∧ code e377988953626 = 4776035464730 := by decide
theorem cert_e377988953626 : check e377988953626 [] .sourceHead = true := by decide
def e377988961818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377988961818 : Closed e377988961818 ∧ code e377988961818 = 4776035472922 := by decide
theorem cert_e377988961818 : check e377988961818 [] .sourceHead = true := by decide
def e377988962842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377988962842 : Closed e377988962842 ∧ code e377988962842 = 4776035473946 := by decide
theorem cert_e377988962842 : check e377988962842 [] .sourceHead = true := by decide
def e377989002778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989002778 : Closed e377989002778 ∧ code e377989002778 = 4776035513882 := by decide
theorem cert_e377989002778 : check e377989002778 [] .sourceHead = true := by decide
def e377989051930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989051930 : Closed e377989051930 ∧ code e377989051930 = 4776035563034 := by decide
theorem cert_e377989051930 : check e377989051930 [] .sourceHead = true := by decide
def e377989052954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989052954 : Closed e377989052954 ∧ code e377989052954 = 4776035564058 := by decide
theorem cert_e377989052954 : check e377989052954 [] .sourceHead = true := by decide
def e377989813786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989813786 : Closed e377989813786 ∧ code e377989813786 = 4776036324890 := by decide
theorem cert_e377989813786 : check e377989813786 [] .sourceHead = true := by decide
def e377989814810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989814810 : Closed e377989814810 ∧ code e377989814810 = 4776036325914 := by decide
theorem cert_e377989814810 : check e377989814810 [] .sourceHead = true := by decide
def e377989818906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989818906 : Closed e377989818906 ∧ code e377989818906 = 4776036330010 := by decide
theorem cert_e377989818906 : check e377989818906 [] .sourceHead = true := by decide
def e377989838362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989838362 : Closed e377989838362 ∧ code e377989838362 = 4776036349466 := by decide
theorem cert_e377989838362 : check e377989838362 [] .sourceHead = true := by decide
def e377989839386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989839386 : Closed e377989839386 ∧ code e377989839386 = 4776036350490 := by decide
theorem cert_e377989839386 : check e377989839386 [] .sourceHead = true := by decide
def e377989863962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e377989863962 : Closed e377989863962 ∧ code e377989863962 = 4776036375066 := by decide
theorem cert_e377989863962 : check e377989863962 [] .sourceHead = true := by decide
def e378047524378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047524378 : Closed e378047524378 ∧ code e378047524378 = 4776094035482 := by decide
theorem cert_e378047524378 : check e378047524378 [] .sourceHead = true := by decide
def e378047526426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047526426 : Closed e378047526426 ∧ code e378047526426 = 4776094037530 := by decide
theorem cert_e378047526426 : check e378047526426 [] .sourceHead = true := by decide
def e378047540762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047540762 : Closed e378047540762 ∧ code e378047540762 = 4776094051866 := by decide
theorem cert_e378047540762 : check e378047540762 [] .sourceHead = true := by decide
def e378047543834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047543834 : Closed e378047543834 ∧ code e378047543834 = 4776094054938 := by decide
theorem cert_e378047543834 : check e378047543834 [] .sourceHead = true := by decide
def e378047551002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047551002 : Closed e378047551002 ∧ code e378047551002 = 4776094062106 := by decide
theorem cert_e378047551002 : check e378047551002 [] .sourceHead = true := by decide
def e378047552026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047552026 : Closed e378047552026 ∧ code e378047552026 = 4776094063130 := by decide
theorem cert_e378047552026 : check e378047552026 [] .sourceHead = true := by decide
def e378047884826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047884826 : Closed e378047884826 ∧ code e378047884826 = 4776094395930 := by decide
theorem cert_e378047884826 : check e378047884826 [] .sourceHead = true := by decide
def e378047886874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378047886874 : Closed e378047886874 ∧ code e378047886874 = 4776094397978 := by decide
theorem cert_e378047886874 : check e378047886874 [] .sourceHead = true := by decide
def e378048028186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048028186 : Closed e378048028186 ∧ code e378048028186 = 4776094539290 := by decide
theorem cert_e378048028186 : check e378048028186 [] .sourceHead = true := by decide
def e378048049350 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048049350 : Closed e378048049350 ∧ code e378048049350 = 4776094560454 := by decide
theorem cert_e378048049350 : check e378048049350 [] .sourceHead = true := by decide
def e378048056858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048056858 : Closed e378048056858 ∧ code e378048056858 = 4776094567962 := by decide
theorem cert_e378048056858 : check e378048056858 [] .sourceHead = true := by decide
def e378048065734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048065734 : Closed e378048065734 ∧ code e378048065734 = 4776094576838 := by decide
theorem cert_e378048065734 : check e378048065734 [] .sourceHead = true := by decide
def e378048114202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048114202 : Closed e378048114202 ∧ code e378048114202 = 4776094625306 := by decide
theorem cert_e378048114202 : check e378048114202 [] .sourceHead = true := by decide
def e378048117274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048117274 : Closed e378048117274 ∧ code e378048117274 = 4776094628378 := by decide
theorem cert_e378048117274 : check e378048117274 [] .sourceHead = true := by decide
def e378048159258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048159258 : Closed e378048159258 ∧ code e378048159258 = 4776094670362 := by decide
theorem cert_e378048159258 : check e378048159258 [] .sourceHead = true := by decide
def e378048180422 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048180422 : Closed e378048180422 ∧ code e378048180422 = 4776094691526 := by decide
theorem cert_e378048180422 : check e378048180422 [] .sourceHead = true := by decide
def e378048198682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048198682 : Closed e378048198682 ∧ code e378048198682 = 4776094709786 := by decide
theorem cert_e378048198682 : check e378048198682 [] .sourceHead = true := by decide
def e378048202266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048202266 : Closed e378048202266 ∧ code e378048202266 = 4776094713370 := by decide
theorem cert_e378048202266 : check e378048202266 [] .sourceHead = true := by decide
def e378048204998 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048204998 : Closed e378048204998 ∧ code e378048204998 = 4776094716102 := by decide
theorem cert_e378048204998 : check e378048204998 [] .sourceHead = true := by decide
def e378048206874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e378048206874 : Closed e378048206874 ∧ code e378048206874 = 4776094717978 := by decide
theorem cert_e378048206874 : check e378048206874 [] .sourceHead = true := by decide
def e378048230938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048230938 : Closed e378048230938 ∧ code e378048230938 = 4776094742042 := by decide
theorem cert_e378048230938 : check e378048230938 [] .sourceHead = true := by decide
def e378048231962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048231962 : Closed e378048231962 ∧ code e378048231962 = 4776094743066 := by decide
theorem cert_e378048231962 : check e378048231962 [] .sourceHead = true := by decide
def e378048253466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048253466 : Closed e378048253466 ∧ code e378048253466 = 4776094764570 := by decide
theorem cert_e378048253466 : check e378048253466 [] .sourceHead = true := by decide
def e378048262342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048262342 : Closed e378048262342 ∧ code e378048262342 = 4776094773446 := by decide
theorem cert_e378048262342 : check e378048262342 [] .sourceHead = true := by decide
def e378048267802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e378048267802 : Closed e378048267802 ∧ code e378048267802 = 4776094778906 := by decide
theorem cert_e378048267802 : check e378048267802 [] .sourceHead = true := by decide
def e378048270534 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e378048270534 : Closed e378048270534 ∧ code e378048270534 = 4776094781638 := by decide
theorem cert_e378048270534 : check e378048270534 [] .sourceHead = true := by decide
end Blc.Floor42
