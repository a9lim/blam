import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1196172750362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172750362 : Closed e1196172750362 ∧ code e1196172750362 = 5594219261466 := by decide
private def t_e1196172750362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172750362 : ¬ IsSelfInterpreter e1196172750362 :=
  wSource (t := t_e1196172750362) (replay_sound (ps := []) (t := e1196172750362) (by decide)) (by decide)
def e1196172753434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172753434 : Closed e1196172753434 ∧ code e1196172753434 = 5594219264538 := by decide
private def t_e1196172753434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172753434 : ¬ IsSelfInterpreter e1196172753434 :=
  wSource (t := t_e1196172753434) (replay_sound (ps := []) (t := e1196172753434) (by decide)) (by decide)
def e1196172760602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172760602 : Closed e1196172760602 ∧ code e1196172760602 = 5594219271706 := by decide
private def t_e1196172760602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172760602 : ¬ IsSelfInterpreter e1196172760602 :=
  wSource (t := t_e1196172760602) (replay_sound (ps := []) (t := e1196172760602) (by decide)) (by decide)
def e1196172761626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172761626 : Closed e1196172761626 ∧ code e1196172761626 = 5594219272730 := by decide
private def t_e1196172761626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172761626 : ¬ IsSelfInterpreter e1196172761626 :=
  wSource (t := t_e1196172761626) (replay_sound (ps := []) (t := e1196172761626) (by decide)) (by decide)
def e1196172802074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196172802074 : Closed e1196172802074 ∧ code e1196172802074 = 5594219313178 := by decide
theorem cert_e1196172802074 : check e1196172802074 [[]] .width = true := by decide
def e1196172832282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172832282 : Closed e1196172832282 ∧ code e1196172832282 = 5594219343386 := by decide
private def t_e1196172832282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172832282 : ¬ IsSelfInterpreter e1196172832282 :=
  wSource (t := t_e1196172832282) (replay_sound (ps := []) (t := e1196172832282) (by decide)) (by decide)
def e1196172834330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172834330 : Closed e1196172834330 ∧ code e1196172834330 = 5594219345434 := by decide
private def t_e1196172834330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172834330 : ¬ IsSelfInterpreter e1196172834330 :=
  wSource (t := t_e1196172834330) (replay_sound (ps := []) (t := e1196172834330) (by decide)) (by decide)
def e1196172886214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196172886214 : Closed e1196172886214 ∧ code e1196172886214 = 5594219397318 := by decide
theorem cert_e1196172886214 : check e1196172886214 [[]] .width = true := by decide
def e1196172930586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172930586 : Closed e1196172930586 ∧ code e1196172930586 = 5594219441690 := by decide
private def t_e1196172930586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172930586 : ¬ IsSelfInterpreter e1196172930586 :=
  wSource (t := t_e1196172930586) (replay_sound (ps := []) (t := e1196172930586) (by decide)) (by decide)
def e1196172933658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172933658 : Closed e1196172933658 ∧ code e1196172933658 = 5594219444762 := by decide
private def t_e1196172933658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172933658 : ¬ IsSelfInterpreter e1196172933658 :=
  wSource (t := t_e1196172933658) (replay_sound (ps := []) (t := e1196172933658) (by decide)) (by decide)
def e1196172974106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196172974106 : Closed e1196172974106 ∧ code e1196172974106 = 5594219485210 := by decide
theorem cert_e1196172974106 : check e1196172974106 [[]] .width = true := by decide
def e1196172981786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172981786 : Closed e1196172981786 ∧ code e1196172981786 = 5594219492890 := by decide
private def t_e1196172981786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172981786 : ¬ IsSelfInterpreter e1196172981786 :=
  wSource (t := t_e1196172981786) (replay_sound (ps := []) (t := e1196172981786) (by decide)) (by decide)
def e1196172982810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196172982810 : Closed e1196172982810 ∧ code e1196172982810 = 5594219493914 := by decide
private def t_e1196172982810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196172982810 : ¬ IsSelfInterpreter e1196172982810 :=
  wSource (t := t_e1196172982810) (replay_sound (ps := []) (t := e1196172982810) (by decide)) (by decide)
def e1196172984518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196172984518 : Closed e1196172984518 ∧ code e1196172984518 = 5594219495622 := by decide
theorem cert_e1196172984518 : check e1196172984518 [[]] .width = true := by decide
def e1196173088794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196173088794 : Closed e1196173088794 ∧ code e1196173088794 = 5594219599898 := by decide
theorem cert_e1196173088794 : check e1196173088794 [[]] .width = true := by decide
def e1196173092890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196173092890 : Closed e1196173092890 ∧ code e1196173092890 = 5594219603994 := by decide
theorem cert_e1196173092890 : check e1196173092890 [[]] .width = true := by decide
def e1196173145626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196173145626 : Closed e1196173145626 ∧ code e1196173145626 = 5594219656730 := by decide
private def t_e1196173145626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196173145626 : ¬ IsSelfInterpreter e1196173145626 :=
  wSource (t := t_e1196173145626) (replay_sound (ps := []) (t := e1196173145626) (by decide)) (by decide)
def e1196173153818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196173153818 : Closed e1196173153818 ∧ code e1196173153818 = 5594219664922 := by decide
private def t_e1196173153818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196173153818 : ¬ IsSelfInterpreter e1196173153818 :=
  wSource (t := t_e1196173153818) (replay_sound (ps := []) (t := e1196173153818) (by decide)) (by decide)
def e1196173154842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196173154842 : Closed e1196173154842 ∧ code e1196173154842 = 5594219665946 := by decide
private def t_e1196173154842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196173154842 : ¬ IsSelfInterpreter e1196173154842 :=
  wSource (t := t_e1196173154842) (replay_sound (ps := []) (t := e1196173154842) (by decide)) (by decide)
def e1196173178906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196173178906 : Closed e1196173178906 ∧ code e1196173178906 = 5594219690010 := by decide
theorem cert_e1196173178906 : check e1196173178906 [[]] .width = true := by decide
def e1196173194778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196173194778 : Closed e1196173194778 ∧ code e1196173194778 = 5594219705882 := by decide
private def t_e1196173194778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196173194778 : ¬ IsSelfInterpreter e1196173194778 :=
  wSource (t := t_e1196173194778) (replay_sound (ps := []) (t := e1196173194778) (by decide)) (by decide)
def e1196173213894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196173213894 : Closed e1196173213894 ∧ code e1196173213894 = 5594219724998 := by decide
theorem cert_e1196173213894 : check e1196173213894 [[]] .width = true := by decide
def e1196173236250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196173236250 : Closed e1196173236250 ∧ code e1196173236250 = 5594219747354 := by decide
theorem cert_e1196173236250 : check e1196173236250 [[]] .width = true := by decide
def e1196173243930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196173243930 : Closed e1196173243930 ∧ code e1196173243930 = 5594219755034 := by decide
private def t_e1196173243930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196173243930 : ¬ IsSelfInterpreter e1196173243930 :=
  wSource (t := t_e1196173243930) (replay_sound (ps := []) (t := e1196173243930) (by decide)) (by decide)
def e1196173244954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196173244954 : Closed e1196173244954 ∧ code e1196173244954 = 5594219756058 := by decide
private def t_e1196173244954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196173244954 : ¬ IsSelfInterpreter e1196173244954 :=
  wSource (t := t_e1196173244954) (replay_sound (ps := []) (t := e1196173244954) (by decide)) (by decide)
def e1196173246662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196173246662 : Closed e1196173246662 ∧ code e1196173246662 = 5594219757766 := by decide
theorem cert_e1196173246662 : check e1196173246662 [[]] .width = true := by decide
def e1196175093274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196175093274 : Closed e1196175093274 ∧ code e1196175093274 = 5594221604378 := by decide
private def t_e1196175093274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196175093274 : ¬ IsSelfInterpreter e1196175093274 :=
  wSource (t := t_e1196175093274) (replay_sound (ps := []) (t := e1196175093274) (by decide)) (by decide)
def e1196175095322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196175095322 : Closed e1196175095322 ∧ code e1196175095322 = 5594221606426 := by decide
private def t_e1196175095322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196175095322 : ¬ IsSelfInterpreter e1196175095322 :=
  wSource (t := t_e1196175095322) (replay_sound (ps := []) (t := e1196175095322) (by decide)) (by decide)
def e1196175111706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196175111706 : Closed e1196175111706 ∧ code e1196175111706 = 5594221622810 := by decide
private def t_e1196175111706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196175111706 : ¬ IsSelfInterpreter e1196175111706 :=
  wSource (t := t_e1196175111706) (replay_sound (ps := []) (t := e1196175111706) (by decide)) (by decide)
def e1196175423514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196175423514 : Closed e1196175423514 ∧ code e1196175423514 = 5594221934618 := by decide
theorem cert_e1196175423514 : check e1196175423514 [[]] .width = true := by decide
def e1196175453722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196175453722 : Closed e1196175453722 ∧ code e1196175453722 = 5594221964826 := by decide
private def t_e1196175453722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196175453722 : ¬ IsSelfInterpreter e1196175453722 :=
  wSource (t := t_e1196175453722) (replay_sound (ps := []) (t := e1196175453722) (by decide)) (by decide)
def e1196175455770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196175455770 : Closed e1196175455770 ∧ code e1196175455770 = 5594221966874 := by decide
private def t_e1196175455770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196175455770 : ¬ IsSelfInterpreter e1196175455770 :=
  wSource (t := t_e1196175455770) (replay_sound (ps := []) (t := e1196175455770) (by decide)) (by decide)
def e1196175507654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196175507654 : Closed e1196175507654 ∧ code e1196175507654 = 5594222018758 := by decide
theorem cert_e1196175507654 : check e1196175507654 [[]] .width = true := by decide
def e1196175538202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196175538202 : Closed e1196175538202 ∧ code e1196175538202 = 5594222049306 := by decide
theorem cert_e1196175538202 : check e1196175538202 [[]] .width = true := by decide
def e1196175554074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196175554074 : Closed e1196175554074 ∧ code e1196175554074 = 5594222065178 := by decide
private def t_e1196175554074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196175554074 : ¬ IsSelfInterpreter e1196175554074 :=
  wSource (t := t_e1196175554074) (replay_sound (ps := []) (t := e1196175554074) (by decide)) (by decide)
def e1196175573190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196175573190 : Closed e1196175573190 ∧ code e1196175573190 = 5594222084294 := by decide
theorem cert_e1196175573190 : check e1196175573190 [[]] .width = true := by decide
def e1196178501146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178501146 : Closed e1196178501146 ∧ code e1196178501146 = 5594225012250 := by decide
private def t_e1196178501146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178501146 : ¬ IsSelfInterpreter e1196178501146 :=
  wSource (t := t_e1196178501146) (replay_sound (ps := []) (t := e1196178501146) (by decide)) (by decide)
def e1196178503194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178503194 : Closed e1196178503194 ∧ code e1196178503194 = 5594225014298 := by decide
private def t_e1196178503194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178503194 : ¬ IsSelfInterpreter e1196178503194 :=
  wSource (t := t_e1196178503194) (replay_sound (ps := []) (t := e1196178503194) (by decide)) (by decide)
def e1196178517530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178517530 : Closed e1196178517530 ∧ code e1196178517530 = 5594225028634 := by decide
private def t_e1196178517530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178517530 : ¬ IsSelfInterpreter e1196178517530 :=
  wSource (t := t_e1196178517530) (replay_sound (ps := []) (t := e1196178517530) (by decide)) (by decide)
def e1196178520602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178520602 : Closed e1196178520602 ∧ code e1196178520602 = 5594225031706 := by decide
private def t_e1196178520602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178520602 : ¬ IsSelfInterpreter e1196178520602 :=
  wSource (t := t_e1196178520602) (replay_sound (ps := []) (t := e1196178520602) (by decide)) (by decide)
def e1196178527770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178527770 : Closed e1196178527770 ∧ code e1196178527770 = 5594225038874 := by decide
private def t_e1196178527770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178527770 : ¬ IsSelfInterpreter e1196178527770 :=
  wSource (t := t_e1196178527770) (replay_sound (ps := []) (t := e1196178527770) (by decide)) (by decide)
def e1196178528794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178528794 : Closed e1196178528794 ∧ code e1196178528794 = 5594225039898 := by decide
private def t_e1196178528794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178528794 : ¬ IsSelfInterpreter e1196178528794 :=
  wSource (t := t_e1196178528794) (replay_sound (ps := []) (t := e1196178528794) (by decide)) (by decide)
def e1196178569242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196178569242 : Closed e1196178569242 ∧ code e1196178569242 = 5594225080346 := by decide
theorem cert_e1196178569242 : check e1196178569242 [[]] .width = true := by decide
def e1196178599450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178599450 : Closed e1196178599450 ∧ code e1196178599450 = 5594225110554 := by decide
private def t_e1196178599450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178599450 : ¬ IsSelfInterpreter e1196178599450 :=
  wSource (t := t_e1196178599450) (replay_sound (ps := []) (t := e1196178599450) (by decide)) (by decide)
def e1196178601498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178601498 : Closed e1196178601498 ∧ code e1196178601498 = 5594225112602 := by decide
private def t_e1196178601498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178601498 : ¬ IsSelfInterpreter e1196178601498 :=
  wSource (t := t_e1196178601498) (replay_sound (ps := []) (t := e1196178601498) (by decide)) (by decide)
def e1196178653382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196178653382 : Closed e1196178653382 ∧ code e1196178653382 = 5594225164486 := by decide
theorem cert_e1196178653382 : check e1196178653382 [[]] .width = true := by decide
def e1196178697754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178697754 : Closed e1196178697754 ∧ code e1196178697754 = 5594225208858 := by decide
private def t_e1196178697754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178697754 : ¬ IsSelfInterpreter e1196178697754 :=
  wSource (t := t_e1196178697754) (replay_sound (ps := []) (t := e1196178697754) (by decide)) (by decide)
def e1196178700826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178700826 : Closed e1196178700826 ∧ code e1196178700826 = 5594225211930 := by decide
private def t_e1196178700826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178700826 : ¬ IsSelfInterpreter e1196178700826 :=
  wSource (t := t_e1196178700826) (replay_sound (ps := []) (t := e1196178700826) (by decide)) (by decide)
def e1196178741274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196178741274 : Closed e1196178741274 ∧ code e1196178741274 = 5594225252378 := by decide
theorem cert_e1196178741274 : check e1196178741274 [[]] .width = true := by decide
def e1196178748954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178748954 : Closed e1196178748954 ∧ code e1196178748954 = 5594225260058 := by decide
private def t_e1196178748954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178748954 : ¬ IsSelfInterpreter e1196178748954 :=
  wSource (t := t_e1196178748954) (replay_sound (ps := []) (t := e1196178748954) (by decide)) (by decide)
def e1196178749978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196178749978 : Closed e1196178749978 ∧ code e1196178749978 = 5594225261082 := by decide
private def t_e1196178749978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196178749978 : ¬ IsSelfInterpreter e1196178749978 :=
  wSource (t := t_e1196178749978) (replay_sound (ps := []) (t := e1196178749978) (by decide)) (by decide)
def e1196178751686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196178751686 : Closed e1196178751686 ∧ code e1196178751686 = 5594225262790 := by decide
theorem cert_e1196178751686 : check e1196178751686 [[]] .width = true := by decide
def e1196180223514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196180223514 : Closed e1196180223514 ∧ code e1196180223514 = 5594226734618 := by decide
private def t_e1196180223514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196180223514 : ¬ IsSelfInterpreter e1196180223514 :=
  wSource (t := t_e1196180223514) (replay_sound (ps := []) (t := e1196180223514) (by decide)) (by decide)
def e1196180231706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196180231706 : Closed e1196180231706 ∧ code e1196180231706 = 5594226742810 := by decide
private def t_e1196180231706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196180231706 : ¬ IsSelfInterpreter e1196180231706 :=
  wSource (t := t_e1196180231706) (replay_sound (ps := []) (t := e1196180231706) (by decide)) (by decide)
def e1196180232730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196180232730 : Closed e1196180232730 ∧ code e1196180232730 = 5594226743834 := by decide
private def t_e1196180232730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196180232730 : ¬ IsSelfInterpreter e1196180232730 :=
  wSource (t := t_e1196180232730) (replay_sound (ps := []) (t := e1196180232730) (by decide)) (by decide)
def e1196180256794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196180256794 : Closed e1196180256794 ∧ code e1196180256794 = 5594226767898 := by decide
theorem cert_e1196180256794 : check e1196180256794 [[]] .width = true := by decide
def e1196180272666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196180272666 : Closed e1196180272666 ∧ code e1196180272666 = 5594226783770 := by decide
private def t_e1196180272666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196180272666 : ¬ IsSelfInterpreter e1196180272666 :=
  wSource (t := t_e1196180272666) (replay_sound (ps := []) (t := e1196180272666) (by decide)) (by decide)
def e1196180291782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196180291782 : Closed e1196180291782 ∧ code e1196180291782 = 5594226802886 := by decide
theorem cert_e1196180291782 : check e1196180291782 [[]] .width = true := by decide
def e1196180314138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e1196180314138 : Closed e1196180314138 ∧ code e1196180314138 = 5594226825242 := by decide
theorem cert_e1196180314138 : check e1196180314138 [[]] .width = true := by decide
def e1196180321818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196180321818 : Closed e1196180321818 ∧ code e1196180321818 = 5594226832922 := by decide
private def t_e1196180321818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196180321818 : ¬ IsSelfInterpreter e1196180321818 :=
  wSource (t := t_e1196180321818) (replay_sound (ps := []) (t := e1196180321818) (by decide)) (by decide)
def e1196180322842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e1196180322842 : Closed e1196180322842 ∧ code e1196180322842 = 5594226833946 := by decide
private def t_e1196180322842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e1196180322842 : ¬ IsSelfInterpreter e1196180322842 :=
  wSource (t := t_e1196180322842) (replay_sound (ps := []) (t := e1196180322842) (by decide)) (by decide)
def e1196180324550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e1196180324550 : Closed e1196180324550 ∧ code e1196180324550 = 5594226835654 := by decide
theorem cert_e1196180324550 : check e1196180324550 [[]] .width = true := by decide
def e1196182035310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e1196182035310 : Closed e1196182035310 ∧ code e1196182035310 = 5594228546414 := by decide
theorem cert_e1196182035310 : check e1196182035310 [[],[.left]] .chain = true := by decide
def e1196182035318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e1196182035318 : Closed e1196182035318 ∧ code e1196182035318 = 5594228546422 := by decide
theorem cert_e1196182035318 : check e1196182035318 [[],[.left]] .chain = true := by decide
def e1196182035382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e1196182035382 : Closed e1196182035382 ∧ code e1196182035382 = 5594228546486 := by decide
theorem cert_e1196182035382 : check e1196182035382 [[],[.left]] .chain = true := by decide
def e1196182035822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1196182035822 : Closed e1196182035822 ∧ code e1196182035822 = 5594228546926 := by decide
theorem cert_e1196182035822 : check e1196182035822 [[],[.left]] .chain = true := by decide
def e1196182035830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1196182035830 : Closed e1196182035830 ∧ code e1196182035830 = 5594228546934 := by decide
theorem cert_e1196182035830 : check e1196182035830 [[],[.left]] .chain = true := by decide
def e1196182035886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1196182035886 : Closed e1196182035886 ∧ code e1196182035886 = 5594228546990 := by decide
theorem cert_e1196182035886 : check e1196182035886 [[],[.left]] .chain = true := by decide
def e1196182035898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1196182035898 : Closed e1196182035898 ∧ code e1196182035898 = 5594228547002 := by decide
theorem cert_e1196182035898 : check e1196182035898 [[],[.left]] .chain = true := by decide
def e1196182035926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1196182035926 : Closed e1196182035926 ∧ code e1196182035926 = 5594228547030 := by decide
theorem cert_e1196182035926 : check e1196182035926 [[],[.left]] .chain = true := by decide
def e1196182035930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1196182035930 : Closed e1196182035930 ∧ code e1196182035930 = 5594228547034 := by decide
theorem cert_e1196182035930 : check e1196182035930 [[],[.left]] .chain = true := by decide
def e1196182036150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e1196182036150 : Closed e1196182036150 ∧ code e1196182036150 = 5594228547254 := by decide
theorem cert_e1196182036150 : check e1196182036150 [[],[.left]] .chain = true := by decide
def e1196182036182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e1196182036182 : Closed e1196182036182 ∧ code e1196182036182 = 5594228547286 := by decide
theorem cert_e1196182036182 : check e1196182036182 [[],[.left]] .chain = true := by decide
def e1196182036186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e1196182036186 : Closed e1196182036186 ∧ code e1196182036186 = 5594228547290 := by decide
theorem cert_e1196182036186 : check e1196182036186 [[],[.left]] .chain = true := by decide
def e1196182038382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e1196182038382 : Closed e1196182038382 ∧ code e1196182038382 = 5594228549486 := by decide
theorem cert_e1196182038382 : check e1196182038382 [[],[.left]] .chain = true := by decide
def e1196182038390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e1196182038390 : Closed e1196182038390 ∧ code e1196182038390 = 5594228549494 := by decide
theorem cert_e1196182038390 : check e1196182038390 [[],[.left]] .chain = true := by decide
def e1196182038454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e1196182038454 : Closed e1196182038454 ∧ code e1196182038454 = 5594228549558 := by decide
theorem cert_e1196182038454 : check e1196182038454 [[],[.left]] .chain = true := by decide
def e1196182039790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196182039790 : Closed e1196182039790 ∧ code e1196182039790 = 5594228550894 := by decide
theorem cert_e1196182039790 : check e1196182039790 [[],[.left]] .chain = true := by decide
def e1196182039798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196182039798 : Closed e1196182039798 ∧ code e1196182039798 = 5594228550902 := by decide
theorem cert_e1196182039798 : check e1196182039798 [[],[.left]] .chain = true := by decide
def e1196182040182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196182040182 : Closed e1196182040182 ∧ code e1196182040182 = 5594228551286 := by decide
theorem cert_e1196182040182 : check e1196182040182 [[],[.left]] .chain = true := by decide
def e1196182041454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1196182041454 : Closed e1196182041454 ∧ code e1196182041454 = 5594228552558 := by decide
theorem cert_e1196182041454 : check e1196182041454 [[],[.left]] .chain = true := by decide
def e1196182041462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1196182041462 : Closed e1196182041462 ∧ code e1196182041462 = 5594228552566 := by decide
theorem cert_e1196182041462 : check e1196182041462 [[],[.left]] .chain = true := by decide
def e1196182041518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1196182041518 : Closed e1196182041518 ∧ code e1196182041518 = 5594228552622 := by decide
theorem cert_e1196182041518 : check e1196182041518 [[],[.left]] .chain = true := by decide
def e1196182041530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1196182041530 : Closed e1196182041530 ∧ code e1196182041530 = 5594228552634 := by decide
theorem cert_e1196182041530 : check e1196182041530 [[],[.left]] .chain = true := by decide
def e1196182041558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1196182041558 : Closed e1196182041558 ∧ code e1196182041558 = 5594228552662 := by decide
theorem cert_e1196182041558 : check e1196182041558 [[],[.left]] .chain = true := by decide
def e1196182041562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1196182041562 : Closed e1196182041562 ∧ code e1196182041562 = 5594228552666 := by decide
theorem cert_e1196182041562 : check e1196182041562 [[],[.left]] .chain = true := by decide
def e1196182041838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196182041838 : Closed e1196182041838 ∧ code e1196182041838 = 5594228552942 := by decide
theorem cert_e1196182041838 : check e1196182041838 [[],[.left]] .chain = true := by decide
def e1196182041846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196182041846 : Closed e1196182041846 ∧ code e1196182041846 = 5594228552950 := by decide
theorem cert_e1196182041846 : check e1196182041846 [[],[.left]] .chain = true := by decide
def e1196182042222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196182042222 : Closed e1196182042222 ∧ code e1196182042222 = 5594228553326 := by decide
theorem cert_e1196182042222 : check e1196182042222 [[],[.left]] .chain = true := by decide
def e1196182042234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196182042234 : Closed e1196182042234 ∧ code e1196182042234 = 5594228553338 := by decide
theorem cert_e1196182042234 : check e1196182042234 [[],[.left]] .chain = true := by decide
def e1196182042422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196182042422 : Closed e1196182042422 ∧ code e1196182042422 = 5594228553526 := by decide
theorem cert_e1196182042422 : check e1196182042422 [[],[.left]] .chain = true := by decide
def e1196182042426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196182042426 : Closed e1196182042426 ∧ code e1196182042426 = 5594228553530 := by decide
theorem cert_e1196182042426 : check e1196182042426 [[],[.left]] .chain = true := by decide
def e1196182043062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e1196182043062 : Closed e1196182043062 ∧ code e1196182043062 = 5594228554166 := by decide
theorem cert_e1196182043062 : check e1196182043062 [[],[.left]] .chain = true := by decide
def e1196182043094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e1196182043094 : Closed e1196182043094 ∧ code e1196182043094 = 5594228554198 := by decide
theorem cert_e1196182043094 : check e1196182043094 [[],[.left]] .chain = true := by decide
def e1196182043098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e1196182043098 : Closed e1196182043098 ∧ code e1196182043098 = 5594228554202 := by decide
theorem cert_e1196182043098 : check e1196182043098 [[],[.left]] .chain = true := by decide
def e1196182043254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e1196182043254 : Closed e1196182043254 ∧ code e1196182043254 = 5594228554358 := by decide
theorem cert_e1196182043254 : check e1196182043254 [[],[.left]] .chain = true := by decide
def e1196182043446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196182043446 : Closed e1196182043446 ∧ code e1196182043446 = 5594228554550 := by decide
theorem cert_e1196182043446 : check e1196182043446 [[],[.left]] .chain = true := by decide
def e1196182043450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196182043450 : Closed e1196182043450 ∧ code e1196182043450 = 5594228554554 := by decide
theorem cert_e1196182043450 : check e1196182043450 [[],[.left]] .chain = true := by decide
def e1196182050670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e1196182050670 : Closed e1196182050670 ∧ code e1196182050670 = 5594228561774 := by decide
theorem cert_e1196182050670 : check e1196182050670 [[],[.left]] .chain = true := by decide
def e1196182050678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e1196182050678 : Closed e1196182050678 ∧ code e1196182050678 = 5594228561782 := by decide
theorem cert_e1196182050678 : check e1196182050678 [[],[.left]] .chain = true := by decide
def e1196182050742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e1196182050742 : Closed e1196182050742 ∧ code e1196182050742 = 5594228561846 := by decide
theorem cert_e1196182050742 : check e1196182050742 [[],[.left]] .chain = true := by decide
def e1196182052078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e1196182052078 : Closed e1196182052078 ∧ code e1196182052078 = 5594228563182 := by decide
theorem cert_e1196182052078 : check e1196182052078 [[],[.left]] .chain = true := by decide
def e1196182052086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e1196182052086 : Closed e1196182052086 ∧ code e1196182052086 = 5594228563190 := by decide
theorem cert_e1196182052086 : check e1196182052086 [[],[.left]] .chain = true := by decide
def e1196182052470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e1196182052470 : Closed e1196182052470 ∧ code e1196182052470 = 5594228563574 := by decide
theorem cert_e1196182052470 : check e1196182052470 [[],[.left]] .chain = true := by decide
def e1196182063982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196182063982 : Closed e1196182063982 ∧ code e1196182063982 = 5594228575086 := by decide
theorem cert_e1196182063982 : check e1196182063982 [[],[.left]] .chain = true := by decide
def e1196182063990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196182063990 : Closed e1196182063990 ∧ code e1196182063990 = 5594228575094 := by decide
theorem cert_e1196182063990 : check e1196182063990 [[],[.left]] .chain = true := by decide
def e1196182064046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196182064046 : Closed e1196182064046 ∧ code e1196182064046 = 5594228575150 := by decide
theorem cert_e1196182064046 : check e1196182064046 [[],[.left]] .chain = true := by decide
def e1196182064058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196182064058 : Closed e1196182064058 ∧ code e1196182064058 = 5594228575162 := by decide
theorem cert_e1196182064058 : check e1196182064058 [[],[.left]] .chain = true := by decide
def e1196182064086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196182064086 : Closed e1196182064086 ∧ code e1196182064086 = 5594228575190 := by decide
theorem cert_e1196182064086 : check e1196182064086 [[],[.left]] .chain = true := by decide
def e1196182064090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196182064090 : Closed e1196182064090 ∧ code e1196182064090 = 5594228575194 := by decide
theorem cert_e1196182064090 : check e1196182064090 [[],[.left]] .chain = true := by decide
def e1196182064366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196182064366 : Closed e1196182064366 ∧ code e1196182064366 = 5594228575470 := by decide
theorem cert_e1196182064366 : check e1196182064366 [[],[.left]] .chain = true := by decide
def e1196182064374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196182064374 : Closed e1196182064374 ∧ code e1196182064374 = 5594228575478 := by decide
theorem cert_e1196182064374 : check e1196182064374 [[],[.left]] .chain = true := by decide
def e1196182064750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196182064750 : Closed e1196182064750 ∧ code e1196182064750 = 5594228575854 := by decide
theorem cert_e1196182064750 : check e1196182064750 [[],[.left]] .chain = true := by decide
def e1196182064762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196182064762 : Closed e1196182064762 ∧ code e1196182064762 = 5594228575866 := by decide
theorem cert_e1196182064762 : check e1196182064762 [[],[.left]] .chain = true := by decide
def e1196182064950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196182064950 : Closed e1196182064950 ∧ code e1196182064950 = 5594228576054 := by decide
theorem cert_e1196182064950 : check e1196182064950 [[],[.left]] .chain = true := by decide
def e1196182064954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196182064954 : Closed e1196182064954 ∧ code e1196182064954 = 5594228576058 := by decide
theorem cert_e1196182064954 : check e1196182064954 [[],[.left]] .chain = true := by decide
def e1196182070710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e1196182070710 : Closed e1196182070710 ∧ code e1196182070710 = 5594228581814 := by decide
theorem cert_e1196182070710 : check e1196182070710 [[],[.left]] .chain = true := by decide
def e1196182070742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e1196182070742 : Closed e1196182070742 ∧ code e1196182070742 = 5594228581846 := by decide
theorem cert_e1196182070742 : check e1196182070742 [[],[.left]] .chain = true := by decide
def e1196182070746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e1196182070746 : Closed e1196182070746 ∧ code e1196182070746 = 5594228581850 := by decide
theorem cert_e1196182070746 : check e1196182070746 [[],[.left]] .chain = true := by decide
def e1196182070902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e1196182070902 : Closed e1196182070902 ∧ code e1196182070902 = 5594228582006 := by decide
theorem cert_e1196182070902 : check e1196182070902 [[],[.left]] .chain = true := by decide
def e1196182071094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e1196182071094 : Closed e1196182071094 ∧ code e1196182071094 = 5594228582198 := by decide
theorem cert_e1196182071094 : check e1196182071094 [[],[.left]] .chain = true := by decide
def e1196182071098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e1196182071098 : Closed e1196182071098 ∧ code e1196182071098 = 5594228582202 := by decide
theorem cert_e1196182071098 : check e1196182071098 [[],[.left]] .chain = true := by decide
def e1196182408046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e1196182408046 : Closed e1196182408046 ∧ code e1196182408046 = 5594228919150 := by decide
theorem cert_e1196182408046 : check e1196182408046 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e1196182408054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e1196182408054 : Closed e1196182408054 ∧ code e1196182408054 = 5594228919158 := by decide
private def t_e1196182408054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e1196182408054 : ¬ IsSelfInterpreter e1196182408054 :=
  wSource (t := t_e1196182408054) (replay_sound (ps := []) (t := e1196182408054) (by decide)) (by decide)
def e1196182408110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e1196182408110 : Closed e1196182408110 ∧ code e1196182408110 = 5594228919214 := by decide
theorem cert_e1196182408110 : check e1196182408110 [[],[.left],[],[],[.under],[.under,.left]] .smaller = true := by decide
def e1196182408122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e1196182408122 : Closed e1196182408122 ∧ code e1196182408122 = 5594228919226 := by decide
theorem cert_e1196182408122 : check e1196182408122 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e1196182408150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e1196182408150 : Closed e1196182408150 ∧ code e1196182408150 = 5594228919254 := by decide
private def t_e1196182408150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e1196182408150 : ¬ IsSelfInterpreter e1196182408150 :=
  wSource (t := t_e1196182408150) (replay_sound (ps := []) (t := e1196182408150) (by decide)) (by decide)
def e1196182408154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e1196182408154 : Closed e1196182408154 ∧ code e1196182408154 = 5594228919258 := by decide
theorem cert_e1196182408154 : check e1196182408154 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e1196182408430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e1196182408430 : Closed e1196182408430 ∧ code e1196182408430 = 5594228919534 := by decide
theorem cert_e1196182408430 : check e1196182408430 [[],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1196182408438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e1196182408438 : Closed e1196182408438 ∧ code e1196182408438 = 5594228919542 := by decide
theorem cert_e1196182408438 : check e1196182408438 [[],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e1196182408814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e1196182408814 : Closed e1196182408814 ∧ code e1196182408814 = 5594228919918 := by decide
theorem cert_e1196182408814 : check e1196182408814 [[],[.left],[],[],[.under],[.under]] .smaller = true := by decide
def e1196182408826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e1196182408826 : Closed e1196182408826 ∧ code e1196182408826 = 5594228919930 := by decide
theorem cert_e1196182408826 : check e1196182408826 [[],[.left],[],[],[.under],[.under]] .smaller = true := by decide
def e1196182409014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e1196182409014 : Closed e1196182409014 ∧ code e1196182409014 = 5594228920118 := by decide
theorem cert_e1196182409014 : check e1196182409014 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e1196182409018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e1196182409018 : Closed e1196182409018 ∧ code e1196182409018 = 5594228920122 := by decide
theorem cert_e1196182409018 : check e1196182409018 [[],[.left],[],[],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e1196198767982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e1196198767982 : Closed e1196198767982 ∧ code e1196198767982 = 5594245279086 := by decide
theorem cert_e1196198767982 : check e1196198767982 [[],[.left]] .chain = true := by decide
def e1196198767990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e1196198767990 : Closed e1196198767990 ∧ code e1196198767990 = 5594245279094 := by decide
theorem cert_e1196198767990 : check e1196198767990 [[],[.left]] .chain = true := by decide
def e1196198768046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e1196198768046 : Closed e1196198768046 ∧ code e1196198768046 = 5594245279150 := by decide
theorem cert_e1196198768046 : check e1196198768046 [[],[.left]] .chain = true := by decide
def e1196198768058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e1196198768058 : Closed e1196198768058 ∧ code e1196198768058 = 5594245279162 := by decide
theorem cert_e1196198768058 : check e1196198768058 [[],[.left]] .chain = true := by decide
def e1196198768086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e1196198768086 : Closed e1196198768086 ∧ code e1196198768086 = 5594245279190 := by decide
theorem cert_e1196198768086 : check e1196198768086 [[],[.left]] .chain = true := by decide
def e1196198768090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e1196198768090 : Closed e1196198768090 ∧ code e1196198768090 = 5594245279194 := by decide
theorem cert_e1196198768090 : check e1196198768090 [[],[.left]] .chain = true := by decide
def e1196198768302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e1196198768302 : Closed e1196198768302 ∧ code e1196198768302 = 5594245279406 := by decide
theorem cert_e1196198768302 : check e1196198768302 [[],[.left]] .chain = true := by decide
def e1196198768314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e1196198768314 : Closed e1196198768314 ∧ code e1196198768314 = 5594245279418 := by decide
theorem cert_e1196198768314 : check e1196198768314 [[],[.left]] .chain = true := by decide
def e1196198768362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e1196198768362 : Closed e1196198768362 ∧ code e1196198768362 = 5594245279466 := by decide
theorem cert_e1196198768362 : check e1196198768362 [[],[.left]] .chain = true := by decide
def e1196198768470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e1196198768470 : Closed e1196198768470 ∧ code e1196198768470 = 5594245279574 := by decide
theorem cert_e1196198768470 : check e1196198768470 [[],[.left]] .chain = true := by decide
def e1196198768474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e1196198768474 : Closed e1196198768474 ∧ code e1196198768474 = 5594245279578 := by decide
theorem cert_e1196198768474 : check e1196198768474 [[],[.left]] .chain = true := by decide
def e1196198768490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e1196198768490 : Closed e1196198768490 ∧ code e1196198768490 = 5594245279594 := by decide
theorem cert_e1196198768490 : check e1196198768490 [[],[.left]] .chain = true := by decide
def e1196198769518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e1196198769518 : Closed e1196198769518 ∧ code e1196198769518 = 5594245280622 := by decide
theorem cert_e1196198769518 : check e1196198769518 [[],[.left]] .chain = true := by decide
def e1196198769526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e1196198769526 : Closed e1196198769526 ∧ code e1196198769526 = 5594245280630 := by decide
theorem cert_e1196198769526 : check e1196198769526 [[],[.left]] .chain = true := by decide
def e1196198769582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e1196198769582 : Closed e1196198769582 ∧ code e1196198769582 = 5594245280686 := by decide
theorem cert_e1196198769582 : check e1196198769582 [[],[.left]] .chain = true := by decide
def e1196198769594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e1196198769594 : Closed e1196198769594 ∧ code e1196198769594 = 5594245280698 := by decide
theorem cert_e1196198769594 : check e1196198769594 [[],[.left]] .chain = true := by decide
def e1196198769622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e1196198769622 : Closed e1196198769622 ∧ code e1196198769622 = 5594245280726 := by decide
theorem cert_e1196198769622 : check e1196198769622 [[],[.left]] .chain = true := by decide
def e1196198769626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e1196198769626 : Closed e1196198769626 ∧ code e1196198769626 = 5594245280730 := by decide
theorem cert_e1196198769626 : check e1196198769626 [[],[.left]] .chain = true := by decide
def e1196198769902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e1196198769902 : Closed e1196198769902 ∧ code e1196198769902 = 5594245281006 := by decide
theorem cert_e1196198769902 : check e1196198769902 [[],[.left]] .chain = true := by decide
def e1196198769910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e1196198769910 : Closed e1196198769910 ∧ code e1196198769910 = 5594245281014 := by decide
theorem cert_e1196198769910 : check e1196198769910 [[],[.left]] .chain = true := by decide
def e1196198770286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e1196198770286 : Closed e1196198770286 ∧ code e1196198770286 = 5594245281390 := by decide
theorem cert_e1196198770286 : check e1196198770286 [[],[.left]] .chain = true := by decide
def e1196198770298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e1196198770298 : Closed e1196198770298 ∧ code e1196198770298 = 5594245281402 := by decide
theorem cert_e1196198770298 : check e1196198770298 [[],[.left]] .chain = true := by decide
def e1196198770486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e1196198770486 : Closed e1196198770486 ∧ code e1196198770486 = 5594245281590 := by decide
theorem cert_e1196198770486 : check e1196198770486 [[],[.left]] .chain = true := by decide
def e1196198770490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e1196198770490 : Closed e1196198770490 ∧ code e1196198770490 = 5594245281594 := by decide
theorem cert_e1196198770490 : check e1196198770490 [[],[.left]] .chain = true := by decide
def e1196198771118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e1196198771118 : Closed e1196198771118 ∧ code e1196198771118 = 5594245282222 := by decide
theorem cert_e1196198771118 : check e1196198771118 [[],[.left]] .chain = true := by decide
def e1196198771130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e1196198771130 : Closed e1196198771130 ∧ code e1196198771130 = 5594245282234 := by decide
theorem cert_e1196198771130 : check e1196198771130 [[],[.left]] .chain = true := by decide
end Blc.Floor42
