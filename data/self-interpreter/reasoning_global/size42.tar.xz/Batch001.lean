import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e276462682938 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276462682938 : Closed e276462682938 ∧ code e276462682938 = 4674509194042 := by decide
theorem cert_e276462682938 : check e276462682938 [[.under]] .three = true := by decide
def e276462683034 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276462683034 : Closed e276462683034 ∧ code e276462683034 = 4674509194138 := by decide
theorem cert_e276462683034 : check e276462683034 [[.under]] .three = true := by decide
def e276462781142 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276462781142 : Closed e276462781142 ∧ code e276462781142 = 4674509292246 := by decide
theorem cert_e276462781142 : check e276462781142 [[.under]] .three = true := by decide
def e276462781146 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276462781146 : Closed e276462781146 ∧ code e276462781146 = 4674509292250 := by decide
theorem cert_e276462781146 : check e276462781146 [[.under]] .three = true := by decide
def e276462781162 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276462781162 : Closed e276462781162 ∧ code e276462781162 = 4674509292266 := by decide
theorem cert_e276462781162 : check e276462781162 [[.under]] .three = true := by decide
def e276462781238 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276462781238 : Closed e276462781238 ∧ code e276462781238 = 4674509292342 := by decide
theorem cert_e276462781238 : check e276462781238 [[.under]] .three = true := by decide
def e276462781242 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276462781242 : Closed e276462781242 ∧ code e276462781242 = 4674509292346 := by decide
theorem cert_e276462781242 : check e276462781242 [[.under]] .three = true := by decide
def e276462781338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276462781338 : Closed e276462781338 ∧ code e276462781338 = 4674509292442 := by decide
theorem cert_e276462781338 : check e276462781338 [[.under]] .three = true := by decide
def e276463010518 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276463010518 : Closed e276463010518 ∧ code e276463010518 = 4674509521622 := by decide
theorem cert_e276463010518 : check e276463010518 [[.under]] .three = true := by decide
def e276463010522 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276463010522 : Closed e276463010522 ∧ code e276463010522 = 4674509521626 := by decide
theorem cert_e276463010522 : check e276463010522 [[.under]] .three = true := by decide
def e276463010538 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276463010538 : Closed e276463010538 ∧ code e276463010538 = 4674509521642 := by decide
theorem cert_e276463010538 : check e276463010538 [[.under]] .three = true := by decide
def e276463010614 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276463010614 : Closed e276463010614 ∧ code e276463010614 = 4674509521718 := by decide
theorem cert_e276463010614 : check e276463010614 [[.under]] .three = true := by decide
def e276463010618 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276463010618 : Closed e276463010618 ∧ code e276463010618 = 4674509521722 := by decide
theorem cert_e276463010618 : check e276463010618 [[.under]] .three = true := by decide
def e276463010714 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276463010714 : Closed e276463010714 ∧ code e276463010714 = 4674509521818 := by decide
theorem cert_e276463010714 : check e276463010714 [[.under]] .three = true := by decide
def e276463043286 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276463043286 : Closed e276463043286 ∧ code e276463043286 = 4674509554390 := by decide
theorem cert_e276463043286 : check e276463043286 [[.under]] .three = true := by decide
def e276463043290 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276463043290 : Closed e276463043290 ∧ code e276463043290 = 4674509554394 := by decide
theorem cert_e276463043290 : check e276463043290 [[.under]] .three = true := by decide
def e276463043306 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276463043306 : Closed e276463043306 ∧ code e276463043306 = 4674509554410 := by decide
theorem cert_e276463043306 : check e276463043306 [[.under]] .three = true := by decide
def e276463043382 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276463043382 : Closed e276463043382 ∧ code e276463043382 = 4674509554486 := by decide
theorem cert_e276463043382 : check e276463043382 [[.under]] .three = true := by decide
def e276463043386 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276463043386 : Closed e276463043386 ∧ code e276463043386 = 4674509554490 := by decide
theorem cert_e276463043386 : check e276463043386 [[.under]] .three = true := by decide
def e276463043482 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276463043482 : Closed e276463043482 ∧ code e276463043482 = 4674509554586 := by decide
theorem cert_e276463043482 : check e276463043482 [[.under]] .three = true := by decide
def e276465304278 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276465304278 : Closed e276465304278 ∧ code e276465304278 = 4674511815382 := by decide
theorem cert_e276465304278 : check e276465304278 [[.under]] .three = true := by decide
def e276465304282 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276465304282 : Closed e276465304282 ∧ code e276465304282 = 4674511815386 := by decide
theorem cert_e276465304282 : check e276465304282 [[.under]] .three = true := by decide
def e276465304298 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276465304298 : Closed e276465304298 ∧ code e276465304298 = 4674511815402 := by decide
theorem cert_e276465304298 : check e276465304298 [[.under]] .three = true := by decide
def e276465304374 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276465304374 : Closed e276465304374 ∧ code e276465304374 = 4674511815478 := by decide
theorem cert_e276465304374 : check e276465304374 [[.under]] .three = true := by decide
def e276465304378 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276465304378 : Closed e276465304378 ∧ code e276465304378 = 4674511815482 := by decide
theorem cert_e276465304378 : check e276465304378 [[.under]] .three = true := by decide
def e276465304474 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276465304474 : Closed e276465304474 ∧ code e276465304474 = 4674511815578 := by decide
theorem cert_e276465304474 : check e276465304474 [[.under]] .three = true := by decide
def e276465369814 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276465369814 : Closed e276465369814 ∧ code e276465369814 = 4674511880918 := by decide
theorem cert_e276465369814 : check e276465369814 [[.under]] .three = true := by decide
def e276465369818 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276465369818 : Closed e276465369818 ∧ code e276465369818 = 4674511880922 := by decide
theorem cert_e276465369818 : check e276465369818 [[.under]] .three = true := by decide
def e276465369834 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276465369834 : Closed e276465369834 ∧ code e276465369834 = 4674511880938 := by decide
theorem cert_e276465369834 : check e276465369834 [[.under]] .three = true := by decide
def e276465369910 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276465369910 : Closed e276465369910 ∧ code e276465369910 = 4674511881014 := by decide
theorem cert_e276465369910 : check e276465369910 [[.under]] .three = true := by decide
def e276465369914 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276465369914 : Closed e276465369914 ∧ code e276465369914 = 4674511881018 := by decide
theorem cert_e276465369914 : check e276465369914 [[.under]] .three = true := by decide
def e276465370010 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276465370010 : Closed e276465370010 ∧ code e276465370010 = 4674511881114 := by decide
theorem cert_e276465370010 : check e276465370010 [[.under]] .three = true := by decide
def e276468450006 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276468450006 : Closed e276468450006 ∧ code e276468450006 = 4674514961110 := by decide
theorem cert_e276468450006 : check e276468450006 [[.under]] .three = true := by decide
def e276468450010 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276468450010 : Closed e276468450010 ∧ code e276468450010 = 4674514961114 := by decide
theorem cert_e276468450010 : check e276468450010 [[.under]] .three = true := by decide
def e276468450026 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276468450026 : Closed e276468450026 ∧ code e276468450026 = 4674514961130 := by decide
theorem cert_e276468450026 : check e276468450026 [[.under]] .three = true := by decide
def e276468450102 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276468450102 : Closed e276468450102 ∧ code e276468450102 = 4674514961206 := by decide
theorem cert_e276468450102 : check e276468450102 [[.under]] .three = true := by decide
def e276468450106 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276468450106 : Closed e276468450106 ∧ code e276468450106 = 4674514961210 := by decide
theorem cert_e276468450106 : check e276468450106 [[.under]] .three = true := by decide
def e276468450202 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276468450202 : Closed e276468450202 ∧ code e276468450202 = 4674514961306 := by decide
theorem cert_e276468450202 : check e276468450202 [[.under]] .three = true := by decide
def e276468548310 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276468548310 : Closed e276468548310 ∧ code e276468548310 = 4674515059414 := by decide
theorem cert_e276468548310 : check e276468548310 [[.under]] .three = true := by decide
def e276468548314 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276468548314 : Closed e276468548314 ∧ code e276468548314 = 4674515059418 := by decide
theorem cert_e276468548314 : check e276468548314 [[.under]] .three = true := by decide
def e276468548330 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276468548330 : Closed e276468548330 ∧ code e276468548330 = 4674515059434 := by decide
theorem cert_e276468548330 : check e276468548330 [[.under]] .three = true := by decide
def e276468548406 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276468548406 : Closed e276468548406 ∧ code e276468548406 = 4674515059510 := by decide
theorem cert_e276468548406 : check e276468548406 [[.under]] .three = true := by decide
def e276468548410 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276468548410 : Closed e276468548410 ∧ code e276468548410 = 4674515059514 := by decide
theorem cert_e276468548410 : check e276468548410 [[.under]] .three = true := by decide
def e276468548506 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276468548506 : Closed e276468548506 ∧ code e276468548506 = 4674515059610 := by decide
theorem cert_e276468548506 : check e276468548506 [[.under]] .three = true := by decide
def e276470088406 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276470088406 : Closed e276470088406 ∧ code e276470088406 = 4674516599510 := by decide
private def t_e276470088406 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e276470088406 : ¬ IsSelfInterpreter e276470088406 :=
  wSource (t := t_e276470088406) (replay_sound (ps := []) (t := e276470088406) (by decide)) (by decide)
def e276470088410 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276470088410 : Closed e276470088410 ∧ code e276470088410 = 4674516599514 := by decide
theorem cert_e276470088410 : check e276470088410 [[.under]] .three = true := by decide
def e276470088426 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276470088426 : Closed e276470088426 ∧ code e276470088426 = 4674516599530 := by decide
theorem cert_e276470088426 : check e276470088426 [[.under]] .three = true := by decide
def e276470088502 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276470088502 : Closed e276470088502 ∧ code e276470088502 = 4674516599606 := by decide
theorem cert_e276470088502 : check e276470088502 [[.under]] .three = true := by decide
def e276470088506 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276470088506 : Closed e276470088506 ∧ code e276470088506 = 4674516599610 := by decide
theorem cert_e276470088506 : check e276470088506 [[.under]] .three = true := by decide
def e276470088602 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276470088602 : Closed e276470088602 ∧ code e276470088602 = 4674516599706 := by decide
theorem cert_e276470088602 : check e276470088602 [[.under]] .three = true := by decide
def e276470121174 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276470121174 : Closed e276470121174 ∧ code e276470121174 = 4674516632278 := by decide
private def t_e276470121174 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e276470121174 : ¬ IsSelfInterpreter e276470121174 :=
  wSource (t := t_e276470121174) (replay_sound (ps := []) (t := e276470121174) (by decide)) (by decide)
def e276470121178 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276470121178 : Closed e276470121178 ∧ code e276470121178 = 4674516632282 := by decide
theorem cert_e276470121178 : check e276470121178 [[.under]] .three = true := by decide
def e276470121194 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276470121194 : Closed e276470121194 ∧ code e276470121194 = 4674516632298 := by decide
theorem cert_e276470121194 : check e276470121194 [[.under]] .three = true := by decide
def e276470121270 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276470121270 : Closed e276470121270 ∧ code e276470121270 = 4674516632374 := by decide
theorem cert_e276470121270 : check e276470121270 [[.under]] .three = true := by decide
def e276470121274 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276470121274 : Closed e276470121274 ∧ code e276470121274 = 4674516632378 := by decide
theorem cert_e276470121274 : check e276470121274 [[.under]] .three = true := by decide
def e276470121370 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276470121370 : Closed e276470121370 ∧ code e276470121370 = 4674516632474 := by decide
theorem cert_e276470121370 : check e276470121370 [[.under]] .three = true := by decide
def e276586939094 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276586939094 : Closed e276586939094 ∧ code e276586939094 = 4674633450198 := by decide
theorem cert_e276586939094 : check e276586939094 [[.under]] .three = true := by decide
def e276586939098 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276586939098 : Closed e276586939098 ∧ code e276586939098 = 4674633450202 := by decide
theorem cert_e276586939098 : check e276586939098 [[.under]] .three = true := by decide
def e276586939114 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276586939114 : Closed e276586939114 ∧ code e276586939114 = 4674633450218 := by decide
theorem cert_e276586939114 : check e276586939114 [[.under]] .three = true := by decide
def e276586939190 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276586939190 : Closed e276586939190 ∧ code e276586939190 = 4674633450294 := by decide
theorem cert_e276586939190 : check e276586939190 [[.under]] .three = true := by decide
def e276586939194 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276586939194 : Closed e276586939194 ∧ code e276586939194 = 4674633450298 := by decide
theorem cert_e276586939194 : check e276586939194 [[.under]] .three = true := by decide
def e276586939290 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276586939290 : Closed e276586939290 ∧ code e276586939290 = 4674633450394 := by decide
theorem cert_e276586939290 : check e276586939290 [[.under]] .three = true := by decide
def e276587987670 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276587987670 : Closed e276587987670 ∧ code e276587987670 = 4674634498774 := by decide
theorem cert_e276587987670 : check e276587987670 [[.under]] .three = true := by decide
def e276587987674 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276587987674 : Closed e276587987674 ∧ code e276587987674 = 4674634498778 := by decide
theorem cert_e276587987674 : check e276587987674 [[.under]] .three = true := by decide
def e276587987690 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276587987690 : Closed e276587987690 ∧ code e276587987690 = 4674634498794 := by decide
theorem cert_e276587987690 : check e276587987690 [[.under]] .three = true := by decide
def e276587987766 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276587987766 : Closed e276587987766 ∧ code e276587987766 = 4674634498870 := by decide
theorem cert_e276587987766 : check e276587987766 [[.under]] .three = true := by decide
def e276587987770 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276587987770 : Closed e276587987770 ∧ code e276587987770 = 4674634498874 := by decide
theorem cert_e276587987770 : check e276587987770 [[.under]] .three = true := by decide
def e276587987866 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276587987866 : Closed e276587987866 ∧ code e276587987866 = 4674634498970 := by decide
theorem cert_e276587987866 : check e276587987866 [[.under]] .three = true := by decide
def e276588053206 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276588053206 : Closed e276588053206 ∧ code e276588053206 = 4674634564310 := by decide
theorem cert_e276588053206 : check e276588053206 [[.under]] .three = true := by decide
def e276588053210 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276588053210 : Closed e276588053210 ∧ code e276588053210 = 4674634564314 := by decide
theorem cert_e276588053210 : check e276588053210 [[.under]] .three = true := by decide
def e276588053226 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276588053226 : Closed e276588053226 ∧ code e276588053226 = 4674634564330 := by decide
theorem cert_e276588053226 : check e276588053226 [[.under]] .three = true := by decide
def e276588053302 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276588053302 : Closed e276588053302 ∧ code e276588053302 = 4674634564406 := by decide
theorem cert_e276588053302 : check e276588053302 [[.under]] .three = true := by decide
def e276588053306 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276588053306 : Closed e276588053306 ∧ code e276588053306 = 4674634564410 := by decide
theorem cert_e276588053306 : check e276588053306 [[.under]] .three = true := by decide
def e276588053402 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276588053402 : Closed e276588053402 ∧ code e276588053402 = 4674634564506 := by decide
theorem cert_e276588053402 : check e276588053402 [[.under]] .three = true := by decide
def e276610007766 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276610007766 : Closed e276610007766 ∧ code e276610007766 = 4674656518870 := by decide
theorem cert_e276610007766 : check e276610007766 [[.under]] .three = true := by decide
def e276610007770 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276610007770 : Closed e276610007770 ∧ code e276610007770 = 4674656518874 := by decide
theorem cert_e276610007770 : check e276610007770 [[.under]] .three = true := by decide
def e276610007786 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276610007786 : Closed e276610007786 ∧ code e276610007786 = 4674656518890 := by decide
theorem cert_e276610007786 : check e276610007786 [[.under]] .three = true := by decide
def e276610007862 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276610007862 : Closed e276610007862 ∧ code e276610007862 = 4674656518966 := by decide
theorem cert_e276610007862 : check e276610007862 [[.under]] .three = true := by decide
def e276610007866 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276610007866 : Closed e276610007866 ∧ code e276610007866 = 4674656518970 := by decide
theorem cert_e276610007866 : check e276610007866 [[.under]] .three = true := by decide
def e276610007962 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276610007962 : Closed e276610007962 ∧ code e276610007962 = 4674656519066 := by decide
theorem cert_e276610007962 : check e276610007962 [[.under]] .three = true := by decide
def e276616299222 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276616299222 : Closed e276616299222 ∧ code e276616299222 = 4674662810326 := by decide
theorem cert_e276616299222 : check e276616299222 [[.under]] .three = true := by decide
def e276616299226 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276616299226 : Closed e276616299226 ∧ code e276616299226 = 4674662810330 := by decide
theorem cert_e276616299226 : check e276616299226 [[.under]] .three = true := by decide
def e276616299242 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276616299242 : Closed e276616299242 ∧ code e276616299242 = 4674662810346 := by decide
theorem cert_e276616299242 : check e276616299242 [[.under]] .three = true := by decide
def e276616299318 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276616299318 : Closed e276616299318 ∧ code e276616299318 = 4674662810422 := by decide
theorem cert_e276616299318 : check e276616299318 [[.under]] .three = true := by decide
def e276616299322 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276616299322 : Closed e276616299322 ∧ code e276616299322 = 4674662810426 := by decide
theorem cert_e276616299322 : check e276616299322 [[.under]] .three = true := by decide
def e276616299418 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276616299418 : Closed e276616299418 ∧ code e276616299418 = 4674662810522 := by decide
theorem cert_e276616299418 : check e276616299418 [[.under]] .three = true := by decide
def e276616364758 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276616364758 : Closed e276616364758 ∧ code e276616364758 = 4674662875862 := by decide
theorem cert_e276616364758 : check e276616364758 [[.under]] .three = true := by decide
def e276616364762 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276616364762 : Closed e276616364762 ∧ code e276616364762 = 4674662875866 := by decide
theorem cert_e276616364762 : check e276616364762 [[.under]] .three = true := by decide
def e276616364778 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276616364778 : Closed e276616364778 ∧ code e276616364778 = 4674662875882 := by decide
theorem cert_e276616364778 : check e276616364778 [[.under]] .three = true := by decide
def e276616364854 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276616364854 : Closed e276616364854 ∧ code e276616364854 = 4674662875958 := by decide
theorem cert_e276616364854 : check e276616364854 [[.under]] .three = true := by decide
def e276616364858 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276616364858 : Closed e276616364858 ∧ code e276616364858 = 4674662875962 := by decide
theorem cert_e276616364858 : check e276616364858 [[.under]] .three = true := by decide
def e276616364954 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276616364954 : Closed e276616364954 ∧ code e276616364954 = 4674662876058 := by decide
theorem cert_e276616364954 : check e276616364954 [[.under]] .three = true := by decide
def e276805042902 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276805042902 : Closed e276805042902 ∧ code e276805042902 = 4674851554006 := by decide
theorem cert_e276805042902 : check e276805042902 [[.under]] .three = true := by decide
def e276805042906 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276805042906 : Closed e276805042906 ∧ code e276805042906 = 4674851554010 := by decide
theorem cert_e276805042906 : check e276805042906 [[.under]] .three = true := by decide
def e276805042922 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276805042922 : Closed e276805042922 ∧ code e276805042922 = 4674851554026 := by decide
theorem cert_e276805042922 : check e276805042922 [[.under]] .three = true := by decide
def e276805042998 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276805042998 : Closed e276805042998 ∧ code e276805042998 = 4674851554102 := by decide
theorem cert_e276805042998 : check e276805042998 [[.under]] .three = true := by decide
def e276805043002 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276805043002 : Closed e276805043002 ∧ code e276805043002 = 4674851554106 := by decide
theorem cert_e276805043002 : check e276805043002 [[.under]] .three = true := by decide
def e276805043098 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276805043098 : Closed e276805043098 ∧ code e276805043098 = 4674851554202 := by decide
theorem cert_e276805043098 : check e276805043098 [[.under]] .three = true := by decide
def e276806615766 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276806615766 : Closed e276806615766 ∧ code e276806615766 = 4674853126870 := by decide
theorem cert_e276806615766 : check e276806615766 [[.under]] .three = true := by decide
def e276806615770 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276806615770 : Closed e276806615770 ∧ code e276806615770 = 4674853126874 := by decide
theorem cert_e276806615770 : check e276806615770 [[.under]] .three = true := by decide
def e276806615786 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276806615786 : Closed e276806615786 ∧ code e276806615786 = 4674853126890 := by decide
theorem cert_e276806615786 : check e276806615786 [[.under]] .three = true := by decide
def e276806615862 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276806615862 : Closed e276806615862 ∧ code e276806615862 = 4674853126966 := by decide
theorem cert_e276806615862 : check e276806615862 [[.under]] .three = true := by decide
def e276806615866 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276806615866 : Closed e276806615866 ∧ code e276806615866 = 4674853126970 := by decide
theorem cert_e276806615866 : check e276806615866 [[.under]] .three = true := by decide
def e276806615962 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276806615962 : Closed e276806615962 ∧ code e276806615962 = 4674853127066 := by decide
theorem cert_e276806615962 : check e276806615962 [[.under]] .three = true := by decide
def e276806714070 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276806714070 : Closed e276806714070 ∧ code e276806714070 = 4674853225174 := by decide
theorem cert_e276806714070 : check e276806714070 [[.under]] .three = true := by decide
def e276806714074 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276806714074 : Closed e276806714074 ∧ code e276806714074 = 4674853225178 := by decide
theorem cert_e276806714074 : check e276806714074 [[.under]] .three = true := by decide
def e276806714090 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276806714090 : Closed e276806714090 ∧ code e276806714090 = 4674853225194 := by decide
theorem cert_e276806714090 : check e276806714090 [[.under]] .three = true := by decide
def e276806714166 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276806714166 : Closed e276806714166 ∧ code e276806714166 = 4674853225270 := by decide
theorem cert_e276806714166 : check e276806714166 [[.under]] .three = true := by decide
def e276806714170 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276806714170 : Closed e276806714170 ∧ code e276806714170 = 4674853225274 := by decide
theorem cert_e276806714170 : check e276806714170 [[.under]] .three = true := by decide
def e276806714266 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276806714266 : Closed e276806714266 ∧ code e276806714266 = 4674853225370 := by decide
theorem cert_e276806714266 : check e276806714266 [[.under]] .three = true := by decide
def e276811334358 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276811334358 : Closed e276811334358 ∧ code e276811334358 = 4674857845462 := by decide
theorem cert_e276811334358 : check e276811334358 [[.under]] .three = true := by decide
def e276811334362 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276811334362 : Closed e276811334362 ∧ code e276811334362 = 4674857845466 := by decide
theorem cert_e276811334362 : check e276811334362 [[.under]] .three = true := by decide
def e276811334378 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276811334378 : Closed e276811334378 ∧ code e276811334378 = 4674857845482 := by decide
theorem cert_e276811334378 : check e276811334378 [[.under]] .three = true := by decide
def e276811334454 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276811334454 : Closed e276811334454 ∧ code e276811334454 = 4674857845558 := by decide
theorem cert_e276811334454 : check e276811334454 [[.under]] .three = true := by decide
def e276811334458 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276811334458 : Closed e276811334458 ∧ code e276811334458 = 4674857845562 := by decide
theorem cert_e276811334458 : check e276811334458 [[.under]] .three = true := by decide
def e276811334554 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276811334554 : Closed e276811334554 ∧ code e276811334554 = 4674857845658 := by decide
theorem cert_e276811334554 : check e276811334554 [[.under]] .three = true := by decide
def e276820771542 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276820771542 : Closed e276820771542 ∧ code e276820771542 = 4674867282646 := by decide
theorem cert_e276820771542 : check e276820771542 [[.under]] .three = true := by decide
def e276820771546 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276820771546 : Closed e276820771546 ∧ code e276820771546 = 4674867282650 := by decide
theorem cert_e276820771546 : check e276820771546 [[.under]] .three = true := by decide
def e276820771562 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276820771562 : Closed e276820771562 ∧ code e276820771562 = 4674867282666 := by decide
theorem cert_e276820771562 : check e276820771562 [[.under]] .three = true := by decide
def e276820771638 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276820771638 : Closed e276820771638 ∧ code e276820771638 = 4674867282742 := by decide
theorem cert_e276820771638 : check e276820771638 [[.under]] .three = true := by decide
def e276820771642 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276820771642 : Closed e276820771642 ∧ code e276820771642 = 4674867282746 := by decide
theorem cert_e276820771642 : check e276820771642 [[.under]] .three = true := by decide
def e276820771738 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276820771738 : Closed e276820771738 ∧ code e276820771738 = 4674867282842 := by decide
theorem cert_e276820771738 : check e276820771738 [[.under]] .three = true := by decide
def e276820869846 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276820869846 : Closed e276820869846 ∧ code e276820869846 = 4674867380950 := by decide
theorem cert_e276820869846 : check e276820869846 [[.under]] .three = true := by decide
def e276820869850 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276820869850 : Closed e276820869850 ∧ code e276820869850 = 4674867380954 := by decide
theorem cert_e276820869850 : check e276820869850 [[.under]] .three = true := by decide
def e276820869866 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276820869866 : Closed e276820869866 ∧ code e276820869866 = 4674867380970 := by decide
theorem cert_e276820869866 : check e276820869866 [[.under]] .three = true := by decide
def e276820869942 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276820869942 : Closed e276820869942 ∧ code e276820869942 = 4674867381046 := by decide
theorem cert_e276820869942 : check e276820869942 [[.under]] .three = true := by decide
def e276820869946 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276820869946 : Closed e276820869946 ∧ code e276820869946 = 4674867381050 := by decide
theorem cert_e276820869946 : check e276820869946 [[.under]] .three = true := by decide
def e276820870042 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276820870042 : Closed e276820870042 ∧ code e276820870042 = 4674867381146 := by decide
theorem cert_e276820870042 : check e276820870042 [[.under]] .three = true := by decide
def e276915143382 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276915143382 : Closed e276915143382 ∧ code e276915143382 = 4674961654486 := by decide
theorem cert_e276915143382 : check e276915143382 [[.under]] .three = true := by decide
def e276915143386 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276915143386 : Closed e276915143386 ∧ code e276915143386 = 4674961654490 := by decide
theorem cert_e276915143386 : check e276915143386 [[.under]] .three = true := by decide
def e276915143402 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276915143402 : Closed e276915143402 ∧ code e276915143402 = 4674961654506 := by decide
theorem cert_e276915143402 : check e276915143402 [[.under]] .three = true := by decide
def e276915143478 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276915143478 : Closed e276915143478 ∧ code e276915143478 = 4674961654582 := by decide
theorem cert_e276915143478 : check e276915143478 [[.under]] .three = true := by decide
def e276915143482 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276915143482 : Closed e276915143482 ∧ code e276915143482 = 4674961654586 := by decide
theorem cert_e276915143482 : check e276915143482 [[.under]] .three = true := by decide
def e276915143578 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276915143578 : Closed e276915143578 ∧ code e276915143578 = 4674961654682 := by decide
theorem cert_e276915143578 : check e276915143578 [[.under]] .three = true := by decide
def e276915208918 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276915208918 : Closed e276915208918 ∧ code e276915208918 = 4674961720022 := by decide
theorem cert_e276915208918 : check e276915208918 [[.under]] .three = true := by decide
def e276915208922 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276915208922 : Closed e276915208922 ∧ code e276915208922 = 4674961720026 := by decide
theorem cert_e276915208922 : check e276915208922 [[.under]] .three = true := by decide
def e276915208938 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276915208938 : Closed e276915208938 ∧ code e276915208938 = 4674961720042 := by decide
theorem cert_e276915208938 : check e276915208938 [[.under]] .three = true := by decide
def e276915209014 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276915209014 : Closed e276915209014 ∧ code e276915209014 = 4674961720118 := by decide
theorem cert_e276915209014 : check e276915209014 [[.under]] .three = true := by decide
def e276915209018 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276915209018 : Closed e276915209018 ∧ code e276915209018 = 4674961720122 := by decide
theorem cert_e276915209018 : check e276915209018 [[.under]] .three = true := by decide
def e276915209114 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276915209114 : Closed e276915209114 ∧ code e276915209114 = 4674961720218 := by decide
theorem cert_e276915209114 : check e276915209114 [[.under]] .three = true := by decide
def e276915667670 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276915667670 : Closed e276915667670 ∧ code e276915667670 = 4674962178774 := by decide
theorem cert_e276915667670 : check e276915667670 [[.under]] .three = true := by decide
def e276915667674 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276915667674 : Closed e276915667674 ∧ code e276915667674 = 4674962178778 := by decide
theorem cert_e276915667674 : check e276915667674 [[.under]] .three = true := by decide
def e276915667690 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276915667690 : Closed e276915667690 ∧ code e276915667690 = 4674962178794 := by decide
theorem cert_e276915667690 : check e276915667690 [[.under]] .three = true := by decide
def e276915667766 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276915667766 : Closed e276915667766 ∧ code e276915667766 = 4674962178870 := by decide
theorem cert_e276915667766 : check e276915667766 [[.under]] .three = true := by decide
def e276915667770 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276915667770 : Closed e276915667770 ∧ code e276915667770 = 4674962178874 := by decide
theorem cert_e276915667770 : check e276915667770 [[.under]] .three = true := by decide
def e276915667866 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276915667866 : Closed e276915667866 ∧ code e276915667866 = 4674962178970 := by decide
theorem cert_e276915667866 : check e276915667866 [[.under]] .three = true := by decide
def e276915765974 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276915765974 : Closed e276915765974 ∧ code e276915765974 = 4674962277078 := by decide
theorem cert_e276915765974 : check e276915765974 [[.under]] .three = true := by decide
def e276915765978 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276915765978 : Closed e276915765978 ∧ code e276915765978 = 4674962277082 := by decide
theorem cert_e276915765978 : check e276915765978 [[.under]] .three = true := by decide
def e276915765994 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276915765994 : Closed e276915765994 ∧ code e276915765994 = 4674962277098 := by decide
theorem cert_e276915765994 : check e276915765994 [[.under]] .three = true := by decide
def e276915766070 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276915766070 : Closed e276915766070 ∧ code e276915766070 = 4674962277174 := by decide
theorem cert_e276915766070 : check e276915766070 [[.under]] .three = true := by decide
def e276915766074 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276915766074 : Closed e276915766074 ∧ code e276915766074 = 4674962277178 := by decide
theorem cert_e276915766074 : check e276915766074 [[.under]] .three = true := by decide
def e276915766170 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276915766170 : Closed e276915766170 ∧ code e276915766170 = 4674962277274 := by decide
theorem cert_e276915766170 : check e276915766170 [[.under]] .three = true := by decide
def e276915995350 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276915995350 : Closed e276915995350 ∧ code e276915995350 = 4674962506454 := by decide
theorem cert_e276915995350 : check e276915995350 [[.under]] .three = true := by decide
def e276915995354 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276915995354 : Closed e276915995354 ∧ code e276915995354 = 4674962506458 := by decide
theorem cert_e276915995354 : check e276915995354 [[.under]] .three = true := by decide
def e276915995370 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e276915995370 : Closed e276915995370 ∧ code e276915995370 = 4674962506474 := by decide
theorem cert_e276915995370 : check e276915995370 [[.under]] .three = true := by decide
def e276915995446 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e276915995446 : Closed e276915995446 ∧ code e276915995446 = 4674962506550 := by decide
theorem cert_e276915995446 : check e276915995446 [[.under]] .three = true := by decide
def e276915995450 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e276915995450 : Closed e276915995450 ∧ code e276915995450 = 4674962506554 := by decide
theorem cert_e276915995450 : check e276915995450 [[.under]] .three = true := by decide
def e276915995546 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e276915995546 : Closed e276915995546 ∧ code e276915995546 = 4674962506650 := by decide
theorem cert_e276915995546 : check e276915995546 [[.under]] .three = true := by decide
def e276916028118 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e276916028118 : Closed e276916028118 ∧ code e276916028118 = 4674962539222 := by decide
theorem cert_e276916028118 : check e276916028118 [[.under]] .three = true := by decide
def e276916028122 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e276916028122 : Closed e276916028122 ∧ code e276916028122 = 4674962539226 := by decide
theorem cert_e276916028122 : check e276916028122 [[.under]] .three = true := by decide
end Blc.Floor42
