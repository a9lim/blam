import Floor42
namespace Blc.Floor42
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e1205812247418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e1205812247418 : Closed e1205812247418 ∧ code e1205812247418 = 5603858758522 := by decide
theorem cert_e1205812247418 : check e1205812247418 [[],[]] .smaller = true := by decide
def e1205812247470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e1205812247470 : Closed e1205812247470 ∧ code e1205812247470 = 5603858758574 := by decide
theorem cert_e1205812247470 : check e1205812247470 [[],[]] .smaller = true := by decide
def e1205812247482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e1205812247482 : Closed e1205812247482 ∧ code e1205812247482 = 5603858758586 := by decide
theorem cert_e1205812247482 : check e1205812247482 [[],[]] .smaller = true := by decide
def e1205812247510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e1205812247510 : Closed e1205812247510 ∧ code e1205812247510 = 5603858758614 := by decide
theorem cert_e1205812247510 : check e1205812247510 [[],[]] .smaller = true := by decide
def e1205812247514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e1205812247514 : Closed e1205812247514 ∧ code e1205812247514 = 5603858758618 := by decide
theorem cert_e1205812247514 : check e1205812247514 [[],[]] .smaller = true := by decide
def e1205812247530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e1205812247530 : Closed e1205812247530 ∧ code e1205812247530 = 5603858758634 := by decide
theorem cert_e1205812247530 : check e1205812247530 [[],[]] .three = true := by decide
def e1205812247902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e1205812247902 : Closed e1205812247902 ∧ code e1205812247902 = 5603858759006 := by decide
theorem cert_e1205812247902 : check e1205812247902 [[],[]] .smaller = true := by decide
def e1205812247918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e1205812247918 : Closed e1205812247918 ∧ code e1205812247918 = 5603858759022 := by decide
theorem cert_e1205812247918 : check e1205812247918 [[],[]] .smaller = true := by decide
def e1205812247926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e1205812247926 : Closed e1205812247926 ∧ code e1205812247926 = 5603858759030 := by decide
theorem cert_e1205812247926 : check e1205812247926 [[],[]] .smaller = true := by decide
def e1205812247930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e1205812247930 : Closed e1205812247930 ∧ code e1205812247930 = 5603858759034 := by decide
theorem cert_e1205812247930 : check e1205812247930 [[],[]] .smaller = true := by decide
def e1205812247982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e1205812247982 : Closed e1205812247982 ∧ code e1205812247982 = 5603858759086 := by decide
theorem cert_e1205812247982 : check e1205812247982 [[],[]] .smaller = true := by decide
def e1205812247994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e1205812247994 : Closed e1205812247994 ∧ code e1205812247994 = 5603858759098 := by decide
theorem cert_e1205812247994 : check e1205812247994 [[],[]] .smaller = true := by decide
def e1205812248022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e1205812248022 : Closed e1205812248022 ∧ code e1205812248022 = 5603858759126 := by decide
theorem cert_e1205812248022 : check e1205812248022 [[],[]] .smaller = true := by decide
def e1205812248026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e1205812248026 : Closed e1205812248026 ∧ code e1205812248026 = 5603858759130 := by decide
theorem cert_e1205812248026 : check e1205812248026 [[],[]] .smaller = true := by decide
def e1205812248042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e1205812248042 : Closed e1205812248042 ∧ code e1205812248042 = 5603858759146 := by decide
theorem cert_e1205812248042 : check e1205812248042 [[],[]] .smaller = true := by decide
def e1205812248238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e1205812248238 : Closed e1205812248238 ∧ code e1205812248238 = 5603858759342 := by decide
theorem cert_e1205812248238 : check e1205812248238 [[],[]] .smaller = true := by decide
def e1205812248246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e1205812248246 : Closed e1205812248246 ∧ code e1205812248246 = 5603858759350 := by decide
theorem cert_e1205812248246 : check e1205812248246 [[],[]] .smaller = true := by decide
def e1205812248250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e1205812248250 : Closed e1205812248250 ∧ code e1205812248250 = 5603858759354 := by decide
theorem cert_e1205812248250 : check e1205812248250 [[],[]] .smaller = true := by decide
def e1205812248278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e1205812248278 : Closed e1205812248278 ∧ code e1205812248278 = 5603858759382 := by decide
theorem cert_e1205812248278 : check e1205812248278 [[],[]] .smaller = true := by decide
def e1205812248282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e1205812248282 : Closed e1205812248282 ∧ code e1205812248282 = 5603858759386 := by decide
theorem cert_e1205812248282 : check e1205812248282 [[],[]] .smaller = true := by decide
def e1205812248298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e1205812248298 : Closed e1205812248298 ∧ code e1205812248298 = 5603858759402 := by decide
theorem cert_e1205812248298 : check e1205812248298 [[],[]] .smaller = true := by decide
def e1205812248406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e1205812248406 : Closed e1205812248406 ∧ code e1205812248406 = 5603858759510 := by decide
theorem cert_e1205812248406 : check e1205812248406 [[],[]] .three = true := by decide
def e1205812248410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e1205812248410 : Closed e1205812248410 ∧ code e1205812248410 = 5603858759514 := by decide
theorem cert_e1205812248410 : check e1205812248410 [[],[]] .three = true := by decide
def e1205812248426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e1205812248426 : Closed e1205812248426 ∧ code e1205812248426 = 5603858759530 := by decide
theorem cert_e1205812248426 : check e1205812248426 [[],[]] .three = true := by decide
def e1205812252094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e1205812252094 : Closed e1205812252094 ∧ code e1205812252094 = 5603858763198 := by decide
theorem cert_e1205812252094 : check e1205812252094 [[],[]] .three = true := by decide
def e1205812252126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e1205812252126 : Closed e1205812252126 ∧ code e1205812252126 = 5603858763230 := by decide
theorem cert_e1205812252126 : check e1205812252126 [[],[]] .smaller = true := by decide
def e1205812252142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e1205812252142 : Closed e1205812252142 ∧ code e1205812252142 = 5603858763246 := by decide
theorem cert_e1205812252142 : check e1205812252142 [[],[]] .smaller = true := by decide
def e1205812252150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e1205812252150 : Closed e1205812252150 ∧ code e1205812252150 = 5603858763254 := by decide
theorem cert_e1205812252150 : check e1205812252150 [[],[]] .three = true := by decide
def e1205812252350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e1205812252350 : Closed e1205812252350 ∧ code e1205812252350 = 5603858763454 := by decide
theorem cert_e1205812252350 : check e1205812252350 [[],[]] .three = true := by decide
def e1205812252382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e1205812252382 : Closed e1205812252382 ∧ code e1205812252382 = 5603858763486 := by decide
theorem cert_e1205812252382 : check e1205812252382 [[],[]] .smaller = true := by decide
def e1205812252398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e1205812252398 : Closed e1205812252398 ∧ code e1205812252398 = 5603858763502 := by decide
theorem cert_e1205812252398 : check e1205812252398 [[],[]] .smaller = true := by decide
def e1205812252406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e1205812252406 : Closed e1205812252406 ∧ code e1205812252406 = 5603858763510 := by decide
theorem cert_e1205812252406 : check e1205812252406 [[],[]] .smaller = true := by decide
def e1205812252410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e1205812252410 : Closed e1205812252410 ∧ code e1205812252410 = 5603858763514 := by decide
theorem cert_e1205812252410 : check e1205812252410 [[],[]] .three = true := by decide
def e1205812252510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e1205812252510 : Closed e1205812252510 ∧ code e1205812252510 = 5603858763614 := by decide
theorem cert_e1205812252510 : check e1205812252510 [[],[]] .smaller = true := by decide
def e1205812252526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e1205812252526 : Closed e1205812252526 ∧ code e1205812252526 = 5603858763630 := by decide
theorem cert_e1205812252526 : check e1205812252526 [[],[]] .smaller = true := by decide
def e1205812252534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e1205812252534 : Closed e1205812252534 ∧ code e1205812252534 = 5603858763638 := by decide
theorem cert_e1205812252534 : check e1205812252534 [[],[]] .smaller = true := by decide
def e1205812252538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e1205812252538 : Closed e1205812252538 ∧ code e1205812252538 = 5603858763642 := by decide
theorem cert_e1205812252538 : check e1205812252538 [[],[]] .smaller = true := by decide
def e1205812252590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e1205812252590 : Closed e1205812252590 ∧ code e1205812252590 = 5603858763694 := by decide
theorem cert_e1205812252590 : check e1205812252590 [[],[]] .smaller = true := by decide
def e1205812252598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e1205812252598 : Closed e1205812252598 ∧ code e1205812252598 = 5603858763702 := by decide
theorem cert_e1205812252598 : check e1205812252598 [[],[]] .smaller = true := by decide
def e1205812252602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e1205812252602 : Closed e1205812252602 ∧ code e1205812252602 = 5603858763706 := by decide
theorem cert_e1205812252602 : check e1205812252602 [[],[]] .smaller = true := by decide
def e1205812252630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e1205812252630 : Closed e1205812252630 ∧ code e1205812252630 = 5603858763734 := by decide
theorem cert_e1205812252630 : check e1205812252630 [[],[]] .three = true := by decide
def e1205812252634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e1205812252634 : Closed e1205812252634 ∧ code e1205812252634 = 5603858763738 := by decide
theorem cert_e1205812252634 : check e1205812252634 [[],[]] .three = true := by decide
def e1205812253630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e1205812253630 : Closed e1205812253630 ∧ code e1205812253630 = 5603858764734 := by decide
theorem cert_e1205812253630 : check e1205812253630 [[],[]] .three = true := by decide
def e1205812253662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e1205812253662 : Closed e1205812253662 ∧ code e1205812253662 = 5603858764766 := by decide
theorem cert_e1205812253662 : check e1205812253662 [[],[]] .smaller = true := by decide
def e1205812253678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e1205812253678 : Closed e1205812253678 ∧ code e1205812253678 = 5603858764782 := by decide
theorem cert_e1205812253678 : check e1205812253678 [[],[]] .smaller = true := by decide
def e1205812253686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e1205812253686 : Closed e1205812253686 ∧ code e1205812253686 = 5603858764790 := by decide
theorem cert_e1205812253686 : check e1205812253686 [[],[]] .three = true := by decide
def e1205812255166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e1205812255166 : Closed e1205812255166 ∧ code e1205812255166 = 5603858766270 := by decide
theorem cert_e1205812255166 : check e1205812255166 [[],[]] .three = true := by decide
def e1205812255198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205812255198 : Closed e1205812255198 ∧ code e1205812255198 = 5603858766302 := by decide
theorem cert_e1205812255198 : check e1205812255198 [[],[]] .smaller = true := by decide
def e1205812255214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205812255214 : Closed e1205812255214 ∧ code e1205812255214 = 5603858766318 := by decide
theorem cert_e1205812255214 : check e1205812255214 [[],[]] .smaller = true := by decide
def e1205812255222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205812255222 : Closed e1205812255222 ∧ code e1205812255222 = 5603858766326 := by decide
theorem cert_e1205812255222 : check e1205812255222 [[],[]] .smaller = true := by decide
def e1205812255226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e1205812255226 : Closed e1205812255226 ∧ code e1205812255226 = 5603858766330 := by decide
theorem cert_e1205812255226 : check e1205812255226 [[],[]] .three = true := by decide
def e1205812255966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205812255966 : Closed e1205812255966 ∧ code e1205812255966 = 5603858767070 := by decide
theorem cert_e1205812255966 : check e1205812255966 [[],[]] .smaller = true := by decide
def e1205812255982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205812255982 : Closed e1205812255982 ∧ code e1205812255982 = 5603858767086 := by decide
theorem cert_e1205812255982 : check e1205812255982 [[],[]] .smaller = true := by decide
def e1205812255990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205812255990 : Closed e1205812255990 ∧ code e1205812255990 = 5603858767094 := by decide
theorem cert_e1205812255990 : check e1205812255990 [[],[]] .smaller = true := by decide
def e1205812255994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205812255994 : Closed e1205812255994 ∧ code e1205812255994 = 5603858767098 := by decide
theorem cert_e1205812255994 : check e1205812255994 [[],[]] .smaller = true := by decide
def e1205812256366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812256366 : Closed e1205812256366 ∧ code e1205812256366 = 5603858767470 := by decide
theorem cert_e1205812256366 : check e1205812256366 [[],[]] .smaller = true := by decide
def e1205812256374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205812256374 : Closed e1205812256374 ∧ code e1205812256374 = 5603858767478 := by decide
theorem cert_e1205812256374 : check e1205812256374 [[],[]] .smaller = true := by decide
def e1205812256378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812256378 : Closed e1205812256378 ∧ code e1205812256378 = 5603858767482 := by decide
theorem cert_e1205812256378 : check e1205812256378 [[],[]] .smaller = true := by decide
def e1205812256566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812256566 : Closed e1205812256566 ∧ code e1205812256566 = 5603858767670 := by decide
theorem cert_e1205812256566 : check e1205812256566 [[],[]] .three = true := by decide
def e1205812256570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812256570 : Closed e1205812256570 ∧ code e1205812256570 = 5603858767674 := by decide
theorem cert_e1205812256570 : check e1205812256570 [[],[]] .three = true := by decide
def e1205812258494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e1205812258494 : Closed e1205812258494 ∧ code e1205812258494 = 5603858769598 := by decide
theorem cert_e1205812258494 : check e1205812258494 [[],[]] .three = true := by decide
def e1205812258526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e1205812258526 : Closed e1205812258526 ∧ code e1205812258526 = 5603858769630 := by decide
theorem cert_e1205812258526 : check e1205812258526 [[],[]] .smaller = true := by decide
def e1205812258542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e1205812258542 : Closed e1205812258542 ∧ code e1205812258542 = 5603858769646 := by decide
theorem cert_e1205812258542 : check e1205812258542 [[],[]] .smaller = true := by decide
def e1205812258550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e1205812258550 : Closed e1205812258550 ∧ code e1205812258550 = 5603858769654 := by decide
theorem cert_e1205812258550 : check e1205812258550 [[],[]] .smaller = true := by decide
def e1205812258554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e1205812258554 : Closed e1205812258554 ∧ code e1205812258554 = 5603858769658 := by decide
theorem cert_e1205812258554 : check e1205812258554 [[],[]] .three = true := by decide
def e1205812258654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e1205812258654 : Closed e1205812258654 ∧ code e1205812258654 = 5603858769758 := by decide
theorem cert_e1205812258654 : check e1205812258654 [[],[]] .smaller = true := by decide
def e1205812258682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e1205812258682 : Closed e1205812258682 ∧ code e1205812258682 = 5603858769786 := by decide
theorem cert_e1205812258682 : check e1205812258682 [[],[]] .smaller = true := by decide
def e1205812258734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e1205812258734 : Closed e1205812258734 ∧ code e1205812258734 = 5603858769838 := by decide
theorem cert_e1205812258734 : check e1205812258734 [[],[]] .smaller = true := by decide
def e1205812258746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e1205812258746 : Closed e1205812258746 ∧ code e1205812258746 = 5603858769850 := by decide
theorem cert_e1205812258746 : check e1205812258746 [[],[]] .smaller = true := by decide
def e1205812258774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e1205812258774 : Closed e1205812258774 ∧ code e1205812258774 = 5603858769878 := by decide
theorem cert_e1205812258774 : check e1205812258774 [[],[]] .smaller = true := by decide
def e1205812258778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e1205812258778 : Closed e1205812258778 ∧ code e1205812258778 = 5603858769882 := by decide
theorem cert_e1205812258778 : check e1205812258778 [[],[]] .smaller = true := by decide
def e1205812258794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e1205812258794 : Closed e1205812258794 ∧ code e1205812258794 = 5603858769898 := by decide
theorem cert_e1205812258794 : check e1205812258794 [[],[]] .three = true := by decide
def e1205812259262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e1205812259262 : Closed e1205812259262 ∧ code e1205812259262 = 5603858770366 := by decide
theorem cert_e1205812259262 : check e1205812259262 [[],[]] .three = true := by decide
def e1205812259294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e1205812259294 : Closed e1205812259294 ∧ code e1205812259294 = 5603858770398 := by decide
theorem cert_e1205812259294 : check e1205812259294 [[],[]] .smaller = true := by decide
def e1205812259310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e1205812259310 : Closed e1205812259310 ∧ code e1205812259310 = 5603858770414 := by decide
theorem cert_e1205812259310 : check e1205812259310 [[],[]] .smaller = true := by decide
def e1205812259318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e1205812259318 : Closed e1205812259318 ∧ code e1205812259318 = 5603858770422 := by decide
theorem cert_e1205812259318 : check e1205812259318 [[],[]] .smaller = true := by decide
def e1205812259322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e1205812259322 : Closed e1205812259322 ∧ code e1205812259322 = 5603858770426 := by decide
theorem cert_e1205812259322 : check e1205812259322 [[],[]] .three = true := by decide
def e1205812260062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205812260062 : Closed e1205812260062 ∧ code e1205812260062 = 5603858771166 := by decide
theorem cert_e1205812260062 : check e1205812260062 [[],[]] .smaller = true := by decide
def e1205812260090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205812260090 : Closed e1205812260090 ∧ code e1205812260090 = 5603858771194 := by decide
theorem cert_e1205812260090 : check e1205812260090 [[],[]] .smaller = true := by decide
def e1205812260462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812260462 : Closed e1205812260462 ∧ code e1205812260462 = 5603858771566 := by decide
theorem cert_e1205812260462 : check e1205812260462 [[],[]] .smaller = true := by decide
def e1205812260474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812260474 : Closed e1205812260474 ∧ code e1205812260474 = 5603858771578 := by decide
theorem cert_e1205812260474 : check e1205812260474 [[],[]] .smaller = true := by decide
def e1205812260662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812260662 : Closed e1205812260662 ∧ code e1205812260662 = 5603858771766 := by decide
theorem cert_e1205812260662 : check e1205812260662 [[],[]] .smaller = true := by decide
def e1205812260666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812260666 : Closed e1205812260666 ∧ code e1205812260666 = 5603858771770 := by decide
theorem cert_e1205812260666 : check e1205812260666 [[],[]] .smaller = true := by decide
def e1205812260762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812260762 : Closed e1205812260762 ∧ code e1205812260762 = 5603858771866 := by decide
theorem cert_e1205812260762 : check e1205812260762 [[],[]] .three = true := by decide
def e1205812261726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e1205812261726 : Closed e1205812261726 ∧ code e1205812261726 = 5603858772830 := by decide
theorem cert_e1205812261726 : check e1205812261726 [[],[]] .smaller = true := by decide
def e1205812261742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e1205812261742 : Closed e1205812261742 ∧ code e1205812261742 = 5603858772846 := by decide
theorem cert_e1205812261742 : check e1205812261742 [[],[]] .smaller = true := by decide
def e1205812261750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e1205812261750 : Closed e1205812261750 ∧ code e1205812261750 = 5603858772854 := by decide
theorem cert_e1205812261750 : check e1205812261750 [[],[]] .smaller = true := by decide
def e1205812261754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e1205812261754 : Closed e1205812261754 ∧ code e1205812261754 = 5603858772858 := by decide
theorem cert_e1205812261754 : check e1205812261754 [[],[]] .smaller = true := by decide
def e1205812261806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e1205812261806 : Closed e1205812261806 ∧ code e1205812261806 = 5603858772910 := by decide
theorem cert_e1205812261806 : check e1205812261806 [[],[]] .smaller = true := by decide
def e1205812261818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e1205812261818 : Closed e1205812261818 ∧ code e1205812261818 = 5603858772922 := by decide
theorem cert_e1205812261818 : check e1205812261818 [[],[]] .smaller = true := by decide
def e1205812261846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e1205812261846 : Closed e1205812261846 ∧ code e1205812261846 = 5603858772950 := by decide
theorem cert_e1205812261846 : check e1205812261846 [[],[]] .smaller = true := by decide
def e1205812261850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e1205812261850 : Closed e1205812261850 ∧ code e1205812261850 = 5603858772954 := by decide
theorem cert_e1205812261850 : check e1205812261850 [[],[]] .smaller = true := by decide
def e1205812261866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e1205812261866 : Closed e1205812261866 ∧ code e1205812261866 = 5603858772970 := by decide
theorem cert_e1205812261866 : check e1205812261866 [[],[]] .smaller = true := by decide
def e1205812262110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e1205812262110 : Closed e1205812262110 ∧ code e1205812262110 = 5603858773214 := by decide
theorem cert_e1205812262110 : check e1205812262110 [[],[]] .smaller = true := by decide
def e1205812262126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e1205812262126 : Closed e1205812262126 ∧ code e1205812262126 = 5603858773230 := by decide
theorem cert_e1205812262126 : check e1205812262126 [[],[]] .smaller = true := by decide
def e1205812262134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e1205812262134 : Closed e1205812262134 ∧ code e1205812262134 = 5603858773238 := by decide
theorem cert_e1205812262134 : check e1205812262134 [[],[]] .smaller = true := by decide
def e1205812262138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e1205812262138 : Closed e1205812262138 ∧ code e1205812262138 = 5603858773242 := by decide
theorem cert_e1205812262138 : check e1205812262138 [[],[]] .smaller = true := by decide
def e1205812262510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812262510 : Closed e1205812262510 ∧ code e1205812262510 = 5603858773614 := by decide
theorem cert_e1205812262510 : check e1205812262510 [[],[]] .smaller = true := by decide
def e1205812262522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812262522 : Closed e1205812262522 ∧ code e1205812262522 = 5603858773626 := by decide
theorem cert_e1205812262522 : check e1205812262522 [[],[]] .smaller = true := by decide
def e1205812262710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812262710 : Closed e1205812262710 ∧ code e1205812262710 = 5603858773814 := by decide
theorem cert_e1205812262710 : check e1205812262710 [[],[]] .smaller = true := by decide
def e1205812262714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812262714 : Closed e1205812262714 ∧ code e1205812262714 = 5603858773818 := by decide
theorem cert_e1205812262714 : check e1205812262714 [[],[]] .smaller = true := by decide
def e1205812262810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812262810 : Closed e1205812262810 ∧ code e1205812262810 = 5603858773914 := by decide
theorem cert_e1205812262810 : check e1205812262810 [[],[]] .smaller = true := by decide
def e1205812263342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e1205812263342 : Closed e1205812263342 ∧ code e1205812263342 = 5603858774446 := by decide
theorem cert_e1205812263342 : check e1205812263342 [[],[]] .smaller = true := by decide
def e1205812263350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e1205812263350 : Closed e1205812263350 ∧ code e1205812263350 = 5603858774454 := by decide
theorem cert_e1205812263350 : check e1205812263350 [[],[]] .smaller = true := by decide
def e1205812263354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e1205812263354 : Closed e1205812263354 ∧ code e1205812263354 = 5603858774458 := by decide
theorem cert_e1205812263354 : check e1205812263354 [[],[]] .smaller = true := by decide
def e1205812263382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e1205812263382 : Closed e1205812263382 ∧ code e1205812263382 = 5603858774486 := by decide
theorem cert_e1205812263382 : check e1205812263382 [[],[]] .smaller = true := by decide
def e1205812263386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e1205812263386 : Closed e1205812263386 ∧ code e1205812263386 = 5603858774490 := by decide
theorem cert_e1205812263386 : check e1205812263386 [[],[]] .smaller = true := by decide
def e1205812263402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e1205812263402 : Closed e1205812263402 ∧ code e1205812263402 = 5603858774506 := by decide
theorem cert_e1205812263402 : check e1205812263402 [[],[]] .smaller = true := by decide
def e1205812263534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e1205812263534 : Closed e1205812263534 ∧ code e1205812263534 = 5603858774638 := by decide
theorem cert_e1205812263534 : check e1205812263534 [[],[]] .smaller = true := by decide
def e1205812263542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e1205812263542 : Closed e1205812263542 ∧ code e1205812263542 = 5603858774646 := by decide
theorem cert_e1205812263542 : check e1205812263542 [[],[]] .smaller = true := by decide
def e1205812263546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e1205812263546 : Closed e1205812263546 ∧ code e1205812263546 = 5603858774650 := by decide
theorem cert_e1205812263546 : check e1205812263546 [[],[]] .smaller = true := by decide
def e1205812263734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812263734 : Closed e1205812263734 ∧ code e1205812263734 = 5603858774838 := by decide
theorem cert_e1205812263734 : check e1205812263734 [[],[]] .smaller = true := by decide
def e1205812263738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812263738 : Closed e1205812263738 ∧ code e1205812263738 = 5603858774842 := by decide
theorem cert_e1205812263738 : check e1205812263738 [[],[]] .smaller = true := by decide
def e1205812263834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812263834 : Closed e1205812263834 ∧ code e1205812263834 = 5603858774938 := by decide
theorem cert_e1205812263834 : check e1205812263834 [[],[]] .smaller = true := by decide
def e1205812264150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e1205812264150 : Closed e1205812264150 ∧ code e1205812264150 = 5603858775254 := by decide
theorem cert_e1205812264150 : check e1205812264150 [[],[]] .three = true := by decide
def e1205812264154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e1205812264154 : Closed e1205812264154 ∧ code e1205812264154 = 5603858775258 := by decide
theorem cert_e1205812264154 : check e1205812264154 [[],[]] .three = true := by decide
def e1205812264170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e1205812264170 : Closed e1205812264170 ∧ code e1205812264170 = 5603858775274 := by decide
theorem cert_e1205812264170 : check e1205812264170 [[],[]] .three = true := by decide
def e1205812264246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e1205812264246 : Closed e1205812264246 ∧ code e1205812264246 = 5603858775350 := by decide
theorem cert_e1205812264246 : check e1205812264246 [[],[]] .three = true := by decide
def e1205812264250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e1205812264250 : Closed e1205812264250 ∧ code e1205812264250 = 5603858775354 := by decide
theorem cert_e1205812264250 : check e1205812264250 [[],[]] .three = true := by decide
def e1205812264346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e1205812264346 : Closed e1205812264346 ∧ code e1205812264346 = 5603858775450 := by decide
theorem cert_e1205812264346 : check e1205812264346 [[],[]] .three = true := by decide
def e1205812267886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e1205812267886 : Closed e1205812267886 ∧ code e1205812267886 = 5603858778990 := by decide
theorem cert_e1205812267886 : check e1205812267886 [[],[]] .smaller = true := by decide
def e1205812267894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e1205812267894 : Closed e1205812267894 ∧ code e1205812267894 = 5603858778998 := by decide
theorem cert_e1205812267894 : check e1205812267894 [[],[]] .smaller = true := by decide
def e1205812267950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e1205812267950 : Closed e1205812267950 ∧ code e1205812267950 = 5603858779054 := by decide
theorem cert_e1205812267950 : check e1205812267950 [[],[]] .smaller = true := by decide
def e1205812267962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e1205812267962 : Closed e1205812267962 ∧ code e1205812267962 = 5603858779066 := by decide
theorem cert_e1205812267962 : check e1205812267962 [[],[]] .smaller = true := by decide
def e1205812267990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e1205812267990 : Closed e1205812267990 ∧ code e1205812267990 = 5603858779094 := by decide
theorem cert_e1205812267990 : check e1205812267990 [[],[]] .smaller = true := by decide
def e1205812267994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e1205812267994 : Closed e1205812267994 ∧ code e1205812267994 = 5603858779098 := by decide
theorem cert_e1205812267994 : check e1205812267994 [[],[]] .smaller = true := by decide
def e1205812268270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e1205812268270 : Closed e1205812268270 ∧ code e1205812268270 = 5603858779374 := by decide
theorem cert_e1205812268270 : check e1205812268270 [[],[]] .smaller = true := by decide
def e1205812268278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e1205812268278 : Closed e1205812268278 ∧ code e1205812268278 = 5603858779382 := by decide
theorem cert_e1205812268278 : check e1205812268278 [[],[]] .smaller = true := by decide
def e1205812268654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e1205812268654 : Closed e1205812268654 ∧ code e1205812268654 = 5603858779758 := by decide
theorem cert_e1205812268654 : check e1205812268654 [[],[]] .smaller = true := by decide
def e1205812268666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e1205812268666 : Closed e1205812268666 ∧ code e1205812268666 = 5603858779770 := by decide
theorem cert_e1205812268666 : check e1205812268666 [[],[]] .smaller = true := by decide
def e1205812268854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e1205812268854 : Closed e1205812268854 ∧ code e1205812268854 = 5603858779958 := by decide
theorem cert_e1205812268854 : check e1205812268854 [[],[]] .smaller = true := by decide
def e1205812268858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e1205812268858 : Closed e1205812268858 ∧ code e1205812268858 = 5603858779962 := by decide
theorem cert_e1205812268858 : check e1205812268858 [[],[]] .smaller = true := by decide
def e1205812276670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e1205812276670 : Closed e1205812276670 ∧ code e1205812276670 = 5603858787774 := by decide
theorem cert_e1205812276670 : check e1205812276670 [[],[]] .three = true := by decide
def e1205812276702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e1205812276702 : Closed e1205812276702 ∧ code e1205812276702 = 5603858787806 := by decide
theorem cert_e1205812276702 : check e1205812276702 [[],[]] .smaller = true := by decide
def e1205812276718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e1205812276718 : Closed e1205812276718 ∧ code e1205812276718 = 5603858787822 := by decide
theorem cert_e1205812276718 : check e1205812276718 [[],[]] .smaller = true := by decide
def e1205812276726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e1205812276726 : Closed e1205812276726 ∧ code e1205812276726 = 5603858787830 := by decide
theorem cert_e1205812276726 : check e1205812276726 [[],[]] .three = true := by decide
def e1205812276926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e1205812276926 : Closed e1205812276926 ∧ code e1205812276926 = 5603858788030 := by decide
theorem cert_e1205812276926 : check e1205812276926 [[],[]] .three = true := by decide
def e1205812276958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e1205812276958 : Closed e1205812276958 ∧ code e1205812276958 = 5603858788062 := by decide
theorem cert_e1205812276958 : check e1205812276958 [[],[]] .smaller = true := by decide
def e1205812276974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e1205812276974 : Closed e1205812276974 ∧ code e1205812276974 = 5603858788078 := by decide
theorem cert_e1205812276974 : check e1205812276974 [[],[]] .smaller = true := by decide
def e1205812276982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e1205812276982 : Closed e1205812276982 ∧ code e1205812276982 = 5603858788086 := by decide
theorem cert_e1205812276982 : check e1205812276982 [[],[]] .smaller = true := by decide
def e1205812276986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e1205812276986 : Closed e1205812276986 ∧ code e1205812276986 = 5603858788090 := by decide
theorem cert_e1205812276986 : check e1205812276986 [[],[]] .three = true := by decide
def e1205812277086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e1205812277086 : Closed e1205812277086 ∧ code e1205812277086 = 5603858788190 := by decide
theorem cert_e1205812277086 : check e1205812277086 [[],[]] .smaller = true := by decide
def e1205812277102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e1205812277102 : Closed e1205812277102 ∧ code e1205812277102 = 5603858788206 := by decide
theorem cert_e1205812277102 : check e1205812277102 [[],[]] .smaller = true := by decide
def e1205812277110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e1205812277110 : Closed e1205812277110 ∧ code e1205812277110 = 5603858788214 := by decide
theorem cert_e1205812277110 : check e1205812277110 [[],[]] .smaller = true := by decide
def e1205812277114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e1205812277114 : Closed e1205812277114 ∧ code e1205812277114 = 5603858788218 := by decide
theorem cert_e1205812277114 : check e1205812277114 [[],[]] .smaller = true := by decide
def e1205812277166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e1205812277166 : Closed e1205812277166 ∧ code e1205812277166 = 5603858788270 := by decide
theorem cert_e1205812277166 : check e1205812277166 [[],[]] .smaller = true := by decide
def e1205812277174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e1205812277174 : Closed e1205812277174 ∧ code e1205812277174 = 5603858788278 := by decide
theorem cert_e1205812277174 : check e1205812277174 [[],[]] .smaller = true := by decide
def e1205812277178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e1205812277178 : Closed e1205812277178 ∧ code e1205812277178 = 5603858788282 := by decide
theorem cert_e1205812277178 : check e1205812277178 [[],[]] .smaller = true := by decide
def e1205812277206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e1205812277206 : Closed e1205812277206 ∧ code e1205812277206 = 5603858788310 := by decide
theorem cert_e1205812277206 : check e1205812277206 [[],[]] .three = true := by decide
def e1205812277210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e1205812277210 : Closed e1205812277210 ∧ code e1205812277210 = 5603858788314 := by decide
theorem cert_e1205812277210 : check e1205812277210 [[],[]] .three = true := by decide
def e1205812278206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e1205812278206 : Closed e1205812278206 ∧ code e1205812278206 = 5603858789310 := by decide
theorem cert_e1205812278206 : check e1205812278206 [[],[]] .three = true := by decide
def e1205812278238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e1205812278238 : Closed e1205812278238 ∧ code e1205812278238 = 5603858789342 := by decide
theorem cert_e1205812278238 : check e1205812278238 [[],[]] .smaller = true := by decide
def e1205812278254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e1205812278254 : Closed e1205812278254 ∧ code e1205812278254 = 5603858789358 := by decide
theorem cert_e1205812278254 : check e1205812278254 [[],[]] .smaller = true := by decide
def e1205812278262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e1205812278262 : Closed e1205812278262 ∧ code e1205812278262 = 5603858789366 := by decide
theorem cert_e1205812278262 : check e1205812278262 [[],[]] .three = true := by decide
def e1205812279742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e1205812279742 : Closed e1205812279742 ∧ code e1205812279742 = 5603858790846 := by decide
theorem cert_e1205812279742 : check e1205812279742 [[],[]] .three = true := by decide
def e1205812279774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e1205812279774 : Closed e1205812279774 ∧ code e1205812279774 = 5603858790878 := by decide
theorem cert_e1205812279774 : check e1205812279774 [[],[]] .smaller = true := by decide
def e1205812279790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e1205812279790 : Closed e1205812279790 ∧ code e1205812279790 = 5603858790894 := by decide
theorem cert_e1205812279790 : check e1205812279790 [[],[]] .smaller = true := by decide
def e1205812279798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e1205812279798 : Closed e1205812279798 ∧ code e1205812279798 = 5603858790902 := by decide
theorem cert_e1205812279798 : check e1205812279798 [[],[]] .smaller = true := by decide
def e1205812279802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e1205812279802 : Closed e1205812279802 ∧ code e1205812279802 = 5603858790906 := by decide
theorem cert_e1205812279802 : check e1205812279802 [[],[]] .three = true := by decide
def e1205812280542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e1205812280542 : Closed e1205812280542 ∧ code e1205812280542 = 5603858791646 := by decide
theorem cert_e1205812280542 : check e1205812280542 [[],[]] .smaller = true := by decide
end Blc.Floor42
