"""Check that the repository archive selector and lane selector name the same sources."""
import importlib.util
from package_partial import selected,D
p=D.parents[2]/'data/self-interpreter/reasoning_global/pack.py'
spec=importlib.util.spec_from_file_location('repository_packer',p)
pkg=importlib.util.module_from_spec(spec);spec.loader.exec_module(pkg)
wanted={m+'.lean' for m in pkg.closure(D)}
wanted.update(p.name for p in D.iterdir() if p.is_file() and p.suffix in pkg.KEEP_SUFFIX and p.name not in pkg.DROP)
got,num=selected()
assert set(got)==wanted
print(num,'Lean modules;',len(wanted),'archive members; exact equality')
# The size-45 contract subtracts exactly the named files after checking the
# hashes. This verifies selection without running either pack.py subcommand.
import json
slim=json.loads((D/'slim.json').read_text());assert slim['regen'] in wanted
omit=slim['files']
assert set(omit)<=wanted and not (set(omit)&{slim['regen'],'slim.json'})
for n,h in omit.items():assert pkg.sha256(D/n)==h,n
print(len(omit),'omitted files;',sum((D/n).stat().st_size for n in omit),'omitted bytes;',len(wanted-set(omit)),'retained files')
