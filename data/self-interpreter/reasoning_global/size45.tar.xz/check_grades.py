"""Independent, memoized upper-grade audit for the finite-chain rows.

Builds the actual open call and its required normal form as de Bruijn syntax,
then evaluates each directly. Cache keys keep only its actually referenced free indices.
"""
from functools import lru_cache
def decode(bits):
    def at(i):
        if bits[i]=='1':
            j=bits.index('0',i)
            return (j-i-1,),j+1
        left,j=at(i+2)
        if bits[i+1]=='0':return ('l',left),j
        right,k=at(j);return ('a',left,right),k
    t,j=at(0);assert j==len(bits);return t

def app(f,x):return ('a',f,x)
def lam(b):return ('l',b)
def lift(t,d=0):
    if len(t)==1:return (t[0]+(t[0]>=d),)
    if t[0]=='l':return lam(lift(t[1],d+1))
    return app(lift(t[1],d),lift(t[2],d))
@lru_cache(4096)
def slots(t):
    if len(t)==1:return (t[0],)
    if t[0]=='l':return tuple(j-1 for j in slots(t[1]) if j)
    return tuple(sorted(set(slots(t[1])) | set(slots(t[2]))))
def check(r):
    code=r['source'];m=decode(code);e=decode(r['wire'])
    op=tuple(map(int,r['table']))
    assert len(op)==16
    def ap(f,x):return op[4*f+x]
    assert all(ap(i,j)<=ap(i+1,j) for i in range(3) for j in range(4))
    assert all(ap(i,j)<=ap(i,j+1) for i in range(4) for j in range(3))
    assert all(ap(3,j)==3 for j in range(4))
    env=(r['remainder_grade'],r['continuation_grade'])
    def ev(t,vs):return cached(t,tuple(vs[j] for j in slots(t)))
    @lru_cache(8192)
    def cached(t,vs):
        if len(t)==1:return vs[0]
        context=dict(zip(slots(t),vs))
        if t[0]=='a':return ap(ev(t[1],context),ev(t[2],context))
        outer={j+1:v for j,v in context.items()}
        body=[ev(t[1],outer | {0:j}) for j in range(4)]
        return next(i for i in range(4) if all(b<=ap(i,j) for j,b in enumerate(body)))
    tail=(0,);c=(1,)
    for bit in code[::-1]:
        b=lam(lam((1 if bit=='0' else 0,)))
        tail=lam(app(app((0,),b),lift(tail)))
    assert ev(e,env)==r['program_grade']
    upper=ev(app(app(e,c),tail),env)
    lower=ev(app(app(c,lam(m)),(0,)),env)
    assert upper<lower,(r['wire'],upper,lower)
    cached.cache_clear()
