from extras import *
from pathlib import Path
from time import monotonic
def quick(e):
 for kind,q in [('src',e),('K',A(e,K)),('delta',A(e,om[1]))]:
  seen=set()
  for style in (1,0,2,3):
   t=q;ps=[]
   for j in range(22):
    if t not in seen:
     seen.add(t)
     if kind=='src' and t[0]=='L' and not occ(t[1]):return ['dead',ps]
     if kind=='src' and (k:=sourcefact(t)):return [k,ps]
     if kind!='delta' and so(t):return ['so'+kind,ps]
     if kind!='K' and j<7:
      for c in (1,2,3,4):
       n,_,ok=profile(t,c)
       if n==0 and ok:return ['rank',ps,kind,c]
    p=variant(t,style) if style<3 else normal_path(t)
    if p is None:break
    t=bounded(t,p)
    if t is None or wire(t)>210:break
    ps=ps+[p]
def main():
 out=HERE/'attempts';out.mkdir(exist_ok=True)
 for s in (HERE/'after4.in').read_text().split()[int(sys.argv[1])::int(sys.argv[2])]:
    dest=out/(s+'.json')
    if dest.exists():continue
    r=quick(lc.decode(s)[0]);dest.write_text(json.dumps(r));so.cache_clear()
if __name__=='__main__':main()
