"""Collect non-canonical witnesses and proof layout choices from the working lane."""
from pathlib import Path
import json,re,csv
from jsonstream import ledger
D=Path(__file__).resolve().parent
def main():
 import probe_rows
 records={};choices=[];shapes={};direct=set()
 for r in ledger(D/'ledger.json'):
  m=r['module']
  if r['kind'] in ('open','pending') or not m.startswith('Batch'):
   x={k:v for k,v in r.items() if k not in ('wire','triple','root')}
   if x['kind']=='open':x.update(kind='pending',strength='predicate',status='pending')
   records[r['wire']]=x
  if r['kind']=='regular':direct.add(m)
 for r in csv.DictReader((D/'complete.tsv').open(),delimiter='\t'):
  if 'Classical.choice' in r['axioms']:choices.append(r['wire'])
 for m in sorted(direct):
  numbered=int(m[3:]);keys=[p.name for p in [D/f'h{numbered}.json',D/f'r{numbered}.json'] if p.exists()]
  rc=next(x for x in records.values() if x.get('individual_module',x['module'])==m)
  key=next(k for k in keys if json.loads((D/k).read_text())[0]==rc['states'])
  ranges=[]
  for p in [D/(m+'.lean'),*D.glob(m+'B*.lean')]:
   for line in p.read_text().splitlines():
    if (' := (RegProof.merge ' in line and line.startswith('theorem ok') and '(a := ' in line):
     ranges.append(int(re.match(r'theorem ok(\d+)',line)[1]))
  shapes[m]=[key,'DirectReg.check' in (D/(m+'Data.lean')).read_text(),sorted(ranges)]
 values=dict(records=records,choice=choices,regular=shapes,probe=probe_rows.assignment())
 (D/'proof-witnesses.json').write_text(json.dumps(values,separators=(',',':'))+'\n')
if __name__=='__main__':main()
