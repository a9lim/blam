from indexed import partition,balanced
from pathlib import Path
import json,re
here=Path(__file__).resolve().parent
def patch(n):
    p=here/(n+'.lean');d=here/(n+'Data.lean')
    if not d.exists():return
    z=d.read_text();m=re.search(r'def code : Array Code := #\[(.*?)\]\ndef P \(i : Nat\).*?\n',z)
    if not m:return
    ns=m[1].split(',');size=len(ns)
    if size<70:return
    starts=list(range(0,size,12))
    defs=[f'def code{x} : Array Code := #['+','.join(ns[x:x+12])+']' for x in starts]
    look=balanced(starts,lambda x:f'(code{x}[i-{x}]?.getD .opaque)')
    defs.append(f'def P (i : Nat) : Code := if i < {size} then {look} else .opaque')
    d.write_text('import LocalRank\n'+z[:m.start()]+'\n'.join(defs)+'\n'+z[m.end():])
    order=n+'Order';o=here/(order+'.lean')
    starts=list(range(0,size,8));body=f'namespace Certgen.{n}.Order\nset_option maxRecDepth 30000\nset_option maxHeartbeats 4000000\nabbrev ord := FloorIndex.forward {size} P\n'
    body+=''.join(f'theorem bl{x} : FloorIndex.rangeOK ord {x} {min(size-x,8)} = true := by decide +kernel\n' for x in starts)
    body+=f'theorem ok (i : Nat) : ord i = true := by\n by_cases h : i < {size}\n · '+partition(starts,3).replace('\n ','\n  ')+'\n · simp [ord,FloorIndex.forward,P,h]\n'
    # render a balanced dispatch independently, so both branches have identical indentation
    header=body[:body.index('theorem ok ')]
    tail=f'theorem ok (i : Nat) : ord i = true := by\n by_cases h : i < {size}\n · '+partition(starts,3)+'\n · simp [ord,FloorIndex.forward,P,h]\n'
    o.write_text('import '+n+'Data\n'+header+tail+f'end Certgen.{n}.Order\n')
    z=p.read_text();z=re.sub(r'theorem ordered_code[^\n]*\n','',z)
    if not z.startswith('import '+order+'\n'):z='import '+order+'\n'+z
    z=z.replace('rankedCode code ordered_code',f'FloorIndex.localRank {size} P Order.ok')
    p.write_text(z)
    for suffix in ('Data','Order',''):
        (here/(n+suffix+'.olean')).unlink(missing_ok=True)
    for x in here.glob(n+'Blk*.olean'):x.unlink()
for n in (here/'regmods.txt').read_text().split():
    if not (here/(n+'.olean')).exists():patch(n)
