"""Expand a slim size-45 archive into its exact kernel-checkable sources."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,shutil,subprocess,sys,tempfile
from regen_inventory import generate,SPECS
D=Path(__file__).resolve().parent
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 spec=json.loads((D/'slim.json').read_text())['files'];missing=[]
 for n,h in spec.items():
  assert Path(n).name==n
  if not (D/n).exists():missing.append(n)
  elif sha(D/n)!=h:raise ValueError(f'Existing file differs from recorded hash: {n}')
 if not missing:print('All',len(spec),'regenerated files already match.');return
 with tempfile.TemporaryDirectory(prefix='.regen-',dir=D) as td:
  tmp=Path(td)
  for p in D.glob('*.py'):shutil.copyfile(p,tmp/p.name)
  seeds=['hard-observations.json','inventory-counts.txt','certs.json','proof-witnesses.json','emitter-versions.json','build-metrics.json','hard-six.txt','raw4.txt','raw5.txt','extra-manifest.json','late-manifest.json','types-manifest.json','bottom-manifest.json']
  for p in [*(D/n for n in seeds),*D.glob('r[0-9]*.json'),*D.glob('h[0-9]*.json')]:shutil.copyfile(p,tmp/p.name)
  enums=[n for n in missing if n in SPECS]
  with ThreadPoolExecutor(max_workers=2) as pool:
   jobs=[]
   if enums:jobs.append(pool.submit(generate,tmp,enums))
   if len(missing)>len(enums):jobs.append(pool.submit(subprocess.run,[sys.executable,'-B',str(tmp/'regen_witnesses.py')],cwd=tmp,check=True,timeout=510))
   for job in jobs:job.result()
  for n in missing:
   if sha(tmp/n)!=spec[n]:raise ValueError(f'Regenerated file differs from recorded hash: {n}')
  for n in missing:(tmp/n).replace(D/n)
 print('Verified',len(spec),'hashes;',len(missing),'files regenerated.')
if __name__=='__main__':main()
