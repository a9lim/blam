"""Switch a large invariant to direct successor indexing with the same branch witnesses."""
from pathlib import Path
import re,sys
D=Path(__file__).resolve().parent
def update(n):
 p=D/(n+'Data.lean');s=p.read_text()
 if 'DirectReg.check ' not in s:
  s,k=re.subn(r'FloorIndex\.check pCode values konts \(RegProof\.states (\d+) getSt\) i \(hints i\)',r'DirectReg.check pCode values konts (RegProof.states \1 getSt) (RegProof.states \1 getSt i) (hints i)',s)
  assert k==1
  p.write_text('import DirectReg\n'+s)
 p=D/(n+'.lean');p.write_text(p.read_text().replace('RegProof.noClock mdl','DirectReg.noClock mdl'))
if __name__=='__main__':
 for n in sys.argv[1:]:update(n)
