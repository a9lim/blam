import H45F9692715709398Proof17
namespace Blc.H45.H45F9692715709398
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h648 (ρ : Env) (a0 : Fits s14 (ρ 0)) : All tab ρ b6 s177 :=
  (consAll (lamAt d33 c33 (smaller (h527 (Types.cons s16 ρ) sub10 a0) sub10)) Positive.none)
theorem h649 (ρ : Env) (a0 : Fits s19 (ρ 0)) : All tab ρ b6 s16 :=
  (consAll (lamAt d24 c24 (smaller (h528 (Types.cons s17 ρ) sub17 a0) sub4)) Positive.none)
theorem h650 (ρ : Env) (a0 : Fits s26 (ρ 0)) : All tab ρ b6 s136 :=
  (consAll (lamAt d41 c41 (smaller (h530 (Types.cons s29 ρ) sub110 a0) sub246)) Positive.none)
theorem h651 (ρ : Env) (a0 : Fits s26 (ρ 0)) : All tab ρ b6 s168 :=
  (consAll (lamAt d44 c44 (smaller (h531 (Types.cons s31 ρ) sub112 a0) sub112)) Positive.none)
theorem h652 (ρ : Env) (a0 : Fits s30 (ρ 0)) : All tab ρ b6 s31 :=
  (consAll (lamAt d43 c43 (smaller (h532 (Types.cons s5 ρ) sub2 a0) sub178)) Positive.none)
theorem h653 (ρ : Env) (a0 : Fits s25 (ρ 0)) : All tab ρ b6 s143 :=
  (consAll (lamAt d18 c18 (smaller (h533 (Types.cons s5 ρ) sub2 a0) sub2)) Positive.none)
theorem h654 (ρ : Env) (a0 : Fits s26 (ρ 0)) : All tab ρ b6 s5 :=
  (consAll (lamAt d9 c9 (smaller (h534 (Types.cons s6 ρ) sub4 a0) sub4)) Positive.none)
theorem h655 (ρ : Env) (a0 : Fits s17 (ρ 0)) : All tab ρ b6 s5 :=
  (consAll (lamAt d9 c9 (smaller (h535 (Types.cons s6 ρ) sub4 a0) sub4)) Positive.none)
theorem h656 (ρ : Env) (a0 : Fits s25 (ρ 0)) : All tab ρ b6 s114 :=
  (consAll (lamAt d39 c39 (smaller (h536 (Types.cons s27 ρ) sub14 a0) sub178)) Positive.none)
theorem h657 (ρ : Env) (a0 : Fits s17 (ρ 0)) : All tab ρ b6 s137 :=
  (consAll (lamAt d23 c23 (smaller (h537 (Types.cons s16 ρ) sub10 a0) sub15)) Positive.none)
theorem h658 (ρ : Env) (a0 : Fits s17 (ρ 0)) : All tab ρ b6 s71 :=
  (consAll (lamAt d6 c6 (smaller (h538 (Types.cons s3 ρ) sub15 a0) sub15)) Positive.none)
theorem h659 (ρ : Env) (a0 : Fits s14 (ρ 0)) : All tab ρ b6 s178 :=
  (consAll (lamAt d47 c47 (smaller (h539 (Types.cons s20 ρ) sub18 a0) sub179)) Positive.none)
theorem h660 (ρ : Env) (a0 : Fits s34 (ρ 0)) : All tab ρ b6 s138 :=
  (consAll (lamAt d53 c53 (smaller (h540 (Types.cons s37 ρ) sub114 a0) sub247)) Positive.none)
theorem h661 (ρ : Env) (a0 : Fits s34 (ρ 0)) : All tab ρ b6 s169 :=
  (consAll (lamAt d56 c56 (smaller (h541 (Types.cons s39 ρ) sub116 a0) sub116)) Positive.none)
theorem h662 (ρ : Env) (a0 : Fits s38 (ρ 0)) : All tab ρ b6 s39 :=
  (consAll (lamAt d55 c55 (smaller (h542 (Types.cons s5 ρ) sub2 a0) sub182)) Positive.none)
theorem h663 (ρ : Env) (a0 : Fits s32 (ρ 0)) : All tab ρ b6 s143 :=
  (consAll (lamAt d18 c18 (smaller (h543 (Types.cons s5 ρ) sub2 a0) sub2)) Positive.none)
theorem h664 (ρ : Env) (a0 : Fits s34 (ρ 0)) : All tab ρ b6 s5 :=
  (consAll (lamAt d9 c9 (smaller (h544 (Types.cons s6 ρ) sub4 a0) sub4)) Positive.none)
theorem h665 (ρ : Env) (a0 : Fits s18 (ρ 0)) : All tab ρ b6 s5 :=
  (consAll (lamAt d9 c9 (smaller (h545 (Types.cons s6 ρ) sub4 a0) sub4)) Positive.none)
theorem h666 (ρ : Env) (a0 : Fits s32 (ρ 0)) : All tab ρ b6 s115 :=
  (consAll (lamAt d51 c51 (smaller (h546 (Types.cons s35 ρ) sub22 a0) sub182)) Positive.none)
theorem h667 (ρ : Env) (a0 : Fits s18 (ρ 0)) : All tab ρ b6 s139 :=
  (consAll (lamAt d59 c59 (smaller (h547 (Types.cons s5 ρ) sub2 a0) sub196)) (consAll (lamAt d65 c65 (smaller (h550 (Types.cons s45 ρ) sub120 a0) sub197)) Positive.none))
theorem h668 (ρ : Env) (a0 : Fits s41 (ρ 0)) : All tab ρ b6 s71 :=
  (consAll (lamAt d6 c6 (smaller (h548 (Types.cons s3 ρ) sub15 a0) sub15)) Positive.none)
theorem h669 (ρ : Env) (a0 : Fits s41 (ρ 0)) : All tab ρ b6 s170 :=
  (consAll (lamAt d62 c62 (smaller (h549 (Types.cons s16 ρ) sub10 a0) sub248)) Positive.none)
theorem h670 (ρ : Env) (a0 : Fits s46 (ρ 0)) : All tab ρ b6 s71 :=
  (consAll (lamAt d6 c6 (smaller (h551 (Types.cons s3 ρ) sub15 a0) sub15)) Positive.none)
theorem h671 (ρ : Env) (a0 : Fits s46 (ρ 0)) : All tab ρ b6 s52 :=
  (consAll (lamAt d69 c69 (smaller (h552 (Types.cons s5 ρ) sub2 a0) sub184)) Positive.none)
theorem h672 (ρ : Env) (a0 : Fits s44 (ρ 0)) : All tab ρ b6 s142 :=
  (consAll (lamAt d73 c73 (smaller (h553 (Types.cons s51 ρ) sub122 a0) sub249)) Positive.none)
theorem h673 (ρ : Env) (a0 : Fits s44 (ρ 0)) : All tab ρ b6 s171 :=
  (consAll (lamAt d75 c75 (smaller (h554 (Types.cons s52 ρ) sub124 a0) sub124)) Positive.none)
theorem h674 (ρ : Env) (a0 : Fits s43 (ρ 0)) : All tab ρ b6 s143 :=
  (consAll (lamAt d18 c18 (smaller (h555 (Types.cons s5 ρ) sub2 a0) sub2)) Positive.none)
theorem h675 (ρ : Env) (a0 : Fits s44 (ρ 0)) : All tab ρ b6 s5 :=
  (consAll (lamAt d9 c9 (smaller (h556 (Types.cons s6 ρ) sub4 a0) sub4)) Positive.none)
theorem h676 (ρ : Env) (a0 : Fits s41 (ρ 0)) : All tab ρ b6 s5 :=
  (consAll (lamAt d9 c9 (smaller (h557 (Types.cons s6 ρ) sub4 a0) sub4)) Positive.none)
theorem h677 (ρ : Env) (a0 : Fits s43 (ρ 0)) : All tab ρ b6 s119 :=
  (consAll (lamAt d71 c71 (smaller (h558 (Types.cons s49 ρ) sub36 a0) sub184)) Positive.none)
theorem h678 (ρ : Env) (a0 : Fits s41 (ρ 0)) : All tab ρ b6 s144 :=
  (consAll (lamAt d78 c78 (smaller (h559 (Types.cons s16 ρ) sub10 a0) sub198)) (consAll (lamAt d92 c92 (smaller (h568 (Types.cons s48 ρ) sub45 a0) sub200)) Positive.none))
theorem h679 (ρ : Env) (a0 : Fits s46 (ρ 0)) : All tab ρ b6 s16 :=
  (consAll (lamAt d24 c24 (smaller (h560 (Types.cons s17 ρ) sub17 a0) sub4)) Positive.none)
theorem h680 (ρ : Env) (a0 : Fits s56 (ρ 0)) : All tab ρ b6 s71 :=
  (consAll (lamAt d6 c6 (smaller (h561 (Types.cons s3 ρ) sub15 a0) sub15)) Positive.none)
theorem h681 (ρ : Env) (a0 : Fits s56 (ρ 0)) : All tab ρ b6 s172 :=
  (consAll (lamAt d84 c84 (smaller (h562 (Types.cons s5 ρ) sub2 a0) sub199)) Positive.none)
theorem h682 (ρ : Env) (a0 : Fits s59 (ρ 0)) : All tab ρ b6 s146 :=
  (consAll (lamAt d88 c88 (smaller (h563 (Types.cons s61 ρ) sub130 a0) sub250)) Positive.none)
theorem h683 (ρ : Env) (a0 : Fits s59 (ρ 0)) : All tab ρ b6 s173 :=
  (consAll (lamAt d91 c91 (smaller (h564 (Types.cons s63 ρ) sub132 a0) sub132)) Positive.none)
end Blc.H45.H45F9692715709398
