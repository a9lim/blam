"""Give the repository's archive selector a genuine per-wire root in each proof partition."""
from genlean import expr,lc
from seal_groups import D
from jsonstream import ledger
import json
def main():
 proofs=(D/'residual-proof-roots.txt').read_text().split()
 num=0;out=D/'attached-ledger.tmp'
 with out.open('w') as fh:
  fh.write('[\n')
  for ix,row in enumerate(ledger(D/'ledger.json')):
   if row['module']!='H45Bridge' and row['strength']=='complete' and not row['kind'].startswith('W'):
    if num in (0,2560,5120):
     j=num//2560;old=row.get('individual_module',row['module']);th=row.get('individual_theorem',row['theorem'])
     s=row['wire'];n='e'+str(int(s,2));m=f'AttachPart{j}';ns='Blc.Floor45.'+m;part=proofs[j]
     data=part.replace('Proof','Data')
     src=[f'import {part}',f'import {old}','namespace '+ns,'open Term SelfintLowerBound SelfintControl Round3Floor38',
          'set_option maxRecDepth 12000',f'def {n} : Term := '+expr(lc.decode(s)[0]),f'theorem wire_{n} : Closed {n} ∧ code {n} = {int("1"+s,2)} := by decide',
          f'theorem partition_checked : Aggregate.Safe {data}.terms := {part}.checked',f'theorem ex_{n} : ¬ IsSelfInterpreter {n} := {th}',f'#print axioms ex_{n}','#print axioms partition_checked','end '+ns]
     (D/(m+'.lean')).write_text('\n'.join(src)+'\n')
     row.update(individual_module=old,individual_theorem=th,module=m,theorem=ns+'.ex_'+n,term=ns+'.'+n)
    num+=1
   if ix:fh.write(',\n')
   fh.write(json.dumps(row,separators=(',',':')))
  fh.write('\n]\n')
 assert num==7016
 out.replace(D/'ledger.json')
if __name__=='__main__':main()
