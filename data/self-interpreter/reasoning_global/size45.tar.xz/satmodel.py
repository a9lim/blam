"""Targeted monotone table synthesis in unary order encoding. SAT is discovery only."""
from grade_rows import calculus,inds
from probes import *
from harder import remain
import os,subprocess,signal,time
from functools import lru_cache
from pathlib import Path
CAD=Path.home()/'.elan/toolchains/leanprover--lean4---v4.32.2/bin/cadical'
class Limit(Exception):pass
class CNF:
 def __init__(self,path):
    self.count=1;self.nclauses=1;self.file=path.open('w');self.file.write('1 0\n')
 def v(self):
    self.count+=1
    if self.count>110000:raise Limit
    return self.count
 def add(self,*xs):
    if 1 in xs:return
    a=set(xs);a.discard(-1)
    if any(-p in a for p in a):return
    self.nclauses+=1
    if self.nclauses>500000:raise Limit
    self.file.write(' '.join(map(str,a))+' 0\n')
 def every(self,ls):
    ls=set(ls)-{1}
    if -1 in ls:return -1
    if not ls:return 1
    if len(ls)==1:return ls.pop()
    z=self.v()
    for x in ls:self.add(-z,x)
    self.add(z,*(-x for x in ls))
    return z
def synthesize(d,n,spec,timeout):
 f=CNF(d/'body');one=1;no=-1
 def fixed(i):return tuple(1 if j<=i else -1 for j in range(n)) + (-1,)
 def grade():
    vs=(1,)+tuple(f.v() for _ in range(1,n))+(-1,)
    for j in range(1,n-1):f.add(-vs[j+1],vs[j])
    return vs
 op=[[grade() if i<n-1 else fixed(n-1) for j in range(n)] for i in range(n)]
 for i in range(n):
    for j in range(n):
      for k in range(1,n):
        if i:f.add(-op[i-1][j][k],op[i][j][k])
        if j:f.add(-op[i][j-1][k],op[i][j][k])
 floor=grade();f.add(-floor[n-1])
 c,r=grade(),grade()
 @lru_cache(None)
 def le(x,y):return f.every(f.every([-x[k],]) if y[k]==-1 else 1 if x[k]==-1 or y[k]==1 or x[k]==y[k] else y[k] if x[k]==1 else -f.every([x[k],-y[k]]) for k in range(1,n))
 def select(x,y,exact):
    # Each upper constraint uses the least indices guaranteed by x and y. For
    # exact output the dual lower constraints use their greatest possible indices.
    if 1 in x[1:] and all(z in (1,-1) for z in x) and all(z in (1,-1) for z in y):
        return op[x.count(1)-1][y.count(1)-1]
    z=grade()
    for i in range(n):
      for j in range(n):
       for k in range(1,n):
        f.add(-x[i],-y[j],-op[i][j][k],z[k])
        if exact:f.add(x[i+1],y[j+1],op[i][j][k],-z[k])
    return z
 @lru_cache(None)
 def calc(t,env,exact):
    if t[0]=='V':return env[0]
    ds=dict(zip(inds(t),env))
    if t[0]=='A':
        def g(u):return calc(u,tuple(ds[i] for i in inds(u)),exact)
        return select(g(t[1]),g(t[2]),exact)
    b=t[1];gr=grade();f.add(le(floor,gr))
    vals=[calc(b,tuple(fixed(a) if i==0 else ds[i-1] for i in inds(b)),exact) for a in range(n)]
    for i in range(n):
        fits=f.every([-floor[i+1]]+[le(x,y) for x,y in zip(vals,op[i])])
        f.add(gr[i+1],fits)
        if exact:f.add(-fits,-gr[i+1])
    return gr
 def evalrho(t,exact):return calc(t,tuple(r if i==0 else c for i in inds(t)),exact)
 try:
    t,u,kind=spec
    if kind=='clock':
        f.add(le(fixed(n-1),c));f.add(le(fixed(n-1),r))
    actual=evalrho(t,False)
    want=floor if kind=='clock' else evalrho(u,True)
    f.add(-le(want,actual))
 except Limit:return
 finally:f.file.close();calc.cache_clear();le.cache_clear()
 with (d/'query.cnf').open('wb') as h:
    h.write(f'p cnf {f.count} {f.nclauses}\n'.encode())
    with (d/'body').open('rb') as body:
       import shutil;shutil.copyfileobj(body,h)
 try:q=subprocess.run([str(CAD),'-q','-t',str(timeout),str(d/'query.cnf')],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=timeout+3)
 except subprocess.TimeoutExpired:return
 if q.returncode!=10:return
 values={int(x) for ln in q.stdout.decode().splitlines() if ln.startswith('v ') for x in ln.split()[1:]}
 def value(g):return sum(i in values for i in g)-1
 tab=''.join(str(value(x)) for row in op for x in row);lo=value(floor);cc=value(c);rr=value(r)
 op0,pick,val=calculus(n,lo,tab)
 def v(t):return val(t,tuple(rr if i==0 else cc for i in inds(t)))
 a=v(t);w=lo if kind=='clock' else v(u)
 assert a<w,(n,lo,tab,cc,rr,a,w)
 return [n,lo,tab,cc,rr,a,w]
def explore(s,n,phase,sec):
 from clockprobes import getclock
 e=lc.decode(s)[0];d=HERE/'sat'/f'work{sys.argv[1]}';d.mkdir(parents=True,exist_ok=True)
 c=V(1);r=V(0);call=A(A(e,c),lc.bitlist(lc.enc(I),r));want=A(A(c,L(I)),r)
 opts=[('clock','0:0:0',e,None),('probe','0:0:0',call,want)]
 if phase>0:
    choices=[(1,1,1),(1,1,4),(0,1,4),(2,1,4),(0,1,7),(0,0,9),(1,0,8)]
    for pi,style,j in choices:
      id=f'{pi}:{style}:{j}'
      try:_,_,_,_,t,v,_,_=get(s,id)
      except (TypeError,IndexError,AssertionError):continue
      if wire(t)<=240:opts.append(('probe',id,t,v))
 for typ,ident,t,w in opts:
    if (z:=synthesize(d,n,(t,w,typ),sec)):return [typ,ident,*z]
if __name__=='__main__':
 d=HERE/'sat';d.mkdir(exist_ok=True);ss=remain()[int(sys.argv[1])::int(sys.argv[2])]
 for s in ss:
    dest=d/(s+'.json')
    if dest.exists():continue
    if z:=explore(s,int(sys.argv[3]),int(sys.argv[4]),int(sys.argv[5])):dest.write_text(json.dumps(z))
