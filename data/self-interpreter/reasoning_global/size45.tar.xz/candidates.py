import sys
sys.dont_write_bytecode = True
from pathlib import Path
from functools import lru_cache
from collections import Counter
import json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
ARCH=ROOT/'data/self-interpreter/reasoning_162/floor38'
sys.path.insert(0,str(ARCH))
from size39 import V,L,A,I,KI,lc,spine,chain,b,w,red,head_path,at,free,width,counts,occ
from grammar import b,w
b.cache_clear()
# Completely independent of source grammars. A step is admitted only if its
# materialized result fits the bit ceiling (including before substitution).
from size38 import subpaths
CAP=800
@lru_cache(32768)
def wire(t):
    if t[0]=='V':return 2+t[1]
    return 2+sum(wire(x) for x in t[1:])
def bounded(t,p):
    f,a=at(t,p)[1:];body=f[1]
    # Conservative bound on substitution; each copy's free occurrences
    # can move inwards by at most the depth of the body.
    if wire(t)>CAP:return None
    u=red(t,p)  # before this call there are at most CAP/2 nodes; even the
                 # quadratic one-step worst case fits 90,000 allocated nodes.
    return u if wire(u)<=CAP else None
def normal_path(t):
    if t[0]=='V':return None
    if t[0]=='L':
        p=normal_path(t[1]);return None if p is None else ['under']+p
    if t[1][0]=='L':return []
    p=normal_path(t[1])
    if p is not None:return ['left']+p
    p=normal_path(t[2]);return None if p is None else ['right']+p
@lru_cache(32768)
def measure(t,d):
    if t[0]=='V':
        m=1<<t[1] if t[1]<d else 0
        return m,m.bit_count()
    if t[0]=='L':
        m,w=measure(t[1],d+1);return m>>1,w
    a,v=measure(t[1],d);b,w=measure(t[2],d)
    return a|b,max(v,w,(a|b).bit_count())
def sourcefact(t):
    lead,h,args=spine(t)
    if wire(t)<45:return 'smaller'
    if lead>=3:return 'three'
    body=t
    for _ in range(lead):body=body[1]
    if chain(body):return 'chain'
    if measure(body,0)[1]<3:return 'width'
    return None
def test(e):
    q=A(A(e,V(1)),lc.bitlist('0010',V(0)))
    for mode,t in [('source',e),('identity',q)]:
        seen=set();ps=[]
        for _ in range(96):
            if t in seen:break
            seen.add(t)
            if mode=='source':
                k=sourcefact(t)
                if k:return [k,ps]
            if b(t):return ['W'+mode,ps]
            lead,h,args=spine(t)
            if h[0]=='V':
                if mode=='source':
                    if lead!=2 or (h==V(1) and len(args)!=2):return ['sourceHead',ps]
                    break
                if (lead,h,len(args))!=(0,V(1),2):return ['identityHead',ps]
                for j,(u,v) in enumerate(zip(args,[KI,V(0)])):
                    qs=[]
                    for _ in range(50):
                        if normal_path(u) is None:
                            if u!=v:return ['payload',ps,j,qs]
                            break
                        p=normal_path(u);u=bounded(u,p)
                        if u is None:break
                        qs.append(p)
                break
            p=head_path(t)
            if p is None:break
            t=bounded(t,p)
            if t is None:break
            ps.append(p)
    return ['open']
def main():
    rows={}; kinds=Counter()
    for line in sorted((HERE/'wires.txt').read_text().splitlines()):
        e=lc.decode(line)[0]
        r=test(e);rows[line]=r;kinds[r[0]]+=1
        if r[0]=='open':print(line,lc.show(e),flush=True)
        if len(rows)%200==0:b.cache_clear();w.cache_clear()
    (HERE/'certs.json').write_text(json.dumps(rows,separators=(',',':')))
    print(kinds)
if __name__=='__main__':main()
