from candidates import *
from smart_probe import apps_spine
from collections import defaultdict
def live(t):
    if t[0]=='V':return 0
    if t[0]=='L':return int(bool(occ(t[1])))+live(t[1])
    return live(t[1])+live(t[2])
def report(file):
    bytr=defaultdict(Counter);forms=Counter();fam=Counter()
    for s in file.read_text().split():
        t=lc.decode(s)[0];k='literal' if t[0]=='L' else 'app'
        b=t if k=='app' else t[1]
        h,args=apps_spine(b)
        sig=k+':'+h[0]+':'+str(len(args))
        bytr[counts(t)][k]+=1;forms[sig]+=1;fam[(k,live(t))]+=1
    return bytr,forms,fam
if __name__=='__main__':
    for age,p in [(42,HERE/'wires.txt'),(40,ROOT/'tmp/recheck/size40/wires.txt')]:
        by,sh,fa=report(p);print(age,'triples',sorted(by.items()),'root spines',sorted(sh.items()),'live',fa)
