from fast_extras import *
from harder import remain
from functools import lru_cache
from collections import deque
def nodes(t,p=(),d=0):
 yield t,p,d
 if t[0]=='L':yield from nodes(t[1],p+('under',),d+1)
 if t[0]=='A':
    yield from nodes(t[1],p+('left',),d);yield from nodes(t[2],p+('right',),d)
@lru_cache(16000)
def gaps(t):
 if t[0]=='V':return (t[1],)
 if t[0]=='L':return tuple(x-1 for x in gaps(t[1]) if x)
 return tuple(sorted(set(gaps(t[1]))|set(gaps(t[2]))))
def replace(t,p,u):
 if not p:return u
 if p[0]=='under':return L(replace(t[1],p[1:],u))
 if p[0]=='left':return A(replace(t[1],p[1:],u),t[2])
 return A(t[1],replace(t[2],p[1:],u))
def compress(t):
 for v,p,_ in nodes(t):
    if wire(v)<12:continue
    choices=Counter()
    for a,_,d in nodes(v):
       if wire(a)<6 or not (not gaps(a) or min(gaps(a))>=d):continue
       choices[lc.shift(-d,0,a)]+=1
    for a,m in choices.items():
       if m<2:continue
       def body(v,d=0):
          if v==lc.shift(d,0,a):return V(d)
          if v[0]=='V':return V(v[1]+int(v[1]>=d))
          if v[0]=='L':return L(body(v[1],d+1))
          return A(body(v[1],d),body(v[2],d))
       u=replace(t,p,A(L(body(v)),a))
       if wire(u)<wire(t):
          assert red(u,list(p))==t
          yield u,list(p)
def find(s):
 e=lc.decode(s)[0];q=deque([(e,[])]);seen={e};tried=0
 while q and tried<450:
    t,ps=q.popleft();tried+=1
    # Also try two nested let factors on the promising smaller intermediate.
    for u,p in compress(t):
       if wire(u)<45:return [lc.enc(u),ps,[p]]
       if wire(u)<59:
          for v,q2 in compress(u):
             if wire(v)<45:return [lc.enc(v),ps,[q2,p]]
    if len(ps)>=7:continue
    for v,p,_ in nodes(t):
       if v[0]!='A' or v[1][0]!='L':continue
       u=red(t,list(p))
       if wire(u)<=102 and u not in seen:
          seen.add(u);q.append((u,ps+[list(p)]))
if __name__=='__main__':
 d=HERE/'factors';d.mkdir(exist_ok=True)
 for s in remain():
    if z:=find(s):(d/(s+'.json')).write_text(json.dumps(z))
