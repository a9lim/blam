# Size 45

All 427,114 rows are resolved. The merged ledger has 403,617 finite predicates and 23,497 closed negative theorems. The original 7,071 residuals supplied 45 late finite predicates and 7,026 direct theorems. The final ten use two common-reduct collisions and eight recursive type proofs from the size-43 helper. All 292 helper modules are copied locally. Local replay passed for the full ledger, all four literal lists, all 7,257 selected Lean modules and the per-wire axiom comparison.

The canonical clean archive check is recorded in archive-check.log and archive-check.metrics in this working directory. The successful compiler measurements are in the extracted .checked directory. REPORT-45.md describes the complete classification and trust boundary.
