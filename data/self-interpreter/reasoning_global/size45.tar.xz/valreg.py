from hard import *
from regscan import probeType
from functools import lru_cache
from harder import remain
base_transfer=regular.transfers
@lru_cache(512)
def fv(nodes):
 acc=[]
 for x in reversed(nodes):
    if x[0]=='V':a=(x[1],)
    elif x[0]=='C':a=()
    elif x[0]=='L':a=tuple(i-1 for i in acc[len(nodes)-1-x[1]] if i)
    else:a=tuple(sorted(set(acc[len(nodes)-1-x[1]])|set(acc[len(nodes)-1-x[2]])))
    acc.append(a)
 return tuple(reversed(acc))
def search(q,depth,alias,which,keep,cap=3200,sec=.09):
 nodes=tuple(regular.compile_term(mask(q)));free=fv(nodes)
 @lru_cache(8000)
 def clip(adr,n):
    if not n:return ()
    return (adr[0],tuple(clip(a,n-1) for a in adr[1]))
 def transfers(nodes,s,vals,konts,k,mode):
    p,env,sp,ctx=s;node=nodes[p]
    if node[0]!='L' or sp is None:return base_transfer(nodes,s,vals,konts,k,mode)
    nxt=[];up=[]
    for arg,rest,site in konts.get(sp,()):
       ap,ae=arg
       if alias and nodes[ap][0]=='V':adr=ae[nodes[ap][1]]
       else:
         vv=[ae[i] for i in free[ap] if i<len(ae)]
         if keep==1:vv=vv[:1]
         if keep==2:vv=vv[-1:]
         key=ap if which==0 else (p,ap) if which==1 else (site,ap)
         adr=(key,tuple(clip(a,depth-1) for a in vv))
       nxt.append((node[1],(adr,)+env,rest,()));up.append(('V',adr,arg))
    return nxt,up,None
 regular.transfers=transfers
 try:
    try:r=regular.discover(mask(q),0,cap=cap,seconds=sec,mode='site')
    except (regular.Limit,RecursionError):return
    if r['ok'] and r['states']<=2400:return portable.portable(r)
 finally:regular.transfers=base_transfer
def find(s):
 e=lc.decode(s)[0]
 for depth,alias,which,keep in [(1,1,0,0),(2,1,0,0),(3,1,0,0),(2,1,1,0),(2,0,0,0),(4,1,0,1),(4,1,0,2),(2,1,2,0)]:
  for kind in ['raw','rigid','apply','extra2','extra4','extra6','suffix']:
   q=probeType(e,kind)
   for j in [0,3]:
    t=q;ps=[]
    for _ in range(j):
       pp=variant(t,1)
       if pp is None:break
       t=bounded(t,pp);ps.append(pp)
       if t is None:break
    if t is None or len(ps)!=j:continue
    z=search(t,depth,alias,which,keep)
    if z:return [len(z['states']),kind,j,depth,f'closure:{alias}:{which}:{keep}',ps,z]
if __name__=='__main__':
 for s in remain():
    p=HERE/('r'+str(int(s,2))+'.json')
    if p.exists():continue
    if z:=find(s):p.write_text(json.dumps(z))
