"""Select independent aggregate groups whose dependencies have finished local replay."""
from recheck import D,LIB
import hashlib,re,json
from functools import lru_cache
@lru_cache(None)
def state(name):
 p=D/(name+'.lean');s=p.read_bytes();h=hashlib.sha256(s);ready=True
 for b in re.findall(rb'^import ([\w.]+)',s,re.M):
  dep=b.decode()
  if (D/(dep+'.lean')).exists():
   k,ok,_=state(dep);h.update(k.encode());ready &=ok
  else:
   st=(LIB/(dep.replace('.','/')+'.olean')).stat();h.update(str((st.st_size,st.st_mtime_ns)).encode())
 key=h.hexdigest();p=D/'.checked'/(name+'.json')
 good=p.exists() and (D/'.checked'/(name+'.olean')).exists() and json.loads(p.read_text())['hash']==key
 return key,good and ready,ready
if __name__=='__main__':
 print(' '.join(p.stem for p in sorted(D.glob('ResidualGroup*.lean')) if state(p.stem)[1:]==(False,True)))
