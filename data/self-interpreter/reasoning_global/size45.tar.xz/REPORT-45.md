# The global lower bound is 46 bits

Every exact closed-source BLC self-interpreter has at least 46 bits. The exclusions through size 44 and the exhaustive size-45 partition yield this bound. All 427,114 candidate layouts have positive certificates. The ledger contains 403,617 finite predicates and 23,497 direct Lean exclusions of literal terms. This is a computer-assisted classification. The library lower-bound theorem checked at the start of this replay is Blc.SelfintKernelFloor44.selfintSizeBound_44.

## Why the enumeration covers every minimum

Let E be a minimum-length exact self-interpreter of size 45. A beta reduct of E is an interpreter. A contraction anywhere in E that makes the wire shorter contradicts minimality. In applying this argument to all length-45 interpreters, the previous exclusions through length 44 give global minimality.

With L lambdas, V variable occurrences and X the sum of zero-based de Bruijn indices, a closed tree has V−1 applications and size 2L+4V−2+X. The capture-width witness supplies three distinct captured binders on one ancestor chain, with occurrence indices costing at least 0+1+2. There are two incomparable nonlinear binders. At most one belongs to that chain, so the source has at least four live binders and at least six variable leaves. Seven live binders would require at least nine leaves and cost at least 51. Six are possible at 45, exactly at (L,V,X)=(6,8,3). The enumeration admits them.

An application root has no additional literal restriction. At a lambda root, two leading lambdas cost at least 46 by the two-public-binder interface bound. In the remaining root λc.B the public continuation occurs in B, and the single-object one-lambda width theorem requires a three-binder capture witness internal to B. Both incomparable nonlinear binders are internal because the public lambda is comparable to every binder. There are at least four live internal binders and six internal leaves, in addition to c and its occurrence.

For each permitted triple, enum.cpp generates the ordered unary/binary skeleton by open child count, then assigns each leaf every enclosing binder subject to the exact index sum. Subtree intervals decide incomparability, occurrence counts decide nonlinearity, and bottom-up free-binder masks decide width. Literal roots drop c from each mask. At a redex (λx.B) A the size change is (k−1)|A|+(f−1)D−2k−4−g, where k counts occurrences of x, D sums their nesting depths in B, f counts free occurrences in A, and g counts occurrences in B above x. The test discards a negative change at any redex and retains zero. It assumes no bound on beta normalization.

Rust traversed all 2,933,097,201 closed terms, with 3,184,752 surviving the structural and literal conditions before contraction. A separate Rust implementation constructs the capture-avoiding substitution at every redex in this latter set. Its retained set agrees exactly with the triple enumerator's 427,114 wires. The repository C audit counted 139,132,360 with an incomparable nonlinear pair, 9,382,936 also of width three and 1,933,272 also without a shortening contraction. It retained all 341,738 of the lane's application roots. Of its omitted literals 987,424 have two leading lambdas, 87,812 have a dead continuation and 430,922 lack the internal width witness, tested in that order. The lane has 85,376 literals. The independent wire and finite-predicate replay verified 403,617 endpoint predicates, 23,497 direct declaration-to-wire mappings. No wire difference is unexplained.

The complete per-triple counts are in triples.tsv. At application roots the numbers with four, five and six live binders are respectively 176,416, 153,666 and 11,656. At literal roots 74,540 have five and 10,836 have six. The complete root-spine signature counts are in root-shapes.tsv. Compared with 44, application roots newly admit a four-lambda head with one argument (624), a three-lambda head with two arguments (240), and a one-lambda head with three arguments (132). Literal bodies newly admit the first two shapes (60 and 360). The positive (L,V) resource pairs newly represented are (4,9), (6,8), (8,7) and (10,6).

| L | V | X | After structure and literal filters, before contraction | Application | Literal |
|---:|---:|---:|---:|---:|---:|
| 4 | 6 | 15 | 0 | 0 | 0 |
| 4 | 7 | 11 | 0 | 0 | 0 |
| 4 | 8 | 7 | 15,840 | 11,000 | 0 |
| 4 | 9 | 3 | 70,528 | 26,392 | 0 |
| 5 | 6 | 13 | 0 | 0 | 0 |
| 5 | 7 | 9 | 8,416 | 3,422 | 0 |
| 5 | 8 | 5 | 587,104 | 109,666 | 30,656 |
| 6 | 6 | 11 | 1,032 | 408 | 0 |
| 6 | 7 | 7 | 402,448 | 61,084 | 13,404 |
| 6 | 8 | 3 | 660,560 | 44,148 | 23,688 |
| 7 | 6 | 9 | 42,936 | 6,478 | 0 |
| 7 | 7 | 5 | 1,101,632 | 62,022 | 16,044 |
| 8 | 6 | 7 | 140,832 | 9,132 | 0 |
| 8 | 7 | 3 | 117,760 | 6,300 | 1,584 |
| 9 | 6 | 5 | 34,152 | 1,590 | 0 |
| 10 | 6 | 3 | 1,512 | 96 | 0 |

## Certificate ledger

| Selected evidence | Application | Literal | Total |
|---|---:|---:|---:|
| Reduct shorter than 45 | 80,676 | 5,087 | 85,763 |
| Nonlinear binders on one chain | 89,845 | 8,951 | 98,796 |
| Insufficient internal capture width | 49,332 | 4,509 | 53,841 |
| At least three leading lambdas | 46,826 | 9,262 | 56,088 |
| Impossible source head | 33,714 | 55,247 | 88,961 |
| Impossible identity-call head | 13,043 | 854 | 13,897 |
| Wrong normal payload or remainder | 5,385 | 886 | 6,271 |
| W/B on source reduct | 15,929 | 499 | 16,428 |
| W/B on identity-call reduct | 41 | 2 | 43 |
| Finite ordered table on closed source | 5,299 | 70 | 5,369 |
| Finite ordered table after a probe | 225 | 2 | 227 |
| Regular Krivine invariant | 659 | 3 | 662 |
| Single-object source reduct | 163 | 3 | 166 |
| Single-object continuation probe | 8 | 1 | 9 |
| Dead public continuation | 173 | 0 | 173 |
| All-size weighted rank | 343 | 0 | 343 |
| Weak-head observation mismatch | 32 | 0 | 32 |
| Missing required free variable | 7 | 0 | 7 |
| Recursive intersection-type table | 23 | 0 | 23 |
| Reused table with bottom propagation | 5 | 0 | 5 |
| Shared-reduct head mismatch | 2 | 0 | 2 |
| Recursive types on the final probes | 8 | 0 | 8 |

Every beta reduct still interprets by confluence. The shorter-reduct predicate therefore uses the previous-size exclusions. For the chain predicate, each application must put every nonlinear binder in at most one of its children, recursively. A leading lambda is an ancestor of every binder below it. Stripping the prefix preserves every incomparable pair. A reduct satisfying the chain predicate contradicts the nonlinear-pair theorem.

Three leading lambdas leave a lambda after the two public arguments have been supplied. The identity test requires an output headed by its fresh continuation. A closed head normal form with one leading lambda has the form λc.c A₁ … Aₖ. After the call, the nonempty encoded identity stream is the last argument. Arity two forces k = 1, and this stream would have to join the fresh rigid remainder, impossible since the stream begins with a lambda. With two leading lambdas and a continuation head, the argument count must be two. The two-lambda stream-head case passes the source-head predicate. On an actual identity call the required head signature is (zero lambdas, variable 1, two arguments), using zero-based de Bruijn indices. A head normal form preserves its signature under further beta steps. Decomposition and confluence further force its two arguments to join the required payload and remainder. A reached normal form differing from the appropriate component refutes this obligation.

For the internal-width predicate, use global capture width at prefix length zero and the one-public-lambda theorem at prefix length one. At length two instantiate the public binders by the closed continuation and stream of the pairing projection, then apply its closed projection argument. The required output has a three-variable capture witness. Each inserted term is closed and has insufficient width on its own. The witness must use three internally bound variables of the source body. At longer prefixes the three-lambda obstruction already applies.

The W/B source certificate places the closed source in the grammar class B. Appending the two identity-test arguments preserves B in function position. A W/B identity certificate enters B at a positive reduct of the actual call. In each case the grammar's progress and substitution theorems rule out the required normal form. These proofs and the direct residual proofs conclude the literal proposition itself.

Each ledger row identifies its wire, root, resource triple, kind, strength, module and qualified theorem. Each accepted supplemental predicate is recorded in additional-finite.json. It supplies the 25 extra chain, 15 width and 5 shorter-reduct witnesses beyond the original 403,572 finite witnesses in certs.json.

## The 7,071 residual layouts

Further finite traces settle 45 original residuals. Direct negative propositions settle the remaining 7,026. residuals.tsv names every literal, statement, module, theorem and transitive axiom list. The three closed lists in SetProof01P000, SetProof01P001 and SetProof01P002 cover 2,560, 2,560 and 1,896 literals. FinalTen.checked0 covers ten more. Blc.Floor45.residuals_excluded applies the final theorem directly and composes it with the three separately proved premises. All four lists and the composition are checked. Of the 23,497 direct theorems, 22,968 use propext and Quot.sound. The other 529 also use Classical.choice.

The final ten ledger theorems are Blc.Floor45.Help45.ex_eN. Each has statement ¬ Blc.IsSelfInterpreter Blc.Floor45.eN for its original Batch definition. The identity bridge is rfl. All 292 proof modules from the helper archive are local package inputs. The common-reduct entries for rows 1 and 10 are selected once each. Independent Observe proofs of both reach the same conclusion, as described below.

| Row | Literal identifier N | Helper proof | This lane's non-identity probes |
|---:|---:|---|---|
| 1 | 9570311402454 | common_head | Checked mismatch on Church-false continuation and Church-true source |
| 2 | 9573528477238 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 3 | 9676763418166 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 4 | 9692402711770 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 5 | 9692402957530 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 6 | 9692402989098 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 7 | 9692402989698 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 8 | 9692715709398 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 9 | 9692869766666 | flow_types | 119 defined target observations, all actual calls at the 8,000-transition cap |
| 10 | 11219262979426 | common_head | Checked mismatch on Church-false continuation and Church-true source |

The independent mismatch proofs for rows 1 and 10 are in pending-observe-manifest.tsv. For each proof E receives Church false, the encoded Church true program and a rigid suffix. The actual weak head is a lambda after 4,177 Krivine transitions. The required result has rigid head variable 0 and arity zero after five transitions. Observe.excluded derives the contradiction. Theorems Blc.Floor45.PendingObserve9570311402454.excluded and Blc.Floor45.PendingObserve11219262979426.excluded are about the literal original Batch terms and use propext and Quot.sound. For rows 2–9 no cap supplied an exclusion. The raw source and one-argument tests, each capped at 30,000 transitions, are recorded independently in pending-probes.json. Rows 5 and 8 reached a lambda before receiving a continuation.

## Reproduction and trust

The unrestricted Rust enumerator, independent C enumeration and explicit beta-contraction comparison matched the triple enumerator's wire set. A single-worker complete inventory rerun took 413.67 seconds and peaked at 458,948,608 bytes. The final finite replay independently checks every literal, trace endpoint, declaration and partition. The static classification, the semantic implications of the seven finite predicates, and the connection from arbitrary syntax to the enumerators are handwritten. Positive finite endpoints, direct exclusions and their stated transitive axioms are kernel-checked. SAT, regular discovery, bounded probes and the packing and regeneration programs supply data. No cap provides a negative verdict.

The Lean replay runs at most four workers, each with -j2 -M 900, a 985,000,000-byte resident-memory guard and a 150-second timeout. A resource failure drains other workers before retrying that module alone. A transient missing repository import is retried after one minute. The aggregate is split to stay within the process limit. Earlier unaccepted discovery and diagnostic processes exceeded the requested limit, peaking at 2,096,201,728 and 1,204,699,136 bytes respectively.

The three verification commands run from the unpacked directory.

```sh
python3 -B recheck_inventory.py
python3 -B verify_ledger.py
python3 -B recheck.py
```

The default Lean driver schedules bounded 390-second slices until the selected proof modules pass. Giving --seconds 390 requests one slice, which exits 75 if work remains. Select a fresh cache with --stage .replay. Each compiler subprocess has a 150-second timeout. In the live lane, --frozen-batches protects the objects used by the helper.

slim.json omits 6,955 byte-reproducible files totaling 581,799,574 uncompressed bytes, including all 2,670 finite-certificate batches, all three recorded enumeration streams, and the complete ledger and theorem tables. regen.py uses retained witness data and local generator sources, checks every reconstructed digest, then installs the output. The archived C auditor is compiled as C using cc -x c. The three check scripts run against the extracted package and the repository's prebuilt Lean library.

The canonical pack and clean-check commands are

```sh
python3 data/self-interpreter/reasoning_global/pack.py pack 45 tmp/global/floor46
python3 data/self-interpreter/reasoning_global/pack.py check 45
```

The successful clean run records per-module times and peak memory in the extracted .checked directory. Its summary counts compiled modules and checks every direct theorem's printed axiom list against complete.tsv.
