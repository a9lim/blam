"""Give each bounded-memory proof partition an explicit, literal-only list and exact public type."""
import re
from pathlib import Path
from genlean import expr,lc
from jsonstream import ledger
D=Path(__file__).resolve().parent
def main():
 rows=[r for r in ledger(D/'ledger.json') if r['strength']=='complete' and not r['kind'].startswith('W')]
 final=[r for r in rows if r["module"]=="H45Bridge"]; rows=[r for r in rows if r["module"]!="H45Bridge"]
 assert len(final)==10 and len(rows)==7016
 from finalten import source
 (D/"FinalTen.lean").write_text(source(final))
 nodes=[]
 for i in range(0,len(rows),40):
  j=i//40;raw=f'PartData{j:03}';proof=f'PartProof{j:03}';old=f'ResidualGroup{j:03}';ns='Blc.Floor45.'
  lit=[expr(lc.decode(r['wire'])[0]) for r in rows[i:i+40]]
  (D/(raw+'.lean')).write_text('import Aggregate\nnamespace '+ns+raw+'\ndef terms : List Term := [\n  '+',\n  '.join(lit)+'\n]\nend '+ns+raw+'\n')
  (D/(proof+'.lean')).write_text(f'import {raw}\nimport {old}\nnamespace {ns}{proof}\ntheorem checked : Aggregate.Safe {raw}.terms := {old}.bad0\nend {ns}{proof}\n')
  nodes.append((raw,proof))
 level=0
 while len(nodes)>3:
  ns2=[]
  for i in range(0,len(nodes),8):
   parts=nodes[i:i+8];raw=f'SetData{level:02}P{i//8:03}';proof=f'SetProof{level:02}P{i//8:03}'
   data=['import '+a for a,b in parts]+['namespace '+ns+raw];rhs=parts[-1][0]+'.terms'
   for a,b in reversed(parts[:-1]):rhs=f'{a}.terms ++ ({rhs})'
   data+=['def terms : List Term := '+rhs,'end '+ns+raw]
   (D/(raw+'.lean')).write_text('\n'.join(data)+'\n')
   source=['import '+raw]+['import '+b for a,b in parts]+['namespace '+ns+proof];rh=parts[-1][1]+'.checked'
   for a,b in reversed(parts[:-1]):rh=f'(Aggregate.merge {a}.terms _ {b}.checked {rh})'
   source+=[f'theorem checked : Aggregate.Safe {raw}.terms := '+rh,'#print axioms checked','end '+ns+proof];(D/(proof+'.lean')).write_text('\n'.join(source)+'\n')
   ns2.append((raw,proof))
  nodes=ns2;level+=1
 assert len(nodes)==3
 a,b,c=[x+'.terms' for x,y in nodes]
 src=['import FinalTen']+['import '+r for r,_ in nodes]+['namespace Blc.Floor45',f'def residuals : List Term := {a} ++ ({b} ++ ({c} ++ FinalTen.xs0))',f'theorem residuals_excluded (first : Aggregate.Safe {a}) (second : Aggregate.Safe {b}) (third : Aggregate.Safe {c}) (t : Term) (h : t ∈ residuals) : ¬ IsSelfInterpreter t :=',f'  Aggregate.merge {a} _ first (Aggregate.merge {b} _ second (Aggregate.merge {c} FinalTen.xs0 third FinalTen.checked0)) t h','#print axioms residuals_excluded','end Blc.Floor45']
 (D/'Residuals.lean').write_text('\n'.join(src)+'\n')
 (D/'residual-proof-roots.txt').write_text(''.join(p+'\n' for _,p in nodes))
if __name__=='__main__':main()
