"""Recreate the original byte streams from the three archived enumeration algorithms."""
from pathlib import Path
import concurrent.futures,subprocess,tempfile
D=Path(__file__).resolve().parent
SPECS={
 'wires.txt':(['c++','-O3','-std=c++20','enum.cpp'],[]),
 'cross.txt':(['rustc','--edition=2021','-O','archive_cross.rs'],[]),
 'broad.txt':(['cc','-O3','-x','c','archive_broad.cpp'],['45'])}
def generate(dest,names):
 def one(name):
  cc,args=SPECS[name]
  with tempfile.TemporaryDirectory(dir=dest) as temp:
   exe=Path(temp)/'enumerator'
   subprocess.run([*cc,'-o',exe],cwd=D,check=True,timeout=60)
   stream=Path(temp)/'out'
   with stream.open('wb') as out:
    subprocess.run([exe,*args],cwd=D,stdout=out,stderr=subprocess.DEVNULL,check=True,timeout=495)
   stream.replace(dest/name)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  list(pool.map(one,sorted(names,key=lambda n:(n!="broad.txt",n!="cross.txt"))))
if __name__=='__main__':
 import sys
 generate(Path(sys.argv[1]).resolve(),SPECS)
