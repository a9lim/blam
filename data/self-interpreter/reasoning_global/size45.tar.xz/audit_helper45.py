"""Type-check the separately produced bridge against the original batch literals."""
import csv,json,os,re,subprocess,time
from recheck import D,TC,LIB,resident
def main():
 helper=D.parent/'floor44'/'help45';td=D/'.helper-audit';td.mkdir(exist_ok=True)
 rows=list(csv.DictReader((helper/'manifest.tsv').open(),delimiter='\t'))
 assert len(rows)==10 and {r['wire'] for r in rows}==set((D/'unresolved.txt').read_text().split())
 s=['import H45Bridge','namespace Blc.Floor45.PackageAudit']
 for i,r in enumerate(rows):
  n=int(r['wire'],2);assert r['statement']==f'¬ Blc.IsSelfInterpreter Blc.Floor45.e{n}'
  s.extend([f'theorem h{i} : {r["statement"]} := {r["theorem"]}',f'#print axioms h{i}'])
 s.append('end Blc.Floor45.PackageAudit');f=td/'CheckBridge.lean';f.write_text('\n'.join(s)+'\n')
 env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[helper/'obj',D/'.checked',LIB,TC/'lib/lean'])),LEAN_NUM_THREADS='2')
 ts=time.monotonic()
 for attempt in range(2):
  with (td/'check.log').open('w') as log:
   p=subprocess.Popen([TC/'bin/lean','-j2','-M','900','--root='+str(td),f],cwd=td,env=env,stdout=log,stderr=log)
   while True:
    pid,st,u=os.wait4(p.pid,os.WNOHANG)
    if pid:break
    if resident(p.pid)>=985000000 or time.monotonic()-ts>90:p.kill()
    time.sleep(.02)
   p.returncode=os.waitstatus_to_exitcode(st)
  if p.returncode!=-9:break
 assert p.returncode==0 and u.ru_maxrss<1000000000,(td/'check.log').read_text()
 result=(td/'check.log').read_text()
 for i,r in enumerate(rows):
  assert f"'Blc.Floor45.PackageAudit.h{i}' depends on axioms: [{r['axioms']}]" in result
  assert set(r['axioms'].split(', '))<={'propext','Classical.choice','Quot.sound'}
 print(len(rows),'exact helper theorem types and axiom lists verified;',round(time.monotonic()-ts,3),'seconds;',u.ru_maxrss,'bytes')
if __name__=='__main__':main()
