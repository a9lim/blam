// Untrusted finite-chain discovery on actual beta-reducts. Cache only free indices.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include <random>
#include <chrono>
using namespace std;
struct Node {int k,x,y;uint64_t fv;int off=0,cnt=0;vector<int> left,right;};
struct Row{int own,act,want;string id;};
vector<Node> ns;map<array<int,3>,int> ids;vector<vector<Row>> rs;vector<string> wires;
int intern(int k,int x,int y){
 array<int,3> a={k,x,y};if(auto it=ids.find(a);it!=ids.end())return it->second;
 if(k==0 && x>=48)throw runtime_error("index");
 auto fv=k==0?1ull<<x:k==1?ns[x].fv>>1:ns[x].fv|ns[y].fv;
 int p=ns.size();ns.push_back({k,x,y,fv});return ids[a]=p;
}
int parse(const string&s,int&i){if(s.at(i++)=='1'){int j=0;while(s.at(i++)=='1')++j;return intern(0,j,0);}
 if(s.at(i++)=='0')return intern(1,parse(s,i),0);int f=parse(s,i);return intern(2,f,parse(s,i));}
int term(const string&s){int i=0;int p=parse(s,i);if(i!=s.size())throw runtime_error("parse");return p;}
int k,base,m,ret[12],maskenv[24],need[12][16],appT[256][256];vector<int16_t> mem;
int projectKey(int key,uint64_t parent,uint64_t child){
 int ret=0,place=1;while(parent){auto b=parent&-parent;int v=key%base;key/=base;if(child&b){ret+=place*v;place*=base;}parent-=b;}return ret;}
void setup(int count){
 k=count;base=m+2;int off=0;
 for(auto &v:ns){int cnt=1;for(int i=0;i<popcount(v.fv);i++){cnt*=base;if(cnt>800000)throw runtime_error("cache cap");}
 v.off=off;v.cnt=cnt;off+=cnt;if(off>15000000)throw runtime_error("cache cap");
 if(v.k==2){v.left.resize(cnt);v.right.resize(cnt);for(int i=0;i<cnt;i++){v.left[i]=projectKey(i,v.fv,ns[v.x].fv);v.right[i]=projectKey(i,v.fv,ns[v.y].fv);}}}mem.resize(off);
}
int eval(int p,int key){
 auto &v=ns[p];auto &r=mem[v.off+key];if(r>=0)return r;
 if(v.k==0)return r=maskenv[key];
 int z=0;
 if(v.k==2){int f=eval(v.x,v.left[key]);if(!f)return r=0;
  int a=eval(v.y,v.right[key]);z=appT[f][a];}
 else {
    int reject=0;
    for(int j=0;j<m;j++){
      int out=eval(v.x,ns[v.x].fv&1?base*key+j:key);
      for(int i=0;i<k;i++)if(need[i][j]&~out)reject|=1<<i;
    }
    for(int i=0;i<k;i++)if(ret[i]>=0 && !(reject&(1<<i)))z|=1<<i;
 }
 return r=z;
}
int key(int p){switch(ns[p].fv){case 0:return 0;case 1:return m;case 2:return m+1;case 3:return m+(m+1)*base;default:throw runtime_error("open");}}
int leftrows;
int modelid; void trial(int cc,int rr){
 if(!leftrows)exit(0);
 maskenv[m]=rr;maskenv[m+1]=cc;
 fill(mem.begin(),mem.end(),-1);
 for(int i=0;i<int(rs.size());i++){
  bool win=false;for(const auto&row:rs[i]){
   int a=eval(row.act,key(row.act));if(!a)continue;
   int bad;
   if(row.id[0]=='!'){if(cc || rr)continue;bad=0;for(int j=0;j<k;j++)if(ret[j]<0)bad|=(a&(1<<j));}
   else bad=a&~eval(row.want,key(row.want));
   if(!bad)continue;
   cout<<wires[i]<<" "<<row.id<<" "<<modelid<<" "<<cc<<" "<<rr<<" "<<countr_zero((unsigned)bad)<<endl;
   win=true;break;
  }
  if(win){rs[i].clear();--leftrows;}
 }
}
int main(int argc,char**argv){
 ifstream in(argv[1]);string w,id,a,b;map<string,int>owners;
 while(in>>w>>id>>a>>b){if(!owners.count(w)){owners[w]=rs.size();rs.emplace_back();wires.push_back(w);}
 int i=owners[w];rs[i].push_back({i,term(a),term(b),id});}
 leftrows=rs.size();ifstream models(argv[2]);int n;modelid=-1;
 while(models>>n>>m){
    ++modelid;setup(n);
    if(k>8 || m>15)throw runtime_error("bounds");
    for(int j=0;j<m;j++)models>>maskenv[j];
    for(int i=0;i<k;i++){models>>ret[i];for(int j=0;j<m;j++)models>>need[i][j];}
    for(int f=0;f<(1<<k);f++)for(int a=0;a<(1<<k);a++){
        int z=0;for(int i=0;i<k;i++)if(f&(1<<i))for(int j=0;j<m;j++)if(!(maskenv[j]&~a))z|=need[i][j];appT[f][a]=z;
    }
    vector<int> keys={0,(1<<k)-1};for(int j=0;j<m;j++)keys.push_back(maskenv[j]);for(int i=0;i<k;i++)keys.push_back(1<<i);
    for(int c:keys)for(int r:keys)trial(c,r);
 }
}
