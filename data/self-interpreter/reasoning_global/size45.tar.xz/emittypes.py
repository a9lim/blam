from type_rows import *
from derivations import deriv
def main():
 import type_rows
 type_rows.main()
 for p in (HERE/'abstract').glob('*.json'):
    s=p.stem;id,graph,r,c,z=json.loads(p.read_text());num=int(s,2);nm=f'e{num}';mod=f'Atom{num}';ns='Blc.Floor45.'+mod
    n=len(graph);ls=['import MultiTypes','namespace '+ns,'open Term SelfintLowerBound SelfintControl SelfintSharp Round3Floor38 MultiTypes','set_option maxRecDepth 30000','set_option maxHeartbeats 6000000']
    for j,ars in enumerate(graph):
       if ars is not None:ls+=[f'def ars{j} : List (Arrow {n}) := '+rulestr(ars)[6:-1]]
    ls += [f'def graph (i : Fin {n}) : Option (List (Arrow {n})) := match i.val with']+[f'  | {j} => '+('none' if ars is None else f'some ars{j}') for j,ars in enumerate(graph)]+['  | _ => none',f'def env (i : Nat) : List (Fin {n}) := if i=1 then {natlist(c)} else {natlist(r)}']
    t=lc.decode(s)[0] if id=='!' else get(s,id)[4]
    proofs,ht=deriv(graph,t,r,c,z)
    prev='';block=[];parts=[]
    def flush():
       if not block:return
       name=mod+'D'+str(len(parts));base=ls if not parts else ['import '+parts[-1],*ls[1:5]]
       (HERE/(name+'.lean')).write_text('\n'.join(base+block+['end '+ns])+'\n');parts.append(name);block.clear()
    sz=0
    for line in proofs:
       block.append(line);sz+=len(line)
       if sz>24000:flush();sz=0
    flush()
    original=(HERE/(mod+'.lean')).read_text();a=original.index('private def endpoint') if id!='!' else original.index('theorem ex_')
    tail=original[a:].replace('  · decide\n  · decide\n  · decide','  · decide\n  · exact (correct graph _ _ _).mpr '+ht+'\n  · decide')
    if id=='!':ht=ht.replace(' env', ' (fun _ => [])');tail=tail.replace('((correct graph '+nm+' (fun _ => []) '+str(z)+').mp (by decide))',ht)
    (HERE/(mod+'.lean')).write_text('\n'.join(['import '+parts[-1],*ls[1:5],src(s,nm),tail]))
if __name__=='__main__':main()
