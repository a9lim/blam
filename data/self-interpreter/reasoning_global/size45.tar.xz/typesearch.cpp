// Untrusted finite-chain discovery on actual beta-reducts. Cache only free indices.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include <random>
#include <chrono>
using namespace std;
struct Node {int k,x,y;uint64_t fv;int off=0,cnt=0;vector<int> left,right;};
struct Row{int own,act,want;string id;};
vector<Node> ns;map<array<int,3>,int> ids;vector<vector<Row>> rs;vector<string> wires;
int intern(int k,int x,int y){
 array<int,3> a={k,x,y};if(auto it=ids.find(a);it!=ids.end())return it->second;
 if(k==0 && x>=48)throw runtime_error("index");
 auto fv=k==0?1ull<<x:k==1?ns[x].fv>>1:ns[x].fv|ns[y].fv;
 int p=ns.size();ns.push_back({k,x,y,fv});return ids[a]=p;
}
int parse(const string&s,int&i){if(s.at(i++)=='1'){int j=0;while(s.at(i++)=='1')++j;return intern(0,j,0);}
 if(s.at(i++)=='0')return intern(1,parse(s,i),0);int f=parse(s,i);return intern(2,f,parse(s,i));}
int term(const string&s){int i=0;int p=parse(s,i);if(i!=s.size())throw runtime_error("parse");return p;}
int k,base,req[12],ret[12],maskenv[12];vector<int16_t> mem;
int projectKey(int key,uint64_t parent,uint64_t child){
 int ret=0,place=1;while(parent){auto b=parent&-parent;int v=key%base;key/=base;if(child&b){ret+=place*v;place*=base;}parent-=b;}return ret;}
void setup(int count){
 k=count;base=k+2;int off=0;
 for(auto &v:ns){int cnt=1;for(int i=0;i<popcount(v.fv);i++){cnt*=base;if(cnt>800000)throw runtime_error("cache cap");}
 v.off=off;v.cnt=cnt;off+=cnt;if(off>15000000)throw runtime_error("cache cap");
 if(v.k==2){v.left.resize(cnt);v.right.resize(cnt);for(int i=0;i<cnt;i++){v.left[i]=projectKey(i,v.fv,ns[v.x].fv);v.right[i]=projectKey(i,v.fv,ns[v.y].fv);}}}mem.resize(off);
}
int eval(int p,int key){
 auto &v=ns[p];auto &r=mem[v.off+key];if(r>=0)return r;
 if(v.k==0)return r=maskenv[key];
 int z=0;
 if(v.k==2){int f=eval(v.x,v.left[key]);if(!f)return r=0;
  int a=eval(v.y,v.right[key]);while(f){int i=countr_zero((unsigned)f);f&=f-1;if(ret[i]>=0 && (req[i]&~a)==0)z|=1<<ret[i];}}
 else for(int i=0;i<k;i++)if(ret[i]>=0 && (eval(v.x,ns[v.x].fv&1?base*key+i:key)&(1<<ret[i])))z|=1<<i;
 return r=z;
}
int key(int p){switch(ns[p].fv){case 0:return 0;case 1:return k;case 2:return k+1;case 3:return k+(k+1)*base;default:throw runtime_error("open");}}
int leftrows;
void trial(int cc,int rr){
 if(!leftrows)exit(0);
 for(int i=0;i<k;i++)maskenv[i]=req[i];maskenv[k]=rr;maskenv[k+1]=cc;
 fill(mem.begin(),mem.end(),-1);
 for(int i=0;i<int(rs.size());i++){
  bool win=false;for(const auto&row:rs[i]){
   int a=eval(row.act,key(row.act));if(!a)continue;
   int bad;
   if(row.id[0]=='!'){bad=0;for(int j=0;j<k;j++)if(ret[j]<0)bad|=(a&(1<<j));}
   else bad=a&~eval(row.want,key(row.want));
   if(!bad)continue;
   cout<<wires[i]<<" "<<row.id<<" "<<k<<" ";
   for(int j=0;j<k;j++)cout<<req[j]<<":"<<ret[j]<<",";cout<<" "<<cc<<" "<<rr<<" "<<countr_zero((unsigned)bad)<<endl;
   win=true;break;
  }
  if(win){rs[i].clear();--leftrows;}
 }
}
void all(int i){if(i==k){trial(0,0);return;}
 for(int r=-1;r<k;r++)for(int q=0;q<(r<0?1:1<<k);q++){req[i]=q;ret[i]=r;all(i+1);}}
int main(int argc,char**argv){
 ifstream in(argv[1]);string w,id,a,b;map<string,int>owners;
 while(in>>w>>id>>a>>b){if(!owners.count(w)){owners[w]=rs.size();rs.emplace_back();wires.push_back(w);}
 int i=owners[w];rs[i].push_back({i,term(a),term(b),id});}
 leftrows=rs.size();setup(atoi(argv[2]));int rounds=atoi(argv[3]);if(!rounds){all(0);return 0;}
 mt19937 rng(atoi(argv[4]));
 for(int j=0;j<rounds;j++){
    for(int t=0;t<k;t++){
       ret[t]=(t==0 && j%2==0)?-1:rng()%k;int x=0;
       int size=rng()%(j%4+2);while(size--)x|=1<<int(rng()%k);
       req[t]=x;
    }
    trial(0,0);if(j%4==0)trial(1<<int(rng()%k),1<<int(rng()%k));
 }
}
