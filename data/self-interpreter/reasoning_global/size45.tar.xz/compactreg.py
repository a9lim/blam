from grade_rows import src
from emitreg import details, expr,paths,lc,red,appall,target_steps,A,HERE,wire,mask,regular
import json,sys
def numlist(xs):return '['+','.join(map(str,xs))+']'
def clo(x):return f'⟨{x[0]},{numlist(x[1])}⟩'
def fr(x):return f'⟨{clo(x[0])},{x[1]}⟩'
def state(x):return f'⟨⟨{x[0]},{numlist(x[1])}⟩,{x[2]}⟩'
def branch(a,b,key,leaf):
 if b-a==1:return leaf(a)
 mid=(a+b)//2
 return f'(if i < {key(mid)} then {branch(a,mid,key,leaf)} else {branch(mid,b,key,leaf)})'
def lookup(name,ty,ls,default):
 if not ls:return [f'def {name} (_ : Nat) : {ty} := {default}']
 # Split literal definitions to keep repeated reductions shallow.
 l=[];chunk=12
 for j in range(0,len(ls),chunk):
    val=branch(j,min(len(ls),j+chunk),lambda x:x,lambda x:ls[x])
    l.append(f'def {name}B{j} (i : Nat) : {ty} := {val}')
 groups=(len(ls)+chunk-1)//chunk
 val=branch(0,groups,lambda x:x*chunk,lambda x:f'{name}B{x*chunk} i')
 l.append(f'def {name} (i : Nat) : {ty} := if i < {len(ls)} then {val} else {default}')
 return l
def ranges(name,fn,n,stride=10):
 ls=[];blocks=[]
 for i in range(0,n,stride):
    end=min(i+stride,n);label=name+str(i)
    ls.append(f'theorem {label} : RegProof.Span {fn} {i} {end} := RegProof.block (n := {end-i}) (by decide +kernel)')
    blocks.append(label)
 def join(bs):
    if len(bs)==1:return bs[0]
    i=len(bs)//2;return '(RegProof.merge '+join(bs[:i])+' '+join(bs[i:])+')'
 ls.append(f'theorem {name}All : RegProof.Span {fn} 0 {n} := {join(blocks)}')
 return ls
def emit(p):
 r=json.loads(p.read_text());n,kind,j,k,mode,ps,c=r;num=int(p.stem[1:]);s=f'{num:045b}';name=f'Reg{num}';nm=f'e{num}';ns='Blc.Floor45.'+name;e=lc.decode(s)[0]
 if kind==['rigids',0]:kind='raw'
 if kind=='raw':q=e;start=nm;need='rawCount he'
 else:
    if isinstance(kind,list):
       _,w,aa=kind;cc,mm,rr=map(lambda s:lc.decode(s)[0],w);aa=[lc.decode(s)[0] for s in aa]
    else:cc,mm,rr,aa=details(kind)
    q=appall(A(A(e,cc),lc.bitlist(lc.enc(mm),rr)),aa)
    start=f'(call {nm} {expr(cc)} {expr(mm)} {expr(rr)} {numlist([expr(v) for v in aa])})';need=f'inputCount (k := {target_steps(cc,mm,rr,aa)}) he (by decide) (by decide)'
 t=q
 for pos in ps:t=red(t,pos)
 nodes=c['nodes'];assert regular.compile_term(mask(t))==list(map(tuple,nodes))
 ts=[]
 def flatten(t):
    ts.append(t)
    for x in t[1:]:
       if isinstance(x,tuple):flatten(x)
 flatten(t)
 code=['.opaque' if x[0]=='C' else '.var '+str(x[1]) if x[0]=='V' else '.lam '+str(x[1]) if x[0]=='L' else f'.app {x[1]} {x[2]}' for x in nodes]
 header=['import RegProof','namespace '+ns,'open Term SelfintLowerBound SelfintSharp SelfintRegularSoundness WeakHeadClock Certgen Round3Floor38','set_option maxRecDepth 17000','set_option maxHeartbeats 6000000']
 a=header.copy();a+=lookup('pCode','Certgen.Code',code,'.opaque')
 idx={t:i for i,t in enumerate(ts)}
 for t0 in sorted(idx,key=wire):
    ji=idx[t0];rhs=('.var '+str(t0[1]) if t0[0]=='V' else f'.lam lit{idx[t0[1]]}' if t0[0]=='L' else f'.app lit{idx[t0[1]]} lit{idx[t0[2]]}')
    a.append(f'def lit{ji} : Term := {rhs}')
 a+=lookup('getTerm','Term',[f'lit{idx[t]}' for t in ts],'.var 0')
 a+=['def align := RegProof.aligned getTerm pCode']+ranges('al','align',len(nodes))
 a+=['def mdl : Model pCode := RegProof.alignedModel getTerm pCode (by','  intro i',f'  by_cases h : i < {len(nodes)}','  · exact alAll i (by omega) h','  · simp [RegProof.aligned,pCode,h])']
 a+=lookup('values','List AClo',[numlist(map(clo,x)) for x in c['values']],'[]')
 a+=lookup('konts','List Frame',[numlist(map(fr,x)) for x in c['konts']],'[]')
 a+=lookup('getSt','AState',list(map(state,c['states'])),'entry')
 a+=lookup('hints','List Nat',list(map(numlist,c['hints'])),'[]')
 a.append(f'def ck (i : Nat) := FloorIndex.check pCode values konts (RegProof.states {n} getSt) i (hints i)')
 (HERE/(name+'Data.lean')).write_text('\n'.join(a+['end '+ns])+'\n')
 a=[f'import {name}Data',*header[1:]]
 a+=ranges('ok','ck',n)
 a += [src(s,nm),f'theorem excluded : ¬ IsSelfInterpreter {nm} := by',
       '  intro he',f'  have h : ∃ j, Count {start} j := {need}',f'  have hp : replay {paths(ps)} {start} = some (mdl.term 0) := by change _ = some (lit{idx[t]}); decide',
       '  obtain ⟨k,hk⟩ := clocks_replay h hp',f'  exact RegProof.noClock mdl {n} getSt hints (by decide) okAll (by decide) k hk','#print axioms excluded','end '+ns]
 (HERE/(name+'.lean')).write_text('\n'.join(a)+'\n')
 return name
if __name__=='__main__':
 for v in sys.argv[1:]:print(emit(HERE/v))
