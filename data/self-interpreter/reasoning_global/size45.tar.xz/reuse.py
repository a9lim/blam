from probes import *
from harder import remain
import subprocess
def go():
 ss=set(remain());groups=[];texts=[]
 for p in sorted((HERE/'abstract').glob('*.json')):
    _,g,*_=json.loads(p.read_text());ds=sorted({tuple(d) for ars in g if ars for d,z in ars})
    if g in groups:continue
    groups.append(g);line=[len(g),len(ds)]+[sum(1<<i for i in d) for d in ds]
    for a in g:line.extend([int(bool(a is not None))-1]+[sum(1<<i for i in set(z for d,z in a or [] if tuple(d)==dom)) for dom in ds])
    texts.append(' '.join(map(str,line)))
 bank=HERE/'typebank.in';bank.write_text('\n'.join(texts)+'\n')
 folder=HERE/'reuse';folder.mkdir(exist_ok=True);num=0
 for p in sorted((HERE/'probes').glob('*.in')):
    ln=[v for v in p.read_text().splitlines() if v.split(' ',1)[0] in ss]
    if not ln:continue
    terms={l.split(' ',1)[0] for l in ln}
    ln.extend(f'{s} ! {s} 10' for s in terms)
    f=folder/p.name;f.write_text('\n'.join(ln)+'\n')
    q=subprocess.run([str(HERE/'multisearch'),str(f),str(bank)],capture_output=True,text=True,timeout=110,check=True)
    for s,ident,j,c,r,z in map(str.split,q.stdout.splitlines()):
        g=groups[int(j)];ms=lambda v:[i for i in range(len(g)) if int(v)&(1<<i)]
        (HERE/'abstract'/(s+'.json')).write_text(json.dumps([ident,g,ms(r),ms(c),int(z)]));num+=1
 print('reused graphs',num)
if __name__=='__main__':go()
