"""Render the recorded witnesses in a scratch directory that contains only archive inputs."""
from pathlib import Path
import csv,json,re,sys,shutil
from itertools import batched
from collections import Counter
import archive_core as core,archive_regular
from jsonstream import pairs
D=Path(__file__).resolve().parent
# The original emitters also import their discovery libraries. Regeneration
# uses only the archived lambda syntax and the preorder code generator.
sys.modules.update(candidates=core,smart_probe=core,regular=archive_regular,portable=archive_regular)
import screen,grade_rows,gradederive,emittypes,extra_rows,probe_rows,observed,compactreg,genreg,faster_regular,release,seal_groups,attach_groups
from jsonstream import ledger
def rebuild_records(data):
 records=data['records'];choices=set(data['choice']);res=[];n=0;closed=[];pending=[];original=[]
 with (D/'ledger.json').open('w') as out,(D/'complete.tsv').open('w') as ff,(D/'residuals.tsv').open('w') as gg:
  fs=[csv.writer(f,delimiter='\t',lineterminator='\n') for f in [ff,gg]]
  for f in fs:f.writerow(['wire','kind','file','theorem','statement','axioms','kernel_status'])
  out.write('[\n')
  for group in batched(pairs(D/'certs.json'),160):
   batch_id=n//160;screen.lean(batch_id,dict(group))
   for s,w in group:
    k=w[0]
    if k=='open':original.append(s)
    num='e'+str(int(s,2));m=f'Batch{batch_id:04}';base='Blc.Floor45.'
    r=records.get(s) or dict(kind=k,module=m,theorem=base+'cert_'+num,term=base+num,strength='complete' if k.startswith('W') else 'predicate')
    row=dict(wire=s,root='app' if s.startswith('01') else 'literal',triple=core.counts(core.lc.decode(s)[0]),**r)
    if n:out.write(',\n')
    out.write(json.dumps(row,separators=(',',':')));n+=1
    if r['kind'] in ('open','pending'):
     pending.append(s)
     fields=[s,'pending',m+'.lean','','¬ Blc.IsSelfInterpreter '+base+num,'','pending']
     for f in fs:f.writerow(fields)
    elif r['strength']=='complete':
     ax='propext, Classical.choice, Quot.sound' if s in choices else 'propext, Quot.sound'
     fields=[s,r['kind'],r['module']+'.lean',r['theorem'],'¬ Blc.IsSelfInterpreter '+r['term'],ax,'checked']
     fs[0].writerow(fields)
     if not k.startswith('W'):
      fs[1].writerow(fields)
      th=r.get('individual_theorem',r['theorem']);om=r.get('individual_module',r['module'])
      if r['module']!='H45Bridge':res.append((th.rsplit('.',1)[0]+'.'+num,th,om))
  out.write('\n]\n')
 assert n==427114
 # Reg proofs use a namespace-local literal even if their theorem is called excluded.
 release.groups(res);seal_groups.main();attach_groups.main()
 (D/'open.txt').write_text(''.join(s+'\n' for s in original))
 (D/'unresolved.txt').write_text(''.join(s+'\n' for s in pending))
def write_inputs(dirname,rows):
 q=D/dirname;q.mkdir(exist_ok=True)
 for s,v in rows.items():(q/(s+'.json')).write_text(json.dumps(v))
def render():
 data=json.loads((D/'proof-witnesses.json').read_text());records=data['records']
 rebuild_records(data)
 # Grade witnesses include the underlying application operation and the selected source.
 shutil.copyfile(D/'hard-six.txt',D/'hardraw6.out')
 grade_rows.generate();sys.argv.append('--hard');grade_rows.generate();sys.argv.pop()
 def load(name):return json.loads((D/(name+'.json')).read_text())
 write_inputs('attempts',{s:[r['kind'],r['replay'],*r['parameters']] for s,r in load('extra-manifest').items()})
 extra_rows.main()
 write_inputs('late',{s:[r['kind'],r['replay'],*r['parameters']] for s,r in load('late-manifest').items()})
 probe_rows.late();probe_rows.assignment=gradederive.assignment=lambda:data['probe'];gradederive.main()
 write_inputs('abstract',{s:[r['layout'],r['proof_graph'],r['remainder_types'],r['continuation_types'],r['token']] for s,r in load('types-manifest').items()})
 emittypes.main()
 for s,r in records.items():
  if r['kind']=='weak_head_observation':
   c,m,t,args=r['probe'];i,a=r['actual'];j,b=r['expected']
   observed.material(s,*[core.lc.decode(x)[0] for x in [c,m,t]],[core.lc.decode(x)[0] for x in args],a,b,i-1,j-1)
 for name,(w,fast,ranges) in data['regular'].items():
  compactreg.emit(D/w);genreg.split(name)
  if fast:faster_regular.update(name)
  for f in [D/(name+'.lean'),*D.glob(name+'B*.lean')]:
   if not ranges:break
   s=f.read_text()
   def split(m):
    a,b=map(int,m.groups())
    if a not in ranges:return m[0]
    def tree(i,j):
     if j==i+1:return f'(RegProof.block (a := {i}) (n := 1) (by decide +kernel))'
     mid=(i+j)//2;return f'(RegProof.merge {tree(i,mid)} {tree(mid,j)})'
    return f'theorem ok{a} : RegProof.Span ck {a} {b} := '+tree(a,b)
   f.write_text(re.sub(r'theorem ok\d+ : RegProof.Span ck (\d+) (\d+) := RegProof.block [^\n]*',split,s))


def finish_metadata():
 import archive_core as core
 from genlean import expr
 versions=json.loads((D/'emitter-versions.json').read_text())
 for kind,files in versions.items():
  for f in files:
   p=D/f;s=p.read_text()
   if kind=='old_open':s=s.replace('SelfintControl SelfintSharp ChainModel','SelfintControl ChainModel')
   else:s=re.sub(r'  have h : ∃ j, Count [^\n]*? j := ','  have h := ',s)
   p.write_text(s)
 q=D/'Reg9692678919414B7.lean'
 q.write_text(q.read_text().replace('ck 930 931 := RegProof.block (n := 1) (by decide +kernel)','ck 930 931 := (RegProof.block (a := 930) (n := 1) (by decide +kernel))'))
 for s,r in json.loads((D/'bottom-manifest.json').read_text()).items():
  lib=r['table'];lc=core.lc;HERE=D;conf=[r['token'],None]
  num=str(int(s,2));nm='e'+num;mod='Bottom'+num;ns='Blc.Floor45.'+mod
  lines=['import H44'+lib,'import Floor45','namespace '+ns,'open Term SelfintLowerBound SelfintControl Round3Floor38','set_option maxRecDepth 20000','set_option maxHeartbeats 3000000',f'def {nm} : Term := '+expr(lc.decode(s)[0]),f'theorem wire_{nm} : Closed {nm} ∧ code {nm} = {int("1"+s,2)} := by decide',f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := Blc.H44.{lib}.excluded (by decide : Blc.H44.Types.has Blc.H44.{lib}.tab Blc.H44.{lib}.env {nm} {conf[-2]} = true)',f'#print axioms ex_{nm}','end '+ns]
  (HERE/(mod+'.lean')).write_text('\n'.join(lines)+'\n')
 a=(D/'open.txt').read_text().splitlines()
 for phase,exclude in [('after4.in',['raw4.txt']),('after_quick.in',['raw4.txt','raw5.txt'])]:
  used={l.split()[0] for f in exclude for l in (D/f).read_text().splitlines()}
  if phase=='after_quick.in':used.update(json.loads((D/'extra-manifest.json').read_text()))
  (D/phase).write_text(''.join(s+'\n' for s in a if s not in used))
 m=json.loads((D/'build-metrics.json').read_text())
 (D/'proof-modules.txt').write_text(''.join(n+'\n' for n in sorted(x['module'] for x in m['modules'])))
if __name__=='__main__':
 render();finish_metadata()

def summaries():
 from collections import defaultdict
 import deliver
 deliver.main()
 roots=defaultdict(Counter);counts=Counter();cells=defaultdict(Counter);pending=0;direct=0
 for r in ledger(D/'ledger.json'):
  k=r['kind'];roots[k][r['root']]+=1;cells[tuple(r['triple'])][r['root']]+=1
  if k=='pending':pending+=1
  else:counts[k]+=1
  if r['strength']=='complete' and not k.startswith('W'):direct+=1
 (D/'checked-counts.json').write_text(json.dumps(dict(checked=counts,pending=({'search':pending} if pending else {})),indent=1)+'\n')
 (D/'partition.json').write_text(json.dumps(dict(n=sum(counts.values())+pending,residual_direct=direct,unresolved=pending,kinds=roots),indent=1)+'\n')
 with (D/'triples.tsv').open('w') as f:
  f.write('L\tV\tX\tclosed_at_roots\tstructural\tapp\tliteral\n')
  for line in (D/'inventory-counts.txt').read_text().splitlines():
   if not re.fullmatch(r'\d+( \d+){5}',line):break
   l,v,x,raw,struct,total=map(int,line.split());c=cells[l,v,x]
   assert c['app']+c['literal']==total
   f.write(f"{l}\t{v}\t{x}\t{raw}\t{struct}\t{c['app']}\t{c['literal']}\n")
if __name__=='__main__':summaries()
