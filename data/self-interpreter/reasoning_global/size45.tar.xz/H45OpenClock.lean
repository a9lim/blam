import H45ProbeClock
import H45Types
namespace Blc.H45
open Term SelfintControl SelfintLowerBound WeakHeadClock
theorem rigid_untyped {t : Term} (hr : Rigid t) (m : Types.Table) (i : Nat) :
    Types.has m Types.empty t i = false := by
  induction hr generalizing i with
  | var v => simp [Types.has,Types.empty]
  | app a h ih => simp [Types.has,ih]
theorem noOpenClock {m t} (ht : Types.has m Types.empty t 0 = true) {n} (hc : Count t n) : False := by
  induction hc with
  | @step t u n hw _ ih => exact ih (Types.preserved (weakStep_beta hw) 0 ht)
  | @stop t h =>
    cases t with
    | var j => simpa [Types.has,Types.empty] using ht
    | lam b => cases ht
    | app f a =>
      have hr := weakStep_none_rigid h (by intro h; exact h)
      rw [rigid_untyped hr] at ht
      contradiction
end Blc.H45
