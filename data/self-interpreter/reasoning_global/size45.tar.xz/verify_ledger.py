"""Check exact literals and finite replay against two independent syntax traversals."""
from pathlib import Path
import hashlib,json,re,sys,itertools
from functools import lru_cache
from collections import Counter
from jsonstream import pairs,ledger
D=Path(__file__).resolve().parent
def paths(ps):return '['+','.join('['+','.join('.'+d for d in p)+']' for p in ps)+']'
def ast(s,i,d):
 if s[i]=='1':
    j=s.index('0',i)-i-1;assert 0<=j<d
    return f'(.var {j})',i+j+2,(0,1,j)
 if s[i+1]=='0':
    x,j,(l,v,k)=ast(s,i+2,d+1);return f'(.lam {x})',j,(l+1,v,k)
 f,j,a=ast(s,i+2,d);x,k,b=ast(s,j,d);return f'(.app {f} {x})',k,tuple(u+v for u,v in zip(a,b))
@lru_cache(8)
def module(name):return (D/(name+'.lean')).read_text()
def main():
 bits=45
 official=D/'replay.py'
 # Load only the repository auditor's functions, excluding its standalone CLI.
 import ast as astlib
 body=astlib.parse(official.read_text());body.body=body.body[:next(i for i,x in enumerate(body.body) if isinstance(x,astlib.Assign) and any(isinstance(v,astlib.Name) and v.id=='wires' for v in x.targets))]
 audit={};exec(compile(body,str(official),'exec'),audit)
 def replay(t,ps):
    def step(t,p):
       if not p:
          assert t[0]=='a' and t[1][0]=='l';return audit['subst'](t[1][1],t[2])
       if p[0]=='under':assert t[0]=='l';return ('l',step(t[1],p[1:]))
       assert t[0]=='a'
       return ('a',step(t[1],p[1:]),t[2]) if p[0]=='left' else ('a',t[1],step(t[2],p[1:]))
    for p in ps:t=step(t,p);assert audit['size'](t)<=4000
    return t
 ss=sorted((D/'wires.txt').read_text().split());assert len(ss)==len(set(ss))==427114
 adds=json.loads((D/'additional-finite.json').read_text());seen=set();counts=Counter()
 for i,(s,(w,cert),row) in enumerate(zip(ss,pairs(D/'certs.json'),ledger(D/'ledger.json'),strict=True)):
    assert s==w==row['wire'];nm='e'+str(int(s,2));bmod=f'Batch{i//160:04}';batch=module(bmod);x,j,tr=ast(s,0,0)
    assert j==45 and list(tr)==row['triple'] and row['root']==('literal' if s.startswith('00') else 'app')
    wire=f'theorem wire_{nm} : Closed {nm} ∧ code {nm} = {int("1"+s,2)} := by decide'
    literal=f'def {nm} : Term := {x}\n';assert literal in batch and wire in batch
    k=cert[0];st=row['strength'];th=row['theorem'];assert th not in seen;seen.add(th);counts['pending' if row.get('status')=='pending' else st]+=1
    if k!='open':
       assert row['kind']==k and row['module']==bmod and th=='Blc.Floor45.cert_'+nm
       if k in ('Wsource','Widentity'):
          assert st=='complete' and f'theorem cert_{nm} : ¬ IsSelfInterpreter {nm} :=' in batch
          assert f'ps := {paths(cert[1])}' in batch.split(f'theorem cert_{nm} :',1)[1].split('\n',1)[0]
       else:
          assert st=='predicate' and audit['check'](s,cert,bits) is True
          check=(f'checkPay {nm} {paths(cert[1])} {cert[2]} {paths(cert[3])}' if k=='payload' else f'check {nm} {paths(cert[1])} .{k}')
          assert f'theorem cert_{nm} : {check} = true := by decide' in batch
       continue
    if row.get('status')=='pending':assert st=='predicate' and row['kind']=='pending' and th=='Blc.Floor45.wire_'+nm and row['module']==bmod;continue
    mod=module(row['module']);short=th.split('.')[-1]
    if row['module']=='H45Bridge':
       assert st=='complete' and row['term']=='Blc.Floor45.'+nm
       assert literal in module('H45Literals')
       assert f'theorem same_{nm} : Blc.H45.{nm} = Blc.Floor45.{nm} := rfl' in mod
       assert f'theorem {short} : ¬ IsSelfInterpreter Blc.Floor45.{nm} := Blc.H45.ex_{nm}' in mod
       assert '#print axioms '+short in mod
       continue
    assert literal in mod and wire in mod
    if st=='complete':
       assert f'theorem {short} : ¬ IsSelfInterpreter {nm} :=' in mod and '#print axioms '+short in mod
    else:
       a,ps=adds[s];assert row['kind']==a and row['replay']==ps
       assert f'theorem {short} : check {nm} {paths(ps)} .{a} = true := by decide' in mod
       t=replay(audit['parse'](s)[0],ps);lead,sub=audit['strip'](t)
       good={'smaller':lambda:audit['size'](t)<45,'chain':lambda:audit['chain'](sub),'width':lambda:lead<=2 and audit['inner_width'](sub)<3,'three':lambda:lead>=3}
       assert good[a]()
 from verify_parts import check as verify_parts
 assert counts=={'predicate':403617,'complete':23497},counts
 print('Direct residuals in the four literal proof partitions:',verify_parts(ast))
 print('Exact wire, declaration and independent finite replay checks passed',dict(counts))
if __name__=='__main__':main()
