"""Minimal sets of marked free variables sufficient for B and W."""
from functools import lru_cache
class Fuel(Exception):pass
def minimal(xs):
    if 0 in xs:return (0,)
    if len(xs)>1024:raise Fuel
    keep=[]
    for x in sorted(xs,key=int.bit_count):
        if all(y&x!=y for y in keep):keep.append(x)
    return tuple(keep)
@lru_cache(8192)
def summaries(t):
    if t[0]=='V':return (), (1<<t[1],)
    if t[0]=='L':
        b,_=summaries(t[1])
        return minimal({x>>1 for x in b if not x&1}),minimal({x>>1 for x in b})
    b,w=summaries(t[1])
    if b==(0,) or not w:return b,()
    rb,rw=summaries(t[2]);rhs=set(rb+rw)
    if len(w)*len(rhs)>2048:raise Fuel
    return minimal(set(b)|{x|y for x in w for y in rhs}),()
def solve(t,m,index):
    try:values=summaries(t)[index]
    except Fuel:return False
    marked=sum(1<<i for i,x in enumerate(m) if x)
    return any(s&marked==s for s in values)
def b(t,m=()):return solve(t,m,0)
def w(t,m=()):return solve(t,m,1)
b.cache_clear=w.cache_clear=summaries.cache_clear
