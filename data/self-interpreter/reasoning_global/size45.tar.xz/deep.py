from extras import *
from genlean import expr,paths
from smart_probe import appall,apps_spine
from itertools import product
from searchprobes import target_steps
from regular40 import mask,regular,portable
P=L(L(L(A(A(V(0),V(2)),V(1)))))
def remaining(s):
    return not (HERE/('r'+str(int(s,2))+'.json')).exists()
def tries(e):
    pair=A(A(A(e,K),lc.bitlist(lc.enc(P),I)),I)
    for t,k in [(e,'dead'),(pair,'pairSO')]:
        for style in (1,0,2,3):
            ps=[];seen=set()
            for _ in range(40):
                if t in seen:break
                seen.add(t)
                if (k=='dead' and t[0]=='L' and not occ(t[1])) or (k=='pairSO' and so(t)):return [k,ps]
                p=variant(t,style) if style<3 else normal_path(t)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps=ps+[p]
            t=e if k=='dead' else pair
    for c,m,r,aa in [(c,m,r,aa) for aa in ([],[om],[om,om],[om]*3,[om]*4,[om]*5,[om]*7) for m in (I,KI,K) for c,r in [(KI,V(0)),(K,om),(L(L(I)),om),(V(1),V(0)),(om[1],V(0))]]:
        k=target_steps(c,m,r,aa)
        if k is None:continue
        q=appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)
        want=appall(A(A(c,L(m)),r),aa)
        for _ in range(k):want=red(want,head_path(want))
        for style in (1,0):
            t=q;ps=[]; seen=set()
            for i in range(32):
                if t in seen:break
                seen.add(t)
                lead,h,args=spine(t);l2,h2,a2=spine(want)
                kind=None
                if t==om or apps_spine(t)[0]==om[1] and apps_spine(t)[1] and apps_spine(t)[1][0]==om[1]:kind='omega'
                elif b(t):kind='Wprobe'
                elif lead>l2 or h[0]=='V' and (lead,h,len(args))!=(l2,h2,len(a2)):kind='mismatch'
                elif want[0]=='V' and not occ(t,want[1]):kind='absent'
                if kind:
                    return [kind,ps,*map(lc.enc,(c,m,r)),list(map(lc.enc,aa)),k]
                p=variant(t,style)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps=ps+[p]
    return None
if __name__=='__main__':
    ss=[s for s in (HERE/'rem.txt').read_text().split() if remaining(s)]
    for s in ss[int(sys.argv[1])::int(sys.argv[2])]:
        if x:=tries(lc.decode(s)[0]):
            (HERE/('x'+str(int(s,2))+'.json')).write_text(json.dumps(x));print(s,x[0],flush=True)
        else:print(s,'?',flush=True)
        b.cache_clear();w.cache_clear()
