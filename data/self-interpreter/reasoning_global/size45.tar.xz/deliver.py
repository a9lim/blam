"""Write the literal open docket, with finite observation evidence only."""
from candidates import *
import csv
def notation(t,env=()):
 if t[0]=='V':return env[t[1]]
 if t[0]=='L':
  bs=[]
  while t[0]=='L':
   x=chr(ord('a')+len(env));bs.append(x);env=(x,*env);t=t[1]
  return '(λ'+' '.join(bs)+'.'+notation(t,env)+')'
 h=t;xs=[]
 while h[0]=='A':xs.append(h[2]);h=h[1]
 return ' '.join([notation(h,env)]+[('('+notation(x,env)+')') if x[0]=='A' else notation(x,env) for x in reversed(xs)])
def main():
 w=(HERE/'unresolved.txt').read_text().split();obs=json.loads((HERE/'hard-observations.json').read_text())
 with (HERE/'unresolved.tsv').open('w') as fh:
  wr=csv.writer(fh,delimiter='\t',lineterminator='\n')
  wr.writerow(['wire','literal','L','V','X','root_observation','machine_steps','halted_probes_of_33','probe_step_cap','status'])
  for s in w:
   t=lc.decode(s)[0];o=obs[s];v,k=o['raw']
   wr.writerow([s,notation(t),*counts(t),'lambda' if v else 'cap',k,o['probe_exits'],1600,'pending'])
if __name__=='__main__':main()
