from valreg import *
from searchprobes import target_steps
import time
def discover(t,depth,site,style,which,k):
 nodes=tuple(regular.compile_term(mask(t)));free=fv(nodes)
 @lru_cache(8000)
 def clip(v,n):
    if not n:return ()
    return (v[0],tuple(clip(a,n-1) for a in v[1]))
 def transfers(nodes,s,vals,konts,unused,mode):
    p,env,sp,ctx=s;node=nodes[p];tag=node[0]
    if tag not in ('A','L') or (tag=='L' and sp is None):
        return base_transfer(nodes,s,vals,konts,unused,mode)
    if tag=='A':
       prev=sp[3] if sp else ()
       px=(p if site else 1)
       sign=(px,)+prev[:depth-1]
       adr=(p,env,ctx,sign)
       return [(node[1],env,adr,ctx)],[('K',adr,((node[2],env),sp,p))],None
    nxt=[];up=[]
    for arg,rest,ac in konts.get(sp,()):
       ap,ae=arg
       rs=rest[3] if rest else ()
       key=(p,ap,rs if which else ())
       if style==0:adr=(key,())
       elif nodes[ap][0]=='V':adr=ae[nodes[ap][1]]
       else:adr=(key,tuple(clip(ae[j],k-1) for j in free[ap]))
       nxt.append((node[1],(adr,)+env,rest,()));up.append(('V',adr,arg))
    return nxt,up,None
 regular.transfers=transfers
 try:
    try:z=regular.discover(mask(t),0,cap=5500,seconds=.07)
    except (regular.Limit, RecursionError):return
    if z['ok'] and z['states']<3000:return portable.portable(z)
 finally:regular.transfers=base_transfer
def one(s):
 e=lc.decode(s)[0]
 for depth,site,style,which,k in [(3,0,0,1,1),(3,1,0,0,1),(2,1,1,1,1),(4,0,1,0,2),(4,1,1,0,2),(2,1,1,1,2),(6,0,0,1,1),(6,1,1,0,2),(4,0,1,1,3)]:
  for kind in ('raw','rigid','apply','extra1','extra3','extra6'):
   q=probeType(e,kind)
   for j in (0,3):
    t=q;ps=[]
    for _ in range(j):
       p=variant(t,1)
       if p is None:break
       t=bounded(t,p);ps.append(p)
       if t is None:break
    if t is None or len(ps)!=j:continue
    if z:=discover(t,depth,site,style,which,k):
       return [len(z['states']),kind,j,depth,f'stack:{site}:{style}:{which}:{k}',ps,z]
if __name__=='__main__':
 for s in remain():
    if z:=one(s):(HERE/('r'+str(int(s,2))+'.json')).write_text(json.dumps(z))
