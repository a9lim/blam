// Search finite monotone application tables against the contract at normal sources.
// Discovery only. Lean constructs the closed derivation for each winning table.
#include <algorithm>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <map>
#include <random>
#include <iostream>
#include <fstream>
using namespace std;
constexpr int M=9;
int n,op[M][M],lowest;
struct Node{int k,x,y,d;};
vector<Node> nodes;map<array<int,3>,int> ids;
int intern(int k,int x,int y){
 array<int,3>w={k,x,y};auto it=ids.find(w);if(it!=ids.end())return it->second;
 int d=k==0?x+1:k==1?max(0,nodes[x].d-1):max(nodes[x].d,nodes[y].d);
 int p=nodes.size();nodes.push_back({k,x,y,d});return ids[w]=p;
}
int parse(const string&s,int&i){
 if(s[i++]=='1'){int z=0;while(s[i++]=='1')++z;return intern(0,z,0);}
 if(s[i++]=='0')return intern(1,parse(s,i),0);
 int f=parse(s,i);return intern(2,f,parse(s,i));
}
vector<vector<int>> cache;vector<int> moduli;
int eval(int p,int env){
 auto [k,x,y,d]=nodes[p];int &v=cache[p][env%moduli[d]];
 if(v!=-1)return v;
 if(!k)return v=(env/moduli[x])%n;
 if(k==2)return v=op[eval(x,env)][eval(y,env)];
 int g=lowest;
 for(int a=0;a<n;a++){int b=eval(x,(env*n+a)%moduli[nodes[x].d]);while(op[g][a]<b)++g;}
 return v=g;
}
struct Wire{string w;int p;};
vector<Wire> todo, ms;
Wire dec(string w){int i=0;return {w,parse(w,i)};}
int kt,kf;
void one(){
 if(todo.empty())exit(0);
 for(auto &vs:cache)fill(vs.begin(),vs.end(),-1);
 int K=eval(kt,0),F=eval(kf,0),cons[2][M],box[M];
 for(int r=0;r<n;r++){
  for(int b=0;b<2;b++){int v=lowest;for(int a=0;a<n;a++)while(op[v][a]<op[op[a][b?F:K]][r])v++;cons[b][r]=v;}
  int v=lowest;for(int a=0;a<n;a++)while(op[v][a]<r)v++;box[r]=v;
 }
 int mn=n;for(auto&t:todo)mn=min(mn,eval(t.p,0));
 // Identify just the strongest failing threshold, sufficient to remove wires monotonically.
 int threshold=mn-1,cm=-1,cr=-1,cc=-1,mode=-1;
 for(int j=0;j<(int)ms.size();j++){
  auto &m=ms[j];int val=eval(m.p,0);
  for(int r=0;r<n;r++){
   int s=r;for(auto p=m.w.rbegin();p!=m.w.rend();++p)s=cons[*p=='1'][s];
   for(int c=0;c<n;c++){
    int want=op[op[c][box[val]]][r];
    while(threshold<n-1 && op[op[threshold+1][c]][s]<want){++threshold;cm=j;cr=r;cc=c;mode=0;}
   }

  }
 }
 if(threshold>=mn){
  for(auto it=todo.begin();it!=todo.end();){
   if(eval(it->p,0)<=threshold){
     cout<<it->w<<" "<<n<<" "<<lowest<<" ";
     for(int i=0;i<n;i++)for(int j=0;j<n;j++)cout<<op[i][j];
     cout<<" "<<ms[cm].w<<" "<<mode<<" "<<cc<<" "<<cr<<endl;
     it=todo.erase(it);
   }else ++it;
  }
 }
}
void gen(int i,int j){
 if(i==n-1){one();return;}
 int lo=max(i?op[i-1][j]:0,j?op[i][j-1]:0);
 for(int k=lo;k<n;k++){op[i][j]=k;if(j+1<n)gen(i,j+1);else gen(i+1,0);}
}
int main(int argc,char**argv){
 ifstream a(argv[1]),b(argv[2]);string s;while(a>>s)todo.push_back(dec(s));while(b>>s)ms.push_back(dec(s));
 kt=dec("0000110").p;kf=dec("000010").p;n=atoi(argv[3]);int rounds=atoi(argv[4]);
 moduli={1};int d=0;for(auto&t:nodes)d=max(d,t.d);
 while((int)moduli.size()<=d)moduli.push_back(moduli.back()*n);
 for(auto&t:nodes)cache.emplace_back(moduli[t.d]);
 fill(op[n-1],op[n-1]+n,n-1);
 if(rounds==0){for(lowest=0;lowest<2;lowest++)gen(0,0);return 0;}
 mt19937 rnd(atoi(argv[5])); // Heat-bath sampler of coordinatewise monotone tables.
 for(int i=0;i<n-1;i++)for(int j=0;j<n;j++)op[i][j]=max(i,j);
 for(int z=0;z<rounds;z++){
   for(int t=0;t<n*n;t++){
     int i=rnd()%(n-1),j=rnd()%n;
     int lo=max(i?op[i-1][j]:0,j?op[i][j-1]:0),hi=min(op[i+1][j],j+1<n?op[i][j+1]:n-1);
     op[i][j]=lo+rnd()%(hi-lo+1);
   }
   lowest=rnd()%2;one();
 }
}
