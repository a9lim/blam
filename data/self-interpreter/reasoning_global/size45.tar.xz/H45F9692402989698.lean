import H45F9692402989698Proof1
import H45Literals
import H45Clocks
namespace Blc.H45.H45F9692402989698
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
def env : Env := Types.cons s0 (Types.cons s0 Types.empty)
theorem excluded : ¬ IsSelfInterpreter e9692402989698 := by
  intro he
  have hp : replay [[.left],[.left],[.left,.left]] (.app e9692402989698 diag) = some b24 := by decide
  obtain ⟨_,hc⟩ := clocks_replay (diagCount he) hp
  exact Types.noClock (m := tab) ((h47 Types.empty) 0 mem12) (by decide) hc
#print axioms excluded
end Blc.H45.H45F9692402989698
