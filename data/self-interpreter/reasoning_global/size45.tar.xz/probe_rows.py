from grade_rows import *
from probes import get,appall
from clockprobes import getclock
from searchprobes import target_steps
from emitextra import emit
from hashlib import sha256
def assignment():
 rows={}
 for dn in ('probes','hardprobe'):
    for p in sorted((HERE/dn).glob('*.out')):
       for line in p.read_text().splitlines():
          s,id,n,lo,tab,c,r,a,b=line.split()
          rows.setdefault(s,['probe',id,int(n),int(lo),tab,*map(int,(c,r,a,b))])
 for p in (HERE/'sat').glob('*.json'):rows.setdefault(p.stem,json.loads(p.read_text()))
 for p in (HERE/'clock').glob('*.out'):
    for line in p.read_text().splitlines():
       s,id,n,lo,tab,a=line.split();rows.setdefault(s,['clock',id,int(n),int(lo),tab,int(n)-1,int(n)-1,int(a),int(lo)])
 return rows
def main():
 rows=assignment();mani={}
 for s,(kind,id,n,lo,tab,x,y,a,b) in rows.items():
    nm='e'+str(int(s,2));mod='Probe'+nm[1:];ns='Blc.Floor45.'+mod
    table='Op'+sha256(f'{n}/{lo}/{tab}'.encode()).hexdigest()[:12];tpath=HERE/(table+'.lean')
    if not tpath.exists():tpath.write_text('import ClockCut\nnamespace Blc.Floor45.'+table+'\n'+hdr+modelop(n,lo,tab)+'\nend Blc.Floor45.'+table+'\n')
    rho=f'(rho (n := {n-1}) {x} {y})';G=table+'.G'
    ls=['import '+table,'namespace '+ns,hdr,src(s,nm)]
    if kind=='probe':
       c,m,r,aa,t,u,ps,qs=get(s,id);params=' '.join(map(expr,(c,m,r)))+' '+natlist(map(expr,aa))
       ls+=['private def endpoint : Term := '+expr(t),'private def goalTerm : Term := '+expr(u),f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := by',
          f'  apply afterCut {G} (x := {x}) (y := {y}) (z := {a}) (t := endpoint) (u := goalTerm) (c := {expr(c)}) (m := {expr(m)}) (r := {expr(r)}) (aa := {natlist(map(expr,aa))}) (by decide)',
          f'  · exact replay_sound (t := call {nm} {params}) (ps := {paths(ps)}) (by decide)',
          f'  · exact replay_sound (t := want {params}) (ps := {paths(qs)}) (by decide)',
          '  · decide','  · decide','  · decide']
       data=dict(probe=[lc.enc(c),lc.enc(m),lc.enc(r),list(map(lc.enc,aa))],replay=ps,target_replay=qs)
    else:
       q,t,ps=getclock(s,id);start=nm;need='rawCount he'
       if q:
          style,c,m,r,aa,k=q;args=natlist(map(expr,aa));params=' '.join(map(expr,(c,m,r)))+' '+args
          eu=f'(call {nm} {params})';need=f'inputCount (e := {nm}) (c := {expr(c)}) (m := {expr(m)}) (r := {expr(r)}) (args := {args}) (k := {k}) he (by decide) (by decide)'
          if style=='prefix':start=f'(.app {nm} {expr(c)})'
          else:start=eu
       ls+=['private def endpoint : Term := '+expr(t),f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := by','  intro he',f'  have hp := replay_sound (t := {start}) (u := endpoint) (ps := {paths(ps)}) (by decide)',
            f'  apply clockCut {G} (z := {a}) (by decide) hp (by decide)',
            f'  obtain ⟨k,hk⟩ := {need}']
       if q and q[0]=='prefix':ls+=['  obtain ⟨j,_,hj⟩ := WeakHeadClock.count_app_left hk','  exact ⟨j,hj⟩']
       else:ls+=['  exact ⟨k,hk⟩']
       data=dict(layout=id,replay=ps)
    ls+=['#print axioms ex_'+nm,'end '+ns];(HERE/(mod+'.lean')).write_text('\n'.join(ls)+'\n')
    mani[s]=dict(kind='probe_model' if kind=='probe' else 'clock_model',module=mod,theorem=ns+'.ex_'+nm,term=ns+'.'+nm,n=n,floor=lo,table=tab,continuation_grade=x,remainder_grade=y,actual_grade=a,target_grade=b,**data)
 (HERE/'probe-manifest.json').write_text(json.dumps(mani,separators=(',',':')))
def late():
 mani={}
 for p in (HERE/'late').glob('*.json'):
    s=p.stem;r=json.loads(p.read_text());kind=r[0];nm='e'+str(int(s,2));mod='Late'+nm[1:];ns='Blc.Floor45.'+mod
    ls=['import ExtraBase','namespace '+ns,'open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38','set_option maxRecDepth 30000','set_option maxHeartbeats 6000000',src(s,nm)]
    if kind=='pairSO':ls.append(emit(s,r))
    else:
       _,ps,cc,mm,rr,as_,qs=r;c,m,rt=map(lambda w:lc.decode(w)[0],(cc,mm,rr));aa=[lc.decode(a)[0] for a in as_]
       t=appall(A(A(lc.decode(s)[0],c),lc.bitlist(mm,rt)),aa);u=appall(A(A(c,L(m)),rt),aa)
       for v in ps:t=red(t,v)
       for v in qs:u=red(u,v)
       args=' '.join(map(expr,(c,m,rt)))+' '+natlist(map(expr,aa))
       ls+=['private def endpoint : Term := '+expr(t),'private def goalTerm : Term := '+expr(u),f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := by','  intro he',
            f'  have hp := replay_sound (t := call {nm} {args}) (u := endpoint) (ps := {paths(ps)}) (by decide)',
            f'  have hq := replay_sound (t := want {args}) (u := goalTerm) (ps := {paths(qs)}) (by decide)',
            '  have hu : NFt goalTerm := by decide','  have hr := expected he (by decide) hp hq hu']
       if kind=='absent':ls+=[f'  exact (by decide : ¬ occ {u[1]} goalTerm = 0) (SelfintKnot.occ_betas_zero hr {u[1]} (by decide))']
       elif kind=='mismatch':ls+=['  exact (by decide : ¬ Layouts.mismatch 32 endpoint goalTerm = false) (Layouts.mismatch_sound 32 hr hu)']
       else:ls+=['  exact WGrammar38.no_normal_form (t := endpoint) (by decide) ⟨goalTerm,hr,fun _ => nft_no_beta hu⟩']
       ls+=['#print axioms ex_'+nm]
    (HERE/(mod+'.lean')).write_text('\n'.join(ls+['end '+ns])+'\n')
    mani[s]=dict(kind=kind,module=mod,theorem=ns+'.ex_'+nm,term=ns+'.'+nm,replay=r[1],parameters=r[2:])
 (HERE/'late-manifest.json').write_text(json.dumps(mani,separators=(',',':')))
if __name__=='__main__':main();late()
