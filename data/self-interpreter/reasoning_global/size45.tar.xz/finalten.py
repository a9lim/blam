"""Render the final ten as a fourth, closed, small proof partition."""
def source(rows):
 ns='Blc.Floor45.FinalTen';ls=['import H45Bridge','import Aggregate','namespace '+ns]
 for i,r in reversed(list(enumerate(rows))):
  tail=f'xs{i+1}' if i+1<len(rows) else '[]'
  ls += [f'def xs{i} : List Term := {r["term"]} :: {tail}',f'theorem checked{i} : Aggregate.Safe xs{i} := by',
         '  intro t ht','  rcases List.mem_cons.mp ht with rfl | ht',f'  · exact {r["theorem"]}',
         f'  · exact checked{i+1} _ ht' if i+1<len(rows) else '  · simp at ht']
 return '\n'.join(ls+['#print axioms checked0','end '+ns])+'\n'
