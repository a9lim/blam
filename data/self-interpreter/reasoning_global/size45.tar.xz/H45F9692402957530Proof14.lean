import H45F9692402957530Proof13
namespace Blc.H45.H45F9692402957530
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h504 (ρ : Env) (a0 : Fits s19 (ρ 0)) (a1 : Fits s20 (ρ 1)) : All tab ρ b24 s103 :=
  (consAll (lamAt d17 c17 (smaller (h427 (Types.cons s2 ρ) sub13 a0 a1) sub4)) Positive.none)
theorem h505 (ρ : Env) (a0 : Fits s33 (ρ 0)) (a1 : Fits s34 (ρ 1)) : All tab ρ b24 s124 :=
  (consAll (lamAt d76 c76 (smaller (h428 (Types.cons s2 ρ) sub13 a0 a1) sub160)) Positive.none)
theorem h506 (ρ : Env) (a0 : Fits s46 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h429 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h507 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s58 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h430 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h443 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h458 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h471 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h474 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h477 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h508 (ρ : Env) (a0 : Fits s45 (ρ 0)) (a1 : Fits s46 (ρ 1)) : All tab ρ b24 s143 :=
  (consAll (lamAt d117 c117 (smaller (h432 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d133 c133 (smaller (h431 (Types.cons s7 ρ) sub7 a0 a1) sub165)) Positive.none))
theorem h509 (ρ : Env) (a0 : Fits s7 (ρ 0)) (a1 : Fits s43 (ρ 1)) : All tab ρ b24 s148 :=
  (consAll (lamAt d117 c117 (smaller (h436 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d148 c148 (smaller (h433 (Types.cons s32 ρ) sub106 a0 a1) sub151)) Positive.none))
theorem h510 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b24 s149 :=
  (consAll (lamAt d128 c128 (smaller (h434 (Types.cons s48 ρ) sub105 a0 a1) sub163)) Positive.none)
theorem h511 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s63 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h435 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h512 (ρ : Env) (a0 : Fits s29 (ρ 0)) (a1 : Fits s24 (ρ 1)) : All tab ρ b24 s155 :=
  (consAll (lamAt d117 c117 (smaller (h441 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d178 c178 (smaller (h437 (Types.cons s71 ρ) sub107 a0 a1) sub105)) Positive.none))
theorem h513 (ρ : Env) (a0 : Fits s55 (ρ 0)) (a1 : Fits s73 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h438 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h514 (ρ : Env) (a0 : Fits s24 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h439 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h515 (ρ : Env) (a0 : Fits s76 (ρ 0)) (a1 : Fits s40 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h440 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h516 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s78 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h449 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h442 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h459 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h470 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h473 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h476 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h517 (ρ : Env) (a0 : Fits s78 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h444 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h518 (ρ : Env) (a0 : Fits s58 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h445 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h519 (ρ : Env) (a0 : Fits s70 (ρ 0)) (a1 : Fits s81 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h447 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h446 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h460 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h485 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h486 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h487 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h520 (ρ : Env) (a0 : Fits s84 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b24 s155 :=
  (consAll (lamAt d117 c117 (smaller (h456 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d178 c178 (smaller (h448 (Types.cons s71 ρ) sub107 a0 a1) sub105)) Positive.none))
theorem h521 (ρ : Env) (a0 : Fits s81 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h450 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h522 (ρ : Env) (a0 : Fits s61 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h451 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h523 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s63 (ρ 1)) : All tab ρ b24 s174 :=
  (consAll (lamAt d117 c117 (smaller (h435 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d286 c286 (smaller (h452 (Types.cons s86 ρ) sub108 a0 a1) sub105)) Positive.none))
theorem h524 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b24 s174 :=
  (consAll (lamAt d117 c117 (smaller (h457 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d286 c286 (smaller (h453 (Types.cons s86 ρ) sub108 a0 a1) sub105)) Positive.none))
theorem h525 (ρ : Env) (a0 : Fits s63 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h454 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h526 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s87 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h455 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h527 (ρ : Env) (a0 : Fits s79 (ρ 0)) (a1 : Fits s89 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h463 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h482 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h461 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h488 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h489 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h490 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h528 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s89 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h462 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h529 (ρ : Env) (a0 : Fits s89 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h464 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h530 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s92 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h466 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h465 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h467 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h472 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h475 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h478 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h531 (ρ : Env) (a0 : Fits s51 (ρ 0)) (a1 : Fits s93 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h468 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h532 (ρ : Env) (a0 : Fits s92 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h469 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h533 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b24 s178 :=
  (consAll (lamAt d117 c117 (smaller (h457 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d347 c347 (smaller (h479 (Types.cons s70 ρ) sub109 a0 a1) sub105)) Positive.none))
theorem h534 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b24 s179 :=
  (consAll (lamAt d117 c117 (smaller (h457 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d348 c348 (smaller (h481 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h480 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none)))
theorem h535 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b24 s180 :=
  (consAll (lamAt d117 c117 (smaller (h457 (Types.cons s48 ρ) sub105 a0 a1) sub155)) (consAll (lamAt d349 c349 (smaller (h480 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))
theorem h536 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s89 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h492 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h483 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h491 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h493 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h494 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h495 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h537 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s87 (ρ 1)) : All tab ρ b24 s141 :=
  (consAll (lamAt d128 c128 (smaller (h497 (Types.cons s48 ρ) sub105 a0 a1) sub163)) (consAll (lamAt d178 c178 (smaller (h484 (Types.cons s71 ρ) sub107 a0 a1) sub105)) (consAll (lamAt d286 c286 (smaller (h496 (Types.cons s86 ρ) sub108 a0 a1) sub105)) (consAll (lamAt d347 c347 (smaller (h498 (Types.cons s70 ρ) sub109 a0 a1) sub105)) (consAll (lamAt d348 c348 (smaller (h499 (Types.cons s79 ρ) sub110 a0 a1) sub105)) (consAll (lamAt d349 c349 (smaller (h500 (Types.cons s11 ρ) sub5 a0 a1) sub105)) Positive.none))))))
theorem h538 (ρ : Env) (a0 : Fits s87 (ρ 0)) (a1 : Fits s49 (ρ 1)) : All tab ρ b24 s136 :=
  (consAll (lamAt d117 c117 (smaller (h501 (Types.cons s48 ρ) sub105 a0 a1) sub155)) Positive.none)
theorem h539 (ρ : Env) (a0 : Fits s4 (ρ 0)) : All tab ρ b25 s5 :=
  (consAll (lamAt d18 c18 (smaller (h502 (Types.cons s1 ρ) sub137 a0) sub176)) Positive.none)
end Blc.H45.H45F9692402957530
