import H45F9573528477238Proof68
namespace Blc.H45.H45F9573528477238
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h2465 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s340 :=
  (consAll (lamAt d741 c741 (smaller (h2245 (Types.cons s346 ρ) sub234 a0) sub1038)) (consAll (lamAt d749 c749 (smaller (h2247 (Types.cons s349 ρ) sub236 a0) sub235)) (consAll (lamAt d770 c770 (smaller (h2256 (Types.cons s359 ρ) sub243 a0) sub550)) Positive.none)))
theorem h2466 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s344 :=
  (consAll (lamAt d740 c740 (smaller (h2248 (Types.cons s345 ρ) sub237 a0) sub1102)) (consAll (lamAt d754 c754 (smaller (h2249 (Types.cons s350 ρ) sub238 a0) sub1101)) Positive.none))
theorem h2467 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s659 :=
  (consAll (lamAt d739 c739 (smaller (h2250 (Types.cons s342 ρ) sub542 a0) sub1100)) Positive.none)
theorem h2468 (ρ : Env) (a0 : Fits s353 (ρ 0)) : All tab ρ b12 s338 :=
  (consAll (lamAt d24 c24 (smaller (h2251 (Types.cons s17 ρ) sub9 a0) sub5)) (consAll (lamAt d762 c762 (smaller (h2252 (Types.cons s354 ρ) sub1039 a0) sub5)) Positive.none))
theorem h2469 (ρ : Env) (a0 : Fits s358 (ρ 0)) : All tab ρ b12 s353 :=
  (consAll (lamAt d766 c766 (smaller (h2255 (Types.cons s357 ρ) sub242 a0) sub5)) Positive.none)
theorem h2470 (ρ : Env) (a0 : Fits s361 (ρ 0)) : All tab ρ b12 s352 :=
  (consAll (lamAt d768 c768 (smaller (h2257 (Types.cons s358 ρ) sub551 a0) sub5)) (consAll (lamAt d774 c774 (smaller (h2258 (Types.cons s361 ρ) sub553 a0) sub5)) Positive.none))
theorem h2471 (ρ : Env) (a0 : Fits s364 (ρ 0)) : All tab ρ b12 s361 :=
  (consAll (lamAt d16 c16 (smaller (h2260 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d776 c776 (smaller (h2259 (Types.cons s362 ρ) sub1238 a0) sub5)) (consAll (lamAt d780 c780 (smaller (h2261 (Types.cons s366 ρ) sub247 a0) sub5)) (consAll (lamAt d784 c784 (smaller (h2262 (Types.cons s368 ρ) sub1040 a0) sub5)) (consAll (lamAt d786 c786 (smaller (h2263 (Types.cons s370 ρ) sub249 a0) sub1040)) Positive.none)))))
theorem h2472 (ρ : Env) (a0 : Fits s372 (ρ 0)) : All tab ρ b12 s364 :=
  (consAll (lamAt d789 c789 (smaller (h2264 (Types.cons s371 ρ) sub250 a0) sub556)) (consAll (lamAt d791 c791 (smaller (h2265 (Types.cons s372 ρ) sub558 a0) sub556)) (consAll (lamAt d798 c798 (smaller (h2268 (Types.cons s376 ρ) sub254 a0) sub1041)) (consAll (lamAt d805 c805 (smaller (h2270 (Types.cons s379 ρ) sub256 a0) sub255)) Positive.none))))
theorem h2473 (ρ : Env) (a0 : Fits s382 (ρ 0)) : All tab ρ b12 s665 :=
  (consAll (lamAt d796 c796 (smaller (h2272 (Types.cons s217 ρ) sub474 a0) sub5)) Positive.none)
theorem h2474 (ρ : Env) (a0 : Fits s386 (ρ 0)) : All tab ρ b12 s382 :=
  (consAll (lamAt d815 c815 (smaller (h2275 (Types.cons s385 ρ) sub259 a0) sub5)) Positive.none)
theorem h2475 (ρ : Env) (a0 : Fits s389 (ρ 0)) : All tab ρ b12 s381 :=
  (consAll (lamAt d817 c817 (smaller (h2277 (Types.cons s386 ρ) sub567 a0) sub5)) (consAll (lamAt d824 c824 (smaller (h2278 (Types.cons s389 ρ) sub569 a0) sub5)) Positive.none))
theorem h2476 (ρ : Env) (a0 : Fits s392 (ρ 0)) : All tab ρ b12 s389 :=
  (consAll (lamAt d826 c826 (smaller (h2279 (Types.cons s390 ρ) sub1245 a0) sub5)) (consAll (lamAt d830 c830 (smaller (h2280 (Types.cons s394 ρ) sub1042 a0) sub5)) (consAll (lamAt d832 c832 (smaller (h2281 (Types.cons s396 ρ) sub265 a0) sub1042)) (consAll (lamAt d836 c836 (smaller (h2282 (Types.cons s398 ρ) sub1043 a0) sub1042)) (consAll (lamAt d838 c838 (smaller (h2283 (Types.cons s400 ρ) sub267 a0) sub1043)) Positive.none)))))
theorem h2477 (ρ : Env) (a0 : Fits s402 (ρ 0)) : All tab ρ b12 s392 :=
  (consAll (lamAt d841 c841 (smaller (h2284 (Types.cons s401 ρ) sub268 a0) sub572)) (consAll (lamAt d843 c843 (smaller (h2285 (Types.cons s402 ρ) sub574 a0) sub572)) (consAll (lamAt d849 c849 (smaller (h2287 (Types.cons s406 ρ) sub1248 a0) sub1249)) (consAll (lamAt d852 c852 (smaller (h2288 (Types.cons s408 ρ) sub1044 a0) sub1104)) (consAll (lamAt d860 c860 (smaller (h2290 (Types.cons s413 ρ) sub274 a0) sub1044)) (consAll (lamAt d881 c881 (smaller (h2297 (Types.cons s423 ρ) sub280 a0) sub1045)) (consAll (lamAt d888 c888 (smaller (h2299 (Types.cons s426 ρ) sub282 a0) sub281)) (consAll (lamAt d1092 c1092 (smaller (h2377 (Types.cons s229 ρ) sub151 a0) sub646)) Positive.none))))))))
theorem h2478 (ρ : Env) (a0 : Fits s405 (ρ 0)) : All tab ρ b12 s393 :=
  (consAll (lamAt d833 c833 (smaller (h2286 (Types.cons s392 ρ) sub573 a0) sub1042)) Positive.none)
theorem h2479 (ρ : Env) (a0 : Fits s411 (ρ 0)) : All tab ρ b12 s405 :=
  (consAll (lamAt d855 c855 (smaller (h2289 (Types.cons s410 ρ) sub273 a0) sub1044)) (consAll (lamAt d863 c863 (smaller (h2291 (Types.cons s414 ρ) sub275 a0) sub274)) (consAll (lamAt d926 c926 (smaller (h2315 (Types.cons s220 ρ) sub478 a0) sub601)) Positive.none)))
theorem h2480 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s408 :=
  (consAll (lamAt d854 c854 (smaller (h2292 (Types.cons s409 ρ) sub276 a0) sub1106)) (consAll (lamAt d870 c870 (smaller (h2293 (Types.cons s416 ρ) sub277 a0) sub1105)) Positive.none))
theorem h2481 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s673 :=
  (consAll (lamAt d853 c853 (smaller (h2294 (Types.cons s402 ρ) sub574 a0) sub1104)) Positive.none)
theorem h2482 (ρ : Env) (a0 : Fits s419 (ρ 0)) : All tab ρ b12 s394 :=
  (consAll (lamAt d831 c831 (smaller (h2295 (Types.cons s395 ρ) sub1246 a0) sub5)) (consAll (lamAt d879 c879 (smaller (h2296 (Types.cons s421 ρ) sub1045 a0) sub5)) (consAll (lamAt d885 c885 (smaller (h2298 (Types.cons s425 ρ) sub281 a0) sub1045)) Positive.none)))
theorem h2483 (ρ : Env) (a0 : Fits s428 (ρ 0)) : All tab ρ b12 s419 :=
  (consAll (lamAt d891 c891 (smaller (h2300 (Types.cons s427 ρ) sub283 a0) sub587)) (consAll (lamAt d898 c898 (smaller (h2303 (Types.cons s431 ρ) sub285 a0) sub5)) Positive.none))
theorem h2484 (ρ : Env) (a0 : Fits s429 (ρ 0)) : All tab ρ b12 s421 :=
  (consAll (lamAt d16 c16 (smaller (h2302 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d880 c880 (smaller (h2301 (Types.cons s422 ρ) sub284 a0) sub5)) Positive.none))
theorem h2485 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s429 :=
  (consAll (lamAt d901 c901 (smaller (h2304 (Types.cons s432 ρ) sub286 a0) sub590)) Positive.none)
theorem h2486 (ρ : Env) (a0 : Fits s434 (ρ 0)) : All tab ρ b12 s418 :=
  (consAll (lamAt d899 c899 (smaller (h2305 (Types.cons s428 ρ) sub591 a0) sub5)) (consAll (lamAt d906 c906 (smaller (h2306 (Types.cons s434 ρ) sub593 a0) sub5)) Positive.none))
theorem h2487 (ρ : Env) (a0 : Fits s437 (ρ 0)) : All tab ρ b12 s434 :=
  (consAll (lamAt d16 c16 (smaller (h2308 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d908 c908 (smaller (h2307 (Types.cons s435 ρ) sub1255 a0) sub5)) (consAll (lamAt d912 c912 (smaller (h2309 (Types.cons s439 ρ) sub290 a0) sub5)) (consAll (lamAt d916 c916 (smaller (h2310 (Types.cons s441 ρ) sub1046 a0) sub5)) (consAll (lamAt d918 c918 (smaller (h2311 (Types.cons s443 ρ) sub292 a0) sub1046)) Positive.none)))))
theorem h2488 (ρ : Env) (a0 : Fits s445 (ρ 0)) : All tab ρ b12 s437 :=
  (consAll (lamAt d921 c921 (smaller (h2312 (Types.cons s444 ρ) sub293 a0) sub596)) (consAll (lamAt d923 c923 (smaller (h2313 (Types.cons s445 ρ) sub598 a0) sub596)) (consAll (lamAt d957 c957 (smaller (h2325 (Types.cons s460 ρ) sub304 a0) sub5)) (consAll (lamAt d964 c964 (smaller (h2327 (Types.cons s463 ρ) sub306 a0) sub305)) Positive.none))))
theorem h2489 (ρ : Env) (a0 : Fits s451 (ρ 0)) : All tab ρ b12 s404 :=
  (consAll (lamAt d16 c16 (smaller (h2357 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d934 c934 (smaller (h2318 (Types.cons s449 ρ) sub298 a0) sub1260)) (consAll (lamAt d940 c940 (smaller (h2319 (Types.cons s452 ρ) sub299 a0) sub1108)) (consAll (lamAt d985 c985 (smaller (h2350 (Types.cons s475 ρ) sub1268 a0) sub5)) (consAll (lamAt d987 c987 (smaller (h2341 (Types.cons s472 ρ) sub618 a0) sub1048)) (consAll (lamAt d1002 c1002 (smaller (h2349 (Types.cons s480 ρ) sub619 a0) sub1110)) (consAll (lamAt d1003 c1003 (smaller (h2347 (Types.cons s484 ρ) sub325 a0) sub1272)) (consAll (lamAt d1017 c1017 (smaller (h2348 (Types.cons s490 ρ) sub326 a0) sub1111)) (consAll (lamAt d1024 c1024 (smaller (h2351 (Types.cons s492 ρ) sub1050 a0) sub5)) (consAll (lamAt d1025 c1025 (smaller (h2356 (Types.cons s493 ρ) sub333 a0) sub5)) (consAll (lamAt d1030 c1030 (smaller (h2353 (Types.cons s496 ρ) sub330 a0) sub1050)) Positive.none)))))))))))
theorem h2490 (ρ : Env) (a0 : Fits s455 (ρ 0)) : All tab ρ b12 s451 :=
  (consAll (lamAt d945 c945 (smaller (h2321 (Types.cons s453 ρ) sub301 a0) sub1262)) (consAll (lamAt d950 c950 (smaller (h2322 (Types.cons s456 ρ) sub302 a0) sub1109)) (consAll (lamAt d1004 c1004 (smaller (h2344 (Types.cons s485 ρ) sub322 a0) sub1049)) (consAll (lamAt d1011 c1011 (smaller (h2346 (Types.cons s488 ρ) sub324 a0) sub323)) (consAll (lamAt d1036 c1036 (smaller (h2355 (Types.cons s498 ρ) sub332 a0) sub629)) (consAll (lamAt d1040 c1040 (smaller (h2358 (Types.cons s500 ρ) sub334 a0) sub5)) (consAll (lamAt d1043 c1043 (smaller (h2359 (Types.cons s489 ρ) sub335 a0) sub631)) Positive.none)))))))
theorem h2491 (ρ : Env) (a0 : Fits s458 (ρ 0)) : All tab ρ b12 s417 :=
  (consAll (lamAt d16 c16 (smaller (h2324 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d917 c917 (smaller (h2323 (Types.cons s442 ρ) sub1256 a0) sub5)) (consAll (lamAt d961 c961 (smaller (h2326 (Types.cons s462 ρ) sub305 a0) sub5)) (consAll (lamAt d962 c962 (smaller (h2329 (Types.cons s458 ρ) sub610 a0) sub5)) Positive.none))))
theorem h2492 (ρ : Env) (a0 : Fits s465 (ρ 0)) : All tab ρ b12 s458 :=
  (consAll (lamAt d16 c16 (smaller (h2331 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d967 c967 (smaller (h2328 (Types.cons s464 ρ) sub307 a0) sub609)) (consAll (lamAt d971 c971 (smaller (h2330 (Types.cons s466 ρ) sub309 a0) sub5)) (consAll (lamAt d973 c973 (smaller (h2332 (Types.cons s468 ρ) sub310 a0) sub5)) Positive.none))))
theorem h2493 (ρ : Env) (a0 : Fits s469 (ρ 0)) : All tab ρ b12 s457 :=
  (consAll (lamAt d974 c974 (smaller (h2333 (Types.cons s465 ρ) sub612 a0) sub5)) (consAll (lamAt d978 c978 (smaller (h2334 (Types.cons s469 ρ) sub614 a0) sub5)) Positive.none))
theorem h2494 (ρ : Env) (a0 : Fits s472 (ρ 0)) : All tab ρ b12 s469 :=
  (consAll (lamAt d980 c980 (smaller (h2335 (Types.cons s470 ρ) sub1267 a0) sub5)) (consAll (lamAt d984 c984 (smaller (h2336 (Types.cons s474 ρ) sub1048 a0) sub5)) (consAll (lamAt d986 c986 (smaller (h2337 (Types.cons s476 ρ) sub315 a0) sub1048)) (consAll (lamAt d990 c990 (smaller (h2338 (Types.cons s478 ρ) sub316 a0) sub315)) Positive.none))))
theorem h2495 (ρ : Env) (a0 : Fits s480 (ρ 0)) : All tab ρ b12 s472 :=
  (consAll (lamAt d993 c993 (smaller (h2339 (Types.cons s479 ρ) sub317 a0) sub617)) (consAll (lamAt d995 c995 (smaller (h2340 (Types.cons s480 ρ) sub619 a0) sub617)) (consAll (lamAt d998 c998 (smaller (h2342 (Types.cons s481 ρ) sub1270 a0) sub1271)) (consAll (lamAt d1001 c1001 (smaller (h2343 (Types.cons s483 ρ) sub1049 a0) sub1110)) (consAll (lamAt d1008 c1008 (smaller (h2345 (Types.cons s487 ρ) sub323 a0) sub1049)) (consAll (lamAt d1026 c1026 (smaller (h2352 (Types.cons s494 ρ) sub329 a0) sub1050)) (consAll (lamAt d1033 c1033 (smaller (h2354 (Types.cons s497 ρ) sub331 a0) sub330)) Positive.none)))))))
theorem h2496 (ρ : Env) (a0 : Fits s501 (ρ 0)) : All tab ρ b12 s455 :=
  (consAll (lamAt d1044 c1044 (smaller (h2360 (Types.cons s455 ρ) sub632 a0) sub631)) (consAll (lamAt d1048 c1048 (smaller (h2361 (Types.cons s502 ρ) sub337 a0) sub1279)) (consAll (lamAt d1051 c1051 (smaller (h2362 (Types.cons s503 ρ) sub338 a0) sub1112)) (consAll (lamAt d1065 c1065 (smaller (h2366 (Types.cons s508 ρ) sub1282 a0) sub1283)) (consAll (lamAt d1068 c1068 (smaller (h2367 (Types.cons s510 ρ) sub342 a0) sub1113)) (consAll (lamAt d1076 c1076 (smaller (h2369 (Types.cons s514 ρ) sub344 a0) sub342)) Positive.none))))))
theorem h2497 (ρ : Env) (a0 : Fits s507 (ρ 0)) : All tab ρ b12 s403 :=
  (consAll (lamAt d1041 c1041 (smaller (h2365 (Types.cons s455 ρ) sub632 a0) sub5)) (consAll (lamAt d1049 c1049 (smaller (h2364 (Types.cons s501 ρ) sub633 a0) sub1318)) (consAll (lamAt d1064 c1064 (smaller (h2371 (Types.cons s507 ρ) sub639 a0) sub5)) (consAll (lamAt d1069 c1069 (smaller (h2364 (Types.cons s501 ρ) sub633 a0) sub1319)) (consAll (lamAt d1077 c1077 (smaller (h2364 (Types.cons s501 ρ) sub633 a0) sub1320)) Positive.none)))))
theorem h2498 (ρ : Env) (a0 : Fits s512 (ρ 0)) : All tab ρ b12 s507 :=
  (consAll (lamAt d16 c16 (smaller (h2373 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d1071 c1071 (smaller (h2368 (Types.cons s511 ρ) sub343 a0) sub342)) (consAll (lamAt d1079 c1079 (smaller (h2370 (Types.cons s515 ρ) sub345 a0) sub344)) (consAll (lamAt d1082 c1082 (smaller (h2372 (Types.cons s516 ρ) sub347 a0) sub5)) (consAll (lamAt d1084 c1084 (smaller (h2374 (Types.cons s518 ρ) sub348 a0) sub5)) Positive.none)))))
theorem h2499 (ρ : Env) (a0 : Fits s389 (ρ 0)) : All tab ρ b12 s506 :=
  (consAll (lamAt d824 c824 (smaller (h2278 (Types.cons s389 ρ) sub569 a0) sub5)) (consAll (lamAt d1085 c1085 (smaller (h2375 (Types.cons s512 ρ) sub644 a0) sub5)) Positive.none))
end Blc.H45.H45F9573528477238
