from grade_rows import inds,lc
from functools import lru_cache
def nums(a):return '['+','.join(map(str,a))+']'
def deriv(graph,term,rr,cc,target):
 n=len(graph);lines=[];pr={};ids={}
 def lit(t):
    if t in ids:return ids[t]
    rhs='.var '+str(t[1]) if t[0]=='V' else '.lam '+lit(t[1]) if t[0]=='L' else '.app '+lit(t[1])+' '+lit(t[2])
    name='lit'+str(len(ids));ids[t]=name;lines.append('def '+name+' : Term := '+rhs);return name
 lit(term)
 # Each free slot is an actual canonical set. Environment-independent slots
 # do not appear in the proof lemma or in the search memo key.
 def en(t,ds):return tuple(ds[i] for i in inds(t))
 def lamenv(b,ds,dom):return tuple(tuple(dom) if i==0 else ds[i-1] for i in inds(b))
 @lru_cache(40000)
 def values(t,env):
    ds=dict(zip(inds(t),env))
    if t[0]=='V':return frozenset(env[0])
    if t[0]=='L':return frozenset(i for i,ars in enumerate(graph) if ars is not None and all(z in values(t[1],lamenv(t[1],ds,d)) for d,z in ars))
    f,a=t[1:];F=values(f,en(f,ds));A=values(a,en(a,ds))
    return frozenset(z for i in F for d,z in graph[i] or [] if A.issuperset(d))
 def allproof(hs):
    e='allNil'
    for h in reversed(hs):e=f'(allCons {h} {e})'
    return e
 def proof(t,env,z):
    key=(t,env,z)
    if key in pr:return pr[key]
    ds=dict(zip(inds(t),env));assert z in values(t,env)
    def use(u,uu,j,ext=False):
       q=proof(u,uu,j);ev='(push _ e)' if ext else 'e';args=[]
       for i in inds(u):args.append('rfl' if ext and i==0 else 'h'+str(i-int(ext)))
       return '('+' '.join([q,ev]+args)+')'
    if t[0]=='V':body=f'.var (by rw [h{t[1]}]; decide)'
    elif t[0]=='L':
       b=t[1];hs=[use(b,lamenv(b,ds,d),j,True).replace('(push _ e)',f'(push {nums(d)} e)') for d,j in graph[z]]
       body=f'.lam (ars := ars{z}) (by rfl) {allproof(hs)}'
    else:
       f,a=t[1:];fe=en(f,ds);ae=en(a,ds)
       _,i,dom=min((len(d),i,tuple(d)) for i in values(f,fe) for d,j in graph[i] or [] if j==z and values(a,ae).issuperset(d))
       hs=[use(a,ae,j) for j in dom]
       body=f'.app (z := {i}) (ars := ars{i}) (a := ⟨{nums(dom)},{z}⟩) (by rfl) (by decide) {use(f,fe,i)} {allproof(hs)}'
    name='q'+str(len(pr));pr[key]=name
    params=' '.join(f'(h{i} : e {i} = {nums(d)})' for i,d in ds.items())
    lines.append(f'theorem {name} (e : Env {n}) {params} : Ty graph e {lit(t)} {z} := {body}')
    return name
 initial=tuple(tuple(rr if i==0 else cc) for i in inds(term));p=proof(term,initial,target)
 return lines,'('+p+' env'+' rfl'*len(inds(term))+')'
