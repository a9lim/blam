from probe_rows import *
def derive(n,lo,tab,term,x,y,G):
 op,pick,val=calculus(n,lo,tab);ls=[];ts={};pr={}
 def lit(t):
    if t in ts:return ts[t]
    r='.var '+str(t[1]) if t[0]=='V' else '.lam '+lit(t[1]) if t[0]=='L' else '.app '+lit(t[1])+' '+lit(t[2])
    nm='lit'+str(len(ts));ts[t]=nm;ls.append(f'def {nm} : Term := {r}');return nm
 lit(term)
 def prove(t,env):
    if (t,env) in pr:return pr[t,env]
    ds=dict(zip(inds(t),env));z=val(t,env)
    def child(u,ee,push=None):
       m=prove(u,ee);ev='e' if push is None else f'(push {push} e)'
       pars=['rfl' if push is not None and j==0 else 'h'+str(j-int(push is not None)) for j in inds(u)]
       return '('+' '.join([m,ev,*pars])+')'
    if t[0]=='V':body=f'.var _ _ (by rw [h{t[1]}]; decide)'
    elif t[0]=='A':
       cs=[child(u,tuple(ds[j] for j in inds(u))) for u in t[1:]];body=f'.app {cs[0]} {cs[1]} (by decide)'
    else:
       u=t[1]
       cases=' ∨ '.join(f'a={k}' for k in range(n))
       body='by\n  apply Typed.lam (by decide)\n  intro a\n  have hcases : '+cases+f' := (by decide : ∀ a : Fin {n}, {cases}) a\n  rcases hcases with '+' | '.join(['el']*n)
       for k in range(n):
          ee=tuple(k if j==0 else ds[j-1] for j in inds(u));h=child(u,ee,k)
          body+=f'\n  · subst a; exact {h}.weaken _ (by decide)'
    m='q'+str(len(pr));pr[t,env]=m;par=' '.join(f'(h{j} : e {j} = {ds[j]})' for j in inds(t))
    ls.append(f'theorem {m} (e : Env {n-1}) {par} : Typed {G} e {lit(t)} {z} := {body}')
    return m
 init=tuple(y if j==0 else x for j in inds(term));q=prove(term,init)
 return ls,'('+q+f' (rho (n := {n-1}) {x} {y})'+' rfl'*len(init)+')'
def main():
 import probe_rows
 probe_rows.main()
 for s,(kind,id,n,lo,tab,x,y,a,b) in assignment().items():
    if kind!='probe':continue
    nm='e'+str(int(s,2));mod='Probe'+nm[1:];ns='Blc.Floor45.'+mod;t=get(s,id)[4];table='Op'+sha256(f'{n}/{lo}/{tab}'.encode()).hexdigest()[:12]
    ls,ht=derive(n,lo,tab,t,x,y,table+'.G');groups=[];chunk=[];sz=0
    for line in ls:
       chunk.append(line);sz+=len(line)
       if sz>30000:groups.append(chunk);chunk=[];sz=0
    if chunk:groups.append(chunk)
    prev=table
    for j,group in enumerate(groups):
       name=mod+'D'+str(j);ls=['import '+prev,'import Guided','namespace '+ns,hdr]+group+['end '+ns]
       (HERE/(name+'.lean')).write_text('\n'.join(ls)+'\n');prev=name
    p=HERE/(mod+'.lean');z=p.read_text().replace('import '+table+'\n','import '+prev+'\n').replace('apply afterCut ','apply afterTyped ').replace('  · decide\n  · decide\n  · decide','  · decide\n  · exact '+ht+'\n  · decide')
    p.write_text(z)
if __name__=='__main__':main()
