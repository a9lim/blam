"""Split only a rejected kernel range check into individual checked transitions."""
from pathlib import Path
import re
D=Path(__file__).resolve().parent
def main():
 count=0
 for p in (D/'.checked').glob('Reg*.log'):
  s=p.read_text()
  if 'excessive memory' not in s:continue
  src=D/(p.stem+'.lean');ls=src.read_text().splitlines();changed=False
  for index in {int(v)-1 for v in re.findall(r'\.lean:(\d+):\d+: error:',s)}:
   if not 0<=index<len(ls):continue
   m=re.fullmatch(r'theorem ok(\d+) : RegProof.Span ck (\d+) (\d+) := RegProof.block .*',ls[index])
   if not m:continue
   label,a,b=map(int,m.groups())
   def tree(i,j):
    if j==i+1:return f'(RegProof.block (a := {i}) (n := 1) (by decide +kernel))'
    mid=(i+j)//2;return f'(RegProof.merge {tree(i,mid)} {tree(mid,j)})'
   ls[index]=f'theorem ok{label} : RegProof.Span ck {a} {b} := '+tree(a,b);changed=True
  if changed:src.write_text('\n'.join(ls)+'\n');print(p.stem);count+=1
 print(count,'modules adjusted')
if __name__=='__main__':main()
