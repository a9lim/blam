"""Match all literal leaves, the three bounded proof roots, and the composition theorem."""
from jsonstream import ledger
from pathlib import Path
import re
D=Path(__file__).resolve().parent
def check(ast):
 rows=(r for r in ledger(D/'ledger.json') if r['module']!='H45Bridge' and r['strength']=='complete' and not r['kind'].startswith('W'))
 checked=0
 for j in range(176):
  m=f'PartData{j:03}';s=(D/(m+'.lean')).read_text();ls=re.findall(r'^  (\(.*\))[,]?$',s,re.M)
  assert len(ls)==(40 if j!=175 else 16)
  for lit in ls:
   r=next(rows);t,end,_=ast(r['wire'],0,0);assert end==45 and lit==t;checked+=1
  assert f'theorem checked : Aggregate.Safe {m}.terms := ResidualGroup{j:03}.bad0' in (D/f'PartProof{j:03}.lean').read_text()
 assert checked==7016 and next(rows,None) is None
 ns=[(f'PartData{j:03}',f'PartProof{j:03}') for j in range(176)]
 for level in range(2):
  n=[]
  for off in range(0,len(ns),8):
   sub=ns[off:off+8];raw=f'SetData{level:02}P{off//8:03}';pr=raw.replace('Data','Proof')
   wire=(D/(raw+'.lean')).read_text().split('def terms : List Term := ')[1].splitlines()[0]
   assert re.findall(r'\w+\.terms',wire)==[a+'.terms' for a,_ in sub]
   proof=(D/(pr+'.lean')).read_text()
   assert f'theorem checked : Aggregate.Safe {raw}.terms' in proof
   assert set(re.findall(r'\w+\.checked',proof.split(' := ')[1]))=={p+'.checked' for _,p in sub}
   n.append((raw,pr))
  ns=n
 mod=(D/'Residuals.lean').read_text()
 assert re.findall(r'\w+\.terms',mod.split('def residuals : List Term := ')[1].splitlines()[0])==[a+'.terms' for a,p in ns]
 for i,(a,p) in enumerate(ns):
  assert f'theorem partition_checked : Aggregate.Safe {a}.terms := {p}.checked' in (D/f'AttachPart{i}.lean').read_text()
  assert f': Aggregate.Safe {a}.terms)' in mod
 final=[r for r in ledger(D/'ledger.json') if r['module']=='H45Bridge']
 assert len(final)==10
 for i,r in enumerate(final):
  text=(D/'FinalTen.lean').read_text()
  assert f'def xs{i} : List Term := {r["term"]} :: ' in text
  assert f'  · exact {r["theorem"]}\n' in text
 assert '++ FinalTen.xs0' in mod and 'FinalTen.checked0' in mod
 return checked+len(final)
