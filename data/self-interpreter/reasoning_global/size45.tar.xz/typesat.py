"""Synthesize a finite recursive intersection type assignment for a fixed probe."""
from probes import *
from harder import remain
from grade_rows import inds
from satmodel import CNF,CAD,Limit
import shutil,subprocess,time
from functools import lru_cache
def synth(d,n,m,t,u,raw,sec):
 f=CNF(d/'body')
 def and_(x):return f.every(x)
 def or_(x):return -and_(-a for a in x)
 def imp(a,b):return or_([-a,b])
 ret=[[[f.v() for k in range(n)] for j in range(m)] for i in range(n)]
 dom=[[f.v() for i in range(n)] for j in range(m)]
 allow=[f.v() for i in range(n)]
 for i in range(n):
    for j in range(m):
       for b in range(n):f.add(-ret[i][j][b],allow[i])
 # Free rigid markers may receive independent atomic assumptions.
 freev=[[f.v() for i in range(n)] for j in range(2)]
 if raw:
    f.add(-allow[0])
    for x in freev:
       for v in x:f.add(-v)
 envs=dom+freev
 @lru_cache(None)
 def ev(t,env):
    if t[0]=='V':return envs[env[0]]
    ds=dict(zip(inds(t),env))
    if t[0]=='L':
       b=t[1];subs=[ev(b,tuple(j if a==0 else ds[a-1] for a in inds(b))) for j in range(m)]
       return [and_([allow[i]]+[imp(ret[i][j][b],subs[j][b]) for j in range(m) for b in range(n)]) for i in range(n)]
    def sub(z):return ev(z,tuple(ds[i] for i in inds(z)))
    fn,ar=sub(t[1]),sub(t[2])
    fits=[and_(imp(dom[j][b],ar[b]) for b in range(n)) for j in range(m)]
    use=[[and_([fn[i],fits[j]]) for j in range(m)] for i in range(n)]
    return [or_(and_([use[i][j],ret[i][j][b]]) for i in range(n) for j in range(m)) for b in range(n)]
 def E(t):return ev(t,tuple(m+i for i in inds(t)))
 try:
    aa=E(t)
    if raw:f.add(aa[0])
    else:
       bb=E(u);f.add(*(and_([a,-b]) for a,b in zip(aa,bb)))
 except Limit:return
 finally:f.file.close();ev.cache_clear()
 with (d/'q.cnf').open('wb') as o:
    o.write(f'p cnf {f.count} {f.nclauses}\n'.encode())
    with (d/'body').open('rb') as z:shutil.copyfileobj(z,o)
 try:q=subprocess.run([str(CAD),'-q','-t',str(sec),str(d/'q.cnf')],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=sec+2)
 except subprocess.TimeoutExpired:return
 if q.returncode!=10:return
 vs={int(x) for ln in q.stdout.decode().splitlines() if ln.startswith('v ') for x in ln.split()[1:]}
 def maskv(a):return [i for i,x in enumerate(a) if x in vs]
 rules=[None if allow[i] not in vs else [[maskv(dom[j]),b] for j in range(m) for b in range(n) if ret[i][j][b] in vs] for i in range(n)]
 return [rules,maskv(freev[0]),maskv(freev[1]),maskv(aa)[0] if raw else min(set(maskv(aa))-set(maskv(bb)))]
def run(n,m,sec,phase):
 d=HERE/'abstract';d.mkdir(exist_ok=True);work=d/f'work{n}_{m}_{phase}';work.mkdir(exist_ok=True)
 for s in remain():
    dest=d/(s+'.json')
    if dest.exists():continue
    opts=['!','0:0:0','1:1:3'] if not phase else ['1:1:4','0:1:5','2:1:3','0:0:8','3:1:5','!','0:0:0']
    e=lc.decode(s)[0]
    for id in opts:
       if id=='!':t=e;u=None
       else:
           try:_,_,_,_,t,u,_,_=get(s,id)
           except (TypeError,IndexError):continue
           if wire(t)>260:continue
       if z:=synth(work,n,m,t,u,id=='!',sec):
           dest.write_text(json.dumps([id,*z]));break
if __name__=='__main__':run(*map(int,sys.argv[1:]))
