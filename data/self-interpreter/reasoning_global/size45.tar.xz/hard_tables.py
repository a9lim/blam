from pathlib import Path
from subprocess import run
import sys
d=Path(__file__).resolve().parent
ss=set((d/'hard.in').read_text().split());out=d/'hardprobe';out.mkdir(exist_ok=True)
for z,p in enumerate(sorted((d/'probes').glob('*.in'))):
 if z%int(sys.argv[2])!=int(sys.argv[1]):continue
 dest=out/p.name;rows=[x for x in p.read_text().splitlines() if x.split(' ',1)[0] in ss]
 if not rows:continue
 dest.write_text('\n'.join(rows)+'\n');q=dest.with_suffix('.out')
 if q.exists():continue
 tmp=q.with_suffix('.tmp')
 with tmp.open('w') as f:run([str(d/'probesearch'),str(dest),str(d/'tables.in'),'4'],stdout=f,check=True,timeout=200)
 tmp.replace(q)
