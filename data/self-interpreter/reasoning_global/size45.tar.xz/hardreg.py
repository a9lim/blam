from hard import *
from extras import K
from regscan import search
for s in (HERE/'hard.in').read_text().split():
 p=HERE/('r'+str(int(s,2))+'.json')
 if p.exists():continue
 # Test loaded suffixes and Church-false quotes before site-sensitive discovery.
 e=lc.decode(s)[0]
 opts=[(KI,KI,V(0),[om]*j) for j in (4,3,2,6,1,5)]+[(K,I,om,[om]*j+[I]) for j in (1,2,3)]
 hit=False
 for c,m,r,aa in opts:
    q=probe(e,c,m,r,aa)
    if target_steps(c,m,r,aa) is None:continue
    for k,alloc in [(0,'site'),(1,'argenv'),(2,'site'),(2,'argenv')]:
       try:z=regular.discover(mask(q),k,cap=3500,seconds=.035,mode=alloc)
       except regular.Limit:continue
       if z['ok'] and z['states']<2200:
          cert=portable.portable(z);p=HERE/('h'+str(int(s,2))+'.json')
          p.write_text(json.dumps([len(cert['states']),('probe',[lc.enc(x) for x in (c,m,r)],[lc.enc(x) for x in aa]),0,k,alloc,[],cert]));hit=True;break
    if hit:break
 if not hit:
    if r:=search(s,1):p.write_text(json.dumps(r))
