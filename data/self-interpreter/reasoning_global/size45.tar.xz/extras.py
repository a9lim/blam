from so import so
from hard import variant, weak_path, simp_path, om
from candidates import *
from ranktest import profile
K=L(L(V(1)))
def probe(e):
    for kind,q in [('src',e),('K',A(e,K)),('delta',A(e,om[1]))]:
        seen=set()
        for style in (1,0,2,3):
            t=q;ps=[]
            for j in range(42):
                if t not in seen:
                    seen.add(t)
                    if kind=='src' and (k:=sourcefact(t)):return [k,ps]
                    if kind!='delta' and so(t):return ['so'+kind,ps]
                    if kind!='K' and j<15:
                        for c in (1,2,3,4):
                            n,_,ok=profile(t,c)
                            if n==0 and ok:return ['rank',ps,kind,c]
                p=variant(t,style) if style<3 else normal_path(t)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps=ps+[p]
    return None
if __name__=='__main__':
    done={}
    for s in (HERE/'open.txt').read_text().split():
        if r:=probe(lc.decode(s)[0]):done[s]=r
    (HERE/'extra.json').write_text(json.dumps(done))
    (HERE/'rem.txt').write_text(''.join(s+'\n' for s in (HERE/'open.txt').read_text().split() if s not in done))
    print(Counter(r[0] for r in done.values()), 'remain',491-len(done))
