from pathlib import Path
import resource,subprocess,sys,os,json,time
d=Path(__file__).resolve().parent
j,n=map(int,sys.argv[1:3]);t=time.monotonic()
for i in range(j,2670,12*n):
 if time.monotonic()-t>480:sys.exit(75)
 if all((d/f'Batch{k:04}.lean').exists() for k in range(i,min(i+12*n,2670),n)):continue
 p=subprocess.Popen([sys.executable,'-B','screen.py',str(i),str(n),str(i+12*n)],cwd=d)
 _,st,r=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st)
 with (d/'screen-metrics.jsonl').open('a') as f:f.write(json.dumps([i,n,p.returncode,r.ru_maxrss])+'\n')
 if p.returncode:sys.exit(1)
 assert r.ru_maxrss<1_000_000_000
