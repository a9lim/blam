from observed import material,lc,HERE
from jsonstream import ledger
import json
def main():
 rows=json.loads((HERE/'pending-probes.json').read_text());names={r['wire']:r['module'] for r in ledger(HERE/'ledger.json') if r['wire'] in rows};out={}
 for s,v in rows.items():
  if not v['mismatch']:continue
  c,m,r,args,a,b,i,j=v['mismatch'];num=int(s,2)
  rec=material(s,*[lc.decode(x)[0] for x in (c,m,r)],[lc.decode(x)[0] for x in args],a,b,i,j)
  src=HERE/(rec['module']+'.lean');local=src.read_text()
  mod='PendingObserve'+str(num);ns='Blc.Floor45.'+mod;t=f'Blc.Floor45.e{num}';th='ex_e'+str(num)
  text=local.replace('import Observe','import Observe\nimport '+names[s]).replace('Blc.Floor45.'+rec['module'],ns)
  text=text.replace('end '+ns,f'theorem excluded : ¬ IsSelfInterpreter {t} := {th}\n#print axioms excluded\nend '+ns)
  (HERE/(mod+'.lean')).write_text(text)
  out[s]=dict(wire=s,file=mod+'.lean',theorem=ns+'.excluded',statement='¬ Blc.IsSelfInterpreter '+t)
 return out
if __name__=='__main__':print(main())
