from probes import *
from harder import remain
import sys
ss=remain();dst=HERE/'types.in'
with dst.open('w') as f:
 for s in ss:
    e=lc.decode(s)[0];f.write(f'{s} ! {s} 10\n')
    for pid in [0,1,2,3,4,5,6,9,11,12]:
     for style,j in [(0,0),(1,2),(1,5),(0,8)]:
      id=f'{pid}:{style}:{j}'
      try:_,_,_,_,t,u,_,_=get(s,id)
      except (TypeError,IndexError):continue
      if wire(t)<=180:f.write(f'{s} {id} {lc.enc(t)} {lc.enc(u)}\n')
