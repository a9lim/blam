from deep import *
from collections import defaultdict
def soproof(t):
    k,*args=so(t)
    if k=='var':return f'(SO.var {t[1]})'
    if k=='app':return f'(SO.app {soproof(t[1])} {soproof(t[2])})'
    b=soproof(t[1])
    if k=='closed':return f'(so_closed_lam (by decide) {b})'
    if k=='dead':return f'(so_dead (by decide) {b})'
    r,g=args
    return f'(SO.lam (g := {expr(g)}) (r := {expr(r)}) {b} {soproof(r)} (by decide) (by rfl))'
def emit(s,r):
    nm='e'+str(int(s,2));e=lc.decode(s)[0];k,ps,*cfg=r
    template='theorem ex_'+nm+' : ¬ IsSelfInterpreter '+nm+' := by\n  intro he\n'
    if k=='width':
        return f'theorem ex_{nm} : check {nm} {paths(ps)} .width = true := by decide\n'
    st=nm;t=e
    if k=='soK':st='(.app '+nm+' churchTrue)';t=A(t,K)
    elif k=='pairSO':st='(projPair '+nm+')';t=A(A(A(t,K),lc.bitlist(lc.enc(P),I)),I)
    elif k=='rank' and cfg[0]=='delta':st='(.app '+nm+' diag)';t=A(t,om[1])
    elif k in ('absent','mismatch'):
        c,m,rr=[lc.decode(x)[0] for x in cfg[:3]];aa=[lc.decode(x)[0] for x in cfg[3]]
        st='(call '+nm+' '+' '.join(map(expr,[c,m,rr]))+' ['+','.join(map(expr,aa))+'])'
        t=appall(A(A(e,c),lc.bitlist(lc.enc(m),rr)),aa)
    for p in ps:t=red(t,p)
    u='t_'+nm
    out=f'private def {u} : Term := {expr(t)}\n'+template+f'  have hp := replay_sound (t := {st}) (u := {u}) (ps := {paths(ps)}) (by decide)\n'
    if k.startswith('so') or k=='pairSO':
        app={'sosrc':'selfInterpreter_not_so (reductSI hp he)','soK':'specialized_not_so he hp','pairSO':'pair_not_so he hp'}[k]
        out+=f'  apply {app}\n  exact {soproof(t)}\n'
    elif k=='rank':
        count='rawCount' if cfg[0]=='src' else 'deltaCount'
        out+=f'  obtain ⟨_, hc⟩ := WeakHeadClock.count_reduct _ (Exists.choose_spec ({count} he)) hp\n' if False else f'  obtain ⟨n, hc⟩ := {count} he\n  obtain ⟨j, _, hj⟩ := WeakHeadClock.count_reduct n hc hp\n  exact Weighted.no_clock {cfg[1]} (by decide : Closed {u}) (by decide) (by decide) hj\n'
    elif k=='dead':
        out+=f'  have h := SelfintRound6BoundLiteral.one_lambda_public_occ (reductSI hp he)\n  exact (by decide : ¬ 1 ≤ occ 0 {expr(t[1])}) h\n'
    elif k in ('absent','mismatch'):
        want=appall(A(A(c,L(m)),rr),aa);qs=[]
        for _ in range(cfg[4]):
            q=head_path(want);qs.append(q);want=red(want,q)
        dest=expr(want);src=st.replace('(call '+nm+' ','(want ')
        out+=f'  have hq := replay_sound (t := {src}) (u := {dest}) (ps := {paths(qs)}) (by decide)\n  have hr := expected he (by decide) hp hq (by decide)\n'
        if k=='absent':out+=f'  have hz := SelfintKnot.occ_betas_zero hr {want[1]} (by decide)\n  exact (by decide : ¬ occ {want[1]} {dest} = 0) hz\n'
        else:out+=f'  have hz := Layouts.mismatch_sound 12 hr (by decide)\n  exact (by decide : ¬ Layouts.mismatch 12 {u} {dest} = false) hz\n'
    return out+'#print axioms ex_'+nm+'\n'
if __name__=='__main__':
    allw=sorted((HERE/'wires.txt').read_text().split());indices={s:i//160 for i,s in enumerate(allw)}
    rows=json.loads((HERE/'extra.json').read_text());rows.update({format(int(p.stem[1:]),'045b'):json.loads(p.read_text()) for p in HERE.glob('x[0-9]*.json')})
    grouped=defaultdict(list)
    for s,r in sorted(rows.items()):grouped[indices[s]].append((s,r))
    for i,rr in grouped.items():
        mod=f'Extra{i:03}'
        (HERE/(mod+'.lean')).write_text(f'import Batch{i:03}\nimport ExtraBase\nnamespace Blc.Floor45.{mod}\nopen Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38\nset_option maxRecDepth 30000\nset_option maxHeartbeats 6000000\n'+''.join(emit(s,r) for s,r in rr)+f'end Blc.Floor45.{mod}\n')
