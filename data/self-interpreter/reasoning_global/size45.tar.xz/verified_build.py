"""Record successful module checks and estimate elapsed replay using their measured durations."""
import heapq,json,re
from pathlib import Path
from package_partial import selected,D
from collections import defaultdict
def main():
 files,_=selected();mods={p[:-5] for p in files if p.endswith('.lean')};deps={};children=defaultdict(list)
 stage=D/'.checked'
 output=[]
 from ready_groups import state
 for m in sorted(mods):
  assert state(m)[1],m
  rec=json.loads((stage/(m+'.json')).read_text());out=(stage/(m+'.olean'))
  p=D/(m+'.lean')
  if 'source_sha256' not in rec:
   import hashlib
   rec['source_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  output.append(rec)
  needs={x for x in re.findall(r'^import ([\w.]+)',p.read_text(),re.M) if x in mods}
  deps[m]=len(needs)
  for x in needs:children[x].append(m)
 duration={r['module']:r['seconds'] for r in output}
 def replay(jobs):
  degree=deps.copy();ready=[x for x,k in degree.items() if not k];heapq.heapify(ready);active=[];now=0;count=0
  while ready or active:
   while ready and len(active)<jobs:
    m=heapq.heappop(ready);heapq.heappush(active,(now+duration[m],m))
   now,m=heapq.heappop(active);count+=1
   for v in children[m]:
    degree[v]-=1
    if degree[v]==0:heapq.heappush(ready,v)
  assert count==len(mods)
  return round(now,2)
 summary=dict(module_count=len(mods),summed_measured_module_seconds=round(sum(duration.values()),3),measured_peak_bytes=max(r['rss_bytes'] for r in output),estimated_clean_wall_seconds={j:replay(j) for j in [1,3,5,6]})
 (D/'proof-modules.txt').write_text('\n'.join(sorted(mods))+'\n')
 (D/'build-metrics.json').write_text(json.dumps(dict(summary=summary,modules=output),separators=(',',':'))+'\n')
 print(summary)
if __name__=='__main__':main()
