from genlean import *
from collections import defaultdict
def natlist(a):return '['+','.join(map(str,a))+']'
@lru_cache(40000)
def inds(t):
 if t[0]=='V':return (t[1],)
 if t[0]=='L':return tuple(i-1 for i in inds(t[1]) if i)
 return tuple(sorted(set(inds(t[1]))|set(inds(t[2]))))
def calculus(n,lo,tab):
 op=[list(map(int,tab[i:i+n])) for i in range(0,n*n,n)]
 def pick(f):return next(i for i in range(lo,n) if all(a<=b for a,b in zip(f,op[i])))
 @lru_cache(12000)
 def val(t,env):
    if t[0]=='V':return env[0]
    d=dict(zip(inds(t),env))
    if t[0]=='L':
        return pick([val(t[1],tuple(a if i==0 else d[i-1] for i in inds(t[1]))) for a in range(n)])
    def sub(u):return val(u,tuple(d[i] for i in inds(u)))
    return op[sub(t[1])][sub(t[2])]
 return op,pick,val
def modelop(n,lo,tab):
 op,_,_=calculus(n,lo,tab)
 return '\n'.join(['def op (i j : Fin '+str(n)+') : Fin '+str(n)+' := match i.val,j.val with']+[f'  | {i},{j} => {op[i][j]}' for i in range(n) for j in range(n) if op[i][j]!=n-1]+[f'  | _,_ => {n-1}',f'def G : Algebra {n-1} := ⟨op,{lo},by decide,by decide,by decide⟩'])
hdr='open Term SelfintLowerBound SelfintControl SelfintSharp ChainModel Round3Floor38\nset_option maxRecDepth 24000\nset_option maxHeartbeats 4000000\n'
def src(s,nm):
 return f'def {nm} : Term := {expr(lc.decode(s)[0])}\ntheorem wire_{nm} : Closed {nm} ∧ code {nm} = {int("1"+s,2)} := by decide\n'
def generate():
 groups=defaultdict(list);manifest={}
 late='--hard' in sys.argv
 for q in (['hardraw6.out'] if late else ['raw4.txt','raw5.txt']):
  for s,n,lo,tab,m,mode,c,r in map(str.split,open(HERE/q)):
   assert mode=='0';groups[(int(n),int(lo),tab,m,int(c),int(r))].append(s)
 for i,((n,lo,tab,m,c,r),ss) in enumerate(sorted(groups.items())):
    mod=('HardGTable' if late else 'GTable')+f'{i:03}';ns='Blc.Floor45.'+mod;op,pick,val=calculus(n,lo,tab);rho=f'(rho (n := {n-1}) {c} {r})'
    ls=['import ProbeModel','namespace '+ns,hdr,modelop(n,lo,tab)]
    bits=[L(L(V(1))),L(L(V(0)))];base=f'Typed G {rho}'
    for b,t in enumerate(bits):ls.append(f'private theorem b{b} : {base} (churchBit {str(bool(b)).lower()}) {val(t,())} := typed_eval _ _')
    ls.append(f'private theorem s0 : {base} (streamOf [] (.var 0)) {r} := .var _ _ (Nat.le_refl _)')
    suf=[];q=r
    for j,b in enumerate(reversed(m),1):
       b=int(b);suf.insert(0,str(bool(b)).lower());q=pick([op[op[a][val(bits[b],())]][q] for a in range(n)])
       ls.append(f'private theorem s{j} : {base} (streamOf {natlist(suf)} (.var 0)) {q} := pairGrade b{b} s{j-1} (by decide) (by decide)')
    mt=lc.decode(m)[0];zmax=max(z for z in range(n) if op[op[z][c]][q]<op[op[c][val(L(mt),())]][r])
    ls+=[f'theorem cut {{t : Term}} (ht : Typed G {rho} t {zmax}) : ¬ IsSelfInterpreter t := by',
         f'  intro he\n  have h := necessary G (m := {expr(mt)}) (by decide) (by decide) s{len(m)} he rfl',
         f'  have hle := G.mono _ _ (G.mono _ _ (eval_le ht) {c}) {q}',
         f'  exact (by decide : ¬ eval G {rho} (.app (.app (.var 1) (.lam {expr(mt)})) (.var 0)) ≤ op (op {zmax} {c}) {q}) (Nat.le_trans h hle)',
         'end '+ns]
    (HERE/(mod+'.lean')).write_text('\n'.join(ls)+'\n')
    for j in range(0,len(ss),32):
        gm=('HardGrade' if late else 'Grade')+f'{i:03}S{j//32:03}';gn='Blc.Floor45.'+gm
        lines=['import '+mod,'namespace '+gn,hdr]
        for s in ss[j:j+32]:
            nm='e'+str(int(s,2));z=val(lc.decode(s)[0],());assert z<=zmax
            lines+=[src(s,nm),f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := {mod}.cut (upper_sound {mod}.G {nm} {rho} {zmax} (by decide))',f'#print axioms ex_{nm}']
            manifest[s]=dict(kind='finite_chain_model',module=gm,theorem=gn+'.ex_'+nm,term=gn+'.'+nm,n=n,table=tab,floor=lo,source=m,continuation_grade=c,remainder_grade=r,program_grade=z)
        (HERE/(gm+'.lean')).write_text('\n'.join(lines+['end '+gn])+'\n')
 (HERE/('hard-model.json' if late else 'model.json')).write_text(json.dumps(manifest,separators=(',',':')))
if __name__=='__main__':generate()
