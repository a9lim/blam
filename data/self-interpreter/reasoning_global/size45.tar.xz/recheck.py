"""Resumable content-addressed replay. An unfinished slice exits 75."""
from pathlib import Path
import csv,argparse,concurrent.futures as cf,ctypes,hashlib,json,os,re,signal,struct,subprocess,time,sys
D=Path(__file__).resolve().parent
ROOT=D.parents[2]
TC=Path.home()/'.elan/toolchains'/(ROOT/'lean/lean-toolchain').read_text().strip().replace('/','--').replace(':','---')
LIB=ROOT/'lean/.lake/build/lib/lean'
def resident(pid):
    if sys.platform!='darwin':
        try:return int(Path(f'/proc/{pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
        except (FileNotFoundError,ProcessLookupError):return 0
    usage=ctypes.create_string_buffer(256)
    if proc.proc_pid_rusage(pid,0,ctypes.byref(usage)):return 0
    return struct.unpack_from('Q',usage.raw,64)[0]
proc=ctypes.CDLL('/usr/lib/libproc.dylib') if sys.platform=='darwin' else None
class Guarded(Exception):
    """A resource failure requires a retry with all other workers drained."""

def run(args):
    stage=D/args.stage;stage.mkdir(exist_ok=True)
    imports={};keys={};done=set(); work={}
    def visit(m):
        if m in keys:return
        src=D/(m+'.lean');data=src.read_bytes();deps=[];h=hashlib.sha256(data)
        for x in re.findall(rb'^import ([\w.]+)',data,re.M):
            x=x.decode()
            if (D/(x+'.lean')).exists():
                visit(x);deps.append(x);h.update(keys[x].encode())
            else:
                ref=LIB/(x.replace('.','/')+'.olean')
                try:st=ref.stat()
                except FileNotFoundError:
                    print('waiting for repository import',ref,flush=True);time.sleep(60);st=ref.stat()
                h.update(str((st.st_size,st.st_mtime_ns)).encode())
        keys[m]=h.hexdigest();imports[m]=deps
        meta=stage/(m+'.json')
        if meta.exists() and (stage/(m+'.olean')).is_file() and json.loads(meta.read_text())['hash']==keys[m]:done.add(m)
    if args.modules:mods=args.modules
    else:
        from jsonstream import ledger
        mods=sorted({r['module'] for r in ledger(D/'ledger.json')}|{'Residuals'})
    for m in sorted(set(mods)):visit(m)
    if getattr(args,'frozen_batches',False) and any(m.startswith('Batch') for m in set(keys)-done):
        raise RuntimeError('An imported Batch would require rebuilding in the selected stage')
    begin=time.monotonic();env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[stage,LIB,TC/'lib/lean'])),LEAN_NUM_THREADS='2')
    def compile(m,retry_import=True):
        log=stage/(m+'.log');out=stage/(m+'.olean');start=time.monotonic()
        guard=None
        with log.open('w') as handle:
            p=subprocess.Popen([str(TC/'bin/lean'),'-j2','-M','900','--root='+str(D),str(D/(m+'.lean')),'-o',str(out)],cwd=stage,env=env,stdout=handle,stderr=handle)
            stop=min(start+150,begin+args.seconds+155)
            while True:
                pid,st,u=os.wait4(p.pid,os.WNOHANG)
                if pid:break
                rss=resident(p.pid)
                if rss>=985_000_000 or time.monotonic()>=stop:
                    guard=f'{rss} bytes RSS' if rss>=985_000_000 else 'worker timeout'
                    p.kill()
                time.sleep(.025)
            p.returncode=os.waitstatus_to_exitcode(st)
        msg=log.read_text()
        peak=u.ru_maxrss if sys.platform=='darwin' else u.ru_maxrss*1024
        if guard or p.returncode==-signal.SIGKILL or peak>=985_000_000 or 'excessive memory consumption' in msg:
            raise Guarded(f'{m}: {guard or msg[-160:] or p.returncode}; peak {peak}')
        if p.returncode and retry_import and ('does not exist' in msg or 'invalid object file' in msg) and ('object file' in msg or '.olean' in msg):
            print('retrying missing import after 60 seconds',m,flush=True);time.sleep(60);return compile(m,False)
        if p.returncode or 'declaration uses `sorry`' in msg:raise RuntimeError(m+'\n'+msg[-2000:])
        ax=re.findall(r"depends on axioms: \[([^\]]*)\]",msg)
        assert all(set(x.split(', '))<={'propext','Classical.choice','Quot.sound'} for x in ax)
        row=dict(hash=keys[m],source_sha256=hashlib.sha256((D/(m+'.lean')).read_bytes()).hexdigest(),module=m,seconds=round(time.monotonic()-start,3),rss_bytes=peak)
        mf=stage/(m+'.json');tmp=mf.with_suffix('.tmp');tmp.write_text(json.dumps(row));tmp.replace(mf)
        return m
    # A pending marker survives a slice boundary. Only a failed isolated
    # retry counts as a guard failure. No other compiler runs during it.
    pending=set(keys)-done;failed={};solo=None
    retry={m for m in pending if (stage/(m+'.retry')).is_file()}
    with cf.ThreadPoolExecutor(args.jobs) as pool:
        while pending or work:
            if time.monotonic()-begin<args.seconds and solo is None:
                if retry and not work:
                    ready=sorted(m for m in retry if all(y in done for y in imports[m]))
                    if ready:
                        solo=ready[0];retry.remove(solo);pending.remove(solo)
                        work[pool.submit(compile,solo)]=solo
                        print('retry alone',solo,flush=True)
                if solo is None and not (retry and work):
                    ready=sorted((x for x in pending-retry if all(y in done for y in imports[x])),
                                 key=lambda m:((stage/(m+'.olean')).exists(),m))
                    for m in ready[:args.jobs-len(work)]:
                        pending.remove(m);work[pool.submit(compile,m)]=m
            if not work:break
            fs,_=cf.wait(work,return_when=cf.FIRST_COMPLETED)
            for f in fs:
                m=work.pop(f);marker=stage/(m+'.retry')
                try:
                    done.add(f.result());marker.unlink(missing_ok=True)
                except Guarded as ex:
                    if m==solo:
                        failed[m]=str(ex);print('isolated guard failure',ex,flush=True)
                    else:
                        print('queued isolated retry',ex,flush=True)
                        marker.write_text(str(ex));retry.add(m);pending.add(m)
                except (RuntimeError,AssertionError) as ex:
                    failed[m]=str(ex);print('failed',m,str(ex)[-350:],flush=True)
                if m==solo:solo=None
            if len(done)%200==0:print(len(done),'of',len(keys),flush=True)
    print(len(done),'of',len(keys),'modules verified; slice',round(time.monotonic()-begin,2),'seconds',flush=True)
    if failed:
        (stage/'slice-failures.json').write_text(json.dumps(failed,indent=1))
        print(len(failed),'failed modules',flush=True);return 1
    if pending:return 75
    if not args.modules:
        from jsonstream import ledger
        audit={};counts={};missing=0
        for row in ledger(D/'ledger.json'):
            if row.get('status')=='pending' or row['strength']=='open':missing+=1;continue
            if row['strength']!='complete':continue
            m=row['module']
            if m not in audit:
                audit[m]=dict(re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",(stage/(m+'.log')).read_text()))
            ax=audit[m][row['theorem']];counts[ax]=counts.get(ax,0)+1
        assert 'Blc.Floor45.residuals_excluded' in (stage/'Residuals.log').read_text()
        for i in range(3):
            assert f'Blc.Floor45.AttachPart{i}.partition_checked' in (stage/f'AttachPart{i}.log').read_text()
        with (D/'complete.tsv').open() as f:
            ts=list(csv.DictReader(f,delimiter='\t'))
        assert len(ts)==23497 and missing==0 and sum(counts.values())==len(ts)
        for r in ts:
            assert r['kernel_status']=='checked' and audit[Path(r['file']).stem][r['theorem']]==r['axioms']
        timings=[json.loads((stage/(m+'.json')).read_text()) for m in done]
        summary=dict(modules=len(done),summed_seconds=sum(x['seconds'] for x in timings),
            peak_rss_bytes=max(x['rss_bytes'] for x in timings),axiom_counts=counts,open=missing)
        (stage/'summary.json').write_text(json.dumps(summary,indent=1)+'\n');print(summary)
        if missing:print(f'{missing} wire(s) explicitly open in this archive.')
    return 0
if __name__=='__main__':
    p=argparse.ArgumentParser(__doc__);p.add_argument('--jobs',type=int,choices=range(1,5),default=4)
    p.add_argument('--seconds',type=int,choices=range(1,401))
    p.add_argument('--frozen-batches',action='store_true',help='require all imported Batch modules to be current in this stage')
    p.add_argument('--stage',default='.checked');p.add_argument('modules',nargs='*')
    args=p.parse_args();bounded=args.seconds is not None
    args.seconds=args.seconds or 390
    while True:
        result=run(args)
        if result!=75 or bounded:sys.exit(result)
