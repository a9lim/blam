from probes import *
from searchprobes import target_steps
from harder import remain
import subprocess
def inputs(e):
 yield e,None
 for c in [om[1],I,KI,K,A(om[1],I),L(A(V(0),om))]:
    k=target_steps(c,I,R,[])
    if k is not None:yield A(e,c),('prefix',c,I,R,[],k)
 for m in [I,KI,K]:
    for narg in [0,1,2,3,4,6,8]:
      for c,r,aa in [(KI,R,[om]*narg),(K,om,[om]*narg+[I]),(L(L(I)),om,[om]*narg),(L(L(A(V(1),om))),R,[om]*narg),(C,R,[om]*narg)]:
        k=target_steps(c,m,r,aa)
        if k is None:continue
        yield appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa),('full',c,m,r,aa,k)
def targets(e):
 seen=set()
 for j,(q,_) in enumerate(inputs(e)):
    for style in [0,1,2]:
      t=q
      for k in range(40):
        if t not in seen and wire(t)<280:
            seen.add(t);yield f'{j}:{style}:{k}',t
        p=variant(t,style)
        if p is None:break
        t=bounded(t,p)
        if t is None or wire(t)>380:break
def getclock(s,ident):
 i,style,k=map(int,ident.split(':'));q,probe=list(inputs(lc.decode(s)[0]))[i];t=q;ps=[]
 for _ in range(k):
    p=variant(t,style);ps.append(p);t=red(t,p)
 return probe,t,ps
if __name__=='__main__':
 ss=remain();d=HERE/'clock';d.mkdir(exist_ok=True)
 tab=HERE/'clocktabs.in';spec=set()
 for line in (HERE/'tables.in').read_text().splitlines():
    n,_,t=line.split()
    for lo in range(1,int(n)-1):spec.add((int(n),lo,t))
 tab.write_text(''.join(f'{n} {lo} {t}\n' for n,lo,t in sorted(spec)))
 for s in ss:
    dst=d/(s+'.out')
    if dst.exists():continue
    e=lc.decode(s)[0];inp=d/(s+'.in')
    with inp.open('w') as f:
       for ident,t in targets(e):f.write(f'{s} {ident} {lc.enc(t)} 10\n')
    tmp=dst.with_suffix('.tmp')
    with tmp.open('w') as f:subprocess.run([str(HERE/'clocksearch'),str(inp),str(tab),'4'],check=True,stdout=f,timeout=100)
    tmp.replace(dst)
