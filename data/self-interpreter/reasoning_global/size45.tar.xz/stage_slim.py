"""Stage exactly the retained pack.py inputs for a regeneration-only check."""
from package_partial import D,selected
import json,shutil,sys
def main():
 target=D/sys.argv[1];target.mkdir(exist_ok=False)
 omit=json.loads((D/'slim.json').read_text())['files']
 for n in selected()[0]:
  if n not in omit:shutil.copyfile(D/n,target/n)
 print(len(list(target.iterdir())),'retained inputs')
if __name__=='__main__':main()
