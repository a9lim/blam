"""Read each archived member back and compare its streamed digest with the selected source."""
import hashlib,tarfile
from package_partial import D,selected
if __name__=='__main__':
 name=D/'size45-partial.tar.xz';names,n=selected();seen=[]
 with tarfile.open(name,'r|xz') as tf:
  for member in tf:
   assert member.isfile()
   with tf.extractfile(member) as f,(D/member.name).open('rb') as g:
    assert hashlib.file_digest(f,'sha256').digest()==hashlib.file_digest(g,'sha256').digest(),member.name
   seen.append(member.name)
 assert seen==names
 print('Verified',len(seen),'member names and byte digests, including',n,'Lean modules.')
