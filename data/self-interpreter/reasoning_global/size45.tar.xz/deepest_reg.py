from hard import *
from harder import remain
for s in remain():
    if not (HERE/('h'+str(int(s,2))+'.json')).exists():
       one(s,7)
