"""Copy two generic typed certificates and specialize them to exact size-45 literals."""
from genlean import *
import shutil,re
def main():
 prior=HERE.parent/'floor44'
 bank=prior/'help44'
 hits=json.loads((HERE/'reuse-table-hits.json').read_text());out={}
 def copy(name):
  p=bank/(name+'.lean')
  for dep in re.findall(r'^import (\w+)$',p.read_text(),re.M):
   if (bank/(dep+'.lean')).exists():copy(dep)
  shutil.copyfile(p,HERE/p.name)
 for s,options in hits.items():
  filename,i=options[0];conf=json.loads((prior/filename).read_text())[i][0]
  lib='Lib'+str(i if filename=='shared.json' else 100+i);copy('H44'+lib)
  num=str(int(s,2));nm='e'+num;mod='Bottom'+num;ns='Blc.Floor45.'+mod
  lines=['import H44'+lib,'import Floor45','namespace '+ns,'open Term SelfintLowerBound SelfintControl Round3Floor38','set_option maxRecDepth 20000','set_option maxHeartbeats 3000000',f'def {nm} : Term := '+expr(lc.decode(s)[0]),f'theorem wire_{nm} : Closed {nm} ∧ code {nm} = {int("1"+s,2)} := by decide',f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := Blc.H44.{lib}.excluded (by decide : Blc.H44.Types.has Blc.H44.{lib}.tab Blc.H44.{lib}.env {nm} {conf[-2]} = true)',f'#print axioms ex_{nm}','end '+ns]
  (HERE/(mod+'.lean')).write_text('\n'.join(lines)+'\n');out[s]=dict(kind='bottom_type_table',module=mod,theorem=ns+'.ex_'+nm,term=ns+'.'+nm,table=lib,token=conf[-2])
 (HERE/'bottom-manifest.json').write_text(json.dumps(out,indent=1))
if __name__=='__main__':main()
