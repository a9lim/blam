import json,collections
from pathlib import Path
d=Path(__file__).resolve().parent
paths=sorted((d/'shards').glob('*.json'));assert len(paths)==2670
c=collections.Counter();opened=[];count=0
with (d/'certs.json').open('w') as f:
 f.write('{')
 for p in paths:
    t=p.read_text();rows=json.loads(t)
    for s,r in rows.items():c[r[0]]+=1;opened.extend([s] if r[0]=='open' else [])
    if count:f.write(',')
    f.write(t[1:-1]);count+=len(rows)
 f.write('}')
assert count==427114
(d/'open.txt').write_text(''.join(s+'\n' for s in opened));print(c)
