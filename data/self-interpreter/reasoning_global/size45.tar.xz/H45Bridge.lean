import H45Rows00
import H45Rows01
import Batch1039
import Batch1114
import Batch1589
import Batch2500
import Batch2501
import Batch2584
import Batch2603
import Batch2664
namespace Blc.Floor45.Help45
theorem same_e9570311402454 : Blc.H45.e9570311402454 = Blc.Floor45.e9570311402454 := rfl
#print axioms same_e9570311402454
theorem ex_e9570311402454 : ¬ IsSelfInterpreter Blc.Floor45.e9570311402454 := Blc.H45.ex_e9570311402454
#print axioms ex_e9570311402454
theorem same_e9573528477238 : Blc.H45.e9573528477238 = Blc.Floor45.e9573528477238 := rfl
#print axioms same_e9573528477238
theorem ex_e9573528477238 : ¬ IsSelfInterpreter Blc.Floor45.e9573528477238 := Blc.H45.ex_e9573528477238
#print axioms ex_e9573528477238
theorem same_e9676763418166 : Blc.H45.e9676763418166 = Blc.Floor45.e9676763418166 := rfl
#print axioms same_e9676763418166
theorem ex_e9676763418166 : ¬ IsSelfInterpreter Blc.Floor45.e9676763418166 := Blc.H45.ex_e9676763418166
#print axioms ex_e9676763418166
theorem same_e9692402711770 : Blc.H45.e9692402711770 = Blc.Floor45.e9692402711770 := rfl
#print axioms same_e9692402711770
theorem ex_e9692402711770 : ¬ IsSelfInterpreter Blc.Floor45.e9692402711770 := Blc.H45.ex_e9692402711770
#print axioms ex_e9692402711770
theorem same_e9692402957530 : Blc.H45.e9692402957530 = Blc.Floor45.e9692402957530 := rfl
#print axioms same_e9692402957530
theorem ex_e9692402957530 : ¬ IsSelfInterpreter Blc.Floor45.e9692402957530 := Blc.H45.ex_e9692402957530
#print axioms ex_e9692402957530
theorem same_e9692402989098 : Blc.H45.e9692402989098 = Blc.Floor45.e9692402989098 := rfl
#print axioms same_e9692402989098
theorem ex_e9692402989098 : ¬ IsSelfInterpreter Blc.Floor45.e9692402989098 := Blc.H45.ex_e9692402989098
#print axioms ex_e9692402989098
theorem same_e9692402989698 : Blc.H45.e9692402989698 = Blc.Floor45.e9692402989698 := rfl
#print axioms same_e9692402989698
theorem ex_e9692402989698 : ¬ IsSelfInterpreter Blc.Floor45.e9692402989698 := Blc.H45.ex_e9692402989698
#print axioms ex_e9692402989698
theorem same_e9692715709398 : Blc.H45.e9692715709398 = Blc.Floor45.e9692715709398 := rfl
#print axioms same_e9692715709398
theorem ex_e9692715709398 : ¬ IsSelfInterpreter Blc.Floor45.e9692715709398 := Blc.H45.ex_e9692715709398
#print axioms ex_e9692715709398
theorem same_e9692869766666 : Blc.H45.e9692869766666 = Blc.Floor45.e9692869766666 := rfl
#print axioms same_e9692869766666
theorem ex_e9692869766666 : ¬ IsSelfInterpreter Blc.Floor45.e9692869766666 := Blc.H45.ex_e9692869766666
#print axioms ex_e9692869766666
theorem same_e11219262979426 : Blc.H45.e11219262979426 = Blc.Floor45.e11219262979426 := rfl
#print axioms same_e11219262979426
theorem ex_e11219262979426 : ¬ IsSelfInterpreter Blc.Floor45.e11219262979426 := Blc.H45.ex_e11219262979426
#print axioms ex_e11219262979426
end Blc.Floor45.Help45
