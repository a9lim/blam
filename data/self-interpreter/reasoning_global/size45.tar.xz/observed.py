from machine_diag import *
from grade_rows import src,natlist
from searchprobes import configs
from itertools import islice
from random import Random
def tag(t):return '.lambda' if t[0]=='l' else f'(.rigid {t[0]} {t[1]})'
def material(s,c,m,r,aa,a,b,i,j):
 nm='e'+str(int(s,2));mod='Seen'+nm[1:];ns='Blc.Floor45.'+mod
 os_=['import Observe','namespace '+ns,'open Term SelfintLowerBound SelfintControl Round3Floor38','set_option maxRecDepth 16000','set_option maxHeartbeats 5000000',
    src(s,nm),f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := Observe.excluded (c := {expr(c)}) (m := {expr(m)}) (r := {expr(r)}) (aa := {natlist(map(expr,aa))}) (i := {i+1}) (j := {j+1}) (a := {tag(a)}) (b := {tag(b)}) (by decide) (by decide) (by decide) (by decide)',
    '#print axioms ex_'+nm,'end '+ns]
 (HERE/(mod+'.lean')).write_text('\n'.join(os_)+'\n')
 return dict(kind='weak_head_observation',module=mod,theorem=ns+'.ex_'+nm,term=ns+'.'+nm,probe=[lc.enc(c),lc.enc(m),lc.enc(r),list(map(lc.enc,aa))],actual=[i+1,a],expected=[j+1,b])
def probeone(s,ss):
 e=lc.decode(s)[0]
 for c,m,r,aa in ss:
    u=appall(A(A(c,L(m)),r),aa);b,j=observe(u,230)
    if b is None:continue
    q=appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa);a,i=observe(q,3500)
    if a is not None and a!=b:return material(s,c,m,r,aa,a,b,i,j)
def main():
 d=HERE/'seen';d.mkdir(exist_ok=True)
 obs=json.loads((HERE/'hard-observations.json').read_text())
 opts=list(symbols());extra=list(configs());Random(450).shuffle(extra)
 for s in remain():
    hits=obs.get(s,{}).get('mismatches',[])
    if hits:tests=[opts[min(hits,key=lambda x:x[1])[0]]]
    elif obs.get(s,{}).get('raw',[None])[0] is None:continue
    else:tests=[(c,m,r,aa) for c,m,r,aa,_ in extra[:700]]
    r=probeone(s,tests)
    if r:(d/(s+'.json')).write_text(json.dumps(r))
if __name__=='__main__':main()
