import H45Literals
import H45F9573528477238
import H45F9676763418166
import H45F9692402711770
import H45F9692402957530
import H45F9692402989098
import H45TraceFinal
namespace Blc.H45
theorem ex_e9570311402454 : ¬ IsSelfInterpreter e9570311402454 := Trace.ex_e9570311402454
#print axioms ex_e9570311402454
theorem ex_e9573528477238 : ¬ IsSelfInterpreter e9573528477238 := H45F9573528477238.excluded
#print axioms ex_e9573528477238
theorem ex_e9676763418166 : ¬ IsSelfInterpreter e9676763418166 := H45F9676763418166.excluded
#print axioms ex_e9676763418166
theorem ex_e9692402711770 : ¬ IsSelfInterpreter e9692402711770 := H45F9692402711770.excluded
#print axioms ex_e9692402711770
theorem ex_e9692402957530 : ¬ IsSelfInterpreter e9692402957530 := H45F9692402957530.excluded
#print axioms ex_e9692402957530
theorem ex_e9692402989098 : ¬ IsSelfInterpreter e9692402989098 := H45F9692402989098.excluded
#print axioms ex_e9692402989098
end Blc.H45
