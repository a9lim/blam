from candidates import *
def expr(t):
    if t[0]=='V':return f'(.var {t[1]})'
    if t[0]=='L':return f'(.lam {expr(t[1])})'
    return f'(.app {expr(t[1])} {expr(t[2])})'
def paths(ps):
    return '['+','.join('['+','.join('.'+s for s in p)+']' for p in ps)+']'
def main():
    rows=json.loads((HERE/'certs.json').read_text())
    for i,(s,r) in enumerate(rows.items()):
        shard=i//160
        if i%160==0:
            out=open(HERE/f'Batch{shard:03}.lean','w');out.write('import Floor45\nnamespace Blc.Floor45\nopen Term SelfintSharp SelfintLowerBound Round3Floor38\nset_option maxRecDepth 20000\n')
        e=lc.decode(s)[0];k=r[0]
        name='e'+str(int(s,2))
        out.write(f'def {name} : Term := {expr(e)}\n')
        out.write(f'theorem wire_{name} : Closed {name} ∧ code {name} = {int("1"+s,2)} := by decide\n')
        if k=='open':pass
        elif k=='payload':
            out.write(f'theorem cert_{name} : checkPay {name} {paths(r[1])} {r[2]} {paths(r[3])} = true := by decide\n')
        elif k.startswith('W'):
            t=e if k=='Wsource' else A(A(e,V(1)),lc.bitlist('0010',V(0)))
            for p in r[1]:t=red(t,p)
            start=name if k=='Wsource' else '(inv '+name+')'
            out.write(f'private def t_{name} : Term := {expr(t)}\ntheorem cert_{name} : ¬ IsSelfInterpreter {name} :=\n')
            out.write(f'  w{k[1:].title()} (t := t_{name}) (replay_sound (ps := {paths(r[1])}) (t := {start}) (by decide)) (by decide)\n')
        else:
            out.write(f'theorem cert_{name} : check {name} {paths(r[1])} .{k} = true := by decide\n')
        if i%160==159 or i==len(rows)-1:
            out.write('end Blc.Floor45\n');out.close()
if __name__=='__main__':main()
