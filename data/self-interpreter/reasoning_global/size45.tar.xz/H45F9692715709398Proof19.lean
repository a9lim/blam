import H45F9692715709398Proof18
namespace Blc.H45.H45F9692715709398
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h684 (ρ : Env) (a0 : Fits s62 (ρ 0)) : All tab ρ b6 s63 :=
  (consAll (lamAt d90 c90 (smaller (h565 (Types.cons s16 ρ) sub10 a0) sub199)) Positive.none)
theorem h685 (ρ : Env) (a0 : Fits s54 (ρ 0)) : All tab ρ b6 s147 :=
  (consAll (lamAt d33 c33 (smaller (h566 (Types.cons s16 ρ) sub10 a0) sub10)) (consAll (lamAt d131 c131 (smaller (h591 (Types.cons s87 ρ) sub68 a0) sub68)) Positive.none))
theorem h686 (ρ : Env) (a0 : Fits s59 (ρ 0)) : All tab ρ b6 s16 :=
  (consAll (lamAt d24 c24 (smaller (h567 (Types.cons s17 ρ) sub17 a0) sub4)) Positive.none)
theorem h687 (ρ : Env) (a0 : Fits s46 (ρ 0)) : All tab ρ b6 s48 :=
  (consAll (lamAt d9 c9 (smaller (h572 (Types.cons s6 ρ) sub4 a0) sub4)) (consAll (lamAt d24 c24 (smaller (h560 (Types.cons s17 ρ) sub17 a0) sub4)) Positive.none))
theorem h688 (ρ : Env) (a0 : Fits s30 (ρ 0)) : All tab ρ b6 s71 :=
  (consAll (lamAt d6 c6 (smaller (h569 (Types.cons s3 ρ) sub15 a0) sub15)) Positive.none)
theorem h689 (ρ : Env) (a0 : Fits s30 (ρ 0)) : All tab ρ b6 s16 :=
  (consAll (lamAt d24 c24 (smaller (h570 (Types.cons s17 ρ) sub17 a0) sub4)) Positive.none)
theorem h690 (ρ : Env) (a0 : Fits s54 (ρ 0)) : All tab ρ b6 s149 :=
  (consAll (lamAt d98 c98 (smaller (h571 (Types.cons s20 ρ) sub18 a0) sub187)) (consAll (lamAt d133 c133 (smaller (h593 (Types.cons s20 ρ) sub18 a0) sub192)) Positive.none))
theorem h691 (ρ : Env) (a0 : Fits s67 (ρ 0)) : All tab ρ b6 s151 :=
  (consAll (lamAt d104 c104 (smaller (h573 (Types.cons s69 ρ) sub71 a0) sub71)) Positive.none)
theorem h692 (ρ : Env) (a0 : Fits s67 (ρ 0)) : All tab ρ b6 s174 :=
  (consAll (lamAt d106 c106 (smaller (h574 (Types.cons s71 ρ) sub74 a0) sub251)) Positive.none)
theorem h693 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b6 s71 :=
  (consAll (lamAt d6 c6 (smaller (h575 (Types.cons s3 ρ) sub15 a0) sub15)) Positive.none)
theorem h694 (ρ : Env) (a0 : Fits s66 (ρ 0)) : All tab ρ b6 s152 :=
  (consAll (lamAt d110 c110 (smaller (h576 (Types.cons s74 ρ) sub139 a0) sub252)) Positive.none)
theorem h695 (ρ : Env) (a0 : Fits s66 (ρ 0)) : All tab ρ b6 s175 :=
  (consAll (lamAt d113 c113 (smaller (h577 (Types.cons s76 ρ) sub141 a0) sub141)) Positive.none)
theorem h696 (ρ : Env) (a0 : Fits s67 (ρ 0)) : All tab ρ b6 s76 :=
  (consAll (lamAt d112 c112 (smaller (h578 (Types.cons s75 ρ) sub55 a0) sub189)) Positive.none)
theorem h697 (ρ : Env) (a0 : Fits s65 (ρ 0)) : All tab ρ b6 s153 :=
  (consAll (lamAt d114 c114 (smaller (h579 (Types.cons s75 ρ) sub55 a0) sub55)) Positive.none)
theorem h698 (ρ : Env) (a0 : Fits s66 (ρ 0)) : All tab ρ b6 s75 :=
  (consAll (lamAt d6 c6 (smaller (h580 (Types.cons s3 ρ) sub15 a0) sub15)) (consAll (lamAt d141 c141 (smaller (h602 (Types.cons s82 ρ) sub75 a0) sub75)) Positive.none))
theorem h699 (ρ : Env) (a0 : Fits s58 (ρ 0)) : All tab ρ b6 s75 :=
  (consAll (lamAt d6 c6 (smaller (h581 (Types.cons s3 ρ) sub15 a0) sub15)) (consAll (lamAt d141 c141 (smaller (h603 (Types.cons s82 ρ) sub75 a0) sub75)) Positive.none))
theorem h700 (ρ : Env) (a0 : Fits s65 (ρ 0)) : All tab ρ b6 s154 :=
  (consAll (lamAt d115 c115 (smaller (h582 (Types.cons s77 ρ) sub143 a0) sub189)) Positive.none)
theorem h701 (ρ : Env) (a0 : Fits s58 (ρ 0)) : All tab ρ b6 s155 :=
  (consAll (lamAt d117 c117 (smaller (h583 (Types.cons s71 ρ) sub74 a0) sub74)) (consAll (lamAt d120 c120 (smaller (h585 (Types.cons s80 ρ) sub147 a0) sub202)) (consAll (lamAt d147 c147 (smaller (h606 (Types.cons s95 ρ) sub78 a0) sub78)) (consAll (lamAt d148 c148 (smaller (h607 (Types.cons s96 ρ) sub157 a0) sub94)) (consAll (lamAt d154 c154 (smaller (h611 (Types.cons s98 ρ) sub161 a0) sub206)) (consAll (lamAt d156 c156 (smaller (h612 (Types.cons s100 ρ) sub163 a0) sub161)) (consAll (lamAt d170 c170 (smaller (h625 (Types.cons s95 ρ) sub78 a0) sub94)) (consAll (lamAt d171 c171 (smaller (h626 (Types.cons s106 ρ) sub168 a0) sub95)) (consAll (lamAt d173 c173 (smaller (h628 (Types.cons s98 ρ) sub161 a0) sub161)) (consAll (lamAt d175 c175 (smaller (h630 (Types.cons s107 ρ) sub95 a0) sub95)) Positive.none))))))))))
theorem h702 (ρ : Env) (a0 : Fits s67 (ρ 0)) : All tab ρ b6 s157 :=
  (consAll (lamAt d6 c6 (smaller (h584 (Types.cons s3 ρ) sub15 a0) sub15)) (consAll (lamAt d168 c168 (smaller (h623 (Types.cons s17 ρ) sub17 a0) sub15)) Positive.none))
theorem h703 (ρ : Env) (a0 : Fits s56 (ρ 0)) : All tab ρ b6 s158 :=
  (consAll (lamAt d6 c6 (smaller (h561 (Types.cons s3 ρ) sub15 a0) sub15)) (consAll (lamAt d151 c151 (smaller (h610 (Types.cons s94 ρ) sub84 a0) sub84)) Positive.none))
theorem h704 (ρ : Env) (a0 : Fits s67 (ρ 0)) : All tab ρ b6 s80 :=
  (consAll (lamAt d121 c121 (smaller (h586 (Types.cons s81 ρ) sub149 a0) sub213)) Positive.none)
theorem h705 (ρ : Env) (a0 : Fits s56 (ρ 0)) : All tab ρ b6 s159 :=
  (consAll (lamAt d123 c123 (smaller (h587 (Types.cons s5 ρ) sub2 a0) sub149)) (consAll (lamAt d161 c161 (smaller (h615 (Types.cons s97 ρ) sub88 a0) sub87)) Positive.none))
theorem h706 (ρ : Env) (a0 : Fits s83 (ρ 0)) : All tab ρ b6 s160 :=
  (consAll (lamAt d127 c127 (smaller (h588 (Types.cons s85 ρ) sub151 a0) sub253)) Positive.none)
theorem h707 (ρ : Env) (a0 : Fits s83 (ρ 0)) : All tab ρ b6 s176 :=
  (consAll (lamAt d130 c130 (smaller (h589 (Types.cons s88 ρ) sub153 a0) sub153)) Positive.none)
theorem h708 (ρ : Env) (a0 : Fits s86 (ρ 0)) : All tab ρ b6 s88 :=
  (consAll (lamAt d129 c129 (smaller (h590 (Types.cons s87 ρ) sub68 a0) sub203)) Positive.none)
theorem h709 (ρ : Env) (a0 : Fits s83 (ρ 0)) : All tab ρ b6 s87 :=
  (consAll (lamAt d24 c24 (smaller (h592 (Types.cons s17 ρ) sub17 a0) sub4)) (consAll (lamAt d163 c163 (smaller (h617 (Types.cons s17 ρ) sub17 a0) sub165)) Positive.none))
theorem h710 (ρ : Env) (a0 : Fits s90 (ρ 0)) : All tab ρ b6 s152 :=
  (consAll (lamAt d110 c110 (smaller (h594 (Types.cons s74 ρ) sub139 a0) sub252)) Positive.none)
theorem h711 (ρ : Env) (a0 : Fits s90 (ρ 0)) : All tab ρ b6 s175 :=
  (consAll (lamAt d113 c113 (smaller (h595 (Types.cons s76 ρ) sub141 a0) sub141)) Positive.none)
theorem h712 (ρ : Env) (a0 : Fits s90 (ρ 0)) : All tab ρ b6 s75 :=
  (consAll (lamAt d6 c6 (smaller (h596 (Types.cons s3 ρ) sub15 a0) sub15)) (consAll (lamAt d141 c141 (smaller (h601 (Types.cons s82 ρ) sub75 a0) sub75)) Positive.none))
theorem h713 (ρ : Env) (a0 : Fits s89 (ρ 0)) : All tab ρ b6 s161 :=
  (consAll (lamAt d137 c137 (smaller (h597 (Types.cons s91 ρ) sub155 a0) sub189)) Positive.none)
theorem h714 (ρ : Env) (a0 : Fits s89 (ρ 0)) : All tab ρ b6 s153 :=
  (consAll (lamAt d114 c114 (smaller (h598 (Types.cons s75 ρ) sub55 a0) sub55)) Positive.none)
theorem h715 (ρ : Env) (a0 : Fits s82 (ρ 0)) : All tab ρ b6 s162 :=
  (consAll (lamAt d139 c139 (smaller (h599 (Types.cons s71 ρ) sub74 a0) sub71)) (consAll (lamAt d146 c146 (smaller (h605 (Types.cons s95 ρ) sub78 a0) sub76)) Positive.none))
theorem h716 (ρ : Env) (a0 : Fits s82 (ρ 0)) : All tab ρ b6 s75 :=
  (consAll (lamAt d6 c6 (smaller (h600 (Types.cons s3 ρ) sub15 a0) sub15)) (consAll (lamAt d141 c141 (smaller (h604 (Types.cons s82 ρ) sub75 a0) sub75)) Positive.none))
theorem h717 (ρ : Env) (a0 : Fits s67 (ρ 0)) : All tab ρ b6 s106 :=
  (consAll (lamAt d141 c141 (smaller (h608 (Types.cons s82 ρ) sub75 a0) sub75)) (consAll (lamAt d157 c157 (smaller (h613 (Types.cons s101 ρ) sub164 a0) sub214)) Positive.none))
theorem h718 (ρ : Env) (a0 : Fits s56 (ρ 0)) : All tab ρ b6 s163 :=
  (consAll (lamAt d145 c145 (smaller (h609 (Types.cons s94 ρ) sub84 a0) sub75)) (consAll (lamAt d151 c151 (smaller (h610 (Types.cons s94 ρ) sub84 a0) sub84)) (consAll (lamAt d159 c159 (smaller (h614 (Types.cons s99 ρ) sub87 a0) sub164)) (consAll (lamAt d169 c169 (smaller (h624 (Types.cons s17 ρ) sub17 a0) sub75)) (consAll (lamAt d172 c172 (smaller (h627 (Types.cons s17 ρ) sub17 a0) sub84)) (consAll (lamAt d174 c174 (smaller (h629 (Types.cons s99 ρ) sub87 a0) sub87)) Positive.none))))))
theorem h719 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b6 s97 :=
  (consAll (lamAt d162 c162 (smaller (h616 (Types.cons s102 ρ) sub165 a0) sub165)) Positive.none)
end Blc.H45.H45F9692715709398
