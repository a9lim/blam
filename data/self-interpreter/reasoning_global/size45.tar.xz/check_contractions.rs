use std::{collections::HashSet,env,fs,io::{self,BufRead}};
#[derive(Clone)] enum T { V(usize), L(Box<T>), A(Box<T>,Box<T>) }
use T::*;
fn parse(bs:&[u8],i:&mut usize)->T {
    let k=bs[*i];*i+=1;
    if k==b'1' {let mut j=0;while bs[*i]==b'1' {j+=1;*i+=1;}*i+=1;return V(j)}
    let k=bs[*i];*i+=1;let x=Box::new(parse(bs,i));
    if k==b'0' {L(x)} else {A(x,Box::new(parse(bs,i)))}
}
fn size(t:&T)->usize {match t {V(i)=>2+i,L(b)=>2+size(b),A(f,x)=>2+size(f)+size(x)}}
fn lift(t:&T,d:usize,by:usize)->T {match t {V(i)=>V(if *i>=d {i+by}else{*i}),L(b)=>L(Box::new(lift(b,d+1,by))),A(f,x)=>A(Box::new(lift(f,d,by)),Box::new(lift(x,d,by)))}}
fn subst(t:&T,d:usize,x:&T)->T {match t {V(i) if *i==d=>lift(x,0,d),V(i)=>V(if *i>d {i-1}else{*i}),L(b)=>L(Box::new(subst(b,d+1,x))),A(f,a)=>A(Box::new(subst(f,d,x)),Box::new(subst(a,d,x)))}}
fn shrink(t:&T)->bool {match t {V(_)=>false,L(b)=>shrink(b),A(f,x)=>matches!(&**f,L(b) if size(&subst(b,0,x))<size(t))||shrink(f)||shrink(x)}}
fn main(){
 let path=env::args().nth(1).unwrap();let owned=fs::read_to_string(path).unwrap();let mut wants:HashSet<&str>=owned.lines().collect();assert_eq!(wants.len(),427114);
 let mut n=0;let mut k=0;for row in io::stdin().lock().lines(){let row=row.unwrap();let mut i=0;let t=parse(row.as_bytes(),&mut i);assert_eq!((i,size(&t)),(45,45));n+=1;if !shrink(&t){assert!(wants.remove(&row[..]),"unexpected or duplicate {}",row);k+=1;}}
 assert!(wants.is_empty());println!("{} structural wires, {} retained, exact set equality",n,k);
}
