from fast_extras import *
from genlean import expr,paths
from smart_probe import appall
C,R=V(1),V(0)
def symbols():
 for m in (I,KI,K):
    for c,r,aa in [(C,R,[]),(KI,R,[]),(K,R,[]),(K,om,[I]),(L(L(I)),om,[]),(L(L(A(V(1),I))),om,[]),(L(L(A(V(0),I))),I,[]),(KI,L(R),[om]),(KI,L(L(R)),[om,om]),(L(L(A(V(1),V(0)))),I,[]),(K,R,[om])]:
        yield c,m,r,aa
def options(e):
  seen=set()
  for pi,(c,m,r,aa) in enumerate(symbols()):
    want=appall(A(A(c,L(m)),r),aa);qs=[]
    for _ in range(16):
        p=normal_path(want)
        if p is None:break
        want=bounded(want,p)
        if want is None:break
        qs.append(p)
    if want is None or normal_path(want) is not None:continue
    call=appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)
    for style in (1,0,2):
      t=call;ps=[]
      for j in range(26):
        if (t,want) not in seen and wire(t)<260:
            seen.add((t,want));yield f'{pi}:{style}:{j}',t,want
        p=variant(t,style)
        if p is None:break
        t=bounded(t,p)
        if t is None or wire(t)>330:break
        ps.append(p)
def get(s,ident):
    pi,style,j=map(int,ident.split(':'))
    c,m,r,aa=list(symbols())[pi];t=appall(A(A(lc.decode(s)[0],c),lc.bitlist(lc.enc(m),r)),aa);ps=[]
    for _ in range(j):
        p=variant(t,style);ps.append(p);t=red(t,p)
    want=appall(A(A(c,L(m)),r),aa);qs=[]
    for _ in range(16):
        p=normal_path(want)
        if p is None:break
        qs.append(p);want=red(want,p)
    assert normal_path(want) is None
    return c,m,r,aa,t,want,ps,qs
if __name__=='__main__':
 import subprocess
 ss=(HERE/'after_quick.in').read_text().split();d=HERE/'probes';d.mkdir(exist_ok=True)
 for i in range(int(sys.argv[1]),(len(ss)+9)//10,int(sys.argv[2])):
    inp=d/f'p{i:03}.in';res=inp.with_suffix('.out')
    if res.exists():continue
    with inp.open('w') as o:
        for s in ss[i*10:i*10+10]:
            for id,t,v in options(lc.decode(s)[0]):
                o.write(f'{s} {id} {lc.enc(t)} {lc.enc(v)}\n')
    tmp=res.with_suffix('.tmp')
    with tmp.open('w') as f:subprocess.run([str(HERE/'probesearch'),str(inp),str(HERE/'tables.in')],stdout=f,check=True,timeout=90)
    tmp.replace(res)
