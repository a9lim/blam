// Untrusted finite-chain discovery on actual beta-reducts. Cache only free indices.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
struct Node {int k,x,y;uint64_t fv;int off=0,cnt=0;vector<int> left,right;};
struct Row{int own,act,want;string id;};
vector<Node> ns;map<array<int,3>,int> ids;vector<vector<Row>> rs;vector<string> wires;
int intern(int k,int x,int y){
 array<int,3> a={k,x,y};if(auto it=ids.find(a);it!=ids.end())return it->second;
 if(k==0 && x>=48)throw runtime_error("index");
 auto fv=k==0?1ull<<x:k==1?ns[x].fv>>1:ns[x].fv|ns[y].fv;
 int p=ns.size();ns.push_back({k,x,y,fv});return ids[a]=p;
}
int parse(const string&s,int&i){if(s.at(i++)=='1'){int j=0;while(s.at(i++)=='1')++j;return intern(0,j,0);}
 if(s.at(i++)=='0')return intern(1,parse(s,i),0);int f=parse(s,i);return intern(2,f,parse(s,i));}
int term(const string&s){int i=0;int p=parse(s,i);if(i!=s.size())throw runtime_error("parse");return p;}
int n,lo,op[9][9];vector<int8_t> mem;
int project(int key,uint64_t parent,uint64_t child){
 int ret=0,place=1;while(parent){auto b=parent&-parent;int v=key%n;key/=n;if(child&b){ret+=place*v;place*=n;}parent-=b;}return ret;
}
void setup(int grade){
 if(n==grade)return;n=grade;int off=0;
 for(auto &v:ns){
  int cnt=1;for(int i=0;i<popcount(v.fv);i++){cnt*=n;if(cnt>300000)throw runtime_error("individual cache bound");}
  v.off=off;v.cnt=cnt;off+=cnt;if(off>35000000)throw runtime_error("sum cache bound");
  if(v.k==2){v.left.resize(cnt);v.right.resize(cnt);for(int i=0;i<cnt;i++){v.left[i]=project(i,v.fv,ns[v.x].fv);v.right[i]=project(i,v.fv,ns[v.y].fv);}}
 }
 mem.resize(off);
}
int eval(int p,int key){
 auto &v=ns[p];auto &r=mem[v.off+key];if(r>=0)return r;
 if(v.k==0)return r=key;
 if(v.k==2)return r=op[eval(v.x,v.left[key])][eval(v.y,v.right[key])];
 int q=lo;for(int a=0;a<n;a++){
   int z=eval(v.x,(ns[v.x].fv&1)?n*key+a:key);while(op[q][a]<z)q++;
 }return r=q;
}
int readenv(int p,int c,int r){switch(ns[p].fv){case 0:return 0;case 1:return r;case 2:return c;case 3:return r+n*c;default:throw runtime_error("open beyond rho");}}
void one(string table){
 if(!lo)return;
 fill(mem.begin(),mem.end(),-1);
 for(int i=0;i<int(rs.size());i++){
  bool win=false;for(const auto&row:rs[i]){
    int a=eval(row.act,readenv(row.act,n-1,n-1));if(a<lo){
       cout<<wires[i]<<" "<<row.id<<" "<<n<<" "<<lo<<" "<<table<<" "<<a<<endl;win=true;}
    if(win)break;
  }
  if(win)rs[i].clear();
 }
}
void gen(int i,int j){
 if(i==n-1){string t;for(int a=0;a<n;a++)for(int b=0;b<n;b++)t+=char('0'+op[a][b]);one(t);return;}
 int base=max(i?op[i-1][j]:0,j?op[i][j-1]:0);
 for(int v=base;v<n;v++){op[i][j]=v;if(j+1==n)gen(i+1,0);else gen(i,j+1);}
}
int main(int argc,char**argv){
 ifstream in(argv[1]);string w,id,a,b;map<string,int>owners;
 while(in>>w>>id>>a>>b){if(!owners.count(w)){owners[w]=rs.size();rs.emplace_back();wires.push_back(w);}
 int i=owners[w];rs[i].push_back({i,term(a),term(b),id});}
 ifstream ts(argv[2]);int m,l;string tab;
 while(ts>>m>>l>>tab){setup(m);lo=l;for(int x=0;x<n;x++)for(int y=0;y<n;y++)op[x][y]=tab[x*n+y]-'0';one(tab);}
 if(argc>3){setup(atoi(argv[3]));fill(op[n-1],op[n-1]+n,n-1);for(lo=1;lo<n-1;lo++)gen(0,0);}
}
