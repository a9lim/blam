from pathlib import Path
from collections import Counter
from functools import lru_cache
import sys,json
import archive_lc as lc
HERE=Path(__file__).resolve().parent
ROOT=HERE
V=lambda n: ("V",n)
L=lambda b: ("L",b)
A=lambda f,a: ("A",f,a)
I=L(V(0));KI=L(I)
def occ(t,n=0):
    if t[0]=='V':return int(t[1]==n)
    if t[0]=='L':return occ(t[1],n+1)
    return occ(t[1],n)+occ(t[2],n)

def nonlinear(t):
    if t[0]=='V':return 0
    if t[0]=='L':return (occ(t[1])>1)+nonlinear(t[1])
    return nonlinear(t[1])+nonlinear(t[2])

def free(t,d=0):
    if t[0]=='V':return {t[1]-d} if t[1]>=d else set()
    if t[0]=='L':return free(t[1],d+1)
    return free(t[1],d)|free(t[2],d)

def width(t):
    if t[0]=='V':return 1
    if t[0]=='L':return max(len(free(t)),width(t[1]))
    return max(len(free(t)),width(t[1]),width(t[2]))

def chain(t):
    if t[0]=='V':return True
    if t[0]=='L':return chain(t[1])
    return chain(t[1]) and chain(t[2]) and (nonlinear(t[1])==0 or nonlinear(t[2])==0)

def counts(t):
    if t[0]=='V':return 0,1,t[1]
    if t[0]=='L':
        a,b,c=counts(t[1]); return a+1,b,c
    return tuple(x+y for x,y in zip(counts(t[1]),counts(t[2])))
def spine(t):
    binders=0
    while t[0]=='L':
        binders+=1
        t=t[1]
    args=[]
    while t[0]=='A':
        args.append(t[2]); t=t[1]
    return binders,t,list(reversed(args))
def head_path(t):
    if t[0]=='L':
        p=head_path(t[1]);return None if p is None else ['under']+p
    if t[0]=='A':
        if t[1][0]=='L':return []
        p=head_path(t[1]);return None if p is None else ['left']+p
    return None

def at(t,p):
    for d in p:t=t[2] if d=='right' else t[1]
    return t

def red(t,p):
    if not p:return lc.beta(t[1],t[2])
    d,*q=p
    if d=='under':return L(red(t[1],q))
    if d=='left':return A(red(t[1],q),t[2])
    return A(t[1],red(t[2],q))

def simp_path(t):
    if t[0]=='L':
        p=simp_path(t[1]);return None if p is None else ['under']+p
    if t[0]=='A':
        if t[1][0]=='L' and (t[2][0]=='V' or occ(t[1][1])<=1):return []
        p=simp_path(t[1])
        if p is not None:return ['left']+p
        p=simp_path(t[2]);return None if p is None else ['right']+p
    return None
def subpaths(t):
    yield []
    if t[0]=='L':
        for p in subpaths(t[1]):yield ['under']+p
    elif t[0]=='A':
        for p in subpaths(t[1]):yield ['left']+p
        for p in subpaths(t[2]):yield ['right']+p
def weak_path(t):
    if t[0]!='A':return None
    if t[1][0]=='L':return []
    p=weak_path(t[1]);return None if p is None else ['left']+p

def apps_spine(t):
    args=[]
    while t[0]=='A':args.append(t[2]);t=t[1]
    return t,list(reversed(args))

def appall(f,args):
    for a in args:f=A(f,a)
    return f
from grammar import b,w
CAP=800
def wire(t):
    if t[0]=='V':return 2+t[1]
    return 2+sum(wire(x) for x in t[1:])

def bounded(t,p):
    f,a=at(t,p)[1:];body=f[1]
    # Conservative bound on substitution; each copy's free occurrences
    # can move inwards by at most the depth of the body.
    if wire(t)>CAP:return None
    u=red(t,p)  # before this call there are at most CAP/2 nodes; even the
                 # quadratic one-step worst case fits 90,000 allocated nodes.
    return u if wire(u)<=CAP else None

def normal_path(t):
    if t[0]=='V':return None
    if t[0]=='L':
        p=normal_path(t[1]);return None if p is None else ['under']+p
    if t[1][0]=='L':return []
    p=normal_path(t[1])
    if p is not None:return ['left']+p
    p=normal_path(t[2]);return None if p is None else ['right']+p

def measure(t,d):
    if t[0]=='V':
        m=1<<t[1] if t[1]<d else 0
        return m,m.bit_count()
    if t[0]=='L':
        m,w=measure(t[1],d+1);return m>>1,w
    a,v=measure(t[1],d);b,w=measure(t[2],d)
    return a|b,max(v,w,(a|b).bit_count())

def sourcefact(t):
    lead,h,args=spine(t)
    if wire(t)<45:return 'smaller'
    if lead>=3:return 'three'
    body=t
    for _ in range(lead):body=body[1]
    if chain(body):return 'chain'
    if measure(body,0)[1]<3:return 'width'
    return None
