import H45F9573528477238Proof66
namespace Blc.H45.H45F9573528477238
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h2400 (ρ : Env) (a0 : Fits s52 (ρ 0)) : All tab ρ b12 s526 :=
  (consAll (lamAt d64 c64 (smaller (h2017 (Types.cons s32 ρ) sub367 a0) sub1020)) Positive.none)
theorem h2401 (ρ : Env) (a0 : Fits s58 (ρ 0)) : All tab ρ b12 s52 :=
  (consAll (lamAt d103 c103 (smaller (h2020 (Types.cons s56 ρ) sub32 a0) sub31)) (consAll (lamAt d112 c112 (smaller (h2022 (Types.cons s61 ρ) sub34 a0) sub33)) (consAll (lamAt d118 c118 (smaller (h2025 (Types.cons s62 ρ) sub36 a0) sub1063)) (consAll (lamAt d121 c121 (smaller (h2026 (Types.cons s63 ρ) sub37 a0) sub1059)) Positive.none))))
theorem h2402 (ρ : Env) (a0 : Fits s64 (ρ 0)) : All tab ρ b12 s539 :=
  (consAll (lamAt d119 c119 (smaller (h2027 (Types.cons s58 ρ) sub384 a0) sub1063)) Positive.none)
theorem h2403 (ρ : Env) (a0 : Fits s66 (ρ 0)) : All tab ρ b12 s58 :=
  (consAll (lamAt d127 c127 (smaller (h2028 (Types.cons s65 ρ) sub1135 a0) sub1136)) (consAll (lamAt d131 c131 (smaller (h2029 (Types.cons s68 ρ) sub1022 a0) sub1060)) (consAll (lamAt d139 c139 (smaller (h2031 (Types.cons s72 ρ) sub42 a0) sub1022)) Positive.none)))
theorem h2404 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s64 :=
  (consAll (lamAt d134 c134 (smaller (h2030 (Types.cons s70 ρ) sub41 a0) sub1022)) (consAll (lamAt d142 c142 (smaller (h2032 (Types.cons s73 ρ) sub43 a0) sub42)) Positive.none))
theorem h2405 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s68 :=
  (consAll (lamAt d133 c133 (smaller (h2034 (Types.cons s69 ρ) sub45 a0) sub1062)) (consAll (lamAt d150 c150 (smaller (h2035 (Types.cons s75 ρ) sub46 a0) sub1061)) Positive.none))
theorem h2406 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s543 :=
  (consAll (lamAt d132 c132 (smaller (h2036 (Types.cons s66 ρ) sub389 a0) sub1060)) Positive.none)
theorem h2407 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s538 :=
  (consAll (lamAt d117 c117 (smaller (h2037 (Types.cons s44 ρ) sub377 a0) sub1020)) Positive.none)
theorem h2408 (ρ : Env) (a0 : Fits s77 (ρ 0)) : All tab ρ b12 s525 :=
  (consAll (lamAt d55 c55 (smaller (h2038 (Types.cons s32 ρ) sub367 a0) sub5)) Positive.none)
theorem h2409 (ρ : Env) (a0 : Fits s83 (ρ 0)) : All tab ρ b12 s77 :=
  (consAll (lamAt d167 c167 (smaller (h2041 (Types.cons s81 ρ) sub50 a0) sub49)) (consAll (lamAt d176 c176 (smaller (h2043 (Types.cons s86 ρ) sub52 a0) sub51)) (consAll (lamAt d179 c179 (smaller (h2045 (Types.cons s87 ρ) sub54 a0) sub5)) (consAll (lamAt d182 c182 (smaller (h2046 (Types.cons s88 ρ) sub55 a0) sub1066)) Positive.none))))
theorem h2410 (ρ : Env) (a0 : Fits s89 (ρ 0)) : All tab ρ b12 s553 :=
  (consAll (lamAt d180 c180 (smaller (h2047 (Types.cons s83 ρ) sub398 a0) sub5)) Positive.none)
theorem h2411 (ρ : Env) (a0 : Fits s91 (ρ 0)) : All tab ρ b12 s83 :=
  (consAll (lamAt d16 c16 (smaller (h2049 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d187 c187 (smaller (h2048 (Types.cons s90 ρ) sub1146 a0) sub5)) (consAll (lamAt d193 c193 (smaller (h2051 (Types.cons s94 ρ) sub1023 a0) sub5)) Positive.none)))
theorem h2412 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s89 :=
  (consAll (lamAt d189 c189 (smaller (h2050 (Types.cons s92 ρ) sub58 a0) sub5)) (consAll (lamAt d194 c194 (smaller (h2052 (Types.cons s95 ρ) sub60 a0) sub1023)) Positive.none))
theorem h2413 (ρ : Env) (a0 : Fits s99 (ρ 0)) : All tab ρ b12 s76 :=
  (consAll (lamAt d24 c24 (smaller (h2054 (Types.cons s17 ρ) sub9 a0) sub5)) (consAll (lamAt d203 c203 (smaller (h2055 (Types.cons s100 ρ) sub62 a0) sub5)) (consAll (lamAt d204 c204 (smaller (h2056 (Types.cons s99 ρ) sub406 a0) sub5)) Positive.none)))
theorem h2414 (ρ : Env) (a0 : Fits s103 (ρ 0)) : All tab ρ b12 s99 :=
  (consAll (lamAt d16 c16 (smaller (h2058 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d207 c207 (smaller (h2057 (Types.cons s101 ρ) sub64 a0) sub5)) (consAll (lamAt d211 c211 (smaller (h2059 (Types.cons s105 ρ) sub65 a0) sub5)) Positive.none)))
theorem h2415 (ρ : Env) (a0 : Fits s107 (ρ 0)) : All tab ρ b12 s103 :=
  (consAll (lamAt d16 c16 (smaller (h2066 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d214 c214 (smaller (h2060 (Types.cons s106 ρ) sub66 a0) sub407)) (consAll (lamAt d216 c216 (smaller (h2061 (Types.cons s107 ρ) sub409 a0) sub407)) (consAll (lamAt d226 c226 (smaller (h2065 (Types.cons s112 ρ) sub1150 a0) sub5)) (consAll (lamAt d233 c233 (smaller (h2068 (Types.cons s117 ρ) sub1025 a0) sub5)) Positive.none)))))
theorem h2416 (ρ : Env) (a0 : Fits s111 (ρ 0)) : All tab ρ b12 s98 :=
  (consAll (lamAt d24 c24 (smaller (h2070 (Types.cons s17 ρ) sub9 a0) sub5)) (consAll (lamAt d212 c212 (smaller (h2064 (Types.cons s103 ρ) sub408 a0) sub5)) (consAll (lamAt d237 c237 (smaller (h2071 (Types.cons s119 ρ) sub75 a0) sub5)) (consAll (lamAt d238 c238 (smaller (h2072 (Types.cons s111 ρ) sub417 a0) sub5)) Positive.none))))
theorem h2417 (ρ : Env) (a0 : Fits s115 (ρ 0)) : All tab ρ b12 s111 :=
  (consAll (lamAt d16 c16 (smaller (h2074 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d228 c228 (smaller (h2067 (Types.cons s114 ρ) sub72 a0) sub5)) (consAll (lamAt d234 c234 (smaller (h2069 (Types.cons s118 ρ) sub74 a0) sub1025)) (consAll (lamAt d241 c241 (smaller (h2073 (Types.cons s120 ρ) sub77 a0) sub5)) Positive.none))))
theorem h2418 (ρ : Env) (a0 : Fits s121 (ρ 0)) : All tab ρ b12 s110 :=
  (consAll (lamAt d230 c230 (smaller (h2075 (Types.cons s115 ρ) sub418 a0) sub5)) (consAll (lamAt d244 c244 (smaller (h2076 (Types.cons s121 ρ) sub420 a0) sub5)) Positive.none))
theorem h2419 (ρ : Env) (a0 : Fits s124 (ρ 0)) : All tab ρ b12 s121 :=
  (consAll (lamAt d246 c246 (smaller (h2077 (Types.cons s122 ρ) sub1153 a0) sub5)) (consAll (lamAt d250 c250 (smaller (h2078 (Types.cons s126 ρ) sub1026 a0) sub5)) (consAll (lamAt d252 c252 (smaller (h2079 (Types.cons s128 ρ) sub82 a0) sub1026)) (consAll (lamAt d256 c256 (smaller (h2080 (Types.cons s130 ρ) sub83 a0) sub82)) Positive.none))))
theorem h2420 (ρ : Env) (a0 : Fits s132 (ρ 0)) : All tab ρ b12 s124 :=
  (consAll (lamAt d259 c259 (smaller (h2081 (Types.cons s131 ρ) sub1027 a0) sub423)) (consAll (lamAt d261 c261 (smaller (h2082 (Types.cons s132 ρ) sub425 a0) sub423)) (consAll (lamAt d269 c269 (smaller (h2085 (Types.cons s137 ρ) sub88 a0) sub87)) (consAll (lamAt d276 c276 (smaller (h2087 (Types.cons s140 ρ) sub90 a0) sub89)) (consAll (lamAt d313 c313 (smaller (h2102 (Types.cons s158 ρ) sub1160 a0) sub1161)) (consAll (lamAt d325 c325 (smaller (h2103 (Types.cons s163 ρ) sub105 a0) sub1069)) (consAll (lamAt d332 c332 (smaller (h2105 (Types.cons s166 ρ) sub107 a0) sub105)) (consAll (lamAt d341 c341 (smaller (h2115 (Types.cons s168 ρ) sub449 a0) sub1068)) (consAll (lamAt d346 c346 (smaller (h2114 (Types.cons s161 ρ) sub442 a0) sub1302)) (consAll (lamAt d354 c354 (smaller (h2114 (Types.cons s161 ρ) sub442 a0) sub1303)) (consAll (lamAt d370 c370 (smaller (h2124 (Types.cons s179 ρ) sub453 a0) sub1159)) (consAll (lamAt d375 c375 (smaller (h2114 (Types.cons s161 ρ) sub442 a0) sub1304)) (consAll (lamAt d383 c383 (smaller (h2114 (Types.cons s161 ρ) sub442 a0) sub1305)) Positive.none)))))))))))))
theorem h2421 (ρ : Env) (a0 : Fits s134 (ρ 0)) : All tab ρ b12 s126 :=
  (consAll (lamAt d251 c251 (smaller (h2083 (Types.cons s127 ρ) sub1154 a0) sub5)) (consAll (lamAt d266 c266 (smaller (h2084 (Types.cons s136 ρ) sub87 a0) sub5)) (consAll (lamAt d273 c273 (smaller (h2086 (Types.cons s139 ρ) sub89 a0) sub87)) Positive.none)))
theorem h2422 (ρ : Env) (a0 : Fits s142 (ρ 0)) : All tab ρ b12 s134 :=
  (consAll (lamAt d16 c16 (smaller (h2091 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d279 c279 (smaller (h2088 (Types.cons s141 ρ) sub1028 a0) sub431)) (consAll (lamAt d285 c285 (smaller (h2090 (Types.cons s145 ρ) sub93 a0) sub5)) Positive.none)))
theorem h2423 (ρ : Env) (a0 : Fits s144 (ρ 0)) : All tab ρ b12 s561 :=
  (consAll (lamAt d267 c267 (smaller (h2089 (Types.cons s134 ρ) sub432 a0) sub5)) Positive.none)
theorem h2424 (ρ : Env) (a0 : Fits s146 (ρ 0)) : All tab ρ b12 s144 :=
  (consAll (lamAt d287 c287 (smaller (h2092 (Types.cons s142 ρ) sub94 a0) sub5)) Positive.none)
theorem h2425 (ρ : Env) (a0 : Fits s147 (ρ 0)) : All tab ρ b12 s133 :=
  (consAll (lamAt d289 c289 (smaller (h2093 (Types.cons s146 ρ) sub95 a0) sub5)) Positive.none)
theorem h2426 (ρ : Env) (a0 : Fits s148 (ρ 0)) : All tab ρ b12 s143 :=
  (consAll (lamAt d293 c293 (smaller (h2094 (Types.cons s147 ρ) sub435 a0) sub5)) Positive.none)
theorem h2427 (ρ : Env) (a0 : Fits s151 (ρ 0)) : All tab ρ b12 s147 :=
  (consAll (lamAt d297 c297 (smaller (h2095 (Types.cons s149 ρ) sub1158 a0) sub1159)) (consAll (lamAt d302 c302 (smaller (h2096 (Types.cons s153 ρ) sub98 a0) sub1068)) (consAll (lamAt d311 c311 (smaller (h2098 (Types.cons s157 ρ) sub1029 a0) sub98)) Positive.none)))
theorem h2428 (ρ : Env) (a0 : Fits s155 (ρ 0)) : All tab ρ b12 s148 :=
  (consAll (lamAt d16 c16 (smaller (h2129 (Types.cons s11 ρ) sub5 a0) sub5)) (consAll (lamAt d305 c305 (smaller (h2097 (Types.cons s154 ρ) sub99 a0) sub98)) (consAll (lamAt d314 c314 (smaller (h2099 (Types.cons s159 ρ) sub101 a0) sub1029)) (consAll (lamAt d397 c397 (smaller (h2128 (Types.cons s191 ρ) sub127 a0) sub5)) Positive.none))))
theorem h2429 (ρ : Env) (a0 : Fits s161 (ρ 0)) : All tab ρ b12 s151 :=
  (consAll (lamAt d317 c317 (smaller (h2100 (Types.cons s160 ρ) sub102 a0) sub439)) (consAll (lamAt d328 c328 (smaller (h2104 (Types.cons s164 ρ) sub106 a0) sub105)) (consAll (lamAt d335 c335 (smaller (h2106 (Types.cons s167 ρ) sub108 a0) sub107)) (consAll (lamAt d342 c342 (smaller (h2109 (Types.cons s169 ρ) sub1165 a0) sub1166)) (consAll (lamAt d345 c345 (smaller (h2110 (Types.cons s171 ρ) sub111 a0) sub1072)) (consAll (lamAt d353 c353 (smaller (h2112 (Types.cons s174 ρ) sub113 a0) sub111)) (consAll (lamAt d371 c371 (smaller (h2119 (Types.cons s180 ρ) sub1171 a0) sub1172)) (consAll (lamAt d374 c374 (smaller (h2120 (Types.cons s182 ρ) sub119 a0) sub1075)) (consAll (lamAt d382 c382 (smaller (h2122 (Types.cons s186 ρ) sub121 a0) sub119)) Positive.none)))))))))
theorem h2430 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s155 :=
  (consAll (lamAt d319 c319 (smaller (h2101 (Types.cons s161 ρ) sub442 a0) sub439)) (consAll (lamAt d402 c402 (smaller (h2131 (Types.cons s188 ρ) sub129 a0) sub457)) Positive.none))
theorem h2431 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s570 :=
  (consAll (lamAt d326 c326 (smaller (h2107 (Types.cons s132 ρ) sub425 a0) sub1069)) Positive.none)
theorem h2432 (ρ : Env) (a0 : Fits s168 (ρ 0)) : All tab ρ b12 s566 :=
  (consAll (lamAt d303 c303 (smaller (h2108 (Types.cons s151 ρ) sub440 a0) sub1068)) Positive.none)
theorem h2433 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b12 s168 :=
  (consAll (lamAt d348 c348 (smaller (h2111 (Types.cons s172 ρ) sub112 a0) sub111)) (consAll (lamAt d356 c356 (smaller (h2113 (Types.cons s175 ρ) sub114 a0) sub113)) (consAll (lamAt d362 c362 (smaller (h2116 (Types.cons s176 ρ) sub116 a0) sub1170)) (consAll (lamAt d365 c365 (smaller (h2117 (Types.cons s177 ρ) sub117 a0) sub1073)) Positive.none))))
theorem h2434 (ρ : Env) (a0 : Fits s179 (ρ 0)) : All tab ρ b12 s581 :=
  (consAll (lamAt d296 c296 (smaller (h2127 (Types.cons s148 ρ) sub436 a0) sub5)) (consAll (lamAt d300 c300 (smaller (h2118 (Types.cons s151 ρ) sub440 a0) sub1159)) Positive.none))
theorem h2435 (ρ : Env) (a0 : Fits s184 (ρ 0)) : All tab ρ b12 s179 :=
  (consAll (lamAt d377 c377 (smaller (h2121 (Types.cons s183 ρ) sub120 a0) sub119)) (consAll (lamAt d385 c385 (smaller (h2123 (Types.cons s187 ρ) sub122 a0) sub121)) (consAll (lamAt d390 c390 (smaller (h2125 (Types.cons s189 ρ) sub124 a0) sub1175)) (consAll (lamAt d393 c393 (smaller (h2126 (Types.cons s190 ρ) sub125 a0) sub1076)) (consAll (lamAt d399 c399 (smaller (h2130 (Types.cons s193 ρ) sub128 a0) sub5)) Positive.none)))))
end Blc.H45.H45F9573528477238
