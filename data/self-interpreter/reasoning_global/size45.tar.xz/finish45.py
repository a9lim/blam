"""Merge the ten separately checked literal exclusions into the archived witnesses."""
from pathlib import Path
import csv,hashlib,json,tarfile
D=Path(__file__).resolve().parent
def main():
 h=D.parent/'floor44/help45'
 with tarfile.open(h/'help45.tar.xz','r:xz') as tf:
  sums=dict((ln.split('  ',1)[1],ln.split('  ',1)[0]) for ln in tf.extractfile('SHA256SUMS').read().decode().splitlines())
  mods=[n for n in tf.getnames() if n.endswith('.lean')]
  assert len(mods)==292 and 'H45Bridge.lean' in mods
  for n in mods:
   assert Path(n).name==n and n.startswith('H45')
   b=tf.extractfile(n).read();assert hashlib.sha256(b).hexdigest()==sums[n]
   (D/n).write_bytes(b)
  manifest=tf.extractfile('manifest.tsv').read()
  assert (D/'helper-proof-index.tsv').read_bytes()==manifest
 p=D/'proof-witnesses.json';data=json.loads(p.read_text())
 rows=list(csv.DictReader(manifest.decode().splitlines(),delimiter='\t'))
 assert len(rows)==10
 for r in rows:
  s=r['wire'];n=int(s,2);old=data['records'][s];assert old['kind'] in ('pending','common_head','flow_types')
  data['records'][s]=dict(kind=r['method'],module='H45Bridge',theorem=r['theorem'],term=f'Blc.Floor45.e{n}',strength='complete')
  if 'Classical.choice' in r['axioms'] and s not in data['choice']:data['choice'].append(s)
 p.write_text(json.dumps(data,separators=(',',':'))+'\n')
 print(len(mods),'local proof modules;',len(rows),'finalized witnesses')
if __name__=='__main__':main()
