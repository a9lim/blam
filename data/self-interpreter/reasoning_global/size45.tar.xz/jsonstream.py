"""Read an arbitrarily long JSON object in bounded chunks."""
import json
def pairs(path):
 dec=json.JSONDecoder()
 with open(path) as f:
    buf='';done=False
    def fill():
       nonlocal buf,done
       s=f.read(65536);done=not s;buf+=s
    def take():
       nonlocal buf
       while True:
          try:v,j=dec.raw_decode(buf);buf=buf[j:].lstrip();return v
          except json.JSONDecodeError:
             if done:raise
             fill();buf=buf.lstrip()
    def ch(x):
       nonlocal buf
       while not buf and not done:fill();buf=buf.lstrip()
       assert buf.startswith(x),buf[:30];buf=buf[1:].lstrip()
    fill();ch('{')
    while True:
       k=take();ch(':');v=take();yield k,v
       while not buf and not done:fill();buf=buf.lstrip()
       if buf.startswith('}'):ch('}');assert not buf and not f.read().strip();return
       ch(',')
def ledger(path):
 with open(path) as f:
    for ln in f:
       line=ln.strip().rstrip(',')
       if line not in ('[',']'):yield json.loads(line)
