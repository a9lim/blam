"""Run one bounded verification subprocess, reporting its own exit and wait4 metrics."""
import json,os,sys,time,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
if __name__=='__main__':
 label=sys.argv[1];start=time.monotonic()
 with (D/(label+'.txt')).open('w') as f:
  p=subprocess.Popen(sys.argv[2:],cwd=D,stdout=f,stderr=subprocess.STDOUT)
  while True:
   pid,st,u=os.wait4(p.pid,os.WNOHANG)
   if pid:break
   if time.monotonic()-start>510:p.kill()
   time.sleep(.08)
 p.returncode=os.waitstatus_to_exitcode(st)
 result=dict(command=sys.argv[2:],exit_code=p.returncode,wall_seconds=round(time.monotonic()-start,3),rss_bytes=u.ru_maxrss)
 print(result)
 (D/(label+'-metrics.json')).write_text(json.dumps(result,indent=1)+'\n')
 assert p.returncode==0 and u.ru_maxrss<1_000_000_000
