"""Compare public and internal head shapes, following size 44's rootshapes.py."""
from candidates import *
import csv
def main():
 prev=HERE.parent/'floor45'/'root-shapes.tsv'
 with prev.open() as f:
  rows=list(csv.DictReader(f,delimiter='\t'))
 old={(int(r['public_lambdas']),r['head'],int(r['spine_arguments']),int(r['head_lambdas'])):int(r['size44']) for r in rows}
 now=Counter()
 with (HERE/'wires.txt').open() as f:
  for s in f:
   l,t,args=spine(lc.decode(s.strip())[0]);h=0
   while t[0]=='L':h+=1;t=t[1]
   now[l,'lambda' if h else 'var',len(args),h]+=1
 with (HERE/'root-shapes.tsv').open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['public_lambdas','head','spine_arguments','head_lambdas','size44','size45'])
  for k in sorted(now.keys()|old.keys()):w.writerow([*k,old.get(k,0),now[k]])
if __name__=='__main__':main()
