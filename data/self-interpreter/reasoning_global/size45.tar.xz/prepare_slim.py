"""Build slim.json from byte-matched independent rendering and the packer's selected files."""
from package_partial import selected,D
from slim_compare import digest
import json
kept_inputs={'certs.json','proof-witnesses.json','emitter-versions.json','build-metrics.json','hard-six.txt','raw4.txt','raw5.txt','extra-manifest.json','late-manifest.json','types-manifest.json','bottom-manifest.json'}
data_files={'unresolved.tsv','checked-counts.json','triples.tsv','partition.json','complete.tsv','residuals.tsv','ledger.json','model.json','hard-model.json','probe-manifest.json','additional-finite.json','residual-proof-roots.txt','proof-modules.txt','wires.txt','cross.txt','broad.txt','open.txt','unresolved.txt','after4.in','after_quick.in'}
def main():
 tmp=D/'.slim-test';files={}
 for n in selected()[0]:
  if n in kept_inputs or not (n.endswith('.lean') or n in data_files) or not (tmp/n).is_file():continue
  p=D/n;h=digest(p);assert h==digest(tmp/n),n;files[n]=h
 assert {f'Batch{i:04}.lean' for i in range(2670)}<=files.keys()
 (D/'slim.json').write_text(json.dumps({'regen':'regen.py','files':files},indent=1)+'\n')
 print(len(files),sum((D/n).stat().st_size for n in files))
if __name__=='__main__':main()
