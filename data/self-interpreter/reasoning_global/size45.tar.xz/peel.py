from observed import *
from searchprobes import target_steps
from harder import remain
from ranktest import profile
from regscan import regular,portable,mask
from functools import lru_cache
from collections import Counter
def points(q,limit=420):
 pool=[];index={}
 def intern(t,e):
    key=(t,e)
    if key not in index:index[key]=len(pool);pool.append(key)
    return index[key]
 @lru_cache(7000)
 def material(t,e,d):
    if t[0]=='V':
       n=t[1]
       if n<d:return t
       k=n-d
       if k>=len(e):return V(n-len(e))
       u=material(*pool[e[k]],0)
       if u is None:return None
       v=lc.shift(d,0,u)
    elif t[0]=='L':
       b=material(t[1],e,d+1)
       if b is None:return None
       v=L(b)
    else:
       f=material(t[1],e,d);a=material(t[2],e,d)
       if f is None or a is None:return None
       v=A(f,a)
    return v if wire(v)<=225 else None
 p=intern(q,());st=[];seen=set()
 for j in range(limit):
    t,e=pool[p]
    if t[0]=='A':st.append(intern(t[2],e));p=intern(t[1],e)
    elif t[0]=='L':
       if not st:break
       p=intern(t[1],(st.pop(),)+e)
    else:
       if t[1]>=len(e):break
       p=e[t[1]]
    if j<2 or pool[p][0][0]!='L':continue
    val=material(*pool[p],0)
    if val is None:continue
    for k in range(min(9,len(st))+1):
       if k and val not in seen:
          seen.add(val);yield j+1,k,val
       if k==min(9,len(st)):break
       a=material(*pool[st[-k-1]],0)
       if a is None or wire(val)+wire(a)+2>225:break
       val=A(val,a)
def frames(e):
 opts=[('raw',e)]
 for i,(c,m,r,aa) in enumerate(symbols()):
    if i not in [0,1,2,3,4,11,12]:continue
    if target_steps(c,m,r,aa) is not None:opts.append((i,appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)))
 return opts
def go(s):
 e=lc.decode(s)[0];opts=[];seen=set()
 for typ,q in frames(e):
    for j,k,t in points(q):
       if t in seen:continue
       seen.add(t);opt=[typ,j,k,lc.enc(t)]
       if not free(t):
        for c in (1,2,3,4):
          r,_,ok=profile(t,c)
          if not r and ok:return ['rank',opt,c]
       opts.append((wire(t),j,k,opt,t))
 opts.sort(key=lambda a:(a[0],a[1],a[2]))
 for _,_,_,opt,t in opts[:85]:
    for ctx,mode in [(0,'site'),(1,'argenv'),(2,'env')]:
       try:z=regular.discover(mask(t),ctx,cap=2000,seconds=.02,mode=mode)
       except regular.Limit:continue
       if z['ok'] and z['states']<1500:
          cert=portable.portable(z);return ['regular',opt,ctx,mode,cert]
 return ['unknown',[r[3] for r in opts[:200]]]
if __name__=='__main__':
 d=HERE/'peel';d.mkdir(exist_ok=True)
 for s in remain():
    p=d/(s+'.json')
    if not p.exists():p.write_text(json.dumps(go(s)))
