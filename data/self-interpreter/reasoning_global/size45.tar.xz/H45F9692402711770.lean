import H45F9692402711770Proof8
import H45Literals
import H45ProbeClock
namespace Blc.H45.H45F9692402711770
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
def env : Env := Types.cons s0 (Types.cons s0 Types.empty)
theorem excluded : ¬ IsSelfInterpreter e9692402711770 := by
  intro he
  have hp : replay [[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] (.app e9692402711770 (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)))) = some b215 := by decide
  obtain ⟨_,hc⟩ := clocks_replay (argCount (c := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)))) (k := 4) he (by decide)) hp
  exact Types.noClock (m := tab) ((h298 Types.empty) 0 mem15) (by decide) hc
#print axioms excluded
end Blc.H45.H45F9692402711770
