"""Collect the exact partition; an open row has only its wire identity."""
from candidates import *
from jsonstream import pairs,ledger
import csv,re
from collections import defaultdict

def fullmod(s,r):
    num=str(int(s,2));nm='Reg'+num;ns='Blc.Floor45.'+nm
    return dict(kind='regular',module=nm,theorem=ns+'.excluded',term=ns+'.e'+num,states=r[0],probe=r[1],prefix=r[5],context=r[3],allocator=r[4])
def collect():
 x={}
 def add(s,r):
    if (HERE/(r['module']+'.lean')).exists():x.setdefault(s,r)
 # Use the shortest independently checkable certificates wherever alternatives overlap.
 for name in ('model','hard-model','extra-manifest','probe-manifest','late-manifest'):
    p=HERE/(name+'.json')
    if p.exists():
       for s,r in json.loads(p.read_text()).items():add(s,r)
 for p in (HERE/'seen').glob('*.json'):add(p.stem,json.loads(p.read_text()))
 p=HERE/'types-manifest.json'
 if p.exists():
    for s,r in json.loads(p.read_text()).items():add(s,r)
 for p in sorted([*HERE.glob('r[0-9]*.json'),*HERE.glob('h[0-9]*.json')]):
    s=f'{int(p.stem[1:]):045b}'
    if s not in x:add(s,fullmod(s,json.loads(p.read_text())))
 for name in ('prefix-manifest','final-manifest','bottom-manifest'):
    p=HERE/(name+'.json')
    if p.exists():
       for s,r in json.loads(p.read_text()).items():add(s,r)
 for s,r in json.loads((HERE/'proof-witnesses.json').read_text())['records'].items():
    if r['module']=='H45Bridge':add(s,r)
 return x
def gather():
 x=collect();res=[];unknown=[];co=Counter();roots=defaultdict(Counter);n=0
 with (HERE/'ledger.tmp').open('w') as out:
    out.write('[\n')
    for i,(s,w) in enumerate(pairs(HERE/'certs.json')):
       k=w[0];nm='e'+str(int(s,2));mod=f'Batch{i//160:04}';term='Blc.Floor45.'+nm
       r=dict(kind=k,module=mod,theorem='Blc.Floor45.cert_'+nm,term=term,strength='complete' if k.startswith('W') else 'predicate')
       if k=='open':
          if s in x:
             r.update(x[s]);r['strength']=x[s].get('strength','complete')
             if r['strength']=='complete' and r['module']!='H45Bridge':res.append((r['term'],r['theorem'],r['module']))
          else:
             unknown.append(s);r.update(kind='pending',strength='predicate',status='pending',theorem='Blc.Floor45.wire_'+nm)
       root='app' if s[:2]=='01' else 'literal';co[r['kind']]+=1;roots[r['kind']][root]+=1
       row=dict(wire=s,root=root,triple=counts(lc.decode(s)[0]),**r)
       if i:out.write(',\n')
       out.write(json.dumps(row,separators=(',',':')));n+=1
    out.write('\n]\n')
 assert n==427114
 (HERE/'ledger.tmp').replace(HERE/'ledger.json')
 (HERE/'unresolved.txt').write_text(''.join(w+'\n' for w in unknown))
 (HERE/'partition.json').write_text(json.dumps(dict(n=n,residual_direct=len(res),unresolved=len(unknown),kinds=roots),indent=1)+'\n')
 return res
def groups(res):
 # The groups depend only on direct negative theorems. They never consume a bare predicate.
 blocks=[]
 for i in range(0,len(res),40):
    rs=res[i:i+40];nm=f'ResidualGroup{i//40:03}';blocks.append(nm)
    lines=['import '+m for m in sorted({m for _,_,m in rs})]+['namespace Blc.Floor45.'+nm]
    for j,(t,th,_) in reversed(list(enumerate(rs))):
       tail=f'xs{j+1}' if j+1<len(rs) else '[]';ih=f'exact bad{j+1} _ h' if j+1<len(rs) else 'simp at h'
       lines+= [f'def xs{j} : List Term := {t} :: {tail}',f'theorem bad{j} (v : Term) (h : v ∈ xs{j}) : ¬ IsSelfInterpreter v := by',
             '  rcases List.mem_cons.mp h with rfl | h',f'  · exact {th}','  · '+ih]
    (HERE/(nm+'.lean')).write_text('\n'.join(lines+['end Blc.Floor45.'+nm])+'\n')
 nodes=[(nm,nm+'.xs0',nm+'.bad0') for nm in blocks];i=0
 while len(nodes)>1:
    nextnodes=[]
    for j in range(0,len(nodes),8):
       group=nodes[j:j+8];nm=f'ResidualSet{i:02}G{j//8:03}'
       lines=['import '+m for m,_,_ in group]+['namespace Blc.Floor45.'+nm]
       for k,(_,left,hleft) in reversed(list(enumerate(group))):
          tail=f'xs{k+1}' if k+1<len(group) else '[]';ih=f'exact bad{k+1} _ h' if k+1<len(group) else 'simp at h'
          lines += [f'def xs{k} : List Term := {left} ++ {tail}',f'theorem bad{k} (t : Term) (h : t ∈ xs{k}) : ¬ IsSelfInterpreter t := by',
                    '  rcases List.mem_append.mp h with h | h',f'  · exact {hleft} t h','  · '+ih]
       (HERE/(nm+'.lean')).write_text('\n'.join(lines+['end Blc.Floor45.'+nm])+'\n')
       nextnodes.append((nm,nm+'.xs0',nm+'.bad0'))
    nodes=nextnodes;i+=1
 m,xs,h=nodes[0]
 (HERE/'Residuals.lean').write_text(f'import {m}\nnamespace Blc.Floor45\ndef residuals := {xs}\ntheorem residuals_excluded (t : Term) (h : t ∈ residuals) : ¬ IsSelfInterpreter t := {h} t h\n#print axioms residuals_excluded\nend Blc.Floor45\n')
def tables():
 from ready_groups import state
 stage=HERE/'.checked';logs={};summary=Counter();pending=Counter()
 with (HERE/'complete.tsv').open('w') as f,(HERE/'residuals.tsv').open('w') as g:
    fs=[csv.writer(h,delimiter='\t',lineterminator='\n') for h in (f,g)]
    for w in fs:w.writerow(['wire','kind','file','theorem','statement','axioms','kernel_status'])
    for r in ledger(HERE/'ledger.json'):
       mod=r['module'];k=r['kind']
       if mod not in logs:
          p=stage/(mod+'.log')
          ok=p.is_file() and state(mod)[1]
          logs[mod]=(ok,dict(re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",p.read_text())) if ok else {})
       present,ax=logs[mod];th=r['theorem'];strength=r['strength']
       if r.get('status')=='pending':
          pending['search']+=1
          for writer in fs:writer.writerow([r['wire'],'pending',mod+'.lean','','¬ Blc.IsSelfInterpreter '+r['term'],'','pending'])
          continue
       ck=present and (strength!='complete' or th in ax)
       if ck:summary[k]+=1
       else:pending[k]+=1
       if strength!='complete':continue
       row=[r['wire'],k,mod+'.lean',th,'¬ Blc.IsSelfInterpreter '+r['term'],ax.get(th,''),'checked' if ck else 'pending']
       fs[0].writerow(row)
       if not k.startswith('W'):fs[1].writerow(row)
 (HERE/'checked-counts.json').write_text(json.dumps(dict(checked=summary,pending=pending),indent=1)+'\n')
 return sum(summary.values()),pending
if __name__=='__main__':
 rs=gather();groups(rs)
 import seal_groups,attach_groups
 seal_groups.main();attach_groups.main()
 print('direct residuals',len(rs),'checked survey',tables())
