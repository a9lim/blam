#[allow(dead_code)]
#[path="archive_enumerate.rs"] mod enumerate;
use std::io::{BufWriter,Write};
// FV bit positions are relative indices; once/twice are occurrence summaries.
// Unlike enum.cpp this has no skeleton, binder IDs or algebraic wire-cost test.
#[derive(Default)]
struct Info { once:u32, twice:u32, width:u32, nl:bool, pair:bool }
fn parse(word:u64, pos:&mut u32, d:u32)->Info{
    let mut bit=||{*pos-=1;(word>>*pos)&1};
    if bit()!=0 {
        let mut v=0;while bit()!=0{v+=1}
        return Info{once:1<<v,width:(v<d) as u32,..Default::default()};
    }
    if bit()==0 {
        let a=parse(word,pos,d+1);
        return Info{once:a.once>>1,twice:a.twice>>1,width:a.width,
                    nl:a.nl || a.twice&1!=0,pair:a.pair};
    }
    let a=parse(word,pos,d);let b=parse(word,pos,d);
    let f=a.once|b.once;
    Info { once:f,twice:a.twice|b.twice|(a.once&b.once),
           width:a.width.max(b.width).max((f&((1<<d)-1)).count_ones()),
           nl:a.nl||b.nl,pair:a.pair||b.pair||(a.nl&&b.nl) }
}
fn main(){
    let mut total=0u64;let mut raw=0u64;
    let mut out=BufWriter::new(std::io::stdout().lock());
    enumerate::for_each_closed(45,&mut |w,_|{
        total+=1;
        let lit=w>>43==0;
        if lit && (w>>41)&3==0{return}
        let mut pos=if lit{43}else{45};
        let a=parse(w,&mut pos,0);
        if a.width>=3 && a.pair && (!lit || a.once&1!=0){
            raw+=1;writeln!(out,"{:045b}",w).unwrap();
        }
    });
    assert_eq!(total,2933097201);
    eprintln!("{} closed, {} structurally admissible",total,raw);
}
