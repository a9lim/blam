from deep import *
from regscan import search
for s in (HERE/'hardw.txt').read_text().split():
    if remaining(s) and (r:=search(s,1)):
        (HERE/('r'+str(int(s,2))+'.json')).write_text(json.dumps(r))
        print(s,r[:5],flush=True)
