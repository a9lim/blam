from probes import *
from deep import P
from searchprobes import target_steps
from harder import remain
from emitextra import soproof
def search(e):
 for pp in [A(A(A(e,K),lc.bitlist(lc.enc(P),I)),I)]:
  for st in [1,0,2]:
   t=pp;ps=[]
   for j in range(60):
    if so(t):return ['pairSO',ps]
    p=variant(t,st)
    if p is None:break
    t=bounded(t,p)
    if t is None:break
    ps.append(p)
 for m in (I,KI,K):
  for aa in [[],[I],[om],[om,om],[om]*4,[om]*6]:
   for c,r in [(KI,R),(K,om),(K,R),(C,R),(L(L(I)),om),(om[1],R),(L(L(A(V(1),I))),R),(L(L(A(V(1),V(0)))),I)]:
    target=appall(A(A(c,L(m)),r),aa);qs=[];wanted=target
    for _ in range(25):
        p=normal_path(wanted)
        if p is None:break
        wanted=bounded(wanted,p)
        if wanted is None:break
        qs.append(p)
    if wanted is None or normal_path(wanted) is not None:continue
    q=appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)
    for style in [1,0]:
     t=q;ps=[];seen=set()
     for j in range(60):
        if t in seen:break
        seen.add(t)
        typ=None
        if b(t):typ='Wprobe'
        elif wanted[0]=='V' and not occ(t,wanted[1]):typ='absent'
        else:
           leads,h,args=spine(t);ll,hh,ar=spine(wanted)
           if leads>ll or h[0]=='V' and (leads,h,len(args))!=(ll,hh,len(ar)):typ='mismatch'
        if typ:return [typ,ps,*map(lc.enc,(c,m,r)),list(map(lc.enc,aa)),qs]
        p=variant(t,style)
        if p is None:break
        t=bounded(t,p)
        if t is None:break
        ps.append(p)
def main():
 d=HERE/'late';d.mkdir(exist_ok=True)
 for s in remain():
    if z:=search(lc.decode(s)[0]):(d/(s+'.json')).write_text(json.dumps(z))
    b.cache_clear();so.cache_clear()
if __name__=='__main__':main()
