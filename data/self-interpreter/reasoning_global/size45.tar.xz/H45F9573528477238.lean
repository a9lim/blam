import H45F9573528477238Proof70
import H45Literals
import H45Clocks
namespace Blc.H45.H45F9573528477238
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
def env : Env := Types.cons s0 (Types.cons s0 Types.empty)
theorem excluded : ¬ IsSelfInterpreter e9573528477238 := by
  intro he
  have hp : replay [] (.app e9573528477238 churchTrue) = some b16 := by decide
  obtain ⟨_,hc⟩ := clocks_replay (kCount he) hp
  exact Types.noClock (m := tab) ((h2502 Types.empty) 0 mem546) (by decide) hc
#print axioms excluded
end Blc.H45.H45F9573528477238
