"""Screen shards, saving each replay immediately and committing shards by rename."""
from genlean import *
import os
SIZE=160
def generate(i, ss):
    dst=HERE/'shards'/f'{i:04}.json'
    if dst.exists():return
    rows={}
    for s in ss:
        rows[s]=test(lc.decode(s)[0])
        b.cache_clear();w.cache_clear()
        if len(rows)%16==0:wire.cache_clear();measure.cache_clear()
    b.cache_clear();w.cache_clear()
    tp=dst.with_suffix('.tmp');tp.write_text(json.dumps(rows,separators=(',',':')));tp.replace(dst)
def lean(i,rows):
    dst=HERE/f'Batch{i:04}.lean'
    if dst.exists():return
    out=['import Floor45','namespace Blc.Floor45','open Term SelfintSharp SelfintLowerBound Round3Floor38','set_option maxRecDepth 30000','set_option maxHeartbeats 3500000']
    for s,r in rows.items():
        e=lc.decode(s)[0];k=r[0];nm='e'+str(int(s,2))
        out.append(f'def {nm} : Term := {expr(e)}')
        out.append(f'theorem wire_{nm} : Closed {nm} ∧ code {nm} = {int("1"+s,2)} := by decide')
        if k=='open':continue
        if k=='payload':prop=f'checkPay {nm} {paths(r[1])} {r[2]} {paths(r[3])} = true := by decide'
        elif k.startswith('W'):
            t=e if k=='Wsource' else A(A(e,V(1)),lc.bitlist('0010',V(0)))
            for p in r[1]:t=red(t,p)
            v='t_'+nm;start=nm if k=='Wsource' else '(inv '+nm+')'
            out.append(f'private def {v} : Term := {expr(t)}')
            prop=f'¬ IsSelfInterpreter {nm} := w{k[1:].title()} (t := {v}) (replay_sound (ps := {paths(r[1])}) (t := {start}) (by decide)) (by decide)'
        else:prop=f'check {nm} {paths(r[1])} .{k} = true := by decide'
        out.append(f'theorem cert_{nm} : {prop}')
        if k.startswith('W'):out.append(f'#print axioms cert_{nm}')
    out.append('end Blc.Floor45')
    tmp=dst.with_suffix('.tmp');tmp.write_text('\n'.join(out)+'\n');tmp.replace(dst)
if __name__=='__main__':
    wires=sorted((HERE/'wires.txt').read_text().split())
    assert len(wires)==len(set(wires))==427114
    assert sum(s.startswith('00') for s in wires)==85376
    (HERE/'shards').mkdir(exist_ok=True)
    for i in range(int(sys.argv[1]),min(int(sys.argv[3]) if len(sys.argv)>3 else 99999,(len(wires)+SIZE-1)//SIZE),int(sys.argv[2])):
        generate(i,wires[i*SIZE:(i+1)*SIZE])
        lean(i,json.loads((HERE/'shards'/f'{i:04}.json').read_text()))
