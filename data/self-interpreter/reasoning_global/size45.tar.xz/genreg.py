from compactreg import *
from pathlib import Path
def split(name):
 dp=HERE/(name+'Data.lean');s=dp.read_text()
 if len(s)>47000:
    lines=s.splitlines(keepends=True);first=next(i for i,v in enumerate(lines) if v.startswith('def '))
    header=''.join(lines[1:first]);entries=[];curr=''
    for l in lines[first:-1]:
       if l.startswith(('def ','theorem ')) and curr:entries.append(curr);curr=''
       curr+=l
    if curr:entries.append(curr)
    groups=['']
    for a in entries:
       if len(groups[-1])+len(a)>35000:groups.append('')
       groups[-1]+=a
    imp='RegProof'
    for j,g in enumerate(groups):
       nm=name+'D'+str(j) if j+1<len(groups) else name+'Data'
       (HERE/(nm+'.lean')).write_text('import '+imp+'\n'+header+g+lines[-1]);imp=nm
 p=HERE/(name+'.lean');s=p.read_text()
 ls=s.splitlines(keepends=True);start=next(i for i,x in enumerate(ls) if x.startswith('theorem ok0 '));end=next(i for i,x in enumerate(ls) if x.startswith('theorem okAll '))
 if end-start>32:
    mods=[]
    for i in range(start,end,12):
       nm=name+'B'+str((i-start)//12);mods.append(nm)
       (HERE/(nm+'.lean')).write_text(''.join(ls[:start]+ls[i:min(end,i+12)]+[ls[-1]]))
    p.write_text(''.join('import '+m+'\n' for m in mods)+''.join(ls[1:start]+ls[end:]))
if __name__=='__main__':
 from collections import Counter
 pcols={s.split()[0] for d in ['probes','hardprobe'] for p in (HERE/d).glob('*.out') for s in p.read_text().splitlines()};stats=Counter()
 for p in sorted([*HERE.glob('r[0-9]*.json'),*HERE.glob('h[0-9]*.json')]):
    s=f'{int(p.stem[1:]):045b}'
    if s in pcols:continue
    nm='Reg'+str(int(s,2))
    if (HERE/(nm+'.lean')).exists():continue
    nm=emit(p);split(nm);stats['generated']+=1
 print(stats)
