def compile_term(t):
    nodes=[]
    def go(t):
        i=len(nodes); nodes.append(None)
        if t[0] in ('V','C'): n=t
        elif t[0]=='L': n=('L',go(t[1]))
        else: n=('A',go(t[1]),go(t[2]))
        nodes[i]=n; return i
    go(t); return nodes
