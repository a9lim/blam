from typesat import *
from prefixsat import candidates as prefix_candidates
def synthpos(work,n,m,t,raw,sec):
 f=CNF(work/'body');arr=[[[f.v() if not raw or i else -1 for _ in range(n)] for _ in range(m)] for i in range(n)]
 dom=[[f.v() for _ in range(n)] for _ in range(m)]
 def and_(s):return f.every(s)
 # The order of domain templates has no semantic effect. Remove that symmetry.
 for a,b in zip(dom,dom[1:]):
    eq=1
    for l,r in reversed(list(zip(a,b))):
       f.add(-eq,-l,r);eq=and_([eq,-and_([l,-r]),-and_([-l,r])])
 # Synthesize only the demanded derivation. Unobserved subexpressions can
 # stay untyped. One witness of the application's argument suffices per domain.
 envs=dom+[[-1]*n]
 @lru_cache(None)
 def calc(t,env):
    if t[0]=='V':return envs[env[0]]
    ds=dict(zip(inds(t),env));out=[f.v() for _ in range(n)]
    if t[0]=='L':
       b=t[1];subs=[calc(b,tuple(j if i==0 else ds[i-1] for i in inds(b))) for j in range(m)]
       for i in range(n):
          if raw and i==0:f.add(-out[i]);continue
          for j in range(m):
             for k in range(n):f.add(-out[i],-arr[i][j][k],subs[j][k])
    else:
       def sub(x):return calc(x,tuple(ds[i] for i in inds(x)))
       fn=sub(t[1]);a=sub(t[2]);fit=[f.v() for j in range(m)]
       for j in range(m):
          for b in range(n):f.add(-fit[j],-dom[j][b],a[b])
       for b in range(n):
          ls=[]
          for i in range(int(raw),n):
             for j in range(m):
                v=f.v();f.add(-v,arr[i][j][b]);f.add(-v,fn[i]);f.add(-v,fit[j]);ls.append(v)
          f.add(-out[b],*ls)
    return out
 try:
    q=calc(t,(m,)*len(inds(t)));f.add(q[0])
    if raw and t[0]=='A' and t[1][0]=='L':
       # Some non-atomic arrow at the outer application returns the target token.
       # Type labels 1..n-1 are interchangeable.
       f.add(*[arr[1][j][0] for j in range(m)])
 except Limit:return
 finally:f.file.close();calc.cache_clear()
 with (work/'q.cnf').open('wb') as o:
    o.write(f'p cnf {f.count} {f.nclauses}\n'.encode())
    with (work/'body').open('rb') as q:shutil.copyfileobj(q,o)
 try:q=subprocess.run([str(CAD),'-q','-t',str(sec),str(work/'q.cnf')],capture_output=True,timeout=sec+2)
 except subprocess.TimeoutExpired:return
 if q.returncode!=10:return
 vals={int(x) for ln in q.stdout.decode().splitlines() if ln.startswith('v ') for x in ln.split()[1:]}
 rules=[None if raw and not i else [[[z for z in range(n) if dom[j][z] in vals],b] for j in range(m) for b in range(n) if arr[i][j][b] in vals] for i in range(n)]
 return [rules,[],[],0]
def go():
 n,m,sec=map(int,sys.argv[1:]);out=HERE/'abstract';work=out/f'positive{n}X{m}';work.mkdir(exist_ok=True)
 for s in remain():
    e=lc.decode(s)[0];dest=out/(s+'.json')
    # The normal targets of probes 0 and 1 have a free marker at the head.
    for id in ['!','0:0:0','1:1:3','0:1:5','1:1:7','0:0:8']:
       if dest.exists():break
       if id=='!':t=e
       else:
          try:t=get(s,id)[4]
          except (TypeError,IndexError):continue
          if wire(t)>245:continue
       if z:=synthpos(work,n,m,t,id=='!',sec):
           dest.write_text(json.dumps([id,*z]));break
if __name__=='__main__':go()
