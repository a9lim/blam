from candidates import *
import resource,signal,traceback,os
def check(*a):
 if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>280000000:
    traceback.print_stack();raise MemoryError("rss guard")
signal.signal(signal.SIGALRM,check);signal.setitimer(signal.ITIMER_REAL,.015,.015)
ss=sorted((HERE/'wires.txt').read_text().split())
for j in range(160):
 s=ss[691*160+j]
 print(j,s,resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,flush=True)
 e=lc.decode(s)[0];r=test(e);b.cache_clear();w.cache_clear()
