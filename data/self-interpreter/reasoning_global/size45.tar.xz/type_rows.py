from grade_rows import *
from probes import get
from machine_diag import observe
from searchprobes import target_steps
def rulestr(ars):
 if ars is None:return 'none'
 return '(some ['+','.join('⟨'+natlist(a)+','+str(b)+'⟩' for a,b in ars)+'])'
def main():
 mani={}
 for p in (HERE/'abstract').glob('*.json'):
    s=p.stem;id,graph,r,c,z=json.loads(p.read_text());num=int(s,2);nm=f'e{num}';mod=f'Atom{num}';ns='Blc.Floor45.'+mod
    n=len(graph);ls=['import MultiTypes','namespace '+ns,'open Term SelfintLowerBound SelfintControl Round3Floor38 MultiTypes','set_option maxRecDepth 30000','set_option maxHeartbeats 5000000',src(s,nm),f'private def graph (i : Fin {n}) : Option (List (Arrow {n})) := match i.val with']
    ls += [f'  | {j} => {rulestr(ars)}' for j,ars in enumerate(graph)]+['  | _ => none']
    if id=='!':
       ls+=[f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := by','  intro he','  obtain ⟨k,hk⟩ := rawCount he',
            f'  exact emptyClock (G := graph) (z := {z}) (by decide) hk ((correct graph {nm} (fun _ => []) {z}).mp (by decide))']
    else:
       cc,m,rr,aa,t,u,ps,qs=get(s,id);params=' '.join(map(expr,(cc,m,rr)))+' '+natlist(map(expr,aa))
       ls+=[f'private def env (i : Nat) : List (Fin {n}) := if i=1 then {natlist(c)} else {natlist(r)}','private def endpoint : Term := '+expr(t),'private def target : Term := '+expr(u),f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := by',
          f'  apply MultiTypes.excluded graph env (z := {z}) (t := endpoint) (u := target) (c := {expr(cc)}) (m := {expr(m)}) (r := {expr(rr)}) (aa := {natlist(map(expr,aa))}) (by decide)',
          f'  · exact replay_sound (t := call {nm} {params}) (ps := {paths(ps)}) (by decide)',f'  · exact replay_sound (t := want {params}) (ps := {paths(qs)}) (by decide)','  · decide','  · decide','  · decide']
    ls+=['#print axioms ex_'+nm,'end '+ns];(HERE/(mod+'.lean')).write_text('\n'.join(ls)+'\n')
    mani[s]=dict(kind='intersection_types',module=mod,theorem=ns+'.ex_'+nm,term=ns+'.'+nm,proof_graph=graph,continuation_types=c,remainder_types=r,token=z,layout=id)
 (HERE/'types-manifest.json').write_text(json.dumps(mani,separators=(',',':')))
if __name__=='__main__':main()
