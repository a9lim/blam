import H45Literals
import H45F9692402989698
import H45F9692715709398
import H45F9692869766666
import H45TraceFinal
namespace Blc.H45
theorem ex_e9692402989698 : ¬ IsSelfInterpreter e9692402989698 := H45F9692402989698.excluded
#print axioms ex_e9692402989698
theorem ex_e9692715709398 : ¬ IsSelfInterpreter e9692715709398 := H45F9692715709398.excluded
#print axioms ex_e9692715709398
theorem ex_e9692869766666 : ¬ IsSelfInterpreter e9692869766666 := H45F9692869766666.excluded
#print axioms ex_e9692869766666
theorem ex_e11219262979426 : ¬ IsSelfInterpreter e11219262979426 := Trace.ex_e11219262979426
#print axioms ex_e11219262979426
end Blc.H45
