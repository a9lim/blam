"""Check non-identity source projections and probe the raw lambda with rigid heads."""
from observed import material,symbols,lc,I,KI,K,V,A,L,om,expr,appall,observe,HERE
from itertools import product
import json
def go(s):
 e=lc.decode(s)[0];C=V(1);R=V(0)
 programs=[K,KI,om[1],L(L(A(V(0),V(1)))),L(L(A(V(1),V(0)))),L(L(L(V(2)))),L(A(V(0),KI))]
 controls=[C,K,KI,L(L(A(V(1),V(0)))),L(L(A(V(0),V(1)))),L(L(A(V(1),KI))),L(L(A(A(V(1),V(0)),I))),L(L(A(V(0),KI)))]
 cases=[];ends=0;hit=None
 for m,c,mode in product(programs,controls,range(3)):
  r,aa=[(R,[]),(om,[KI,K]),(L(L(R)),[om,I])][mode]
  goal,k=observe(appall(A(A(c,L(m)),r),aa),400)
  if not goal:continue
  x,j=observe(appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa),8000)
  cases.append(j);ends+=x is not None
  if x is not None and goal!=x:hit=[lc.enc(c),lc.enc(m),lc.enc(r),list(map(lc.enc,aa)),x,goal,j,k];break
 raw=[observe(e,30000),observe(A(e,C),30000),observe(A(e,KI),30000)]
 return dict(calls=len(cases),exits=ends,max_steps=max(cases),mismatch=hit,raw_and_prefix=raw)
if __name__=='__main__':
 rows={}
 for s in (HERE/'unresolved.txt').read_text().split():
  rows[s]=go(s)
  (HERE/'pending-probes.json').write_text(json.dumps(rows,indent=1)+'\n')
 print([(r['calls'],r['exits'],r['mismatch']) for r in rows.values()])
