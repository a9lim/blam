import hashlib,json,re,collections
from pathlib import Path
from package_partial import selected
D=Path(__file__).resolve().parent
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def compare():
 stats=collections.Counter();bad=[];missing=[];good={}
 for f in selected()[0]:
  src=D/f;test=D/'.slim-test'/f;k=re.split(r'\d|\.',f)[0]
  if not test.exists():missing.append(f);continue
  if digest(src)!=digest(test):
   bad.append(f);stats[k,'different']+=1
  else:good[f]=digest(src);stats[k,'same']+=1
 print('mismatches',collections.Counter(re.split(r'\d|\.',f)[0] for f in bad))
 print('missing Lean',collections.Counter(re.split(r'\d|\.',f)[0] for f in missing if f.endswith('.lean')))
 (D/'.slim-test'/'comparison.json').write_text(json.dumps([bad,missing,good]))
if __name__=='__main__':compare()
