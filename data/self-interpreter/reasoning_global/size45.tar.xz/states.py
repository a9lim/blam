from candidates import *
from inventory_summary import live,apps_spine
from collections import defaultdict
import csv
by=defaultdict(Counter);sh=Counter();n=Counter()
for wireline in open(HERE/'wires.txt'):
 t=lc.decode(wireline.strip())[0];l,v,x=counts(t);rt='literal' if t[0]=='L' else 'app'
 by[l,v,x][rt]+=1;n[rt,live(t)]+=1
 h,aa=apps_spine(t[1] if rt=='literal' else t);sh[rt,h[0],''.join(a[0] for a in aa)]+=1
with open(HERE/'triples.tsv','w') as f:
 f.write('L\tV\tX\tclosed_at_roots\tstructural\tapp\tliteral\n')
 for ln in open(HERE/'enum.log'):
  l,v,x,c,st,k=map(int,ln.split());a,b=by[l,v,x]['app'],by[l,v,x]['literal'];assert a+b==k
  f.write(f'{l}\t{v}\t{x}\t{c}\t{st}\t{a}\t{b}\n')
print('live',sorted(n.items()),'spines',sorted(sh.items()))
