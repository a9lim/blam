from genlean import *
from collections import defaultdict
wires=sorted((HERE/'wires.txt').read_text().split());shard={s:i//160 for i,s in enumerate(wires)}
early=set(json.loads((HERE/'extra.json').read_text()))|{format(int(p.stem[1:]),'045b') for p in HERE.glob('x[0-9]*.json')}
specs=defaultdict(list)
for l in open(HERE/'algebra-witnesses.txt'):
    s,n,lo,tab,m,mode,c,r=l.split()
    if s not in early:
        assert mode=='0'
        specs[(int(n),int(lo),tab,m,int(c),int(r))].append(s)
def natlist(xs):return '['+','.join(map(str,xs))+']'
targets={}
def mk():
    grouped=defaultdict(list)
    lines=[]
    for i,((n,lo,tab,m,c,r),rows) in enumerate(sorted(specs.items())):
        op=[list(map(int,tab[j:j+n])) for j in range(0,n*n,n)]
        def pick(f):return next(k for k in range(lo,n) if all(v<=w for v,w in zip(f,op[k])))
        @lru_cache(None)
        def val(t,env):
            if t[0]=='V':return env[t[1]]
            if t[0]=='A':return op[val(t[1],env)][val(t[2],env)]
            return pick([val(t[1],(x,)+env) for x in range(n)])
        bit=[L(L(V(1))),L(L(V(0)))]
        def cell(bitval,tail):return pick([op[op[x][bitval]][tail] for x in range(n)])
        pre='M'+str(i);env=f'(rho (n := {n-1}) {c} {r})'
        ls=[f'def op{pre} (i j : Fin {n}) : Fin {n} := match i.val,j.val with']
        ls += [f'  | {x},{y} => {op[x][y]}' for x in range(n) for y in range(n) if op[x][y]!=n-1]
        ls += [f'  | _,_ => {n-1}',f'def g{pre} : Algebra {n-1} := ⟨op{pre},{lo},by decide,by decide,by decide⟩']
        base=f'Typed g{pre} {env}'
        for b in (0,1):
            q=val(bit[b],())
            ls.append(f'private theorem b{pre}_{b} : {base} (churchBit {str(bool(b)).lower()}) {q} := typed_eval _ _')
        ls.append(f'private theorem s{pre}_0 : {base} (streamOf [] (.var 0)) {r} := .var _ _ (Nat.le_refl _)')
        suff=[];q=r
        for j,b in enumerate(reversed(m),1):
            b=int(b);suff.insert(0,str(bool(b)).lower());q=cell(val(bit[b],()),q)
            ls.append(f'private theorem s{pre}_{j} : {base} (streamOf {natlist(suff)} (.var 0)) {q} := pairGrade b{pre}_{b} s{pre}_{j-1} (by decide) (by decide)')
        mt=lc.decode(m)[0];dst=op[op[c][val(L(mt),())]][r]
        for z in range(n):
            if op[op[z][c]][q]>=dst:continue
            ls.append(f'theorem cut{pre}_{z} {{t : Term}} (hv : eval g{pre} {env} t = {z}) : ¬ IsSelfInterpreter t := by\n  intro he\n  have hz := necessary g{pre} (m := {expr(mt)}) (by decide) (by decide) s{pre}_{len(m)} he hv\n  exact (by decide : ¬ eval g{pre} {env} (.app (.app (.var 1) (.lam {expr(mt)})) (.var 0)) ≤ op{pre} (op{pre} {z} {c}) {q}) hz')
        for s in rows:
            z=val(lc.decode(s)[0],());assert op[op[z][c]][q]<dst
            nm='e'+str(int(s,2));mod=f'Grades{shard[s]:03}'
            grouped[shard[s]].append(f'theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := cut{pre}_{z} (by decide)\n#print axioms ex_{nm}')
            targets[s]=dict(module=mod,theorem='Blc.Floor45.'+mod+'.ex_'+nm,table=tab,source=m,continuation_grade=c,remainder_grade=r,program_grade=z)
        lines.extend(ls)
    hdr='open Term SelfintLowerBound SelfintControl ChainModel\nset_option maxRecDepth 30000\nset_option maxHeartbeats 5000000\n'
    (HERE/'Tables.lean').write_text('import ChainModel\nnamespace Blc.Floor45.Grades\n'+hdr+'\n'.join(lines)+'\nend Blc.Floor45.Grades\n')
    for i,ss in grouped.items():
        mod=f'Grades{i:03}'
        (HERE/(mod+'.lean')).write_text(f'import Tables\nimport Batch{i:03}\nnamespace Blc.Floor45.{mod}\nopen Grades\n'+hdr+'\n'.join(ss)+f'\nend Blc.Floor45.{mod}\n')
    (HERE/'model.json').write_text(json.dumps(targets))
if __name__=='__main__':mk()
