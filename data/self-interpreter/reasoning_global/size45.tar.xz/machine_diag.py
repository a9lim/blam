from probes import *
from harder import remain
from collections import Counter
def observe(t,cap=12000):
 nodes=[]
 def c(t,d):
    i=len(nodes);nodes.append(None)
    if t[0]=='V':node=('v',t[1]) if t[1]<d else ('m',t[1]-d)
    elif t[0]=='L':node=('l',c(t[1],d+1))
    else:node=('a',c(t[1],d),c(t[2],d))
    nodes[i]=node;return i
 c(t,0);p=0;env=();st=[]
 for j in range(cap):
    ty,*args=nodes[p]
    if ty=='a':st.append((args[1],env));p=args[0]
    elif ty=='l':
       if not st:return ('l',0),j
       env=(st.pop(),)+env;p=args[0]
    elif ty=='m':return (args[0],len(st)),j
    else:p,env=env[args[0]]
 return None,cap
if __name__=='__main__':
 rows={};summary=Counter()
 for s in remain():
    e=lc.decode(s)[0];seen,steps=observe(e);summary['raw whnf' if seen else 'raw cap']+=1
    hits=[];exits=0
    for i,(c,m,r,aa) in enumerate(symbols()):
       target=appall(A(A(c,L(m)),r),aa);t=appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)
       want,_=observe(target,600);got,k=observe(t,1600)
       if got:exits+=1
       if got is not None and want is not None and got!=want:hits.append((i,k,got,want))
    if hits:summary['positive mismatch']+=1
    rows[s]={'raw':[seen,steps],'probe_exits':exits,'mismatches':hits}
 (HERE/'hard-observations.json').write_text(json.dumps(rows));print(summary)
