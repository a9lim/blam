"""Read accepted kernel logs and emit the standalone per-wire localized proof manifest."""
from pathlib import Path
import json,re,csv
D=Path(__file__).resolve().parent
def main():
 obs=json.loads((D/'pending-probes.json').read_text());rows=[]
 for s,r in obs.items():
  if not r['mismatch']:continue
  m='PendingObserve'+str(int(s,2));th='Blc.Floor45.'+m+'.excluded'
  log=(D/'.checked'/(m+'.log')).read_text()
  ax=re.search(re.escape("'"+th+"' depends on axioms: [")+r'([^\]]+)\]',log).group(1)
  assert set(ax.split(', '))=={'propext','Quot.sound'}
  rows.append([s,m+'.lean',th,'¬ Blc.IsSelfInterpreter Blc.Floor45.e'+str(int(s,2)),ax])
 with (D/'pending-observe-manifest.tsv').open('w') as f:
  wr=csv.writer(f,delimiter='\t',lineterminator='\n');wr.writerow(['wire','file','theorem','statement','axioms']);wr.writerows(rows)
if __name__=='__main__':main()
