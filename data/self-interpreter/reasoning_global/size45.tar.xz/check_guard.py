"""Exercise queue draining and the isolated retry with a simulated RSS reading."""
import os,tempfile
from types import SimpleNamespace
from unittest.mock import patch
from pathlib import Path
import recheck as r
def main():
 real=r.subprocess.Popen;wait4=os.wait4;live=set();attempts=[];flagged=None
 def popen(argv,*a,**kw):
  p=real(argv,*a,**kw);m=Path(argv[-3]).stem
  attempts.append((m,len(live)));live.add(p.pid)
  return p
 def wait(pid,mode):
  v=wait4(pid,mode)
  if v[0]:live.discard(v[0])
  return v
 def rss(pid):
  nonlocal flagged
  if flagged is None:flagged=pid
  return 990000000 if pid==flagged else 0
 with tempfile.TemporaryDirectory(dir=r.D) as td,patch.object(r.subprocess,'Popen',popen),patch.object(r.os,'wait4',wait),patch.object(r,'resident',rss):
  args=SimpleNamespace(stage=td,modules=['Aggregate','H44Base'],seconds=45,jobs=2)
  assert r.run(args)==0
  assert len(attempts)==3 and attempts[-1][0] in [m for m,_ in attempts[:2]] and attempts[-1][1]==0,attempts
 print('The simulated guard fired; the full worker pool drained before a successful isolated retry.')
if __name__=='__main__':main()
