"""Assemble standalone syntactic definitions from the repository's discovery sources."""
import ast
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];F=R/'data/self-interpreter/reasoning_162/floor38';T=R/'tools/self-interpreter/theory/floor37';A=R/'data/self-interpreter/reasoning_weight/archive/certgen'
def get(p,names):
 s=p.read_text();nodes={n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 return '\n\n'.join(ast.get_source_segment(s,nodes[n]) for n in names)+'\n'
def main():
 from shutil import copyfile
 copyfile(R/'tools/self-interpreter/lc.py',D/'archive_lc.py')
 s='from pathlib import Path\nfrom collections import Counter\nfrom functools import lru_cache\nimport sys,json\nimport archive_lc as lc\nHERE=Path(__file__).resolve().parent\nROOT=HERE\nV=lambda n: ("V",n)\nL=lambda b: ("L",b)\nA=lambda f,a: ("A",f,a)\nI=L(V(0));KI=L(I)\n'
 s+=get(T/'verify.py',['occ','nonlinear','free','width','chain','counts'])
 s+=get(T/'check35.py',['spine'])
 s+=get(F/'exact_probe.py',['head_path','at','red','simp_path'])
 s+=get(F/'size38.py',['subpaths'])
 s+=get(F/'smart_probe.py',['weak_path','apps_spine','appall'])
 s+='from grammar import b,w\nCAP=800\n'
 s+=get(D/'candidates.py',['wire','bounded','normal_path','measure','sourcefact'])
 (D/'archive_core.py').write_text(s)
 (D/'archive_regular.py').write_text(get(A/'aam.py',['compile_term']))
if __name__=='__main__':main()
