from typesat import *
from machine_diag import observe
from hashlib import sha256
def candidates(s):
 ps=json.loads((HERE/'peel'/(s+'.json')).read_text())
 if ps[0]!='unknown':return []
 # Prefer the smallest genuinely unobserved prefixes, then other control sites.
 good=[];seen=set()
 for opt in ps[1]:
    k,j,ar,bits=opt
    if bits in seen:continue
    seen.add(bits)
    t=lc.decode(bits)[0];h,steps=observe(t,1000)
    if h is None:good.append(opt)
 return good
def main():
 out=HERE/'peeled';out.mkdir(exist_ok=True);work=out/'work';work.mkdir(exist_ok=True)
 ss=[s for s in remain() if (HERE/'peel'/(s+'.json')).exists()]
 cand={s:candidates(s) for s in ss}
 print('unknown prefixes',[len(cand[s]) for s in ss],flush=True)
 cache={};n,m,sec=map(int,sys.argv[1:])
 for i in range(10):
    for s in ss:
       dest=out/(s+'.json')
       if dest.exists() or i>=len(cand[s]):continue
       opt=cand[s][i];t=lc.decode(opt[-1])[0];bits=opt[-1]
       if bits not in cache:cache[bits]=synth(work,n,m,t,None,True,sec)
       if z:=cache[bits]:dest.write_text(json.dumps([opt,*z]))
if __name__=='__main__':main()
