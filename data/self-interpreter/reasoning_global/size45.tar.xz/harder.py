from pathlib import Path
d=Path(__file__).resolve().parent
def remain():
 seen={s.split()[0] for k in ['probes','hardprobe'] for p in (d/k).glob('*.out') for s in p.read_text().splitlines()}
 for p in [*d.glob('r[0-9]*.json'),*d.glob('h[0-9]*.json')]:seen.add(f'{int(p.stem[1:]):045b}')
 for p in d.glob('hardraw*.out'):seen.update(s.split()[0] for s in p.read_text().splitlines())
 for dn in ['late','sat','sat2','abstract','newreg','seen','factors']:
  for p in (d/dn).glob('*.json'):seen.add(p.stem)
 for p in (d/'clock').glob('*.out'):
  if p.stat().st_size:seen.add(p.stem)
 return sorted(set((d/'after_quick.in').read_text().split())-seen)
if __name__=='__main__':print('\n'.join(remain()))
