"""Reproduce three enumerations and the exact substitution comparison, in bounded jobs."""
import concurrent.futures as cf,hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
D=Path(__file__).resolve().parent
AUD=D
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 start=time.monotonic();metrics=[]
 with tempfile.TemporaryDirectory(dir=D) as td:
    td=Path(td)
    def run(label,cmd,out,inp=None,limit=460):
       ts=time.monotonic();log=td/(label+'.log')
       with out.open('wb') as fout,log.open('wb') as err,(inp or Path(os.devnull)).open('rb') as fin:
          p=subprocess.Popen(cmd,stdout=fout,stderr=err,stdin=fin,cwd=D)
          while True:
             pid,st,u=os.wait4(p.pid,os.WNOHANG)
             if pid:break
             if time.monotonic()-ts>limit:p.kill()
             time.sleep(.15)
          p.returncode=os.waitstatus_to_exitcode(st)
       assert p.returncode==0,(label,log.read_text()[-1000:])
       assert u.ru_maxrss<1_000_000_000
       metrics.append(dict(step=label,seconds=round(time.monotonic()-ts,3),rss_bytes=u.ru_maxrss));return log.read_text()
    def check(item):
       name,cmd,args,expected=item;exe=td/name;out=td/(name+'.out')
       run('compile-'+name,[*cmd,'-o',str(exe)],td/(name+'.compile'))
       msg=run(name,[str(exe),*args],out)
       assert sha(out)==sha(D/expected)
       if name=='cross':assert '2933097201 closed, 3184752 structurally admissible' in msg
       if name=='broad':assert 'closed terms 2933097201; incomparable nonlinear pair 139132360; and width 3: 9382936; and no shrinking contraction 1933272' in msg
       return out
    tasks=[('triple',['c++','-O3','-std=c++20','enum.cpp'],[],'wires.txt'),('cross',['rustc','--edition=2021','-O','archive_cross.rs'],[],'cross.txt'),('broad',['cc','-O3','-x','c',str(AUD/'archive_broad.cpp')],['45'],'broad.txt')]
    with cf.ThreadPoolExecutor(max(1,min(4,int(sys.argv[1]) if len(sys.argv)>1 else 3))) as pool:triple,cross,broad=list(pool.map(check,tasks))
    sub=td/'contracts';run('compile-sub',['rustc','--edition=2021','-O','check_contractions.rs','-o',str(sub)],td/'sub.compile')
    run('contractions',[str(sub),str(triple)],td/'equal',cross)
    assert '3184752 structural wires, 427114 retained, exact set equality' in (td/'equal').read_text()
    run('broad-compare',[sys.executable,'-B',str(AUD/'compare.py'),str(broad),str(triple)],td/'bcompare')
    assert 'COMPLETE' in (td/'bcompare').read_text() and 'enumerator 341738, lane 341738' in (td/'bcompare').read_text()
 (D/'inventory-metrics.json').write_text(json.dumps(dict(wall_seconds=round(time.monotonic()-start,2),steps=metrics),indent=1)+'\n')
 print('Three inventories agree. 427114 exact candidates, 22492 with six live binders (see triples.tsv and root-shapes.tsv).')
if __name__=='__main__':main()
