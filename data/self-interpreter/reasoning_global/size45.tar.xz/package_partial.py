"""Write the exact repository pack.py selection into a lane-local partial archive."""
from pathlib import Path
import json,tarfile,re,sys,hashlib,os
from jsonstream import ledger
D=Path(__file__).resolve().parent
def selected():
 mods=set()
 def visit(m):
  if m in mods:return
  mods.add(m);p=D/(m+'.lean')
  for dep in re.findall(r'^import ([\w.]+)',p.read_text(),re.M):
   if (D/(dep+'.lean')).is_file():visit(dep)
 for m in sorted({r['module'] for r in ledger(D/'ledger.json')}|{'Residuals'}):visit(m)
 names={m+'.lean' for m in mods}
 names.update(p.name for p in D.iterdir() if p.is_file() and p.suffix in {'.py','.cpp','.rs','.json','.txt','.tsv','.md','.in'} and p.name!='build.jsonl')
 return sorted(names),len(mods)
def main():
 names,n=selected()
 print(n,'proof modules;',len(names),'archive members',flush=True)
 if '--write' not in sys.argv:return
 name=D/'size45-partial.tar.xz';tmp=name.with_suffix('.tmp')
 with tarfile.open(tmp,'w:xz',preset=2) as tf:
  for f in names:
   src=D/f;info=tarfile.TarInfo(f);info.size=src.stat().st_size;info.mode=0o644
   with src.open('rb') as fh:tf.addfile(info,fh)
 tmp.replace(name)
 with name.open('rb') as fh:print(name.name,name.stat().st_size,hashlib.file_digest(fh,'sha256').hexdigest())
if __name__=='__main__':main()
