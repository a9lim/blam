from regscan import *
ss=(HERE/'after_quick.in').read_text().split()
for s in ss[int(sys.argv[1])::int(sys.argv[2])]:
  pr=HERE/('r'+str(int(s,2))+'.json')
  if pr.exists():continue
  r=search(s,0)
  if r:pr.write_text(json.dumps(r))
