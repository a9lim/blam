from regular40 import *
from itertools import product
import time
def search(s, group):
    e=lc.decode(s)[0]
    kinds=['raw','rigid','apply','extra1','extra2','extra3','poison','value','suffix','extra4','extra5','extra6']
    start=time.monotonic()
    for k,m in [(0,'site'),(1,'argenv'),(2,'argenv'),(1,'site'),(2,'site'),(3,'env'),(3,'argenv')]:
        for kind,j in product(kinds,[0,2,4,8] if group else [0]):
            if time.monotonic()-start > (5 if group else .65):return
            t=probeType(e,kind);ps=[]
            for _ in range(j):
                p=weak_path(t)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps.append(p)
            if t is None or len(ps)!=j:continue
            try:z=regular.discover(mask(t),k,cap=2300,seconds=.025,mode=m)
            except regular.Limit:continue
            if z['ok'] and z['states']<600:
                c=portable.portable(z)
                return [len(c['states']),kind,j,k,m,ps,c]
if __name__=='__main__':
    group=int(sys.argv[1]); start=int(sys.argv[2]); step=int(sys.argv[3])
    for s in (HERE/'rem.txt').read_text().split()[start::step]:
        dest=HERE/('r'+str(int(s,2))+'.json')
        if dest.exists():continue
        if z:=search(s,group):
            dest.write_text(json.dumps(z))
            print(s,z[:5],flush=True)
