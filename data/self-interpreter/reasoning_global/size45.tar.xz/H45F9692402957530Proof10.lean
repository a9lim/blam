import H45F9692402957530Proof9
namespace Blc.H45.H45F9692402957530
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h360 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s45 (ρ 1)) : All tab ρ b22 s57 :=
  (consAll (lamAt d90 c90 (smaller (h190 (Types.cons s45 ρ) sub151 a0 a1) sub5)) Positive.none)
theorem h361 (ρ : Env) (a0 : Fits s32 (ρ 0)) (a1 : Fits s7 (ρ 1)) : All tab ρ b22 s44 :=
  (consAll (lamAt d150 c150 (smaller (h191 (Types.cons s7 ρ) sub7 a0 a1) sub126)) Positive.none)
theorem h362 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b22 s65 :=
  (consAll (lamAt d116 c116 (smaller (h192 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d264 c264 (smaller (h215 (Types.cons s84 ρ) sub118 a0 a1) sub5)) Positive.none))
theorem h363 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b22 s68 :=
  (consAll (lamAt d116 c116 (smaller (h192 (Types.cons s11 ρ) sub5 a0 a1) sub5)) Positive.none)
theorem h364 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s7 (ρ 1)) : All tab ρ b22 s44 :=
  (consAll (lamAt d150 c150 (smaller (h193 (Types.cons s7 ρ) sub7 a0 a1) sub126)) Positive.none)
theorem h365 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s24 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h195 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h196 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h202 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h208 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h216 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h233 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h245 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h265 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h286 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h340 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h366 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s29 (ρ 1)) : All tab ρ b22 s25 :=
  (consAll (lamAt d180 c180 (smaller (h197 (Types.cons s29 ρ) sub152 a0 a1) sub128)) Positive.none)
theorem h367 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s55 (ρ 1)) : All tab ρ b22 s75 :=
  (consAll (lamAt d181 c181 (smaller (h198 (Types.cons s55 ρ) sub153 a0 a1) sub125)) Positive.none)
theorem h368 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s76 (ρ 1)) : All tab ρ b22 s41 :=
  (consAll (lamAt d187 c187 (smaller (h199 (Types.cons s76 ρ) sub154 a0 a1) sub125)) Positive.none)
theorem h369 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s29 (ρ 1)) : All tab ρ b22 s25 :=
  (consAll (lamAt d180 c180 (smaller (h200 (Types.cons s29 ρ) sub152 a0 a1) sub128)) Positive.none)
theorem h370 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s48 (ρ 1)) : All tab ρ b22 s60 :=
  (consAll (lamAt d132 c132 (smaller (h201 (Types.cons s48 ρ) sub105 a0 a1) sub5)) Positive.none)
theorem h371 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s78 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h204 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h205 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h206 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h210 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h218 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h231 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h243 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h263 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h284 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h338 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h372 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s71 (ρ 1)) : All tab ρ b22 s80 :=
  (consAll (lamAt d213 c213 (smaller (h207 (Types.cons s71 ρ) sub107 a0 a1) sub130)) Positive.none)
theorem h373 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s58 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h211 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h212 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h213 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h214 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h219 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h232 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h244 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h264 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h285 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h339 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h374 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s84 (ρ 1)) : All tab ρ b22 s65 :=
  (consAll (lamAt d116 c116 (smaller (h221 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d264 c264 (smaller (h220 (Types.cons s84 ρ) sub118 a0 a1) sub5)) Positive.none))
theorem h375 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s71 (ρ 1)) : All tab ρ b22 s80 :=
  (consAll (lamAt d213 c213 (smaller (h222 (Types.cons s71 ρ) sub107 a0 a1) sub130)) Positive.none)
theorem h376 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s81 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h223 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h224 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h225 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h226 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h227 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h234 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h246 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h266 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h287 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h341 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h377 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s70 (ρ 1)) : All tab ρ b22 s85 :=
  (consAll (lamAt d165 c165 (smaller (h228 (Types.cons s70 ρ) sub109 a0 a1) sub5)) Positive.none)
theorem h378 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s70 (ρ 1)) : All tab ρ b22 s85 :=
  (consAll (lamAt d165 c165 (smaller (h229 (Types.cons s70 ρ) sub109 a0 a1) sub5)) Positive.none)
theorem h379 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s61 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h235 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h236 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h237 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h238 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h240 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h239 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h247 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h267 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h288 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h342 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h380 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b22 s68 :=
  (consAll (lamAt d116 c116 (smaller (h241 (Types.cons s11 ρ) sub5 a0 a1) sub5)) Positive.none)
theorem h381 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b22 s65 :=
  (consAll (lamAt d116 c116 (smaller (h241 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d264 c264 (smaller (h248 (Types.cons s84 ρ) sub118 a0 a1) sub5)) Positive.none))
theorem h382 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s63 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h250 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h251 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h252 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h253 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h255 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h254 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h249 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h261 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h282 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h335 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h383 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s84 (ρ 1)) : All tab ρ b22 s65 :=
  (consAll (lamAt d116 c116 (smaller (h256 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d264 c264 (smaller (h257 (Types.cons s84 ρ) sub118 a0 a1) sub5)) Positive.none))
theorem h384 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s48 (ρ 1)) : All tab ρ b22 s60 :=
  (consAll (lamAt d132 c132 (smaller (h258 (Types.cons s48 ρ) sub105 a0 a1) sub5)) Positive.none)
theorem h385 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s71 (ρ 1)) : All tab ρ b22 s80 :=
  (consAll (lamAt d213 c213 (smaller (h259 (Types.cons s71 ρ) sub107 a0 a1) sub130)) Positive.none)
theorem h386 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s70 (ρ 1)) : All tab ρ b22 s85 :=
  (consAll (lamAt d165 c165 (smaller (h260 (Types.cons s70 ρ) sub109 a0 a1) sub5)) Positive.none)
theorem h387 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s89 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h270 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h271 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h272 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h273 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h275 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h274 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h269 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h268 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h281 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h334 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h388 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s79 (ρ 1)) : All tab ρ b22 s91 :=
  (consAll (lamAt d116 c116 (smaller (h279 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d299 c299 (smaller (h276 (Types.cons s79 ρ) sub110 a0 a1) sub5)) Positive.none))
theorem h389 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s79 (ρ 1)) : All tab ρ b22 s91 :=
  (consAll (lamAt d116 c116 (smaller (h280 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d299 c299 (smaller (h277 (Types.cons s79 ρ) sub110 a0 a1) sub5)) Positive.none))
theorem h390 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b22 s91 :=
  (consAll (lamAt d116 c116 (smaller (h192 (Types.cons s11 ρ) sub5 a0 a1) sub5)) (consAll (lamAt d299 c299 (smaller (h278 (Types.cons s79 ρ) sub110 a0 a1) sub5)) Positive.none))
theorem h391 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s92 (ρ 1)) : All tab ρ b22 s50 :=
  (consAll (lamAt d118 c118 (smaller (h291 (Types.cons s46 ρ) sub141 a0 a1) sub125)) (consAll (lamAt d185 c185 (smaller (h292 (Types.cons s24 ρ) sub142 a0 a1) sub125)) (consAll (lamAt d230 c230 (smaller (h293 (Types.cons s78 ρ) sub143 a0 a1) sub125)) (consAll (lamAt d245 c245 (smaller (h294 (Types.cons s58 ρ) sub144 a0 a1) sub125)) (consAll (lamAt d272 c272 (smaller (h297 (Types.cons s81 ρ) sub145 a0 a1) sub125)) (consAll (lamAt d278 c278 (smaller (h296 (Types.cons s61 ρ) sub146 a0 a1) sub125)) (consAll (lamAt d298 c298 (smaller (h290 (Types.cons s63 ρ) sub147 a0 a1) sub125)) (consAll (lamAt d320 c320 (smaller (h289 (Types.cons s89 ρ) sub148 a0 a1) sub125)) (consAll (lamAt d335 c335 (smaller (h295 (Types.cons s92 ρ) sub149 a0 a1) sub125)) (consAll (lamAt d366 c366 (smaller (h337 (Types.cons s87 ρ) sub150 a0 a1) sub125)) Positive.none))))))))))
theorem h392 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s86 (ρ 1)) : All tab ρ b22 s96 :=
  (consAll (lamAt d315 c315 (smaller (h298 (Types.cons s86 ρ) sub108 a0 a1) sub5)) Positive.none)
theorem h393 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s86 (ρ 1)) : All tab ρ b22 s96 :=
  (consAll (lamAt d315 c315 (smaller (h299 (Types.cons s86 ρ) sub108 a0 a1) sub5)) Positive.none)
theorem h394 (ρ : Env) (a0 : Fits s86 (ρ 0)) (a1 : Fits s86 (ρ 1)) : All tab ρ b22 s96 :=
  (consAll (lamAt d315 c315 (smaller (h300 (Types.cons s86 ρ) sub108 a0 a1) sub5)) Positive.none)
theorem h395 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s51 (ρ 1)) : All tab ρ b22 s56 :=
  (consAll (lamAt d106 c106 (smaller (h301 (Types.cons s51 ρ) sub155 a0 a1) sub5)) Positive.none)
end Blc.H45.H45F9692402957530
