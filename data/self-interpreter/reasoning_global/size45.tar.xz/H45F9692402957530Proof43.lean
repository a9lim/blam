import H45F9692402957530Proof42
namespace Blc.H45.H45F9692402957530
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h1548 (ρ : Env) (a0 : Fits s68 (ρ 0)) (a1 : Fits s11 (ρ 1)) (a2 : Fits s79 (ρ 2)) (a3 : Fits s2 (ρ 3)) : All tab ρ b61 s136 :=
  appAll len123 d123 c123 sub125 ((h917 ρ a3) 123 mem326) (smaller (h1224 ρ a0 a1 a2) sub105)
theorem h1549 (ρ : Env) (a0 : Fits s68 (ρ 0)) (a1 : Fits s11 (ρ 1)) (a2 : Fits s11 (ρ 2)) (a3 : Fits s2 (ρ 3)) : All tab ρ b61 s136 :=
  appAll len123 d123 c123 sub125 ((h917 ρ a3) 123 mem326) (smaller (h1226 ρ a0 a1 a2) sub105)
theorem h1550 (ρ : Env) (a0 : Fits s1 (ρ 0)) (a1 : Fits s2 (ρ 1)) (a2 : Fits s3 (ρ 2)) : All tab ρ b62 s4 :=
  (consAll (lamAt d7 c7 (smaller (h1229 (Types.cons s5 ρ) sub183 a0 a1 a2) sub9)) (consAll (lamAt d19 c19 (smaller (h1231 (Types.cons s10 ρ) sub156 a0 a1 a2) sub4)) Positive.none))
theorem h1551 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s4 (ρ 1)) (a2 : Fits s8 (ρ 2)) : All tab ρ b62 s9 :=
  (consAll (lamAt d2 c2 (smaller (h1230 (Types.cons s0 ρ) sub324 a0 a1 a2) sub5)) Positive.none)
theorem h1552 (ρ : Env) (a0 : Fits s6 (ρ 0)) (a1 : Fits s0 (ρ 1)) (a2 : Fits s8 (ρ 2)) : All tab ρ b62 s9 :=
  (consAll (lamAt d2 c2 (smaller (h1232 (Types.cons s0 ρ) sub324 a0 a1 a2) sub5)) Positive.none)
theorem h1553 (ρ : Env) (a0 : Fits s13 (ρ 0)) (a1 : Fits s2 (ρ 1)) (a2 : Fits s14 (ρ 2)) : All tab ρ b62 s15 :=
  (consAll (lamAt d29 c29 (smaller (h1233 (Types.cons s16 ρ) sub184 a0 a1 a2) sub185)) (consAll (lamAt d34 c34 (smaller (h1235 (Types.cons s17 ρ) sub157 a0 a1 a2) sub4)) Positive.none))
theorem h1554 (ρ : Env) (a0 : Fits s12 (ρ 0)) (a1 : Fits s15 (ρ 1)) (a2 : Fits s8 (ρ 2)) : All tab ρ b62 s9 :=
  (consAll (lamAt d2 c2 (smaller (h1234 (Types.cons s0 ρ) sub324 a0 a1 a2) sub5)) Positive.none)
theorem h1555 (ρ : Env) (a0 : Fits s19 (ρ 0)) (a1 : Fits s2 (ρ 1)) (a2 : Fits s14 (ρ 2)) : All tab ρ b62 s20 :=
  (consAll (lamAt d41 c41 (smaller (h1236 (Types.cons s21 ρ) sub186 a0 a1 a2) sub187)) (consAll (lamAt d45 c45 (smaller (h1238 (Types.cons s22 ρ) sub158 a0 a1 a2) sub4)) Positive.none))
theorem h1556 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s20 (ρ 1)) (a2 : Fits s8 (ρ 2)) : All tab ρ b62 s9 :=
  (consAll (lamAt d2 c2 (smaller (h1237 (Types.cons s0 ρ) sub324 a0 a1 a2) sub5)) Positive.none)
theorem h1557 (ρ : Env) (a0 : Fits s6 (ρ 0)) (a1 : Fits s0 (ρ 1)) (a2 : Fits s23 (ρ 2)) : All tab ρ b62 s24 :=
  (consAll (lamAt d49 c49 (smaller (h1239 (Types.cons s25 ρ) sub169 a0 a1 a2) sub188)) (consAll (lamAt d135 c135 (smaller (h1279 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d183 c183 (smaller (h1273 (Types.cons s25 ρ) sub169 a0 a1 a2) sub385)) (consAll (lamAt d188 c188 (smaller (h1282 (Types.cons s77 ρ) sub378 a0 a1 a2) sub125)) (consAll (lamAt d211 c211 (smaller (h1273 (Types.cons s25 ρ) sub169 a0 a1 a2) sub382)) Positive.none)))))
theorem h1558 (ρ : Env) (a0 : Fits s33 (ρ 0)) (a1 : Fits s2 (ρ 1)) (a2 : Fits s14 (ρ 2)) : All tab ρ b62 s34 :=
  (consAll (lamAt d68 c68 (smaller (h1240 (Types.cons s35 ρ) sub159 a0 a1 a2) sub189)) (consAll (lamAt d78 c78 (smaller (h1242 (Types.cons s35 ρ) sub159 a0 a1 a2) sub160)) Positive.none))
theorem h1559 (ρ : Env) (a0 : Fits s2 (ρ 0)) (a1 : Fits s34 (ρ 1)) (a2 : Fits s37 (ρ 2)) : All tab ρ b62 s9 :=
  (consAll (lamAt d2 c2 (smaller (h1241 (Types.cons s0 ρ) sub324 a0 a1 a2) sub5)) Positive.none)
theorem h1560 (ρ : Env) (a0 : Fits s29 (ρ 0)) (a1 : Fits s0 (ρ 1)) (a2 : Fits s37 (ρ 2)) : All tab ρ b62 s24 :=
  (consAll (lamAt d49 c49 (smaller (h1243 (Types.cons s25 ρ) sub169 a0 a1 a2) sub188)) (consAll (lamAt d135 c135 (smaller (h1280 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d183 c183 (smaller (h1274 (Types.cons s25 ρ) sub169 a0 a1 a2) sub385)) (consAll (lamAt d188 c188 (smaller (h1283 (Types.cons s77 ρ) sub378 a0 a1 a2) sub125)) (consAll (lamAt d211 c211 (smaller (h1274 (Types.cons s25 ρ) sub169 a0 a1 a2) sub382)) Positive.none)))))
theorem h1561 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s2 (ρ 1)) (a2 : Fits s39 (ρ 2)) : All tab ρ b62 s40 :=
  (consAll (lamAt d83 c83 (smaller (h1244 (Types.cons s41 ρ) sub171 a0 a1 a2) sub5)) (consAll (lamAt d192 c192 (smaller (h1285 (Types.cons s41 ρ) sub171 a0 a1 a2) sub155)) Positive.none))
theorem h1562 (ρ : Env) (a0 : Fits s7 (ρ 0)) (a1 : Fits s32 (ρ 1)) (a2 : Fits s42 (ρ 2)) : All tab ρ b62 s43 :=
  (consAll (lamAt d89 c89 (smaller (h1245 (Types.cons s44 ρ) sub166 a0 a1 a2) sub5)) (consAll (lamAt d153 c153 (smaller (h1263 (Types.cons s44 ρ) sub166 a0 a1 a2) sub386)) (consAll (lamAt d170 c170 (smaller (h1263 (Types.cons s44 ρ) sub166 a0 a1 a2) sub387)) Positive.none)))
theorem h1563 (ρ : Env) (a0 : Fits s45 (ρ 0)) (a1 : Fits s7 (ρ 1)) (a2 : Fits s32 (ρ 2)) : All tab ρ b62 s46 :=
  (consAll (lamAt d95 c95 (smaller (h1246 (Types.cons s47 ρ) sub190 a0 a1 a2) sub191)) (consAll (lamAt d121 c121 (smaller (h1250 (Types.cons s57 ρ) sub164 a0 a1 a2) sub125)) (consAll (lamAt d135 c135 (smaller (h1254 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d136 c136 (smaller (h1256 (Types.cons s57 ρ) sub164 a0 a1 a2) sub388)) (consAll (lamAt d149 c149 (smaller (h1256 (Types.cons s57 ρ) sub164 a0 a1 a2) sub389)) Positive.none)))))
theorem h1564 (ρ : Env) (a0 : Fits s45 (ρ 0)) (a1 : Fits s7 (ρ 1)) (a2 : Fits s2 (ρ 2)) : All tab ρ b62 s46 :=
  (consAll (lamAt d95 c95 (smaller (h1247 (Types.cons s47 ρ) sub190 a0 a1 a2) sub191)) (consAll (lamAt d121 c121 (smaller (h1251 (Types.cons s57 ρ) sub164 a0 a1 a2) sub125)) (consAll (lamAt d135 c135 (smaller (h1255 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d136 c136 (smaller (h1257 (Types.cons s57 ρ) sub164 a0 a1 a2) sub388)) (consAll (lamAt d149 c149 (smaller (h1257 (Types.cons s57 ρ) sub164 a0 a1 a2) sub389)) Positive.none)))))
theorem h1565 (ρ : Env) (a0 : Fits s46 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s49 :=
  (consAll (lamAt d105 c105 (smaller (h1248 (Types.cons s50 ρ) sub161 a0 a1 a2) sub5)) (consAll (lamAt d119 c119 (smaller (h1249 (Types.cons s50 ρ) sub161 a0 a1 a2) sub155)) Positive.none))
theorem h1566 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s58 :=
  (consAll (lamAt d126 c126 (smaller (h1252 (Types.cons s59 ρ) sub192 a0 a1 a2) sub193)) (consAll (lamAt d130 c130 (smaller (h1253 (Types.cons s60 ρ) sub162 a0 a1 a2) sub163)) (consAll (lamAt d135 c135 (smaller (h1317 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d234 c234 (smaller (h1253 (Types.cons s60 ρ) sub162 a0 a1 a2) sub385)) (consAll (lamAt d265 c265 (smaller (h1324 (Types.cons s60 ρ) sub162 a0 a1 a2) sub125)) Positive.none)))))
theorem h1567 (ρ : Env) (a0 : Fits s45 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s46 :=
  (consAll (lamAt d95 c95 (smaller (h1258 (Types.cons s47 ρ) sub190 a0 a1 a2) sub191)) (consAll (lamAt d121 c121 (smaller (h1259 (Types.cons s57 ρ) sub164 a0 a1 a2) sub125)) (consAll (lamAt d135 c135 (smaller (h1261 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d136 c136 (smaller (h1260 (Types.cons s57 ρ) sub164 a0 a1 a2) sub388)) (consAll (lamAt d149 c149 (smaller (h1260 (Types.cons s57 ρ) sub164 a0 a1 a2) sub389)) Positive.none)))))
theorem h1568 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s61 :=
  (consAll (lamAt d135 c135 (smaller (h1338 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d147 c147 (smaller (h1262 (Types.cons s62 ρ) sub194 a0 a1 a2) sub195)) (consAll (lamAt d158 c158 (smaller (h1265 (Types.cons s65 ρ) sub167 a0 a1 a2) sub163)) (consAll (lamAt d275 c275 (smaller (h1265 (Types.cons s65 ρ) sub167 a0 a1 a2) sub385)) (consAll (lamAt d288 c288 (smaller (h1341 (Types.cons s65 ρ) sub167 a0 a1 a2) sub125)) (consAll (lamAt d308 c308 (smaller (h1265 (Types.cons s65 ρ) sub167 a0 a1 a2) sub382)) Positive.none))))))
theorem h1569 (ρ : Env) (a0 : Fits s11 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s63 :=
  (consAll (lamAt d135 c135 (smaller (h1338 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d157 c157 (smaller (h1264 (Types.cons s64 ρ) sub196 a0 a1 a2) sub197)) (consAll (lamAt d163 c163 (smaller (h1266 (Types.cons s68 ρ) sub168 a0 a1 a2) sub382)) (consAll (lamAt d295 c295 (smaller (h1266 (Types.cons s68 ρ) sub168 a0 a1 a2) sub385)) (consAll (lamAt d302 c302 (smaller (h1356 (Types.cons s68 ρ) sub168 a0 a1 a2) sub125)) Positive.none)))))
theorem h1570 (ρ : Env) (a0 : Fits s7 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s43 :=
  (consAll (lamAt d89 c89 (smaller (h1267 (Types.cons s44 ρ) sub166 a0 a1 a2) sub5)) (consAll (lamAt d153 c153 (smaller (h1268 (Types.cons s44 ρ) sub166 a0 a1 a2) sub386)) (consAll (lamAt d170 c170 (smaller (h1268 (Types.cons s44 ρ) sub166 a0 a1 a2) sub387)) Positive.none)))
theorem h1571 (ρ : Env) (a0 : Fits s29 (ρ 0)) (a1 : Fits s71 (ρ 1)) (a2 : Fits s2 (ρ 2)) : All tab ρ b62 s24 :=
  (consAll (lamAt d49 c49 (smaller (h1269 (Types.cons s25 ρ) sub169 a0 a1 a2) sub188)) (consAll (lamAt d135 c135 (smaller (h1278 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d183 c183 (smaller (h1275 (Types.cons s25 ρ) sub169 a0 a1 a2) sub385)) (consAll (lamAt d188 c188 (smaller (h1281 (Types.cons s77 ρ) sub378 a0 a1 a2) sub125)) (consAll (lamAt d211 c211 (smaller (h1275 (Types.cons s25 ρ) sub169 a0 a1 a2) sub382)) Positive.none)))))
theorem h1572 (ρ : Env) (a0 : Fits s55 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s73 :=
  (consAll (lamAt d176 c176 (smaller (h1270 (Types.cons s75 ρ) sub170 a0 a1 a2) sub5)) (consAll (lamAt d184 c184 (smaller (h1277 (Types.cons s75 ρ) sub170 a0 a1 a2) sub155)) Positive.none))
theorem h1573 (ρ : Env) (a0 : Fits s24 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s49 :=
  (consAll (lamAt d105 c105 (smaller (h1271 (Types.cons s50 ρ) sub161 a0 a1 a2) sub5)) (consAll (lamAt d119 c119 (smaller (h1272 (Types.cons s50 ρ) sub161 a0 a1 a2) sub155)) Positive.none))
theorem h1574 (ρ : Env) (a0 : Fits s76 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s40 :=
  (consAll (lamAt d83 c83 (smaller (h1276 (Types.cons s41 ρ) sub171 a0 a1 a2) sub5)) (consAll (lamAt d192 c192 (smaller (h1284 (Types.cons s41 ρ) sub171 a0 a1 a2) sub155)) Positive.none))
theorem h1575 (ρ : Env) (a0 : Fits s29 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s24 :=
  (consAll (lamAt d49 c49 (smaller (h1287 (Types.cons s25 ρ) sub169 a0 a1 a2) sub188)) (consAll (lamAt d135 c135 (smaller (h1288 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d183 c183 (smaller (h1286 (Types.cons s25 ρ) sub169 a0 a1 a2) sub385)) (consAll (lamAt d188 c188 (smaller (h1289 (Types.cons s77 ρ) sub378 a0 a1 a2) sub125)) (consAll (lamAt d211 c211 (smaller (h1286 (Types.cons s25 ρ) sub169 a0 a1 a2) sub382)) Positive.none)))))
theorem h1576 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s71 (ρ 1)) (a2 : Fits s2 (ρ 2)) : All tab ρ b62 s78 :=
  (consAll (lamAt d135 c135 (smaller (h1304 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d205 c205 (smaller (h1290 (Types.cons s80 ρ) sub172 a0 a1 a2) sub198)) (consAll (lamAt d227 c227 (smaller (h1298 (Types.cons s80 ρ) sub172 a0 a1 a2) sub385)) (consAll (lamAt d250 c250 (smaller (h1311 (Types.cons s83 ρ) sub379 a0 a1 a2) sub125)) (consAll (lamAt d276 c276 (smaller (h1298 (Types.cons s80 ρ) sub172 a0 a1 a2) sub163)) Positive.none)))))
theorem h1577 (ρ : Env) (a0 : Fits s71 (ρ 0)) (a1 : Fits s0 (ρ 1)) (a2 : Fits s37 (ρ 2)) : All tab ρ b62 s78 :=
  (consAll (lamAt d135 c135 (smaller (h1305 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d205 c205 (smaller (h1291 (Types.cons s80 ρ) sub172 a0 a1 a2) sub198)) (consAll (lamAt d227 c227 (smaller (h1299 (Types.cons s80 ρ) sub172 a0 a1 a2) sub385)) (consAll (lamAt d250 c250 (smaller (h1312 (Types.cons s83 ρ) sub379 a0 a1 a2) sub125)) (consAll (lamAt d276 c276 (smaller (h1299 (Types.cons s80 ρ) sub172 a0 a1 a2) sub163)) Positive.none)))))
theorem h1578 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s0 (ρ 1)) (a2 : Fits s37 (ρ 2)) : All tab ρ b62 s58 :=
  (consAll (lamAt d126 c126 (smaller (h1293 (Types.cons s59 ρ) sub192 a0 a1 a2) sub193)) (consAll (lamAt d130 c130 (smaller (h1292 (Types.cons s60 ρ) sub162 a0 a1 a2) sub163)) (consAll (lamAt d135 c135 (smaller (h1315 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d234 c234 (smaller (h1292 (Types.cons s60 ρ) sub162 a0 a1 a2) sub385)) (consAll (lamAt d265 c265 (smaller (h1322 (Types.cons s60 ρ) sub162 a0 a1 a2) sub125)) Positive.none)))))
theorem h1579 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s71 (ρ 1)) (a2 : Fits s2 (ρ 2)) : All tab ρ b62 s58 :=
  (consAll (lamAt d126 c126 (smaller (h1295 (Types.cons s59 ρ) sub192 a0 a1 a2) sub193)) (consAll (lamAt d130 c130 (smaller (h1294 (Types.cons s60 ρ) sub162 a0 a1 a2) sub163)) (consAll (lamAt d135 c135 (smaller (h1316 (Types.cons s48 ρ) sub105 a0 a1 a2) sub115)) (consAll (lamAt d234 c234 (smaller (h1294 (Types.cons s60 ρ) sub162 a0 a1 a2) sub385)) (consAll (lamAt d265 c265 (smaller (h1323 (Types.cons s60 ρ) sub162 a0 a1 a2) sub125)) Positive.none)))))
theorem h1580 (ρ : Env) (a0 : Fits s78 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s49 :=
  (consAll (lamAt d105 c105 (smaller (h1297 (Types.cons s50 ρ) sub161 a0 a1 a2) sub5)) (consAll (lamAt d119 c119 (smaller (h1296 (Types.cons s50 ρ) sub161 a0 a1 a2) sub155)) Positive.none))
theorem h1581 (ρ : Env) (a0 : Fits s58 (ρ 0)) (a1 : Fits s48 (ρ 1)) (a2 : Fits s7 (ρ 2)) : All tab ρ b62 s49 :=
  (consAll (lamAt d105 c105 (smaller (h1301 (Types.cons s50 ρ) sub161 a0 a1 a2) sub5)) (consAll (lamAt d119 c119 (smaller (h1300 (Types.cons s50 ρ) sub161 a0 a1 a2) sub155)) Positive.none))
end Blc.H45.H45F9692402957530
