from regular40 import *
from searchprobes import target_steps,appall
def details(kind):
    aa=[];m=I
    if kind=='rigid':c,r=C,R
    elif kind.startswith('extra'):c,r=KI,R;aa=[om]*int(kind[5:])
    elif kind=='apply':c,r=L(L(V(1))),om;aa=[om,I]
    elif kind=='poison':c,r=L(L(I)),om
    elif kind=='suffix':c,r=KI,R
    elif kind=='value':c,r=L(L(V(1))),om
    else:raise KeyError(kind)
    return c,m,r,aa
def emit(s,r,alt=None):
    e=lc.decode(s)[0];num=int(s,2);name='R'+str(num)
    n,kind,j,k,mode,ps,c=r
    if kind=='bottom1':return
    if alt or kind!='raw':
        cont,m,tail,aa=alt or details(kind)
        start=appall(A(A(e,cont),lc.bitlist(lc.enc(m),tail)),aa)
        ltl='['+','.join(map(expr,aa))+']'
        startLean=f'(call e{num} {expr(cont)} {expr(m)} {expr(tail)} {ltl})'
        reach=f'(inputCount (k := {target_steps(cont,m,tail,aa)}) he (by decide) (by decide))'
    else:
        start=e;startLean='e'+str(num);reach='(rawCount he)'
    t=start
    for p in ps:t=red(t,p)
    assert list(map(tuple,c['nodes']))==regular.compile_term(mask(t))
    ni=sorted((HERE/'wires.txt').read_text().split()).index(s)//160
    out=portable.lean(c,name).split('theorem no_stop')[0]
    out=out.replace('import Regular',f'import RegularBase\nimport Batch{ni:03}')
    # Keep each syntactic subterm as a literal in a checked source model.
    o=['open Blc Blc.Floor42 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp']
    ts=[]
    def walk(t):
        i=len(ts);ts.append(t)
        if t[0]=='A':walk(t[1]);walk(t[2])
        if t[0]=='L':walk(t[1])
    walk(t)
    idx={t:i for i,t in enumerate(ts)}
    for u in sorted(idx,key=wire):
        j=idx[u];nameT=lambda v:'lit'+str(idx[v])
        rhs=(f'.var {u[1]}' if u[0]=='V' else f'.lam {nameT(u[1])}' if u[0]=='L' else f'.app {nameT(u[1])} {nameT(u[2])}')
        o.append(f'def lit{j} : Term := {rhs}')
    o.append('def terms : Array Term := #['+','.join('lit'+str(idx[t]) for t in ts)+']')
    o.append('''def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide +kernel
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p''')
    o.append(f'''theorem excluded : ¬ IsSelfInterpreter e{num} := by
 intro he
 have hp : replay {paths(ps)} {startLean} = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay {reach} hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.{name}''')
    from modelbridge import bridge
    (HERE/(name+'.lean')).write_text(bridge(out+'\n'+'\n'.join(o)+'\n',c,ts,idx))
if __name__=='__main__':
    for p in sorted(HERE.glob('r[0-9]*.json')):
        s=f'{int(p.stem[1:]):040b}';r=json.loads(p.read_text())
        emit(s,r)
