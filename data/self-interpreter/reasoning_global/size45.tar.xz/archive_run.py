"""Time a canonical packer invocation and preserve its exit status and log."""
from pathlib import Path
import os,sys,json,subprocess,time
D=Path(__file__).resolve().parent
ROOT=D.parents[2]
def main():
 action=sys.argv[1];assert action in ('pack','check')
 cmd=['python3','data/self-interpreter/reasoning_global/pack.py',action,'45']
 if action=='pack':cmd.append('tmp/global/floor46')
 if action=='check':assert not (ROOT/'tmp/recheck/size45').exists()
 start=time.monotonic()
 with (D/f'archive-{action}.log').open('w') as f:
  p=subprocess.Popen(cmd,cwd=ROOT,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
  _,st,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(st)
 result=dict(command=cmd,exit_code=p.returncode,wall_seconds=round(time.monotonic()-start,3),max_rss_bytes=u.ru_maxrss)
 (D/f'archive-{action}.metrics').write_text(json.dumps(result,indent=1)+'\n')
 print(result,flush=True);return p.returncode
if __name__=='__main__':sys.exit(main())
