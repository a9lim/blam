import Blc.SelfintProof
namespace Blc.Floor45.Aggregate
def Safe (xs : List Term) := ∀ t ∈ xs, ¬ IsSelfInterpreter t
theorem empty : Safe [] := by intro t h; contradiction
theorem merge (a b : List Term) (x : Safe a) (y : Safe b) : Safe (a ++ b) := by
  intro t ht
  rcases List.mem_append.mp ht with h | h
  · exact x t h
  · exact y t h
end Blc.Floor45.Aggregate
