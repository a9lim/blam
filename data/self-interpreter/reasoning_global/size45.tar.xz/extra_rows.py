from emitextra import *
from grade_rows import src
import re
from collections import defaultdict
def main():
 raw={v.split()[0] for q in ['raw4.txt','raw5.txt'] for v in open(HERE/q)}
 xs={p.stem:r for p in (HERE/'attempts').glob('*.json') if p.stem not in raw and (r:=json.loads(p.read_text()))}
 # Positive finite paths found in the second source search augment the finite pass.
 more={s:r for s,r in xs.items() if r[0] in ('chain','width','smaller','three')}
 (HERE/'additional-finite.json').write_text(json.dumps(more))
 mani={}
 for i in range(0,len(xs),16):
    group=sorted(xs.items())[i:i+16];mod=f'Extra{i//16:03}';ns='Blc.Floor45.'+mod
    out=['import ExtraBase','namespace '+ns,'open Term SelfintSingleObject SelfintSharp SelfintLowerBound SelfintControl Round3Floor38','set_option maxRecDepth 30000','set_option maxHeartbeats 6000000']
    for s,r in group:
        nm='e'+str(int(s,2));out.append(src(s,nm))
        if s in more:
            out.append(f'theorem ex_{nm} : check {nm} {paths(r[1])} .{r[0]} = true := by decide')
        else:out.append(emit(s,r))
        mani[s]=dict(kind=r[0],module=mod,theorem=ns+'.ex_'+nm,term=ns+'.'+nm,replay=r[1],parameters=r[2:],strength='predicate' if s in more else 'complete')
    (HERE/(mod+'.lean')).write_text('\n'.join(out+['end '+ns])+'\n')
 (HERE/'extra-manifest.json').write_text(json.dumps(mani,separators=(',',':')))
if __name__=='__main__':main()
