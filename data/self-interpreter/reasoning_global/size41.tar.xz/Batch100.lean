import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601831834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601831834 : Closed e605601831834 ∧ code e605601831834 = 2804625087386 := by decide
theorem cert_e605601831834 : check e605601831834 [[],[]] .chain = true := by decide
def e605601832046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e605601832046 : Closed e605601832046 ∧ code e605601832046 = 2804625087598 := by decide
theorem cert_e605601832046 : check e605601832046 [[],[]] .chain = true := by decide
def e605601832058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e605601832058 : Closed e605601832058 ∧ code e605601832058 = 2804625087610 := by decide
theorem cert_e605601832058 : check e605601832058 [[],[]] .chain = true := by decide
def e605601832222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e605601832222 : Closed e605601832222 ∧ code e605601832222 = 2804625087774 := by decide
theorem cert_e605601832222 : check e605601832222 [[],[]] .chain = true := by decide
def e605601832390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e605601832390 : Closed e605601832390 ∧ code e605601832390 = 2804625087942 := by decide
theorem cert_e605601832390 : check e605601832390 [[],[]] .chain = true := by decide
def e605601832458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605601832458 : Closed e605601832458 ∧ code e605601832458 = 2804625088010 := by decide
theorem cert_e605601832458 : check e605601832458 [[],[]] .chain = true := by decide
def e605601832494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601832494 : Closed e605601832494 ∧ code e605601832494 = 2804625088046 := by decide
theorem cert_e605601832494 : check e605601832494 [[],[]] .sourceHead = true := by decide
def e605601832502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605601832502 : Closed e605601832502 ∧ code e605601832502 = 2804625088054 := by decide
theorem cert_e605601832502 : check e605601832502 [[],[]] .chain = true := by decide
def e605601832506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605601832506 : Closed e605601832506 ∧ code e605601832506 = 2804625088058 := by decide
theorem cert_e605601832506 : check e605601832506 [[],[]] .chain = true := by decide
def e605601832554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605601832554 : Closed e605601832554 ∧ code e605601832554 = 2804625088106 := by decide
theorem cert_e605601832554 : check e605601832554 [[],[]] .chain = true := by decide
def e605601832578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605601832578 : Closed e605601832578 ∧ code e605601832578 = 2804625088130 := by decide
theorem cert_e605601832578 : check e605601832578 [[],[]] .chain = true := by decide
def e605601832590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605601832590 : Closed e605601832590 ∧ code e605601832590 = 2804625088142 := by decide
theorem cert_e605601832590 : check e605601832590 [[],[]] .chain = true := by decide
def e605601832602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601832602 : Closed e605601832602 ∧ code e605601832602 = 2804625088154 := by decide
theorem cert_e605601832602 : check e605601832602 [[],[]] .chain = true := by decide
def e605601832646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605601832646 : Closed e605601832646 ∧ code e605601832646 = 2804625088198 := by decide
theorem cert_e605601832646 : check e605601832646 [[],[]] .chain = true := by decide
def e605601832674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605601832674 : Closed e605601832674 ∧ code e605601832674 = 2804625088226 := by decide
theorem cert_e605601832674 : check e605601832674 [[],[]] .sourceHead = true := by decide
def e605601832686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 2))))))
theorem wire_e605601832686 : Closed e605601832686 ∧ code e605601832686 = 2804625088238 := by decide
theorem cert_e605601832686 : check e605601832686 [[],[]] .sourceHead = true := by decide
def e605601833438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605601833438 : Closed e605601833438 ∧ code e605601833438 = 2804625088990 := by decide
theorem cert_e605601833438 : check e605601833438 [[],[]] .chain = true := by decide
def e605601833462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605601833462 : Closed e605601833462 ∧ code e605601833462 = 2804625089014 := by decide
theorem cert_e605601833462 : check e605601833462 [[],[]] .chain = true := by decide
def e605601834414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605601834414 : Closed e605601834414 ∧ code e605601834414 = 2804625089966 := by decide
theorem cert_e605601834414 : check e605601834414 [[],[]] .chain = true := by decide
def e605601834426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605601834426 : Closed e605601834426 ∧ code e605601834426 = 2804625089978 := by decide
theorem cert_e605601834426 : check e605601834426 [[],[]] .chain = true := by decide
def e605601834474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605601834474 : Closed e605601834474 ∧ code e605601834474 = 2804625090026 := by decide
theorem cert_e605601834474 : check e605601834474 [[],[]] .chain = true := by decide
def e605601834606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605601834606 : Closed e605601834606 ∧ code e605601834606 = 2804625090158 := by decide
theorem cert_e605601834606 : check e605601834606 [[],[]] .chain = true := by decide
def e605601834618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605601834618 : Closed e605601834618 ∧ code e605601834618 = 2804625090170 := by decide
theorem cert_e605601834618 : check e605601834618 [[],[]] .chain = true := by decide
def e605601834782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605601834782 : Closed e605601834782 ∧ code e605601834782 = 2804625090334 := by decide
theorem cert_e605601834782 : check e605601834782 [[],[]] .chain = true := by decide
def e605601834882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e605601834882 : Closed e605601834882 ∧ code e605601834882 = 2804625090434 := by decide
theorem cert_e605601834882 : check e605601834882 [[],[]] .chain = true := by decide
def e605601834894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605601834894 : Closed e605601834894 ∧ code e605601834894 = 2804625090446 := by decide
theorem cert_e605601834894 : check e605601834894 [[],[]] .chain = true := by decide
def e605601834906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605601834906 : Closed e605601834906 ∧ code e605601834906 = 2804625090458 := by decide
theorem cert_e605601834906 : check e605601834906 [[],[]] .chain = true := by decide
def e605601837278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e605601837278 : Closed e605601837278 ∧ code e605601837278 = 2804625092830 := by decide
theorem cert_e605601837278 : check e605601837278 [[],[]] .chain = true := by decide
def e605601837306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e605601837306 : Closed e605601837306 ∧ code e605601837306 = 2804625092858 := by decide
theorem cert_e605601837306 : check e605601837306 [[],[]] .chain = true := by decide
def e605601837854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605601837854 : Closed e605601837854 ∧ code e605601837854 = 2804625093406 := by decide
theorem cert_e605601837854 : check e605601837854 [[],[]] .chain = true := by decide
def e605601838022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605601838022 : Closed e605601838022 ∧ code e605601838022 = 2804625093574 := by decide
theorem cert_e605601838022 : check e605601838022 [[],[]] .chain = true := by decide
def e605601839130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605601839130 : Closed e605601839130 ∧ code e605601839130 = 2804625094682 := by decide
theorem cert_e605601839130 : check e605601839130 [[],[]] .sourceHead = true := by decide
def e605601839166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 4))))))))
theorem wire_e605601839166 : Closed e605601839166 ∧ code e605601839166 = 2804625094718 := by decide
theorem cert_e605601839166 : check e605601839166 [[],[]] .sourceHead = true := by decide
def e605601839214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605601839214 : Closed e605601839214 ∧ code e605601839214 = 2804625094766 := by decide
theorem cert_e605601839214 : check e605601839214 [[],[]] .chain = true := by decide
def e605601839222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605601839222 : Closed e605601839222 ∧ code e605601839222 = 2804625094774 := by decide
theorem cert_e605601839222 : check e605601839222 [[],[]] .chain = true := by decide
def e605601839226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605601839226 : Closed e605601839226 ∧ code e605601839226 = 2804625094778 := by decide
theorem cert_e605601839226 : check e605601839226 [[],[]] .chain = true := by decide
def e605601839466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605601839466 : Closed e605601839466 ∧ code e605601839466 = 2804625095018 := by decide
theorem cert_e605601839466 : check e605601839466 [[],[]] .chain = true := by decide
def e605601839490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605601839490 : Closed e605601839490 ∧ code e605601839490 = 2804625095042 := by decide
theorem cert_e605601839490 : check e605601839490 [[],[]] .chain = true := by decide
def e605601839502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605601839502 : Closed e605601839502 ∧ code e605601839502 = 2804625095054 := by decide
theorem cert_e605601839502 : check e605601839502 [[],[]] .chain = true := by decide
def e605601839514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605601839514 : Closed e605601839514 ∧ code e605601839514 = 2804625095066 := by decide
theorem cert_e605601839514 : check e605601839514 [[],[]] .chain = true := by decide
def e605601839558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605601839558 : Closed e605601839558 ∧ code e605601839558 = 2804625095110 := by decide
theorem cert_e605601839558 : check e605601839558 [[],[]] .chain = true := by decide
def e605601839586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605601839586 : Closed e605601839586 ∧ code e605601839586 = 2804625095138 := by decide
theorem cert_e605601839586 : check e605601839586 [[],[]] .sourceHead = true := by decide
def e605601839598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601839598 : Closed e605601839598 ∧ code e605601839598 = 2804625095150 := by decide
theorem cert_e605601839598 : check e605601839598 [[],[]] .sourceHead = true := by decide
def e605601842030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e605601842030 : Closed e605601842030 ∧ code e605601842030 = 2804625097582 := by decide
theorem cert_e605601842030 : check e605601842030 [[],[]] .chain = true := by decide
def e605601842042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e605601842042 : Closed e605601842042 ∧ code e605601842042 = 2804625097594 := by decide
theorem cert_e605601842042 : check e605601842042 [[],[]] .chain = true := by decide
def e605601842094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e605601842094 : Closed e605601842094 ∧ code e605601842094 = 2804625097646 := by decide
theorem cert_e605601842094 : check e605601842094 [[],[]] .chain = true := by decide
def e605601842154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e605601842154 : Closed e605601842154 ∧ code e605601842154 = 2804625097706 := by decide
theorem cert_e605601842154 : check e605601842154 [[],[]] .chain = true := by decide
def e605601842798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601842798 : Closed e605601842798 ∧ code e605601842798 = 2804625098350 := by decide
theorem cert_e605601842798 : check e605601842798 [[],[]] .chain = true := by decide
def e605601842810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601842810 : Closed e605601842810 ∧ code e605601842810 = 2804625098362 := by decide
theorem cert_e605601842810 : check e605601842810 [[],[]] .chain = true := by decide
def e605601843098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601843098 : Closed e605601843098 ∧ code e605601843098 = 2804625098650 := by decide
theorem cert_e605601843098 : check e605601843098 [[],[]] .chain = true := by decide
def e605601844334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e605601844334 : Closed e605601844334 ∧ code e605601844334 = 2804625099886 := by decide
theorem cert_e605601844334 : check e605601844334 [[],[]] .chain = true := by decide
def e605601844346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e605601844346 : Closed e605601844346 ∧ code e605601844346 = 2804625099898 := by decide
theorem cert_e605601844346 : check e605601844346 [[],[]] .chain = true := by decide
def e605601844510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e605601844510 : Closed e605601844510 ∧ code e605601844510 = 2804625100062 := by decide
theorem cert_e605601844510 : check e605601844510 [[],[]] .chain = true := by decide
def e605601844678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e605601844678 : Closed e605601844678 ∧ code e605601844678 = 2804625100230 := by decide
theorem cert_e605601844678 : check e605601844678 [[],[]] .chain = true := by decide
def e605601845018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e605601845018 : Closed e605601845018 ∧ code e605601845018 = 2804625100570 := by decide
theorem cert_e605601845018 : check e605601845018 [[],[]] .chain = true := by decide
def e605601845062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e605601845062 : Closed e605601845062 ∧ code e605601845062 = 2804625100614 := by decide
theorem cert_e605601845062 : check e605601845062 [[],[]] .chain = true := by decide
def e605601845470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e605601845470 : Closed e605601845470 ∧ code e605601845470 = 2804625101022 := by decide
theorem cert_e605601845470 : check e605601845470 [[],[]] .chain = true := by decide
def e605601845498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e605601845498 : Closed e605601845498 ∧ code e605601845498 = 2804625101050 := by decide
theorem cert_e605601845498 : check e605601845498 [[],[]] .chain = true := by decide
def e605601846046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605601846046 : Closed e605601846046 ∧ code e605601846046 = 2804625101598 := by decide
theorem cert_e605601846046 : check e605601846046 [[],[]] .chain = true := by decide
def e605601846214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605601846214 : Closed e605601846214 ∧ code e605601846214 = 2804625101766 := by decide
theorem cert_e605601846214 : check e605601846214 [[],[]] .chain = true := by decide
def e605601848374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e605601848374 : Closed e605601848374 ∧ code e605601848374 = 2804625103926 := by decide
theorem cert_e605601848374 : check e605601848374 [[],[]] .chain = true := by decide
def e605601848378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e605601848378 : Closed e605601848378 ∧ code e605601848378 = 2804625103930 := by decide
theorem cert_e605601848378 : check e605601848378 [[],[]] .chain = true := by decide
def e605601848518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e605601848518 : Closed e605601848518 ∧ code e605601848518 = 2804625104070 := by decide
theorem cert_e605601848518 : check e605601848518 [[],[]] .chain = true := by decide
def e605601849450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605601849450 : Closed e605601849450 ∧ code e605601849450 = 2804625105002 := by decide
theorem cert_e605601849450 : check e605601849450 [[],[]] .sourceHead = true := by decide
def e605601849498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601849498 : Closed e605601849498 ∧ code e605601849498 = 2804625105050 := by decide
theorem cert_e605601849498 : check e605601849498 [[],[]] .chain = true := by decide
def e605601849582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e605601849582 : Closed e605601849582 ∧ code e605601849582 = 2804625105134 := by decide
theorem cert_e605601849582 : check e605601849582 [[],[]] .sourceHead = true := by decide
def e605601849594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e605601849594 : Closed e605601849594 ∧ code e605601849594 = 2804625105146 := by decide
theorem cert_e605601849594 : check e605601849594 [[],[]] .sourceHead = true := by decide
def e605601849782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e605601849782 : Closed e605601849782 ∧ code e605601849782 = 2804625105334 := by decide
theorem cert_e605601849782 : check e605601849782 [[],[]] .chain = true := by decide
def e605601849786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605601849786 : Closed e605601849786 ∧ code e605601849786 = 2804625105338 := by decide
theorem cert_e605601849786 : check e605601849786 [[],[]] .chain = true := by decide
def e605601849814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e605601849814 : Closed e605601849814 ∧ code e605601849814 = 2804625105366 := by decide
theorem cert_e605601849814 : check e605601849814 [[],[]] .chain = true := by decide
def e605601849818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e605601849818 : Closed e605601849818 ∧ code e605601849818 = 2804625105370 := by decide
theorem cert_e605601849818 : check e605601849818 [[],[]] .chain = true := by decide
def e605601849834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605601849834 : Closed e605601849834 ∧ code e605601849834 = 2804625105386 := by decide
theorem cert_e605601849834 : check e605601849834 [[],[]] .chain = true := by decide
def e605601849966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601849966 : Closed e605601849966 ∧ code e605601849966 = 2804625105518 := by decide
theorem cert_e605601849966 : check e605601849966 [[],[]] .sourceHead = true := by decide
def e605601849978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601849978 : Closed e605601849978 ∧ code e605601849978 = 2804625105530 := by decide
theorem cert_e605601849978 : check e605601849978 [[],[]] .sourceHead = true := by decide
def e605601850142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e605601850142 : Closed e605601850142 ∧ code e605601850142 = 2804625105694 := by decide
theorem cert_e605601850142 : check e605601850142 [[],[]] .sourceHead = true := by decide
def e605601850166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601850166 : Closed e605601850166 ∧ code e605601850166 = 2804625105718 := by decide
theorem cert_e605601850166 : check e605601850166 [[],[]] .chain = true := by decide
def e605601850170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601850170 : Closed e605601850170 ∧ code e605601850170 = 2804625105722 := by decide
theorem cert_e605601850170 : check e605601850170 [[],[]] .chain = true := by decide
def e605601850266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601850266 : Closed e605601850266 ∧ code e605601850266 = 2804625105818 := by decide
theorem cert_e605601850266 : check e605601850266 [[],[]] .chain = true := by decide
def e605601850310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e605601850310 : Closed e605601850310 ∧ code e605601850310 = 2804625105862 := by decide
theorem cert_e605601850310 : check e605601850310 [[],[]] .sourceHead = true := by decide
def e605601850794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605601850794 : Closed e605601850794 ∧ code e605601850794 = 2804625106346 := by decide
theorem cert_e605601850794 : check e605601850794 [[],[]] .chain = true := by decide
def e605601850890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605601850890 : Closed e605601850890 ∧ code e605601850890 = 2804625106442 := by decide
theorem cert_e605601850890 : check e605601850890 [[],[]] .chain = true := by decide
def e605601850926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601850926 : Closed e605601850926 ∧ code e605601850926 = 2804625106478 := by decide
theorem cert_e605601850926 : check e605601850926 [[],[]] .sourceHead = true := by decide
def e605601850934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605601850934 : Closed e605601850934 ∧ code e605601850934 = 2804625106486 := by decide
theorem cert_e605601850934 : check e605601850934 [[],[]] .chain = true := by decide
def e605601850938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605601850938 : Closed e605601850938 ∧ code e605601850938 = 2804625106490 := by decide
theorem cert_e605601850938 : check e605601850938 [[],[]] .chain = true := by decide
def e605601850986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605601850986 : Closed e605601850986 ∧ code e605601850986 = 2804625106538 := by decide
theorem cert_e605601850986 : check e605601850986 [[],[]] .chain = true := by decide
def e605601851010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605601851010 : Closed e605601851010 ∧ code e605601851010 = 2804625106562 := by decide
theorem cert_e605601851010 : check e605601851010 [[],[]] .chain = true := by decide
def e605601851022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605601851022 : Closed e605601851022 ∧ code e605601851022 = 2804625106574 := by decide
theorem cert_e605601851022 : check e605601851022 [[],[]] .chain = true := by decide
def e605601851034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601851034 : Closed e605601851034 ∧ code e605601851034 = 2804625106586 := by decide
theorem cert_e605601851034 : check e605601851034 [[],[]] .chain = true := by decide
def e605601851078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605601851078 : Closed e605601851078 ∧ code e605601851078 = 2804625106630 := by decide
theorem cert_e605601851078 : check e605601851078 [[],[]] .chain = true := by decide
def e605601851106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605601851106 : Closed e605601851106 ∧ code e605601851106 = 2804625106658 := by decide
theorem cert_e605601851106 : check e605601851106 [[],[]] .sourceHead = true := by decide
def e605601851118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e605601851118 : Closed e605601851118 ∧ code e605601851118 = 2804625106670 := by decide
theorem cert_e605601851118 : check e605601851118 [[],[]] .sourceHead = true := by decide
def e605601851162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e605601851162 : Closed e605601851162 ∧ code e605601851162 = 2804625106714 := by decide
theorem cert_e605601851162 : check e605601851162 [[],[]] .chain = true := by decide
def e605601851206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e605601851206 : Closed e605601851206 ∧ code e605601851206 = 2804625106758 := by decide
theorem cert_e605601851206 : check e605601851206 [[],[]] .chain = true := by decide
def e605601851274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601851274 : Closed e605601851274 ∧ code e605601851274 = 2804625106826 := by decide
theorem cert_e605601851274 : check e605601851274 [[],[]] .sourceHead = true := by decide
def e605601851298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e605601851298 : Closed e605601851298 ∧ code e605601851298 = 2804625106850 := by decide
theorem cert_e605601851298 : check e605601851298 [[],[]] .sourceHead = true := by decide
def e605601851310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e605601851310 : Closed e605601851310 ∧ code e605601851310 = 2804625106862 := by decide
theorem cert_e605601851310 : check e605601851310 [[],[]] .sourceHead = true := by decide
def e605601851322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e605601851322 : Closed e605601851322 ∧ code e605601851322 = 2804625106874 := by decide
theorem cert_e605601851322 : check e605601851322 [[],[]] .sourceHead = true := by decide
def e605601851418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605601851418 : Closed e605601851418 ∧ code e605601851418 = 2804625106970 := by decide
theorem cert_e605601851418 : check e605601851418 [[],[]] .sourceHead = true := by decide
def e605601851454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e605601851454 : Closed e605601851454 ∧ code e605601851454 = 2804625107006 := by decide
theorem cert_e605601851454 : check e605601851454 [[],[]] .sourceHead = true := by decide
def e605601851502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605601851502 : Closed e605601851502 ∧ code e605601851502 = 2804625107054 := by decide
theorem cert_e605601851502 : check e605601851502 [[],[]] .chain = true := by decide
def e605601851510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605601851510 : Closed e605601851510 ∧ code e605601851510 = 2804625107062 := by decide
theorem cert_e605601851510 : check e605601851510 [[],[]] .chain = true := by decide
def e605601851514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605601851514 : Closed e605601851514 ∧ code e605601851514 = 2804625107066 := by decide
theorem cert_e605601851514 : check e605601851514 [[],[]] .chain = true := by decide
def e605601851754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605601851754 : Closed e605601851754 ∧ code e605601851754 = 2804625107306 := by decide
theorem cert_e605601851754 : check e605601851754 [[],[]] .chain = true := by decide
def e605601851778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605601851778 : Closed e605601851778 ∧ code e605601851778 = 2804625107330 := by decide
theorem cert_e605601851778 : check e605601851778 [[],[]] .chain = true := by decide
def e605601851790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605601851790 : Closed e605601851790 ∧ code e605601851790 = 2804625107342 := by decide
theorem cert_e605601851790 : check e605601851790 [[],[]] .chain = true := by decide
def e605601851802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605601851802 : Closed e605601851802 ∧ code e605601851802 = 2804625107354 := by decide
theorem cert_e605601851802 : check e605601851802 [[],[]] .chain = true := by decide
def e605601851846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605601851846 : Closed e605601851846 ∧ code e605601851846 = 2804625107398 := by decide
theorem cert_e605601851846 : check e605601851846 [[],[]] .chain = true := by decide
def e605601851874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605601851874 : Closed e605601851874 ∧ code e605601851874 = 2804625107426 := by decide
theorem cert_e605601851874 : check e605601851874 [[],[]] .sourceHead = true := by decide
def e605601851886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601851886 : Closed e605601851886 ∧ code e605601851886 = 2804625107438 := by decide
theorem cert_e605601851886 : check e605601851886 [[],[]] .sourceHead = true := by decide
def e605601852470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e605601852470 : Closed e605601852470 ∧ code e605601852470 = 2804625108022 := by decide
theorem cert_e605601852470 : check e605601852470 [[],[]] .chain = true := by decide
def e605601852474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e605601852474 : Closed e605601852474 ∧ code e605601852474 = 2804625108026 := by decide
theorem cert_e605601852474 : check e605601852474 [[],[]] .chain = true := by decide
def e605601852614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e605601852614 : Closed e605601852614 ∧ code e605601852614 = 2804625108166 := by decide
theorem cert_e605601852614 : check e605601852614 [[],[]] .chain = true := by decide
def e605601852942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e605601852942 : Closed e605601852942 ∧ code e605601852942 = 2804625108494 := by decide
theorem cert_e605601852942 : check e605601852942 [[],[]] .sourceHead = true := by decide
def e605601853026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e605601853026 : Closed e605601853026 ∧ code e605601853026 = 2804625108578 := by decide
theorem cert_e605601853026 : check e605601853026 [[],[]] .sourceHead = true := by decide
def e605601853038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601853038 : Closed e605601853038 ∧ code e605601853038 = 2804625108590 := by decide
theorem cert_e605601853038 : check e605601853038 [[],[]] .sourceHead = true := by decide
def e605601853050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601853050 : Closed e605601853050 ∧ code e605601853050 = 2804625108602 := by decide
theorem cert_e605601853050 : check e605601853050 [[],[]] .sourceHead = true := by decide
def e605601858390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e605601858390 : Closed e605601858390 ∧ code e605601858390 = 2804625113942 := by decide
theorem cert_e605601858390 : check e605601858390 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e605601858394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e605601858394 : Closed e605601858394 ∧ code e605601858394 = 2804625113946 := by decide
theorem cert_e605601858394 : check e605601858394 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e605601858774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601858774 : Closed e605601858774 ∧ code e605601858774 = 2804625114326 := by decide
theorem cert_e605601858774 : check e605601858774 [[],[]] .chain = true := by decide
def e605601858778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601858778 : Closed e605601858778 ∧ code e605601858778 = 2804625114330 := by decide
theorem cert_e605601858778 : check e605601858778 [[],[]] .chain = true := by decide
def e605601858794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601858794 : Closed e605601858794 ∧ code e605601858794 = 2804625114346 := by decide
theorem cert_e605601858794 : check e605601858794 [[],[]] .chain = true := by decide
def e605601858870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601858870 : Closed e605601858870 ∧ code e605601858870 = 2804625114422 := by decide
theorem cert_e605601858870 : check e605601858870 [[],[]] .chain = true := by decide
def e605601858874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601858874 : Closed e605601858874 ∧ code e605601858874 = 2804625114426 := by decide
theorem cert_e605601858874 : check e605601858874 [[],[]] .chain = true := by decide
def e605601858970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601858970 : Closed e605601858970 ∧ code e605601858970 = 2804625114522 := by decide
theorem cert_e605601858970 : check e605601858970 [[],[]] .chain = true := by decide
def e605601859438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e605601859438 : Closed e605601859438 ∧ code e605601859438 = 2804625114990 := by decide
theorem cert_e605601859438 : check e605601859438 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601859446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e605601859446 : Closed e605601859446 ∧ code e605601859446 = 2804625114998 := by decide
theorem cert_e605601859446 : check e605601859446 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601859502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e605601859502 : Closed e605601859502 ∧ code e605601859502 = 2804625115054 := by decide
theorem cert_e605601859502 : check e605601859502 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601859514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e605601859514 : Closed e605601859514 ∧ code e605601859514 = 2804625115066 := by decide
theorem cert_e605601859514 : check e605601859514 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601859542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e605601859542 : Closed e605601859542 ∧ code e605601859542 = 2804625115094 := by decide
theorem cert_e605601859542 : check e605601859542 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605601859546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e605601859546 : Closed e605601859546 ∧ code e605601859546 = 2804625115098 := by decide
theorem cert_e605601859546 : check e605601859546 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605601861046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e605601861046 : Closed e605601861046 ∧ code e605601861046 = 2804625116598 := by decide
theorem cert_e605601861046 : check e605601861046 [[],[]] .chain = true := by decide
def e605601861078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e605601861078 : Closed e605601861078 ∧ code e605601861078 = 2804625116630 := by decide
theorem cert_e605601861078 : check e605601861078 [[],[]] .chain = true := by decide
def e605601861082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e605601861082 : Closed e605601861082 ∧ code e605601861082 = 2804625116634 := by decide
theorem cert_e605601861082 : check e605601861082 [[],[]] .chain = true := by decide
def e605601861302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e605601861302 : Closed e605601861302 ∧ code e605601861302 = 2804625116854 := by decide
theorem cert_e605601861302 : check e605601861302 [[],[]] .chain = true := by decide
def e605601861334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e605601861334 : Closed e605601861334 ∧ code e605601861334 = 2804625116886 := by decide
theorem cert_e605601861334 : check e605601861334 [[],[]] .chain = true := by decide
def e605601861338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e605601861338 : Closed e605601861338 ∧ code e605601861338 = 2804625116890 := by decide
theorem cert_e605601861338 : check e605601861338 [[],[]] .chain = true := by decide
def e605601861354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601861354 : Closed e605601861354 ∧ code e605601861354 = 2804625116906 := by decide
theorem cert_e605601861354 : check e605601861354 [[],[]] .chain = true := by decide
def e605601861462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601861462 : Closed e605601861462 ∧ code e605601861462 = 2804625117014 := by decide
theorem cert_e605601861462 : check e605601861462 [[],[]] .chain = true := by decide
def e605601861466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601861466 : Closed e605601861466 ∧ code e605601861466 = 2804625117018 := by decide
theorem cert_e605601861466 : check e605601861466 [[],[]] .chain = true := by decide
def e605601861482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e605601861482 : Closed e605601861482 ∧ code e605601861482 = 2804625117034 := by decide
theorem cert_e605601861482 : check e605601861482 [[],[]] .chain = true := by decide
def e605601862510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601862510 : Closed e605601862510 ∧ code e605601862510 = 2804625118062 := by decide
theorem cert_e605601862510 : check e605601862510 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601862518 : Closed e605601862518 ∧ code e605601862518 = 2804625118070 := by decide
theorem cert_e605601862518 : check e605601862518 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601862574 : Closed e605601862574 ∧ code e605601862574 = 2804625118126 := by decide
theorem cert_e605601862574 : check e605601862574 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601862586 : Closed e605601862586 ∧ code e605601862586 = 2804625118138 := by decide
theorem cert_e605601862586 : check e605601862586 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601862614 : Closed e605601862614 ∧ code e605601862614 = 2804625118166 := by decide
theorem cert_e605601862614 : check e605601862614 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601862618 : Closed e605601862618 ∧ code e605601862618 = 2804625118170 := by decide
theorem cert_e605601862618 : check e605601862618 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601862894 : Closed e605601862894 ∧ code e605601862894 = 2804625118446 := by decide
theorem cert_e605601862894 : check e605601862894 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601862902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601862902 : Closed e605601862902 ∧ code e605601862902 = 2804625118454 := by decide
theorem cert_e605601862902 : check e605601862902 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601863278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601863278 : Closed e605601863278 ∧ code e605601863278 = 2804625118830 := by decide
theorem cert_e605601863278 : check e605601863278 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601863290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601863290 : Closed e605601863290 ∧ code e605601863290 = 2804625118842 := by decide
theorem cert_e605601863290 : check e605601863290 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601863478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601863478 : Closed e605601863478 ∧ code e605601863478 = 2804625119030 := by decide
theorem cert_e605601863478 : check e605601863478 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601863482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601863482 : Closed e605601863482 ∧ code e605601863482 = 2804625119034 := by decide
theorem cert_e605601863482 : check e605601863482 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601863918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601863918 : Closed e605601863918 ∧ code e605601863918 = 2804625119470 := by decide
theorem cert_e605601863918 : check e605601863918 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601863926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601863926 : Closed e605601863926 ∧ code e605601863926 = 2804625119478 := by decide
theorem cert_e605601863926 : check e605601863926 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601864118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e605601864118 : Closed e605601864118 ∧ code e605601864118 = 2804625119670 := by decide
theorem cert_e605601864118 : check e605601864118 [[],[]] .chain = true := by decide
def e605601864150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e605601864150 : Closed e605601864150 ∧ code e605601864150 = 2804625119702 := by decide
theorem cert_e605601864150 : check e605601864150 [[],[]] .chain = true := by decide
def e605601864154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e605601864154 : Closed e605601864154 ∧ code e605601864154 = 2804625119706 := by decide
theorem cert_e605601864154 : check e605601864154 [[],[]] .chain = true := by decide
def e605601864310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e605601864310 : Closed e605601864310 ∧ code e605601864310 = 2804625119862 := by decide
theorem cert_e605601864310 : check e605601864310 [[],[]] .chain = true := by decide
def e605601864478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601864478 : Closed e605601864478 ∧ code e605601864478 = 2804625120030 := by decide
theorem cert_e605601864478 : check e605601864478 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601864502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601864502 : Closed e605601864502 ∧ code e605601864502 = 2804625120054 := by decide
theorem cert_e605601864502 : check e605601864502 [[],[]] .chain = true := by decide
end Blc.Floor41
