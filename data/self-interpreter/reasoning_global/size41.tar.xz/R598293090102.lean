import CodeBridge
import R598293090102Blk0
import R598293090102Blk6
import R598293090102Blk12
import R598293090102Blk18
import R598293090102Blk24
import R598293090102Blk30
import R598293090102Blk36
import R598293090102Blk42
import R598293090102Blk48
import R598293090102Blk54
import R598293090102Blk60
import R598293090102Blk66
import R598293090102Blk72
import R598293090102Blk78
import R598293090102Blk84
import R598293090102Blk90
import R598293090102Blk96
import R598293090102Blk102
import R598293090102Blk108
import R598293090102Blk114
import R598293090102Blk120
import R598293090102Blk126
import R598293090102Blk132
namespace Certgen.R598293090102
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit184 : Term := .var 0
def lit102 : Term := .var 1
def lit68 : Term := .var 2
def lit94 : Term := .lam lit184
def lit101 : Term := .lam lit102
def lit93 : Term := .lam lit94
def lit103 : Term := .var 4
def lit182 : Term := .app lit184 lit184
def lit69 : Term := .app lit184 lit102
def lit100 : Term := .lam lit101
def lit181 : Term := .lam lit182
def lit91 : Term := .app lit184 lit93
def lit98 : Term := .app lit184 lit100
def lit67 : Term := .app lit68 lit69
def lit66 : Term := .lam lit67
def lit65 : Term := .lam lit66
def lit176 : Term := .app lit181 lit181
def lit97 : Term := .app lit98 lit103
def lit63 : Term := .app lit184 lit65
def lit96 : Term := .lam lit97
def lit62 : Term := .lam lit63
def lit34 : Term := .app lit62 lit69
def lit90 : Term := .app lit91 lit96
def lit33 : Term := .lam lit34
def lit89 : Term := .lam lit90
def lit32 : Term := .lam lit33
def lit31 : Term := .app lit32 lit69
def lit30 : Term := .lam lit31
def lit51 : Term := .app lit62 lit62
def lit83 : Term := .app lit98 lit89
def lit29 : Term := .lam lit30
def lit82 : Term := .lam lit83
def lit76 : Term := .app lit98 lit82
def lit75 : Term := .lam lit76
def lit12 : Term := .app lit32 lit29
def lit11 : Term := .app lit12 lit51
def lit10 : Term := .app lit11 lit93
def lit9 : Term := .app lit10 lit75
def lit8 : Term := .app lit9 lit176
def lit7 : Term := .app lit8 lit176
def lit6 : Term := .app lit7 lit176
def lit5 : Term := .app lit6 lit176
def lit4 : Term := .app lit5 lit176
def lit3 : Term := .app lit4 lit176
def lit2 : Term := .app lit3 lit176
def lit1 : Term := .app lit2 lit176
def lit0 : Term := .app lit1 lit176
def filling : Nat → Term := fun p => if p = 103 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub184 : model.term 184 = lit184 := model.var_eq 184 0 (by rfl)
theorem sub183 : model.term 183 = lit184 := model.var_eq 183 0 (by rfl)
theorem sub182 : model.term 182 = lit182 := by rw [model.app_eq 182 183 184 (by rfl), sub183, sub184]; rfl
theorem sub181 : model.term 181 = lit181 := by rw [model.lam_eq 181 182 (by rfl), sub182]; rfl
theorem sub180 : model.term 180 = lit184 := model.var_eq 180 0 (by rfl)
theorem sub179 : model.term 179 = lit184 := model.var_eq 179 0 (by rfl)
theorem sub178 : model.term 178 = lit182 := by rw [model.app_eq 178 179 180 (by rfl), sub179, sub180]; rfl
theorem sub177 : model.term 177 = lit181 := by rw [model.lam_eq 177 178 (by rfl), sub178]; rfl
theorem sub176 : model.term 176 = lit176 := by rw [model.app_eq 176 177 181 (by rfl), sub177, sub181]; rfl
theorem sub175 : model.term 175 = lit184 := model.var_eq 175 0 (by rfl)
theorem sub174 : model.term 174 = lit184 := model.var_eq 174 0 (by rfl)
theorem sub173 : model.term 173 = lit182 := by rw [model.app_eq 173 174 175 (by rfl), sub174, sub175]; rfl
theorem sub172 : model.term 172 = lit181 := by rw [model.lam_eq 172 173 (by rfl), sub173]; rfl
theorem sub171 : model.term 171 = lit184 := model.var_eq 171 0 (by rfl)
theorem sub170 : model.term 170 = lit184 := model.var_eq 170 0 (by rfl)
theorem sub169 : model.term 169 = lit182 := by rw [model.app_eq 169 170 171 (by rfl), sub170, sub171]; rfl
theorem sub168 : model.term 168 = lit181 := by rw [model.lam_eq 168 169 (by rfl), sub169]; rfl
theorem sub167 : model.term 167 = lit176 := by rw [model.app_eq 167 168 172 (by rfl), sub168, sub172]; rfl
theorem sub166 : model.term 166 = lit184 := model.var_eq 166 0 (by rfl)
theorem sub165 : model.term 165 = lit184 := model.var_eq 165 0 (by rfl)
theorem sub164 : model.term 164 = lit182 := by rw [model.app_eq 164 165 166 (by rfl), sub165, sub166]; rfl
theorem sub163 : model.term 163 = lit181 := by rw [model.lam_eq 163 164 (by rfl), sub164]; rfl
theorem sub162 : model.term 162 = lit184 := model.var_eq 162 0 (by rfl)
theorem sub161 : model.term 161 = lit184 := model.var_eq 161 0 (by rfl)
theorem sub160 : model.term 160 = lit182 := by rw [model.app_eq 160 161 162 (by rfl), sub161, sub162]; rfl
theorem sub159 : model.term 159 = lit181 := by rw [model.lam_eq 159 160 (by rfl), sub160]; rfl
theorem sub158 : model.term 158 = lit176 := by rw [model.app_eq 158 159 163 (by rfl), sub159, sub163]; rfl
theorem sub157 : model.term 157 = lit184 := model.var_eq 157 0 (by rfl)
theorem sub156 : model.term 156 = lit184 := model.var_eq 156 0 (by rfl)
theorem sub155 : model.term 155 = lit182 := by rw [model.app_eq 155 156 157 (by rfl), sub156, sub157]; rfl
theorem sub154 : model.term 154 = lit181 := by rw [model.lam_eq 154 155 (by rfl), sub155]; rfl
theorem sub153 : model.term 153 = lit184 := model.var_eq 153 0 (by rfl)
theorem sub152 : model.term 152 = lit184 := model.var_eq 152 0 (by rfl)
theorem sub151 : model.term 151 = lit182 := by rw [model.app_eq 151 152 153 (by rfl), sub152, sub153]; rfl
theorem sub150 : model.term 150 = lit181 := by rw [model.lam_eq 150 151 (by rfl), sub151]; rfl
theorem sub149 : model.term 149 = lit176 := by rw [model.app_eq 149 150 154 (by rfl), sub150, sub154]; rfl
theorem sub148 : model.term 148 = lit184 := model.var_eq 148 0 (by rfl)
theorem sub147 : model.term 147 = lit184 := model.var_eq 147 0 (by rfl)
theorem sub146 : model.term 146 = lit182 := by rw [model.app_eq 146 147 148 (by rfl), sub147, sub148]; rfl
theorem sub145 : model.term 145 = lit181 := by rw [model.lam_eq 145 146 (by rfl), sub146]; rfl
theorem sub144 : model.term 144 = lit184 := model.var_eq 144 0 (by rfl)
theorem sub143 : model.term 143 = lit184 := model.var_eq 143 0 (by rfl)
theorem sub142 : model.term 142 = lit182 := by rw [model.app_eq 142 143 144 (by rfl), sub143, sub144]; rfl
theorem sub141 : model.term 141 = lit181 := by rw [model.lam_eq 141 142 (by rfl), sub142]; rfl
theorem sub140 : model.term 140 = lit176 := by rw [model.app_eq 140 141 145 (by rfl), sub141, sub145]; rfl
theorem sub139 : model.term 139 = lit184 := model.var_eq 139 0 (by rfl)
theorem sub138 : model.term 138 = lit184 := model.var_eq 138 0 (by rfl)
theorem sub137 : model.term 137 = lit182 := by rw [model.app_eq 137 138 139 (by rfl), sub138, sub139]; rfl
theorem sub136 : model.term 136 = lit181 := by rw [model.lam_eq 136 137 (by rfl), sub137]; rfl
theorem sub135 : model.term 135 = lit184 := model.var_eq 135 0 (by rfl)
theorem sub134 : model.term 134 = lit184 := model.var_eq 134 0 (by rfl)
theorem sub133 : model.term 133 = lit182 := by rw [model.app_eq 133 134 135 (by rfl), sub134, sub135]; rfl
theorem sub132 : model.term 132 = lit181 := by rw [model.lam_eq 132 133 (by rfl), sub133]; rfl
theorem sub131 : model.term 131 = lit176 := by rw [model.app_eq 131 132 136 (by rfl), sub132, sub136]; rfl
theorem sub130 : model.term 130 = lit184 := model.var_eq 130 0 (by rfl)
theorem sub129 : model.term 129 = lit184 := model.var_eq 129 0 (by rfl)
theorem sub128 : model.term 128 = lit182 := by rw [model.app_eq 128 129 130 (by rfl), sub129, sub130]; rfl
theorem sub127 : model.term 127 = lit181 := by rw [model.lam_eq 127 128 (by rfl), sub128]; rfl
theorem sub126 : model.term 126 = lit184 := model.var_eq 126 0 (by rfl)
theorem sub125 : model.term 125 = lit184 := model.var_eq 125 0 (by rfl)
theorem sub124 : model.term 124 = lit182 := by rw [model.app_eq 124 125 126 (by rfl), sub125, sub126]; rfl
theorem sub123 : model.term 123 = lit181 := by rw [model.lam_eq 123 124 (by rfl), sub124]; rfl
theorem sub122 : model.term 122 = lit176 := by rw [model.app_eq 122 123 127 (by rfl), sub123, sub127]; rfl
theorem sub121 : model.term 121 = lit184 := model.var_eq 121 0 (by rfl)
theorem sub120 : model.term 120 = lit184 := model.var_eq 120 0 (by rfl)
theorem sub119 : model.term 119 = lit182 := by rw [model.app_eq 119 120 121 (by rfl), sub120, sub121]; rfl
theorem sub118 : model.term 118 = lit181 := by rw [model.lam_eq 118 119 (by rfl), sub119]; rfl
theorem sub117 : model.term 117 = lit184 := model.var_eq 117 0 (by rfl)
theorem sub116 : model.term 116 = lit184 := model.var_eq 116 0 (by rfl)
theorem sub115 : model.term 115 = lit182 := by rw [model.app_eq 115 116 117 (by rfl), sub116, sub117]; rfl
theorem sub114 : model.term 114 = lit181 := by rw [model.lam_eq 114 115 (by rfl), sub115]; rfl
theorem sub113 : model.term 113 = lit176 := by rw [model.app_eq 113 114 118 (by rfl), sub114, sub118]; rfl
theorem sub112 : model.term 112 = lit184 := model.var_eq 112 0 (by rfl)
theorem sub111 : model.term 111 = lit184 := model.var_eq 111 0 (by rfl)
theorem sub110 : model.term 110 = lit182 := by rw [model.app_eq 110 111 112 (by rfl), sub111, sub112]; rfl
theorem sub109 : model.term 109 = lit181 := by rw [model.lam_eq 109 110 (by rfl), sub110]; rfl
theorem sub108 : model.term 108 = lit184 := model.var_eq 108 0 (by rfl)
theorem sub107 : model.term 107 = lit184 := model.var_eq 107 0 (by rfl)
theorem sub106 : model.term 106 = lit182 := by rw [model.app_eq 106 107 108 (by rfl), sub107, sub108]; rfl
theorem sub105 : model.term 105 = lit181 := by rw [model.lam_eq 105 106 (by rfl), sub106]; rfl
theorem sub104 : model.term 104 = lit176 := by rw [model.app_eq 104 105 109 (by rfl), sub105, sub109]; rfl
theorem sub103 : model.term 103 = lit103 := (opaqueTerm (rankedCode code ordered_code) filling (p := 103) (by rfl)).trans (by rfl)
theorem sub102 : model.term 102 = lit102 := model.var_eq 102 1 (by rfl)
theorem sub101 : model.term 101 = lit101 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit100 := by rw [model.lam_eq 100 101 (by rfl), sub101]; rfl
theorem sub99 : model.term 99 = lit184 := model.var_eq 99 0 (by rfl)
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 100 (by rfl), sub99, sub100]; rfl
theorem sub97 : model.term 97 = lit97 := by rw [model.app_eq 97 98 103 (by rfl), sub98, sub103]; rfl
theorem sub96 : model.term 96 = lit96 := by rw [model.lam_eq 96 97 (by rfl), sub97]; rfl
theorem sub95 : model.term 95 = lit184 := model.var_eq 95 0 (by rfl)
theorem sub94 : model.term 94 = lit94 := by rw [model.lam_eq 94 95 (by rfl), sub95]; rfl
theorem sub93 : model.term 93 = lit93 := by rw [model.lam_eq 93 94 (by rfl), sub94]; rfl
theorem sub92 : model.term 92 = lit184 := model.var_eq 92 0 (by rfl)
theorem sub91 : model.term 91 = lit91 := by rw [model.app_eq 91 92 93 (by rfl), sub92, sub93]; rfl
theorem sub90 : model.term 90 = lit90 := by rw [model.app_eq 90 91 96 (by rfl), sub91, sub96]; rfl
theorem sub89 : model.term 89 = lit89 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit102 := model.var_eq 88 1 (by rfl)
theorem sub87 : model.term 87 = lit101 := by rw [model.lam_eq 87 88 (by rfl), sub88]; rfl
theorem sub86 : model.term 86 = lit100 := by rw [model.lam_eq 86 87 (by rfl), sub87]; rfl
theorem sub85 : model.term 85 = lit184 := model.var_eq 85 0 (by rfl)
theorem sub84 : model.term 84 = lit98 := by rw [model.app_eq 84 85 86 (by rfl), sub85, sub86]; rfl
theorem sub83 : model.term 83 = lit83 := by rw [model.app_eq 83 84 89 (by rfl), sub84, sub89]; rfl
theorem sub82 : model.term 82 = lit82 := by rw [model.lam_eq 82 83 (by rfl), sub83]; rfl
theorem sub81 : model.term 81 = lit102 := model.var_eq 81 1 (by rfl)
theorem sub80 : model.term 80 = lit101 := by rw [model.lam_eq 80 81 (by rfl), sub81]; rfl
theorem sub79 : model.term 79 = lit100 := by rw [model.lam_eq 79 80 (by rfl), sub80]; rfl
theorem sub78 : model.term 78 = lit184 := model.var_eq 78 0 (by rfl)
theorem sub77 : model.term 77 = lit98 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit76 := by rw [model.app_eq 76 77 82 (by rfl), sub77, sub82]; rfl
theorem sub75 : model.term 75 = lit75 := by rw [model.lam_eq 75 76 (by rfl), sub76]; rfl
theorem sub74 : model.term 74 = lit184 := model.var_eq 74 0 (by rfl)
theorem sub73 : model.term 73 = lit94 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit93 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit102 := model.var_eq 71 1 (by rfl)
theorem sub70 : model.term 70 = lit184 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 71 (by rfl), sub70, sub71]; rfl
theorem sub68 : model.term 68 = lit68 := model.var_eq 68 2 (by rfl)
theorem sub67 : model.term 67 = lit67 := by rw [model.app_eq 67 68 69 (by rfl), sub68, sub69]; rfl
theorem sub66 : model.term 66 = lit66 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit65 := by rw [model.lam_eq 65 66 (by rfl), sub66]; rfl
theorem sub64 : model.term 64 = lit184 := model.var_eq 64 0 (by rfl)
theorem sub63 : model.term 63 = lit63 := by rw [model.app_eq 63 64 65 (by rfl), sub64, sub65]; rfl
theorem sub62 : model.term 62 = lit62 := by rw [model.lam_eq 62 63 (by rfl), sub63]; rfl
theorem sub61 : model.term 61 = lit102 := model.var_eq 61 1 (by rfl)
theorem sub60 : model.term 60 = lit184 := model.var_eq 60 0 (by rfl)
theorem sub59 : model.term 59 = lit69 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit68 := model.var_eq 58 2 (by rfl)
theorem sub57 : model.term 57 = lit67 := by rw [model.app_eq 57 58 59 (by rfl), sub58, sub59]; rfl
theorem sub56 : model.term 56 = lit66 := by rw [model.lam_eq 56 57 (by rfl), sub57]; rfl
theorem sub55 : model.term 55 = lit65 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit184 := model.var_eq 54 0 (by rfl)
theorem sub53 : model.term 53 = lit63 := by rw [model.app_eq 53 54 55 (by rfl), sub54, sub55]; rfl
theorem sub52 : model.term 52 = lit62 := by rw [model.lam_eq 52 53 (by rfl), sub53]; rfl
theorem sub51 : model.term 51 = lit51 := by rw [model.app_eq 51 52 62 (by rfl), sub52, sub62]; rfl
theorem sub50 : model.term 50 = lit102 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit184 := model.var_eq 49 0 (by rfl)
theorem sub48 : model.term 48 = lit69 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit102 := model.var_eq 47 1 (by rfl)
theorem sub46 : model.term 46 = lit184 := model.var_eq 46 0 (by rfl)
theorem sub45 : model.term 45 = lit69 := by rw [model.app_eq 45 46 47 (by rfl), sub46, sub47]; rfl
theorem sub44 : model.term 44 = lit102 := model.var_eq 44 1 (by rfl)
theorem sub43 : model.term 43 = lit184 := model.var_eq 43 0 (by rfl)
theorem sub42 : model.term 42 = lit69 := by rw [model.app_eq 42 43 44 (by rfl), sub43, sub44]; rfl
theorem sub41 : model.term 41 = lit68 := model.var_eq 41 2 (by rfl)
theorem sub40 : model.term 40 = lit67 := by rw [model.app_eq 40 41 42 (by rfl), sub41, sub42]; rfl
theorem sub39 : model.term 39 = lit66 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit65 := by rw [model.lam_eq 38 39 (by rfl), sub39]; rfl
theorem sub37 : model.term 37 = lit184 := model.var_eq 37 0 (by rfl)
theorem sub36 : model.term 36 = lit63 := by rw [model.app_eq 36 37 38 (by rfl), sub37, sub38]; rfl
theorem sub35 : model.term 35 = lit62 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit34 := by rw [model.app_eq 34 35 45 (by rfl), sub35, sub45]; rfl
theorem sub33 : model.term 33 = lit33 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit32 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit31 := by rw [model.app_eq 31 32 48 (by rfl), sub32, sub48]; rfl
theorem sub30 : model.term 30 = lit30 := by rw [model.lam_eq 30 31 (by rfl), sub31]; rfl
theorem sub29 : model.term 29 = lit29 := by rw [model.lam_eq 29 30 (by rfl), sub30]; rfl
theorem sub28 : model.term 28 = lit102 := model.var_eq 28 1 (by rfl)
theorem sub27 : model.term 27 = lit184 := model.var_eq 27 0 (by rfl)
theorem sub26 : model.term 26 = lit69 := by rw [model.app_eq 26 27 28 (by rfl), sub27, sub28]; rfl
theorem sub25 : model.term 25 = lit102 := model.var_eq 25 1 (by rfl)
theorem sub24 : model.term 24 = lit184 := model.var_eq 24 0 (by rfl)
theorem sub23 : model.term 23 = lit69 := by rw [model.app_eq 23 24 25 (by rfl), sub24, sub25]; rfl
theorem sub22 : model.term 22 = lit68 := model.var_eq 22 2 (by rfl)
theorem sub21 : model.term 21 = lit67 := by rw [model.app_eq 21 22 23 (by rfl), sub22, sub23]; rfl
theorem sub20 : model.term 20 = lit66 := by rw [model.lam_eq 20 21 (by rfl), sub21]; rfl
theorem sub19 : model.term 19 = lit65 := by rw [model.lam_eq 19 20 (by rfl), sub20]; rfl
theorem sub18 : model.term 18 = lit184 := model.var_eq 18 0 (by rfl)
theorem sub17 : model.term 17 = lit63 := by rw [model.app_eq 17 18 19 (by rfl), sub18, sub19]; rfl
theorem sub16 : model.term 16 = lit62 := by rw [model.lam_eq 16 17 (by rfl), sub17]; rfl
theorem sub15 : model.term 15 = lit34 := by rw [model.app_eq 15 16 26 (by rfl), sub16, sub26]; rfl
theorem sub14 : model.term 14 = lit33 := by rw [model.lam_eq 14 15 (by rfl), sub15]; rfl
theorem sub13 : model.term 13 = lit32 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 29 (by rfl), sub13, sub29]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.app_eq 11 12 51 (by rfl), sub12, sub51]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.app_eq 10 11 72 (by rfl), sub11, sub72]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.app_eq 9 10 75 (by rfl), sub10, sub75]; rfl
theorem sub8 : model.term 8 = lit8 := by rw [model.app_eq 8 9 104 (by rfl), sub9, sub104]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.app_eq 7 8 113 (by rfl), sub8, sub113]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.app_eq 6 7 122 (by rfl), sub7, sub122]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 131 (by rfl), sub6, sub131]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 140 (by rfl), sub5, sub140]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 149 (by rfl), sub4, sub149]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 158 (by rfl), sub3, sub158]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 167 (by rfl), sub2, sub167]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 176 (by rfl), sub1, sub176]; rfl
theorem allValid (i : Nat) (h : i < 1611) : validState i = true := by
 by_cases h804 : i < 804
 · by_cases h396 : i < 396
   · by_cases h192 : i < 192
     · by_cases h96 : i < 96
       · by_cases h48 : i < 48
         · by_cases h24 : i < 24
           · by_cases h12 : i < 12
             · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
           · by_cases h36 : i < 36
             · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
         · by_cases h72 : i < 72
           · by_cases h60 : i < 60
             · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
           · by_cases h84 : i < 84
             · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
       · by_cases h144 : i < 144
         · by_cases h120 : i < 120
           · by_cases h108 : i < 108
             · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
           · by_cases h132 : i < 132
             · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
         · by_cases h168 : i < 168
           · by_cases h156 : i < 156
             · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
           · by_cases h180 : i < 180
             · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
     · by_cases h288 : i < 288
       · by_cases h240 : i < 240
         · by_cases h216 : i < 216
           · by_cases h204 : i < 204
             · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl204 (by omega) (by omega)
           · by_cases h228 : i < 228
             · exact FloorIndex.rangeOK_at bl216 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl228 (by omega) (by omega)
         · by_cases h264 : i < 264
           · by_cases h252 : i < 252
             · exact FloorIndex.rangeOK_at bl240 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl252 (by omega) (by omega)
           · by_cases h276 : i < 276
             · exact FloorIndex.rangeOK_at bl264 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl276 (by omega) (by omega)
       · by_cases h336 : i < 336
         · by_cases h312 : i < 312
           · by_cases h300 : i < 300
             · exact FloorIndex.rangeOK_at bl288 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl300 (by omega) (by omega)
           · by_cases h324 : i < 324
             · exact FloorIndex.rangeOK_at bl312 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl324 (by omega) (by omega)
         · by_cases h360 : i < 360
           · by_cases h348 : i < 348
             · exact FloorIndex.rangeOK_at bl336 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl348 (by omega) (by omega)
           · by_cases h372 : i < 372
             · exact FloorIndex.rangeOK_at bl360 (by omega) (by omega)
             · by_cases h384 : i < 384
               · exact FloorIndex.rangeOK_at bl372 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl384 (by omega) (by omega)
   · by_cases h600 : i < 600
     · by_cases h492 : i < 492
       · by_cases h444 : i < 444
         · by_cases h420 : i < 420
           · by_cases h408 : i < 408
             · exact FloorIndex.rangeOK_at bl396 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl408 (by omega) (by omega)
           · by_cases h432 : i < 432
             · exact FloorIndex.rangeOK_at bl420 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl432 (by omega) (by omega)
         · by_cases h468 : i < 468
           · by_cases h456 : i < 456
             · exact FloorIndex.rangeOK_at bl444 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl456 (by omega) (by omega)
           · by_cases h480 : i < 480
             · exact FloorIndex.rangeOK_at bl468 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl480 (by omega) (by omega)
       · by_cases h540 : i < 540
         · by_cases h516 : i < 516
           · by_cases h504 : i < 504
             · exact FloorIndex.rangeOK_at bl492 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl504 (by omega) (by omega)
           · by_cases h528 : i < 528
             · exact FloorIndex.rangeOK_at bl516 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl528 (by omega) (by omega)
         · by_cases h564 : i < 564
           · by_cases h552 : i < 552
             · exact FloorIndex.rangeOK_at bl540 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl552 (by omega) (by omega)
           · by_cases h576 : i < 576
             · exact FloorIndex.rangeOK_at bl564 (by omega) (by omega)
             · by_cases h588 : i < 588
               · exact FloorIndex.rangeOK_at bl576 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl588 (by omega) (by omega)
     · by_cases h696 : i < 696
       · by_cases h648 : i < 648
         · by_cases h624 : i < 624
           · by_cases h612 : i < 612
             · exact FloorIndex.rangeOK_at bl600 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl612 (by omega) (by omega)
           · by_cases h636 : i < 636
             · exact FloorIndex.rangeOK_at bl624 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl636 (by omega) (by omega)
         · by_cases h672 : i < 672
           · by_cases h660 : i < 660
             · exact FloorIndex.rangeOK_at bl648 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl660 (by omega) (by omega)
           · by_cases h684 : i < 684
             · exact FloorIndex.rangeOK_at bl672 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl684 (by omega) (by omega)
       · by_cases h744 : i < 744
         · by_cases h720 : i < 720
           · by_cases h708 : i < 708
             · exact FloorIndex.rangeOK_at bl696 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl708 (by omega) (by omega)
           · by_cases h732 : i < 732
             · exact FloorIndex.rangeOK_at bl720 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl732 (by omega) (by omega)
         · by_cases h768 : i < 768
           · by_cases h756 : i < 756
             · exact FloorIndex.rangeOK_at bl744 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl756 (by omega) (by omega)
           · by_cases h780 : i < 780
             · exact FloorIndex.rangeOK_at bl768 (by omega) (by omega)
             · by_cases h792 : i < 792
               · exact FloorIndex.rangeOK_at bl780 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl792 (by omega) (by omega)
 · by_cases h1212 : i < 1212
   · by_cases h1008 : i < 1008
     · by_cases h900 : i < 900
       · by_cases h852 : i < 852
         · by_cases h828 : i < 828
           · by_cases h816 : i < 816
             · exact FloorIndex.rangeOK_at bl804 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl816 (by omega) (by omega)
           · by_cases h840 : i < 840
             · exact FloorIndex.rangeOK_at bl828 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl840 (by omega) (by omega)
         · by_cases h876 : i < 876
           · by_cases h864 : i < 864
             · exact FloorIndex.rangeOK_at bl852 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl864 (by omega) (by omega)
           · by_cases h888 : i < 888
             · exact FloorIndex.rangeOK_at bl876 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl888 (by omega) (by omega)
       · by_cases h948 : i < 948
         · by_cases h924 : i < 924
           · by_cases h912 : i < 912
             · exact FloorIndex.rangeOK_at bl900 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl912 (by omega) (by omega)
           · by_cases h936 : i < 936
             · exact FloorIndex.rangeOK_at bl924 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl936 (by omega) (by omega)
         · by_cases h972 : i < 972
           · by_cases h960 : i < 960
             · exact FloorIndex.rangeOK_at bl948 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl960 (by omega) (by omega)
           · by_cases h984 : i < 984
             · exact FloorIndex.rangeOK_at bl972 (by omega) (by omega)
             · by_cases h996 : i < 996
               · exact FloorIndex.rangeOK_at bl984 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl996 (by omega) (by omega)
     · by_cases h1104 : i < 1104
       · by_cases h1056 : i < 1056
         · by_cases h1032 : i < 1032
           · by_cases h1020 : i < 1020
             · exact FloorIndex.rangeOK_at bl1008 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1020 (by omega) (by omega)
           · by_cases h1044 : i < 1044
             · exact FloorIndex.rangeOK_at bl1032 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1044 (by omega) (by omega)
         · by_cases h1080 : i < 1080
           · by_cases h1068 : i < 1068
             · exact FloorIndex.rangeOK_at bl1056 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1068 (by omega) (by omega)
           · by_cases h1092 : i < 1092
             · exact FloorIndex.rangeOK_at bl1080 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1092 (by omega) (by omega)
       · by_cases h1152 : i < 1152
         · by_cases h1128 : i < 1128
           · by_cases h1116 : i < 1116
             · exact FloorIndex.rangeOK_at bl1104 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1116 (by omega) (by omega)
           · by_cases h1140 : i < 1140
             · exact FloorIndex.rangeOK_at bl1128 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1140 (by omega) (by omega)
         · by_cases h1176 : i < 1176
           · by_cases h1164 : i < 1164
             · exact FloorIndex.rangeOK_at bl1152 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1164 (by omega) (by omega)
           · by_cases h1188 : i < 1188
             · exact FloorIndex.rangeOK_at bl1176 (by omega) (by omega)
             · by_cases h1200 : i < 1200
               · exact FloorIndex.rangeOK_at bl1188 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1200 (by omega) (by omega)
   · by_cases h1416 : i < 1416
     · by_cases h1308 : i < 1308
       · by_cases h1260 : i < 1260
         · by_cases h1236 : i < 1236
           · by_cases h1224 : i < 1224
             · exact FloorIndex.rangeOK_at bl1212 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1224 (by omega) (by omega)
           · by_cases h1248 : i < 1248
             · exact FloorIndex.rangeOK_at bl1236 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1248 (by omega) (by omega)
         · by_cases h1284 : i < 1284
           · by_cases h1272 : i < 1272
             · exact FloorIndex.rangeOK_at bl1260 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1272 (by omega) (by omega)
           · by_cases h1296 : i < 1296
             · exact FloorIndex.rangeOK_at bl1284 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1296 (by omega) (by omega)
       · by_cases h1356 : i < 1356
         · by_cases h1332 : i < 1332
           · by_cases h1320 : i < 1320
             · exact FloorIndex.rangeOK_at bl1308 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1320 (by omega) (by omega)
           · by_cases h1344 : i < 1344
             · exact FloorIndex.rangeOK_at bl1332 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1344 (by omega) (by omega)
         · by_cases h1380 : i < 1380
           · by_cases h1368 : i < 1368
             · exact FloorIndex.rangeOK_at bl1356 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1368 (by omega) (by omega)
           · by_cases h1392 : i < 1392
             · exact FloorIndex.rangeOK_at bl1380 (by omega) (by omega)
             · by_cases h1404 : i < 1404
               · exact FloorIndex.rangeOK_at bl1392 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1404 (by omega) (by omega)
     · by_cases h1512 : i < 1512
       · by_cases h1464 : i < 1464
         · by_cases h1440 : i < 1440
           · by_cases h1428 : i < 1428
             · exact FloorIndex.rangeOK_at bl1416 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1428 (by omega) (by omega)
           · by_cases h1452 : i < 1452
             · exact FloorIndex.rangeOK_at bl1440 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1452 (by omega) (by omega)
         · by_cases h1488 : i < 1488
           · by_cases h1476 : i < 1476
             · exact FloorIndex.rangeOK_at bl1464 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1476 (by omega) (by omega)
           · by_cases h1500 : i < 1500
             · exact FloorIndex.rangeOK_at bl1488 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1500 (by omega) (by omega)
       · by_cases h1560 : i < 1560
         · by_cases h1536 : i < 1536
           · by_cases h1524 : i < 1524
             · exact FloorIndex.rangeOK_at bl1512 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1524 (by omega) (by omega)
           · by_cases h1548 : i < 1548
             · exact FloorIndex.rangeOK_at bl1536 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1548 (by omega) (by omega)
         · by_cases h1584 : i < 1584
           · by_cases h1572 : i < 1572
             · exact FloorIndex.rangeOK_at bl1560 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1572 (by omega) (by omega)
           · by_cases h1596 : i < 1596
             · exact FloorIndex.rangeOK_at bl1584 (by omega) (by omega)
             · by_cases h1608 : i < 1608
               · exact FloorIndex.rangeOK_at bl1596 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1608 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 1611
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e598293090102 := by
 intro he
 have hp : replay [[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] (call e598293090102 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R598293090102
