import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605792431226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605792431226 : Closed e605792431226 ∧ code e605792431226 = 2804815686778 := by decide
private def t_e605792431226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem cert_e605792431226 : ¬ IsSelfInterpreter e605792431226 :=
  wSource (t := t_e605792431226) (replay_sound (ps := []) (t := e605792431226) (by decide)) (by decide)
def e605792431390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605792431390 : Closed e605792431390 ∧ code e605792431390 = 2804815686942 := by decide
private def t_e605792431390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem cert_e605792431390 : ¬ IsSelfInterpreter e605792431390 :=
  wSource (t := t_e605792431390) (replay_sound (ps := []) (t := e605792431390) (by decide)) (by decide)
def e605792431558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605792431558 : Closed e605792431558 ∧ code e605792431558 = 2804815687110 := by decide
private def t_e605792431558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem cert_e605792431558 : ¬ IsSelfInterpreter e605792431558 :=
  wSource (t := t_e605792431558) (replay_sound (ps := []) (t := e605792431558) (by decide)) (by decide)
def e605792431626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605792431626 : Closed e605792431626 ∧ code e605792431626 = 2804815687178 := by decide
private def t_e605792431626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem cert_e605792431626 : ¬ IsSelfInterpreter e605792431626 :=
  wSource (t := t_e605792431626) (replay_sound (ps := []) (t := e605792431626) (by decide)) (by decide)
def e605792431670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605792431670 : Closed e605792431670 ∧ code e605792431670 = 2804815687222 := by decide
private def t_e605792431670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem cert_e605792431670 : ¬ IsSelfInterpreter e605792431670 :=
  wSource (t := t_e605792431670) (replay_sound (ps := []) (t := e605792431670) (by decide)) (by decide)
def e605792431674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605792431674 : Closed e605792431674 ∧ code e605792431674 = 2804815687226 := by decide
private def t_e605792431674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem cert_e605792431674 : ¬ IsSelfInterpreter e605792431674 :=
  wSource (t := t_e605792431674) (replay_sound (ps := []) (t := e605792431674) (by decide)) (by decide)
def e605792431722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605792431722 : Closed e605792431722 ∧ code e605792431722 = 2804815687274 := by decide
private def t_e605792431722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem cert_e605792431722 : ¬ IsSelfInterpreter e605792431722 :=
  wSource (t := t_e605792431722) (replay_sound (ps := []) (t := e605792431722) (by decide)) (by decide)
def e605792431746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605792431746 : Closed e605792431746 ∧ code e605792431746 = 2804815687298 := by decide
private def t_e605792431746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem cert_e605792431746 : ¬ IsSelfInterpreter e605792431746 :=
  wSource (t := t_e605792431746) (replay_sound (ps := []) (t := e605792431746) (by decide)) (by decide)
def e605792431758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605792431758 : Closed e605792431758 ∧ code e605792431758 = 2804815687310 := by decide
private def t_e605792431758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem cert_e605792431758 : ¬ IsSelfInterpreter e605792431758 :=
  wSource (t := t_e605792431758) (replay_sound (ps := []) (t := e605792431758) (by decide)) (by decide)
def e605792431770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605792431770 : Closed e605792431770 ∧ code e605792431770 = 2804815687322 := by decide
private def t_e605792431770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem cert_e605792431770 : ¬ IsSelfInterpreter e605792431770 :=
  wSource (t := t_e605792431770) (replay_sound (ps := []) (t := e605792431770) (by decide)) (by decide)
def e605792431814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605792431814 : Closed e605792431814 ∧ code e605792431814 = 2804815687366 := by decide
private def t_e605792431814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem cert_e605792431814 : ¬ IsSelfInterpreter e605792431814 :=
  wSource (t := t_e605792431814) (replay_sound (ps := []) (t := e605792431814) (by decide)) (by decide)
def e605792432214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605792432214 : Closed e605792432214 ∧ code e605792432214 = 2804815687766 := by decide
theorem cert_e605792432214 : check e605792432214 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e605792432218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605792432218 : Closed e605792432218 ∧ code e605792432218 = 2804815687770 := by decide
theorem cert_e605792432218 : check e605792432218 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e605792432566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e605792432566 : Closed e605792432566 ∧ code e605792432566 = 2804815688118 := by decide
theorem cert_e605792432566 : check e605792432566 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792432598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605792432598 : Closed e605792432598 ∧ code e605792432598 = 2804815688150 := by decide
theorem cert_e605792432598 : check e605792432598 [[],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e605792432602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605792432602 : Closed e605792432602 ∧ code e605792432602 = 2804815688154 := by decide
def e605792432982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605792432982 : Closed e605792432982 ∧ code e605792432982 = 2804815688534 := by decide
theorem cert_e605792432982 : check e605792432982 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792432986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605792432986 : Closed e605792432986 ∧ code e605792432986 = 2804815688538 := by decide
theorem cert_e605792432986 : check e605792432986 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605792433002 : Closed e605792433002 ∧ code e605792433002 = 2804815688554 := by decide
theorem cert_e605792433002 : check e605792433002 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605792433066 : Closed e605792433066 ∧ code e605792433066 = 2804815688618 := by decide
def e605792433174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605792433174 : Closed e605792433174 ∧ code e605792433174 = 2804815688726 := by decide
theorem cert_e605792433174 : check e605792433174 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e605792433270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605792433270 : Closed e605792433270 ∧ code e605792433270 = 2804815688822 := by decide
theorem cert_e605792433270 : check e605792433270 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605792433366 : Closed e605792433366 ∧ code e605792433366 = 2804815688918 := by decide
theorem cert_e605792433366 : check e605792433366 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605792433370 : Closed e605792433370 ∧ code e605792433370 = 2804815688922 := by decide
theorem cert_e605792433370 : check e605792433370 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605792433386 : Closed e605792433386 ∧ code e605792433386 = 2804815688938 := by decide
theorem cert_e605792433386 : check e605792433386 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605792433462 : Closed e605792433462 ∧ code e605792433462 = 2804815689014 := by decide
theorem cert_e605792433462 : check e605792433462 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605792433466 : Closed e605792433466 ∧ code e605792433466 = 2804815689018 := by decide
theorem cert_e605792433466 : check e605792433466 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605792433538 : Closed e605792433538 ∧ code e605792433538 = 2804815689090 := by decide
theorem cert_e605792433538 : check e605792433538 [[],[],[],[],[.under,.left,.left]] .chain = true := by decide
def e605792433550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605792433550 : Closed e605792433550 ∧ code e605792433550 = 2804815689102 := by decide
theorem cert_e605792433550 : check e605792433550 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605792433562 : Closed e605792433562 ∧ code e605792433562 = 2804815689114 := by decide
theorem cert_e605792433562 : check e605792433562 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e605792433674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605792433674 : Closed e605792433674 ∧ code e605792433674 = 2804815689226 := by decide
private def t_e605792433674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem cert_e605792433674 : ¬ IsSelfInterpreter e605792433674 :=
  wSource (t := t_e605792433674) (replay_sound (ps := []) (t := e605792433674) (by decide)) (by decide)
def e605792433718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605792433718 : Closed e605792433718 ∧ code e605792433718 = 2804815689270 := by decide
private def t_e605792433718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem cert_e605792433718 : ¬ IsSelfInterpreter e605792433718 :=
  wSource (t := t_e605792433718) (replay_sound (ps := []) (t := e605792433718) (by decide)) (by decide)
def e605792433722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605792433722 : Closed e605792433722 ∧ code e605792433722 = 2804815689274 := by decide
private def t_e605792433722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem cert_e605792433722 : ¬ IsSelfInterpreter e605792433722 :=
  wSource (t := t_e605792433722) (replay_sound (ps := []) (t := e605792433722) (by decide)) (by decide)
def e605792433770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605792433770 : Closed e605792433770 ∧ code e605792433770 = 2804815689322 := by decide
private def t_e605792433770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem cert_e605792433770 : ¬ IsSelfInterpreter e605792433770 :=
  wSource (t := t_e605792433770) (replay_sound (ps := []) (t := e605792433770) (by decide)) (by decide)
def e605792433794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605792433794 : Closed e605792433794 ∧ code e605792433794 = 2804815689346 := by decide
private def t_e605792433794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem cert_e605792433794 : ¬ IsSelfInterpreter e605792433794 :=
  wSource (t := t_e605792433794) (replay_sound (ps := []) (t := e605792433794) (by decide)) (by decide)
def e605792433806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605792433806 : Closed e605792433806 ∧ code e605792433806 = 2804815689358 := by decide
private def t_e605792433806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem cert_e605792433806 : ¬ IsSelfInterpreter e605792433806 :=
  wSource (t := t_e605792433806) (replay_sound (ps := []) (t := e605792433806) (by decide)) (by decide)
def e605792433818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605792433818 : Closed e605792433818 ∧ code e605792433818 = 2804815689370 := by decide
private def t_e605792433818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem cert_e605792433818 : ¬ IsSelfInterpreter e605792433818 :=
  wSource (t := t_e605792433818) (replay_sound (ps := []) (t := e605792433818) (by decide)) (by decide)
def e605792433862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605792433862 : Closed e605792433862 ∧ code e605792433862 = 2804815689414 := by decide
private def t_e605792433862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem cert_e605792433862 : ¬ IsSelfInterpreter e605792433862 :=
  wSource (t := t_e605792433862) (replay_sound (ps := []) (t := e605792433862) (by decide)) (by decide)
def e605792437486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e605792437486 : Closed e605792437486 ∧ code e605792437486 = 2804815693038 := by decide
theorem cert_e605792437486 : check e605792437486 [[],[],[],[]] .sourceHead = true := by decide
def e605792437494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e605792437494 : Closed e605792437494 ∧ code e605792437494 = 2804815693046 := by decide
theorem cert_e605792437494 : check e605792437494 [[],[],[],[]] .sourceHead = true := by decide
def e605792440046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e605792440046 : Closed e605792440046 ∧ code e605792440046 = 2804815695598 := by decide
theorem cert_e605792440046 : check e605792440046 [[],[],[],[]] .sourceHead = true := by decide
def e605792440054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605792440054 : Closed e605792440054 ∧ code e605792440054 = 2804815695606 := by decide
theorem cert_e605792440054 : check e605792440054 [[],[],[],[]] .sourceHead = true := by decide
def e605792440174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e605792440174 : Closed e605792440174 ∧ code e605792440174 = 2804815695726 := by decide
theorem cert_e605792440174 : check e605792440174 [[],[],[],[]] .sourceHead = true := by decide
def e605792440186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e605792440186 : Closed e605792440186 ∧ code e605792440186 = 2804815695738 := by decide
theorem cert_e605792440186 : check e605792440186 [[],[],[],[]] .sourceHead = true := by decide
def e605792440246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605792440246 : Closed e605792440246 ∧ code e605792440246 = 2804815695798 := by decide
theorem cert_e605792440246 : check e605792440246 [[],[],[],[]] .sourceHead = true := by decide
def e605792440250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e605792440250 : Closed e605792440250 ∧ code e605792440250 = 2804815695802 := by decide
theorem cert_e605792440250 : check e605792440250 [[],[],[],[]] .sourceHead = true := by decide
def e605792443630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e605792443630 : Closed e605792443630 ∧ code e605792443630 = 2804815699182 := by decide
theorem cert_e605792443630 : check e605792443630 [[],[],[],[]] .sourceHead = true := by decide
def e605792443638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e605792443638 : Closed e605792443638 ∧ code e605792443638 = 2804815699190 := by decide
theorem cert_e605792443638 : check e605792443638 [[],[],[],[]] .sourceHead = true := by decide
def e605792444022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e605792444022 : Closed e605792444022 ∧ code e605792444022 = 2804815699574 := by decide
theorem cert_e605792444022 : check e605792444022 [[],[],[],[]] .sourceHead = true := by decide
def e605792447854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605792447854 : Closed e605792447854 ∧ code e605792447854 = 2804815703406 := by decide
theorem cert_e605792447854 : check e605792447854 [[],[],[],[]] .sourceHead = true := by decide
def e605792447862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605792447862 : Closed e605792447862 ∧ code e605792447862 = 2804815703414 := by decide
theorem cert_e605792447862 : check e605792447862 [[],[],[],[]] .sourceHead = true := by decide
def e605792447918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605792447918 : Closed e605792447918 ∧ code e605792447918 = 2804815703470 := by decide
theorem cert_e605792447918 : check e605792447918 [[],[],[],[]] .sourceHead = true := by decide
def e605792447930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605792447930 : Closed e605792447930 ∧ code e605792447930 = 2804815703482 := by decide
theorem cert_e605792447930 : check e605792447930 [[],[],[],[]] .sourceHead = true := by decide
def e605792447958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605792447958 : Closed e605792447958 ∧ code e605792447958 = 2804815703510 := by decide
theorem cert_e605792447958 : check e605792447958 [[],[],[],[]] .sourceHead = true := by decide
def e605792447962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605792447962 : Closed e605792447962 ∧ code e605792447962 = 2804815703514 := by decide
theorem cert_e605792447962 : check e605792447962 [[],[],[],[]] .sourceHead = true := by decide
def e605792448174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605792448174 : Closed e605792448174 ∧ code e605792448174 = 2804815703726 := by decide
theorem cert_e605792448174 : check e605792448174 [[],[],[],[]] .sourceHead = true := by decide
def e605792448186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605792448186 : Closed e605792448186 ∧ code e605792448186 = 2804815703738 := by decide
theorem cert_e605792448186 : check e605792448186 [[],[],[],[]] .sourceHead = true := by decide
def e605792448234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605792448234 : Closed e605792448234 ∧ code e605792448234 = 2804815703786 := by decide
theorem cert_e605792448234 : check e605792448234 [[],[],[],[]] .sourceHead = true := by decide
def e605792448342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605792448342 : Closed e605792448342 ∧ code e605792448342 = 2804815703894 := by decide
theorem cert_e605792448342 : check e605792448342 [[],[],[],[]] .sourceHead = true := by decide
def e605792448346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605792448346 : Closed e605792448346 ∧ code e605792448346 = 2804815703898 := by decide
theorem cert_e605792448346 : check e605792448346 [[],[],[],[]] .sourceHead = true := by decide
def e605792448362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605792448362 : Closed e605792448362 ∧ code e605792448362 = 2804815703914 := by decide
theorem cert_e605792448362 : check e605792448362 [[],[],[],[]] .sourceHead = true := by decide
def e605792449390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605792449390 : Closed e605792449390 ∧ code e605792449390 = 2804815704942 := by decide
theorem cert_e605792449390 : check e605792449390 [[],[],[],[]] .sourceHead = true := by decide
def e605792449398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605792449398 : Closed e605792449398 ∧ code e605792449398 = 2804815704950 := by decide
theorem cert_e605792449398 : check e605792449398 [[],[],[],[]] .sourceHead = true := by decide
def e605792449454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605792449454 : Closed e605792449454 ∧ code e605792449454 = 2804815705006 := by decide
theorem cert_e605792449454 : check e605792449454 [[],[],[],[]] .sourceHead = true := by decide
def e605792449466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605792449466 : Closed e605792449466 ∧ code e605792449466 = 2804815705018 := by decide
theorem cert_e605792449466 : check e605792449466 [[],[],[],[]] .sourceHead = true := by decide
def e605792449494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605792449494 : Closed e605792449494 ∧ code e605792449494 = 2804815705046 := by decide
theorem cert_e605792449494 : check e605792449494 [[],[],[],[]] .sourceHead = true := by decide
def e605792449498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605792449498 : Closed e605792449498 ∧ code e605792449498 = 2804815705050 := by decide
theorem cert_e605792449498 : check e605792449498 [[],[],[],[]] .sourceHead = true := by decide
def e605792449774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605792449774 : Closed e605792449774 ∧ code e605792449774 = 2804815705326 := by decide
theorem cert_e605792449774 : check e605792449774 [[],[],[],[]] .sourceHead = true := by decide
def e605792449782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605792449782 : Closed e605792449782 ∧ code e605792449782 = 2804815705334 := by decide
theorem cert_e605792449782 : check e605792449782 [[],[],[],[]] .sourceHead = true := by decide
def e605792450158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605792450158 : Closed e605792450158 ∧ code e605792450158 = 2804815705710 := by decide
theorem cert_e605792450158 : check e605792450158 [[],[],[],[]] .sourceHead = true := by decide
def e605792450170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605792450170 : Closed e605792450170 ∧ code e605792450170 = 2804815705722 := by decide
theorem cert_e605792450170 : check e605792450170 [[],[],[],[]] .sourceHead = true := by decide
def e605792450358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605792450358 : Closed e605792450358 ∧ code e605792450358 = 2804815705910 := by decide
theorem cert_e605792450358 : check e605792450358 [[],[],[],[]] .sourceHead = true := by decide
def e605792450362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605792450362 : Closed e605792450362 ∧ code e605792450362 = 2804815705914 := by decide
theorem cert_e605792450362 : check e605792450362 [[],[],[],[]] .sourceHead = true := by decide
def e605792450606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605792450606 : Closed e605792450606 ∧ code e605792450606 = 2804815706158 := by decide
theorem cert_e605792450606 : check e605792450606 [[],[],[],[]] .sourceHead = true := by decide
def e605792450798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605792450798 : Closed e605792450798 ∧ code e605792450798 = 2804815706350 := by decide
theorem cert_e605792450798 : check e605792450798 [[],[],[],[]] .sourceHead = true := by decide
def e605792450806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605792450806 : Closed e605792450806 ∧ code e605792450806 = 2804815706358 := by decide
theorem cert_e605792450806 : check e605792450806 [[],[],[],[]] .sourceHead = true := by decide
def e605792450990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605792450990 : Closed e605792450990 ∧ code e605792450990 = 2804815706542 := by decide
theorem cert_e605792450990 : check e605792450990 [[],[],[],[]] .sourceHead = true := by decide
def e605792451002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605792451002 : Closed e605792451002 ∧ code e605792451002 = 2804815706554 := by decide
theorem cert_e605792451002 : check e605792451002 [[],[],[],[]] .sourceHead = true := by decide
def e605792451050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605792451050 : Closed e605792451050 ∧ code e605792451050 = 2804815706602 := by decide
theorem cert_e605792451050 : check e605792451050 [[],[],[],[]] .sourceHead = true := by decide
def e605792451182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605792451182 : Closed e605792451182 ∧ code e605792451182 = 2804815706734 := by decide
theorem cert_e605792451182 : check e605792451182 [[],[],[],[]] .sourceHead = true := by decide
def e605792451194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605792451194 : Closed e605792451194 ∧ code e605792451194 = 2804815706746 := by decide
theorem cert_e605792451194 : check e605792451194 [[],[],[],[]] .sourceHead = true := by decide
def e605792451358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605792451358 : Closed e605792451358 ∧ code e605792451358 = 2804815706910 := by decide
theorem cert_e605792451358 : check e605792451358 [[],[],[],[]] .sourceHead = true := by decide
def e605792451458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605792451458 : Closed e605792451458 ∧ code e605792451458 = 2804815707010 := by decide
theorem cert_e605792451458 : check e605792451458 [[],[],[],[]] .sourceHead = true := by decide
def e605792451470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605792451470 : Closed e605792451470 ∧ code e605792451470 = 2804815707022 := by decide
theorem cert_e605792451470 : check e605792451470 [[],[],[],[]] .sourceHead = true := by decide
def e605792451482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605792451482 : Closed e605792451482 ∧ code e605792451482 = 2804815707034 := by decide
theorem cert_e605792451482 : check e605792451482 [[],[],[],[]] .sourceHead = true := by decide
def e605792451606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605792451606 : Closed e605792451606 ∧ code e605792451606 = 2804815707158 := by decide
theorem cert_e605792451606 : check e605792451606 [[],[],[],[]] .sourceHead = true := by decide
def e605792451702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605792451702 : Closed e605792451702 ∧ code e605792451702 = 2804815707254 := by decide
theorem cert_e605792451702 : check e605792451702 [[],[],[],[]] .sourceHead = true := by decide
def e605792451798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605792451798 : Closed e605792451798 ∧ code e605792451798 = 2804815707350 := by decide
theorem cert_e605792451798 : check e605792451798 [[],[],[],[]] .sourceHead = true := by decide
def e605792451802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605792451802 : Closed e605792451802 ∧ code e605792451802 = 2804815707354 := by decide
theorem cert_e605792451802 : check e605792451802 [[],[],[],[]] .sourceHead = true := by decide
def e605792451818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605792451818 : Closed e605792451818 ∧ code e605792451818 = 2804815707370 := by decide
theorem cert_e605792451818 : check e605792451818 [[],[],[],[]] .sourceHead = true := by decide
def e605792451894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605792451894 : Closed e605792451894 ∧ code e605792451894 = 2804815707446 := by decide
theorem cert_e605792451894 : check e605792451894 [[],[],[],[]] .sourceHead = true := by decide
def e605792451898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605792451898 : Closed e605792451898 ∧ code e605792451898 = 2804815707450 := by decide
theorem cert_e605792451898 : check e605792451898 [[],[],[],[]] .sourceHead = true := by decide
def e605792451970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605792451970 : Closed e605792451970 ∧ code e605792451970 = 2804815707522 := by decide
theorem cert_e605792451970 : check e605792451970 [[],[],[],[]] .sourceHead = true := by decide
def e605792451982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605792451982 : Closed e605792451982 ∧ code e605792451982 = 2804815707534 := by decide
theorem cert_e605792451982 : check e605792451982 [[],[],[],[]] .sourceHead = true := by decide
def e605792451994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605792451994 : Closed e605792451994 ∧ code e605792451994 = 2804815707546 := by decide
theorem cert_e605792451994 : check e605792451994 [[],[],[],[]] .sourceHead = true := by decide
def e605792453598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605792453598 : Closed e605792453598 ∧ code e605792453598 = 2804815709150 := by decide
theorem cert_e605792453598 : check e605792453598 [[],[],[],[]] .sourceHead = true := by decide
def e605792453614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605792453614 : Closed e605792453614 ∧ code e605792453614 = 2804815709166 := by decide
theorem cert_e605792453614 : check e605792453614 [[],[],[],[]] .sourceHead = true := by decide
def e605792455534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605792455534 : Closed e605792455534 ∧ code e605792455534 = 2804815711086 := by decide
theorem cert_e605792455534 : check e605792455534 [[],[],[],[]] .sourceHead = true := by decide
def e605792455542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605792455542 : Closed e605792455542 ∧ code e605792455542 = 2804815711094 := by decide
theorem cert_e605792455542 : check e605792455542 [[],[],[],[]] .sourceHead = true := by decide
def e605792455598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605792455598 : Closed e605792455598 ∧ code e605792455598 = 2804815711150 := by decide
theorem cert_e605792455598 : check e605792455598 [[],[],[],[]] .sourceHead = true := by decide
def e605792455610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605792455610 : Closed e605792455610 ∧ code e605792455610 = 2804815711162 := by decide
theorem cert_e605792455610 : check e605792455610 [[],[],[],[]] .sourceHead = true := by decide
def e605792455638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605792455638 : Closed e605792455638 ∧ code e605792455638 = 2804815711190 := by decide
theorem cert_e605792455638 : check e605792455638 [[],[],[],[]] .sourceHead = true := by decide
def e605792455642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605792455642 : Closed e605792455642 ∧ code e605792455642 = 2804815711194 := by decide
theorem cert_e605792455642 : check e605792455642 [[],[],[],[]] .sourceHead = true := by decide
def e605792455918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605792455918 : Closed e605792455918 ∧ code e605792455918 = 2804815711470 := by decide
theorem cert_e605792455918 : check e605792455918 [[],[],[],[]] .sourceHead = true := by decide
def e605792455926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605792455926 : Closed e605792455926 ∧ code e605792455926 = 2804815711478 := by decide
theorem cert_e605792455926 : check e605792455926 [[],[],[],[]] .sourceHead = true := by decide
def e605792456302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605792456302 : Closed e605792456302 ∧ code e605792456302 = 2804815711854 := by decide
theorem cert_e605792456302 : check e605792456302 [[],[],[],[]] .sourceHead = true := by decide
def e605792456314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605792456314 : Closed e605792456314 ∧ code e605792456314 = 2804815711866 := by decide
theorem cert_e605792456314 : check e605792456314 [[],[],[],[]] .sourceHead = true := by decide
def e605792456502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605792456502 : Closed e605792456502 ∧ code e605792456502 = 2804815712054 := by decide
theorem cert_e605792456502 : check e605792456502 [[],[],[],[]] .sourceHead = true := by decide
def e605792456506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605792456506 : Closed e605792456506 ∧ code e605792456506 = 2804815712058 := by decide
theorem cert_e605792456506 : check e605792456506 [[],[],[],[]] .sourceHead = true := by decide
def e605792461278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605792461278 : Closed e605792461278 ∧ code e605792461278 = 2804815716830 := by decide
theorem cert_e605792461278 : check e605792461278 [[],[],[],[]] .sourceHead = true := by decide
def e605792461302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605792461302 : Closed e605792461302 ∧ code e605792461302 = 2804815716854 := by decide
theorem cert_e605792461302 : check e605792461302 [[],[],[],[]] .sourceHead = true := by decide
def e605792462254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605792462254 : Closed e605792462254 ∧ code e605792462254 = 2804815717806 := by decide
theorem cert_e605792462254 : check e605792462254 [[],[],[],[]] .sourceHead = true := by decide
def e605792462266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605792462266 : Closed e605792462266 ∧ code e605792462266 = 2804815717818 := by decide
theorem cert_e605792462266 : check e605792462266 [[],[],[],[]] .sourceHead = true := by decide
def e605792462314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605792462314 : Closed e605792462314 ∧ code e605792462314 = 2804815717866 := by decide
theorem cert_e605792462314 : check e605792462314 [[],[],[],[]] .sourceHead = true := by decide
def e605792462446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605792462446 : Closed e605792462446 ∧ code e605792462446 = 2804815717998 := by decide
theorem cert_e605792462446 : check e605792462446 [[],[],[],[]] .sourceHead = true := by decide
def e605792462458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605792462458 : Closed e605792462458 ∧ code e605792462458 = 2804815718010 := by decide
theorem cert_e605792462458 : check e605792462458 [[],[],[],[]] .sourceHead = true := by decide
def e605792462622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605792462622 : Closed e605792462622 ∧ code e605792462622 = 2804815718174 := by decide
theorem cert_e605792462622 : check e605792462622 [[],[],[],[]] .sourceHead = true := by decide
def e605792462722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605792462722 : Closed e605792462722 ∧ code e605792462722 = 2804815718274 := by decide
theorem cert_e605792462722 : check e605792462722 [[],[],[],[]] .sourceHead = true := by decide
def e605792462734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605792462734 : Closed e605792462734 ∧ code e605792462734 = 2804815718286 := by decide
theorem cert_e605792462734 : check e605792462734 [[],[],[],[]] .sourceHead = true := by decide
def e605792462746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792462746 : Closed e605792462746 ∧ code e605792462746 = 2804815718298 := by decide
theorem cert_e605792462746 : check e605792462746 [[],[],[],[]] .sourceHead = true := by decide
def e605792465134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605792465134 : Closed e605792465134 ∧ code e605792465134 = 2804815720686 := by decide
theorem cert_e605792465134 : check e605792465134 [[],[],[],[]] .sourceHead = true := by decide
def e605792465142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605792465142 : Closed e605792465142 ∧ code e605792465142 = 2804815720694 := by decide
theorem cert_e605792465142 : check e605792465142 [[],[],[],[]] .sourceHead = true := by decide
def e605792465622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605792465622 : Closed e605792465622 ∧ code e605792465622 = 2804815721174 := by decide
theorem cert_e605792465622 : check e605792465622 [[],[],[],[]] .sourceHead = true := by decide
def e605792465626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605792465626 : Closed e605792465626 ∧ code e605792465626 = 2804815721178 := by decide
theorem cert_e605792465626 : check e605792465626 [[],[],[],[]] .sourceHead = true := by decide
def e605792465642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605792465642 : Closed e605792465642 ∧ code e605792465642 = 2804815721194 := by decide
theorem cert_e605792465642 : check e605792465642 [[],[],[],[]] .sourceHead = true := by decide
def e605792465718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605792465718 : Closed e605792465718 ∧ code e605792465718 = 2804815721270 := by decide
theorem cert_e605792465718 : check e605792465718 [[],[],[],[]] .sourceHead = true := by decide
def e605792465722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605792465722 : Closed e605792465722 ∧ code e605792465722 = 2804815721274 := by decide
theorem cert_e605792465722 : check e605792465722 [[],[],[],[]] .sourceHead = true := by decide
def e605792465794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605792465794 : Closed e605792465794 ∧ code e605792465794 = 2804815721346 := by decide
theorem cert_e605792465794 : check e605792465794 [[],[],[],[]] .sourceHead = true := by decide
def e605792465806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605792465806 : Closed e605792465806 ∧ code e605792465806 = 2804815721358 := by decide
theorem cert_e605792465806 : check e605792465806 [[],[],[],[]] .sourceHead = true := by decide
def e605792465818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792465818 : Closed e605792465818 ∧ code e605792465818 = 2804815721370 := by decide
theorem cert_e605792465818 : check e605792465818 [[],[],[],[]] .sourceHead = true := by decide
def e605792469614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605792469614 : Closed e605792469614 ∧ code e605792469614 = 2804815725166 := by decide
theorem cert_e605792469614 : check e605792469614 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792469626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605792469626 : Closed e605792469626 ∧ code e605792469626 = 2804815725178 := by decide
theorem cert_e605792469626 : check e605792469626 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605792470894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605792470894 : Closed e605792470894 ∧ code e605792470894 = 2804815726446 := by decide
theorem cert_e605792470894 : check e605792470894 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605792470906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605792470906 : Closed e605792470906 ∧ code e605792470906 = 2804815726458 := by decide
theorem cert_e605792470906 : check e605792470906 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605792471002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605792471002 : Closed e605792471002 ∧ code e605792471002 = 2804815726554 := by decide
theorem cert_e605792471002 : check e605792471002 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605792472302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605792472302 : Closed e605792472302 ∧ code e605792472302 = 2804815727854 := by decide
theorem cert_e605792472302 : check e605792472302 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605792472310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605792472310 : Closed e605792472310 ∧ code e605792472310 = 2804815727862 := by decide
theorem cert_e605792472310 : check e605792472310 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605792472686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605792472686 : Closed e605792472686 ∧ code e605792472686 = 2804815728238 := by decide
theorem cert_e605792472686 : check e605792472686 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792472698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605792472698 : Closed e605792472698 ∧ code e605792472698 = 2804815728250 := by decide
theorem cert_e605792472698 : check e605792472698 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792472886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605792472886 : Closed e605792472886 ∧ code e605792472886 = 2804815728438 := by decide
theorem cert_e605792472886 : check e605792472886 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792472890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605792472890 : Closed e605792472890 ∧ code e605792472890 = 2804815728442 := by decide
def e605792474798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605792474798 : Closed e605792474798 ∧ code e605792474798 = 2804815730350 := by decide
theorem cert_e605792474798 : check e605792474798 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792474810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605792474810 : Closed e605792474810 ∧ code e605792474810 = 2804815730362 := by decide
theorem cert_e605792474810 : check e605792474810 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792474858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605792474858 : Closed e605792474858 ∧ code e605792474858 = 2804815730410 := by decide
theorem cert_e605792474858 : check e605792474858 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605792475050 : Closed e605792475050 ∧ code e605792475050 = 2804815730602 := by decide
theorem cert_e605792475050 : check e605792475050 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792475182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605792475182 : Closed e605792475182 ∧ code e605792475182 = 2804815730734 := by decide
theorem cert_e605792475182 : check e605792475182 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605792475374 : Closed e605792475374 ∧ code e605792475374 = 2804815730926 := by decide
theorem cert_e605792475374 : check e605792475374 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605792475382 : Closed e605792475382 ∧ code e605792475382 = 2804815730934 := by decide
theorem cert_e605792475382 : check e605792475382 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605792475566 : Closed e605792475566 ∧ code e605792475566 = 2804815731118 := by decide
theorem cert_e605792475566 : check e605792475566 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605792475578 : Closed e605792475578 ∧ code e605792475578 = 2804815731130 := by decide
theorem cert_e605792475578 : check e605792475578 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605792475626 : Closed e605792475626 ∧ code e605792475626 = 2804815731178 := by decide
theorem cert_e605792475626 : check e605792475626 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605792475758 : Closed e605792475758 ∧ code e605792475758 = 2804815731310 := by decide
theorem cert_e605792475758 : check e605792475758 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605792475770 : Closed e605792475770 ∧ code e605792475770 = 2804815731322 := by decide
theorem cert_e605792475770 : check e605792475770 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792475934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605792475934 : Closed e605792475934 ∧ code e605792475934 = 2804815731486 := by decide
theorem cert_e605792475934 : check e605792475934 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792476034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605792476034 : Closed e605792476034 ∧ code e605792476034 = 2804815731586 := by decide
theorem cert_e605792476034 : check e605792476034 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792476046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605792476046 : Closed e605792476046 ∧ code e605792476046 = 2804815731598 := by decide
theorem cert_e605792476046 : check e605792476046 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792476058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605792476058 : Closed e605792476058 ∧ code e605792476058 = 2804815731610 := by decide
theorem cert_e605792476058 : check e605792476058 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792476270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605792476270 : Closed e605792476270 ∧ code e605792476270 = 2804815731822 := by decide
theorem cert_e605792476270 : check e605792476270 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792476282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605792476282 : Closed e605792476282 ∧ code e605792476282 = 2804815731834 := by decide
def e605792476446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605792476446 : Closed e605792476446 ∧ code e605792476446 = 2804815731998 := by decide
theorem cert_e605792476446 : check e605792476446 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
end Blc.Floor41
