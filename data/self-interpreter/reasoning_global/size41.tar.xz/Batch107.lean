import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602347130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605602347130 : Closed e605602347130 ∧ code e605602347130 = 2804625602682 := by decide
theorem cert_e605602347130 : check e605602347130 [[],[]] .chain = true := by decide
def e605602347370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605602347370 : Closed e605602347370 ∧ code e605602347370 = 2804625602922 := by decide
theorem cert_e605602347370 : check e605602347370 [[],[]] .chain = true := by decide
def e605602347394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605602347394 : Closed e605602347394 ∧ code e605602347394 = 2804625602946 := by decide
theorem cert_e605602347394 : check e605602347394 [[],[]] .chain = true := by decide
def e605602347406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605602347406 : Closed e605602347406 ∧ code e605602347406 = 2804625602958 := by decide
theorem cert_e605602347406 : check e605602347406 [[],[]] .chain = true := by decide
def e605602347418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602347418 : Closed e605602347418 ∧ code e605602347418 = 2804625602970 := by decide
theorem cert_e605602347418 : check e605602347418 [[],[]] .chain = true := by decide
def e605602347462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605602347462 : Closed e605602347462 ∧ code e605602347462 = 2804625603014 := by decide
theorem cert_e605602347462 : check e605602347462 [[],[]] .chain = true := by decide
def e605602347490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605602347490 : Closed e605602347490 ∧ code e605602347490 = 2804625603042 := by decide
theorem cert_e605602347490 : check e605602347490 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602347502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 2))))))))
theorem wire_e605602347502 : Closed e605602347502 ∧ code e605602347502 = 2804625603054 := by decide
theorem cert_e605602347502 : check e605602347502 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602382814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605602382814 : Closed e605602382814 ∧ code e605602382814 = 2804625638366 := by decide
theorem cert_e605602382814 : check e605602382814 [[],[]] .chain = true := by decide
def e605602382830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605602382830 : Closed e605602382830 ∧ code e605602382830 = 2804625638382 := by decide
theorem cert_e605602382830 : check e605602382830 [[],[]] .chain = true := by decide
def e605602384750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605602384750 : Closed e605602384750 ∧ code e605602384750 = 2804625640302 := by decide
theorem cert_e605602384750 : check e605602384750 [[],[]] .chain = true := by decide
def e605602384758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605602384758 : Closed e605602384758 ∧ code e605602384758 = 2804625640310 := by decide
theorem cert_e605602384758 : check e605602384758 [[],[]] .chain = true := by decide
def e605602384814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605602384814 : Closed e605602384814 ∧ code e605602384814 = 2804625640366 := by decide
theorem cert_e605602384814 : check e605602384814 [[],[]] .chain = true := by decide
def e605602384826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605602384826 : Closed e605602384826 ∧ code e605602384826 = 2804625640378 := by decide
theorem cert_e605602384826 : check e605602384826 [[],[]] .chain = true := by decide
def e605602384854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605602384854 : Closed e605602384854 ∧ code e605602384854 = 2804625640406 := by decide
theorem cert_e605602384854 : check e605602384854 [[],[]] .chain = true := by decide
def e605602384858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605602384858 : Closed e605602384858 ∧ code e605602384858 = 2804625640410 := by decide
theorem cert_e605602384858 : check e605602384858 [[],[]] .chain = true := by decide
def e605602385134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602385134 : Closed e605602385134 ∧ code e605602385134 = 2804625640686 := by decide
theorem cert_e605602385134 : check e605602385134 [[],[]] .chain = true := by decide
def e605602385142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602385142 : Closed e605602385142 ∧ code e605602385142 = 2804625640694 := by decide
theorem cert_e605602385142 : check e605602385142 [[],[]] .chain = true := by decide
def e605602385518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602385518 : Closed e605602385518 ∧ code e605602385518 = 2804625641070 := by decide
theorem cert_e605602385518 : check e605602385518 [[],[]] .chain = true := by decide
def e605602385530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602385530 : Closed e605602385530 ∧ code e605602385530 = 2804625641082 := by decide
theorem cert_e605602385530 : check e605602385530 [[],[]] .chain = true := by decide
def e605602385694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e605602385694 : Closed e605602385694 ∧ code e605602385694 = 2804625641246 := by decide
theorem cert_e605602385694 : check e605602385694 [[],[]] .chain = true := by decide
def e605602385718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602385718 : Closed e605602385718 ∧ code e605602385718 = 2804625641270 := by decide
theorem cert_e605602385718 : check e605602385718 [[],[]] .chain = true := by decide
def e605602385722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602385722 : Closed e605602385722 ∧ code e605602385722 = 2804625641274 := by decide
theorem cert_e605602385722 : check e605602385722 [[],[]] .chain = true := by decide
def e605602392918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605602392918 : Closed e605602392918 ∧ code e605602392918 = 2804625648470 := by decide
theorem cert_e605602392918 : check e605602392918 [[],[]] .chain = true := by decide
def e605602392922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605602392922 : Closed e605602392922 ∧ code e605602392922 = 2804625648474 := by decide
theorem cert_e605602392922 : check e605602392922 [[],[]] .chain = true := by decide
def e605602392938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605602392938 : Closed e605602392938 ∧ code e605602392938 = 2804625648490 := by decide
theorem cert_e605602392938 : check e605602392938 [[],[]] .chain = true := by decide
def e605602393002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605602393002 : Closed e605602393002 ∧ code e605602393002 = 2804625648554 := by decide
theorem cert_e605602393002 : check e605602393002 [[],[]] .chain = true := by decide
def e605602393110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605602393110 : Closed e605602393110 ∧ code e605602393110 = 2804625648662 := by decide
theorem cert_e605602393110 : check e605602393110 [[],[]] .chain = true := by decide
def e605602393206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605602393206 : Closed e605602393206 ∧ code e605602393206 = 2804625648758 := by decide
theorem cert_e605602393206 : check e605602393206 [[],[]] .chain = true := by decide
def e605602393302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605602393302 : Closed e605602393302 ∧ code e605602393302 = 2804625648854 := by decide
theorem cert_e605602393302 : check e605602393302 [[],[]] .chain = true := by decide
def e605602393306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605602393306 : Closed e605602393306 ∧ code e605602393306 = 2804625648858 := by decide
theorem cert_e605602393306 : check e605602393306 [[],[]] .chain = true := by decide
def e605602393322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605602393322 : Closed e605602393322 ∧ code e605602393322 = 2804625648874 := by decide
theorem cert_e605602393322 : check e605602393322 [[],[]] .chain = true := by decide
def e605602393398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605602393398 : Closed e605602393398 ∧ code e605602393398 = 2804625648950 := by decide
theorem cert_e605602393398 : check e605602393398 [[],[]] .chain = true := by decide
def e605602393402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605602393402 : Closed e605602393402 ∧ code e605602393402 = 2804625648954 := by decide
theorem cert_e605602393402 : check e605602393402 [[],[]] .chain = true := by decide
def e605602393474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602393474 : Closed e605602393474 ∧ code e605602393474 = 2804625649026 := by decide
theorem cert_e605602393474 : check e605602393474 [[],[]] .chain = true := by decide
def e605602393486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605602393486 : Closed e605602393486 ∧ code e605602393486 = 2804625649038 := by decide
theorem cert_e605602393486 : check e605602393486 [[],[]] .chain = true := by decide
def e605602393498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602393498 : Closed e605602393498 ∧ code e605602393498 = 2804625649050 := by decide
theorem cert_e605602393498 : check e605602393498 [[],[]] .chain = true := by decide
def e605602393610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605602393610 : Closed e605602393610 ∧ code e605602393610 = 2804625649162 := by decide
theorem cert_e605602393610 : check e605602393610 [[],[]] .chain = true := by decide
def e605602393646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605602393646 : Closed e605602393646 ∧ code e605602393646 = 2804625649198 := by decide
theorem cert_e605602393646 : check e605602393646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602393654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605602393654 : Closed e605602393654 ∧ code e605602393654 = 2804625649206 := by decide
theorem cert_e605602393654 : check e605602393654 [[],[]] .chain = true := by decide
def e605602393658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605602393658 : Closed e605602393658 ∧ code e605602393658 = 2804625649210 := by decide
theorem cert_e605602393658 : check e605602393658 [[],[]] .chain = true := by decide
def e605602393706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605602393706 : Closed e605602393706 ∧ code e605602393706 = 2804625649258 := by decide
theorem cert_e605602393706 : check e605602393706 [[],[]] .chain = true := by decide
def e605602393730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602393730 : Closed e605602393730 ∧ code e605602393730 = 2804625649282 := by decide
theorem cert_e605602393730 : check e605602393730 [[],[]] .chain = true := by decide
def e605602393742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605602393742 : Closed e605602393742 ∧ code e605602393742 = 2804625649294 := by decide
theorem cert_e605602393742 : check e605602393742 [[],[]] .chain = true := by decide
def e605602393754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602393754 : Closed e605602393754 ∧ code e605602393754 = 2804625649306 := by decide
theorem cert_e605602393754 : check e605602393754 [[],[]] .chain = true := by decide
def e605602393798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605602393798 : Closed e605602393798 ∧ code e605602393798 = 2804625649350 := by decide
theorem cert_e605602393798 : check e605602393798 [[],[]] .chain = true := by decide
def e605602393826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605602393826 : Closed e605602393826 ∧ code e605602393826 = 2804625649378 := by decide
theorem cert_e605602393826 : check e605602393826 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602393838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e605602393838 : Closed e605602393838 ∧ code e605602393838 = 2804625649390 := by decide
theorem cert_e605602393838 : check e605602393838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602393878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605602393878 : Closed e605602393878 ∧ code e605602393878 = 2804625649430 := by decide
theorem cert_e605602393878 : check e605602393878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605602393954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605602393954 : Closed e605602393954 ∧ code e605602393954 = 2804625649506 := by decide
theorem cert_e605602393954 : check e605602393954 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605602393966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e605602393966 : Closed e605602393966 ∧ code e605602393966 = 2804625649518 := by decide
theorem cert_e605602393966 : check e605602393966 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605602393974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e605602393974 : Closed e605602393974 ∧ code e605602393974 = 2804625649526 := by decide
theorem cert_e605602393974 : check e605602393974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602394350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605602394350 : Closed e605602394350 ∧ code e605602394350 = 2804625649902 := by decide
theorem cert_e605602394350 : check e605602394350 [[],[]] .chain = true := by decide
def e605602394358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605602394358 : Closed e605602394358 ∧ code e605602394358 = 2804625649910 := by decide
theorem cert_e605602394358 : check e605602394358 [[],[]] .chain = true := by decide
def e605602394838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605602394838 : Closed e605602394838 ∧ code e605602394838 = 2804625650390 := by decide
theorem cert_e605602394838 : check e605602394838 [[],[]] .chain = true := by decide
def e605602394842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605602394842 : Closed e605602394842 ∧ code e605602394842 = 2804625650394 := by decide
theorem cert_e605602394842 : check e605602394842 [[],[]] .chain = true := by decide
def e605602394858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605602394858 : Closed e605602394858 ∧ code e605602394858 = 2804625650410 := by decide
theorem cert_e605602394858 : check e605602394858 [[],[]] .chain = true := by decide
def e605602394934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602394934 : Closed e605602394934 ∧ code e605602394934 = 2804625650486 := by decide
theorem cert_e605602394934 : check e605602394934 [[],[]] .chain = true := by decide
def e605602394938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602394938 : Closed e605602394938 ∧ code e605602394938 = 2804625650490 := by decide
theorem cert_e605602394938 : check e605602394938 [[],[]] .chain = true := by decide
def e605602395010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605602395010 : Closed e605602395010 ∧ code e605602395010 = 2804625650562 := by decide
theorem cert_e605602395010 : check e605602395010 [[],[]] .chain = true := by decide
def e605602395022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605602395022 : Closed e605602395022 ∧ code e605602395022 = 2804625650574 := by decide
theorem cert_e605602395022 : check e605602395022 [[],[]] .chain = true := by decide
def e605602395034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602395034 : Closed e605602395034 ∧ code e605602395034 = 2804625650586 := by decide
theorem cert_e605602395034 : check e605602395034 [[],[]] .chain = true := by decide
def e605602396186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605602396186 : Closed e605602396186 ∧ code e605602396186 = 2804625651738 := by decide
theorem cert_e605602396186 : check e605602396186 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602396222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e605602396222 : Closed e605602396222 ∧ code e605602396222 = 2804625651774 := by decide
theorem cert_e605602396222 : check e605602396222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602396270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605602396270 : Closed e605602396270 ∧ code e605602396270 = 2804625651822 := by decide
theorem cert_e605602396270 : check e605602396270 [[],[]] .chain = true := by decide
def e605602396278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605602396278 : Closed e605602396278 ∧ code e605602396278 = 2804625651830 := by decide
theorem cert_e605602396278 : check e605602396278 [[],[]] .chain = true := by decide
def e605602396282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605602396282 : Closed e605602396282 ∧ code e605602396282 = 2804625651834 := by decide
theorem cert_e605602396282 : check e605602396282 [[],[]] .chain = true := by decide
def e605602396522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605602396522 : Closed e605602396522 ∧ code e605602396522 = 2804625652074 := by decide
theorem cert_e605602396522 : check e605602396522 [[],[]] .chain = true := by decide
def e605602396546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605602396546 : Closed e605602396546 ∧ code e605602396546 = 2804625652098 := by decide
theorem cert_e605602396546 : check e605602396546 [[],[]] .chain = true := by decide
def e605602396558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605602396558 : Closed e605602396558 ∧ code e605602396558 = 2804625652110 := by decide
theorem cert_e605602396558 : check e605602396558 [[],[]] .chain = true := by decide
def e605602396570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602396570 : Closed e605602396570 ∧ code e605602396570 = 2804625652122 := by decide
theorem cert_e605602396570 : check e605602396570 [[],[]] .chain = true := by decide
def e605602396614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605602396614 : Closed e605602396614 ∧ code e605602396614 = 2804625652166 := by decide
theorem cert_e605602396614 : check e605602396614 [[],[]] .chain = true := by decide
def e605602396642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605602396642 : Closed e605602396642 ∧ code e605602396642 = 2804625652194 := by decide
theorem cert_e605602396642 : check e605602396642 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602396654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e605602396654 : Closed e605602396654 ∧ code e605602396654 = 2804625652206 := by decide
theorem cert_e605602396654 : check e605602396654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602397214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e605602397214 : Closed e605602397214 ∧ code e605602397214 = 2804625652766 := by decide
theorem cert_e605602397214 : check e605602397214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602397410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605602397410 : Closed e605602397410 ∧ code e605602397410 = 2804625652962 := by decide
theorem cert_e605602397410 : check e605602397410 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602397422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e605602397422 : Closed e605602397422 ∧ code e605602397422 = 2804625652974 := by decide
theorem cert_e605602397422 : check e605602397422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602397430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e605602397430 : Closed e605602397430 ∧ code e605602397430 = 2804625652982 := by decide
theorem cert_e605602397430 : check e605602397430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e605602454126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602454126 : Closed e605602454126 ∧ code e605602454126 = 2804625709678 := by decide
theorem cert_e605602454126 : checkPay e605602454126 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602454138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602454138 : Closed e605602454138 ∧ code e605602454138 = 2804625709690 := by decide
theorem cert_e605602454138 : checkPay e605602454138 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602455278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 2))))))
theorem wire_e605602455278 : Closed e605602455278 ∧ code e605602455278 = 2804625710830 := by decide
theorem cert_e605602455278 : check e605602455278 [[],[]] .chain = true := by decide
def e605602455290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))) (.var 0))))))
theorem wire_e605602455290 : Closed e605602455290 ∧ code e605602455290 = 2804625710842 := by decide
theorem cert_e605602455290 : check e605602455290 [[],[]] .chain = true := by decide
def e605602455482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))) (.var 0))))))
theorem wire_e605602455482 : Closed e605602455482 ∧ code e605602455482 = 2804625711034 := by decide
theorem cert_e605602455482 : check e605602455482 [[],[]] .chain = true := by decide
def e605602457006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605602457006 : Closed e605602457006 ∧ code e605602457006 = 2804625712558 := by decide
theorem cert_e605602457006 : check e605602457006 [[],[]] .chain = true := by decide
def e605602457018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605602457018 : Closed e605602457018 ∧ code e605602457018 = 2804625712570 := by decide
theorem cert_e605602457018 : check e605602457018 [[],[]] .chain = true := by decide
def e605602457066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605602457066 : Closed e605602457066 ∧ code e605602457066 = 2804625712618 := by decide
theorem cert_e605602457066 : check e605602457066 [[],[]] .chain = true := by decide
def e605602457198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605602457198 : Closed e605602457198 ∧ code e605602457198 = 2804625712750 := by decide
theorem cert_e605602457198 : check e605602457198 [[],[]] .chain = true := by decide
def e605602457210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605602457210 : Closed e605602457210 ∧ code e605602457210 = 2804625712762 := by decide
theorem cert_e605602457210 : check e605602457210 [[],[]] .chain = true := by decide
def e605602457498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605602457498 : Closed e605602457498 ∧ code e605602457498 = 2804625713050 := by decide
theorem cert_e605602457498 : check e605602457498 [[],[]] .chain = true := by decide
def e605602462190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602462190 : Closed e605602462190 ∧ code e605602462190 = 2804625717742 := by decide
theorem cert_e605602462190 : checkPay e605602462190 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602463342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602463342 : Closed e605602463342 ∧ code e605602463342 = 2804625718894 := by decide
theorem cert_e605602463342 : checkPay e605602463342 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602463354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602463354 : Closed e605602463354 ∧ code e605602463354 = 2804625718906 := by decide
theorem cert_e605602463354 : checkPay e605602463354 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602470766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 2))))))
theorem wire_e605602470766 : Closed e605602470766 ∧ code e605602470766 = 2804625726318 := by decide
theorem cert_e605602470766 : check e605602470766 [[],[]] .chain = true := by decide
def e605602470774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e605602470774 : Closed e605602470774 ∧ code e605602470774 = 2804625726326 := by decide
theorem cert_e605602470774 : check e605602470774 [[],[]] .smaller = true := by decide
def e605602470778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 0))))))
theorem wire_e605602470778 : Closed e605602470778 ∧ code e605602470778 = 2804625726330 := by decide
theorem cert_e605602470778 : check e605602470778 [[],[]] .chain = true := by decide
def e605602470838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e605602470838 : Closed e605602470838 ∧ code e605602470838 = 2804625726390 := by decide
theorem cert_e605602470838 : check e605602470838 [[],[]] .smaller = true := by decide
def e605602470874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0))))))
theorem wire_e605602470874 : Closed e605602470874 ∧ code e605602470874 = 2804625726426 := by decide
theorem cert_e605602470874 : check e605602470874 [[],[]] .chain = true := by decide
def e605602471278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e605602471278 : Closed e605602471278 ∧ code e605602471278 = 2804625726830 := by decide
theorem cert_e605602471278 : check e605602471278 [[],[]] .chain = true := by decide
def e605602471286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e605602471286 : Closed e605602471286 ∧ code e605602471286 = 2804625726838 := by decide
theorem cert_e605602471286 : check e605602471286 [[],[]] .smaller = true := by decide
def e605602471290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e605602471290 : Closed e605602471290 ∧ code e605602471290 = 2804625726842 := by decide
theorem cert_e605602471290 : check e605602471290 [[],[]] .chain = true := by decide
def e605602471342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e605602471342 : Closed e605602471342 ∧ code e605602471342 = 2804625726894 := by decide
theorem cert_e605602471342 : check e605602471342 [[],[]] .chain = true := by decide
def e605602471382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e605602471382 : Closed e605602471382 ∧ code e605602471382 = 2804625726934 := by decide
theorem cert_e605602471382 : check e605602471382 [[],[]] .smaller = true := by decide
def e605602471402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e605602471402 : Closed e605602471402 ∧ code e605602471402 = 2804625726954 := by decide
theorem cert_e605602471402 : check e605602471402 [[],[]] .chain = true := by decide
def e605602471606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e605602471606 : Closed e605602471606 ∧ code e605602471606 = 2804625727158 := by decide
theorem cert_e605602471606 : check e605602471606 [[],[]] .smaller = true := by decide
def e605602471638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e605602471638 : Closed e605602471638 ∧ code e605602471638 = 2804625727190 := by decide
theorem cert_e605602471638 : check e605602471638 [[],[]] .smaller = true := by decide
def e605602471770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605602471770 : Closed e605602471770 ∧ code e605602471770 = 2804625727322 := by decide
theorem cert_e605602471770 : check e605602471770 [[],[]] .chain = true := by decide
def e605602471786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605602471786 : Closed e605602471786 ∧ code e605602471786 = 2804625727338 := by decide
theorem cert_e605602471786 : check e605602471786 [[],[]] .chain = true := by decide
def e605602473838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e605602473838 : Closed e605602473838 ∧ code e605602473838 = 2804625729390 := by decide
theorem cert_e605602473838 : check e605602473838 [[],[]] .chain = true := by decide
def e605602473846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e605602473846 : Closed e605602473846 ∧ code e605602473846 = 2804625729398 := by decide
theorem cert_e605602473846 : check e605602473846 [[],[]] .smaller = true := by decide
def e605602473850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e605602473850 : Closed e605602473850 ∧ code e605602473850 = 2804625729402 := by decide
theorem cert_e605602473850 : check e605602473850 [[],[]] .chain = true := by decide
def e605602473910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e605602473910 : Closed e605602473910 ∧ code e605602473910 = 2804625729462 := by decide
theorem cert_e605602473910 : check e605602473910 [[],[]] .smaller = true := by decide
def e605602473946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e605602473946 : Closed e605602473946 ∧ code e605602473946 = 2804625729498 := by decide
theorem cert_e605602473946 : check e605602473946 [[],[]] .chain = true := by decide
def e605602475246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602475246 : Closed e605602475246 ∧ code e605602475246 = 2804625730798 := by decide
theorem cert_e605602475246 : check e605602475246 [[],[]] .chain = true := by decide
def e605602475254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602475254 : Closed e605602475254 ∧ code e605602475254 = 2804625730806 := by decide
theorem cert_e605602475254 : check e605602475254 [[],[]] .chain = true := by decide
def e605602475630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602475630 : Closed e605602475630 ∧ code e605602475630 = 2804625731182 := by decide
theorem cert_e605602475630 : check e605602475630 [[],[]] .chain = true := by decide
def e605602475642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602475642 : Closed e605602475642 ∧ code e605602475642 = 2804625731194 := by decide
theorem cert_e605602475642 : check e605602475642 [[],[]] .chain = true := by decide
def e605602475830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602475830 : Closed e605602475830 ∧ code e605602475830 = 2804625731382 := by decide
theorem cert_e605602475830 : check e605602475830 [[],[]] .chain = true := by decide
def e605602475834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602475834 : Closed e605602475834 ∧ code e605602475834 = 2804625731386 := by decide
theorem cert_e605602475834 : check e605602475834 [[],[]] .chain = true := by decide
def e605602476526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2))))))
theorem wire_e605602476526 : Closed e605602476526 ∧ code e605602476526 = 2804625732078 := by decide
theorem cert_e605602476526 : check e605602476526 [[],[]] .chain = true := by decide
def e605602476534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 1))))))
theorem wire_e605602476534 : Closed e605602476534 ∧ code e605602476534 = 2804625732086 := by decide
theorem cert_e605602476534 : check e605602476534 [[],[]] .chain = true := by decide
def e605602476910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e605602476910 : Closed e605602476910 ∧ code e605602476910 = 2804625732462 := by decide
theorem cert_e605602476910 : check e605602476910 [[],[]] .chain = true := by decide
def e605602476918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e605602476918 : Closed e605602476918 ∧ code e605602476918 = 2804625732470 := by decide
theorem cert_e605602476918 : check e605602476918 [[],[]] .smaller = true := by decide
def e605602476922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e605602476922 : Closed e605602476922 ∧ code e605602476922 = 2804625732474 := by decide
theorem cert_e605602476922 : check e605602476922 [[],[]] .chain = true := by decide
def e605602476974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e605602476974 : Closed e605602476974 ∧ code e605602476974 = 2804625732526 := by decide
theorem cert_e605602476974 : check e605602476974 [[],[]] .chain = true := by decide
def e605602477014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e605602477014 : Closed e605602477014 ∧ code e605602477014 = 2804625732566 := by decide
theorem cert_e605602477014 : check e605602477014 [[],[]] .smaller = true := by decide
def e605602477034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e605602477034 : Closed e605602477034 ∧ code e605602477034 = 2804625732586 := by decide
theorem cert_e605602477034 : check e605602477034 [[],[]] .chain = true := by decide
def e605602477294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602477294 : Closed e605602477294 ∧ code e605602477294 = 2804625732846 := by decide
theorem cert_e605602477294 : check e605602477294 [[],[]] .chain = true := by decide
def e605602477302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602477302 : Closed e605602477302 ∧ code e605602477302 = 2804625732854 := by decide
theorem cert_e605602477302 : check e605602477302 [[],[]] .chain = true := by decide
def e605602477678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602477678 : Closed e605602477678 ∧ code e605602477678 = 2804625733230 := by decide
theorem cert_e605602477678 : check e605602477678 [[],[]] .chain = true := by decide
def e605602477690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602477690 : Closed e605602477690 ∧ code e605602477690 = 2804625733242 := by decide
theorem cert_e605602477690 : check e605602477690 [[],[]] .chain = true := by decide
def e605602477854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e605602477854 : Closed e605602477854 ∧ code e605602477854 = 2804625733406 := by decide
theorem cert_e605602477854 : check e605602477854 [[],[]] .chain = true := by decide
def e605602477966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e605602477966 : Closed e605602477966 ∧ code e605602477966 = 2804625733518 := by decide
theorem cert_e605602477966 : check e605602477966 [[],[]] .chain = true := by decide
def e605602477978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602477978 : Closed e605602477978 ∧ code e605602477978 = 2804625733530 := by decide
theorem cert_e605602477978 : check e605602477978 [[],[]] .chain = true := by decide
def e605602478318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 2))))))
theorem wire_e605602478318 : Closed e605602478318 ∧ code e605602478318 = 2804625733870 := by decide
theorem cert_e605602478318 : check e605602478318 [[],[]] .chain = true := by decide
def e605602478330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 0))))))
theorem wire_e605602478330 : Closed e605602478330 ∧ code e605602478330 = 2804625733882 := by decide
theorem cert_e605602478330 : check e605602478330 [[],[]] .chain = true := by decide
def e605602478518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e605602478518 : Closed e605602478518 ∧ code e605602478518 = 2804625734070 := by decide
theorem cert_e605602478518 : check e605602478518 [[],[]] .smaller = true := by decide
def e605602478550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e605602478550 : Closed e605602478550 ∧ code e605602478550 = 2804625734102 := by decide
theorem cert_e605602478550 : check e605602478550 [[],[]] .smaller = true := by decide
def e605602478702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602478702 : Closed e605602478702 ∧ code e605602478702 = 2804625734254 := by decide
theorem cert_e605602478702 : check e605602478702 [[],[]] .chain = true := by decide
def e605602478714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602478714 : Closed e605602478714 ∧ code e605602478714 = 2804625734266 := by decide
theorem cert_e605602478714 : check e605602478714 [[],[]] .chain = true := by decide
def e605602478878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e605602478878 : Closed e605602478878 ∧ code e605602478878 = 2804625734430 := by decide
theorem cert_e605602478878 : check e605602478878 [[],[]] .chain = true := by decide
def e605602479046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e605602479046 : Closed e605602479046 ∧ code e605602479046 = 2804625734598 := by decide
theorem cert_e605602479046 : check e605602479046 [[],[]] .chain = true := by decide
def e605602479222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 1))))))
theorem wire_e605602479222 : Closed e605602479222 ∧ code e605602479222 = 2804625734774 := by decide
theorem cert_e605602479222 : check e605602479222 [[],[]] .chain = true := by decide
def e605602479226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 0))))))
theorem wire_e605602479226 : Closed e605602479226 ∧ code e605602479226 = 2804625734778 := by decide
theorem cert_e605602479226 : check e605602479226 [[],[]] .chain = true := by decide
def e605602479322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605602479322 : Closed e605602479322 ∧ code e605602479322 = 2804625734874 := by decide
theorem cert_e605602479322 : check e605602479322 [[],[]] .chain = true := by decide
def e605602479338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605602479338 : Closed e605602479338 ∧ code e605602479338 = 2804625734890 := by decide
theorem cert_e605602479338 : check e605602479338 [[],[]] .chain = true := by decide
def e605602479414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602479414 : Closed e605602479414 ∧ code e605602479414 = 2804625734966 := by decide
theorem cert_e605602479414 : check e605602479414 [[],[]] .chain = true := by decide
def e605602479418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602479418 : Closed e605602479418 ∧ code e605602479418 = 2804625734970 := by decide
theorem cert_e605602479418 : check e605602479418 [[],[]] .chain = true := by decide
def e605602479502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e605602479502 : Closed e605602479502 ∧ code e605602479502 = 2804625735054 := by decide
theorem cert_e605602479502 : check e605602479502 [[],[]] .chain = true := by decide
def e605602479514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602479514 : Closed e605602479514 ∧ code e605602479514 = 2804625735066 := by decide
theorem cert_e605602479514 : check e605602479514 [[],[]] .chain = true := by decide
def e605602479558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e605602479558 : Closed e605602479558 ∧ code e605602479558 = 2804625735110 := by decide
theorem cert_e605602479558 : check e605602479558 [[],[]] .chain = true := by decide
def e605602485998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e605602485998 : Closed e605602485998 ∧ code e605602485998 = 2804625741550 := by decide
theorem cert_e605602485998 : checkPay e605602485998 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602486190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e605602486190 : Closed e605602486190 ∧ code e605602486190 = 2804625741742 := by decide
theorem cert_e605602486190 : checkPay e605602486190 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602486202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e605602486202 : Closed e605602486202 ∧ code e605602486202 = 2804625741754 := by decide
theorem cert_e605602486202 : checkPay e605602486202 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602486766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e605602486766 : Closed e605602486766 ∧ code e605602486766 = 2804625742318 := by decide
theorem cert_e605602486766 : checkPay e605602486766 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602487918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e605602487918 : Closed e605602487918 ∧ code e605602487918 = 2804625743470 := by decide
theorem cert_e605602487918 : checkPay e605602487918 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602487930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e605602487930 : Closed e605602487930 ∧ code e605602487930 = 2804625743482 := by decide
theorem cert_e605602487930 : checkPay e605602487930 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602497502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e605602497502 : Closed e605602497502 ∧ code e605602497502 = 2804625753054 := by decide
theorem cert_e605602497502 : check e605602497502 [[],[]] .chain = true := by decide
def e605602497518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e605602497518 : Closed e605602497518 ∧ code e605602497518 = 2804625753070 := by decide
theorem cert_e605602497518 : check e605602497518 [[],[]] .chain = true := by decide
def e605602499438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605602499438 : Closed e605602499438 ∧ code e605602499438 = 2804625754990 := by decide
theorem cert_e605602499438 : check e605602499438 [[],[]] .chain = true := by decide
def e605602499446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605602499446 : Closed e605602499446 ∧ code e605602499446 = 2804625754998 := by decide
theorem cert_e605602499446 : check e605602499446 [[],[]] .chain = true := by decide
end Blc.Floor41
