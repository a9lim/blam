import R598355276698V0
import R598355276698K0
import R598355276698st0
import R598355276698st12
import R598355276698hs0
import R598355276698hs12
import CodeBridge
import Batch044
namespace Certgen.R598355276698
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 99,.app 2 90,.app 3 53,.app 4 50,.app 5 38,.app 6 18,.lam 7,.app 8 9,.var 0,.lam 10,.lam 11,.app 12 13,.var 2,.app 14 15,.var 1,.app 16 17,.var 0,.var 0,.lam 19,.lam 20,.app 21 33,.lam 22,.app 23 24,.var 0,.lam 25,.lam 26,.app 27 28,.var 2,.app 29 30,.var 1,.app 31 32,.var 0,.var 0,.app 34 35,.var 1,.app 36 37,.var 0,.var 0,.lam 39,.app 40 41,.var 0,.lam 42,.lam 43,.app 44 45,.var 2,.app 46 47,.var 1,.app 48 49,.var 0,.var 0,.lam 51,.lam 52,.var 1,.lam 54,.app 55 60,.app 56 57,.var 0,.lam 58,.lam 59,.var 1,.lam 61,.app 62 67,.app 63 64,.var 0,.lam 65,.lam 66,.var 1,.lam 68,.app 69 74,.app 70 71,.var 0,.lam 72,.lam 73,.var 0,.lam 75,.app 76 81,.app 77 78,.var 0,.lam 79,.lam 80,.var 1,.app 82 86,.lam 83,.app 84 85,.var 0,.var 0,.lam 87,.app 88 89,.var 0,.var 0,.app 91 95,.lam 92,.app 93 94,.var 0,.var 0,.lam 96,.app 97 98,.var 0,.var 0,.lam 100,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 40 then (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD [])) else (if i < 60 then (K40[i-40]?.getD []) else (if i < 80 then (K60[i-60]?.getD []) else (K80[i-80]?.getD []))))
def st (i : Nat) : AState := if i < 285 then (if i < 140 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 100 then (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)) else (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)))) else (if i < 220 then (if i < 180 then (if i < 160 then (st140[i-140]?.getD entry) else (st160[i-160]?.getD entry)) else (if i < 200 then (st180[i-180]?.getD entry) else (st200[i-200]?.getD entry))) else (if i < 260 then (if i < 240 then (st220[i-220]?.getD entry) else (st240[i-240]?.getD entry)) else (if i < 280 then (st260[i-260]?.getD entry) else (st280[i-280]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 140 then (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 100 then (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])) else (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD [])))) else (if i < 220 then (if i < 180 then (if i < 160 then (hs140[i-140]?.getD []) else (hs160[i-160]?.getD [])) else (if i < 200 then (hs180[i-180]?.getD []) else (hs200[i-200]?.getD []))) else (if i < 260 then (if i < 240 then (hs220[i-220]?.getD []) else (hs240[i-240]?.getD [])) else (if i < 280 then (hs260[i-260]?.getD []) else (hs280[i-280]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R598355276698
