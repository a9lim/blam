import Extra41
import Batch044
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598355260378
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private def u15 := Term.app u0 u5
private def u16 := Term.app u15 u0
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou9 : SO u9 := SO.lam (r := u14) (g := u16) sou8 sou14 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598355260378 : ¬ IsSelfInterpreter e598355260378 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598355260378
end Witness598355260378
namespace Witness598355260654
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.app u1 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u13 := Term.app u0 u4
private def u14 := Term.app u1 u4
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou1 sou6
private theorem sou13 : SO u13 := SO.app sou0 sou4
private theorem sou8 : SO u8 := SO.lam (r := u13) (g := u14) sou7 sou13 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou3 sou11
theorem nege598355260654 : ¬ IsSelfInterpreter e598355260654 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege598355260654
end Witness598355260654
namespace Witness598355260662
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u1 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u13 := Term.app u5 u0
private def u14 := Term.app u1 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou1 sou6
private theorem sou13 : SO u13 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u13) (g := u14) sou7 sou13 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou3 sou11
theorem nege598355260662 : ¬ IsSelfInterpreter e598355260662 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege598355260662
end Witness598355260662
namespace Witness598355261038
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u2 u10
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u0 u13
private def u15 := Term.app u2 u14
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u9 u17
private def u19 := Term.app u9 u9
private def u20 := Term.app u18 u19
theorem nege598355261038 : ¬ IsSelfInterpreter e598355261038 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355261038 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355261038
end Witness598355261038
namespace Witness598355261050
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u0
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u2 u10
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u13 u0
private def u15 := Term.app u2 u14
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u9 u17
private def u19 := Term.app u9 u9
private def u20 := Term.app u18 u19
theorem nege598355261050 : ¬ IsSelfInterpreter e598355261050 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355261050 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355261050
end Witness598355261050
namespace Witness598355261238
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u0 u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u0 u9
private def u12 := Term.app u11 u4
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u0 u14
private def u16 := Term.app u15 u4
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.app u9 u18
private def u20 := Term.app u10 u19
theorem nege598355261238 : ¬ IsSelfInterpreter e598355261238 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355261238 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355261238
end Witness598355261238
namespace Witness598355261242
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u0 u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u0 u9
private def u12 := Term.app u11 u4
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u0 u14
private def u16 := Term.app u15 u4
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.app u18 u9
private def u20 := Term.app u10 u19
theorem nege598355261242 : ¬ IsSelfInterpreter e598355261242 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355261242 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355261242
end Witness598355261242
namespace Witness598355261882
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege598355261882 : ¬ IsSelfInterpreter e598355261882 := by
  intro he
  have h : replay [] (.app e598355261882 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege598355261882
end Witness598355261882
end Blc.Floor41
