import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605606296170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605606296170 : Closed e605606296170 ∧ code e605606296170 = 2804629551722 := by decide
theorem cert_e605606296170 : check e605606296170 [[],[]] .chain = true := by decide
def e605606296194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605606296194 : Closed e605606296194 ∧ code e605606296194 = 2804629551746 := by decide
theorem cert_e605606296194 : check e605606296194 [[],[]] .chain = true := by decide
def e605606296206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605606296206 : Closed e605606296206 ∧ code e605606296206 = 2804629551758 := by decide
theorem cert_e605606296206 : check e605606296206 [[],[]] .chain = true := by decide
def e605606296218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605606296218 : Closed e605606296218 ∧ code e605606296218 = 2804629551770 := by decide
theorem cert_e605606296218 : check e605606296218 [[],[]] .chain = true := by decide
def e605606296262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605606296262 : Closed e605606296262 ∧ code e605606296262 = 2804629551814 := by decide
theorem cert_e605606296262 : check e605606296262 [[],[]] .chain = true := by decide
def e605606296290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605606296290 : Closed e605606296290 ∧ code e605606296290 = 2804629551842 := by decide
theorem cert_e605606296290 : check e605606296290 [[],[],[.under,.under]] .three = true := by decide
def e605606296302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e605606296302 : Closed e605606296302 ∧ code e605606296302 = 2804629551854 := by decide
theorem cert_e605606296302 : check e605606296302 [[],[],[.under,.under]] .three = true := by decide
def e605606296346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605606296346 : Closed e605606296346 ∧ code e605606296346 = 2804629551898 := by decide
theorem cert_e605606296346 : check e605606296346 [[],[]] .chain = true := by decide
def e605606296390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605606296390 : Closed e605606296390 ∧ code e605606296390 = 2804629551942 := by decide
theorem cert_e605606296390 : check e605606296390 [[],[]] .chain = true := by decide
def e605606296458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605606296458 : Closed e605606296458 ∧ code e605606296458 = 2804629552010 := by decide
theorem cert_e605606296458 : check e605606296458 [[],[],[.under,.under]] .three = true := by decide
def e605606296482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605606296482 : Closed e605606296482 ∧ code e605606296482 = 2804629552034 := by decide
theorem cert_e605606296482 : check e605606296482 [[],[],[.under,.under]] .three = true := by decide
def e605606296494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e605606296494 : Closed e605606296494 ∧ code e605606296494 = 2804629552046 := by decide
theorem cert_e605606296494 : check e605606296494 [[],[],[.under,.under]] .three = true := by decide
def e605606296506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e605606296506 : Closed e605606296506 ∧ code e605606296506 = 2804629552058 := by decide
theorem cert_e605606296506 : check e605606296506 [[],[],[.under,.under]] .three = true := by decide
def e605606296662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605606296662 : Closed e605606296662 ∧ code e605606296662 = 2804629552214 := by decide
theorem cert_e605606296662 : check e605606296662 [[],[],[.under,.under]] .three = true := by decide
def e605606296666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605606296666 : Closed e605606296666 ∧ code e605606296666 = 2804629552218 := by decide
theorem cert_e605606296666 : check e605606296666 [[],[],[.under,.under]] .three = true := by decide
def e605606296854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605606296854 : Closed e605606296854 ∧ code e605606296854 = 2804629552406 := by decide
theorem cert_e605606296854 : check e605606296854 [[],[],[.under,.under]] .three = true := by decide
def e605606296930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605606296930 : Closed e605606296930 ∧ code e605606296930 = 2804629552482 := by decide
theorem cert_e605606296930 : check e605606296930 [[],[],[.under,.under]] .three = true := by decide
def e605606296942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605606296942 : Closed e605606296942 ∧ code e605606296942 = 2804629552494 := by decide
theorem cert_e605606296942 : check e605606296942 [[],[],[.under,.under]] .three = true := by decide
def e605606296950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605606296950 : Closed e605606296950 ∧ code e605606296950 = 2804629552502 := by decide
theorem cert_e605606296950 : check e605606296950 [[],[],[.under,.under]] .three = true := by decide
def e605606296970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605606296970 : Closed e605606296970 ∧ code e605606296970 = 2804629552522 := by decide
theorem cert_e605606296970 : check e605606296970 [[],[],[.under,.under]] .three = true := by decide
def e605606296994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605606296994 : Closed e605606296994 ∧ code e605606296994 = 2804629552546 := by decide
theorem cert_e605606296994 : check e605606296994 [[],[],[.under,.under]] .three = true := by decide
def e605606297006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605606297006 : Closed e605606297006 ∧ code e605606297006 = 2804629552558 := by decide
theorem cert_e605606297006 : check e605606297006 [[],[],[.under,.under]] .three = true := by decide
def e605606297018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605606297018 : Closed e605606297018 ∧ code e605606297018 = 2804629552570 := by decide
theorem cert_e605606297018 : check e605606297018 [[],[],[.under,.under]] .three = true := by decide
def e605606297046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605606297046 : Closed e605606297046 ∧ code e605606297046 = 2804629552598 := by decide
private def t_e605606297046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e605606297046 : ¬ IsSelfInterpreter e605606297046 :=
  wSource (t := t_e605606297046) (replay_sound (ps := []) (t := e605606297046) (by decide)) (by decide)
def e605606297050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605606297050 : Closed e605606297050 ∧ code e605606297050 = 2804629552602 := by decide
private def t_e605606297050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e605606297050 : ¬ IsSelfInterpreter e605606297050 :=
  wSource (t := t_e605606297050) (replay_sound (ps := []) (t := e605606297050) (by decide)) (by decide)
def e605606297814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e605606297814 : Closed e605606297814 ∧ code e605606297814 = 2804629553366 := by decide
theorem cert_e605606297814 : check e605606297814 [[],[],[.under,.under]] .three = true := by decide
def e605606297910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605606297910 : Closed e605606297910 ∧ code e605606297910 = 2804629553462 := by decide
theorem cert_e605606297910 : check e605606297910 [[],[]] .chain = true := by decide
def e605606297914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605606297914 : Closed e605606297914 ∧ code e605606297914 = 2804629553466 := by decide
theorem cert_e605606297914 : check e605606297914 [[],[]] .chain = true := by decide
def e605606298094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e605606298094 : Closed e605606298094 ∧ code e605606298094 = 2804629553646 := by decide
theorem cert_e605606298094 : check e605606298094 [[],[],[.under,.under]] .three = true := by decide
def e605606298102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e605606298102 : Closed e605606298102 ∧ code e605606298102 = 2804629553654 := by decide
theorem cert_e605606298102 : check e605606298102 [[],[],[.under,.under]] .three = true := by decide
def e605606298486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605606298486 : Closed e605606298486 ∧ code e605606298486 = 2804629554038 := by decide
theorem cert_e605606298486 : check e605606298486 [[],[]] .chain = true := by decide
def e605606298550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e605606298550 : Closed e605606298550 ∧ code e605606298550 = 2804629554102 := by decide
theorem cert_e605606298550 : check e605606298550 [[],[]] .chain = true := by decide
def e605606298554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605606298554 : Closed e605606298554 ∧ code e605606298554 = 2804629554106 := by decide
theorem cert_e605606298554 : check e605606298554 [[],[]] .chain = true := by decide
def e605606298582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605606298582 : Closed e605606298582 ∧ code e605606298582 = 2804629554134 := by decide
theorem cert_e605606298582 : check e605606298582 [[],[]] .chain = true := by decide
def e605606298586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605606298586 : Closed e605606298586 ∧ code e605606298586 = 2804629554138 := by decide
theorem cert_e605606298586 : check e605606298586 [[],[]] .chain = true := by decide
def e605606298862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605606298862 : Closed e605606298862 ∧ code e605606298862 = 2804629554414 := by decide
theorem cert_e605606298862 : check e605606298862 [[],[],[.under,.under]] .three = true := by decide
def e605606298870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605606298870 : Closed e605606298870 ∧ code e605606298870 = 2804629554422 := by decide
theorem cert_e605606298870 : check e605606298870 [[],[],[.under,.under]] .three = true := by decide
def e605606299254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e605606299254 : Closed e605606299254 ∧ code e605606299254 = 2804629554806 := by decide
theorem cert_e605606299254 : check e605606299254 [[],[]] .chain = true := by decide
def e605606299422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e605606299422 : Closed e605606299422 ∧ code e605606299422 = 2804629554974 := by decide
theorem cert_e605606299422 : check e605606299422 [[],[],[.under,.under]] .three = true := by decide
def e605606299446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605606299446 : Closed e605606299446 ∧ code e605606299446 = 2804629554998 := by decide
theorem cert_e605606299446 : check e605606299446 [[],[]] .chain = true := by decide
def e605606299450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605606299450 : Closed e605606299450 ∧ code e605606299450 = 2804629555002 := by decide
theorem cert_e605606299450 : check e605606299450 [[],[]] .chain = true := by decide
def e605606299534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e605606299534 : Closed e605606299534 ∧ code e605606299534 = 2804629555086 := by decide
theorem cert_e605606299534 : check e605606299534 [[],[],[.under,.under]] .three = true := by decide
def e605606300502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605606300502 : Closed e605606300502 ∧ code e605606300502 = 2804629556054 := by decide
theorem cert_e605606300502 : check e605606300502 [[],[]] .chain = true := by decide
def e605606300506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605606300506 : Closed e605606300506 ∧ code e605606300506 = 2804629556058 := by decide
theorem cert_e605606300506 : check e605606300506 [[],[]] .chain = true := by decide
def e605606300522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605606300522 : Closed e605606300522 ∧ code e605606300522 = 2804629556074 := by decide
theorem cert_e605606300522 : check e605606300522 [[],[]] .chain = true := by decide
def e605606300586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605606300586 : Closed e605606300586 ∧ code e605606300586 = 2804629556138 := by decide
theorem cert_e605606300586 : check e605606300586 [[],[]] .chain = true := by decide
def e605606300694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605606300694 : Closed e605606300694 ∧ code e605606300694 = 2804629556246 := by decide
theorem cert_e605606300694 : check e605606300694 [[],[]] .chain = true := by decide
def e605606300790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605606300790 : Closed e605606300790 ∧ code e605606300790 = 2804629556342 := by decide
theorem cert_e605606300790 : check e605606300790 [[],[]] .chain = true := by decide
def e605606300886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605606300886 : Closed e605606300886 ∧ code e605606300886 = 2804629556438 := by decide
theorem cert_e605606300886 : check e605606300886 [[],[]] .chain = true := by decide
def e605606300890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605606300890 : Closed e605606300890 ∧ code e605606300890 = 2804629556442 := by decide
theorem cert_e605606300890 : check e605606300890 [[],[]] .chain = true := by decide
def e605606300906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605606300906 : Closed e605606300906 ∧ code e605606300906 = 2804629556458 := by decide
theorem cert_e605606300906 : check e605606300906 [[],[]] .chain = true := by decide
def e605606300982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605606300982 : Closed e605606300982 ∧ code e605606300982 = 2804629556534 := by decide
theorem cert_e605606300982 : check e605606300982 [[],[]] .chain = true := by decide
def e605606300986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605606300986 : Closed e605606300986 ∧ code e605606300986 = 2804629556538 := by decide
theorem cert_e605606300986 : check e605606300986 [[],[]] .chain = true := by decide
def e605606301058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605606301058 : Closed e605606301058 ∧ code e605606301058 = 2804629556610 := by decide
theorem cert_e605606301058 : check e605606301058 [[],[]] .chain = true := by decide
def e605606301070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605606301070 : Closed e605606301070 ∧ code e605606301070 = 2804629556622 := by decide
theorem cert_e605606301070 : check e605606301070 [[],[]] .chain = true := by decide
def e605606301082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605606301082 : Closed e605606301082 ∧ code e605606301082 = 2804629556634 := by decide
theorem cert_e605606301082 : check e605606301082 [[],[]] .chain = true := by decide
def e605606301194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605606301194 : Closed e605606301194 ∧ code e605606301194 = 2804629556746 := by decide
theorem cert_e605606301194 : check e605606301194 [[],[]] .chain = true := by decide
def e605606301230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605606301230 : Closed e605606301230 ∧ code e605606301230 = 2804629556782 := by decide
theorem cert_e605606301230 : check e605606301230 [[],[],[.under,.under]] .three = true := by decide
def e605606301238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605606301238 : Closed e605606301238 ∧ code e605606301238 = 2804629556790 := by decide
theorem cert_e605606301238 : check e605606301238 [[],[]] .chain = true := by decide
def e605606301242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605606301242 : Closed e605606301242 ∧ code e605606301242 = 2804629556794 := by decide
theorem cert_e605606301242 : check e605606301242 [[],[]] .chain = true := by decide
def e605606301290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605606301290 : Closed e605606301290 ∧ code e605606301290 = 2804629556842 := by decide
theorem cert_e605606301290 : check e605606301290 [[],[]] .chain = true := by decide
def e605606301314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605606301314 : Closed e605606301314 ∧ code e605606301314 = 2804629556866 := by decide
theorem cert_e605606301314 : check e605606301314 [[],[]] .chain = true := by decide
def e605606301326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605606301326 : Closed e605606301326 ∧ code e605606301326 = 2804629556878 := by decide
theorem cert_e605606301326 : check e605606301326 [[],[]] .chain = true := by decide
def e605606301338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605606301338 : Closed e605606301338 ∧ code e605606301338 = 2804629556890 := by decide
theorem cert_e605606301338 : check e605606301338 [[],[]] .chain = true := by decide
def e605606301382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605606301382 : Closed e605606301382 ∧ code e605606301382 = 2804629556934 := by decide
theorem cert_e605606301382 : check e605606301382 [[],[]] .chain = true := by decide
def e605606301410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605606301410 : Closed e605606301410 ∧ code e605606301410 = 2804629556962 := by decide
theorem cert_e605606301410 : check e605606301410 [[],[],[.under,.under]] .three = true := by decide
def e605606301422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e605606301422 : Closed e605606301422 ∧ code e605606301422 = 2804629556974 := by decide
theorem cert_e605606301422 : check e605606301422 [[],[],[.under,.under]] .three = true := by decide
def e605606301462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605606301462 : Closed e605606301462 ∧ code e605606301462 = 2804629557014 := by decide
theorem cert_e605606301462 : check e605606301462 [[],[],[.under,.under]] .three = true := by decide
def e605606301538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605606301538 : Closed e605606301538 ∧ code e605606301538 = 2804629557090 := by decide
theorem cert_e605606301538 : check e605606301538 [[],[],[.under,.under]] .three = true := by decide
def e605606301550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e605606301550 : Closed e605606301550 ∧ code e605606301550 = 2804629557102 := by decide
theorem cert_e605606301550 : check e605606301550 [[],[],[.under,.under]] .three = true := by decide
def e605606301558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e605606301558 : Closed e605606301558 ∧ code e605606301558 = 2804629557110 := by decide
theorem cert_e605606301558 : check e605606301558 [[],[],[.under,.under]] .three = true := by decide
def e605606301934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605606301934 : Closed e605606301934 ∧ code e605606301934 = 2804629557486 := by decide
theorem cert_e605606301934 : check e605606301934 [[],[]] .chain = true := by decide
def e605606301942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605606301942 : Closed e605606301942 ∧ code e605606301942 = 2804629557494 := by decide
theorem cert_e605606301942 : check e605606301942 [[],[]] .chain = true := by decide
def e605606302422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605606302422 : Closed e605606302422 ∧ code e605606302422 = 2804629557974 := by decide
theorem cert_e605606302422 : check e605606302422 [[],[]] .chain = true := by decide
def e605606302426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605606302426 : Closed e605606302426 ∧ code e605606302426 = 2804629557978 := by decide
theorem cert_e605606302426 : check e605606302426 [[],[]] .chain = true := by decide
def e605606302442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605606302442 : Closed e605606302442 ∧ code e605606302442 = 2804629557994 := by decide
theorem cert_e605606302442 : check e605606302442 [[],[]] .chain = true := by decide
def e605606302518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606302518 : Closed e605606302518 ∧ code e605606302518 = 2804629558070 := by decide
theorem cert_e605606302518 : check e605606302518 [[],[]] .chain = true := by decide
def e605606302522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606302522 : Closed e605606302522 ∧ code e605606302522 = 2804629558074 := by decide
theorem cert_e605606302522 : check e605606302522 [[],[]] .chain = true := by decide
def e605606302594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605606302594 : Closed e605606302594 ∧ code e605606302594 = 2804629558146 := by decide
theorem cert_e605606302594 : check e605606302594 [[],[]] .chain = true := by decide
def e605606302606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605606302606 : Closed e605606302606 ∧ code e605606302606 = 2804629558158 := by decide
theorem cert_e605606302606 : check e605606302606 [[],[]] .chain = true := by decide
def e605606302618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606302618 : Closed e605606302618 ∧ code e605606302618 = 2804629558170 := by decide
theorem cert_e605606302618 : check e605606302618 [[],[]] .chain = true := by decide
def e605606303770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605606303770 : Closed e605606303770 ∧ code e605606303770 = 2804629559322 := by decide
theorem cert_e605606303770 : check e605606303770 [[],[],[.under,.under]] .three = true := by decide
def e605606303806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e605606303806 : Closed e605606303806 ∧ code e605606303806 = 2804629559358 := by decide
theorem cert_e605606303806 : check e605606303806 [[],[],[.under,.under]] .three = true := by decide
def e605606303854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605606303854 : Closed e605606303854 ∧ code e605606303854 = 2804629559406 := by decide
theorem cert_e605606303854 : check e605606303854 [[],[]] .chain = true := by decide
def e605606303862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605606303862 : Closed e605606303862 ∧ code e605606303862 = 2804629559414 := by decide
theorem cert_e605606303862 : check e605606303862 [[],[]] .chain = true := by decide
def e605606303866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605606303866 : Closed e605606303866 ∧ code e605606303866 = 2804629559418 := by decide
theorem cert_e605606303866 : check e605606303866 [[],[]] .chain = true := by decide
def e605606304106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605606304106 : Closed e605606304106 ∧ code e605606304106 = 2804629559658 := by decide
theorem cert_e605606304106 : check e605606304106 [[],[]] .chain = true := by decide
def e605606304130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605606304130 : Closed e605606304130 ∧ code e605606304130 = 2804629559682 := by decide
theorem cert_e605606304130 : check e605606304130 [[],[]] .chain = true := by decide
def e605606304142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605606304142 : Closed e605606304142 ∧ code e605606304142 = 2804629559694 := by decide
theorem cert_e605606304142 : check e605606304142 [[],[]] .chain = true := by decide
def e605606304154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606304154 : Closed e605606304154 ∧ code e605606304154 = 2804629559706 := by decide
theorem cert_e605606304154 : check e605606304154 [[],[]] .chain = true := by decide
def e605606304198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605606304198 : Closed e605606304198 ∧ code e605606304198 = 2804629559750 := by decide
theorem cert_e605606304198 : check e605606304198 [[],[]] .chain = true := by decide
def e605606304226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605606304226 : Closed e605606304226 ∧ code e605606304226 = 2804629559778 := by decide
theorem cert_e605606304226 : check e605606304226 [[],[],[.under,.under]] .three = true := by decide
def e605606304238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e605606304238 : Closed e605606304238 ∧ code e605606304238 = 2804629559790 := by decide
theorem cert_e605606304238 : check e605606304238 [[],[],[.under,.under]] .three = true := by decide
def e605606304798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e605606304798 : Closed e605606304798 ∧ code e605606304798 = 2804629560350 := by decide
theorem cert_e605606304798 : check e605606304798 [[],[],[.under,.under]] .three = true := by decide
def e605606304994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605606304994 : Closed e605606304994 ∧ code e605606304994 = 2804629560546 := by decide
theorem cert_e605606304994 : check e605606304994 [[],[],[.under,.under]] .three = true := by decide
def e605606305006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e605606305006 : Closed e605606305006 ∧ code e605606305006 = 2804629560558 := by decide
theorem cert_e605606305006 : check e605606305006 [[],[],[.under,.under]] .three = true := by decide
def e605606305014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e605606305014 : Closed e605606305014 ∧ code e605606305014 = 2804629560566 := by decide
theorem cert_e605606305014 : check e605606305014 [[],[],[.under,.under]] .three = true := by decide
def e605606305898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e605606305898 : Closed e605606305898 ∧ code e605606305898 = 2804629561450 := by decide
theorem cert_e605606305898 : check e605606305898 [[],[],[.under,.under]] .three = true := by decide
def e605606305946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e605606305946 : Closed e605606305946 ∧ code e605606305946 = 2804629561498 := by decide
theorem cert_e605606305946 : check e605606305946 [[],[]] .chain = true := by decide
def e605606306030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605606306030 : Closed e605606306030 ∧ code e605606306030 = 2804629561582 := by decide
theorem cert_e605606306030 : check e605606306030 [[],[],[.under,.under]] .three = true := by decide
def e605606306042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e605606306042 : Closed e605606306042 ∧ code e605606306042 = 2804629561594 := by decide
theorem cert_e605606306042 : check e605606306042 [[],[],[.under,.under]] .three = true := by decide
def e605606306230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605606306230 : Closed e605606306230 ∧ code e605606306230 = 2804629561782 := by decide
theorem cert_e605606306230 : check e605606306230 [[],[]] .chain = true := by decide
def e605606306234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605606306234 : Closed e605606306234 ∧ code e605606306234 = 2804629561786 := by decide
theorem cert_e605606306234 : check e605606306234 [[],[]] .chain = true := by decide
def e605606306262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605606306262 : Closed e605606306262 ∧ code e605606306262 = 2804629561814 := by decide
theorem cert_e605606306262 : check e605606306262 [[],[]] .chain = true := by decide
def e605606306266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605606306266 : Closed e605606306266 ∧ code e605606306266 = 2804629561818 := by decide
theorem cert_e605606306266 : check e605606306266 [[],[]] .chain = true := by decide
def e605606306282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605606306282 : Closed e605606306282 ∧ code e605606306282 = 2804629561834 := by decide
theorem cert_e605606306282 : check e605606306282 [[],[]] .chain = true := by decide
def e605606306414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605606306414 : Closed e605606306414 ∧ code e605606306414 = 2804629561966 := by decide
theorem cert_e605606306414 : check e605606306414 [[],[],[.under,.under]] .three = true := by decide
def e605606306426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605606306426 : Closed e605606306426 ∧ code e605606306426 = 2804629561978 := by decide
theorem cert_e605606306426 : check e605606306426 [[],[],[.under,.under]] .three = true := by decide
def e605606306590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e605606306590 : Closed e605606306590 ∧ code e605606306590 = 2804629562142 := by decide
theorem cert_e605606306590 : check e605606306590 [[],[],[.under,.under]] .three = true := by decide
def e605606306614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605606306614 : Closed e605606306614 ∧ code e605606306614 = 2804629562166 := by decide
theorem cert_e605606306614 : check e605606306614 [[],[]] .chain = true := by decide
def e605606306618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605606306618 : Closed e605606306618 ∧ code e605606306618 = 2804629562170 := by decide
theorem cert_e605606306618 : check e605606306618 [[],[]] .chain = true := by decide
def e605606306714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605606306714 : Closed e605606306714 ∧ code e605606306714 = 2804629562266 := by decide
theorem cert_e605606306714 : check e605606306714 [[],[]] .chain = true := by decide
def e605606306758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e605606306758 : Closed e605606306758 ∧ code e605606306758 = 2804629562310 := by decide
theorem cert_e605606306758 : check e605606306758 [[],[],[.under,.under]] .three = true := by decide
def e605606307242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605606307242 : Closed e605606307242 ∧ code e605606307242 = 2804629562794 := by decide
theorem cert_e605606307242 : check e605606307242 [[],[]] .chain = true := by decide
def e605606307338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605606307338 : Closed e605606307338 ∧ code e605606307338 = 2804629562890 := by decide
theorem cert_e605606307338 : check e605606307338 [[],[]] .chain = true := by decide
def e605606307374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605606307374 : Closed e605606307374 ∧ code e605606307374 = 2804629562926 := by decide
theorem cert_e605606307374 : check e605606307374 [[],[],[.under,.under]] .three = true := by decide
def e605606307382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605606307382 : Closed e605606307382 ∧ code e605606307382 = 2804629562934 := by decide
theorem cert_e605606307382 : check e605606307382 [[],[]] .chain = true := by decide
def e605606307386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605606307386 : Closed e605606307386 ∧ code e605606307386 = 2804629562938 := by decide
theorem cert_e605606307386 : check e605606307386 [[],[]] .chain = true := by decide
def e605606307434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605606307434 : Closed e605606307434 ∧ code e605606307434 = 2804629562986 := by decide
theorem cert_e605606307434 : check e605606307434 [[],[]] .chain = true := by decide
def e605606307458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605606307458 : Closed e605606307458 ∧ code e605606307458 = 2804629563010 := by decide
theorem cert_e605606307458 : check e605606307458 [[],[]] .chain = true := by decide
def e605606307470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605606307470 : Closed e605606307470 ∧ code e605606307470 = 2804629563022 := by decide
theorem cert_e605606307470 : check e605606307470 [[],[]] .chain = true := by decide
def e605606307482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605606307482 : Closed e605606307482 ∧ code e605606307482 = 2804629563034 := by decide
theorem cert_e605606307482 : check e605606307482 [[],[]] .chain = true := by decide
def e605606307526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605606307526 : Closed e605606307526 ∧ code e605606307526 = 2804629563078 := by decide
theorem cert_e605606307526 : check e605606307526 [[],[]] .chain = true := by decide
def e605606307554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605606307554 : Closed e605606307554 ∧ code e605606307554 = 2804629563106 := by decide
theorem cert_e605606307554 : check e605606307554 [[],[],[.under,.under]] .three = true := by decide
def e605606307566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e605606307566 : Closed e605606307566 ∧ code e605606307566 = 2804629563118 := by decide
theorem cert_e605606307566 : check e605606307566 [[],[],[.under,.under]] .three = true := by decide
def e605606307610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605606307610 : Closed e605606307610 ∧ code e605606307610 = 2804629563162 := by decide
theorem cert_e605606307610 : check e605606307610 [[],[]] .chain = true := by decide
def e605606307654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605606307654 : Closed e605606307654 ∧ code e605606307654 = 2804629563206 := by decide
theorem cert_e605606307654 : check e605606307654 [[],[]] .chain = true := by decide
def e605606307722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605606307722 : Closed e605606307722 ∧ code e605606307722 = 2804629563274 := by decide
theorem cert_e605606307722 : check e605606307722 [[],[],[.under,.under]] .three = true := by decide
def e605606307746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605606307746 : Closed e605606307746 ∧ code e605606307746 = 2804629563298 := by decide
theorem cert_e605606307746 : check e605606307746 [[],[],[.under,.under]] .three = true := by decide
def e605606307758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e605606307758 : Closed e605606307758 ∧ code e605606307758 = 2804629563310 := by decide
theorem cert_e605606307758 : check e605606307758 [[],[],[.under,.under]] .three = true := by decide
def e605606307770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e605606307770 : Closed e605606307770 ∧ code e605606307770 = 2804629563322 := by decide
theorem cert_e605606307770 : check e605606307770 [[],[],[.under,.under]] .three = true := by decide
def e605606307866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605606307866 : Closed e605606307866 ∧ code e605606307866 = 2804629563418 := by decide
theorem cert_e605606307866 : check e605606307866 [[],[],[.under,.under]] .three = true := by decide
def e605606307902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e605606307902 : Closed e605606307902 ∧ code e605606307902 = 2804629563454 := by decide
theorem cert_e605606307902 : check e605606307902 [[],[],[.under,.under]] .three = true := by decide
def e605606307950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605606307950 : Closed e605606307950 ∧ code e605606307950 = 2804629563502 := by decide
theorem cert_e605606307950 : check e605606307950 [[],[]] .chain = true := by decide
def e605606307958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605606307958 : Closed e605606307958 ∧ code e605606307958 = 2804629563510 := by decide
theorem cert_e605606307958 : check e605606307958 [[],[]] .chain = true := by decide
def e605606307962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605606307962 : Closed e605606307962 ∧ code e605606307962 = 2804629563514 := by decide
theorem cert_e605606307962 : check e605606307962 [[],[]] .chain = true := by decide
def e605606308202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605606308202 : Closed e605606308202 ∧ code e605606308202 = 2804629563754 := by decide
theorem cert_e605606308202 : check e605606308202 [[],[]] .chain = true := by decide
def e605606308226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605606308226 : Closed e605606308226 ∧ code e605606308226 = 2804629563778 := by decide
theorem cert_e605606308226 : check e605606308226 [[],[]] .chain = true := by decide
def e605606308238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605606308238 : Closed e605606308238 ∧ code e605606308238 = 2804629563790 := by decide
theorem cert_e605606308238 : check e605606308238 [[],[]] .chain = true := by decide
def e605606308250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606308250 : Closed e605606308250 ∧ code e605606308250 = 2804629563802 := by decide
theorem cert_e605606308250 : check e605606308250 [[],[]] .chain = true := by decide
def e605606308294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605606308294 : Closed e605606308294 ∧ code e605606308294 = 2804629563846 := by decide
theorem cert_e605606308294 : check e605606308294 [[],[]] .chain = true := by decide
def e605606308322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605606308322 : Closed e605606308322 ∧ code e605606308322 = 2804629563874 := by decide
theorem cert_e605606308322 : check e605606308322 [[],[],[.under,.under]] .three = true := by decide
def e605606308334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e605606308334 : Closed e605606308334 ∧ code e605606308334 = 2804629563886 := by decide
theorem cert_e605606308334 : check e605606308334 [[],[],[.under,.under]] .three = true := by decide
def e605606308918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605606308918 : Closed e605606308918 ∧ code e605606308918 = 2804629564470 := by decide
theorem cert_e605606308918 : check e605606308918 [[],[]] .chain = true := by decide
def e605606308922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605606308922 : Closed e605606308922 ∧ code e605606308922 = 2804629564474 := by decide
theorem cert_e605606308922 : check e605606308922 [[],[]] .chain = true := by decide
def e605606309062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605606309062 : Closed e605606309062 ∧ code e605606309062 = 2804629564614 := by decide
theorem cert_e605606309062 : check e605606309062 [[],[]] .chain = true := by decide
def e605606309390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e605606309390 : Closed e605606309390 ∧ code e605606309390 = 2804629564942 := by decide
theorem cert_e605606309390 : check e605606309390 [[],[],[.under,.under]] .three = true := by decide
def e605606309474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605606309474 : Closed e605606309474 ∧ code e605606309474 = 2804629565026 := by decide
theorem cert_e605606309474 : check e605606309474 [[],[],[.under,.under]] .three = true := by decide
def e605606309486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e605606309486 : Closed e605606309486 ∧ code e605606309486 = 2804629565038 := by decide
theorem cert_e605606309486 : check e605606309486 [[],[],[.under,.under]] .three = true := by decide
def e605606309498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e605606309498 : Closed e605606309498 ∧ code e605606309498 = 2804629565050 := by decide
theorem cert_e605606309498 : check e605606309498 [[],[],[.under,.under]] .three = true := by decide
def e605606310006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605606310006 : Closed e605606310006 ∧ code e605606310006 = 2804629565558 := by decide
theorem cert_e605606310006 : check e605606310006 [[],[],[.under,.under]] .three = true := by decide
def e605606310010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605606310010 : Closed e605606310010 ∧ code e605606310010 = 2804629565562 := by decide
theorem cert_e605606310010 : check e605606310010 [[],[],[.under,.under]] .three = true := by decide
def e605606310198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605606310198 : Closed e605606310198 ∧ code e605606310198 = 2804629565750 := by decide
theorem cert_e605606310198 : check e605606310198 [[],[],[.under,.under]] .three = true := by decide
def e605606310202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605606310202 : Closed e605606310202 ∧ code e605606310202 = 2804629565754 := by decide
theorem cert_e605606310202 : check e605606310202 [[],[],[.under,.under]] .three = true := by decide
def e605606310286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e605606310286 : Closed e605606310286 ∧ code e605606310286 = 2804629565838 := by decide
theorem cert_e605606310286 : check e605606310286 [[],[],[.under,.under]] .three = true := by decide
def e605606310342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e605606310342 : Closed e605606310342 ∧ code e605606310342 = 2804629565894 := by decide
theorem cert_e605606310342 : check e605606310342 [[],[],[.under,.under]] .three = true := by decide
def e605606310678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605606310678 : Closed e605606310678 ∧ code e605606310678 = 2804629566230 := by decide
theorem cert_e605606310678 : check e605606310678 [[],[],[.under,.under]] .three = true := by decide
def e605606310754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605606310754 : Closed e605606310754 ∧ code e605606310754 = 2804629566306 := by decide
theorem cert_e605606310754 : check e605606310754 [[],[],[.under,.under]] .three = true := by decide
def e605606310766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605606310766 : Closed e605606310766 ∧ code e605606310766 = 2804629566318 := by decide
theorem cert_e605606310766 : check e605606310766 [[],[],[.under,.under]] .three = true := by decide
def e605606310774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605606310774 : Closed e605606310774 ∧ code e605606310774 = 2804629566326 := by decide
theorem cert_e605606310774 : check e605606310774 [[],[],[.under,.under]] .three = true := by decide
end Blc.Floor41
