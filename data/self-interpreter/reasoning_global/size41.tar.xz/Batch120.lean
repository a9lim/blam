import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605605160918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605605160918 : Closed e605605160918 ∧ code e605605160918 = 2804628416470 := by decide
theorem cert_e605605160918 : check e605605160918 [[],[]] .chain = true := by decide
def e605605160922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605605160922 : Closed e605605160922 ∧ code e605605160922 = 2804628416474 := by decide
theorem cert_e605605160922 : check e605605160922 [[],[]] .chain = true := by decide
def e605605161438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605605161438 : Closed e605605161438 ∧ code e605605161438 = 2804628416990 := by decide
theorem cert_e605605161438 : check e605605161438 [[],[]] .chain = true := by decide
def e605605161462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605605161462 : Closed e605605161462 ∧ code e605605161462 = 2804628417014 := by decide
theorem cert_e605605161462 : check e605605161462 [[],[]] .chain = true := by decide
def e605605162206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605605162206 : Closed e605605162206 ∧ code e605605162206 = 2804628417758 := by decide
theorem cert_e605605162206 : check e605605162206 [[],[]] .chain = true := by decide
def e605605162222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605605162222 : Closed e605605162222 ∧ code e605605162222 = 2804628417774 := by decide
theorem cert_e605605162222 : check e605605162222 [[],[]] .smaller = true := by decide
def e605605162230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605605162230 : Closed e605605162230 ∧ code e605605162230 = 2804628417782 := by decide
theorem cert_e605605162230 : check e605605162230 [[],[]] .smaller = true := by decide
def e605605162234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605605162234 : Closed e605605162234 ∧ code e605605162234 = 2804628417786 := by decide
theorem cert_e605605162234 : check e605605162234 [[],[]] .chain = true := by decide
def e605605162558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e605605162558 : Closed e605605162558 ∧ code e605605162558 = 2804628418110 := by decide
theorem cert_e605605162558 : check e605605162558 [[],[]] .chain = true := by decide
def e605605162614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605605162614 : Closed e605605162614 ∧ code e605605162614 = 2804628418166 := by decide
theorem cert_e605605162614 : check e605605162614 [[],[]] .smaller = true := by decide
def e605605162782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e605605162782 : Closed e605605162782 ∧ code e605605162782 = 2804628418334 := by decide
theorem cert_e605605162782 : check e605605162782 [[],[]] .chain = true := by decide
def e605605162806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605605162806 : Closed e605605162806 ∧ code e605605162806 = 2804628418358 := by decide
theorem cert_e605605162806 : check e605605162806 [[],[]] .chain = true := by decide
def e605605162810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605605162810 : Closed e605605162810 ∧ code e605605162810 = 2804628418362 := by decide
theorem cert_e605605162810 : check e605605162810 [[],[]] .chain = true := by decide
def e605605163486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.var 3))))))))
theorem wire_e605605163486 : Closed e605605163486 ∧ code e605605163486 = 2804628419038 := by decide
theorem cert_e605605163486 : check e605605163486 [[],[]] .chain = true := by decide
def e605605163510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 1))))))))
theorem wire_e605605163510 : Closed e605605163510 ∧ code e605605163510 = 2804628419062 := by decide
theorem cert_e605605163510 : check e605605163510 [[],[]] .chain = true := by decide
def e605605163870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605605163870 : Closed e605605163870 ∧ code e605605163870 = 2804628419422 := by decide
theorem cert_e605605163870 : check e605605163870 [[],[]] .chain = true := by decide
def e605605163886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605605163886 : Closed e605605163886 ∧ code e605605163886 = 2804628419438 := by decide
theorem cert_e605605163886 : check e605605163886 [[],[]] .smaller = true := by decide
def e605605163894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605605163894 : Closed e605605163894 ∧ code e605605163894 = 2804628419446 := by decide
theorem cert_e605605163894 : check e605605163894 [[],[]] .smaller = true := by decide
def e605605163898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605605163898 : Closed e605605163898 ∧ code e605605163898 = 2804628419450 := by decide
theorem cert_e605605163898 : check e605605163898 [[],[]] .chain = true := by decide
def e605605163950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605605163950 : Closed e605605163950 ∧ code e605605163950 = 2804628419502 := by decide
theorem cert_e605605163950 : check e605605163950 [[],[]] .smaller = true := by decide
def e605605163962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605605163962 : Closed e605605163962 ∧ code e605605163962 = 2804628419514 := by decide
theorem cert_e605605163962 : check e605605163962 [[],[]] .smaller = true := by decide
def e605605163990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605605163990 : Closed e605605163990 ∧ code e605605163990 = 2804628419542 := by decide
theorem cert_e605605163990 : check e605605163990 [[],[]] .smaller = true := by decide
def e605605163994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605605163994 : Closed e605605163994 ∧ code e605605163994 = 2804628419546 := by decide
theorem cert_e605605163994 : check e605605163994 [[],[]] .smaller = true := by decide
def e605605164010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605605164010 : Closed e605605164010 ∧ code e605605164010 = 2804628419562 := by decide
theorem cert_e605605164010 : check e605605164010 [[],[]] .chain = true := by decide
def e605605164254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605605164254 : Closed e605605164254 ∧ code e605605164254 = 2804628419806 := by decide
theorem cert_e605605164254 : check e605605164254 [[],[]] .chain = true := by decide
def e605605164270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605605164270 : Closed e605605164270 ∧ code e605605164270 = 2804628419822 := by decide
theorem cert_e605605164270 : check e605605164270 [[],[]] .smaller = true := by decide
def e605605164278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605605164278 : Closed e605605164278 ∧ code e605605164278 = 2804628419830 := by decide
theorem cert_e605605164278 : check e605605164278 [[],[]] .smaller = true := by decide
def e605605164282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605605164282 : Closed e605605164282 ∧ code e605605164282 = 2804628419834 := by decide
theorem cert_e605605164282 : check e605605164282 [[],[]] .chain = true := by decide
def e605605164606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e605605164606 : Closed e605605164606 ∧ code e605605164606 = 2804628420158 := by decide
theorem cert_e605605164606 : check e605605164606 [[],[]] .chain = true := by decide
def e605605164654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605605164654 : Closed e605605164654 ∧ code e605605164654 = 2804628420206 := by decide
theorem cert_e605605164654 : check e605605164654 [[],[]] .smaller = true := by decide
def e605605164666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605605164666 : Closed e605605164666 ∧ code e605605164666 = 2804628420218 := by decide
theorem cert_e605605164666 : check e605605164666 [[],[]] .smaller = true := by decide
def e605605164854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605605164854 : Closed e605605164854 ∧ code e605605164854 = 2804628420406 := by decide
theorem cert_e605605164854 : check e605605164854 [[],[]] .smaller = true := by decide
def e605605164858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605605164858 : Closed e605605164858 ∧ code e605605164858 = 2804628420410 := by decide
theorem cert_e605605164858 : check e605605164858 [[],[]] .smaller = true := by decide
def e605605164942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e605605164942 : Closed e605605164942 ∧ code e605605164942 = 2804628420494 := by decide
theorem cert_e605605164942 : check e605605164942 [[],[]] .chain = true := by decide
def e605605164954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605164954 : Closed e605605164954 ∧ code e605605164954 = 2804628420506 := by decide
theorem cert_e605605164954 : check e605605164954 [[],[]] .chain = true := by decide
def e605605165278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e605605165278 : Closed e605605165278 ∧ code e605605165278 = 2804628420830 := by decide
theorem cert_e605605165278 : check e605605165278 [[],[]] .chain = true := by decide
def e605605165306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e605605165306 : Closed e605605165306 ∧ code e605605165306 = 2804628420858 := by decide
theorem cert_e605605165306 : check e605605165306 [[],[]] .chain = true := by decide
def e605605165494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605605165494 : Closed e605605165494 ∧ code e605605165494 = 2804628421046 := by decide
theorem cert_e605605165494 : check e605605165494 [[],[]] .smaller = true := by decide
def e605605165526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605605165526 : Closed e605605165526 ∧ code e605605165526 = 2804628421078 := by decide
theorem cert_e605605165526 : check e605605165526 [[],[]] .smaller = true := by decide
def e605605165530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605605165530 : Closed e605605165530 ∧ code e605605165530 = 2804628421082 := by decide
theorem cert_e605605165530 : check e605605165530 [[],[]] .smaller = true := by decide
def e605605165630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e605605165630 : Closed e605605165630 ∧ code e605605165630 = 2804628421182 := by decide
theorem cert_e605605165630 : check e605605165630 [[],[]] .chain = true := by decide
def e605605165686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605605165686 : Closed e605605165686 ∧ code e605605165686 = 2804628421238 := by decide
theorem cert_e605605165686 : check e605605165686 [[],[]] .smaller = true := by decide
def e605605165878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605605165878 : Closed e605605165878 ∧ code e605605165878 = 2804628421430 := by decide
theorem cert_e605605165878 : check e605605165878 [[],[]] .smaller = true := by decide
def e605605165882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605605165882 : Closed e605605165882 ∧ code e605605165882 = 2804628421434 := by decide
theorem cert_e605605165882 : check e605605165882 [[],[]] .smaller = true := by decide
def e605605166022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e605605166022 : Closed e605605166022 ∧ code e605605166022 = 2804628421574 := by decide
theorem cert_e605605166022 : check e605605166022 [[],[]] .chain = true := by decide
def e605605166190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605605166190 : Closed e605605166190 ∧ code e605605166190 = 2804628421742 := by decide
theorem cert_e605605166190 : check e605605166190 [[],[]] .chain = true := by decide
def e605605166198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605605166198 : Closed e605605166198 ∧ code e605605166198 = 2804628421750 := by decide
theorem cert_e605605166198 : check e605605166198 [[],[]] .chain = true := by decide
def e605605166202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605605166202 : Closed e605605166202 ∧ code e605605166202 = 2804628421754 := by decide
theorem cert_e605605166202 : check e605605166202 [[],[]] .chain = true := by decide
def e605605166294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605605166294 : Closed e605605166294 ∧ code e605605166294 = 2804628421846 := by decide
theorem cert_e605605166294 : check e605605166294 [[],[]] .chain = true := by decide
def e605605166298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605605166298 : Closed e605605166298 ∧ code e605605166298 = 2804628421850 := by decide
theorem cert_e605605166298 : check e605605166298 [[],[]] .chain = true := by decide
def e605605166314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605605166314 : Closed e605605166314 ∧ code e605605166314 = 2804628421866 := by decide
theorem cert_e605605166314 : check e605605166314 [[],[]] .chain = true := by decide
def e605605166366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605605166366 : Closed e605605166366 ∧ code e605605166366 = 2804628421918 := by decide
theorem cert_e605605166366 : check e605605166366 [[],[]] .chain = true := by decide
def e605605166390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605605166390 : Closed e605605166390 ∧ code e605605166390 = 2804628421942 := by decide
theorem cert_e605605166390 : check e605605166390 [[],[]] .chain = true := by decide
def e605605166394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605605166394 : Closed e605605166394 ∧ code e605605166394 = 2804628421946 := by decide
theorem cert_e605605166394 : check e605605166394 [[],[]] .chain = true := by decide
def e605605166478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605605166478 : Closed e605605166478 ∧ code e605605166478 = 2804628422030 := by decide
theorem cert_e605605166478 : check e605605166478 [[],[]] .chain = true := by decide
def e605605166490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605166490 : Closed e605605166490 ∧ code e605605166490 = 2804628422042 := by decide
theorem cert_e605605166490 : check e605605166490 [[],[]] .chain = true := by decide
def e605605166534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605605166534 : Closed e605605166534 ∧ code e605605166534 = 2804628422086 := by decide
theorem cert_e605605166534 : check e605605166534 [[],[]] .chain = true := by decide
def e605605172958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605605172958 : Closed e605605172958 ∧ code e605605172958 = 2804628428510 := by decide
theorem cert_e605605172958 : check e605605172958 [[],[]] .chain = true := by decide
def e605605172982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605605172982 : Closed e605605172982 ∧ code e605605172982 = 2804628428534 := by decide
theorem cert_e605605172982 : check e605605172982 [[],[]] .chain = true := by decide
def e605605173086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605605173086 : Closed e605605173086 ∧ code e605605173086 = 2804628428638 := by decide
theorem cert_e605605173086 : check e605605173086 [[],[]] .chain = true := by decide
def e605605173102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605605173102 : Closed e605605173102 ∧ code e605605173102 = 2804628428654 := by decide
theorem cert_e605605173102 : check e605605173102 [[],[]] .smaller = true := by decide
def e605605173110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605605173110 : Closed e605605173110 ∧ code e605605173110 = 2804628428662 := by decide
theorem cert_e605605173110 : check e605605173110 [[],[]] .smaller = true := by decide
def e605605173114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605605173114 : Closed e605605173114 ∧ code e605605173114 = 2804628428666 := by decide
theorem cert_e605605173114 : check e605605173114 [[],[]] .chain = true := by decide
def e605605173174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605605173174 : Closed e605605173174 ∧ code e605605173174 = 2804628428726 := by decide
theorem cert_e605605173174 : check e605605173174 [[],[]] .smaller = true := by decide
def e605605173206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605605173206 : Closed e605605173206 ∧ code e605605173206 = 2804628428758 := by decide
theorem cert_e605605173206 : check e605605173206 [[],[]] .chain = true := by decide
def e605605173210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605605173210 : Closed e605605173210 ∧ code e605605173210 = 2804628428762 := by decide
theorem cert_e605605173210 : check e605605173210 [[],[]] .chain = true := by decide
def e605605173726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605605173726 : Closed e605605173726 ∧ code e605605173726 = 2804628429278 := by decide
theorem cert_e605605173726 : check e605605173726 [[],[]] .chain = true := by decide
def e605605173750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605605173750 : Closed e605605173750 ∧ code e605605173750 = 2804628429302 := by decide
theorem cert_e605605173750 : check e605605173750 [[],[]] .chain = true := by decide
def e605605174494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605605174494 : Closed e605605174494 ∧ code e605605174494 = 2804628430046 := by decide
theorem cert_e605605174494 : check e605605174494 [[],[]] .chain = true := by decide
def e605605174510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605605174510 : Closed e605605174510 ∧ code e605605174510 = 2804628430062 := by decide
theorem cert_e605605174510 : check e605605174510 [[],[]] .smaller = true := by decide
def e605605174518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605605174518 : Closed e605605174518 ∧ code e605605174518 = 2804628430070 := by decide
theorem cert_e605605174518 : check e605605174518 [[],[]] .smaller = true := by decide
def e605605174522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605605174522 : Closed e605605174522 ∧ code e605605174522 = 2804628430074 := by decide
theorem cert_e605605174522 : check e605605174522 [[],[]] .chain = true := by decide
def e605605174846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605605174846 : Closed e605605174846 ∧ code e605605174846 = 2804628430398 := by decide
theorem cert_e605605174846 : check e605605174846 [[],[]] .chain = true := by decide
def e605605174902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605605174902 : Closed e605605174902 ∧ code e605605174902 = 2804628430454 := by decide
theorem cert_e605605174902 : check e605605174902 [[],[]] .smaller = true := by decide
def e605605175070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605605175070 : Closed e605605175070 ∧ code e605605175070 = 2804628430622 := by decide
theorem cert_e605605175070 : check e605605175070 [[],[]] .chain = true := by decide
def e605605175094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605175094 : Closed e605605175094 ∧ code e605605175094 = 2804628430646 := by decide
theorem cert_e605605175094 : check e605605175094 [[],[]] .chain = true := by decide
def e605605175098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605175098 : Closed e605605175098 ∧ code e605605175098 = 2804628430650 := by decide
theorem cert_e605605175098 : check e605605175098 [[],[]] .chain = true := by decide
def e605605186398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605605186398 : Closed e605605186398 ∧ code e605605186398 = 2804628441950 := by decide
theorem cert_e605605186398 : check e605605186398 [[],[]] .chain = true := by decide
def e605605186414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605605186414 : Closed e605605186414 ∧ code e605605186414 = 2804628441966 := by decide
theorem cert_e605605186414 : check e605605186414 [[],[]] .smaller = true := by decide
def e605605186422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605605186422 : Closed e605605186422 ∧ code e605605186422 = 2804628441974 := by decide
theorem cert_e605605186422 : check e605605186422 [[],[]] .smaller = true := by decide
def e605605186426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605605186426 : Closed e605605186426 ∧ code e605605186426 = 2804628441978 := by decide
theorem cert_e605605186426 : check e605605186426 [[],[]] .chain = true := by decide
def e605605186478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605605186478 : Closed e605605186478 ∧ code e605605186478 = 2804628442030 := by decide
theorem cert_e605605186478 : check e605605186478 [[],[]] .smaller = true := by decide
def e605605186490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605605186490 : Closed e605605186490 ∧ code e605605186490 = 2804628442042 := by decide
theorem cert_e605605186490 : check e605605186490 [[],[]] .smaller = true := by decide
def e605605186518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605605186518 : Closed e605605186518 ∧ code e605605186518 = 2804628442070 := by decide
theorem cert_e605605186518 : check e605605186518 [[],[]] .smaller = true := by decide
def e605605186522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605605186522 : Closed e605605186522 ∧ code e605605186522 = 2804628442074 := by decide
theorem cert_e605605186522 : check e605605186522 [[],[]] .smaller = true := by decide
def e605605186538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605605186538 : Closed e605605186538 ∧ code e605605186538 = 2804628442090 := by decide
theorem cert_e605605186538 : check e605605186538 [[],[]] .chain = true := by decide
def e605605186782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605605186782 : Closed e605605186782 ∧ code e605605186782 = 2804628442334 := by decide
theorem cert_e605605186782 : check e605605186782 [[],[]] .chain = true := by decide
def e605605186798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605605186798 : Closed e605605186798 ∧ code e605605186798 = 2804628442350 := by decide
theorem cert_e605605186798 : check e605605186798 [[],[]] .smaller = true := by decide
def e605605186806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605605186806 : Closed e605605186806 ∧ code e605605186806 = 2804628442358 := by decide
theorem cert_e605605186806 : check e605605186806 [[],[]] .smaller = true := by decide
def e605605186810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605605186810 : Closed e605605186810 ∧ code e605605186810 = 2804628442362 := by decide
theorem cert_e605605186810 : check e605605186810 [[],[]] .chain = true := by decide
def e605605187134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605605187134 : Closed e605605187134 ∧ code e605605187134 = 2804628442686 := by decide
theorem cert_e605605187134 : check e605605187134 [[],[]] .chain = true := by decide
def e605605187182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605605187182 : Closed e605605187182 ∧ code e605605187182 = 2804628442734 := by decide
theorem cert_e605605187182 : check e605605187182 [[],[]] .smaller = true := by decide
def e605605187194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605605187194 : Closed e605605187194 ∧ code e605605187194 = 2804628442746 := by decide
theorem cert_e605605187194 : check e605605187194 [[],[]] .smaller = true := by decide
def e605605187382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605187382 : Closed e605605187382 ∧ code e605605187382 = 2804628442934 := by decide
theorem cert_e605605187382 : check e605605187382 [[],[]] .smaller = true := by decide
def e605605187386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605187386 : Closed e605605187386 ∧ code e605605187386 = 2804628442938 := by decide
theorem cert_e605605187386 : check e605605187386 [[],[]] .smaller = true := by decide
def e605605187470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605605187470 : Closed e605605187470 ∧ code e605605187470 = 2804628443022 := by decide
theorem cert_e605605187470 : check e605605187470 [[],[]] .chain = true := by decide
def e605605187482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605605187482 : Closed e605605187482 ∧ code e605605187482 = 2804628443034 := by decide
theorem cert_e605605187482 : check e605605187482 [[],[]] .chain = true := by decide
def e605605193142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605605193142 : Closed e605605193142 ∧ code e605605193142 = 2804628448694 := by decide
theorem cert_e605605193142 : check e605605193142 [[],[]] .smaller = true := by decide
def e605605193174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605605193174 : Closed e605605193174 ∧ code e605605193174 = 2804628448726 := by decide
theorem cert_e605605193174 : check e605605193174 [[],[]] .smaller = true := by decide
def e605605193178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605605193178 : Closed e605605193178 ∧ code e605605193178 = 2804628448730 := by decide
theorem cert_e605605193178 : check e605605193178 [[],[]] .smaller = true := by decide
def e605605193278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e605605193278 : Closed e605605193278 ∧ code e605605193278 = 2804628448830 := by decide
theorem cert_e605605193278 : check e605605193278 [[],[]] .chain = true := by decide
def e605605193334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605605193334 : Closed e605605193334 ∧ code e605605193334 = 2804628448886 := by decide
theorem cert_e605605193334 : check e605605193334 [[],[]] .smaller = true := by decide
def e605605193526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605193526 : Closed e605605193526 ∧ code e605605193526 = 2804628449078 := by decide
theorem cert_e605605193526 : check e605605193526 [[],[]] .smaller = true := by decide
def e605605193530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605193530 : Closed e605605193530 ∧ code e605605193530 = 2804628449082 := by decide
theorem cert_e605605193530 : check e605605193530 [[],[]] .smaller = true := by decide
def e605605193670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e605605193670 : Closed e605605193670 ∧ code e605605193670 = 2804628449222 := by decide
theorem cert_e605605193670 : check e605605193670 [[],[]] .chain = true := by decide
def e605605196502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605605196502 : Closed e605605196502 ∧ code e605605196502 = 2804628452054 := by decide
theorem cert_e605605196502 : check e605605196502 [[],[]] .chain = true := by decide
def e605605196506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605605196506 : Closed e605605196506 ∧ code e605605196506 = 2804628452058 := by decide
theorem cert_e605605196506 : check e605605196506 [[],[]] .chain = true := by decide
def e605605196522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605605196522 : Closed e605605196522 ∧ code e605605196522 = 2804628452074 := by decide
theorem cert_e605605196522 : check e605605196522 [[],[]] .chain = true := by decide
def e605605196574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605605196574 : Closed e605605196574 ∧ code e605605196574 = 2804628452126 := by decide
theorem cert_e605605196574 : check e605605196574 [[],[]] .chain = true := by decide
def e605605196598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605196598 : Closed e605605196598 ∧ code e605605196598 = 2804628452150 := by decide
theorem cert_e605605196598 : check e605605196598 [[],[]] .chain = true := by decide
def e605605196602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605196602 : Closed e605605196602 ∧ code e605605196602 = 2804628452154 := by decide
theorem cert_e605605196602 : check e605605196602 [[],[]] .chain = true := by decide
def e605605196686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605605196686 : Closed e605605196686 ∧ code e605605196686 = 2804628452238 := by decide
theorem cert_e605605196686 : check e605605196686 [[],[]] .chain = true := by decide
def e605605196698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605605196698 : Closed e605605196698 ∧ code e605605196698 = 2804628452250 := by decide
theorem cert_e605605196698 : check e605605196698 [[],[]] .chain = true := by decide
def e605605196742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605605196742 : Closed e605605196742 ∧ code e605605196742 = 2804628452294 := by decide
theorem cert_e605605196742 : check e605605196742 [[],[]] .chain = true := by decide
def e605605419694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605605419694 : Closed e605605419694 ∧ code e605605419694 = 2804628675246 := by decide
theorem cert_e605605419694 : check e605605419694 [[],[]] .chain = true := by decide
def e605605419706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605605419706 : Closed e605605419706 ∧ code e605605419706 = 2804628675258 := by decide
theorem cert_e605605419706 : check e605605419706 [[],[]] .chain = true := by decide
def e605605419754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605605419754 : Closed e605605419754 ∧ code e605605419754 = 2804628675306 := by decide
theorem cert_e605605419754 : check e605605419754 [[],[]] .chain = true := by decide
def e605605419946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605605419946 : Closed e605605419946 ∧ code e605605419946 = 2804628675498 := by decide
theorem cert_e605605419946 : check e605605419946 [[],[]] .chain = true := by decide
def e605605420714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605605420714 : Closed e605605420714 ∧ code e605605420714 = 2804628676266 := by decide
theorem cert_e605605420714 : check e605605420714 [[],[]] .chain = true := by decide
def e605605421230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605605421230 : Closed e605605421230 ∧ code e605605421230 = 2804628676782 := by decide
theorem cert_e605605421230 : check e605605421230 [[],[]] .chain = true := by decide
def e605605421242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605605421242 : Closed e605605421242 ∧ code e605605421242 = 2804628676794 := by decide
theorem cert_e605605421242 : check e605605421242 [[],[]] .chain = true := by decide
def e605605421806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e605605421806 : Closed e605605421806 ∧ code e605605421806 = 2804628677358 := by decide
theorem cert_e605605421806 : check e605605421806 [[],[]] .sourceHead = true := by decide
def e605605421934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605605421934 : Closed e605605421934 ∧ code e605605421934 = 2804628677486 := by decide
theorem cert_e605605421934 : check e605605421934 [[],[]] .chain = true := by decide
def e605605421942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605605421942 : Closed e605605421942 ∧ code e605605421942 = 2804628677494 := by decide
theorem cert_e605605421942 : check e605605421942 [[],[]] .chain = true := by decide
def e605605421998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605605421998 : Closed e605605421998 ∧ code e605605421998 = 2804628677550 := by decide
theorem cert_e605605421998 : check e605605421998 [[],[]] .chain = true := by decide
def e605605422010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605605422010 : Closed e605605422010 ∧ code e605605422010 = 2804628677562 := by decide
theorem cert_e605605422010 : check e605605422010 [[],[]] .chain = true := by decide
def e605605422038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605605422038 : Closed e605605422038 ∧ code e605605422038 = 2804628677590 := by decide
theorem cert_e605605422038 : check e605605422038 [[],[]] .chain = true := by decide
def e605605422042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605605422042 : Closed e605605422042 ∧ code e605605422042 = 2804628677594 := by decide
theorem cert_e605605422042 : check e605605422042 [[],[]] .chain = true := by decide
def e605605422766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605605422766 : Closed e605605422766 ∧ code e605605422766 = 2804628678318 := by decide
theorem cert_e605605422766 : check e605605422766 [[],[]] .chain = true := by decide
def e605605422778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605605422778 : Closed e605605422778 ∧ code e605605422778 = 2804628678330 := by decide
theorem cert_e605605422778 : check e605605422778 [[],[]] .chain = true := by decide
def e605605422826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605605422826 : Closed e605605422826 ∧ code e605605422826 = 2804628678378 := by decide
theorem cert_e605605422826 : check e605605422826 [[],[]] .chain = true := by decide
def e605605423018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605605423018 : Closed e605605423018 ∧ code e605605423018 = 2804628678570 := by decide
theorem cert_e605605423018 : check e605605423018 [[],[]] .chain = true := by decide
def e605605423150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605605423150 : Closed e605605423150 ∧ code e605605423150 = 2804628678702 := by decide
theorem cert_e605605423150 : check e605605423150 [[],[]] .chain = true := by decide
def e605605423342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605605423342 : Closed e605605423342 ∧ code e605605423342 = 2804628678894 := by decide
theorem cert_e605605423342 : check e605605423342 [[],[]] .chain = true := by decide
def e605605423350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605605423350 : Closed e605605423350 ∧ code e605605423350 = 2804628678902 := by decide
theorem cert_e605605423350 : check e605605423350 [[],[]] .chain = true := by decide
def e605605423534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605605423534 : Closed e605605423534 ∧ code e605605423534 = 2804628679086 := by decide
theorem cert_e605605423534 : check e605605423534 [[],[]] .chain = true := by decide
def e605605423546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605605423546 : Closed e605605423546 ∧ code e605605423546 = 2804628679098 := by decide
theorem cert_e605605423546 : check e605605423546 [[],[]] .chain = true := by decide
def e605605423594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605605423594 : Closed e605605423594 ∧ code e605605423594 = 2804628679146 := by decide
theorem cert_e605605423594 : check e605605423594 [[],[]] .chain = true := by decide
def e605605423726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605605423726 : Closed e605605423726 ∧ code e605605423726 = 2804628679278 := by decide
theorem cert_e605605423726 : check e605605423726 [[],[]] .chain = true := by decide
def e605605423738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605605423738 : Closed e605605423738 ∧ code e605605423738 = 2804628679290 := by decide
theorem cert_e605605423738 : check e605605423738 [[],[]] .chain = true := by decide
def e605605423902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605605423902 : Closed e605605423902 ∧ code e605605423902 = 2804628679454 := by decide
theorem cert_e605605423902 : check e605605423902 [[],[]] .chain = true := by decide
def e605605424002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605605424002 : Closed e605605424002 ∧ code e605605424002 = 2804628679554 := by decide
theorem cert_e605605424002 : check e605605424002 [[],[]] .chain = true := by decide
def e605605424014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605605424014 : Closed e605605424014 ∧ code e605605424014 = 2804628679566 := by decide
theorem cert_e605605424014 : check e605605424014 [[],[]] .chain = true := by decide
def e605605424026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605605424026 : Closed e605605424026 ∧ code e605605424026 = 2804628679578 := by decide
theorem cert_e605605424026 : check e605605424026 [[],[]] .chain = true := by decide
def e605605424238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605605424238 : Closed e605605424238 ∧ code e605605424238 = 2804628679790 := by decide
theorem cert_e605605424238 : check e605605424238 [[],[]] .chain = true := by decide
def e605605424250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605605424250 : Closed e605605424250 ∧ code e605605424250 = 2804628679802 := by decide
theorem cert_e605605424250 : check e605605424250 [[],[]] .chain = true := by decide
def e605605424414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605605424414 : Closed e605605424414 ∧ code e605605424414 = 2804628679966 := by decide
theorem cert_e605605424414 : check e605605424414 [[],[]] .chain = true := by decide
def e605605424582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605605424582 : Closed e605605424582 ∧ code e605605424582 = 2804628680134 := by decide
theorem cert_e605605424582 : check e605605424582 [[],[]] .chain = true := by decide
def e605605424650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605605424650 : Closed e605605424650 ∧ code e605605424650 = 2804628680202 := by decide
theorem cert_e605605424650 : check e605605424650 [[],[]] .chain = true := by decide
def e605605424686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605605424686 : Closed e605605424686 ∧ code e605605424686 = 2804628680238 := by decide
theorem cert_e605605424686 : check e605605424686 [[],[]] .sourceHead = true := by decide
def e605605424694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605605424694 : Closed e605605424694 ∧ code e605605424694 = 2804628680246 := by decide
theorem cert_e605605424694 : check e605605424694 [[],[]] .chain = true := by decide
def e605605424698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605605424698 : Closed e605605424698 ∧ code e605605424698 = 2804628680250 := by decide
theorem cert_e605605424698 : check e605605424698 [[],[]] .chain = true := by decide
def e605605424746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605605424746 : Closed e605605424746 ∧ code e605605424746 = 2804628680298 := by decide
theorem cert_e605605424746 : check e605605424746 [[],[]] .chain = true := by decide
def e605605424770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605605424770 : Closed e605605424770 ∧ code e605605424770 = 2804628680322 := by decide
theorem cert_e605605424770 : check e605605424770 [[],[]] .chain = true := by decide
def e605605424782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605605424782 : Closed e605605424782 ∧ code e605605424782 = 2804628680334 := by decide
theorem cert_e605605424782 : check e605605424782 [[],[]] .chain = true := by decide
def e605605424794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605605424794 : Closed e605605424794 ∧ code e605605424794 = 2804628680346 := by decide
theorem cert_e605605424794 : check e605605424794 [[],[]] .chain = true := by decide
def e605605424838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605605424838 : Closed e605605424838 ∧ code e605605424838 = 2804628680390 := by decide
theorem cert_e605605424838 : check e605605424838 [[],[]] .chain = true := by decide
def e605605424866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605605424866 : Closed e605605424866 ∧ code e605605424866 = 2804628680418 := by decide
theorem cert_e605605424866 : check e605605424866 [[],[]] .sourceHead = true := by decide
def e605605424878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)))))))
theorem wire_e605605424878 : Closed e605605424878 ∧ code e605605424878 = 2804628680430 := by decide
theorem cert_e605605424878 : check e605605424878 [[],[]] .sourceHead = true := by decide
def e605605425582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605605425582 : Closed e605605425582 ∧ code e605605425582 = 2804628681134 := by decide
theorem cert_e605605425582 : check e605605425582 [[],[]] .chain = true := by decide
end Blc.Floor41
