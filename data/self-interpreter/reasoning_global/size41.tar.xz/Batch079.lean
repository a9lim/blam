import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593208750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2)))))))
theorem wire_e605593208750 : Closed e605593208750 ∧ code e605593208750 = 2804616464302 := by decide
theorem cert_e605593208750 : check e605593208750 [[],[]] .smaller = true := by decide
def e605593208762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 0)))))))
theorem wire_e605593208762 : Closed e605593208762 ∧ code e605593208762 = 2804616464314 := by decide
theorem cert_e605593208762 : check e605593208762 [[],[]] .smaller = true := by decide
def e605593208790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1)))))))
theorem wire_e605593208790 : Closed e605593208790 ∧ code e605593208790 = 2804616464342 := by decide
theorem cert_e605593208790 : check e605593208790 [[],[]] .smaller = true := by decide
def e605593208794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 0)))))))
theorem wire_e605593208794 : Closed e605593208794 ∧ code e605593208794 = 2804616464346 := by decide
theorem cert_e605593208794 : check e605593208794 [[],[]] .smaller = true := by decide
def e605593210222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e605593210222 : Closed e605593210222 ∧ code e605593210222 = 2804616465774 := by decide
theorem cert_e605593210222 : check e605593210222 [[],[]] .smaller = true := by decide
def e605593210230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e605593210230 : Closed e605593210230 ∧ code e605593210230 = 2804616465782 := by decide
theorem cert_e605593210230 : check e605593210230 [[],[]] .smaller = true := by decide
def e605593211758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605593211758 : Closed e605593211758 ∧ code e605593211758 = 2804616467310 := by decide
theorem cert_e605593211758 : check e605593211758 [[],[]] .smaller = true := by decide
def e605593211766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605593211766 : Closed e605593211766 ∧ code e605593211766 = 2804616467318 := by decide
theorem cert_e605593211766 : check e605593211766 [[],[]] .smaller = true := by decide
def e605593211822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605593211822 : Closed e605593211822 ∧ code e605593211822 = 2804616467374 := by decide
theorem cert_e605593211822 : check e605593211822 [[],[]] .smaller = true := by decide
def e605593211834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605593211834 : Closed e605593211834 ∧ code e605593211834 = 2804616467386 := by decide
theorem cert_e605593211834 : check e605593211834 [[],[]] .smaller = true := by decide
def e605593211862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605593211862 : Closed e605593211862 ∧ code e605593211862 = 2804616467414 := by decide
theorem cert_e605593211862 : check e605593211862 [[],[]] .smaller = true := by decide
def e605593211866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605593211866 : Closed e605593211866 ∧ code e605593211866 = 2804616467418 := by decide
theorem cert_e605593211866 : check e605593211866 [[],[]] .smaller = true := by decide
def e605593212142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593212142 : Closed e605593212142 ∧ code e605593212142 = 2804616467694 := by decide
theorem cert_e605593212142 : check e605593212142 [[],[]] .smaller = true := by decide
def e605593212150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593212150 : Closed e605593212150 ∧ code e605593212150 = 2804616467702 := by decide
theorem cert_e605593212150 : check e605593212150 [[],[]] .smaller = true := by decide
def e605593212526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593212526 : Closed e605593212526 ∧ code e605593212526 = 2804616468078 := by decide
theorem cert_e605593212526 : check e605593212526 [[],[]] .smaller = true := by decide
def e605593212538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593212538 : Closed e605593212538 ∧ code e605593212538 = 2804616468090 := by decide
theorem cert_e605593212538 : check e605593212538 [[],[]] .smaller = true := by decide
def e605593212726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593212726 : Closed e605593212726 ∧ code e605593212726 = 2804616468278 := by decide
theorem cert_e605593212726 : check e605593212726 [[],[]] .smaller = true := by decide
def e605593212730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593212730 : Closed e605593212730 ∧ code e605593212730 = 2804616468282 := by decide
theorem cert_e605593212730 : check e605593212730 [[],[]] .smaller = true := by decide
def e605593213166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605593213166 : Closed e605593213166 ∧ code e605593213166 = 2804616468718 := by decide
theorem cert_e605593213166 : check e605593213166 [[],[]] .smaller = true := by decide
def e605593213174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605593213174 : Closed e605593213174 ∧ code e605593213174 = 2804616468726 := by decide
theorem cert_e605593213174 : check e605593213174 [[],[]] .smaller = true := by decide
def e605593213726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605593213726 : Closed e605593213726 ∧ code e605593213726 = 2804616469278 := by decide
theorem cert_e605593213726 : check e605593213726 [[],[]] .smaller = true := by decide
def e605593213838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605593213838 : Closed e605593213838 ∧ code e605593213838 = 2804616469390 := by decide
theorem cert_e605593213838 : check e605593213838 [[],[]] .smaller = true := by decide
def e605593214062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605593214062 : Closed e605593214062 ∧ code e605593214062 = 2804616469614 := by decide
theorem cert_e605593214062 : check e605593214062 [[],[]] .smaller = true := by decide
def e605593214074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605593214074 : Closed e605593214074 ∧ code e605593214074 = 2804616469626 := by decide
theorem cert_e605593214074 : check e605593214074 [[],[]] .smaller = true := by decide
def e605593214238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605593214238 : Closed e605593214238 ∧ code e605593214238 = 2804616469790 := by decide
theorem cert_e605593214238 : check e605593214238 [[],[]] .smaller = true := by decide
def e605593214406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605593214406 : Closed e605593214406 ∧ code e605593214406 = 2804616469958 := by decide
theorem cert_e605593214406 : check e605593214406 [[],[]] .smaller = true := by decide
def e605593214518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605593214518 : Closed e605593214518 ∧ code e605593214518 = 2804616470070 := by decide
theorem cert_e605593214518 : check e605593214518 [[],[]] .smaller = true := by decide
def e605593214522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605593214522 : Closed e605593214522 ∧ code e605593214522 = 2804616470074 := by decide
theorem cert_e605593214522 : check e605593214522 [[],[]] .smaller = true := by decide
def e605593214606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605593214606 : Closed e605593214606 ∧ code e605593214606 = 2804616470158 := by decide
theorem cert_e605593214606 : check e605593214606 [[],[]] .smaller = true := by decide
def e605593214662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605593214662 : Closed e605593214662 ∧ code e605593214662 = 2804616470214 := by decide
theorem cert_e605593214662 : check e605593214662 [[],[]] .smaller = true := by decide
def e605593219438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e605593219438 : Closed e605593219438 ∧ code e605593219438 = 2804616474990 := by decide
theorem cert_e605593219438 : check e605593219438 [[],[]] .smaller = true := by decide
def e605593219446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e605593219446 : Closed e605593219446 ∧ code e605593219446 = 2804616474998 := by decide
theorem cert_e605593219446 : check e605593219446 [[],[]] .smaller = true := by decide
def e605593220574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e605593220574 : Closed e605593220574 ∧ code e605593220574 = 2804616476126 := by decide
theorem cert_e605593220574 : check e605593220574 [[],[]] .three = true := by decide
def e605593220590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e605593220590 : Closed e605593220590 ∧ code e605593220590 = 2804616476142 := by decide
theorem cert_e605593220590 : check e605593220590 [[],[]] .three = true := by decide
def e605593220654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605593220654 : Closed e605593220654 ∧ code e605593220654 = 2804616476206 := by decide
theorem cert_e605593220654 : check e605593220654 [[],[]] .smaller = true := by decide
def e605593220830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e605593220830 : Closed e605593220830 ∧ code e605593220830 = 2804616476382 := by decide
theorem cert_e605593220830 : check e605593220830 [[],[]] .three = true := by decide
def e605593220834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605593220834 : Closed e605593220834 ∧ code e605593220834 = 2804616476386 := by decide
theorem cert_e605593220834 : check e605593220834 [[],[]] .smaller = true := by decide
def e605593220846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e605593220846 : Closed e605593220846 ∧ code e605593220846 = 2804616476398 := by decide
theorem cert_e605593220846 : check e605593220846 [[],[]] .smaller = true := by decide
def e605593220854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e605593220854 : Closed e605593220854 ∧ code e605593220854 = 2804616476406 := by decide
theorem cert_e605593220854 : check e605593220854 [[],[]] .three = true := by decide
def e605593220886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605593220886 : Closed e605593220886 ∧ code e605593220886 = 2804616476438 := by decide
theorem cert_e605593220886 : check e605593220886 [[],[]] .smaller = true := by decide
def e605593220958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e605593220958 : Closed e605593220958 ∧ code e605593220958 = 2804616476510 := by decide
theorem cert_e605593220958 : check e605593220958 [[],[]] .three = true := by decide
def e605593220962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605593220962 : Closed e605593220962 ∧ code e605593220962 = 2804616476514 := by decide
theorem cert_e605593220962 : check e605593220962 [[],[]] .smaller = true := by decide
def e605593220974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e605593220974 : Closed e605593220974 ∧ code e605593220974 = 2804616476526 := by decide
theorem cert_e605593220974 : check e605593220974 [[],[]] .smaller = true := by decide
def e605593220982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e605593220982 : Closed e605593220982 ∧ code e605593220982 = 2804616476534 := by decide
theorem cert_e605593220982 : check e605593220982 [[],[]] .smaller = true := by decide
def e605593220986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e605593220986 : Closed e605593220986 ∧ code e605593220986 = 2804616476538 := by decide
theorem cert_e605593220986 : check e605593220986 [[],[]] .three = true := by decide
def e605593221038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e605593221038 : Closed e605593221038 ∧ code e605593221038 = 2804616476590 := by decide
theorem cert_e605593221038 : check e605593221038 [[],[]] .three = true := by decide
def e605593221046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e605593221046 : Closed e605593221046 ∧ code e605593221046 = 2804616476598 := by decide
theorem cert_e605593221046 : check e605593221046 [[],[]] .three = true := by decide
def e605593221050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e605593221050 : Closed e605593221050 ∧ code e605593221050 = 2804616476602 := by decide
theorem cert_e605593221050 : check e605593221050 [[],[]] .three = true := by decide
def e605593221294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605593221294 : Closed e605593221294 ∧ code e605593221294 = 2804616476846 := by decide
theorem cert_e605593221294 : check e605593221294 [[],[]] .smaller = true := by decide
def e605593221306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605593221306 : Closed e605593221306 ∧ code e605593221306 = 2804616476858 := by decide
theorem cert_e605593221306 : check e605593221306 [[],[]] .smaller = true := by decide
def e605593221678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605593221678 : Closed e605593221678 ∧ code e605593221678 = 2804616477230 := by decide
theorem cert_e605593221678 : check e605593221678 [[],[]] .smaller = true := by decide
def e605593221854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e605593221854 : Closed e605593221854 ∧ code e605593221854 = 2804616477406 := by decide
theorem cert_e605593221854 : check e605593221854 [[],[]] .three = true := by decide
def e605593221858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605593221858 : Closed e605593221858 ∧ code e605593221858 = 2804616477410 := by decide
theorem cert_e605593221858 : check e605593221858 [[],[]] .smaller = true := by decide
def e605593221870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e605593221870 : Closed e605593221870 ∧ code e605593221870 = 2804616477422 := by decide
theorem cert_e605593221870 : check e605593221870 [[],[]] .smaller = true := by decide
def e605593221878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e605593221878 : Closed e605593221878 ∧ code e605593221878 = 2804616477430 := by decide
theorem cert_e605593221878 : check e605593221878 [[],[]] .three = true := by decide
def e605593221982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e605593221982 : Closed e605593221982 ∧ code e605593221982 = 2804616477534 := by decide
theorem cert_e605593221982 : check e605593221982 [[],[]] .three = true := by decide
def e605593221998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605593221998 : Closed e605593221998 ∧ code e605593221998 = 2804616477550 := by decide
theorem cert_e605593221998 : check e605593221998 [[],[]] .smaller = true := by decide
def e605593222006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605593222006 : Closed e605593222006 ∧ code e605593222006 = 2804616477558 := by decide
theorem cert_e605593222006 : check e605593222006 [[],[]] .smaller = true := by decide
def e605593222010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e605593222010 : Closed e605593222010 ∧ code e605593222010 = 2804616477562 := by decide
theorem cert_e605593222010 : check e605593222010 [[],[]] .three = true := by decide
def e605593222026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593222026 : Closed e605593222026 ∧ code e605593222026 = 2804616477578 := by decide
theorem cert_e605593222026 : check e605593222026 [[],[]] .smaller = true := by decide
def e605593222050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593222050 : Closed e605593222050 ∧ code e605593222050 = 2804616477602 := by decide
theorem cert_e605593222050 : check e605593222050 [[],[]] .smaller = true := by decide
def e605593222062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605593222062 : Closed e605593222062 ∧ code e605593222062 = 2804616477614 := by decide
theorem cert_e605593222062 : check e605593222062 [[],[]] .smaller = true := by decide
def e605593222070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e605593222070 : Closed e605593222070 ∧ code e605593222070 = 2804616477622 := by decide
theorem cert_e605593222070 : check e605593222070 [[],[]] .smaller = true := by decide
def e605593222074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605593222074 : Closed e605593222074 ∧ code e605593222074 = 2804616477626 := by decide
theorem cert_e605593222074 : check e605593222074 [[],[]] .smaller = true := by decide
def e605593222102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605593222102 : Closed e605593222102 ∧ code e605593222102 = 2804616477654 := by decide
theorem cert_e605593222102 : check e605593222102 [[],[]] .three = true := by decide
def e605593222106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605593222106 : Closed e605593222106 ∧ code e605593222106 = 2804616477658 := by decide
theorem cert_e605593222106 : check e605593222106 [[],[]] .three = true := by decide
def e605593222230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605593222230 : Closed e605593222230 ∧ code e605593222230 = 2804616477782 := by decide
theorem cert_e605593222230 : check e605593222230 [[],[]] .smaller = true := by decide
def e605593222234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605593222234 : Closed e605593222234 ∧ code e605593222234 = 2804616477786 := by decide
theorem cert_e605593222234 : check e605593222234 [[],[]] .smaller = true := by decide
def e605593222422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605593222422 : Closed e605593222422 ∧ code e605593222422 = 2804616477974 := by decide
theorem cert_e605593222422 : check e605593222422 [[],[]] .smaller = true := by decide
def e605593222494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e605593222494 : Closed e605593222494 ∧ code e605593222494 = 2804616478046 := by decide
theorem cert_e605593222494 : check e605593222494 [[],[]] .three = true := by decide
def e605593222498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605593222498 : Closed e605593222498 ∧ code e605593222498 = 2804616478050 := by decide
theorem cert_e605593222498 : check e605593222498 [[],[]] .smaller = true := by decide
def e605593222510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605593222510 : Closed e605593222510 ∧ code e605593222510 = 2804616478062 := by decide
theorem cert_e605593222510 : check e605593222510 [[],[]] .smaller = true := by decide
def e605593222518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605593222518 : Closed e605593222518 ∧ code e605593222518 = 2804616478070 := by decide
theorem cert_e605593222518 : check e605593222518 [[],[]] .smaller = true := by decide
def e605593222522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e605593222522 : Closed e605593222522 ∧ code e605593222522 = 2804616478074 := by decide
theorem cert_e605593222522 : check e605593222522 [[],[]] .three = true := by decide
def e605593222538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593222538 : Closed e605593222538 ∧ code e605593222538 = 2804616478090 := by decide
theorem cert_e605593222538 : check e605593222538 [[],[]] .smaller = true := by decide
def e605593222562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593222562 : Closed e605593222562 ∧ code e605593222562 = 2804616478114 := by decide
theorem cert_e605593222562 : check e605593222562 [[],[]] .smaller = true := by decide
def e605593222574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605593222574 : Closed e605593222574 ∧ code e605593222574 = 2804616478126 := by decide
theorem cert_e605593222574 : check e605593222574 [[],[]] .smaller = true := by decide
def e605593222582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e605593222582 : Closed e605593222582 ∧ code e605593222582 = 2804616478134 := by decide
theorem cert_e605593222582 : check e605593222582 [[],[]] .smaller = true := by decide
def e605593222586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605593222586 : Closed e605593222586 ∧ code e605593222586 = 2804616478138 := by decide
theorem cert_e605593222586 : check e605593222586 [[],[]] .smaller = true := by decide
def e605593222614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605593222614 : Closed e605593222614 ∧ code e605593222614 = 2804616478166 := by decide
theorem cert_e605593222614 : check e605593222614 [[],[]] .smaller = true := by decide
def e605593222618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605593222618 : Closed e605593222618 ∧ code e605593222618 = 2804616478170 := by decide
theorem cert_e605593222618 : check e605593222618 [[],[]] .smaller = true := by decide
def e605593222634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e605593222634 : Closed e605593222634 ∧ code e605593222634 = 2804616478186 := by decide
theorem cert_e605593222634 : check e605593222634 [[],[]] .three = true := by decide
def e605593222830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605593222830 : Closed e605593222830 ∧ code e605593222830 = 2804616478382 := by decide
theorem cert_e605593222830 : check e605593222830 [[],[]] .three = true := by decide
def e605593222838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e605593222838 : Closed e605593222838 ∧ code e605593222838 = 2804616478390 := by decide
theorem cert_e605593222838 : check e605593222838 [[],[]] .three = true := by decide
def e605593222842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605593222842 : Closed e605593222842 ∧ code e605593222842 = 2804616478394 := by decide
theorem cert_e605593222842 : check e605593222842 [[],[]] .three = true := by decide
def e605593222870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605593222870 : Closed e605593222870 ∧ code e605593222870 = 2804616478422 := by decide
theorem cert_e605593222870 : check e605593222870 [[],[]] .three = true := by decide
def e605593222874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605593222874 : Closed e605593222874 ∧ code e605593222874 = 2804616478426 := by decide
theorem cert_e605593222874 : check e605593222874 [[],[]] .three = true := by decide
def e605593222890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605593222890 : Closed e605593222890 ∧ code e605593222890 = 2804616478442 := by decide
theorem cert_e605593222890 : check e605593222890 [[],[]] .three = true := by decide
def e605593223662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e605593223662 : Closed e605593223662 ∧ code e605593223662 = 2804616479214 := by decide
theorem cert_e605593223662 : check e605593223662 [[],[]] .smaller = true := by decide
def e605593223670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e605593223670 : Closed e605593223670 ∧ code e605593223670 = 2804616479222 := by decide
theorem cert_e605593223670 : check e605593223670 [[],[]] .smaller = true := by decide
def e605593224430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593224430 : Closed e605593224430 ∧ code e605593224430 = 2804616479982 := by decide
theorem cert_e605593224430 : check e605593224430 [[],[]] .smaller = true := by decide
def e605593224438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593224438 : Closed e605593224438 ∧ code e605593224438 = 2804616479990 := by decide
theorem cert_e605593224438 : check e605593224438 [[],[]] .smaller = true := by decide
def e605593224990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e605593224990 : Closed e605593224990 ∧ code e605593224990 = 2804616480542 := by decide
theorem cert_e605593224990 : check e605593224990 [[],[]] .smaller = true := by decide
def e605593225102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e605593225102 : Closed e605593225102 ∧ code e605593225102 = 2804616480654 := by decide
theorem cert_e605593225102 : check e605593225102 [[],[]] .smaller = true := by decide
def e605593226718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e605593226718 : Closed e605593226718 ∧ code e605593226718 = 2804616482270 := by decide
theorem cert_e605593226718 : check e605593226718 [[],[]] .three = true := by decide
def e605593226734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e605593226734 : Closed e605593226734 ∧ code e605593226734 = 2804616482286 := by decide
theorem cert_e605593226734 : check e605593226734 [[],[]] .three = true := by decide
def e605593226798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605593226798 : Closed e605593226798 ∧ code e605593226798 = 2804616482350 := by decide
theorem cert_e605593226798 : check e605593226798 [[],[]] .smaller = true := by decide
def e605593226974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e605593226974 : Closed e605593226974 ∧ code e605593226974 = 2804616482526 := by decide
theorem cert_e605593226974 : check e605593226974 [[],[]] .three = true := by decide
def e605593226978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605593226978 : Closed e605593226978 ∧ code e605593226978 = 2804616482530 := by decide
theorem cert_e605593226978 : check e605593226978 [[],[]] .smaller = true := by decide
def e605593226990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e605593226990 : Closed e605593226990 ∧ code e605593226990 = 2804616482542 := by decide
theorem cert_e605593226990 : check e605593226990 [[],[]] .smaller = true := by decide
def e605593226998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e605593226998 : Closed e605593226998 ∧ code e605593226998 = 2804616482550 := by decide
theorem cert_e605593226998 : check e605593226998 [[],[]] .three = true := by decide
def e605593227030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605593227030 : Closed e605593227030 ∧ code e605593227030 = 2804616482582 := by decide
theorem cert_e605593227030 : check e605593227030 [[],[]] .smaller = true := by decide
def e605593227102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e605593227102 : Closed e605593227102 ∧ code e605593227102 = 2804616482654 := by decide
theorem cert_e605593227102 : check e605593227102 [[],[]] .three = true := by decide
def e605593227106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605593227106 : Closed e605593227106 ∧ code e605593227106 = 2804616482658 := by decide
theorem cert_e605593227106 : check e605593227106 [[],[]] .smaller = true := by decide
def e605593227118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e605593227118 : Closed e605593227118 ∧ code e605593227118 = 2804616482670 := by decide
theorem cert_e605593227118 : check e605593227118 [[],[]] .smaller = true := by decide
def e605593227126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e605593227126 : Closed e605593227126 ∧ code e605593227126 = 2804616482678 := by decide
theorem cert_e605593227126 : check e605593227126 [[],[]] .smaller = true := by decide
def e605593227130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e605593227130 : Closed e605593227130 ∧ code e605593227130 = 2804616482682 := by decide
theorem cert_e605593227130 : check e605593227130 [[],[]] .three = true := by decide
def e605593227182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e605593227182 : Closed e605593227182 ∧ code e605593227182 = 2804616482734 := by decide
theorem cert_e605593227182 : check e605593227182 [[],[]] .three = true := by decide
def e605593227190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e605593227190 : Closed e605593227190 ∧ code e605593227190 = 2804616482742 := by decide
theorem cert_e605593227190 : check e605593227190 [[],[]] .three = true := by decide
def e605593227194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e605593227194 : Closed e605593227194 ∧ code e605593227194 = 2804616482746 := by decide
theorem cert_e605593227194 : check e605593227194 [[],[]] .three = true := by decide
def e605593228254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e605593228254 : Closed e605593228254 ∧ code e605593228254 = 2804616483806 := by decide
theorem cert_e605593228254 : check e605593228254 [[],[]] .three = true := by decide
def e605593228270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e605593228270 : Closed e605593228270 ∧ code e605593228270 = 2804616483822 := by decide
theorem cert_e605593228270 : check e605593228270 [[],[]] .three = true := by decide
def e605593229374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e605593229374 : Closed e605593229374 ∧ code e605593229374 = 2804616484926 := by decide
theorem cert_e605593229374 : check e605593229374 [[],[]] .smaller = true := by decide
def e605593229790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e605593229790 : Closed e605593229790 ∧ code e605593229790 = 2804616485342 := by decide
theorem cert_e605593229790 : check e605593229790 [[],[]] .three = true := by decide
def e605593229794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605593229794 : Closed e605593229794 ∧ code e605593229794 = 2804616485346 := by decide
theorem cert_e605593229794 : check e605593229794 [[],[]] .smaller = true := by decide
def e605593229806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e605593229806 : Closed e605593229806 ∧ code e605593229806 = 2804616485358 := by decide
theorem cert_e605593229806 : check e605593229806 [[],[]] .smaller = true := by decide
def e605593229814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e605593229814 : Closed e605593229814 ∧ code e605593229814 = 2804616485366 := by decide
theorem cert_e605593229814 : check e605593229814 [[],[]] .three = true := by decide
def e605593230366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e605593230366 : Closed e605593230366 ∧ code e605593230366 = 2804616485918 := by decide
theorem cert_e605593230366 : check e605593230366 [[],[]] .smaller = true := by decide
def e605593230558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e605593230558 : Closed e605593230558 ∧ code e605593230558 = 2804616486110 := by decide
theorem cert_e605593230558 : check e605593230558 [[],[]] .three = true := by decide
def e605593230562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605593230562 : Closed e605593230562 ∧ code e605593230562 = 2804616486114 := by decide
theorem cert_e605593230562 : check e605593230562 [[],[]] .smaller = true := by decide
def e605593230574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593230574 : Closed e605593230574 ∧ code e605593230574 = 2804616486126 := by decide
theorem cert_e605593230574 : check e605593230574 [[],[]] .smaller = true := by decide
def e605593230582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593230582 : Closed e605593230582 ∧ code e605593230582 = 2804616486134 := by decide
theorem cert_e605593230582 : check e605593230582 [[],[]] .smaller = true := by decide
def e605593230586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e605593230586 : Closed e605593230586 ∧ code e605593230586 = 2804616486138 := by decide
theorem cert_e605593230586 : check e605593230586 [[],[]] .three = true := by decide
def e605593230958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593230958 : Closed e605593230958 ∧ code e605593230958 = 2804616486510 := by decide
theorem cert_e605593230958 : check e605593230958 [[],[]] .three = true := by decide
def e605593230966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593230966 : Closed e605593230966 ∧ code e605593230966 = 2804616486518 := by decide
theorem cert_e605593230966 : check e605593230966 [[],[]] .three = true := by decide
def e605593230970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593230970 : Closed e605593230970 ∧ code e605593230970 = 2804616486522 := by decide
theorem cert_e605593230970 : check e605593230970 [[],[]] .three = true := by decide
def e605593231598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605593231598 : Closed e605593231598 ∧ code e605593231598 = 2804616487150 := by decide
theorem cert_e605593231598 : check e605593231598 [[],[]] .smaller = true := by decide
def e605593231610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e605593231610 : Closed e605593231610 ∧ code e605593231610 = 2804616487162 := by decide
theorem cert_e605593231610 : check e605593231610 [[],[]] .smaller = true := by decide
def e605593231790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605593231790 : Closed e605593231790 ∧ code e605593231790 = 2804616487342 := by decide
theorem cert_e605593231790 : check e605593231790 [[],[]] .smaller = true := by decide
def e605593231982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593231982 : Closed e605593231982 ∧ code e605593231982 = 2804616487534 := by decide
theorem cert_e605593231982 : check e605593231982 [[],[]] .smaller = true := by decide
def e605593231994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593231994 : Closed e605593231994 ∧ code e605593231994 = 2804616487546 := by decide
theorem cert_e605593231994 : check e605593231994 [[],[]] .smaller = true := by decide
def e605593232158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e605593232158 : Closed e605593232158 ∧ code e605593232158 = 2804616487710 := by decide
theorem cert_e605593232158 : check e605593232158 [[],[]] .smaller = true := by decide
def e605593232326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e605593232326 : Closed e605593232326 ∧ code e605593232326 = 2804616487878 := by decide
theorem cert_e605593232326 : check e605593232326 [[],[]] .smaller = true := by decide
def e605593232942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605593232942 : Closed e605593232942 ∧ code e605593232942 = 2804616488494 := by decide
theorem cert_e605593232942 : check e605593232942 [[],[]] .smaller = true := by decide
def e605593233118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e605593233118 : Closed e605593233118 ∧ code e605593233118 = 2804616488670 := by decide
theorem cert_e605593233118 : check e605593233118 [[],[]] .three = true := by decide
def e605593233122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605593233122 : Closed e605593233122 ∧ code e605593233122 = 2804616488674 := by decide
theorem cert_e605593233122 : check e605593233122 [[],[]] .smaller = true := by decide
def e605593233134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e605593233134 : Closed e605593233134 ∧ code e605593233134 = 2804616488686 := by decide
theorem cert_e605593233134 : check e605593233134 [[],[]] .smaller = true := by decide
def e605593233142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e605593233142 : Closed e605593233142 ∧ code e605593233142 = 2804616488694 := by decide
theorem cert_e605593233142 : check e605593233142 [[],[]] .three = true := by decide
def e605593233246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e605593233246 : Closed e605593233246 ∧ code e605593233246 = 2804616488798 := by decide
theorem cert_e605593233246 : check e605593233246 [[],[]] .three = true := by decide
def e605593233262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e605593233262 : Closed e605593233262 ∧ code e605593233262 = 2804616488814 := by decide
theorem cert_e605593233262 : check e605593233262 [[],[]] .smaller = true := by decide
def e605593233270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e605593233270 : Closed e605593233270 ∧ code e605593233270 = 2804616488822 := by decide
theorem cert_e605593233270 : check e605593233270 [[],[]] .smaller = true := by decide
def e605593233274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e605593233274 : Closed e605593233274 ∧ code e605593233274 = 2804616488826 := by decide
theorem cert_e605593233274 : check e605593233274 [[],[]] .three = true := by decide
def e605593233290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593233290 : Closed e605593233290 ∧ code e605593233290 = 2804616488842 := by decide
theorem cert_e605593233290 : check e605593233290 [[],[]] .smaller = true := by decide
def e605593233314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593233314 : Closed e605593233314 ∧ code e605593233314 = 2804616488866 := by decide
theorem cert_e605593233314 : check e605593233314 [[],[]] .smaller = true := by decide
def e605593233326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e605593233326 : Closed e605593233326 ∧ code e605593233326 = 2804616488878 := by decide
theorem cert_e605593233326 : check e605593233326 [[],[]] .smaller = true := by decide
def e605593233334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e605593233334 : Closed e605593233334 ∧ code e605593233334 = 2804616488886 := by decide
theorem cert_e605593233334 : check e605593233334 [[],[]] .smaller = true := by decide
def e605593233338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e605593233338 : Closed e605593233338 ∧ code e605593233338 = 2804616488890 := by decide
theorem cert_e605593233338 : check e605593233338 [[],[]] .smaller = true := by decide
def e605593233366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e605593233366 : Closed e605593233366 ∧ code e605593233366 = 2804616488918 := by decide
theorem cert_e605593233366 : check e605593233366 [[],[]] .three = true := by decide
def e605593233370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e605593233370 : Closed e605593233370 ∧ code e605593233370 = 2804616488922 := by decide
theorem cert_e605593233370 : check e605593233370 [[],[]] .three = true := by decide
def e605593233470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e605593233470 : Closed e605593233470 ∧ code e605593233470 = 2804616489022 := by decide
theorem cert_e605593233470 : check e605593233470 [[],[]] .smaller = true := by decide
def e605593233886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e605593233886 : Closed e605593233886 ∧ code e605593233886 = 2804616489438 := by decide
theorem cert_e605593233886 : check e605593233886 [[],[]] .three = true := by decide
def e605593233890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605593233890 : Closed e605593233890 ∧ code e605593233890 = 2804616489442 := by decide
theorem cert_e605593233890 : check e605593233890 [[],[]] .smaller = true := by decide
def e605593233902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e605593233902 : Closed e605593233902 ∧ code e605593233902 = 2804616489454 := by decide
theorem cert_e605593233902 : check e605593233902 [[],[]] .smaller = true := by decide
def e605593233910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e605593233910 : Closed e605593233910 ∧ code e605593233910 = 2804616489462 := by decide
theorem cert_e605593233910 : check e605593233910 [[],[]] .three = true := by decide
def e605593234654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e605593234654 : Closed e605593234654 ∧ code e605593234654 = 2804616490206 := by decide
theorem cert_e605593234654 : check e605593234654 [[],[]] .three = true := by decide
def e605593234670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593234670 : Closed e605593234670 ∧ code e605593234670 = 2804616490222 := by decide
theorem cert_e605593234670 : check e605593234670 [[],[]] .smaller = true := by decide
def e605593234678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593234678 : Closed e605593234678 ∧ code e605593234678 = 2804616490230 := by decide
theorem cert_e605593234678 : check e605593234678 [[],[]] .smaller = true := by decide
def e605593234682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e605593234682 : Closed e605593234682 ∧ code e605593234682 = 2804616490234 := by decide
theorem cert_e605593234682 : check e605593234682 [[],[]] .three = true := by decide
def e605593234958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e605593234958 : Closed e605593234958 ∧ code e605593234958 = 2804616490510 := by decide
theorem cert_e605593234958 : check e605593234958 [[],[]] .smaller = true := by decide
def e605593234970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593234970 : Closed e605593234970 ∧ code e605593234970 = 2804616490522 := by decide
theorem cert_e605593234970 : check e605593234970 [[],[]] .smaller = true := by decide
end Blc.Floor41
