import R598355276502V0
import R598355276502K0
import R598355276502st0
import R598355276502st12
import R598355276502hs0
import R598355276502hs12
import CodeBridge
import Batch044
namespace Certgen.R598355276502
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.app 9 10,.var 0,.lam 11,.lam 12,.app 13 14,.var 2,.app 15 18,.app 16 17,.var 0,.var 0,.var 1]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD [])))
def st (i : Nat) : AState := if i < 259 then (if i < 120 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 80 then (st60[i-60]?.getD entry) else (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)))) else (if i < 180 then (if i < 140 then (st120[i-120]?.getD entry) else (if i < 160 then (st140[i-140]?.getD entry) else (st160[i-160]?.getD entry))) else (if i < 220 then (if i < 200 then (st180[i-180]?.getD entry) else (st200[i-200]?.getD entry)) else (if i < 240 then (st220[i-220]?.getD entry) else (st240[i-240]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 120 then (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 80 then (hs60[i-60]?.getD []) else (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])))) else (if i < 180 then (if i < 140 then (hs120[i-120]?.getD []) else (if i < 160 then (hs140[i-140]?.getD []) else (hs160[i-160]?.getD []))) else (if i < 220 then (if i < 200 then (hs180[i-180]?.getD []) else (hs200[i-200]?.getD [])) else (if i < 240 then (hs220[i-220]?.getD []) else (hs240[i-240]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R598355276502
