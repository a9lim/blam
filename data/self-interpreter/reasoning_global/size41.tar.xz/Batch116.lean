import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603681526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605603681526 : Closed e605603681526 ∧ code e605603681526 = 2804626937078 := by decide
theorem cert_e605603681526 : check e605603681526 [[],[]] .chain = true := by decide
def e605603681902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605603681902 : Closed e605603681902 ∧ code e605603681902 = 2804626937454 := by decide
theorem cert_e605603681902 : check e605603681902 [[],[]] .chain = true := by decide
def e605603681914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605603681914 : Closed e605603681914 ∧ code e605603681914 = 2804626937466 := by decide
theorem cert_e605603681914 : check e605603681914 [[],[]] .chain = true := by decide
def e605603682102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605603682102 : Closed e605603682102 ∧ code e605603682102 = 2804626937654 := by decide
theorem cert_e605603682102 : check e605603682102 [[],[]] .chain = true := by decide
def e605603682106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605603682106 : Closed e605603682106 ∧ code e605603682106 = 2804626937658 := by decide
theorem cert_e605603682106 : check e605603682106 [[],[]] .chain = true := by decide
def e605603682350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605603682350 : Closed e605603682350 ∧ code e605603682350 = 2804626937902 := by decide
theorem cert_e605603682350 : check e605603682350 [[],[]] .chain = true := by decide
def e605603682542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605603682542 : Closed e605603682542 ∧ code e605603682542 = 2804626938094 := by decide
theorem cert_e605603682542 : check e605603682542 [[],[]] .chain = true := by decide
def e605603682550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605603682550 : Closed e605603682550 ∧ code e605603682550 = 2804626938102 := by decide
theorem cert_e605603682550 : check e605603682550 [[],[]] .chain = true := by decide
def e605603682734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605603682734 : Closed e605603682734 ∧ code e605603682734 = 2804626938286 := by decide
theorem cert_e605603682734 : check e605603682734 [[],[]] .chain = true := by decide
def e605603682746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605603682746 : Closed e605603682746 ∧ code e605603682746 = 2804626938298 := by decide
theorem cert_e605603682746 : check e605603682746 [[],[]] .chain = true := by decide
def e605603682794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605603682794 : Closed e605603682794 ∧ code e605603682794 = 2804626938346 := by decide
theorem cert_e605603682794 : check e605603682794 [[],[]] .chain = true := by decide
def e605603682926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605603682926 : Closed e605603682926 ∧ code e605603682926 = 2804626938478 := by decide
theorem cert_e605603682926 : check e605603682926 [[],[]] .chain = true := by decide
def e605603682938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605603682938 : Closed e605603682938 ∧ code e605603682938 = 2804626938490 := by decide
theorem cert_e605603682938 : check e605603682938 [[],[]] .chain = true := by decide
def e605603683102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605603683102 : Closed e605603683102 ∧ code e605603683102 = 2804626938654 := by decide
theorem cert_e605603683102 : check e605603683102 [[],[]] .chain = true := by decide
def e605603683202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605603683202 : Closed e605603683202 ∧ code e605603683202 = 2804626938754 := by decide
theorem cert_e605603683202 : check e605603683202 [[],[]] .chain = true := by decide
def e605603683214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605603683214 : Closed e605603683214 ∧ code e605603683214 = 2804626938766 := by decide
theorem cert_e605603683214 : check e605603683214 [[],[]] .chain = true := by decide
def e605603683226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605603683226 : Closed e605603683226 ∧ code e605603683226 = 2804626938778 := by decide
theorem cert_e605603683226 : check e605603683226 [[],[]] .chain = true := by decide
def e605603683350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605603683350 : Closed e605603683350 ∧ code e605603683350 = 2804626938902 := by decide
theorem cert_e605603683350 : check e605603683350 [[],[]] .chain = true := by decide
def e605603683446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605603683446 : Closed e605603683446 ∧ code e605603683446 = 2804626938998 := by decide
theorem cert_e605603683446 : check e605603683446 [[],[]] .chain = true := by decide
def e605603683542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605603683542 : Closed e605603683542 ∧ code e605603683542 = 2804626939094 := by decide
theorem cert_e605603683542 : check e605603683542 [[],[]] .chain = true := by decide
def e605603683546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605603683546 : Closed e605603683546 ∧ code e605603683546 = 2804626939098 := by decide
theorem cert_e605603683546 : check e605603683546 [[],[]] .chain = true := by decide
def e605603683562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605603683562 : Closed e605603683562 ∧ code e605603683562 = 2804626939114 := by decide
theorem cert_e605603683562 : check e605603683562 [[],[]] .chain = true := by decide
def e605603683638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605603683638 : Closed e605603683638 ∧ code e605603683638 = 2804626939190 := by decide
theorem cert_e605603683638 : check e605603683638 [[],[]] .chain = true := by decide
def e605603683642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605603683642 : Closed e605603683642 ∧ code e605603683642 = 2804626939194 := by decide
theorem cert_e605603683642 : check e605603683642 [[],[]] .chain = true := by decide
def e605603683714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605603683714 : Closed e605603683714 ∧ code e605603683714 = 2804626939266 := by decide
theorem cert_e605603683714 : check e605603683714 [[],[]] .chain = true := by decide
def e605603683726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605603683726 : Closed e605603683726 ∧ code e605603683726 = 2804626939278 := by decide
theorem cert_e605603683726 : check e605603683726 [[],[]] .chain = true := by decide
def e605603683738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605603683738 : Closed e605603683738 ∧ code e605603683738 = 2804626939290 := by decide
theorem cert_e605603683738 : check e605603683738 [[],[]] .chain = true := by decide
def e605603684526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605603684526 : Closed e605603684526 ∧ code e605603684526 = 2804626940078 := by decide
theorem cert_e605603684526 : check e605603684526 [[],[]] .chain = true := by decide
def e605603684538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605603684538 : Closed e605603684538 ∧ code e605603684538 = 2804626940090 := by decide
theorem cert_e605603684538 : check e605603684538 [[],[]] .chain = true := by decide
def e605603685102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e605603685102 : Closed e605603685102 ∧ code e605603685102 = 2804626940654 := by decide
theorem cert_e605603685102 : check e605603685102 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603685230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605603685230 : Closed e605603685230 ∧ code e605603685230 = 2804626940782 := by decide
theorem cert_e605603685230 : check e605603685230 [[],[]] .chain = true := by decide
def e605603685238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605603685238 : Closed e605603685238 ∧ code e605603685238 = 2804626940790 := by decide
theorem cert_e605603685238 : check e605603685238 [[],[]] .chain = true := by decide
def e605603685294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605603685294 : Closed e605603685294 ∧ code e605603685294 = 2804626940846 := by decide
theorem cert_e605603685294 : check e605603685294 [[],[]] .chain = true := by decide
def e605603685306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605603685306 : Closed e605603685306 ∧ code e605603685306 = 2804626940858 := by decide
theorem cert_e605603685306 : check e605603685306 [[],[]] .chain = true := by decide
def e605603685334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605603685334 : Closed e605603685334 ∧ code e605603685334 = 2804626940886 := by decide
theorem cert_e605603685334 : check e605603685334 [[],[]] .chain = true := by decide
def e605603685338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605603685338 : Closed e605603685338 ∧ code e605603685338 = 2804626940890 := by decide
theorem cert_e605603685338 : check e605603685338 [[],[]] .chain = true := by decide
def e605603686062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605603686062 : Closed e605603686062 ∧ code e605603686062 = 2804626941614 := by decide
theorem cert_e605603686062 : check e605603686062 [[],[]] .chain = true := by decide
def e605603686074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605603686074 : Closed e605603686074 ∧ code e605603686074 = 2804626941626 := by decide
theorem cert_e605603686074 : check e605603686074 [[],[]] .chain = true := by decide
def e605603686122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605603686122 : Closed e605603686122 ∧ code e605603686122 = 2804626941674 := by decide
theorem cert_e605603686122 : check e605603686122 [[],[]] .chain = true := by decide
def e605603686314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605603686314 : Closed e605603686314 ∧ code e605603686314 = 2804626941866 := by decide
theorem cert_e605603686314 : check e605603686314 [[],[]] .chain = true := by decide
def e605603686446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605603686446 : Closed e605603686446 ∧ code e605603686446 = 2804626941998 := by decide
theorem cert_e605603686446 : check e605603686446 [[],[]] .chain = true := by decide
def e605603686638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605603686638 : Closed e605603686638 ∧ code e605603686638 = 2804626942190 := by decide
theorem cert_e605603686638 : check e605603686638 [[],[]] .chain = true := by decide
def e605603686646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605603686646 : Closed e605603686646 ∧ code e605603686646 = 2804626942198 := by decide
theorem cert_e605603686646 : check e605603686646 [[],[]] .chain = true := by decide
def e605603686830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605603686830 : Closed e605603686830 ∧ code e605603686830 = 2804626942382 := by decide
theorem cert_e605603686830 : check e605603686830 [[],[]] .chain = true := by decide
def e605603686842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605603686842 : Closed e605603686842 ∧ code e605603686842 = 2804626942394 := by decide
theorem cert_e605603686842 : check e605603686842 [[],[]] .chain = true := by decide
def e605603686890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605603686890 : Closed e605603686890 ∧ code e605603686890 = 2804626942442 := by decide
theorem cert_e605603686890 : check e605603686890 [[],[]] .chain = true := by decide
def e605603687022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605603687022 : Closed e605603687022 ∧ code e605603687022 = 2804626942574 := by decide
theorem cert_e605603687022 : check e605603687022 [[],[]] .chain = true := by decide
def e605603687034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605603687034 : Closed e605603687034 ∧ code e605603687034 = 2804626942586 := by decide
theorem cert_e605603687034 : check e605603687034 [[],[]] .chain = true := by decide
def e605603687198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605603687198 : Closed e605603687198 ∧ code e605603687198 = 2804626942750 := by decide
theorem cert_e605603687198 : check e605603687198 [[],[]] .chain = true := by decide
def e605603687298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605603687298 : Closed e605603687298 ∧ code e605603687298 = 2804626942850 := by decide
theorem cert_e605603687298 : check e605603687298 [[],[]] .chain = true := by decide
def e605603687310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605603687310 : Closed e605603687310 ∧ code e605603687310 = 2804626942862 := by decide
theorem cert_e605603687310 : check e605603687310 [[],[]] .chain = true := by decide
def e605603687322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605603687322 : Closed e605603687322 ∧ code e605603687322 = 2804626942874 := by decide
theorem cert_e605603687322 : check e605603687322 [[],[]] .chain = true := by decide
def e605603687534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605603687534 : Closed e605603687534 ∧ code e605603687534 = 2804626943086 := by decide
theorem cert_e605603687534 : check e605603687534 [[],[]] .chain = true := by decide
def e605603687546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605603687546 : Closed e605603687546 ∧ code e605603687546 = 2804626943098 := by decide
theorem cert_e605603687546 : check e605603687546 [[],[]] .chain = true := by decide
def e605603687710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605603687710 : Closed e605603687710 ∧ code e605603687710 = 2804626943262 := by decide
theorem cert_e605603687710 : check e605603687710 [[],[]] .chain = true := by decide
def e605603687878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605603687878 : Closed e605603687878 ∧ code e605603687878 = 2804626943430 := by decide
theorem cert_e605603687878 : check e605603687878 [[],[]] .chain = true := by decide
def e605603687946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605603687946 : Closed e605603687946 ∧ code e605603687946 = 2804626943498 := by decide
theorem cert_e605603687946 : check e605603687946 [[],[]] .chain = true := by decide
def e605603687982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605603687982 : Closed e605603687982 ∧ code e605603687982 = 2804626943534 := by decide
theorem cert_e605603687982 : check e605603687982 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603687990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605603687990 : Closed e605603687990 ∧ code e605603687990 = 2804626943542 := by decide
theorem cert_e605603687990 : check e605603687990 [[],[]] .chain = true := by decide
def e605603687994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605603687994 : Closed e605603687994 ∧ code e605603687994 = 2804626943546 := by decide
theorem cert_e605603687994 : check e605603687994 [[],[]] .chain = true := by decide
def e605603688042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605603688042 : Closed e605603688042 ∧ code e605603688042 = 2804626943594 := by decide
theorem cert_e605603688042 : check e605603688042 [[],[]] .chain = true := by decide
def e605603688066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605603688066 : Closed e605603688066 ∧ code e605603688066 = 2804626943618 := by decide
theorem cert_e605603688066 : check e605603688066 [[],[]] .chain = true := by decide
def e605603688078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605603688078 : Closed e605603688078 ∧ code e605603688078 = 2804626943630 := by decide
theorem cert_e605603688078 : check e605603688078 [[],[]] .chain = true := by decide
def e605603688090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605603688090 : Closed e605603688090 ∧ code e605603688090 = 2804626943642 := by decide
theorem cert_e605603688090 : check e605603688090 [[],[]] .chain = true := by decide
def e605603688134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605603688134 : Closed e605603688134 ∧ code e605603688134 = 2804626943686 := by decide
theorem cert_e605603688134 : check e605603688134 [[],[]] .chain = true := by decide
def e605603688162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605603688162 : Closed e605603688162 ∧ code e605603688162 = 2804626943714 := by decide
theorem cert_e605603688162 : check e605603688162 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603688174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)))))))
theorem wire_e605603688174 : Closed e605603688174 ∧ code e605603688174 = 2804626943726 := by decide
theorem cert_e605603688174 : check e605603688174 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603688534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605603688534 : Closed e605603688534 ∧ code e605603688534 = 2804626944086 := by decide
theorem cert_e605603688534 : check e605603688534 [[],[]] .chain = true := by decide
def e605603688538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605603688538 : Closed e605603688538 ∧ code e605603688538 = 2804626944090 := by decide
theorem cert_e605603688538 : check e605603688538 [[],[]] .chain = true := by decide
def e605603688814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605603688814 : Closed e605603688814 ∧ code e605603688814 = 2804626944366 := by decide
theorem cert_e605603688814 : check e605603688814 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605603688822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605603688822 : Closed e605603688822 ∧ code e605603688822 = 2804626944374 := by decide
theorem cert_e605603688822 : check e605603688822 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605603688886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e605603688886 : Closed e605603688886 ∧ code e605603688886 = 2804626944438 := by decide
theorem cert_e605603688886 : check e605603688886 [[],[]] .chain = true := by decide
def e605603688918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605603688918 : Closed e605603688918 ∧ code e605603688918 = 2804626944470 := by decide
theorem cert_e605603688918 : check e605603688918 [[],[]] .chain = true := by decide
def e605603688922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605603688922 : Closed e605603688922 ∧ code e605603688922 = 2804626944474 := by decide
theorem cert_e605603688922 : check e605603688922 [[],[]] .chain = true := by decide
def e605603689302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605603689302 : Closed e605603689302 ∧ code e605603689302 = 2804626944854 := by decide
theorem cert_e605603689302 : check e605603689302 [[],[]] .chain = true := by decide
def e605603689306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605603689306 : Closed e605603689306 ∧ code e605603689306 = 2804626944858 := by decide
theorem cert_e605603689306 : check e605603689306 [[],[]] .chain = true := by decide
def e605603689322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605603689322 : Closed e605603689322 ∧ code e605603689322 = 2804626944874 := by decide
theorem cert_e605603689322 : check e605603689322 [[],[]] .chain = true := by decide
def e605603689386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605603689386 : Closed e605603689386 ∧ code e605603689386 = 2804626944938 := by decide
theorem cert_e605603689386 : check e605603689386 [[],[]] .chain = true := by decide
def e605603689494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605603689494 : Closed e605603689494 ∧ code e605603689494 = 2804626945046 := by decide
theorem cert_e605603689494 : check e605603689494 [[],[]] .chain = true := by decide
def e605603689590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605603689590 : Closed e605603689590 ∧ code e605603689590 = 2804626945142 := by decide
theorem cert_e605603689590 : check e605603689590 [[],[]] .chain = true := by decide
def e605603689686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605603689686 : Closed e605603689686 ∧ code e605603689686 = 2804626945238 := by decide
theorem cert_e605603689686 : check e605603689686 [[],[]] .chain = true := by decide
def e605603689690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605603689690 : Closed e605603689690 ∧ code e605603689690 = 2804626945242 := by decide
theorem cert_e605603689690 : check e605603689690 [[],[]] .chain = true := by decide
def e605603689706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605603689706 : Closed e605603689706 ∧ code e605603689706 = 2804626945258 := by decide
theorem cert_e605603689706 : check e605603689706 [[],[]] .chain = true := by decide
def e605603689782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605603689782 : Closed e605603689782 ∧ code e605603689782 = 2804626945334 := by decide
theorem cert_e605603689782 : check e605603689782 [[],[]] .chain = true := by decide
def e605603689786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605603689786 : Closed e605603689786 ∧ code e605603689786 = 2804626945338 := by decide
theorem cert_e605603689786 : check e605603689786 [[],[]] .chain = true := by decide
def e605603689858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605603689858 : Closed e605603689858 ∧ code e605603689858 = 2804626945410 := by decide
theorem cert_e605603689858 : check e605603689858 [[],[]] .chain = true := by decide
def e605603689870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605603689870 : Closed e605603689870 ∧ code e605603689870 = 2804626945422 := by decide
theorem cert_e605603689870 : check e605603689870 [[],[]] .chain = true := by decide
def e605603689882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605603689882 : Closed e605603689882 ∧ code e605603689882 = 2804626945434 := by decide
theorem cert_e605603689882 : check e605603689882 [[],[]] .chain = true := by decide
def e605603689994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605603689994 : Closed e605603689994 ∧ code e605603689994 = 2804626945546 := by decide
theorem cert_e605603689994 : check e605603689994 [[],[]] .chain = true := by decide
def e605603690030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605603690030 : Closed e605603690030 ∧ code e605603690030 = 2804626945582 := by decide
theorem cert_e605603690030 : check e605603690030 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603690038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605603690038 : Closed e605603690038 ∧ code e605603690038 = 2804626945590 := by decide
theorem cert_e605603690038 : check e605603690038 [[],[]] .chain = true := by decide
def e605603690042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605603690042 : Closed e605603690042 ∧ code e605603690042 = 2804626945594 := by decide
theorem cert_e605603690042 : check e605603690042 [[],[]] .chain = true := by decide
def e605603690090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605603690090 : Closed e605603690090 ∧ code e605603690090 = 2804626945642 := by decide
theorem cert_e605603690090 : check e605603690090 [[],[]] .chain = true := by decide
def e605603690114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605603690114 : Closed e605603690114 ∧ code e605603690114 = 2804626945666 := by decide
theorem cert_e605603690114 : check e605603690114 [[],[]] .chain = true := by decide
def e605603690126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605603690126 : Closed e605603690126 ∧ code e605603690126 = 2804626945678 := by decide
theorem cert_e605603690126 : check e605603690126 [[],[]] .chain = true := by decide
def e605603690138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605603690138 : Closed e605603690138 ∧ code e605603690138 = 2804626945690 := by decide
theorem cert_e605603690138 : check e605603690138 [[],[]] .chain = true := by decide
def e605603690182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605603690182 : Closed e605603690182 ∧ code e605603690182 = 2804626945734 := by decide
theorem cert_e605603690182 : check e605603690182 [[],[]] .chain = true := by decide
def e605603690210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605603690210 : Closed e605603690210 ∧ code e605603690210 = 2804626945762 := by decide
theorem cert_e605603690210 : check e605603690210 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e605603690222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e605603690222 : Closed e605603690222 ∧ code e605603690222 = 2804626945774 := by decide
theorem cert_e605603690222 : check e605603690222 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603690262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605603690262 : Closed e605603690262 ∧ code e605603690262 = 2804626945814 := by decide
theorem cert_e605603690262 : check e605603690262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605603690338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605603690338 : Closed e605603690338 ∧ code e605603690338 = 2804626945890 := by decide
def e605603690350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e605603690350 : Closed e605603690350 ∧ code e605603690350 = 2804626945902 := by decide
def e605603690358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e605603690358 : Closed e605603690358 ∧ code e605603690358 = 2804626945910 := by decide
theorem cert_e605603690358 : check e605603690358 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605603693806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e605603693806 : Closed e605603693806 ∧ code e605603693806 = 2804626949358 := by decide
theorem cert_e605603693806 : check e605603693806 [[],[]] .chain = true := by decide
def e605603693814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e605603693814 : Closed e605603693814 ∧ code e605603693814 = 2804626949366 := by decide
theorem cert_e605603693814 : check e605603693814 [[],[]] .chain = true := by decide
def e605603696366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e605603696366 : Closed e605603696366 ∧ code e605603696366 = 2804626951918 := by decide
theorem cert_e605603696366 : check e605603696366 [[],[]] .chain = true := by decide
def e605603696374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605603696374 : Closed e605603696374 ∧ code e605603696374 = 2804626951926 := by decide
theorem cert_e605603696374 : check e605603696374 [[],[]] .chain = true := by decide
def e605603696494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e605603696494 : Closed e605603696494 ∧ code e605603696494 = 2804626952046 := by decide
theorem cert_e605603696494 : check e605603696494 [[],[]] .chain = true := by decide
def e605603696506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e605603696506 : Closed e605603696506 ∧ code e605603696506 = 2804626952058 := by decide
theorem cert_e605603696506 : check e605603696506 [[],[]] .chain = true := by decide
def e605603696566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605603696566 : Closed e605603696566 ∧ code e605603696566 = 2804626952118 := by decide
theorem cert_e605603696566 : check e605603696566 [[],[]] .chain = true := by decide
def e605603696570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e605603696570 : Closed e605603696570 ∧ code e605603696570 = 2804626952122 := by decide
theorem cert_e605603696570 : check e605603696570 [[],[]] .chain = true := by decide
def e605603699950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e605603699950 : Closed e605603699950 ∧ code e605603699950 = 2804626955502 := by decide
theorem cert_e605603699950 : check e605603699950 [[],[]] .chain = true := by decide
def e605603699958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e605603699958 : Closed e605603699958 ∧ code e605603699958 = 2804626955510 := by decide
theorem cert_e605603699958 : check e605603699958 [[],[]] .chain = true := by decide
def e605603700342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e605603700342 : Closed e605603700342 ∧ code e605603700342 = 2804626955894 := by decide
theorem cert_e605603700342 : check e605603700342 [[],[]] .chain = true := by decide
def e605603704174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605603704174 : Closed e605603704174 ∧ code e605603704174 = 2804626959726 := by decide
theorem cert_e605603704174 : check e605603704174 [[],[]] .chain = true := by decide
def e605603704182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605603704182 : Closed e605603704182 ∧ code e605603704182 = 2804626959734 := by decide
theorem cert_e605603704182 : check e605603704182 [[],[]] .chain = true := by decide
def e605603704238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605603704238 : Closed e605603704238 ∧ code e605603704238 = 2804626959790 := by decide
theorem cert_e605603704238 : check e605603704238 [[],[]] .chain = true := by decide
def e605603704250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605603704250 : Closed e605603704250 ∧ code e605603704250 = 2804626959802 := by decide
theorem cert_e605603704250 : check e605603704250 [[],[]] .chain = true := by decide
def e605603704278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605603704278 : Closed e605603704278 ∧ code e605603704278 = 2804626959830 := by decide
theorem cert_e605603704278 : check e605603704278 [[],[]] .chain = true := by decide
def e605603704282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605603704282 : Closed e605603704282 ∧ code e605603704282 = 2804626959834 := by decide
theorem cert_e605603704282 : check e605603704282 [[],[]] .chain = true := by decide
def e605603704494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605603704494 : Closed e605603704494 ∧ code e605603704494 = 2804626960046 := by decide
theorem cert_e605603704494 : check e605603704494 [[],[]] .chain = true := by decide
def e605603704506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605603704506 : Closed e605603704506 ∧ code e605603704506 = 2804626960058 := by decide
theorem cert_e605603704506 : check e605603704506 [[],[]] .chain = true := by decide
def e605603704554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605603704554 : Closed e605603704554 ∧ code e605603704554 = 2804626960106 := by decide
theorem cert_e605603704554 : check e605603704554 [[],[]] .chain = true := by decide
def e605603704662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605603704662 : Closed e605603704662 ∧ code e605603704662 = 2804626960214 := by decide
theorem cert_e605603704662 : check e605603704662 [[],[]] .chain = true := by decide
def e605603704666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605603704666 : Closed e605603704666 ∧ code e605603704666 = 2804626960218 := by decide
theorem cert_e605603704666 : check e605603704666 [[],[]] .chain = true := by decide
def e605603704682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605603704682 : Closed e605603704682 ∧ code e605603704682 = 2804626960234 := by decide
theorem cert_e605603704682 : check e605603704682 [[],[]] .chain = true := by decide
def e605603705710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605603705710 : Closed e605603705710 ∧ code e605603705710 = 2804626961262 := by decide
theorem cert_e605603705710 : check e605603705710 [[],[]] .chain = true := by decide
def e605603705718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605603705718 : Closed e605603705718 ∧ code e605603705718 = 2804626961270 := by decide
theorem cert_e605603705718 : check e605603705718 [[],[]] .chain = true := by decide
def e605603705774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605603705774 : Closed e605603705774 ∧ code e605603705774 = 2804626961326 := by decide
theorem cert_e605603705774 : check e605603705774 [[],[]] .chain = true := by decide
def e605603705786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605603705786 : Closed e605603705786 ∧ code e605603705786 = 2804626961338 := by decide
theorem cert_e605603705786 : check e605603705786 [[],[]] .chain = true := by decide
def e605603705814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605603705814 : Closed e605603705814 ∧ code e605603705814 = 2804626961366 := by decide
theorem cert_e605603705814 : check e605603705814 [[],[]] .chain = true := by decide
def e605603705818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605603705818 : Closed e605603705818 ∧ code e605603705818 = 2804626961370 := by decide
theorem cert_e605603705818 : check e605603705818 [[],[]] .chain = true := by decide
def e605603706094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605603706094 : Closed e605603706094 ∧ code e605603706094 = 2804626961646 := by decide
theorem cert_e605603706094 : check e605603706094 [[],[]] .chain = true := by decide
def e605603706102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605603706102 : Closed e605603706102 ∧ code e605603706102 = 2804626961654 := by decide
theorem cert_e605603706102 : check e605603706102 [[],[]] .chain = true := by decide
def e605603706478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605603706478 : Closed e605603706478 ∧ code e605603706478 = 2804626962030 := by decide
theorem cert_e605603706478 : check e605603706478 [[],[]] .chain = true := by decide
def e605603706490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605603706490 : Closed e605603706490 ∧ code e605603706490 = 2804626962042 := by decide
theorem cert_e605603706490 : check e605603706490 [[],[]] .chain = true := by decide
def e605603706678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605603706678 : Closed e605603706678 ∧ code e605603706678 = 2804626962230 := by decide
theorem cert_e605603706678 : check e605603706678 [[],[]] .chain = true := by decide
def e605603706682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605603706682 : Closed e605603706682 ∧ code e605603706682 = 2804626962234 := by decide
theorem cert_e605603706682 : check e605603706682 [[],[]] .chain = true := by decide
def e605603706926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605603706926 : Closed e605603706926 ∧ code e605603706926 = 2804626962478 := by decide
theorem cert_e605603706926 : check e605603706926 [[],[]] .chain = true := by decide
def e605603707118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605603707118 : Closed e605603707118 ∧ code e605603707118 = 2804626962670 := by decide
theorem cert_e605603707118 : check e605603707118 [[],[]] .chain = true := by decide
def e605603707126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605603707126 : Closed e605603707126 ∧ code e605603707126 = 2804626962678 := by decide
theorem cert_e605603707126 : check e605603707126 [[],[]] .chain = true := by decide
def e605603707310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605603707310 : Closed e605603707310 ∧ code e605603707310 = 2804626962862 := by decide
theorem cert_e605603707310 : check e605603707310 [[],[]] .chain = true := by decide
def e605603707322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605603707322 : Closed e605603707322 ∧ code e605603707322 = 2804626962874 := by decide
theorem cert_e605603707322 : check e605603707322 [[],[]] .chain = true := by decide
def e605603707370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605603707370 : Closed e605603707370 ∧ code e605603707370 = 2804626962922 := by decide
theorem cert_e605603707370 : check e605603707370 [[],[]] .chain = true := by decide
def e605603707502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605603707502 : Closed e605603707502 ∧ code e605603707502 = 2804626963054 := by decide
theorem cert_e605603707502 : check e605603707502 [[],[]] .chain = true := by decide
def e605603707514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605603707514 : Closed e605603707514 ∧ code e605603707514 = 2804626963066 := by decide
theorem cert_e605603707514 : check e605603707514 [[],[]] .chain = true := by decide
def e605603707678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605603707678 : Closed e605603707678 ∧ code e605603707678 = 2804626963230 := by decide
theorem cert_e605603707678 : check e605603707678 [[],[]] .chain = true := by decide
def e605603707778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605603707778 : Closed e605603707778 ∧ code e605603707778 = 2804626963330 := by decide
theorem cert_e605603707778 : check e605603707778 [[],[]] .chain = true := by decide
def e605603707790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605603707790 : Closed e605603707790 ∧ code e605603707790 = 2804626963342 := by decide
theorem cert_e605603707790 : check e605603707790 [[],[]] .chain = true := by decide
def e605603707802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605603707802 : Closed e605603707802 ∧ code e605603707802 = 2804626963354 := by decide
theorem cert_e605603707802 : check e605603707802 [[],[]] .chain = true := by decide
def e605603707926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605603707926 : Closed e605603707926 ∧ code e605603707926 = 2804626963478 := by decide
theorem cert_e605603707926 : check e605603707926 [[],[]] .chain = true := by decide
def e605603708022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605603708022 : Closed e605603708022 ∧ code e605603708022 = 2804626963574 := by decide
theorem cert_e605603708022 : check e605603708022 [[],[]] .chain = true := by decide
def e605603708118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605603708118 : Closed e605603708118 ∧ code e605603708118 = 2804626963670 := by decide
theorem cert_e605603708118 : check e605603708118 [[],[]] .chain = true := by decide
def e605603708122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605603708122 : Closed e605603708122 ∧ code e605603708122 = 2804626963674 := by decide
theorem cert_e605603708122 : check e605603708122 [[],[]] .chain = true := by decide
def e605603708138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605603708138 : Closed e605603708138 ∧ code e605603708138 = 2804626963690 := by decide
theorem cert_e605603708138 : check e605603708138 [[],[]] .chain = true := by decide
def e605603708214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605603708214 : Closed e605603708214 ∧ code e605603708214 = 2804626963766 := by decide
theorem cert_e605603708214 : check e605603708214 [[],[]] .chain = true := by decide
def e605603708218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605603708218 : Closed e605603708218 ∧ code e605603708218 = 2804626963770 := by decide
theorem cert_e605603708218 : check e605603708218 [[],[]] .chain = true := by decide
def e605603708290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605603708290 : Closed e605603708290 ∧ code e605603708290 = 2804626963842 := by decide
theorem cert_e605603708290 : check e605603708290 [[],[]] .chain = true := by decide
def e605603708302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605603708302 : Closed e605603708302 ∧ code e605603708302 = 2804626963854 := by decide
theorem cert_e605603708302 : check e605603708302 [[],[]] .chain = true := by decide
def e605603708314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605603708314 : Closed e605603708314 ∧ code e605603708314 = 2804626963866 := by decide
theorem cert_e605603708314 : check e605603708314 [[],[]] .chain = true := by decide
end Blc.Floor41
