import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605590435054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605590435054 : Closed e605590435054 ∧ code e605590435054 = 2804613690606 := by decide
theorem cert_e605590435054 : check e605590435054 [[],[]] .smaller = true := by decide
def e605590435062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605590435062 : Closed e605590435062 ∧ code e605590435062 = 2804613690614 := by decide
theorem cert_e605590435062 : check e605590435062 [[],[]] .smaller = true := by decide
def e605590435438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605590435438 : Closed e605590435438 ∧ code e605590435438 = 2804613690990 := by decide
theorem cert_e605590435438 : check e605590435438 [[],[]] .smaller = true := by decide
def e605590435450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605590435450 : Closed e605590435450 ∧ code e605590435450 = 2804613691002 := by decide
theorem cert_e605590435450 : check e605590435450 [[],[]] .smaller = true := by decide
def e605590435638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590435638 : Closed e605590435638 ∧ code e605590435638 = 2804613691190 := by decide
theorem cert_e605590435638 : check e605590435638 [[],[]] .smaller = true := by decide
def e605590435642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590435642 : Closed e605590435642 ∧ code e605590435642 = 2804613691194 := by decide
theorem cert_e605590435642 : check e605590435642 [[],[]] .smaller = true := by decide
def e605590436270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e605590436270 : Closed e605590436270 ∧ code e605590436270 = 2804613691822 := by decide
theorem cert_e605590436270 : check e605590436270 [[],[]] .smaller = true := by decide
def e605590436282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e605590436282 : Closed e605590436282 ∧ code e605590436282 = 2804613691834 := by decide
theorem cert_e605590436282 : check e605590436282 [[],[]] .smaller = true := by decide
def e605590436330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e605590436330 : Closed e605590436330 ∧ code e605590436330 = 2804613691882 := by decide
theorem cert_e605590436330 : check e605590436330 [[],[]] .smaller = true := by decide
def e605590436462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605590436462 : Closed e605590436462 ∧ code e605590436462 = 2804613692014 := by decide
theorem cert_e605590436462 : check e605590436462 [[],[]] .smaller = true := by decide
def e605590436474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605590436474 : Closed e605590436474 ∧ code e605590436474 = 2804613692026 := by decide
theorem cert_e605590436474 : check e605590436474 [[],[]] .smaller = true := by decide
def e605590436762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605590436762 : Closed e605590436762 ∧ code e605590436762 = 2804613692314 := by decide
theorem cert_e605590436762 : check e605590436762 [[],[]] .smaller = true := by decide
def e605590437078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e605590437078 : Closed e605590437078 ∧ code e605590437078 = 2804613692630 := by decide
theorem cert_e605590437078 : check e605590437078 [[],[]] .smaller = true := by decide
def e605590437082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e605590437082 : Closed e605590437082 ∧ code e605590437082 = 2804613692634 := by decide
theorem cert_e605590437082 : check e605590437082 [[],[]] .smaller = true := by decide
def e605590437098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e605590437098 : Closed e605590437098 ∧ code e605590437098 = 2804613692650 := by decide
theorem cert_e605590437098 : check e605590437098 [[],[]] .smaller = true := by decide
def e605590437174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590437174 : Closed e605590437174 ∧ code e605590437174 = 2804613692726 := by decide
theorem cert_e605590437174 : check e605590437174 [[],[]] .smaller = true := by decide
def e605590437178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590437178 : Closed e605590437178 ∧ code e605590437178 = 2804613692730 := by decide
theorem cert_e605590437178 : check e605590437178 [[],[]] .smaller = true := by decide
def e605590437274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605590437274 : Closed e605590437274 ∧ code e605590437274 = 2804613692826 := by decide
theorem cert_e605590437274 : check e605590437274 [[],[]] .smaller = true := by decide
def e605590440814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e605590440814 : Closed e605590440814 ∧ code e605590440814 = 2804613696366 := by decide
theorem cert_e605590440814 : check e605590440814 [[],[]] .smaller = true := by decide
def e605590440822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e605590440822 : Closed e605590440822 ∧ code e605590440822 = 2804613696374 := by decide
theorem cert_e605590440822 : check e605590440822 [[],[]] .smaller = true := by decide
def e605590440878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e605590440878 : Closed e605590440878 ∧ code e605590440878 = 2804613696430 := by decide
theorem cert_e605590440878 : check e605590440878 [[],[]] .smaller = true := by decide
def e605590440890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e605590440890 : Closed e605590440890 ∧ code e605590440890 = 2804613696442 := by decide
theorem cert_e605590440890 : check e605590440890 [[],[]] .smaller = true := by decide
def e605590440918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e605590440918 : Closed e605590440918 ∧ code e605590440918 = 2804613696470 := by decide
theorem cert_e605590440918 : check e605590440918 [[],[]] .smaller = true := by decide
def e605590440922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e605590440922 : Closed e605590440922 ∧ code e605590440922 = 2804613696474 := by decide
theorem cert_e605590440922 : check e605590440922 [[],[]] .smaller = true := by decide
def e605590441198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e605590441198 : Closed e605590441198 ∧ code e605590441198 = 2804613696750 := by decide
theorem cert_e605590441198 : check e605590441198 [[],[]] .smaller = true := by decide
def e605590441206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e605590441206 : Closed e605590441206 ∧ code e605590441206 = 2804613696758 := by decide
theorem cert_e605590441206 : check e605590441206 [[],[]] .smaller = true := by decide
def e605590441582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e605590441582 : Closed e605590441582 ∧ code e605590441582 = 2804613697134 := by decide
theorem cert_e605590441582 : check e605590441582 [[],[]] .smaller = true := by decide
def e605590441594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e605590441594 : Closed e605590441594 ∧ code e605590441594 = 2804613697146 := by decide
theorem cert_e605590441594 : check e605590441594 [[],[]] .smaller = true := by decide
def e605590441782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e605590441782 : Closed e605590441782 ∧ code e605590441782 = 2804613697334 := by decide
theorem cert_e605590441782 : check e605590441782 [[],[]] .smaller = true := by decide
def e605590441786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e605590441786 : Closed e605590441786 ∧ code e605590441786 = 2804613697338 := by decide
theorem cert_e605590441786 : check e605590441786 [[],[]] .smaller = true := by decide
def e605590447534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e605590447534 : Closed e605590447534 ∧ code e605590447534 = 2804613703086 := by decide
theorem cert_e605590447534 : check e605590447534 [[],[]] .smaller = true := by decide
def e605590447546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e605590447546 : Closed e605590447546 ∧ code e605590447546 = 2804613703098 := by decide
theorem cert_e605590447546 : check e605590447546 [[],[]] .smaller = true := by decide
def e605590447594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e605590447594 : Closed e605590447594 ∧ code e605590447594 = 2804613703146 := by decide
theorem cert_e605590447594 : check e605590447594 [[],[]] .smaller = true := by decide
def e605590447726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e605590447726 : Closed e605590447726 ∧ code e605590447726 = 2804613703278 := by decide
theorem cert_e605590447726 : check e605590447726 [[],[]] .smaller = true := by decide
def e605590447738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e605590447738 : Closed e605590447738 ∧ code e605590447738 = 2804613703290 := by decide
theorem cert_e605590447738 : check e605590447738 [[],[]] .smaller = true := by decide
def e605590448026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e605590448026 : Closed e605590448026 ∧ code e605590448026 = 2804613703578 := by decide
theorem cert_e605590448026 : check e605590448026 [[],[]] .smaller = true := by decide
def e605590450902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e605590450902 : Closed e605590450902 ∧ code e605590450902 = 2804613706454 := by decide
theorem cert_e605590450902 : check e605590450902 [[],[]] .smaller = true := by decide
def e605590450906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e605590450906 : Closed e605590450906 ∧ code e605590450906 = 2804613706458 := by decide
theorem cert_e605590450906 : check e605590450906 [[],[]] .smaller = true := by decide
def e605590450922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e605590450922 : Closed e605590450922 ∧ code e605590450922 = 2804613706474 := by decide
theorem cert_e605590450922 : check e605590450922 [[],[]] .smaller = true := by decide
def e605590450998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e605590450998 : Closed e605590450998 ∧ code e605590450998 = 2804613706550 := by decide
theorem cert_e605590450998 : check e605590450998 [[],[]] .smaller = true := by decide
def e605590451002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e605590451002 : Closed e605590451002 ∧ code e605590451002 = 2804613706554 := by decide
theorem cert_e605590451002 : check e605590451002 [[],[]] .smaller = true := by decide
def e605590451098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e605590451098 : Closed e605590451098 ∧ code e605590451098 = 2804613706650 := by decide
theorem cert_e605590451098 : check e605590451098 [[],[]] .smaller = true := by decide
def e605590566334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4)))))))))
theorem wire_e605590566334 : Closed e605590566334 ∧ code e605590566334 = 2804613821886 := by decide
theorem cert_e605590566334 : check e605590566334 [[],[]] .smaller = true := by decide
def e605590566366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e605590566366 : Closed e605590566366 ∧ code e605590566366 = 2804613821918 := by decide
theorem cert_e605590566366 : check e605590566366 [[],[]] .smaller = true := by decide
def e605590566382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e605590566382 : Closed e605590566382 ∧ code e605590566382 = 2804613821934 := by decide
theorem cert_e605590566382 : check e605590566382 [[],[]] .smaller = true := by decide
def e605590566390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1)))))))))
theorem wire_e605590566390 : Closed e605590566390 ∧ code e605590566390 = 2804613821942 := by decide
theorem cert_e605590566390 : check e605590566390 [[],[]] .smaller = true := by decide
def e605590566590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4)))))))))
theorem wire_e605590566590 : Closed e605590566590 ∧ code e605590566590 = 2804613822142 := by decide
theorem cert_e605590566590 : check e605590566590 [[],[]] .smaller = true := by decide
def e605590566622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e605590566622 : Closed e605590566622 ∧ code e605590566622 = 2804613822174 := by decide
theorem cert_e605590566622 : check e605590566622 [[],[]] .smaller = true := by decide
def e605590566638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))))
theorem wire_e605590566638 : Closed e605590566638 ∧ code e605590566638 = 2804613822190 := by decide
theorem cert_e605590566638 : check e605590566638 [[],[]] .smaller = true := by decide
def e605590566646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e605590566646 : Closed e605590566646 ∧ code e605590566646 = 2804613822198 := by decide
theorem cert_e605590566646 : check e605590566646 [[],[]] .smaller = true := by decide
def e605590566650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0)))))))))
theorem wire_e605590566650 : Closed e605590566650 ∧ code e605590566650 = 2804613822202 := by decide
theorem cert_e605590566650 : check e605590566650 [[],[]] .smaller = true := by decide
def e605590566750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e605590566750 : Closed e605590566750 ∧ code e605590566750 = 2804613822302 := by decide
theorem cert_e605590566750 : check e605590566750 [[],[]] .smaller = true := by decide
def e605590566766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))))
theorem wire_e605590566766 : Closed e605590566766 ∧ code e605590566766 = 2804613822318 := by decide
theorem cert_e605590566766 : check e605590566766 [[],[]] .smaller = true := by decide
def e605590566774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))))
theorem wire_e605590566774 : Closed e605590566774 ∧ code e605590566774 = 2804613822326 := by decide
theorem cert_e605590566774 : check e605590566774 [[],[]] .smaller = true := by decide
def e605590566778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e605590566778 : Closed e605590566778 ∧ code e605590566778 = 2804613822330 := by decide
theorem cert_e605590566778 : check e605590566778 [[],[]] .smaller = true := by decide
def e605590566830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e605590566830 : Closed e605590566830 ∧ code e605590566830 = 2804613822382 := by decide
theorem cert_e605590566830 : check e605590566830 [[],[]] .smaller = true := by decide
def e605590566838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e605590566838 : Closed e605590566838 ∧ code e605590566838 = 2804613822390 := by decide
theorem cert_e605590566838 : check e605590566838 [[],[]] .smaller = true := by decide
def e605590566842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e605590566842 : Closed e605590566842 ∧ code e605590566842 = 2804613822394 := by decide
theorem cert_e605590566842 : check e605590566842 [[],[]] .smaller = true := by decide
def e605590566870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1)))))))))
theorem wire_e605590566870 : Closed e605590566870 ∧ code e605590566870 = 2804613822422 := by decide
theorem cert_e605590566870 : check e605590566870 [[],[]] .smaller = true := by decide
def e605590566874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0)))))))))
theorem wire_e605590566874 : Closed e605590566874 ∧ code e605590566874 = 2804613822426 := by decide
theorem cert_e605590566874 : check e605590566874 [[],[]] .smaller = true := by decide
def e605590567614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4)))))))))
theorem wire_e605590567614 : Closed e605590567614 ∧ code e605590567614 = 2804613823166 := by decide
theorem cert_e605590567614 : check e605590567614 [[],[]] .smaller = true := by decide
def e605590567646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e605590567646 : Closed e605590567646 ∧ code e605590567646 = 2804613823198 := by decide
theorem cert_e605590567646 : check e605590567646 [[],[]] .smaller = true := by decide
def e605590567662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e605590567662 : Closed e605590567662 ∧ code e605590567662 = 2804613823214 := by decide
theorem cert_e605590567662 : check e605590567662 [[],[]] .smaller = true := by decide
def e605590567670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e605590567670 : Closed e605590567670 ∧ code e605590567670 = 2804613823222 := by decide
theorem cert_e605590567670 : check e605590567670 [[],[]] .smaller = true := by decide
def e605590567674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0)))))))))
theorem wire_e605590567674 : Closed e605590567674 ∧ code e605590567674 = 2804613823226 := by decide
theorem cert_e605590567674 : check e605590567674 [[],[]] .smaller = true := by decide
def e605590567774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e605590567774 : Closed e605590567774 ∧ code e605590567774 = 2804613823326 := by decide
theorem cert_e605590567774 : check e605590567774 [[],[]] .smaller = true := by decide
def e605590567802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e605590567802 : Closed e605590567802 ∧ code e605590567802 = 2804613823354 := by decide
theorem cert_e605590567802 : check e605590567802 [[],[]] .smaller = true := by decide
def e605590567854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e605590567854 : Closed e605590567854 ∧ code e605590567854 = 2804613823406 := by decide
theorem cert_e605590567854 : check e605590567854 [[],[]] .smaller = true := by decide
def e605590567866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e605590567866 : Closed e605590567866 ∧ code e605590567866 = 2804613823418 := by decide
theorem cert_e605590567866 : check e605590567866 [[],[]] .smaller = true := by decide
def e605590567894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e605590567894 : Closed e605590567894 ∧ code e605590567894 = 2804613823446 := by decide
theorem cert_e605590567894 : check e605590567894 [[],[]] .smaller = true := by decide
def e605590567898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e605590567898 : Closed e605590567898 ∧ code e605590567898 = 2804613823450 := by decide
theorem cert_e605590567898 : check e605590567898 [[],[]] .smaller = true := by decide
def e605590567914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0)))))))))
theorem wire_e605590567914 : Closed e605590567914 ∧ code e605590567914 = 2804613823466 := by decide
theorem cert_e605590567914 : check e605590567914 [[],[]] .smaller = true := by decide
def e605590568286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e605590568286 : Closed e605590568286 ∧ code e605590568286 = 2804613823838 := by decide
theorem cert_e605590568286 : check e605590568286 [[],[]] .smaller = true := by decide
def e605590568302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605590568302 : Closed e605590568302 ∧ code e605590568302 = 2804613823854 := by decide
theorem cert_e605590568302 : check e605590568302 [[],[]] .smaller = true := by decide
def e605590568310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605590568310 : Closed e605590568310 ∧ code e605590568310 = 2804613823862 := by decide
theorem cert_e605590568310 : check e605590568310 [[],[]] .smaller = true := by decide
def e605590568314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e605590568314 : Closed e605590568314 ∧ code e605590568314 = 2804613823866 := by decide
theorem cert_e605590568314 : check e605590568314 [[],[]] .smaller = true := by decide
def e605590568366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605590568366 : Closed e605590568366 ∧ code e605590568366 = 2804613823918 := by decide
theorem cert_e605590568366 : check e605590568366 [[],[]] .smaller = true := by decide
def e605590568378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605590568378 : Closed e605590568378 ∧ code e605590568378 = 2804613823930 := by decide
theorem cert_e605590568378 : check e605590568378 [[],[]] .smaller = true := by decide
def e605590568406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605590568406 : Closed e605590568406 ∧ code e605590568406 = 2804613823958 := by decide
theorem cert_e605590568406 : check e605590568406 [[],[]] .smaller = true := by decide
def e605590568410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605590568410 : Closed e605590568410 ∧ code e605590568410 = 2804613823962 := by decide
theorem cert_e605590568410 : check e605590568410 [[],[]] .smaller = true := by decide
def e605590568426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e605590568426 : Closed e605590568426 ∧ code e605590568426 = 2804613823978 := by decide
theorem cert_e605590568426 : check e605590568426 [[],[]] .smaller = true := by decide
def e605590568622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605590568622 : Closed e605590568622 ∧ code e605590568622 = 2804613824174 := by decide
theorem cert_e605590568622 : check e605590568622 [[],[]] .smaller = true := by decide
def e605590568630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e605590568630 : Closed e605590568630 ∧ code e605590568630 = 2804613824182 := by decide
theorem cert_e605590568630 : check e605590568630 [[],[]] .smaller = true := by decide
def e605590568634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605590568634 : Closed e605590568634 ∧ code e605590568634 = 2804613824186 := by decide
theorem cert_e605590568634 : check e605590568634 [[],[]] .smaller = true := by decide
def e605590568662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e605590568662 : Closed e605590568662 ∧ code e605590568662 = 2804613824214 := by decide
theorem cert_e605590568662 : check e605590568662 [[],[]] .smaller = true := by decide
def e605590568666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e605590568666 : Closed e605590568666 ∧ code e605590568666 = 2804613824218 := by decide
theorem cert_e605590568666 : check e605590568666 [[],[]] .smaller = true := by decide
def e605590568682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605590568682 : Closed e605590568682 ∧ code e605590568682 = 2804613824234 := by decide
theorem cert_e605590568682 : check e605590568682 [[],[]] .smaller = true := by decide
def e605590568790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605590568790 : Closed e605590568790 ∧ code e605590568790 = 2804613824342 := by decide
theorem cert_e605590568790 : check e605590568790 [[],[]] .smaller = true := by decide
def e605590568794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605590568794 : Closed e605590568794 ∧ code e605590568794 = 2804613824346 := by decide
theorem cert_e605590568794 : check e605590568794 [[],[]] .smaller = true := by decide
def e605590568810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605590568810 : Closed e605590568810 ∧ code e605590568810 = 2804613824362 := by decide
theorem cert_e605590568810 : check e605590568810 [[],[]] .smaller = true := by decide
def e605590572478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4)))))))))
theorem wire_e605590572478 : Closed e605590572478 ∧ code e605590572478 = 2804613828030 := by decide
theorem cert_e605590572478 : check e605590572478 [[],[]] .smaller = true := by decide
def e605590572510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e605590572510 : Closed e605590572510 ∧ code e605590572510 = 2804613828062 := by decide
theorem cert_e605590572510 : check e605590572510 [[],[]] .smaller = true := by decide
def e605590572526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e605590572526 : Closed e605590572526 ∧ code e605590572526 = 2804613828078 := by decide
theorem cert_e605590572526 : check e605590572526 [[],[]] .smaller = true := by decide
def e605590572534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1)))))))))
theorem wire_e605590572534 : Closed e605590572534 ∧ code e605590572534 = 2804613828086 := by decide
theorem cert_e605590572534 : check e605590572534 [[],[]] .smaller = true := by decide
def e605590572734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4)))))))))
theorem wire_e605590572734 : Closed e605590572734 ∧ code e605590572734 = 2804613828286 := by decide
theorem cert_e605590572734 : check e605590572734 [[],[]] .smaller = true := by decide
def e605590572766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e605590572766 : Closed e605590572766 ∧ code e605590572766 = 2804613828318 := by decide
theorem cert_e605590572766 : check e605590572766 [[],[]] .smaller = true := by decide
def e605590572782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))))
theorem wire_e605590572782 : Closed e605590572782 ∧ code e605590572782 = 2804613828334 := by decide
theorem cert_e605590572782 : check e605590572782 [[],[]] .smaller = true := by decide
def e605590572790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e605590572790 : Closed e605590572790 ∧ code e605590572790 = 2804613828342 := by decide
theorem cert_e605590572790 : check e605590572790 [[],[]] .smaller = true := by decide
def e605590572794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0)))))))))
theorem wire_e605590572794 : Closed e605590572794 ∧ code e605590572794 = 2804613828346 := by decide
theorem cert_e605590572794 : check e605590572794 [[],[]] .smaller = true := by decide
def e605590572894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e605590572894 : Closed e605590572894 ∧ code e605590572894 = 2804613828446 := by decide
theorem cert_e605590572894 : check e605590572894 [[],[]] .smaller = true := by decide
def e605590572910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))))
theorem wire_e605590572910 : Closed e605590572910 ∧ code e605590572910 = 2804613828462 := by decide
theorem cert_e605590572910 : check e605590572910 [[],[]] .smaller = true := by decide
def e605590572918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))))
theorem wire_e605590572918 : Closed e605590572918 ∧ code e605590572918 = 2804613828470 := by decide
theorem cert_e605590572918 : check e605590572918 [[],[]] .smaller = true := by decide
def e605590572922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e605590572922 : Closed e605590572922 ∧ code e605590572922 = 2804613828474 := by decide
theorem cert_e605590572922 : check e605590572922 [[],[]] .smaller = true := by decide
def e605590572974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e605590572974 : Closed e605590572974 ∧ code e605590572974 = 2804613828526 := by decide
theorem cert_e605590572974 : check e605590572974 [[],[]] .smaller = true := by decide
def e605590572982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e605590572982 : Closed e605590572982 ∧ code e605590572982 = 2804613828534 := by decide
theorem cert_e605590572982 : check e605590572982 [[],[]] .smaller = true := by decide
def e605590572986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e605590572986 : Closed e605590572986 ∧ code e605590572986 = 2804613828538 := by decide
theorem cert_e605590572986 : check e605590572986 [[],[]] .smaller = true := by decide
def e605590573014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1)))))))))
theorem wire_e605590573014 : Closed e605590573014 ∧ code e605590573014 = 2804613828566 := by decide
theorem cert_e605590573014 : check e605590573014 [[],[]] .smaller = true := by decide
def e605590573018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0)))))))))
theorem wire_e605590573018 : Closed e605590573018 ∧ code e605590573018 = 2804613828570 := by decide
theorem cert_e605590573018 : check e605590573018 [[],[]] .smaller = true := by decide
def e605590574014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4))))))))))
theorem wire_e605590574014 : Closed e605590574014 ∧ code e605590574014 = 2804613829566 := by decide
theorem cert_e605590574014 : check e605590574014 [[],[]] .smaller = true := by decide
def e605590574046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e605590574046 : Closed e605590574046 ∧ code e605590574046 = 2804613829598 := by decide
theorem cert_e605590574046 : check e605590574046 [[],[]] .smaller = true := by decide
def e605590574062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e605590574062 : Closed e605590574062 ∧ code e605590574062 = 2804613829614 := by decide
theorem cert_e605590574062 : check e605590574062 [[],[]] .smaller = true := by decide
def e605590574070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1))))))))))
theorem wire_e605590574070 : Closed e605590574070 ∧ code e605590574070 = 2804613829622 := by decide
theorem cert_e605590574070 : check e605590574070 [[],[]] .smaller = true := by decide
def e605590575550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4))))))))))
theorem wire_e605590575550 : Closed e605590575550 ∧ code e605590575550 = 2804613831102 := by decide
theorem cert_e605590575550 : check e605590575550 [[],[]] .smaller = true := by decide
def e605590575582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e605590575582 : Closed e605590575582 ∧ code e605590575582 = 2804613831134 := by decide
theorem cert_e605590575582 : check e605590575582 [[],[]] .smaller = true := by decide
def e605590575598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))))
theorem wire_e605590575598 : Closed e605590575598 ∧ code e605590575598 = 2804613831150 := by decide
theorem cert_e605590575598 : check e605590575598 [[],[]] .smaller = true := by decide
def e605590575606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e605590575606 : Closed e605590575606 ∧ code e605590575606 = 2804613831158 := by decide
theorem cert_e605590575606 : check e605590575606 [[],[]] .smaller = true := by decide
def e605590575610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0))))))))))
theorem wire_e605590575610 : Closed e605590575610 ∧ code e605590575610 = 2804613831162 := by decide
theorem cert_e605590575610 : check e605590575610 [[],[]] .smaller = true := by decide
def e605590576350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e605590576350 : Closed e605590576350 ∧ code e605590576350 = 2804613831902 := by decide
theorem cert_e605590576350 : check e605590576350 [[],[]] .smaller = true := by decide
def e605590576366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605590576366 : Closed e605590576366 ∧ code e605590576366 = 2804613831918 := by decide
theorem cert_e605590576366 : check e605590576366 [[],[]] .smaller = true := by decide
def e605590576374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605590576374 : Closed e605590576374 ∧ code e605590576374 = 2804613831926 := by decide
theorem cert_e605590576374 : check e605590576374 [[],[]] .smaller = true := by decide
def e605590576378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e605590576378 : Closed e605590576378 ∧ code e605590576378 = 2804613831930 := by decide
theorem cert_e605590576378 : check e605590576378 [[],[]] .smaller = true := by decide
def e605590576750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605590576750 : Closed e605590576750 ∧ code e605590576750 = 2804613832302 := by decide
theorem cert_e605590576750 : check e605590576750 [[],[]] .smaller = true := by decide
def e605590576758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e605590576758 : Closed e605590576758 ∧ code e605590576758 = 2804613832310 := by decide
theorem cert_e605590576758 : check e605590576758 [[],[]] .smaller = true := by decide
def e605590576762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605590576762 : Closed e605590576762 ∧ code e605590576762 = 2804613832314 := by decide
theorem cert_e605590576762 : check e605590576762 [[],[]] .smaller = true := by decide
def e605590576950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605590576950 : Closed e605590576950 ∧ code e605590576950 = 2804613832502 := by decide
theorem cert_e605590576950 : check e605590576950 [[],[]] .smaller = true := by decide
def e605590576954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605590576954 : Closed e605590576954 ∧ code e605590576954 = 2804613832506 := by decide
theorem cert_e605590576954 : check e605590576954 [[],[]] .smaller = true := by decide
def e605590578878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4)))))))))
theorem wire_e605590578878 : Closed e605590578878 ∧ code e605590578878 = 2804613834430 := by decide
theorem cert_e605590578878 : check e605590578878 [[],[]] .smaller = true := by decide
def e605590578910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e605590578910 : Closed e605590578910 ∧ code e605590578910 = 2804613834462 := by decide
theorem cert_e605590578910 : check e605590578910 [[],[]] .smaller = true := by decide
def e605590578926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e605590578926 : Closed e605590578926 ∧ code e605590578926 = 2804613834478 := by decide
theorem cert_e605590578926 : check e605590578926 [[],[]] .smaller = true := by decide
def e605590578934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e605590578934 : Closed e605590578934 ∧ code e605590578934 = 2804613834486 := by decide
theorem cert_e605590578934 : check e605590578934 [[],[]] .smaller = true := by decide
def e605590578938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0)))))))))
theorem wire_e605590578938 : Closed e605590578938 ∧ code e605590578938 = 2804613834490 := by decide
theorem cert_e605590578938 : check e605590578938 [[],[]] .smaller = true := by decide
def e605590579038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e605590579038 : Closed e605590579038 ∧ code e605590579038 = 2804613834590 := by decide
theorem cert_e605590579038 : check e605590579038 [[],[]] .smaller = true := by decide
def e605590579066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e605590579066 : Closed e605590579066 ∧ code e605590579066 = 2804613834618 := by decide
theorem cert_e605590579066 : check e605590579066 [[],[]] .smaller = true := by decide
def e605590579118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e605590579118 : Closed e605590579118 ∧ code e605590579118 = 2804613834670 := by decide
theorem cert_e605590579118 : check e605590579118 [[],[]] .smaller = true := by decide
def e605590579130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e605590579130 : Closed e605590579130 ∧ code e605590579130 = 2804613834682 := by decide
theorem cert_e605590579130 : check e605590579130 [[],[]] .smaller = true := by decide
def e605590579158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e605590579158 : Closed e605590579158 ∧ code e605590579158 = 2804613834710 := by decide
theorem cert_e605590579158 : check e605590579158 [[],[]] .smaller = true := by decide
def e605590579162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e605590579162 : Closed e605590579162 ∧ code e605590579162 = 2804613834714 := by decide
theorem cert_e605590579162 : check e605590579162 [[],[]] .smaller = true := by decide
def e605590579178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0)))))))))
theorem wire_e605590579178 : Closed e605590579178 ∧ code e605590579178 = 2804613834730 := by decide
theorem cert_e605590579178 : check e605590579178 [[],[]] .smaller = true := by decide
def e605590579646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4))))))))))
theorem wire_e605590579646 : Closed e605590579646 ∧ code e605590579646 = 2804613835198 := by decide
theorem cert_e605590579646 : check e605590579646 [[],[]] .smaller = true := by decide
def e605590579678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e605590579678 : Closed e605590579678 ∧ code e605590579678 = 2804613835230 := by decide
theorem cert_e605590579678 : check e605590579678 [[],[]] .smaller = true := by decide
def e605590579694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e605590579694 : Closed e605590579694 ∧ code e605590579694 = 2804613835246 := by decide
theorem cert_e605590579694 : check e605590579694 [[],[]] .smaller = true := by decide
def e605590579702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e605590579702 : Closed e605590579702 ∧ code e605590579702 = 2804613835254 := by decide
theorem cert_e605590579702 : check e605590579702 [[],[]] .smaller = true := by decide
def e605590579706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0))))))))))
theorem wire_e605590579706 : Closed e605590579706 ∧ code e605590579706 = 2804613835258 := by decide
theorem cert_e605590579706 : check e605590579706 [[],[]] .smaller = true := by decide
def e605590580446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e605590580446 : Closed e605590580446 ∧ code e605590580446 = 2804613835998 := by decide
theorem cert_e605590580446 : check e605590580446 [[],[]] .smaller = true := by decide
def e605590580474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e605590580474 : Closed e605590580474 ∧ code e605590580474 = 2804613836026 := by decide
theorem cert_e605590580474 : check e605590580474 [[],[]] .smaller = true := by decide
def e605590580846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605590580846 : Closed e605590580846 ∧ code e605590580846 = 2804613836398 := by decide
theorem cert_e605590580846 : check e605590580846 [[],[]] .smaller = true := by decide
def e605590580858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605590580858 : Closed e605590580858 ∧ code e605590580858 = 2804613836410 := by decide
theorem cert_e605590580858 : check e605590580858 [[],[]] .smaller = true := by decide
def e605590581046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605590581046 : Closed e605590581046 ∧ code e605590581046 = 2804613836598 := by decide
theorem cert_e605590581046 : check e605590581046 [[],[]] .smaller = true := by decide
def e605590581050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605590581050 : Closed e605590581050 ∧ code e605590581050 = 2804613836602 := by decide
theorem cert_e605590581050 : check e605590581050 [[],[]] .smaller = true := by decide
def e605590581146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605590581146 : Closed e605590581146 ∧ code e605590581146 = 2804613836698 := by decide
theorem cert_e605590581146 : check e605590581146 [[],[]] .smaller = true := by decide
def e605590582110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e605590582110 : Closed e605590582110 ∧ code e605590582110 = 2804613837662 := by decide
theorem cert_e605590582110 : check e605590582110 [[],[]] .smaller = true := by decide
def e605590582126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605590582126 : Closed e605590582126 ∧ code e605590582126 = 2804613837678 := by decide
theorem cert_e605590582126 : check e605590582126 [[],[]] .smaller = true := by decide
def e605590582134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605590582134 : Closed e605590582134 ∧ code e605590582134 = 2804613837686 := by decide
theorem cert_e605590582134 : check e605590582134 [[],[]] .smaller = true := by decide
def e605590582138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e605590582138 : Closed e605590582138 ∧ code e605590582138 = 2804613837690 := by decide
theorem cert_e605590582138 : check e605590582138 [[],[]] .smaller = true := by decide
def e605590582190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605590582190 : Closed e605590582190 ∧ code e605590582190 = 2804613837742 := by decide
theorem cert_e605590582190 : check e605590582190 [[],[]] .smaller = true := by decide
def e605590582202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605590582202 : Closed e605590582202 ∧ code e605590582202 = 2804613837754 := by decide
theorem cert_e605590582202 : check e605590582202 [[],[]] .smaller = true := by decide
def e605590582230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605590582230 : Closed e605590582230 ∧ code e605590582230 = 2804613837782 := by decide
theorem cert_e605590582230 : check e605590582230 [[],[]] .smaller = true := by decide
def e605590582234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605590582234 : Closed e605590582234 ∧ code e605590582234 = 2804613837786 := by decide
theorem cert_e605590582234 : check e605590582234 [[],[]] .smaller = true := by decide
def e605590582250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e605590582250 : Closed e605590582250 ∧ code e605590582250 = 2804613837802 := by decide
theorem cert_e605590582250 : check e605590582250 [[],[]] .smaller = true := by decide
def e605590582494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e605590582494 : Closed e605590582494 ∧ code e605590582494 = 2804613838046 := by decide
theorem cert_e605590582494 : check e605590582494 [[],[]] .smaller = true := by decide
end Blc.Floor41
