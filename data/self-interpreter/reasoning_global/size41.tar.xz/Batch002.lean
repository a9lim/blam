import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e149954874286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e149954874286 : Closed e149954874286 ∧ code e149954874286 = 2348978129838 := by decide
theorem cert_e149954874286 : check e149954874286 [[.under]] .sourceHead = true := by decide
def e149954874298 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e149954874298 : Closed e149954874298 ∧ code e149954874298 = 2348978129850 := by decide
theorem cert_e149954874298 : check e149954874298 [[.under]] .sourceHead = true := by decide
def e149954874326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e149954874326 : Closed e149954874326 ∧ code e149954874326 = 2348978129878 := by decide
theorem cert_e149954874326 : check e149954874326 [[.under]] .sourceHead = true := by decide
def e149954874330 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e149954874330 : Closed e149954874330 ∧ code e149954874330 = 2348978129882 := by decide
theorem cert_e149954874330 : check e149954874330 [[.under]] .sourceHead = true := by decide
def e149954874606 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e149954874606 : Closed e149954874606 ∧ code e149954874606 = 2348978130158 := by decide
theorem cert_e149954874606 : check e149954874606 [[.under]] .sourceHead = true := by decide
def e149954874614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e149954874614 : Closed e149954874614 ∧ code e149954874614 = 2348978130166 := by decide
theorem cert_e149954874614 : check e149954874614 [[.under]] .sourceHead = true := by decide
def e149954874990 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e149954874990 : Closed e149954874990 ∧ code e149954874990 = 2348978130542 := by decide
theorem cert_e149954874990 : check e149954874990 [[.under]] .sourceHead = true := by decide
def e149954875002 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e149954875002 : Closed e149954875002 ∧ code e149954875002 = 2348978130554 := by decide
theorem cert_e149954875002 : check e149954875002 [[.under]] .sourceHead = true := by decide
def e149954875190 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e149954875190 : Closed e149954875190 ∧ code e149954875190 = 2348978130742 := by decide
theorem cert_e149954875190 : check e149954875190 [[.under]] .sourceHead = true := by decide
def e149954875194 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e149954875194 : Closed e149954875194 ∧ code e149954875194 = 2348978130746 := by decide
theorem cert_e149954875194 : check e149954875194 [[.under]] .sourceHead = true := by decide
def e149954880950 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e149954880950 : Closed e149954880950 ∧ code e149954880950 = 2348978136502 := by decide
theorem cert_e149954880950 : check e149954880950 [[.under]] .sourceHead = true := by decide
def e149954880982 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e149954880982 : Closed e149954880982 ∧ code e149954880982 = 2348978136534 := by decide
theorem cert_e149954880982 : check e149954880982 [[.under]] .sourceHead = true := by decide
def e149954880986 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e149954880986 : Closed e149954880986 ∧ code e149954880986 = 2348978136538 := by decide
theorem cert_e149954880986 : check e149954880986 [[.under]] .sourceHead = true := by decide
def e149954881142 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e149954881142 : Closed e149954881142 ∧ code e149954881142 = 2348978136694 := by decide
theorem cert_e149954881142 : check e149954881142 [[.under]] .sourceHead = true := by decide
def e149954881334 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e149954881334 : Closed e149954881334 ∧ code e149954881334 = 2348978136886 := by decide
theorem cert_e149954881334 : check e149954881334 [[.under]] .sourceHead = true := by decide
def e149954881338 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e149954881338 : Closed e149954881338 ∧ code e149954881338 = 2348978136890 := by decide
theorem cert_e149954881338 : check e149954881338 [[.under]] .sourceHead = true := by decide
def e149955218286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e149955218286 : Closed e149955218286 ∧ code e149955218286 = 2348978473838 := by decide
theorem cert_e149955218286 : check e149955218286 [[.under]] .sourceHead = true := by decide
def e149955218294 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e149955218294 : Closed e149955218294 ∧ code e149955218294 = 2348978473846 := by decide
theorem cert_e149955218294 : check e149955218294 [[.under]] .sourceHead = true := by decide
def e149955218350 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e149955218350 : Closed e149955218350 ∧ code e149955218350 = 2348978473902 := by decide
theorem cert_e149955218350 : check e149955218350 [[.under]] .sourceHead = true := by decide
def e149955218362 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e149955218362 : Closed e149955218362 ∧ code e149955218362 = 2348978473914 := by decide
theorem cert_e149955218362 : check e149955218362 [[.under]] .sourceHead = true := by decide
def e149955218390 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e149955218390 : Closed e149955218390 ∧ code e149955218390 = 2348978473942 := by decide
theorem cert_e149955218390 : check e149955218390 [[.under]] .sourceHead = true := by decide
def e149955218394 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e149955218394 : Closed e149955218394 ∧ code e149955218394 = 2348978473946 := by decide
theorem cert_e149955218394 : check e149955218394 [[.under]] .sourceHead = true := by decide
def e149955218670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e149955218670 : Closed e149955218670 ∧ code e149955218670 = 2348978474222 := by decide
theorem cert_e149955218670 : check e149955218670 [[.under]] .sourceHead = true := by decide
def e149955218678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e149955218678 : Closed e149955218678 ∧ code e149955218678 = 2348978474230 := by decide
theorem cert_e149955218678 : check e149955218678 [[.under]] .sourceHead = true := by decide
def e149955219054 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e149955219054 : Closed e149955219054 ∧ code e149955219054 = 2348978474606 := by decide
theorem cert_e149955219054 : check e149955219054 [[.under]] .sourceHead = true := by decide
def e149955219066 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e149955219066 : Closed e149955219066 ∧ code e149955219066 = 2348978474618 := by decide
theorem cert_e149955219066 : check e149955219066 [[.under]] .sourceHead = true := by decide
def e149955219254 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e149955219254 : Closed e149955219254 ∧ code e149955219254 = 2348978474806 := by decide
theorem cert_e149955219254 : check e149955219254 [[.under]] .sourceHead = true := by decide
def e149955219258 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e149955219258 : Closed e149955219258 ∧ code e149955219258 = 2348978474810 := by decide
theorem cert_e149955219258 : check e149955219258 [[.under]] .sourceHead = true := by decide
def e150371801114 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150371801114 : Closed e150371801114 ∧ code e150371801114 = 2349395056666 := by decide
theorem cert_e150371801114 : check e150371801114 [[.under]] .width = true := by decide
def e150371932186 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150371932186 : Closed e150371932186 ∧ code e150371932186 = 2349395187738 := by decide
theorem cert_e150371932186 : check e150371932186 [[.under]] .width = true := by decide
def e150372849690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150372849690 : Closed e150372849690 ∧ code e150372849690 = 2349396105242 := by decide
theorem cert_e150372849690 : check e150372849690 [[.under]] .width = true := by decide
def e150373046298 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150373046298 : Closed e150373046298 ∧ code e150373046298 = 2349396301850 := by decide
theorem cert_e150373046298 : check e150373046298 [[.under]] .width = true := by decide
def e150373505050 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150373505050 : Closed e150373505050 ∧ code e150373505050 = 2349396760602 := by decide
theorem cert_e150373505050 : check e150373505050 [[.under]] .width = true := by decide
def e150373570586 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150373570586 : Closed e150373570586 ∧ code e150373570586 = 2349396826138 := by decide
theorem cert_e150373570586 : check e150373570586 [[.under]] .width = true := by decide
def e150378092570 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150378092570 : Closed e150378092570 ∧ code e150378092570 = 2349401348122 := by decide
theorem cert_e150378092570 : check e150378092570 [[.under]] .width = true := by decide
def e150378223642 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150378223642 : Closed e150378223642 ∧ code e150378223642 = 2349401479194 := by decide
theorem cert_e150378223642 : check e150378223642 [[.under]] .width = true := by decide
def e150384384026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150384384026 : Closed e150384384026 ∧ code e150384384026 = 2349407639578 := by decide
theorem cert_e150384384026 : check e150384384026 [[.under]] .width = true := by decide
def e150384580634 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150384580634 : Closed e150384580634 ∧ code e150384580634 = 2349407836186 := by decide
theorem cert_e150384580634 : check e150384580634 [[.under]] .width = true := by decide
def e150387660826 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150387660826 : Closed e150387660826 ∧ code e150387660826 = 2349410916378 := by decide
theorem cert_e150387660826 : check e150387660826 [[.under]] .width = true := by decide
def e150387726362 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e150387726362 : Closed e150387726362 ∧ code e150387726362 = 2349410981914 := by decide
theorem cert_e150387726362 : check e150387726362 [[.under]] .width = true := by decide
def e151229913966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e151229913966 : Closed e151229913966 ∧ code e151229913966 = 2350253169518 := by decide
theorem cert_e151229913966 : check e151229913966 [[.under],[.under]] .three = true := by decide
def e151229913974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e151229913974 : Closed e151229913974 ∧ code e151229913974 = 2350253169526 := by decide
theorem cert_e151229913974 : check e151229913974 [[.under],[.under]] .three = true := by decide
def e151229914038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e151229914038 : Closed e151229914038 ∧ code e151229914038 = 2350253169590 := by decide
theorem cert_e151229914038 : check e151229914038 [[.under],[.under]] .three = true := by decide
def e151229914478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e151229914478 : Closed e151229914478 ∧ code e151229914478 = 2350253170030 := by decide
theorem cert_e151229914478 : check e151229914478 [[.under],[.under]] .three = true := by decide
def e151229914486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e151229914486 : Closed e151229914486 ∧ code e151229914486 = 2350253170038 := by decide
theorem cert_e151229914486 : check e151229914486 [[.under],[.under]] .three = true := by decide
def e151229914542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e151229914542 : Closed e151229914542 ∧ code e151229914542 = 2350253170094 := by decide
theorem cert_e151229914542 : check e151229914542 [[.under],[.under]] .three = true := by decide
def e151229914554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e151229914554 : Closed e151229914554 ∧ code e151229914554 = 2350253170106 := by decide
theorem cert_e151229914554 : check e151229914554 [[.under],[.under]] .three = true := by decide
def e151229914582 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e151229914582 : Closed e151229914582 ∧ code e151229914582 = 2350253170134 := by decide
theorem cert_e151229914582 : check e151229914582 [[.under],[.under]] .three = true := by decide
def e151229914586 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e151229914586 : Closed e151229914586 ∧ code e151229914586 = 2350253170138 := by decide
theorem cert_e151229914586 : check e151229914586 [[.under],[.under]] .three = true := by decide
def e151229914806 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e151229914806 : Closed e151229914806 ∧ code e151229914806 = 2350253170358 := by decide
theorem cert_e151229914806 : check e151229914806 [[.under],[.under]] .three = true := by decide
def e151229914838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e151229914838 : Closed e151229914838 ∧ code e151229914838 = 2350253170390 := by decide
theorem cert_e151229914838 : check e151229914838 [[.under],[.under]] .three = true := by decide
def e151229914842 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e151229914842 : Closed e151229914842 ∧ code e151229914842 = 2350253170394 := by decide
theorem cert_e151229914842 : check e151229914842 [[.under],[.under]] .three = true := by decide
def e151229917038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e151229917038 : Closed e151229917038 ∧ code e151229917038 = 2350253172590 := by decide
theorem cert_e151229917038 : check e151229917038 [[.under],[.under]] .three = true := by decide
def e151229917046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e151229917046 : Closed e151229917046 ∧ code e151229917046 = 2350253172598 := by decide
theorem cert_e151229917046 : check e151229917046 [[.under],[.under]] .three = true := by decide
def e151229917110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e151229917110 : Closed e151229917110 ∧ code e151229917110 = 2350253172662 := by decide
theorem cert_e151229917110 : check e151229917110 [[.under],[.under]] .three = true := by decide
def e151229918446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e151229918446 : Closed e151229918446 ∧ code e151229918446 = 2350253173998 := by decide
theorem cert_e151229918446 : check e151229918446 [[.under],[.under]] .three = true := by decide
def e151229918454 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e151229918454 : Closed e151229918454 ∧ code e151229918454 = 2350253174006 := by decide
theorem cert_e151229918454 : check e151229918454 [[.under],[.under]] .three = true := by decide
def e151229918838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e151229918838 : Closed e151229918838 ∧ code e151229918838 = 2350253174390 := by decide
theorem cert_e151229918838 : check e151229918838 [[.under],[.under]] .three = true := by decide
def e151229920110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e151229920110 : Closed e151229920110 ∧ code e151229920110 = 2350253175662 := by decide
theorem cert_e151229920110 : check e151229920110 [[.under],[.under]] .three = true := by decide
def e151229920118 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e151229920118 : Closed e151229920118 ∧ code e151229920118 = 2350253175670 := by decide
theorem cert_e151229920118 : check e151229920118 [[.under],[.under]] .three = true := by decide
def e151229920174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e151229920174 : Closed e151229920174 ∧ code e151229920174 = 2350253175726 := by decide
theorem cert_e151229920174 : check e151229920174 [[.under],[.under]] .three = true := by decide
def e151229920186 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e151229920186 : Closed e151229920186 ∧ code e151229920186 = 2350253175738 := by decide
theorem cert_e151229920186 : check e151229920186 [[.under],[.under]] .three = true := by decide
def e151229920214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e151229920214 : Closed e151229920214 ∧ code e151229920214 = 2350253175766 := by decide
theorem cert_e151229920214 : check e151229920214 [[.under],[.under]] .three = true := by decide
def e151229920218 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e151229920218 : Closed e151229920218 ∧ code e151229920218 = 2350253175770 := by decide
theorem cert_e151229920218 : check e151229920218 [[.under],[.under]] .three = true := by decide
def e151229920494 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e151229920494 : Closed e151229920494 ∧ code e151229920494 = 2350253176046 := by decide
theorem cert_e151229920494 : check e151229920494 [[.under],[.under]] .three = true := by decide
def e151229920502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e151229920502 : Closed e151229920502 ∧ code e151229920502 = 2350253176054 := by decide
theorem cert_e151229920502 : check e151229920502 [[.under],[.under]] .three = true := by decide
def e151229920878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e151229920878 : Closed e151229920878 ∧ code e151229920878 = 2350253176430 := by decide
theorem cert_e151229920878 : check e151229920878 [[.under],[.under]] .three = true := by decide
def e151229920890 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e151229920890 : Closed e151229920890 ∧ code e151229920890 = 2350253176442 := by decide
theorem cert_e151229920890 : check e151229920890 [[.under],[.under]] .three = true := by decide
def e151229921078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e151229921078 : Closed e151229921078 ∧ code e151229921078 = 2350253176630 := by decide
theorem cert_e151229921078 : check e151229921078 [[.under],[.under]] .three = true := by decide
def e151229921082 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e151229921082 : Closed e151229921082 ∧ code e151229921082 = 2350253176634 := by decide
theorem cert_e151229921082 : check e151229921082 [[.under],[.under]] .three = true := by decide
def e151229921718 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e151229921718 : Closed e151229921718 ∧ code e151229921718 = 2350253177270 := by decide
theorem cert_e151229921718 : check e151229921718 [[.under],[.under]] .three = true := by decide
def e151229921750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e151229921750 : Closed e151229921750 ∧ code e151229921750 = 2350253177302 := by decide
theorem cert_e151229921750 : check e151229921750 [[.under],[.under]] .three = true := by decide
def e151229921754 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e151229921754 : Closed e151229921754 ∧ code e151229921754 = 2350253177306 := by decide
theorem cert_e151229921754 : check e151229921754 [[.under],[.under]] .three = true := by decide
def e151229921910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e151229921910 : Closed e151229921910 ∧ code e151229921910 = 2350253177462 := by decide
theorem cert_e151229921910 : check e151229921910 [[.under],[.under]] .three = true := by decide
def e151229922102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e151229922102 : Closed e151229922102 ∧ code e151229922102 = 2350253177654 := by decide
theorem cert_e151229922102 : check e151229922102 [[.under],[.under]] .three = true := by decide
def e151229922106 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e151229922106 : Closed e151229922106 ∧ code e151229922106 = 2350253177658 := by decide
theorem cert_e151229922106 : check e151229922106 [[.under],[.under]] .three = true := by decide
def e151229929326 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e151229929326 : Closed e151229929326 ∧ code e151229929326 = 2350253184878 := by decide
theorem cert_e151229929326 : check e151229929326 [[.under],[.under]] .three = true := by decide
def e151229929334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e151229929334 : Closed e151229929334 ∧ code e151229929334 = 2350253184886 := by decide
theorem cert_e151229929334 : check e151229929334 [[.under],[.under]] .three = true := by decide
def e151229929398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e151229929398 : Closed e151229929398 ∧ code e151229929398 = 2350253184950 := by decide
theorem cert_e151229929398 : check e151229929398 [[.under],[.under]] .three = true := by decide
def e151229930734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e151229930734 : Closed e151229930734 ∧ code e151229930734 = 2350253186286 := by decide
theorem cert_e151229930734 : check e151229930734 [[.under],[.under]] .three = true := by decide
def e151229930742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e151229930742 : Closed e151229930742 ∧ code e151229930742 = 2350253186294 := by decide
theorem cert_e151229930742 : check e151229930742 [[.under],[.under]] .three = true := by decide
def e151229931126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e151229931126 : Closed e151229931126 ∧ code e151229931126 = 2350253186678 := by decide
theorem cert_e151229931126 : check e151229931126 [[.under],[.under]] .three = true := by decide
def e151229942638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e151229942638 : Closed e151229942638 ∧ code e151229942638 = 2350253198190 := by decide
theorem cert_e151229942638 : check e151229942638 [[.under],[.under]] .three = true := by decide
def e151229942646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e151229942646 : Closed e151229942646 ∧ code e151229942646 = 2350253198198 := by decide
theorem cert_e151229942646 : check e151229942646 [[.under],[.under]] .three = true := by decide
def e151229942702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e151229942702 : Closed e151229942702 ∧ code e151229942702 = 2350253198254 := by decide
theorem cert_e151229942702 : check e151229942702 [[.under],[.under]] .three = true := by decide
def e151229942714 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e151229942714 : Closed e151229942714 ∧ code e151229942714 = 2350253198266 := by decide
theorem cert_e151229942714 : check e151229942714 [[.under],[.under]] .three = true := by decide
def e151229942742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e151229942742 : Closed e151229942742 ∧ code e151229942742 = 2350253198294 := by decide
theorem cert_e151229942742 : check e151229942742 [[.under],[.under]] .three = true := by decide
def e151229942746 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e151229942746 : Closed e151229942746 ∧ code e151229942746 = 2350253198298 := by decide
theorem cert_e151229942746 : check e151229942746 [[.under],[.under]] .three = true := by decide
def e151229943022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e151229943022 : Closed e151229943022 ∧ code e151229943022 = 2350253198574 := by decide
theorem cert_e151229943022 : check e151229943022 [[.under],[.under]] .three = true := by decide
def e151229943030 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e151229943030 : Closed e151229943030 ∧ code e151229943030 = 2350253198582 := by decide
theorem cert_e151229943030 : check e151229943030 [[.under],[.under]] .three = true := by decide
def e151229943406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e151229943406 : Closed e151229943406 ∧ code e151229943406 = 2350253198958 := by decide
theorem cert_e151229943406 : check e151229943406 [[.under],[.under]] .three = true := by decide
def e151229943418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e151229943418 : Closed e151229943418 ∧ code e151229943418 = 2350253198970 := by decide
theorem cert_e151229943418 : check e151229943418 [[.under],[.under]] .three = true := by decide
def e151229943606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e151229943606 : Closed e151229943606 ∧ code e151229943606 = 2350253199158 := by decide
theorem cert_e151229943606 : check e151229943606 [[.under],[.under]] .three = true := by decide
def e151229943610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e151229943610 : Closed e151229943610 ∧ code e151229943610 = 2350253199162 := by decide
theorem cert_e151229943610 : check e151229943610 [[.under],[.under]] .three = true := by decide
def e151229949366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e151229949366 : Closed e151229949366 ∧ code e151229949366 = 2350253204918 := by decide
theorem cert_e151229949366 : check e151229949366 [[.under],[.under]] .three = true := by decide
def e151229949398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e151229949398 : Closed e151229949398 ∧ code e151229949398 = 2350253204950 := by decide
theorem cert_e151229949398 : check e151229949398 [[.under],[.under]] .three = true := by decide
def e151229949402 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e151229949402 : Closed e151229949402 ∧ code e151229949402 = 2350253204954 := by decide
theorem cert_e151229949402 : check e151229949402 [[.under],[.under]] .three = true := by decide
def e151229949558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e151229949558 : Closed e151229949558 ∧ code e151229949558 = 2350253205110 := by decide
theorem cert_e151229949558 : check e151229949558 [[.under],[.under]] .three = true := by decide
def e151229949750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e151229949750 : Closed e151229949750 ∧ code e151229949750 = 2350253205302 := by decide
theorem cert_e151229949750 : check e151229949750 [[.under],[.under]] .three = true := by decide
def e151229949754 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e151229949754 : Closed e151229949754 ∧ code e151229949754 = 2350253205306 := by decide
theorem cert_e151229949754 : check e151229949754 [[.under],[.under]] .three = true := by decide
def e151230286702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e151230286702 : Closed e151230286702 ∧ code e151230286702 = 2350253542254 := by decide
theorem cert_e151230286702 : check e151230286702 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230286710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e151230286710 : Closed e151230286710 ∧ code e151230286710 = 2350253542262 := by decide
theorem cert_e151230286710 : check e151230286710 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230286766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e151230286766 : Closed e151230286766 ∧ code e151230286766 = 2350253542318 := by decide
theorem cert_e151230286766 : check e151230286766 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230286778 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e151230286778 : Closed e151230286778 ∧ code e151230286778 = 2350253542330 := by decide
theorem cert_e151230286778 : check e151230286778 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230286806 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e151230286806 : Closed e151230286806 ∧ code e151230286806 = 2350253542358 := by decide
theorem cert_e151230286806 : check e151230286806 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230286810 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e151230286810 : Closed e151230286810 ∧ code e151230286810 = 2350253542362 := by decide
theorem cert_e151230286810 : check e151230286810 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230287086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e151230287086 : Closed e151230287086 ∧ code e151230287086 = 2350253542638 := by decide
theorem cert_e151230287086 : check e151230287086 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230287094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e151230287094 : Closed e151230287094 ∧ code e151230287094 = 2350253542646 := by decide
theorem cert_e151230287094 : check e151230287094 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230287470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e151230287470 : Closed e151230287470 ∧ code e151230287470 = 2350253543022 := by decide
theorem cert_e151230287470 : check e151230287470 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230287482 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e151230287482 : Closed e151230287482 ∧ code e151230287482 = 2350253543034 := by decide
theorem cert_e151230287482 : check e151230287482 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230287670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e151230287670 : Closed e151230287670 ∧ code e151230287670 = 2350253543222 := by decide
theorem cert_e151230287670 : check e151230287670 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151230287674 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e151230287674 : Closed e151230287674 ∧ code e151230287674 = 2350253543226 := by decide
theorem cert_e151230287674 : check e151230287674 [[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e151297022830 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e151297022830 : Closed e151297022830 ∧ code e151297022830 = 2350320278382 := by decide
theorem cert_e151297022830 : check e151297022830 [[.under],[.under]] .three = true := by decide
def e151297022838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e151297022838 : Closed e151297022838 ∧ code e151297022838 = 2350320278390 := by decide
theorem cert_e151297022838 : check e151297022838 [[.under],[.under]] .three = true := by decide
def e151297022902 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e151297022902 : Closed e151297022902 ∧ code e151297022902 = 2350320278454 := by decide
theorem cert_e151297022902 : check e151297022902 [[.under],[.under]] .three = true := by decide
def e151297023342 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e151297023342 : Closed e151297023342 ∧ code e151297023342 = 2350320278894 := by decide
theorem cert_e151297023342 : check e151297023342 [[.under],[.under]] .three = true := by decide
def e151297023350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e151297023350 : Closed e151297023350 ∧ code e151297023350 = 2350320278902 := by decide
theorem cert_e151297023350 : check e151297023350 [[.under],[.under]] .three = true := by decide
def e151297023406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e151297023406 : Closed e151297023406 ∧ code e151297023406 = 2350320278958 := by decide
theorem cert_e151297023406 : check e151297023406 [[.under],[.under]] .three = true := by decide
def e151297023418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e151297023418 : Closed e151297023418 ∧ code e151297023418 = 2350320278970 := by decide
theorem cert_e151297023418 : check e151297023418 [[.under],[.under]] .three = true := by decide
def e151297023446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e151297023446 : Closed e151297023446 ∧ code e151297023446 = 2350320278998 := by decide
theorem cert_e151297023446 : check e151297023446 [[.under],[.under]] .three = true := by decide
def e151297023450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e151297023450 : Closed e151297023450 ∧ code e151297023450 = 2350320279002 := by decide
theorem cert_e151297023450 : check e151297023450 [[.under],[.under]] .three = true := by decide
def e151297023670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e151297023670 : Closed e151297023670 ∧ code e151297023670 = 2350320279222 := by decide
theorem cert_e151297023670 : check e151297023670 [[.under],[.under]] .three = true := by decide
def e151297023702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e151297023702 : Closed e151297023702 ∧ code e151297023702 = 2350320279254 := by decide
theorem cert_e151297023702 : check e151297023702 [[.under],[.under]] .three = true := by decide
def e151297023706 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e151297023706 : Closed e151297023706 ∧ code e151297023706 = 2350320279258 := by decide
theorem cert_e151297023706 : check e151297023706 [[.under],[.under]] .three = true := by decide
def e151297025902 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e151297025902 : Closed e151297025902 ∧ code e151297025902 = 2350320281454 := by decide
theorem cert_e151297025902 : check e151297025902 [[.under],[.under]] .three = true := by decide
def e151297025910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e151297025910 : Closed e151297025910 ∧ code e151297025910 = 2350320281462 := by decide
theorem cert_e151297025910 : check e151297025910 [[.under],[.under]] .three = true := by decide
def e151297025974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e151297025974 : Closed e151297025974 ∧ code e151297025974 = 2350320281526 := by decide
theorem cert_e151297025974 : check e151297025974 [[.under],[.under]] .three = true := by decide
def e151297027310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e151297027310 : Closed e151297027310 ∧ code e151297027310 = 2350320282862 := by decide
theorem cert_e151297027310 : check e151297027310 [[.under],[.under]] .three = true := by decide
def e151297027318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e151297027318 : Closed e151297027318 ∧ code e151297027318 = 2350320282870 := by decide
theorem cert_e151297027318 : check e151297027318 [[.under],[.under]] .three = true := by decide
def e151297027702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e151297027702 : Closed e151297027702 ∧ code e151297027702 = 2350320283254 := by decide
theorem cert_e151297027702 : check e151297027702 [[.under],[.under]] .three = true := by decide
def e151297028974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e151297028974 : Closed e151297028974 ∧ code e151297028974 = 2350320284526 := by decide
theorem cert_e151297028974 : check e151297028974 [[.under],[.under]] .three = true := by decide
def e151297028982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e151297028982 : Closed e151297028982 ∧ code e151297028982 = 2350320284534 := by decide
theorem cert_e151297028982 : check e151297028982 [[.under],[.under]] .three = true := by decide
def e151297029038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e151297029038 : Closed e151297029038 ∧ code e151297029038 = 2350320284590 := by decide
theorem cert_e151297029038 : check e151297029038 [[.under],[.under]] .three = true := by decide
def e151297029050 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e151297029050 : Closed e151297029050 ∧ code e151297029050 = 2350320284602 := by decide
theorem cert_e151297029050 : check e151297029050 [[.under],[.under]] .three = true := by decide
def e151297029078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e151297029078 : Closed e151297029078 ∧ code e151297029078 = 2350320284630 := by decide
theorem cert_e151297029078 : check e151297029078 [[.under],[.under]] .three = true := by decide
def e151297029082 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e151297029082 : Closed e151297029082 ∧ code e151297029082 = 2350320284634 := by decide
theorem cert_e151297029082 : check e151297029082 [[.under],[.under]] .three = true := by decide
def e151297029358 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e151297029358 : Closed e151297029358 ∧ code e151297029358 = 2350320284910 := by decide
theorem cert_e151297029358 : check e151297029358 [[.under],[.under]] .three = true := by decide
def e151297029366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e151297029366 : Closed e151297029366 ∧ code e151297029366 = 2350320284918 := by decide
theorem cert_e151297029366 : check e151297029366 [[.under],[.under]] .three = true := by decide
def e151297029742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e151297029742 : Closed e151297029742 ∧ code e151297029742 = 2350320285294 := by decide
theorem cert_e151297029742 : check e151297029742 [[.under],[.under]] .three = true := by decide
def e151297029754 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e151297029754 : Closed e151297029754 ∧ code e151297029754 = 2350320285306 := by decide
theorem cert_e151297029754 : check e151297029754 [[.under],[.under]] .three = true := by decide
def e151297029942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e151297029942 : Closed e151297029942 ∧ code e151297029942 = 2350320285494 := by decide
theorem cert_e151297029942 : check e151297029942 [[.under],[.under]] .three = true := by decide
def e151297029946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e151297029946 : Closed e151297029946 ∧ code e151297029946 = 2350320285498 := by decide
theorem cert_e151297029946 : check e151297029946 [[.under],[.under]] .three = true := by decide
def e151297030582 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e151297030582 : Closed e151297030582 ∧ code e151297030582 = 2350320286134 := by decide
theorem cert_e151297030582 : check e151297030582 [[.under],[.under]] .three = true := by decide
def e151297030614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e151297030614 : Closed e151297030614 ∧ code e151297030614 = 2350320286166 := by decide
theorem cert_e151297030614 : check e151297030614 [[.under],[.under]] .three = true := by decide
def e151297030618 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e151297030618 : Closed e151297030618 ∧ code e151297030618 = 2350320286170 := by decide
theorem cert_e151297030618 : check e151297030618 [[.under],[.under]] .three = true := by decide
def e151297030774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e151297030774 : Closed e151297030774 ∧ code e151297030774 = 2350320286326 := by decide
theorem cert_e151297030774 : check e151297030774 [[.under],[.under]] .three = true := by decide
def e151297030966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e151297030966 : Closed e151297030966 ∧ code e151297030966 = 2350320286518 := by decide
theorem cert_e151297030966 : check e151297030966 [[.under],[.under]] .three = true := by decide
def e151297030970 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e151297030970 : Closed e151297030970 ∧ code e151297030970 = 2350320286522 := by decide
theorem cert_e151297030970 : check e151297030970 [[.under],[.under]] .three = true := by decide
def e151297038190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e151297038190 : Closed e151297038190 ∧ code e151297038190 = 2350320293742 := by decide
theorem cert_e151297038190 : check e151297038190 [[.under],[.under]] .three = true := by decide
def e151297038198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e151297038198 : Closed e151297038198 ∧ code e151297038198 = 2350320293750 := by decide
theorem cert_e151297038198 : check e151297038198 [[.under],[.under]] .three = true := by decide
def e151297038262 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e151297038262 : Closed e151297038262 ∧ code e151297038262 = 2350320293814 := by decide
theorem cert_e151297038262 : check e151297038262 [[.under],[.under]] .three = true := by decide
def e151297039598 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e151297039598 : Closed e151297039598 ∧ code e151297039598 = 2350320295150 := by decide
theorem cert_e151297039598 : check e151297039598 [[.under],[.under]] .three = true := by decide
def e151297039606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e151297039606 : Closed e151297039606 ∧ code e151297039606 = 2350320295158 := by decide
theorem cert_e151297039606 : check e151297039606 [[.under],[.under]] .three = true := by decide
def e151297039990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e151297039990 : Closed e151297039990 ∧ code e151297039990 = 2350320295542 := by decide
theorem cert_e151297039990 : check e151297039990 [[.under],[.under]] .three = true := by decide
def e151297051502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e151297051502 : Closed e151297051502 ∧ code e151297051502 = 2350320307054 := by decide
theorem cert_e151297051502 : check e151297051502 [[.under],[.under]] .three = true := by decide
def e151297051510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e151297051510 : Closed e151297051510 ∧ code e151297051510 = 2350320307062 := by decide
theorem cert_e151297051510 : check e151297051510 [[.under],[.under]] .three = true := by decide
def e151297051566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e151297051566 : Closed e151297051566 ∧ code e151297051566 = 2350320307118 := by decide
theorem cert_e151297051566 : check e151297051566 [[.under],[.under]] .three = true := by decide
def e151297051578 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e151297051578 : Closed e151297051578 ∧ code e151297051578 = 2350320307130 := by decide
theorem cert_e151297051578 : check e151297051578 [[.under],[.under]] .three = true := by decide
def e151297051606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e151297051606 : Closed e151297051606 ∧ code e151297051606 = 2350320307158 := by decide
theorem cert_e151297051606 : check e151297051606 [[.under],[.under]] .three = true := by decide
def e151297051610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e151297051610 : Closed e151297051610 ∧ code e151297051610 = 2350320307162 := by decide
theorem cert_e151297051610 : check e151297051610 [[.under],[.under]] .three = true := by decide
end Blc.Floor41
