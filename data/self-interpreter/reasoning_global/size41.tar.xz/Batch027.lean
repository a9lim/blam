import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565594241270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e565594241270 : Closed e565594241270 ∧ code e565594241270 = 2764617496822 := by decide
theorem cert_e565594241270 : check e565594241270 [[],[.under]] .three = true := by decide
def e565594241454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e565594241454 : Closed e565594241454 ∧ code e565594241454 = 2764617497006 := by decide
theorem cert_e565594241454 : check e565594241454 [[],[.under]] .three = true := by decide
def e565594241466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e565594241466 : Closed e565594241466 ∧ code e565594241466 = 2764617497018 := by decide
theorem cert_e565594241466 : check e565594241466 [[],[.under]] .three = true := by decide
def e565594241514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e565594241514 : Closed e565594241514 ∧ code e565594241514 = 2764617497066 := by decide
theorem cert_e565594241514 : check e565594241514 [[],[.under]] .three = true := by decide
def e565594241646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e565594241646 : Closed e565594241646 ∧ code e565594241646 = 2764617497198 := by decide
theorem cert_e565594241646 : check e565594241646 [[],[.under]] .three = true := by decide
def e565594241658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e565594241658 : Closed e565594241658 ∧ code e565594241658 = 2764617497210 := by decide
theorem cert_e565594241658 : check e565594241658 [[],[.under]] .three = true := by decide
def e565594241822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e565594241822 : Closed e565594241822 ∧ code e565594241822 = 2764617497374 := by decide
theorem cert_e565594241822 : check e565594241822 [[],[.under]] .three = true := by decide
def e565594241934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e565594241934 : Closed e565594241934 ∧ code e565594241934 = 2764617497486 := by decide
theorem cert_e565594241934 : check e565594241934 [[],[.under]] .three = true := by decide
def e565594241946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e565594241946 : Closed e565594241946 ∧ code e565594241946 = 2764617497498 := by decide
theorem cert_e565594241946 : check e565594241946 [[],[.under]] .three = true := by decide
def e565594242166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e565594242166 : Closed e565594242166 ∧ code e565594242166 = 2764617497718 := by decide
theorem cert_e565594242166 : check e565594242166 [[],[.under]] .three = true := by decide
def e565594242262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e565594242262 : Closed e565594242262 ∧ code e565594242262 = 2764617497814 := by decide
theorem cert_e565594242262 : check e565594242262 [[],[.under]] .three = true := by decide
def e565594242266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e565594242266 : Closed e565594242266 ∧ code e565594242266 = 2764617497818 := by decide
theorem cert_e565594242266 : check e565594242266 [[],[.under]] .three = true := by decide
def e565594242282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e565594242282 : Closed e565594242282 ∧ code e565594242282 = 2764617497834 := by decide
theorem cert_e565594242282 : check e565594242282 [[],[.under]] .three = true := by decide
def e565594242358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e565594242358 : Closed e565594242358 ∧ code e565594242358 = 2764617497910 := by decide
theorem cert_e565594242358 : check e565594242358 [[],[.under]] .three = true := by decide
def e565594242362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e565594242362 : Closed e565594242362 ∧ code e565594242362 = 2764617497914 := by decide
theorem cert_e565594242362 : check e565594242362 [[],[.under]] .three = true := by decide
def e565594242446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e565594242446 : Closed e565594242446 ∧ code e565594242446 = 2764617497998 := by decide
theorem cert_e565594242446 : check e565594242446 [[],[.under]] .three = true := by decide
def e565594242458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e565594242458 : Closed e565594242458 ∧ code e565594242458 = 2764617498010 := by decide
theorem cert_e565594242458 : check e565594242458 [[],[.under]] .three = true := by decide
def e565594244062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e565594244062 : Closed e565594244062 ∧ code e565594244062 = 2764617499614 := by decide
theorem cert_e565594244062 : check e565594244062 [[],[.under]] .three = true := by decide
def e565594244078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e565594244078 : Closed e565594244078 ∧ code e565594244078 = 2764617499630 := by decide
theorem cert_e565594244078 : check e565594244078 [[],[.under]] .three = true := by decide
def e565594245998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565594245998 : Closed e565594245998 ∧ code e565594245998 = 2764617501550 := by decide
theorem cert_e565594245998 : check e565594245998 [[],[.under]] .three = true := by decide
def e565594246006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565594246006 : Closed e565594246006 ∧ code e565594246006 = 2764617501558 := by decide
theorem cert_e565594246006 : check e565594246006 [[],[.under]] .three = true := by decide
def e565594246062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565594246062 : Closed e565594246062 ∧ code e565594246062 = 2764617501614 := by decide
theorem cert_e565594246062 : check e565594246062 [[],[.under]] .three = true := by decide
def e565594246074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565594246074 : Closed e565594246074 ∧ code e565594246074 = 2764617501626 := by decide
theorem cert_e565594246074 : check e565594246074 [[],[.under]] .three = true := by decide
def e565594246102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565594246102 : Closed e565594246102 ∧ code e565594246102 = 2764617501654 := by decide
theorem cert_e565594246102 : check e565594246102 [[],[.under]] .three = true := by decide
def e565594246106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565594246106 : Closed e565594246106 ∧ code e565594246106 = 2764617501658 := by decide
theorem cert_e565594246106 : check e565594246106 [[],[.under]] .three = true := by decide
def e565594246382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565594246382 : Closed e565594246382 ∧ code e565594246382 = 2764617501934 := by decide
theorem cert_e565594246382 : check e565594246382 [[],[.under]] .three = true := by decide
def e565594246390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565594246390 : Closed e565594246390 ∧ code e565594246390 = 2764617501942 := by decide
theorem cert_e565594246390 : check e565594246390 [[],[.under]] .three = true := by decide
def e565594246766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565594246766 : Closed e565594246766 ∧ code e565594246766 = 2764617502318 := by decide
theorem cert_e565594246766 : check e565594246766 [[],[.under]] .three = true := by decide
def e565594246778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565594246778 : Closed e565594246778 ∧ code e565594246778 = 2764617502330 := by decide
theorem cert_e565594246778 : check e565594246778 [[],[.under]] .three = true := by decide
def e565594246966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565594246966 : Closed e565594246966 ∧ code e565594246966 = 2764617502518 := by decide
theorem cert_e565594246966 : check e565594246966 [[],[.under]] .three = true := by decide
def e565594246970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565594246970 : Closed e565594246970 ∧ code e565594246970 = 2764617502522 := by decide
theorem cert_e565594246970 : check e565594246970 [[],[.under]] .three = true := by decide
def e565594251742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e565594251742 : Closed e565594251742 ∧ code e565594251742 = 2764617507294 := by decide
theorem cert_e565594251742 : check e565594251742 [[],[.under]] .three = true := by decide
def e565594251766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e565594251766 : Closed e565594251766 ∧ code e565594251766 = 2764617507318 := by decide
theorem cert_e565594251766 : check e565594251766 [[],[.under]] .three = true := by decide
def e565594252718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e565594252718 : Closed e565594252718 ∧ code e565594252718 = 2764617508270 := by decide
theorem cert_e565594252718 : check e565594252718 [[],[.under]] .three = true := by decide
def e565594252730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e565594252730 : Closed e565594252730 ∧ code e565594252730 = 2764617508282 := by decide
theorem cert_e565594252730 : check e565594252730 [[],[.under]] .three = true := by decide
def e565594252778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e565594252778 : Closed e565594252778 ∧ code e565594252778 = 2764617508330 := by decide
theorem cert_e565594252778 : check e565594252778 [[],[.under]] .three = true := by decide
def e565594252910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e565594252910 : Closed e565594252910 ∧ code e565594252910 = 2764617508462 := by decide
theorem cert_e565594252910 : check e565594252910 [[],[.under]] .three = true := by decide
def e565594252922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e565594252922 : Closed e565594252922 ∧ code e565594252922 = 2764617508474 := by decide
theorem cert_e565594252922 : check e565594252922 [[],[.under]] .three = true := by decide
def e565594253086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e565594253086 : Closed e565594253086 ∧ code e565594253086 = 2764617508638 := by decide
theorem cert_e565594253086 : check e565594253086 [[],[.under]] .three = true := by decide
def e565594253198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e565594253198 : Closed e565594253198 ∧ code e565594253198 = 2764617508750 := by decide
theorem cert_e565594253198 : check e565594253198 [[],[.under]] .three = true := by decide
def e565594253210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e565594253210 : Closed e565594253210 ∧ code e565594253210 = 2764617508762 := by decide
theorem cert_e565594253210 : check e565594253210 [[],[.under]] .three = true := by decide
def e565594255598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e565594255598 : Closed e565594255598 ∧ code e565594255598 = 2764617511150 := by decide
theorem cert_e565594255598 : check e565594255598 [[],[.under]] .three = true := by decide
def e565594255606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e565594255606 : Closed e565594255606 ∧ code e565594255606 = 2764617511158 := by decide
theorem cert_e565594255606 : check e565594255606 [[],[.under]] .three = true := by decide
def e565594256086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e565594256086 : Closed e565594256086 ∧ code e565594256086 = 2764617511638 := by decide
theorem cert_e565594256086 : check e565594256086 [[],[.under]] .three = true := by decide
def e565594256090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e565594256090 : Closed e565594256090 ∧ code e565594256090 = 2764617511642 := by decide
theorem cert_e565594256090 : check e565594256090 [[],[.under]] .three = true := by decide
def e565594256106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e565594256106 : Closed e565594256106 ∧ code e565594256106 = 2764617511658 := by decide
theorem cert_e565594256106 : check e565594256106 [[],[.under]] .three = true := by decide
def e565594256182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e565594256182 : Closed e565594256182 ∧ code e565594256182 = 2764617511734 := by decide
theorem cert_e565594256182 : check e565594256182 [[],[.under]] .three = true := by decide
def e565594256186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e565594256186 : Closed e565594256186 ∧ code e565594256186 = 2764617511738 := by decide
theorem cert_e565594256186 : check e565594256186 [[],[.under]] .three = true := by decide
def e565594256270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e565594256270 : Closed e565594256270 ∧ code e565594256270 = 2764617511822 := by decide
theorem cert_e565594256270 : check e565594256270 [[],[.under]] .three = true := by decide
def e565594256282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e565594256282 : Closed e565594256282 ∧ code e565594256282 = 2764617511834 := by decide
theorem cert_e565594256282 : check e565594256282 [[],[.under]] .three = true := by decide
def e565594261358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e565594261358 : Closed e565594261358 ∧ code e565594261358 = 2764617516910 := by decide
theorem cert_e565594261358 : check e565594261358 [[],[.under]] .three = true := by decide
def e565594261370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e565594261370 : Closed e565594261370 ∧ code e565594261370 = 2764617516922 := by decide
theorem cert_e565594261370 : check e565594261370 [[],[.under]] .three = true := by decide
def e565594261466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e565594261466 : Closed e565594261466 ∧ code e565594261466 = 2764617517018 := by decide
theorem cert_e565594261466 : check e565594261466 [[],[.under]] .three = true := by decide
def e565594262766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e565594262766 : Closed e565594262766 ∧ code e565594262766 = 2764617518318 := by decide
theorem cert_e565594262766 : check e565594262766 [[],[.under]] .three = true := by decide
def e565594262774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e565594262774 : Closed e565594262774 ∧ code e565594262774 = 2764617518326 := by decide
theorem cert_e565594262774 : check e565594262774 [[],[.under]] .three = true := by decide
def e565594263150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e565594263150 : Closed e565594263150 ∧ code e565594263150 = 2764617518702 := by decide
theorem cert_e565594263150 : check e565594263150 [[],[.under]] .three = true := by decide
def e565594263162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e565594263162 : Closed e565594263162 ∧ code e565594263162 = 2764617518714 := by decide
theorem cert_e565594263162 : check e565594263162 [[],[.under]] .three = true := by decide
def e565594263350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e565594263350 : Closed e565594263350 ∧ code e565594263350 = 2764617518902 := by decide
theorem cert_e565594263350 : check e565594263350 [[],[.under]] .three = true := by decide
def e565594263354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e565594263354 : Closed e565594263354 ∧ code e565594263354 = 2764617518906 := by decide
theorem cert_e565594263354 : check e565594263354 [[],[.under]] .three = true := by decide
def e565594265262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e565594265262 : Closed e565594265262 ∧ code e565594265262 = 2764617520814 := by decide
theorem cert_e565594265262 : check e565594265262 [[],[.under]] .three = true := by decide
def e565594265274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e565594265274 : Closed e565594265274 ∧ code e565594265274 = 2764617520826 := by decide
theorem cert_e565594265274 : check e565594265274 [[],[.under]] .three = true := by decide
def e565594265322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e565594265322 : Closed e565594265322 ∧ code e565594265322 = 2764617520874 := by decide
theorem cert_e565594265322 : check e565594265322 [[],[.under]] .three = true := by decide
def e565594265514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e565594265514 : Closed e565594265514 ∧ code e565594265514 = 2764617521066 := by decide
theorem cert_e565594265514 : check e565594265514 [[],[.under]] .three = true := by decide
def e565594265838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e565594265838 : Closed e565594265838 ∧ code e565594265838 = 2764617521390 := by decide
theorem cert_e565594265838 : check e565594265838 [[],[.under]] .three = true := by decide
def e565594265846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e565594265846 : Closed e565594265846 ∧ code e565594265846 = 2764617521398 := by decide
theorem cert_e565594265846 : check e565594265846 [[],[.under]] .three = true := by decide
def e565594266030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e565594266030 : Closed e565594266030 ∧ code e565594266030 = 2764617521582 := by decide
theorem cert_e565594266030 : check e565594266030 [[],[.under]] .three = true := by decide
def e565594266042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e565594266042 : Closed e565594266042 ∧ code e565594266042 = 2764617521594 := by decide
theorem cert_e565594266042 : check e565594266042 [[],[.under]] .three = true := by decide
def e565594266090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e565594266090 : Closed e565594266090 ∧ code e565594266090 = 2764617521642 := by decide
theorem cert_e565594266090 : check e565594266090 [[],[.under]] .three = true := by decide
def e565594266222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e565594266222 : Closed e565594266222 ∧ code e565594266222 = 2764617521774 := by decide
theorem cert_e565594266222 : check e565594266222 [[],[.under]] .three = true := by decide
def e565594266234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e565594266234 : Closed e565594266234 ∧ code e565594266234 = 2764617521786 := by decide
theorem cert_e565594266234 : check e565594266234 [[],[.under]] .three = true := by decide
def e565594266398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e565594266398 : Closed e565594266398 ∧ code e565594266398 = 2764617521950 := by decide
theorem cert_e565594266398 : check e565594266398 [[],[.under]] .three = true := by decide
def e565594266510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e565594266510 : Closed e565594266510 ∧ code e565594266510 = 2764617522062 := by decide
theorem cert_e565594266510 : check e565594266510 [[],[.under]] .three = true := by decide
def e565594266522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e565594266522 : Closed e565594266522 ∧ code e565594266522 = 2764617522074 := by decide
theorem cert_e565594266522 : check e565594266522 [[],[.under]] .three = true := by decide
def e565594266734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e565594266734 : Closed e565594266734 ∧ code e565594266734 = 2764617522286 := by decide
theorem cert_e565594266734 : check e565594266734 [[],[.under]] .three = true := by decide
def e565594266746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e565594266746 : Closed e565594266746 ∧ code e565594266746 = 2764617522298 := by decide
theorem cert_e565594266746 : check e565594266746 [[],[.under]] .three = true := by decide
def e565594266910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e565594266910 : Closed e565594266910 ∧ code e565594266910 = 2764617522462 := by decide
theorem cert_e565594266910 : check e565594266910 [[],[.under]] .three = true := by decide
def e565594267078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e565594267078 : Closed e565594267078 ∧ code e565594267078 = 2764617522630 := by decide
theorem cert_e565594267078 : check e565594267078 [[],[.under]] .three = true := by decide
def e565594267190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e565594267190 : Closed e565594267190 ∧ code e565594267190 = 2764617522742 := by decide
theorem cert_e565594267190 : check e565594267190 [[],[.under]] .three = true := by decide
def e565594267194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e565594267194 : Closed e565594267194 ∧ code e565594267194 = 2764617522746 := by decide
theorem cert_e565594267194 : check e565594267194 [[],[.under]] .three = true := by decide
def e565594267242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e565594267242 : Closed e565594267242 ∧ code e565594267242 = 2764617522794 := by decide
theorem cert_e565594267242 : check e565594267242 [[],[.under]] .three = true := by decide
def e565594267278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e565594267278 : Closed e565594267278 ∧ code e565594267278 = 2764617522830 := by decide
theorem cert_e565594267278 : check e565594267278 [[],[.under]] .three = true := by decide
def e565594267290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e565594267290 : Closed e565594267290 ∧ code e565594267290 = 2764617522842 := by decide
theorem cert_e565594267290 : check e565594267290 [[],[.under]] .three = true := by decide
def e565594267334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e565594267334 : Closed e565594267334 ∧ code e565594267334 = 2764617522886 := by decide
theorem cert_e565594267334 : check e565594267334 [[],[.under]] .three = true := by decide
def e565594268126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e565594268126 : Closed e565594268126 ∧ code e565594268126 = 2764617523678 := by decide
theorem cert_e565594268126 : check e565594268126 [[],[.under]] .three = true := by decide
def e565594268150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e565594268150 : Closed e565594268150 ∧ code e565594268150 = 2764617523702 := by decide
theorem cert_e565594268150 : check e565594268150 [[],[.under]] .three = true := by decide
def e565594269102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e565594269102 : Closed e565594269102 ∧ code e565594269102 = 2764617524654 := by decide
theorem cert_e565594269102 : check e565594269102 [[],[.under]] .three = true := by decide
def e565594269114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e565594269114 : Closed e565594269114 ∧ code e565594269114 = 2764617524666 := by decide
theorem cert_e565594269114 : check e565594269114 [[],[.under]] .three = true := by decide
def e565594269162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e565594269162 : Closed e565594269162 ∧ code e565594269162 = 2764617524714 := by decide
theorem cert_e565594269162 : check e565594269162 [[],[.under]] .three = true := by decide
def e565594269294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e565594269294 : Closed e565594269294 ∧ code e565594269294 = 2764617524846 := by decide
theorem cert_e565594269294 : check e565594269294 [[],[.under]] .three = true := by decide
def e565594269306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e565594269306 : Closed e565594269306 ∧ code e565594269306 = 2764617524858 := by decide
theorem cert_e565594269306 : check e565594269306 [[],[.under]] .three = true := by decide
def e565594269470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e565594269470 : Closed e565594269470 ∧ code e565594269470 = 2764617525022 := by decide
theorem cert_e565594269470 : check e565594269470 [[],[.under]] .three = true := by decide
def e565594269582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e565594269582 : Closed e565594269582 ∧ code e565594269582 = 2764617525134 := by decide
theorem cert_e565594269582 : check e565594269582 [[],[.under]] .three = true := by decide
def e565594269594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e565594269594 : Closed e565594269594 ∧ code e565594269594 = 2764617525146 := by decide
theorem cert_e565594269594 : check e565594269594 [[],[.under]] .three = true := by decide
def e565594272542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e565594272542 : Closed e565594272542 ∧ code e565594272542 = 2764617528094 := by decide
theorem cert_e565594272542 : check e565594272542 [[],[.under]] .three = true := by decide
def e565594272710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e565594272710 : Closed e565594272710 ∧ code e565594272710 = 2764617528262 := by decide
theorem cert_e565594272710 : check e565594272710 [[],[.under]] .three = true := by decide
def e565594273910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e565594273910 : Closed e565594273910 ∧ code e565594273910 = 2764617529462 := by decide
theorem cert_e565594273910 : check e565594273910 [[],[.under]] .three = true := by decide
def e565594274154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e565594274154 : Closed e565594274154 ∧ code e565594274154 = 2764617529706 := by decide
theorem cert_e565594274154 : check e565594274154 [[],[.under]] .three = true := by decide
def e565594274190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e565594274190 : Closed e565594274190 ∧ code e565594274190 = 2764617529742 := by decide
theorem cert_e565594274190 : check e565594274190 [[],[.under]] .three = true := by decide
def e565594274202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e565594274202 : Closed e565594274202 ∧ code e565594274202 = 2764617529754 := by decide
theorem cert_e565594274202 : check e565594274202 [[],[.under]] .three = true := by decide
def e565594274246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e565594274246 : Closed e565594274246 ∧ code e565594274246 = 2764617529798 := by decide
theorem cert_e565594274246 : check e565594274246 [[],[.under]] .three = true := by decide
def e565594276790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e565594276790 : Closed e565594276790 ∧ code e565594276790 = 2764617532342 := by decide
theorem cert_e565594276790 : check e565594276790 [[],[.under]] .three = true := by decide
def e565594276794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e565594276794 : Closed e565594276794 ∧ code e565594276794 = 2764617532346 := by decide
theorem cert_e565594276794 : check e565594276794 [[],[.under]] .three = true := by decide
def e565594276826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e565594276826 : Closed e565594276826 ∧ code e565594276826 = 2764617532378 := by decide
theorem cert_e565594276826 : check e565594276826 [[],[.under]] .three = true := by decide
def e565594277494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e565594277494 : Closed e565594277494 ∧ code e565594277494 = 2764617533046 := by decide
theorem cert_e565594277494 : check e565594277494 [[],[.under]] .three = true := by decide
def e565594277686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e565594277686 : Closed e565594277686 ∧ code e565594277686 = 2764617533238 := by decide
theorem cert_e565594277686 : check e565594277686 [[],[.under]] .three = true := by decide
def e565594277690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e565594277690 : Closed e565594277690 ∧ code e565594277690 = 2764617533242 := by decide
theorem cert_e565594277690 : check e565594277690 [[],[.under]] .three = true := by decide
def e565594278742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e565594278742 : Closed e565594278742 ∧ code e565594278742 = 2764617534294 := by decide
theorem cert_e565594278742 : check e565594278742 [[],[.under]] .three = true := by decide
def e565594278746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e565594278746 : Closed e565594278746 ∧ code e565594278746 = 2764617534298 := by decide
theorem cert_e565594278746 : check e565594278746 [[],[.under]] .three = true := by decide
def e565594278762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e565594278762 : Closed e565594278762 ∧ code e565594278762 = 2764617534314 := by decide
theorem cert_e565594278762 : check e565594278762 [[],[.under]] .three = true := by decide
def e565594278826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e565594278826 : Closed e565594278826 ∧ code e565594278826 = 2764617534378 := by decide
theorem cert_e565594278826 : check e565594278826 [[],[.under]] .three = true := by decide
def e565594279030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e565594279030 : Closed e565594279030 ∧ code e565594279030 = 2764617534582 := by decide
theorem cert_e565594279030 : check e565594279030 [[],[.under]] .three = true := by decide
def e565594279126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e565594279126 : Closed e565594279126 ∧ code e565594279126 = 2764617534678 := by decide
theorem cert_e565594279126 : check e565594279126 [[],[.under]] .three = true := by decide
def e565594279130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e565594279130 : Closed e565594279130 ∧ code e565594279130 = 2764617534682 := by decide
theorem cert_e565594279130 : check e565594279130 [[],[.under]] .three = true := by decide
def e565594279146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e565594279146 : Closed e565594279146 ∧ code e565594279146 = 2764617534698 := by decide
theorem cert_e565594279146 : check e565594279146 [[],[.under]] .three = true := by decide
def e565594279222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e565594279222 : Closed e565594279222 ∧ code e565594279222 = 2764617534774 := by decide
theorem cert_e565594279222 : check e565594279222 [[],[.under]] .three = true := by decide
def e565594279226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e565594279226 : Closed e565594279226 ∧ code e565594279226 = 2764617534778 := by decide
theorem cert_e565594279226 : check e565594279226 [[],[.under]] .three = true := by decide
def e565594279310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e565594279310 : Closed e565594279310 ∧ code e565594279310 = 2764617534862 := by decide
theorem cert_e565594279310 : check e565594279310 [[],[.under]] .three = true := by decide
def e565594279322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e565594279322 : Closed e565594279322 ∧ code e565594279322 = 2764617534874 := by decide
theorem cert_e565594279322 : check e565594279322 [[],[.under]] .three = true := by decide
def e565594279478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e565594279478 : Closed e565594279478 ∧ code e565594279478 = 2764617535030 := by decide
theorem cert_e565594279478 : check e565594279478 [[],[.under]] .three = true := by decide
def e565594279482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e565594279482 : Closed e565594279482 ∧ code e565594279482 = 2764617535034 := by decide
theorem cert_e565594279482 : check e565594279482 [[],[.under]] .three = true := by decide
def e565594279530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e565594279530 : Closed e565594279530 ∧ code e565594279530 = 2764617535082 := by decide
theorem cert_e565594279530 : check e565594279530 [[],[.under]] .three = true := by decide
def e565594279566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e565594279566 : Closed e565594279566 ∧ code e565594279566 = 2764617535118 := by decide
theorem cert_e565594279566 : check e565594279566 [[],[.under]] .three = true := by decide
def e565594279578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e565594279578 : Closed e565594279578 ∧ code e565594279578 = 2764617535130 := by decide
theorem cert_e565594279578 : check e565594279578 [[],[.under]] .three = true := by decide
def e565594279622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e565594279622 : Closed e565594279622 ∧ code e565594279622 = 2764617535174 := by decide
theorem cert_e565594279622 : check e565594279622 [[],[.under]] .three = true := by decide
def e565594280174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e565594280174 : Closed e565594280174 ∧ code e565594280174 = 2764617535726 := by decide
theorem cert_e565594280174 : check e565594280174 [[],[.under]] .three = true := by decide
def e565594280182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e565594280182 : Closed e565594280182 ∧ code e565594280182 = 2764617535734 := by decide
theorem cert_e565594280182 : check e565594280182 [[],[.under]] .three = true := by decide
def e565594280662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e565594280662 : Closed e565594280662 ∧ code e565594280662 = 2764617536214 := by decide
theorem cert_e565594280662 : check e565594280662 [[],[.under]] .three = true := by decide
def e565594280666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e565594280666 : Closed e565594280666 ∧ code e565594280666 = 2764617536218 := by decide
theorem cert_e565594280666 : check e565594280666 [[],[.under]] .three = true := by decide
def e565594280682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e565594280682 : Closed e565594280682 ∧ code e565594280682 = 2764617536234 := by decide
theorem cert_e565594280682 : check e565594280682 [[],[.under]] .three = true := by decide
def e565594280758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e565594280758 : Closed e565594280758 ∧ code e565594280758 = 2764617536310 := by decide
theorem cert_e565594280758 : check e565594280758 [[],[.under]] .three = true := by decide
def e565594280762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e565594280762 : Closed e565594280762 ∧ code e565594280762 = 2764617536314 := by decide
theorem cert_e565594280762 : check e565594280762 [[],[.under]] .three = true := by decide
def e565594280846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e565594280846 : Closed e565594280846 ∧ code e565594280846 = 2764617536398 := by decide
theorem cert_e565594280846 : check e565594280846 [[],[.under]] .three = true := by decide
def e565594280858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e565594280858 : Closed e565594280858 ∧ code e565594280858 = 2764617536410 := by decide
theorem cert_e565594280858 : check e565594280858 [[],[.under]] .three = true := by decide
def e565594282102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e565594282102 : Closed e565594282102 ∧ code e565594282102 = 2764617537654 := by decide
theorem cert_e565594282102 : check e565594282102 [[],[.under]] .three = true := by decide
def e565594282346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e565594282346 : Closed e565594282346 ∧ code e565594282346 = 2764617537898 := by decide
theorem cert_e565594282346 : check e565594282346 [[],[.under]] .three = true := by decide
def e565594282382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e565594282382 : Closed e565594282382 ∧ code e565594282382 = 2764617537934 := by decide
theorem cert_e565594282382 : check e565594282382 [[],[.under]] .three = true := by decide
def e565594282394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e565594282394 : Closed e565594282394 ∧ code e565594282394 = 2764617537946 := by decide
theorem cert_e565594282394 : check e565594282394 [[],[.under]] .three = true := by decide
def e565594282438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e565594282438 : Closed e565594282438 ∧ code e565594282438 = 2764617537990 := by decide
theorem cert_e565594282438 : check e565594282438 [[],[.under]] .three = true := by decide
def e565594295150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e565594295150 : Closed e565594295150 ∧ code e565594295150 = 2764617550702 := by decide
theorem cert_e565594295150 : check e565594295150 [[],[.under]] .smaller = true := by decide
def e565594295158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e565594295158 : Closed e565594295158 ∧ code e565594295158 = 2764617550710 := by decide
theorem cert_e565594295158 : check e565594295158 [[],[.under]] .smaller = true := by decide
def e565594295214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e565594295214 : Closed e565594295214 ∧ code e565594295214 = 2764617550766 := by decide
theorem cert_e565594295214 : check e565594295214 [[],[.under]] .smaller = true := by decide
def e565594295226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e565594295226 : Closed e565594295226 ∧ code e565594295226 = 2764617550778 := by decide
theorem cert_e565594295226 : check e565594295226 [[],[.under]] .smaller = true := by decide
def e565594295254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e565594295254 : Closed e565594295254 ∧ code e565594295254 = 2764617550806 := by decide
theorem cert_e565594295254 : check e565594295254 [[],[.under]] .smaller = true := by decide
def e565594295258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e565594295258 : Closed e565594295258 ∧ code e565594295258 = 2764617550810 := by decide
theorem cert_e565594295258 : check e565594295258 [[],[.under]] .smaller = true := by decide
def e565594295534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e565594295534 : Closed e565594295534 ∧ code e565594295534 = 2764617551086 := by decide
theorem cert_e565594295534 : check e565594295534 [[],[.under]] .smaller = true := by decide
def e565594295542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e565594295542 : Closed e565594295542 ∧ code e565594295542 = 2764617551094 := by decide
theorem cert_e565594295542 : check e565594295542 [[],[.under]] .smaller = true := by decide
def e565594295918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e565594295918 : Closed e565594295918 ∧ code e565594295918 = 2764617551470 := by decide
theorem cert_e565594295918 : check e565594295918 [[],[.under]] .smaller = true := by decide
def e565594295930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e565594295930 : Closed e565594295930 ∧ code e565594295930 = 2764617551482 := by decide
theorem cert_e565594295930 : check e565594295930 [[],[.under]] .smaller = true := by decide
def e565594296118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e565594296118 : Closed e565594296118 ∧ code e565594296118 = 2764617551670 := by decide
theorem cert_e565594296118 : check e565594296118 [[],[.under]] .smaller = true := by decide
def e565594296122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e565594296122 : Closed e565594296122 ∧ code e565594296122 = 2764617551674 := by decide
theorem cert_e565594296122 : check e565594296122 [[],[.under]] .smaller = true := by decide
def e565594336622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e565594336622 : Closed e565594336622 ∧ code e565594336622 = 2764617592174 := by decide
theorem cert_e565594336622 : check e565594336622 [[],[.under]] .three = true := by decide
def e565594336630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e565594336630 : Closed e565594336630 ∧ code e565594336630 = 2764617592182 := by decide
theorem cert_e565594336630 : check e565594336630 [[],[.under]] .three = true := by decide
def e565594336686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e565594336686 : Closed e565594336686 ∧ code e565594336686 = 2764617592238 := by decide
theorem cert_e565594336686 : check e565594336686 [[],[.under]] .three = true := by decide
def e565594336698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e565594336698 : Closed e565594336698 ∧ code e565594336698 = 2764617592250 := by decide
theorem cert_e565594336698 : check e565594336698 [[],[.under]] .three = true := by decide
def e565594336726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e565594336726 : Closed e565594336726 ∧ code e565594336726 = 2764617592278 := by decide
theorem cert_e565594336726 : check e565594336726 [[],[.under]] .three = true := by decide
def e565594336730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e565594336730 : Closed e565594336730 ∧ code e565594336730 = 2764617592282 := by decide
theorem cert_e565594336730 : check e565594336730 [[],[.under]] .three = true := by decide
def e565594336942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e565594336942 : Closed e565594336942 ∧ code e565594336942 = 2764617592494 := by decide
theorem cert_e565594336942 : check e565594336942 [[],[.under]] .three = true := by decide
def e565594336954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e565594336954 : Closed e565594336954 ∧ code e565594336954 = 2764617592506 := by decide
theorem cert_e565594336954 : check e565594336954 [[],[.under]] .three = true := by decide
def e565594337002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e565594337002 : Closed e565594337002 ∧ code e565594337002 = 2764617592554 := by decide
theorem cert_e565594337002 : check e565594337002 [[],[.under]] .three = true := by decide
def e565594337110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e565594337110 : Closed e565594337110 ∧ code e565594337110 = 2764617592662 := by decide
theorem cert_e565594337110 : check e565594337110 [[],[.under]] .three = true := by decide
end Blc.Floor41
