import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601864506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601864506 : Closed e605601864506 ∧ code e605601864506 = 2804625120058 := by decide
theorem cert_e605601864506 : check e605601864506 [[],[]] .chain = true := by decide
def e605601864590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601864590 : Closed e605601864590 ∧ code e605601864590 = 2804625120142 := by decide
theorem cert_e605601864590 : check e605601864590 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601864814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601864814 : Closed e605601864814 ∧ code e605601864814 = 2804625120366 := by decide
theorem cert_e605601864814 : check e605601864814 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601864826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601864826 : Closed e605601864826 ∧ code e605601864826 = 2804625120378 := by decide
theorem cert_e605601864826 : check e605601864826 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601864918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601864918 : Closed e605601864918 ∧ code e605601864918 = 2804625120470 := by decide
theorem cert_e605601864918 : check e605601864918 [[],[]] .chain = true := by decide
def e605601864922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601864922 : Closed e605601864922 ∧ code e605601864922 = 2804625120474 := by decide
theorem cert_e605601864922 : check e605601864922 [[],[]] .chain = true := by decide
def e605601864938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601864938 : Closed e605601864938 ∧ code e605601864938 = 2804625120490 := by decide
theorem cert_e605601864938 : check e605601864938 [[],[]] .chain = true := by decide
def e605601864990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601864990 : Closed e605601864990 ∧ code e605601864990 = 2804625120542 := by decide
theorem cert_e605601864990 : check e605601864990 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601865014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601865014 : Closed e605601865014 ∧ code e605601865014 = 2804625120566 := by decide
theorem cert_e605601865014 : check e605601865014 [[],[]] .chain = true := by decide
def e605601865018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601865018 : Closed e605601865018 ∧ code e605601865018 = 2804625120570 := by decide
theorem cert_e605601865018 : check e605601865018 [[],[]] .chain = true := by decide
def e605601865114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601865114 : Closed e605601865114 ∧ code e605601865114 = 2804625120666 := by decide
theorem cert_e605601865114 : check e605601865114 [[],[]] .chain = true := by decide
def e605601865158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601865158 : Closed e605601865158 ∧ code e605601865158 = 2804625120710 := by decide
theorem cert_e605601865158 : check e605601865158 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601865270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601865270 : Closed e605601865270 ∧ code e605601865270 = 2804625120822 := by decide
theorem cert_e605601865270 : check e605601865270 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605601865274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601865274 : Closed e605601865274 ∧ code e605601865274 = 2804625120826 := by decide
theorem cert_e605601865274 : check e605601865274 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605601865358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601865358 : Closed e605601865358 ∧ code e605601865358 = 2804625120910 := by decide
theorem cert_e605601865358 : check e605601865358 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605601865414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601865414 : Closed e605601865414 ∧ code e605601865414 = 2804625120966 := by decide
theorem cert_e605601865414 : check e605601865414 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605601869142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601869142 : Closed e605601869142 ∧ code e605601869142 = 2804625124694 := by decide
theorem cert_e605601869142 : check e605601869142 [[],[]] .chain = true := by decide
def e605601869146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601869146 : Closed e605601869146 ∧ code e605601869146 = 2804625124698 := by decide
theorem cert_e605601869146 : check e605601869146 [[],[]] .chain = true := by decide
def e605601869162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e605601869162 : Closed e605601869162 ∧ code e605601869162 = 2804625124714 := by decide
theorem cert_e605601869162 : check e605601869162 [[],[]] .chain = true := by decide
def e605601869226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601869226 : Closed e605601869226 ∧ code e605601869226 = 2804625124778 := by decide
theorem cert_e605601869226 : check e605601869226 [[],[]] .chain = true := by decide
def e605601869482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601869482 : Closed e605601869482 ∧ code e605601869482 = 2804625125034 := by decide
theorem cert_e605601869482 : check e605601869482 [[],[]] .chain = true := by decide
def e605601869910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e605601869910 : Closed e605601869910 ∧ code e605601869910 = 2804625125462 := by decide
theorem cert_e605601869910 : check e605601869910 [[],[]] .chain = true := by decide
def e605601869914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e605601869914 : Closed e605601869914 ∧ code e605601869914 = 2804625125466 := by decide
theorem cert_e605601869914 : check e605601869914 [[],[]] .chain = true := by decide
def e605601870190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e605601870190 : Closed e605601870190 ∧ code e605601870190 = 2804625125742 := by decide
theorem cert_e605601870190 : check e605601870190 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601870198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e605601870198 : Closed e605601870198 ∧ code e605601870198 = 2804625125750 := by decide
theorem cert_e605601870198 : check e605601870198 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601870262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e605601870262 : Closed e605601870262 ∧ code e605601870262 = 2804625125814 := by decide
theorem cert_e605601870262 : check e605601870262 [[],[]] .chain = true := by decide
def e605601870294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e605601870294 : Closed e605601870294 ∧ code e605601870294 = 2804625125846 := by decide
theorem cert_e605601870294 : check e605601870294 [[],[]] .chain = true := by decide
def e605601870298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e605601870298 : Closed e605601870298 ∧ code e605601870298 = 2804625125850 := by decide
theorem cert_e605601870298 : check e605601870298 [[],[]] .chain = true := by decide
def e605601870678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601870678 : Closed e605601870678 ∧ code e605601870678 = 2804625126230 := by decide
theorem cert_e605601870678 : check e605601870678 [[],[]] .chain = true := by decide
def e605601870682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601870682 : Closed e605601870682 ∧ code e605601870682 = 2804625126234 := by decide
theorem cert_e605601870682 : check e605601870682 [[],[]] .chain = true := by decide
def e605601870698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e605601870698 : Closed e605601870698 ∧ code e605601870698 = 2804625126250 := by decide
theorem cert_e605601870698 : check e605601870698 [[],[]] .chain = true := by decide
def e605601870762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601870762 : Closed e605601870762 ∧ code e605601870762 = 2804625126314 := by decide
theorem cert_e605601870762 : check e605601870762 [[],[]] .chain = true := by decide
def e605601870870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601870870 : Closed e605601870870 ∧ code e605601870870 = 2804625126422 := by decide
theorem cert_e605601870870 : check e605601870870 [[],[]] .chain = true := by decide
def e605601870966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e605601870966 : Closed e605601870966 ∧ code e605601870966 = 2804625126518 := by decide
theorem cert_e605601870966 : check e605601870966 [[],[]] .chain = true := by decide
def e605601871062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601871062 : Closed e605601871062 ∧ code e605601871062 = 2804625126614 := by decide
theorem cert_e605601871062 : check e605601871062 [[],[]] .chain = true := by decide
def e605601871066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601871066 : Closed e605601871066 ∧ code e605601871066 = 2804625126618 := by decide
theorem cert_e605601871066 : check e605601871066 [[],[]] .chain = true := by decide
def e605601871082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601871082 : Closed e605601871082 ∧ code e605601871082 = 2804625126634 := by decide
theorem cert_e605601871082 : check e605601871082 [[],[]] .chain = true := by decide
def e605601871158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601871158 : Closed e605601871158 ∧ code e605601871158 = 2804625126710 := by decide
theorem cert_e605601871158 : check e605601871158 [[],[]] .chain = true := by decide
def e605601871162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601871162 : Closed e605601871162 ∧ code e605601871162 = 2804625126714 := by decide
theorem cert_e605601871162 : check e605601871162 [[],[]] .chain = true := by decide
def e605601871234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e605601871234 : Closed e605601871234 ∧ code e605601871234 = 2804625126786 := by decide
theorem cert_e605601871234 : check e605601871234 [[],[]] .chain = true := by decide
def e605601871246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e605601871246 : Closed e605601871246 ∧ code e605601871246 = 2804625126798 := by decide
theorem cert_e605601871246 : check e605601871246 [[],[]] .chain = true := by decide
def e605601871258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601871258 : Closed e605601871258 ∧ code e605601871258 = 2804625126810 := by decide
theorem cert_e605601871258 : check e605601871258 [[],[]] .chain = true := by decide
def e605601871370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601871370 : Closed e605601871370 ∧ code e605601871370 = 2804625126922 := by decide
theorem cert_e605601871370 : check e605601871370 [[],[]] .chain = true := by decide
def e605601871406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601871406 : Closed e605601871406 ∧ code e605601871406 = 2804625126958 := by decide
theorem cert_e605601871406 : check e605601871406 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601871414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601871414 : Closed e605601871414 ∧ code e605601871414 = 2804625126966 := by decide
theorem cert_e605601871414 : check e605601871414 [[],[]] .chain = true := by decide
def e605601871418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601871418 : Closed e605601871418 ∧ code e605601871418 = 2804625126970 := by decide
theorem cert_e605601871418 : check e605601871418 [[],[]] .chain = true := by decide
def e605601871466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601871466 : Closed e605601871466 ∧ code e605601871466 = 2804625127018 := by decide
theorem cert_e605601871466 : check e605601871466 [[],[]] .chain = true := by decide
def e605601871490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601871490 : Closed e605601871490 ∧ code e605601871490 = 2804625127042 := by decide
theorem cert_e605601871490 : check e605601871490 [[],[]] .chain = true := by decide
def e605601871502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601871502 : Closed e605601871502 ∧ code e605601871502 = 2804625127054 := by decide
theorem cert_e605601871502 : check e605601871502 [[],[]] .chain = true := by decide
def e605601871514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601871514 : Closed e605601871514 ∧ code e605601871514 = 2804625127066 := by decide
theorem cert_e605601871514 : check e605601871514 [[],[]] .chain = true := by decide
def e605601871558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601871558 : Closed e605601871558 ∧ code e605601871558 = 2804625127110 := by decide
theorem cert_e605601871558 : check e605601871558 [[],[]] .chain = true := by decide
def e605601871586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601871586 : Closed e605601871586 ∧ code e605601871586 = 2804625127138 := by decide
theorem cert_e605601871586 : check e605601871586 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601871598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e605601871598 : Closed e605601871598 ∧ code e605601871598 = 2804625127150 := by decide
theorem cert_e605601871598 : check e605601871598 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e605601871638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e605601871638 : Closed e605601871638 ∧ code e605601871638 = 2804625127190 := by decide
theorem cert_e605601871638 : check e605601871638 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601871714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e605601871714 : Closed e605601871714 ∧ code e605601871714 = 2804625127266 := by decide
theorem cert_e605601871714 : check e605601871714 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601871726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e605601871726 : Closed e605601871726 ∧ code e605601871726 = 2804625127278 := by decide
theorem cert_e605601871726 : check e605601871726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601871734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e605601871734 : Closed e605601871734 ∧ code e605601871734 = 2804625127286 := by decide
theorem cert_e605601871734 : check e605601871734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601871914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e605601871914 : Closed e605601871914 ∧ code e605601871914 = 2804625127466 := by decide
theorem cert_e605601871914 : check e605601871914 [[],[]] .chain = true := by decide
def e605601872046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601872046 : Closed e605601872046 ∧ code e605601872046 = 2804625127598 := by decide
theorem cert_e605601872046 : check e605601872046 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601872058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601872058 : Closed e605601872058 ∧ code e605601872058 = 2804625127610 := by decide
theorem cert_e605601872058 : check e605601872058 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601872086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e605601872086 : Closed e605601872086 ∧ code e605601872086 = 2804625127638 := by decide
theorem cert_e605601872086 : check e605601872086 [[],[]] .chain = true := by decide
def e605601872090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e605601872090 : Closed e605601872090 ∧ code e605601872090 = 2804625127642 := by decide
theorem cert_e605601872090 : check e605601872090 [[],[]] .chain = true := by decide
def e605601872106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601872106 : Closed e605601872106 ∧ code e605601872106 = 2804625127658 := by decide
theorem cert_e605601872106 : check e605601872106 [[],[]] .chain = true := by decide
def e605601872298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601872298 : Closed e605601872298 ∧ code e605601872298 = 2804625127850 := by decide
theorem cert_e605601872298 : check e605601872298 [[],[]] .chain = true := by decide
def e605601872394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601872394 : Closed e605601872394 ∧ code e605601872394 = 2804625127946 := by decide
theorem cert_e605601872394 : check e605601872394 [[],[]] .chain = true := by decide
def e605601872430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601872430 : Closed e605601872430 ∧ code e605601872430 = 2804625127982 := by decide
theorem cert_e605601872430 : check e605601872430 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601872438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601872438 : Closed e605601872438 ∧ code e605601872438 = 2804625127990 := by decide
theorem cert_e605601872438 : check e605601872438 [[],[]] .chain = true := by decide
def e605601872442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601872442 : Closed e605601872442 ∧ code e605601872442 = 2804625127994 := by decide
theorem cert_e605601872442 : check e605601872442 [[],[]] .chain = true := by decide
def e605601872490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601872490 : Closed e605601872490 ∧ code e605601872490 = 2804625128042 := by decide
theorem cert_e605601872490 : check e605601872490 [[],[]] .chain = true := by decide
def e605601872514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601872514 : Closed e605601872514 ∧ code e605601872514 = 2804625128066 := by decide
theorem cert_e605601872514 : check e605601872514 [[],[]] .chain = true := by decide
def e605601872526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601872526 : Closed e605601872526 ∧ code e605601872526 = 2804625128078 := by decide
theorem cert_e605601872526 : check e605601872526 [[],[]] .chain = true := by decide
def e605601872538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601872538 : Closed e605601872538 ∧ code e605601872538 = 2804625128090 := by decide
theorem cert_e605601872538 : check e605601872538 [[],[]] .chain = true := by decide
def e605601872582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601872582 : Closed e605601872582 ∧ code e605601872582 = 2804625128134 := by decide
theorem cert_e605601872582 : check e605601872582 [[],[]] .chain = true := by decide
def e605601872610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601872610 : Closed e605601872610 ∧ code e605601872610 = 2804625128162 := by decide
theorem cert_e605601872610 : check e605601872610 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601872622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e605601872622 : Closed e605601872622 ∧ code e605601872622 = 2804625128174 := by decide
theorem cert_e605601872622 : check e605601872622 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601872666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e605601872666 : Closed e605601872666 ∧ code e605601872666 = 2804625128218 := by decide
theorem cert_e605601872666 : check e605601872666 [[],[]] .chain = true := by decide
def e605601872710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e605601872710 : Closed e605601872710 ∧ code e605601872710 = 2804625128262 := by decide
theorem cert_e605601872710 : check e605601872710 [[],[]] .chain = true := by decide
def e605601872778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e605601872778 : Closed e605601872778 ∧ code e605601872778 = 2804625128330 := by decide
theorem cert_e605601872778 : check e605601872778 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601872802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e605601872802 : Closed e605601872802 ∧ code e605601872802 = 2804625128354 := by decide
theorem cert_e605601872802 : check e605601872802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601872814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e605601872814 : Closed e605601872814 ∧ code e605601872814 = 2804625128366 := by decide
theorem cert_e605601872814 : check e605601872814 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601872826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e605601872826 : Closed e605601872826 ∧ code e605601872826 = 2804625128378 := by decide
theorem cert_e605601872826 : check e605601872826 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601872982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601872982 : Closed e605601872982 ∧ code e605601872982 = 2804625128534 := by decide
theorem cert_e605601872982 : check e605601872982 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601872986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601872986 : Closed e605601872986 ∧ code e605601872986 = 2804625128538 := by decide
theorem cert_e605601872986 : check e605601872986 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601873174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e605601873174 : Closed e605601873174 ∧ code e605601873174 = 2804625128726 := by decide
theorem cert_e605601873174 : check e605601873174 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601873250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e605601873250 : Closed e605601873250 ∧ code e605601873250 = 2804625128802 := by decide
theorem cert_e605601873250 : check e605601873250 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601873262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e605601873262 : Closed e605601873262 ∧ code e605601873262 = 2804625128814 := by decide
theorem cert_e605601873262 : check e605601873262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601873270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e605601873270 : Closed e605601873270 ∧ code e605601873270 = 2804625128822 := by decide
theorem cert_e605601873270 : check e605601873270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e605601873290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e605601873290 : Closed e605601873290 ∧ code e605601873290 = 2804625128842 := by decide
theorem cert_e605601873290 : check e605601873290 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601873314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e605601873314 : Closed e605601873314 ∧ code e605601873314 = 2804625128866 := by decide
theorem cert_e605601873314 : check e605601873314 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601873326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e605601873326 : Closed e605601873326 ∧ code e605601873326 = 2804625128878 := by decide
theorem cert_e605601873326 : check e605601873326 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605601873338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e605601873338 : Closed e605601873338 ∧ code e605601873338 = 2804625128890 := by decide
theorem cert_e605601873338 : check e605601873338 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605601873366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e605601873366 : Closed e605601873366 ∧ code e605601873366 = 2804625128918 := by decide
private def t_e605601873366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem cert_e605601873366 : ¬ IsSelfInterpreter e605601873366 :=
  wSource (t := t_e605601873366) (replay_sound (ps := []) (t := e605601873366) (by decide)) (by decide)
def e605601873370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e605601873370 : Closed e605601873370 ∧ code e605601873370 = 2804625128922 := by decide
private def t_e605601873370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem cert_e605601873370 : ¬ IsSelfInterpreter e605601873370 :=
  wSource (t := t_e605601873370) (replay_sound (ps := []) (t := e605601873370) (by decide)) (by decide)
def e605601874134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e605601874134 : Closed e605601874134 ∧ code e605601874134 = 2804625129686 := by decide
theorem cert_e605601874134 : check e605601874134 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e605601874230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601874230 : Closed e605601874230 ∧ code e605601874230 = 2804625129782 := by decide
theorem cert_e605601874230 : check e605601874230 [[],[]] .chain = true := by decide
def e605601874234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601874234 : Closed e605601874234 ∧ code e605601874234 = 2804625129786 := by decide
theorem cert_e605601874234 : check e605601874234 [[],[]] .chain = true := by decide
def e605601874414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e605601874414 : Closed e605601874414 ∧ code e605601874414 = 2804625129966 := by decide
theorem cert_e605601874414 : check e605601874414 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601874422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e605601874422 : Closed e605601874422 ∧ code e605601874422 = 2804625129974 := by decide
theorem cert_e605601874422 : check e605601874422 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601874806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e605601874806 : Closed e605601874806 ∧ code e605601874806 = 2804625130358 := by decide
theorem cert_e605601874806 : check e605601874806 [[],[]] .chain = true := by decide
def e605601874870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e605601874870 : Closed e605601874870 ∧ code e605601874870 = 2804625130422 := by decide
theorem cert_e605601874870 : check e605601874870 [[],[]] .chain = true := by decide
def e605601874874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e605601874874 : Closed e605601874874 ∧ code e605601874874 = 2804625130426 := by decide
theorem cert_e605601874874 : check e605601874874 [[],[]] .chain = true := by decide
def e605601874902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e605601874902 : Closed e605601874902 ∧ code e605601874902 = 2804625130454 := by decide
theorem cert_e605601874902 : check e605601874902 [[],[]] .chain = true := by decide
def e605601874906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e605601874906 : Closed e605601874906 ∧ code e605601874906 = 2804625130458 := by decide
theorem cert_e605601874906 : check e605601874906 [[],[]] .chain = true := by decide
def e605601875182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601875182 : Closed e605601875182 ∧ code e605601875182 = 2804625130734 := by decide
theorem cert_e605601875182 : check e605601875182 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601875190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601875190 : Closed e605601875190 ∧ code e605601875190 = 2804625130742 := by decide
theorem cert_e605601875190 : check e605601875190 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601875574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e605601875574 : Closed e605601875574 ∧ code e605601875574 = 2804625131126 := by decide
theorem cert_e605601875574 : check e605601875574 [[],[]] .chain = true := by decide
def e605601875742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e605601875742 : Closed e605601875742 ∧ code e605601875742 = 2804625131294 := by decide
theorem cert_e605601875742 : check e605601875742 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601875766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601875766 : Closed e605601875766 ∧ code e605601875766 = 2804625131318 := by decide
theorem cert_e605601875766 : check e605601875766 [[],[]] .chain = true := by decide
def e605601875770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601875770 : Closed e605601875770 ∧ code e605601875770 = 2804625131322 := by decide
theorem cert_e605601875770 : check e605601875770 [[],[]] .chain = true := by decide
def e605601875854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e605601875854 : Closed e605601875854 ∧ code e605601875854 = 2804625131406 := by decide
theorem cert_e605601875854 : check e605601875854 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601876822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e605601876822 : Closed e605601876822 ∧ code e605601876822 = 2804625132374 := by decide
theorem cert_e605601876822 : check e605601876822 [[],[]] .chain = true := by decide
def e605601876826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e605601876826 : Closed e605601876826 ∧ code e605601876826 = 2804625132378 := by decide
theorem cert_e605601876826 : check e605601876826 [[],[]] .chain = true := by decide
def e605601876842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e605601876842 : Closed e605601876842 ∧ code e605601876842 = 2804625132394 := by decide
theorem cert_e605601876842 : check e605601876842 [[],[]] .chain = true := by decide
def e605601876906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605601876906 : Closed e605601876906 ∧ code e605601876906 = 2804625132458 := by decide
theorem cert_e605601876906 : check e605601876906 [[],[]] .chain = true := by decide
def e605601877014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e605601877014 : Closed e605601877014 ∧ code e605601877014 = 2804625132566 := by decide
theorem cert_e605601877014 : check e605601877014 [[],[]] .chain = true := by decide
def e605601877110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e605601877110 : Closed e605601877110 ∧ code e605601877110 = 2804625132662 := by decide
theorem cert_e605601877110 : check e605601877110 [[],[]] .chain = true := by decide
def e605601877206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e605601877206 : Closed e605601877206 ∧ code e605601877206 = 2804625132758 := by decide
theorem cert_e605601877206 : check e605601877206 [[],[]] .chain = true := by decide
def e605601877210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e605601877210 : Closed e605601877210 ∧ code e605601877210 = 2804625132762 := by decide
theorem cert_e605601877210 : check e605601877210 [[],[]] .chain = true := by decide
def e605601877226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e605601877226 : Closed e605601877226 ∧ code e605601877226 = 2804625132778 := by decide
theorem cert_e605601877226 : check e605601877226 [[],[]] .chain = true := by decide
def e605601877302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601877302 : Closed e605601877302 ∧ code e605601877302 = 2804625132854 := by decide
theorem cert_e605601877302 : check e605601877302 [[],[]] .chain = true := by decide
def e605601877306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601877306 : Closed e605601877306 ∧ code e605601877306 = 2804625132858 := by decide
theorem cert_e605601877306 : check e605601877306 [[],[]] .chain = true := by decide
def e605601877378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e605601877378 : Closed e605601877378 ∧ code e605601877378 = 2804625132930 := by decide
theorem cert_e605601877378 : check e605601877378 [[],[]] .chain = true := by decide
def e605601877390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e605601877390 : Closed e605601877390 ∧ code e605601877390 = 2804625132942 := by decide
theorem cert_e605601877390 : check e605601877390 [[],[]] .chain = true := by decide
def e605601877402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601877402 : Closed e605601877402 ∧ code e605601877402 = 2804625132954 := by decide
theorem cert_e605601877402 : check e605601877402 [[],[]] .chain = true := by decide
def e605601877514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605601877514 : Closed e605601877514 ∧ code e605601877514 = 2804625133066 := by decide
theorem cert_e605601877514 : check e605601877514 [[],[]] .chain = true := by decide
def e605601877550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601877550 : Closed e605601877550 ∧ code e605601877550 = 2804625133102 := by decide
theorem cert_e605601877550 : check e605601877550 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601877558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605601877558 : Closed e605601877558 ∧ code e605601877558 = 2804625133110 := by decide
theorem cert_e605601877558 : check e605601877558 [[],[]] .chain = true := by decide
def e605601877562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605601877562 : Closed e605601877562 ∧ code e605601877562 = 2804625133114 := by decide
theorem cert_e605601877562 : check e605601877562 [[],[]] .chain = true := by decide
def e605601877610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605601877610 : Closed e605601877610 ∧ code e605601877610 = 2804625133162 := by decide
theorem cert_e605601877610 : check e605601877610 [[],[]] .chain = true := by decide
def e605601877634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605601877634 : Closed e605601877634 ∧ code e605601877634 = 2804625133186 := by decide
theorem cert_e605601877634 : check e605601877634 [[],[]] .chain = true := by decide
def e605601877646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605601877646 : Closed e605601877646 ∧ code e605601877646 = 2804625133198 := by decide
theorem cert_e605601877646 : check e605601877646 [[],[]] .chain = true := by decide
def e605601877658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601877658 : Closed e605601877658 ∧ code e605601877658 = 2804625133210 := by decide
theorem cert_e605601877658 : check e605601877658 [[],[]] .chain = true := by decide
def e605601877702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605601877702 : Closed e605601877702 ∧ code e605601877702 = 2804625133254 := by decide
theorem cert_e605601877702 : check e605601877702 [[],[]] .chain = true := by decide
def e605601877730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605601877730 : Closed e605601877730 ∧ code e605601877730 = 2804625133282 := by decide
theorem cert_e605601877730 : check e605601877730 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601877742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e605601877742 : Closed e605601877742 ∧ code e605601877742 = 2804625133294 := by decide
theorem cert_e605601877742 : check e605601877742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605601877782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601877782 : Closed e605601877782 ∧ code e605601877782 = 2804625133334 := by decide
theorem cert_e605601877782 : check e605601877782 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601877858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e605601877858 : Closed e605601877858 ∧ code e605601877858 = 2804625133410 := by decide
theorem cert_e605601877858 : check e605601877858 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601877870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e605601877870 : Closed e605601877870 ∧ code e605601877870 = 2804625133422 := by decide
theorem cert_e605601877870 : check e605601877870 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605601877878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e605601877878 : Closed e605601877878 ∧ code e605601877878 = 2804625133430 := by decide
theorem cert_e605601877878 : check e605601877878 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601878254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605601878254 : Closed e605601878254 ∧ code e605601878254 = 2804625133806 := by decide
theorem cert_e605601878254 : check e605601878254 [[],[]] .chain = true := by decide
def e605601878262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605601878262 : Closed e605601878262 ∧ code e605601878262 = 2804625133814 := by decide
theorem cert_e605601878262 : check e605601878262 [[],[]] .chain = true := by decide
def e605601878742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605601878742 : Closed e605601878742 ∧ code e605601878742 = 2804625134294 := by decide
theorem cert_e605601878742 : check e605601878742 [[],[]] .chain = true := by decide
def e605601878746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605601878746 : Closed e605601878746 ∧ code e605601878746 = 2804625134298 := by decide
theorem cert_e605601878746 : check e605601878746 [[],[]] .chain = true := by decide
def e605601878762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605601878762 : Closed e605601878762 ∧ code e605601878762 = 2804625134314 := by decide
theorem cert_e605601878762 : check e605601878762 [[],[]] .chain = true := by decide
def e605601878838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605601878838 : Closed e605601878838 ∧ code e605601878838 = 2804625134390 := by decide
theorem cert_e605601878838 : check e605601878838 [[],[]] .chain = true := by decide
def e605601878842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605601878842 : Closed e605601878842 ∧ code e605601878842 = 2804625134394 := by decide
theorem cert_e605601878842 : check e605601878842 [[],[]] .chain = true := by decide
def e605601878914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e605601878914 : Closed e605601878914 ∧ code e605601878914 = 2804625134466 := by decide
theorem cert_e605601878914 : check e605601878914 [[],[]] .chain = true := by decide
def e605601878926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e605601878926 : Closed e605601878926 ∧ code e605601878926 = 2804625134478 := by decide
theorem cert_e605601878926 : check e605601878926 [[],[]] .chain = true := by decide
def e605601878938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605601878938 : Closed e605601878938 ∧ code e605601878938 = 2804625134490 := by decide
theorem cert_e605601878938 : check e605601878938 [[],[]] .chain = true := by decide
def e605601880090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605601880090 : Closed e605601880090 ∧ code e605601880090 = 2804625135642 := by decide
theorem cert_e605601880090 : check e605601880090 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e605601880126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e605601880126 : Closed e605601880126 ∧ code e605601880126 = 2804625135678 := by decide
theorem cert_e605601880126 : check e605601880126 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601880174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605601880174 : Closed e605601880174 ∧ code e605601880174 = 2804625135726 := by decide
theorem cert_e605601880174 : check e605601880174 [[],[]] .chain = true := by decide
def e605601880182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605601880182 : Closed e605601880182 ∧ code e605601880182 = 2804625135734 := by decide
theorem cert_e605601880182 : check e605601880182 [[],[]] .chain = true := by decide
def e605601880186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605601880186 : Closed e605601880186 ∧ code e605601880186 = 2804625135738 := by decide
theorem cert_e605601880186 : check e605601880186 [[],[]] .chain = true := by decide
def e605601880426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605601880426 : Closed e605601880426 ∧ code e605601880426 = 2804625135978 := by decide
theorem cert_e605601880426 : check e605601880426 [[],[]] .chain = true := by decide
def e605601880450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605601880450 : Closed e605601880450 ∧ code e605601880450 = 2804625136002 := by decide
theorem cert_e605601880450 : check e605601880450 [[],[]] .chain = true := by decide
def e605601880462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605601880462 : Closed e605601880462 ∧ code e605601880462 = 2804625136014 := by decide
theorem cert_e605601880462 : check e605601880462 [[],[]] .chain = true := by decide
def e605601880474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605601880474 : Closed e605601880474 ∧ code e605601880474 = 2804625136026 := by decide
theorem cert_e605601880474 : check e605601880474 [[],[]] .chain = true := by decide
def e605601880518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605601880518 : Closed e605601880518 ∧ code e605601880518 = 2804625136070 := by decide
theorem cert_e605601880518 : check e605601880518 [[],[]] .chain = true := by decide
def e605601880546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605601880546 : Closed e605601880546 ∧ code e605601880546 = 2804625136098 := by decide
theorem cert_e605601880546 : check e605601880546 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
end Blc.Floor41
