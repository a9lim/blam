import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598345529786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e598345529786 : Closed e598345529786 ∧ code e598345529786 = 2797368785338 := by decide
def e598345529834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e598345529834 : Closed e598345529834 ∧ code e598345529834 = 2797368785386 := by decide
def e598345530586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e598345530586 : Closed e598345530586 ∧ code e598345530586 = 2797368786138 := by decide
def e598345530602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e598345530602 : Closed e598345530602 ∧ code e598345530602 = 2797368786154 := by decide
def e598345583470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598345583470 : Closed e598345583470 ∧ code e598345583470 = 2797368839022 := by decide
def e598345583478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598345583478 : Closed e598345583478 ∧ code e598345583478 = 2797368839030 := by decide
def e598345583534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598345583534 : Closed e598345583534 ∧ code e598345583534 = 2797368839086 := by decide
def e598345583546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598345583546 : Closed e598345583546 ∧ code e598345583546 = 2797368839098 := by decide
def e598345583574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598345583574 : Closed e598345583574 ∧ code e598345583574 = 2797368839126 := by decide
def e598345583578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598345583578 : Closed e598345583578 ∧ code e598345583578 = 2797368839130 := by decide
def e598345583854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598345583854 : Closed e598345583854 ∧ code e598345583854 = 2797368839406 := by decide
def e598345583862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598345583862 : Closed e598345583862 ∧ code e598345583862 = 2797368839414 := by decide
def e598345584238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598345584238 : Closed e598345584238 ∧ code e598345584238 = 2797368839790 := by decide
def e598345584250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598345584250 : Closed e598345584250 ∧ code e598345584250 = 2797368839802 := by decide
def e598345584438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598345584438 : Closed e598345584438 ∧ code e598345584438 = 2797368839990 := by decide
def e598345584442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598345584442 : Closed e598345584442 ∧ code e598345584442 = 2797368839994 := by decide
def e598345788894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e598345788894 : Closed e598345788894 ∧ code e598345788894 = 2797369044446 := by decide
theorem cert_e598345788894 : check e598345788894 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345788910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e598345788910 : Closed e598345788910 ∧ code e598345788910 = 2797369044462 := by decide
theorem cert_e598345788910 : check e598345788910 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345789278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e598345789278 : Closed e598345789278 ∧ code e598345789278 = 2797369044830 := by decide
theorem cert_e598345789278 : check e598345789278 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345789306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e598345789306 : Closed e598345789306 ∧ code e598345789306 = 2797369044858 := by decide
theorem cert_e598345789306 : check e598345789306 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345789358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e598345789358 : Closed e598345789358 ∧ code e598345789358 = 2797369044910 := by decide
theorem cert_e598345789358 : check e598345789358 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345789370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e598345789370 : Closed e598345789370 ∧ code e598345789370 = 2797369044922 := by decide
theorem cert_e598345789370 : check e598345789370 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345790430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e598345790430 : Closed e598345790430 ∧ code e598345790430 = 2797369045982 := by decide
theorem cert_e598345790430 : check e598345790430 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345790446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e598345790446 : Closed e598345790446 ∧ code e598345790446 = 2797369045998 := by decide
theorem cert_e598345790446 : check e598345790446 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345792734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e598345792734 : Closed e598345792734 ∧ code e598345792734 = 2797369048286 := by decide
theorem cert_e598345792734 : check e598345792734 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345792762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e598345792762 : Closed e598345792762 ∧ code e598345792762 = 2797369048314 := by decide
theorem cert_e598345792762 : check e598345792762 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345793134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e598345793134 : Closed e598345793134 ∧ code e598345793134 = 2797369048686 := by decide
theorem cert_e598345793134 : check e598345793134 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345793146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e598345793146 : Closed e598345793146 ∧ code e598345793146 = 2797369048698 := by decide
theorem cert_e598345793146 : check e598345793146 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598345821550 : Closed e598345821550 ∧ code e598345821550 = 2797369077102 := by decide
theorem cert_e598345821550 : check e598345821550 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598345821558 : Closed e598345821558 ∧ code e598345821558 = 2797369077110 := by decide
theorem cert_e598345821558 : check e598345821558 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598345821614 : Closed e598345821614 ∧ code e598345821614 = 2797369077166 := by decide
theorem cert_e598345821614 : check e598345821614 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598345821626 : Closed e598345821626 ∧ code e598345821626 = 2797369077178 := by decide
theorem cert_e598345821626 : check e598345821626 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598345821654 : Closed e598345821654 ∧ code e598345821654 = 2797369077206 := by decide
theorem cert_e598345821654 : check e598345821654 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598345821658 : Closed e598345821658 ∧ code e598345821658 = 2797369077210 := by decide
theorem cert_e598345821658 : check e598345821658 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598345821870 : Closed e598345821870 ∧ code e598345821870 = 2797369077422 := by decide
theorem cert_e598345821870 : check e598345821870 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598345821882 : Closed e598345821882 ∧ code e598345821882 = 2797369077434 := by decide
theorem cert_e598345821882 : check e598345821882 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345821930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598345821930 : Closed e598345821930 ∧ code e598345821930 = 2797369077482 := by decide
theorem cert_e598345821930 : check e598345821930 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345822038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598345822038 : Closed e598345822038 ∧ code e598345822038 = 2797369077590 := by decide
theorem cert_e598345822038 : check e598345822038 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345822042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598345822042 : Closed e598345822042 ∧ code e598345822042 = 2797369077594 := by decide
theorem cert_e598345822042 : check e598345822042 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345822058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598345822058 : Closed e598345822058 ∧ code e598345822058 = 2797369077610 := by decide
theorem cert_e598345822058 : check e598345822058 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598345823086 : Closed e598345823086 ∧ code e598345823086 = 2797369078638 := by decide
theorem cert_e598345823086 : check e598345823086 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598345823094 : Closed e598345823094 ∧ code e598345823094 = 2797369078646 := by decide
theorem cert_e598345823094 : check e598345823094 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598345823150 : Closed e598345823150 ∧ code e598345823150 = 2797369078702 := by decide
theorem cert_e598345823150 : check e598345823150 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598345823162 : Closed e598345823162 ∧ code e598345823162 = 2797369078714 := by decide
theorem cert_e598345823162 : check e598345823162 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598345823190 : Closed e598345823190 ∧ code e598345823190 = 2797369078742 := by decide
theorem cert_e598345823190 : check e598345823190 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598345823194 : Closed e598345823194 ∧ code e598345823194 = 2797369078746 := by decide
theorem cert_e598345823194 : check e598345823194 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598345823470 : Closed e598345823470 ∧ code e598345823470 = 2797369079022 := by decide
theorem cert_e598345823470 : check e598345823470 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598345823478 : Closed e598345823478 ∧ code e598345823478 = 2797369079030 := by decide
theorem cert_e598345823478 : check e598345823478 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598345823854 : Closed e598345823854 ∧ code e598345823854 = 2797369079406 := by decide
theorem cert_e598345823854 : check e598345823854 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345823866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598345823866 : Closed e598345823866 ∧ code e598345823866 = 2797369079418 := by decide
theorem cert_e598345823866 : check e598345823866 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598345824054 : Closed e598345824054 ∧ code e598345824054 = 2797369079606 := by decide
theorem cert_e598345824054 : check e598345824054 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598345824058 : Closed e598345824058 ∧ code e598345824058 = 2797369079610 := by decide
theorem cert_e598345824058 : check e598345824058 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598345824686 : Closed e598345824686 ∧ code e598345824686 = 2797369080238 := by decide
theorem cert_e598345824686 : check e598345824686 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598345824698 : Closed e598345824698 ∧ code e598345824698 = 2797369080250 := by decide
theorem cert_e598345824698 : check e598345824698 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598345824746 : Closed e598345824746 ∧ code e598345824746 = 2797369080298 := by decide
theorem cert_e598345824746 : check e598345824746 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598345824878 : Closed e598345824878 ∧ code e598345824878 = 2797369080430 := by decide
theorem cert_e598345824878 : check e598345824878 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345824890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598345824890 : Closed e598345824890 ∧ code e598345824890 = 2797369080442 := by decide
theorem cert_e598345824890 : check e598345824890 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598345825178 : Closed e598345825178 ∧ code e598345825178 = 2797369080730 := by decide
theorem cert_e598345825178 : check e598345825178 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598345825494 : Closed e598345825494 ∧ code e598345825494 = 2797369081046 := by decide
theorem cert_e598345825494 : check e598345825494 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598345825498 : Closed e598345825498 ∧ code e598345825498 = 2797369081050 := by decide
theorem cert_e598345825498 : check e598345825498 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598345825514 : Closed e598345825514 ∧ code e598345825514 = 2797369081066 := by decide
theorem cert_e598345825514 : check e598345825514 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598345825590 : Closed e598345825590 ∧ code e598345825590 = 2797369081142 := by decide
theorem cert_e598345825590 : check e598345825590 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598345825594 : Closed e598345825594 ∧ code e598345825594 = 2797369081146 := by decide
theorem cert_e598345825594 : check e598345825594 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345825690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598345825690 : Closed e598345825690 ∧ code e598345825690 = 2797369081242 := by decide
theorem cert_e598345825690 : check e598345825690 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345827294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e598345827294 : Closed e598345827294 ∧ code e598345827294 = 2797369082846 := by decide
theorem cert_e598345827294 : check e598345827294 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345827310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e598345827310 : Closed e598345827310 ∧ code e598345827310 = 2797369082862 := by decide
theorem cert_e598345827310 : check e598345827310 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598345829230 : Closed e598345829230 ∧ code e598345829230 = 2797369084782 := by decide
theorem cert_e598345829230 : check e598345829230 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598345829238 : Closed e598345829238 ∧ code e598345829238 = 2797369084790 := by decide
theorem cert_e598345829238 : check e598345829238 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598345829294 : Closed e598345829294 ∧ code e598345829294 = 2797369084846 := by decide
theorem cert_e598345829294 : check e598345829294 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598345829306 : Closed e598345829306 ∧ code e598345829306 = 2797369084858 := by decide
theorem cert_e598345829306 : check e598345829306 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598345829334 : Closed e598345829334 ∧ code e598345829334 = 2797369084886 := by decide
theorem cert_e598345829334 : check e598345829334 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598345829338 : Closed e598345829338 ∧ code e598345829338 = 2797369084890 := by decide
theorem cert_e598345829338 : check e598345829338 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598345829614 : Closed e598345829614 ∧ code e598345829614 = 2797369085166 := by decide
theorem cert_e598345829614 : check e598345829614 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598345829622 : Closed e598345829622 ∧ code e598345829622 = 2797369085174 := by decide
theorem cert_e598345829622 : check e598345829622 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345829998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598345829998 : Closed e598345829998 ∧ code e598345829998 = 2797369085550 := by decide
theorem cert_e598345829998 : check e598345829998 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345830010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598345830010 : Closed e598345830010 ∧ code e598345830010 = 2797369085562 := by decide
theorem cert_e598345830010 : check e598345830010 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345830198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598345830198 : Closed e598345830198 ∧ code e598345830198 = 2797369085750 := by decide
theorem cert_e598345830198 : check e598345830198 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345830202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598345830202 : Closed e598345830202 ∧ code e598345830202 = 2797369085754 := by decide
theorem cert_e598345830202 : check e598345830202 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345834974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e598345834974 : Closed e598345834974 ∧ code e598345834974 = 2797369090526 := by decide
theorem cert_e598345834974 : check e598345834974 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345834998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e598345834998 : Closed e598345834998 ∧ code e598345834998 = 2797369090550 := by decide
theorem cert_e598345834998 : check e598345834998 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345835950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598345835950 : Closed e598345835950 ∧ code e598345835950 = 2797369091502 := by decide
theorem cert_e598345835950 : check e598345835950 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345835962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598345835962 : Closed e598345835962 ∧ code e598345835962 = 2797369091514 := by decide
theorem cert_e598345835962 : check e598345835962 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345836010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598345836010 : Closed e598345836010 ∧ code e598345836010 = 2797369091562 := by decide
theorem cert_e598345836010 : check e598345836010 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345836142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598345836142 : Closed e598345836142 ∧ code e598345836142 = 2797369091694 := by decide
theorem cert_e598345836142 : check e598345836142 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345836154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598345836154 : Closed e598345836154 ∧ code e598345836154 = 2797369091706 := by decide
theorem cert_e598345836154 : check e598345836154 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345836442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598345836442 : Closed e598345836442 ∧ code e598345836442 = 2797369091994 := by decide
theorem cert_e598345836442 : check e598345836442 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345838830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e598345838830 : Closed e598345838830 ∧ code e598345838830 = 2797369094382 := by decide
theorem cert_e598345838830 : check e598345838830 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345838838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e598345838838 : Closed e598345838838 ∧ code e598345838838 = 2797369094390 := by decide
theorem cert_e598345838838 : check e598345838838 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345839318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598345839318 : Closed e598345839318 ∧ code e598345839318 = 2797369094870 := by decide
theorem cert_e598345839318 : check e598345839318 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345839322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598345839322 : Closed e598345839322 ∧ code e598345839322 = 2797369094874 := by decide
theorem cert_e598345839322 : check e598345839322 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345839338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598345839338 : Closed e598345839338 ∧ code e598345839338 = 2797369094890 := by decide
theorem cert_e598345839338 : check e598345839338 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345839414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598345839414 : Closed e598345839414 ∧ code e598345839414 = 2797369094966 := by decide
theorem cert_e598345839414 : check e598345839414 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345839418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598345839418 : Closed e598345839418 ∧ code e598345839418 = 2797369094970 := by decide
theorem cert_e598345839418 : check e598345839418 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345839514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598345839514 : Closed e598345839514 ∧ code e598345839514 = 2797369095066 := by decide
theorem cert_e598345839514 : check e598345839514 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345976686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598345976686 : Closed e598345976686 ∧ code e598345976686 = 2797369232238 := by decide
theorem cert_e598345976686 : check e598345976686 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345976694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598345976694 : Closed e598345976694 ∧ code e598345976694 = 2797369232246 := by decide
theorem cert_e598345976694 : check e598345976694 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345976750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598345976750 : Closed e598345976750 ∧ code e598345976750 = 2797369232302 := by decide
theorem cert_e598345976750 : check e598345976750 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345976762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598345976762 : Closed e598345976762 ∧ code e598345976762 = 2797369232314 := by decide
theorem cert_e598345976762 : check e598345976762 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345976790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598345976790 : Closed e598345976790 ∧ code e598345976790 = 2797369232342 := by decide
theorem cert_e598345976790 : check e598345976790 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345976794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598345976794 : Closed e598345976794 ∧ code e598345976794 = 2797369232346 := by decide
theorem cert_e598345976794 : check e598345976794 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345977070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598345977070 : Closed e598345977070 ∧ code e598345977070 = 2797369232622 := by decide
theorem cert_e598345977070 : check e598345977070 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345977078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598345977078 : Closed e598345977078 ∧ code e598345977078 = 2797369232630 := by decide
theorem cert_e598345977078 : check e598345977078 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345977454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598345977454 : Closed e598345977454 ∧ code e598345977454 = 2797369233006 := by decide
theorem cert_e598345977454 : check e598345977454 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345977466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598345977466 : Closed e598345977466 ∧ code e598345977466 = 2797369233018 := by decide
theorem cert_e598345977466 : check e598345977466 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345977654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598345977654 : Closed e598345977654 ∧ code e598345977654 = 2797369233206 := by decide
theorem cert_e598345977654 : check e598345977654 [[],[.left],[],[]] .sourceHead = true := by decide
def e598345977658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598345977658 : Closed e598345977658 ∧ code e598345977658 = 2797369233210 := by decide
theorem cert_e598345977658 : check e598345977658 [[],[.left],[],[]] .sourceHead = true := by decide
def e598346307294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e598346307294 : Closed e598346307294 ∧ code e598346307294 = 2797369562846 := by decide
theorem cert_e598346307294 : check e598346307294 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598346307318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e598346307318 : Closed e598346307318 ∧ code e598346307318 = 2797369562870 := by decide
theorem cert_e598346307318 : check e598346307318 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e598346307422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e598346307422 : Closed e598346307422 ∧ code e598346307422 = 2797369562974 := by decide
theorem cert_e598346307422 : check e598346307422 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e598346307450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e598346307450 : Closed e598346307450 ∧ code e598346307450 = 2797369563002 := by decide
private def t_e598346307450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e598346307450 : ¬ IsSelfInterpreter e598346307450 :=
  wSource (t := t_e598346307450) (replay_sound (ps := []) (t := e598346307450) (by decide)) (by decide)
def e598346307542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e598346307542 : Closed e598346307542 ∧ code e598346307542 = 2797369563094 := by decide
theorem cert_e598346307542 : check e598346307542 [[],[.left],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e598346307546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e598346307546 : Closed e598346307546 ∧ code e598346307546 = 2797369563098 := by decide
private def t_e598346307546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e598346307546 : ¬ IsSelfInterpreter e598346307546 :=
  wSource (t := t_e598346307546) (replay_sound (ps := []) (t := e598346307546) (by decide)) (by decide)
def e598346308062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e598346308062 : Closed e598346308062 ∧ code e598346308062 = 2797369563614 := by decide
theorem cert_e598346308062 : check e598346308062 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e598346308086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e598346308086 : Closed e598346308086 ∧ code e598346308086 = 2797369563638 := by decide
theorem cert_e598346308086 : check e598346308086 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e598346308830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e598346308830 : Closed e598346308830 ∧ code e598346308830 = 2797369564382 := by decide
theorem cert_e598346308830 : check e598346308830 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e598346308858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e598346308858 : Closed e598346308858 ∧ code e598346308858 = 2797369564410 := by decide
theorem cert_e598346308858 : check e598346308858 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e598346309430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e598346309430 : Closed e598346309430 ∧ code e598346309430 = 2797369564982 := by decide
theorem cert_e598346309430 : check e598346309430 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e598346309434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e598346309434 : Closed e598346309434 ∧ code e598346309434 = 2797369564986 := by decide
theorem cert_e598346309434 : check e598346309434 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e598346324206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e598346324206 : Closed e598346324206 ∧ code e598346324206 = 2797369579758 := by decide
def e598346324214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e598346324214 : Closed e598346324214 ∧ code e598346324214 = 2797369579766 := by decide
theorem cert_e598346324214 : check e598346324214 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598346324766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e598346324766 : Closed e598346324766 ∧ code e598346324766 = 2797369580318 := by decide
theorem cert_e598346324766 : check e598346324766 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e598346324878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e598346324878 : Closed e598346324878 ∧ code e598346324878 = 2797369580430 := by decide
private def t_e598346324878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e598346324878 : ¬ IsSelfInterpreter e598346324878 :=
  wSource (t := t_e598346324878) (replay_sound (ps := []) (t := e598346324878) (by decide)) (by decide)
def e598346325102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e598346325102 : Closed e598346325102 ∧ code e598346325102 = 2797369580654 := by decide
theorem cert_e598346325102 : checkPay e598346325102 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e598346325114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e598346325114 : Closed e598346325114 ∧ code e598346325114 = 2797369580666 := by decide
theorem cert_e598346325114 : check e598346325114 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598346325278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e598346325278 : Closed e598346325278 ∧ code e598346325278 = 2797369580830 := by decide
theorem cert_e598346325278 : check e598346325278 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e598346325446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e598346325446 : Closed e598346325446 ∧ code e598346325446 = 2797369580998 := by decide
theorem cert_e598346325446 : checkPay e598346325446 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.right,.under,.under,.left,.right,.under,.left]] = true := by decide
def e598346325558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598346325558 : Closed e598346325558 ∧ code e598346325558 = 2797369581110 := by decide
theorem cert_e598346325558 : check e598346325558 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e598346325562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598346325562 : Closed e598346325562 ∧ code e598346325562 = 2797369581114 := by decide
theorem cert_e598346325562 : check e598346325562 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598346325646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598346325646 : Closed e598346325646 ∧ code e598346325646 = 2797369581198 := by decide
private def t_e598346325646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e598346325646 : ¬ IsSelfInterpreter e598346325646 :=
  wSource (t := t_e598346325646) (replay_sound (ps := []) (t := e598346325646) (by decide)) (by decide)
def e598346325702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598346325702 : Closed e598346325702 ∧ code e598346325702 = 2797369581254 := by decide
theorem cert_e598346325702 : check e598346325702 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e598346327838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e598346327838 : Closed e598346327838 ∧ code e598346327838 = 2797369583390 := by decide
theorem cert_e598346327838 : check e598346327838 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598346327950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e598346327950 : Closed e598346327950 ∧ code e598346327950 = 2797369583502 := by decide
theorem cert_e598346327950 : check e598346327950 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598346330910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e598346330910 : Closed e598346330910 ∧ code e598346330910 = 2797369586462 := by decide
theorem cert_e598346330910 : checkPay e598346330910 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left]] 0 [[]] = true := by decide
def e598346331078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e598346331078 : Closed e598346331078 ∧ code e598346331078 = 2797369586630 := by decide
theorem cert_e598346331078 : check e598346331078 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e598346332558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598346332558 : Closed e598346332558 ∧ code e598346332558 = 2797369588110 := by decide
theorem cert_e598346332558 : check e598346332558 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e598346332614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598346332614 : Closed e598346332614 ∧ code e598346332614 = 2797369588166 := by decide
theorem cert_e598346332614 : check e598346332614 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e598354177466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e598354177466 : Closed e598354177466 ∧ code e598354177466 = 2797377433018 := by decide
def e598354177498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e598354177498 : Closed e598354177498 ∧ code e598354177498 = 2797377433050 := by decide
def e598354177722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e598354177722 : Closed e598354177722 ∧ code e598354177722 = 2797377433274 := by decide
def e598354177770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e598354177770 : Closed e598354177770 ∧ code e598354177770 = 2797377433322 := by decide
private def t_e598354177770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem cert_e598354177770 : ¬ IsSelfInterpreter e598354177770 :=
  wSource (t := t_e598354177770) (replay_sound (ps := []) (t := e598354177770) (by decide)) (by decide)
def e598354177882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e598354177882 : Closed e598354177882 ∧ code e598354177882 = 2797377433434 := by decide
def e598354177898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e598354177898 : Closed e598354177898 ∧ code e598354177898 = 2797377433450 := by decide
private def t_e598354177898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e598354177898 : ¬ IsSelfInterpreter e598354177898 :=
  wSource (t := t_e598354177898) (replay_sound (ps := []) (t := e598354177898) (by decide)) (by decide)
def e598354179002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e598354179002 : Closed e598354179002 ∧ code e598354179002 = 2797377434554 := by decide
def e598354179034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e598354179034 : Closed e598354179034 ∧ code e598354179034 = 2797377434586 := by decide
def e598354180538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e598354180538 : Closed e598354180538 ∧ code e598354180538 = 2797377436090 := by decide
def e598354180586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e598354180586 : Closed e598354180586 ∧ code e598354180586 = 2797377436138 := by decide
def e598354181338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e598354181338 : Closed e598354181338 ∧ code e598354181338 = 2797377436890 := by decide
def e598354181354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e598354181354 : Closed e598354181354 ∧ code e598354181354 = 2797377436906 := by decide
def e598354430830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598354430830 : Closed e598354430830 ∧ code e598354430830 = 2797377686382 := by decide
private def t_e598354430830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e598354430830 : ¬ IsSelfInterpreter e598354430830 :=
  wSource (t := t_e598354430830) (replay_sound (ps := []) (t := e598354430830) (by decide)) (by decide)
def e598354430838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598354430838 : Closed e598354430838 ∧ code e598354430838 = 2797377686390 := by decide
private def t_e598354430838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e598354430838 : ¬ IsSelfInterpreter e598354430838 :=
  wSource (t := t_e598354430838) (replay_sound (ps := []) (t := e598354430838) (by decide)) (by decide)
def e598354430894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598354430894 : Closed e598354430894 ∧ code e598354430894 = 2797377686446 := by decide
private def t_e598354430894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e598354430894 : ¬ IsSelfInterpreter e598354430894 :=
  wSource (t := t_e598354430894) (replay_sound (ps := []) (t := e598354430894) (by decide)) (by decide)
def e598354430906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598354430906 : Closed e598354430906 ∧ code e598354430906 = 2797377686458 := by decide
private def t_e598354430906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e598354430906 : ¬ IsSelfInterpreter e598354430906 :=
  wSource (t := t_e598354430906) (replay_sound (ps := []) (t := e598354430906) (by decide)) (by decide)
def e598354430934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598354430934 : Closed e598354430934 ∧ code e598354430934 = 2797377686486 := by decide
private def t_e598354430934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e598354430934 : ¬ IsSelfInterpreter e598354430934 :=
  wSource (t := t_e598354430934) (replay_sound (ps := []) (t := e598354430934) (by decide)) (by decide)
def e598354430938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598354430938 : Closed e598354430938 ∧ code e598354430938 = 2797377686490 := by decide
private def t_e598354430938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e598354430938 : ¬ IsSelfInterpreter e598354430938 :=
  wSource (t := t_e598354430938) (replay_sound (ps := []) (t := e598354430938) (by decide)) (by decide)
def e598354431214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598354431214 : Closed e598354431214 ∧ code e598354431214 = 2797377686766 := by decide
private def t_e598354431214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e598354431214 : ¬ IsSelfInterpreter e598354431214 :=
  wSource (t := t_e598354431214) (replay_sound (ps := []) (t := e598354431214) (by decide)) (by decide)
def e598354431222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598354431222 : Closed e598354431222 ∧ code e598354431222 = 2797377686774 := by decide
private def t_e598354431222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e598354431222 : ¬ IsSelfInterpreter e598354431222 :=
  wSource (t := t_e598354431222) (replay_sound (ps := []) (t := e598354431222) (by decide)) (by decide)
def e598354431598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598354431598 : Closed e598354431598 ∧ code e598354431598 = 2797377687150 := by decide
private def t_e598354431598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e598354431598 : ¬ IsSelfInterpreter e598354431598 :=
  wSource (t := t_e598354431598) (replay_sound (ps := []) (t := e598354431598) (by decide)) (by decide)
def e598354431610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598354431610 : Closed e598354431610 ∧ code e598354431610 = 2797377687162 := by decide
private def t_e598354431610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e598354431610 : ¬ IsSelfInterpreter e598354431610 :=
  wSource (t := t_e598354431610) (replay_sound (ps := []) (t := e598354431610) (by decide)) (by decide)
def e598354431798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598354431798 : Closed e598354431798 ∧ code e598354431798 = 2797377687350 := by decide
private def t_e598354431798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e598354431798 : ¬ IsSelfInterpreter e598354431798 :=
  wSource (t := t_e598354431798) (replay_sound (ps := []) (t := e598354431798) (by decide)) (by decide)
def e598354431802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598354431802 : Closed e598354431802 ∧ code e598354431802 = 2797377687354 := by decide
private def t_e598354431802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e598354431802 : ¬ IsSelfInterpreter e598354431802 :=
  wSource (t := t_e598354431802) (replay_sound (ps := []) (t := e598354431802) (by decide)) (by decide)
end Blc.Floor41
