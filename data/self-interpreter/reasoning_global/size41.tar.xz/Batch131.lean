import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605640920886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605640920886 : Closed e605640920886 ∧ code e605640920886 = 2804664176438 := by decide
theorem cert_e605640920886 : check e605640920886 [[],[]] .smaller = true := by decide
def e605640920890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605640920890 : Closed e605640920890 ∧ code e605640920890 = 2804664176442 := by decide
theorem cert_e605640920890 : check e605640920890 [[],[]] .smaller = true := by decide
def e605640921022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e605640921022 : Closed e605640921022 ∧ code e605640921022 = 2804664176574 := by decide
theorem cert_e605640921022 : check e605640921022 [[],[]] .chain = true := by decide
def e605640921054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e605640921054 : Closed e605640921054 ∧ code e605640921054 = 2804664176606 := by decide
theorem cert_e605640921054 : check e605640921054 [[],[]] .chain = true := by decide
def e605640928734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605640928734 : Closed e605640928734 ∧ code e605640928734 = 2804664184286 := by decide
theorem cert_e605640928734 : check e605640928734 [[],[]] .chain = true := by decide
def e605640928750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605640928750 : Closed e605640928750 ∧ code e605640928750 = 2804664184302 := by decide
theorem cert_e605640928750 : check e605640928750 [[],[]] .chain = true := by decide
def e605640928814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605640928814 : Closed e605640928814 ∧ code e605640928814 = 2804664184366 := by decide
theorem cert_e605640928814 : check e605640928814 [[],[]] .smaller = true := by decide
def e605640928990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605640928990 : Closed e605640928990 ∧ code e605640928990 = 2804664184542 := by decide
theorem cert_e605640928990 : check e605640928990 [[],[]] .chain = true := by decide
def e605640928994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605640928994 : Closed e605640928994 ∧ code e605640928994 = 2804664184546 := by decide
theorem cert_e605640928994 : check e605640928994 [[],[]] .smaller = true := by decide
def e605640929006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e605640929006 : Closed e605640929006 ∧ code e605640929006 = 2804664184558 := by decide
theorem cert_e605640929006 : check e605640929006 [[],[]] .smaller = true := by decide
def e605640929014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605640929014 : Closed e605640929014 ∧ code e605640929014 = 2804664184566 := by decide
theorem cert_e605640929014 : check e605640929014 [[],[]] .chain = true := by decide
def e605640929046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605640929046 : Closed e605640929046 ∧ code e605640929046 = 2804664184598 := by decide
theorem cert_e605640929046 : check e605640929046 [[],[]] .smaller = true := by decide
def e605640929118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605640929118 : Closed e605640929118 ∧ code e605640929118 = 2804664184670 := by decide
theorem cert_e605640929118 : check e605640929118 [[],[]] .chain = true := by decide
def e605640929122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605640929122 : Closed e605640929122 ∧ code e605640929122 = 2804664184674 := by decide
theorem cert_e605640929122 : check e605640929122 [[],[]] .smaller = true := by decide
def e605640929134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e605640929134 : Closed e605640929134 ∧ code e605640929134 = 2804664184686 := by decide
theorem cert_e605640929134 : check e605640929134 [[],[]] .smaller = true := by decide
def e605640929142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e605640929142 : Closed e605640929142 ∧ code e605640929142 = 2804664184694 := by decide
theorem cert_e605640929142 : check e605640929142 [[],[]] .smaller = true := by decide
def e605640929146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605640929146 : Closed e605640929146 ∧ code e605640929146 = 2804664184698 := by decide
theorem cert_e605640929146 : check e605640929146 [[],[]] .chain = true := by decide
def e605640929198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605640929198 : Closed e605640929198 ∧ code e605640929198 = 2804664184750 := by decide
theorem cert_e605640929198 : check e605640929198 [[],[]] .chain = true := by decide
def e605640929206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605640929206 : Closed e605640929206 ∧ code e605640929206 = 2804664184758 := by decide
theorem cert_e605640929206 : check e605640929206 [[],[]] .chain = true := by decide
def e605640929210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605640929210 : Closed e605640929210 ∧ code e605640929210 = 2804664184762 := by decide
theorem cert_e605640929210 : check e605640929210 [[],[]] .chain = true := by decide
def e605640930270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605640930270 : Closed e605640930270 ∧ code e605640930270 = 2804664185822 := by decide
theorem cert_e605640930270 : check e605640930270 [[],[]] .chain = true := by decide
def e605640930286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605640930286 : Closed e605640930286 ∧ code e605640930286 = 2804664185838 := by decide
theorem cert_e605640930286 : check e605640930286 [[],[]] .chain = true := by decide
def e605640931390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e605640931390 : Closed e605640931390 ∧ code e605640931390 = 2804664186942 := by decide
theorem cert_e605640931390 : check e605640931390 [[],[]] .smaller = true := by decide
def e605640931806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605640931806 : Closed e605640931806 ∧ code e605640931806 = 2804664187358 := by decide
theorem cert_e605640931806 : check e605640931806 [[],[]] .chain = true := by decide
def e605640931810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605640931810 : Closed e605640931810 ∧ code e605640931810 = 2804664187362 := by decide
theorem cert_e605640931810 : check e605640931810 [[],[]] .smaller = true := by decide
def e605640931822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e605640931822 : Closed e605640931822 ∧ code e605640931822 = 2804664187374 := by decide
theorem cert_e605640931822 : check e605640931822 [[],[]] .smaller = true := by decide
def e605640931830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605640931830 : Closed e605640931830 ∧ code e605640931830 = 2804664187382 := by decide
theorem cert_e605640931830 : check e605640931830 [[],[]] .chain = true := by decide
def e605640932382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e605640932382 : Closed e605640932382 ∧ code e605640932382 = 2804664187934 := by decide
theorem cert_e605640932382 : check e605640932382 [[],[]] .smaller = true := by decide
def e605640932574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605640932574 : Closed e605640932574 ∧ code e605640932574 = 2804664188126 := by decide
theorem cert_e605640932574 : check e605640932574 [[],[]] .chain = true := by decide
def e605640932578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605640932578 : Closed e605640932578 ∧ code e605640932578 = 2804664188130 := by decide
theorem cert_e605640932578 : check e605640932578 [[],[]] .smaller = true := by decide
def e605640932590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e605640932590 : Closed e605640932590 ∧ code e605640932590 = 2804664188142 := by decide
theorem cert_e605640932590 : check e605640932590 [[],[]] .smaller = true := by decide
def e605640932598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e605640932598 : Closed e605640932598 ∧ code e605640932598 = 2804664188150 := by decide
theorem cert_e605640932598 : check e605640932598 [[],[]] .smaller = true := by decide
def e605640932602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605640932602 : Closed e605640932602 ∧ code e605640932602 = 2804664188154 := by decide
theorem cert_e605640932602 : check e605640932602 [[],[]] .chain = true := by decide
def e605640932974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605640932974 : Closed e605640932974 ∧ code e605640932974 = 2804664188526 := by decide
theorem cert_e605640932974 : check e605640932974 [[],[]] .chain = true := by decide
def e605640932982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605640932982 : Closed e605640932982 ∧ code e605640932982 = 2804664188534 := by decide
theorem cert_e605640932982 : check e605640932982 [[],[]] .chain = true := by decide
def e605640932986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605640932986 : Closed e605640932986 ∧ code e605640932986 = 2804664188538 := by decide
theorem cert_e605640932986 : check e605640932986 [[],[]] .chain = true := by decide
def e605640955438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605640955438 : Closed e605640955438 ∧ code e605640955438 = 2804664210990 := by decide
theorem cert_e605640955438 : check e605640955438 [[],[]] .smaller = true := by decide
def e605640955614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605640955614 : Closed e605640955614 ∧ code e605640955614 = 2804664211166 := by decide
theorem cert_e605640955614 : check e605640955614 [[],[]] .chain = true := by decide
def e605640955618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605640955618 : Closed e605640955618 ∧ code e605640955618 = 2804664211170 := by decide
theorem cert_e605640955618 : check e605640955618 [[],[]] .smaller = true := by decide
def e605640955630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605640955630 : Closed e605640955630 ∧ code e605640955630 = 2804664211182 := by decide
theorem cert_e605640955630 : check e605640955630 [[],[]] .smaller = true := by decide
def e605640955638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605640955638 : Closed e605640955638 ∧ code e605640955638 = 2804664211190 := by decide
theorem cert_e605640955638 : check e605640955638 [[],[]] .chain = true := by decide
def e605640955742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605640955742 : Closed e605640955742 ∧ code e605640955742 = 2804664211294 := by decide
theorem cert_e605640955742 : check e605640955742 [[],[]] .chain = true := by decide
def e605640955770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605640955770 : Closed e605640955770 ∧ code e605640955770 = 2804664211322 := by decide
theorem cert_e605640955770 : check e605640955770 [[],[]] .chain = true := by decide
def e605640955786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605640955786 : Closed e605640955786 ∧ code e605640955786 = 2804664211338 := by decide
theorem cert_e605640955786 : check e605640955786 [[],[]] .smaller = true := by decide
def e605640955810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605640955810 : Closed e605640955810 ∧ code e605640955810 = 2804664211362 := by decide
theorem cert_e605640955810 : check e605640955810 [[],[]] .smaller = true := by decide
def e605640955822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605640955822 : Closed e605640955822 ∧ code e605640955822 = 2804664211374 := by decide
theorem cert_e605640955822 : check e605640955822 [[],[]] .smaller = true := by decide
def e605640955834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605640955834 : Closed e605640955834 ∧ code e605640955834 = 2804664211386 := by decide
theorem cert_e605640955834 : check e605640955834 [[],[]] .smaller = true := by decide
def e605640955862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605640955862 : Closed e605640955862 ∧ code e605640955862 = 2804664211414 := by decide
theorem cert_e605640955862 : check e605640955862 [[],[]] .chain = true := by decide
def e605640955866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605640955866 : Closed e605640955866 ∧ code e605640955866 = 2804664211418 := by decide
theorem cert_e605640955866 : check e605640955866 [[],[]] .chain = true := by decide
def e605640955966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e605640955966 : Closed e605640955966 ∧ code e605640955966 = 2804664211518 := by decide
theorem cert_e605640955966 : check e605640955966 [[],[]] .smaller = true := by decide
def e605640956382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605640956382 : Closed e605640956382 ∧ code e605640956382 = 2804664211934 := by decide
theorem cert_e605640956382 : check e605640956382 [[],[]] .chain = true := by decide
def e605640956386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605640956386 : Closed e605640956386 ∧ code e605640956386 = 2804664211938 := by decide
theorem cert_e605640956386 : check e605640956386 [[],[]] .smaller = true := by decide
def e605640956398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605640956398 : Closed e605640956398 ∧ code e605640956398 = 2804664211950 := by decide
theorem cert_e605640956398 : check e605640956398 [[],[]] .smaller = true := by decide
def e605640956406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605640956406 : Closed e605640956406 ∧ code e605640956406 = 2804664211958 := by decide
theorem cert_e605640956406 : check e605640956406 [[],[]] .chain = true := by decide
def e605640957150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605640957150 : Closed e605640957150 ∧ code e605640957150 = 2804664212702 := by decide
theorem cert_e605640957150 : check e605640957150 [[],[]] .chain = true := by decide
def e605640957178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605640957178 : Closed e605640957178 ∧ code e605640957178 = 2804664212730 := by decide
theorem cert_e605640957178 : check e605640957178 [[],[]] .chain = true := by decide
def e605640957454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e605640957454 : Closed e605640957454 ∧ code e605640957454 = 2804664213006 := by decide
theorem cert_e605640957454 : check e605640957454 [[],[]] .smaller = true := by decide
def e605640957502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605640957502 : Closed e605640957502 ∧ code e605640957502 = 2804664213054 := by decide
theorem cert_e605640957502 : check e605640957502 [[],[]] .chain = true := by decide
def e605640957538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605640957538 : Closed e605640957538 ∧ code e605640957538 = 2804664213090 := by decide
theorem cert_e605640957538 : check e605640957538 [[],[]] .smaller = true := by decide
def e605640957550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605640957550 : Closed e605640957550 ∧ code e605640957550 = 2804664213102 := by decide
theorem cert_e605640957550 : check e605640957550 [[],[]] .smaller = true := by decide
def e605640957562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605640957562 : Closed e605640957562 ∧ code e605640957562 = 2804664213114 := by decide
theorem cert_e605640957562 : check e605640957562 [[],[]] .smaller = true := by decide
def e605640957726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605640957726 : Closed e605640957726 ∧ code e605640957726 = 2804664213278 := by decide
theorem cert_e605640957726 : check e605640957726 [[],[]] .chain = true := by decide
def e605640957750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605640957750 : Closed e605640957750 ∧ code e605640957750 = 2804664213302 := by decide
theorem cert_e605640957750 : check e605640957750 [[],[]] .chain = true := by decide
def e605640957754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605640957754 : Closed e605640957754 ∧ code e605640957754 = 2804664213306 := by decide
theorem cert_e605640957754 : check e605640957754 [[],[]] .chain = true := by decide
def e605640967102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e605640967102 : Closed e605640967102 ∧ code e605640967102 = 2804664222654 := by decide
theorem cert_e605640967102 : check e605640967102 [[],[]] .chain = true := by decide
def e605640967158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e605640967158 : Closed e605640967158 ∧ code e605640967158 = 2804664222710 := by decide
theorem cert_e605640967158 : check e605640967158 [[],[]] .chain = true := by decide
def e605640968982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605640968982 : Closed e605640968982 ∧ code e605640968982 = 2804664224534 := by decide
theorem cert_e605640968982 : check e605640968982 [[],[]] .smaller = true := by decide
def e605640969054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605640969054 : Closed e605640969054 ∧ code e605640969054 = 2804664224606 := by decide
theorem cert_e605640969054 : check e605640969054 [[],[]] .chain = true := by decide
def e605640969058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605640969058 : Closed e605640969058 ∧ code e605640969058 = 2804664224610 := by decide
theorem cert_e605640969058 : check e605640969058 [[],[]] .smaller = true := by decide
def e605640969070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605640969070 : Closed e605640969070 ∧ code e605640969070 = 2804664224622 := by decide
theorem cert_e605640969070 : check e605640969070 [[],[]] .smaller = true := by decide
def e605640969078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605640969078 : Closed e605640969078 ∧ code e605640969078 = 2804664224630 := by decide
theorem cert_e605640969078 : check e605640969078 [[],[]] .smaller = true := by decide
def e605640969082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605640969082 : Closed e605640969082 ∧ code e605640969082 = 2804664224634 := by decide
theorem cert_e605640969082 : check e605640969082 [[],[]] .chain = true := by decide
def e605640969098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605640969098 : Closed e605640969098 ∧ code e605640969098 = 2804664224650 := by decide
theorem cert_e605640969098 : check e605640969098 [[],[]] .smaller = true := by decide
def e605640969122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605640969122 : Closed e605640969122 ∧ code e605640969122 = 2804664224674 := by decide
theorem cert_e605640969122 : check e605640969122 [[],[]] .smaller = true := by decide
def e605640969134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605640969134 : Closed e605640969134 ∧ code e605640969134 = 2804664224686 := by decide
theorem cert_e605640969134 : check e605640969134 [[],[]] .smaller = true := by decide
def e605640969146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605640969146 : Closed e605640969146 ∧ code e605640969146 = 2804664224698 := by decide
theorem cert_e605640969146 : check e605640969146 [[],[]] .smaller = true := by decide
def e605640969174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605640969174 : Closed e605640969174 ∧ code e605640969174 = 2804664224726 := by decide
theorem cert_e605640969174 : check e605640969174 [[],[]] .smaller = true := by decide
def e605640969178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605640969178 : Closed e605640969178 ∧ code e605640969178 = 2804664224730 := by decide
theorem cert_e605640969178 : check e605640969178 [[],[]] .smaller = true := by decide
def e605640969194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605640969194 : Closed e605640969194 ∧ code e605640969194 = 2804664224746 := by decide
theorem cert_e605640969194 : check e605640969194 [[],[]] .chain = true := by decide
def e605640969246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e605640969246 : Closed e605640969246 ∧ code e605640969246 = 2804664224798 := by decide
theorem cert_e605640969246 : check e605640969246 [[],[]] .smaller = true := by decide
def e605640969438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605640969438 : Closed e605640969438 ∧ code e605640969438 = 2804664224990 := by decide
theorem cert_e605640969438 : check e605640969438 [[],[]] .chain = true := by decide
def e605640969442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605640969442 : Closed e605640969442 ∧ code e605640969442 = 2804664224994 := by decide
theorem cert_e605640969442 : check e605640969442 [[],[]] .smaller = true := by decide
def e605640969454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605640969454 : Closed e605640969454 ∧ code e605640969454 = 2804664225006 := by decide
theorem cert_e605640969454 : check e605640969454 [[],[]] .smaller = true := by decide
def e605640969462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605640969462 : Closed e605640969462 ∧ code e605640969462 = 2804664225014 := by decide
theorem cert_e605640969462 : check e605640969462 [[],[]] .smaller = true := by decide
def e605640969466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605640969466 : Closed e605640969466 ∧ code e605640969466 = 2804664225018 := by decide
theorem cert_e605640969466 : check e605640969466 [[],[]] .chain = true := by decide
def e605640969742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e605640969742 : Closed e605640969742 ∧ code e605640969742 = 2804664225294 := by decide
theorem cert_e605640969742 : check e605640969742 [[],[]] .smaller = true := by decide
def e605640969790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605640969790 : Closed e605640969790 ∧ code e605640969790 = 2804664225342 := by decide
theorem cert_e605640969790 : check e605640969790 [[],[]] .chain = true := by decide
def e605640969826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605640969826 : Closed e605640969826 ∧ code e605640969826 = 2804664225378 := by decide
theorem cert_e605640969826 : check e605640969826 [[],[]] .smaller = true := by decide
def e605640969838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605640969838 : Closed e605640969838 ∧ code e605640969838 = 2804664225390 := by decide
theorem cert_e605640969838 : check e605640969838 [[],[]] .smaller = true := by decide
def e605640969850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605640969850 : Closed e605640969850 ∧ code e605640969850 = 2804664225402 := by decide
theorem cert_e605640969850 : check e605640969850 [[],[]] .smaller = true := by decide
def e605640970038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605640970038 : Closed e605640970038 ∧ code e605640970038 = 2804664225590 := by decide
theorem cert_e605640970038 : check e605640970038 [[],[]] .smaller = true := by decide
def e605640970042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605640970042 : Closed e605640970042 ∧ code e605640970042 = 2804664225594 := by decide
theorem cert_e605640970042 : check e605640970042 [[],[]] .smaller = true := by decide
def e605640970126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605640970126 : Closed e605640970126 ∧ code e605640970126 = 2804664225678 := by decide
theorem cert_e605640970126 : check e605640970126 [[],[]] .chain = true := by decide
def e605640970138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605640970138 : Closed e605640970138 ∧ code e605640970138 = 2804664225690 := by decide
theorem cert_e605640970138 : check e605640970138 [[],[]] .chain = true := by decide
def e605640974814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605640974814 : Closed e605640974814 ∧ code e605640974814 = 2804664230366 := by decide
theorem cert_e605640974814 : check e605640974814 [[],[]] .chain = true := by decide
def e605640974838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605640974838 : Closed e605640974838 ∧ code e605640974838 = 2804664230390 := by decide
theorem cert_e605640974838 : check e605640974838 [[],[]] .chain = true := by decide
def e605640975790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605640975790 : Closed e605640975790 ∧ code e605640975790 = 2804664231342 := by decide
theorem cert_e605640975790 : check e605640975790 [[],[]] .chain = true := by decide
def e605640975798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605640975798 : Closed e605640975798 ∧ code e605640975798 = 2804664231350 := by decide
theorem cert_e605640975798 : check e605640975798 [[],[]] .chain = true := by decide
def e605640975802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605640975802 : Closed e605640975802 ∧ code e605640975802 = 2804664231354 := by decide
theorem cert_e605640975802 : check e605640975802 [[],[]] .chain = true := by decide
def e605640975830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605640975830 : Closed e605640975830 ∧ code e605640975830 = 2804664231382 := by decide
theorem cert_e605640975830 : check e605640975830 [[],[]] .chain = true := by decide
def e605640975834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605640975834 : Closed e605640975834 ∧ code e605640975834 = 2804664231386 := by decide
theorem cert_e605640975834 : check e605640975834 [[],[]] .chain = true := by decide
def e605640975850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605640975850 : Closed e605640975850 ∧ code e605640975850 = 2804664231402 := by decide
theorem cert_e605640975850 : check e605640975850 [[],[]] .chain = true := by decide
def e605640975982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605640975982 : Closed e605640975982 ∧ code e605640975982 = 2804664231534 := by decide
theorem cert_e605640975982 : check e605640975982 [[],[]] .chain = true := by decide
def e605640975990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605640975990 : Closed e605640975990 ∧ code e605640975990 = 2804664231542 := by decide
theorem cert_e605640975990 : check e605640975990 [[],[]] .chain = true := by decide
def e605640975994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605640975994 : Closed e605640975994 ∧ code e605640975994 = 2804664231546 := by decide
theorem cert_e605640975994 : check e605640975994 [[],[]] .chain = true := by decide
def e605640976158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605640976158 : Closed e605640976158 ∧ code e605640976158 = 2804664231710 := by decide
theorem cert_e605640976158 : check e605640976158 [[],[]] .chain = true := by decide
def e605640976182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605640976182 : Closed e605640976182 ∧ code e605640976182 = 2804664231734 := by decide
theorem cert_e605640976182 : check e605640976182 [[],[]] .chain = true := by decide
def e605640976186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605640976186 : Closed e605640976186 ∧ code e605640976186 = 2804664231738 := by decide
theorem cert_e605640976186 : check e605640976186 [[],[]] .chain = true := by decide
def e605640976270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605640976270 : Closed e605640976270 ∧ code e605640976270 = 2804664231822 := by decide
theorem cert_e605640976270 : check e605640976270 [[],[]] .chain = true := by decide
def e605640976282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605640976282 : Closed e605640976282 ∧ code e605640976282 = 2804664231834 := by decide
theorem cert_e605640976282 : check e605640976282 [[],[]] .chain = true := by decide
def e605641422190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605641422190 : Closed e605641422190 ∧ code e605641422190 = 2804664677742 := by decide
theorem cert_e605641422190 : check e605641422190 [[],[]] .chain = true := by decide
def e605641422198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605641422198 : Closed e605641422198 ∧ code e605641422198 = 2804664677750 := by decide
theorem cert_e605641422198 : check e605641422198 [[],[]] .chain = true := by decide
def e605641422254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605641422254 : Closed e605641422254 ∧ code e605641422254 = 2804664677806 := by decide
theorem cert_e605641422254 : check e605641422254 [[],[]] .chain = true := by decide
def e605641422266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605641422266 : Closed e605641422266 ∧ code e605641422266 = 2804664677818 := by decide
theorem cert_e605641422266 : check e605641422266 [[],[]] .chain = true := by decide
def e605641422294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605641422294 : Closed e605641422294 ∧ code e605641422294 = 2804664677846 := by decide
theorem cert_e605641422294 : check e605641422294 [[],[]] .chain = true := by decide
def e605641422298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605641422298 : Closed e605641422298 ∧ code e605641422298 = 2804664677850 := by decide
theorem cert_e605641422298 : check e605641422298 [[],[]] .chain = true := by decide
def e605641422510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605641422510 : Closed e605641422510 ∧ code e605641422510 = 2804664678062 := by decide
theorem cert_e605641422510 : check e605641422510 [[],[]] .chain = true := by decide
def e605641422522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605641422522 : Closed e605641422522 ∧ code e605641422522 = 2804664678074 := by decide
theorem cert_e605641422522 : check e605641422522 [[],[]] .chain = true := by decide
def e605641422570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605641422570 : Closed e605641422570 ∧ code e605641422570 = 2804664678122 := by decide
theorem cert_e605641422570 : check e605641422570 [[],[]] .chain = true := by decide
def e605641422678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605641422678 : Closed e605641422678 ∧ code e605641422678 = 2804664678230 := by decide
theorem cert_e605641422678 : check e605641422678 [[],[]] .chain = true := by decide
def e605641422682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605641422682 : Closed e605641422682 ∧ code e605641422682 = 2804664678234 := by decide
theorem cert_e605641422682 : check e605641422682 [[],[]] .chain = true := by decide
def e605641422698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605641422698 : Closed e605641422698 ∧ code e605641422698 = 2804664678250 := by decide
theorem cert_e605641422698 : check e605641422698 [[],[]] .chain = true := by decide
def e605641423534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605641423534 : Closed e605641423534 ∧ code e605641423534 = 2804664679086 := by decide
theorem cert_e605641423534 : check e605641423534 [[],[]] .chain = true := by decide
def e605641423546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605641423546 : Closed e605641423546 ∧ code e605641423546 = 2804664679098 := by decide
theorem cert_e605641423546 : check e605641423546 [[],[]] .chain = true := by decide
def e605641423594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605641423594 : Closed e605641423594 ∧ code e605641423594 = 2804664679146 := by decide
theorem cert_e605641423594 : check e605641423594 [[],[]] .chain = true := by decide
def e605641423786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605641423786 : Closed e605641423786 ∧ code e605641423786 = 2804664679338 := by decide
theorem cert_e605641423786 : check e605641423786 [[],[]] .chain = true := by decide
def e605641424214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605641424214 : Closed e605641424214 ∧ code e605641424214 = 2804664679766 := by decide
theorem cert_e605641424214 : check e605641424214 [[],[]] .chain = true := by decide
def e605641424218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605641424218 : Closed e605641424218 ∧ code e605641424218 = 2804664679770 := by decide
theorem cert_e605641424218 : check e605641424218 [[],[]] .chain = true := by decide
def e605641424234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605641424234 : Closed e605641424234 ∧ code e605641424234 = 2804664679786 := by decide
theorem cert_e605641424234 : check e605641424234 [[],[]] .chain = true := by decide
def e605641424298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605641424298 : Closed e605641424298 ∧ code e605641424298 = 2804664679850 := by decide
theorem cert_e605641424298 : check e605641424298 [[],[]] .chain = true := by decide
def e605641425262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e605641425262 : Closed e605641425262 ∧ code e605641425262 = 2804664680814 := by decide
theorem cert_e605641425262 : check e605641425262 [[],[]] .chain = true := by decide
def e605641425270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e605641425270 : Closed e605641425270 ∧ code e605641425270 = 2804664680822 := by decide
theorem cert_e605641425270 : check e605641425270 [[],[]] .chain = true := by decide
def e605641426798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e605641426798 : Closed e605641426798 ∧ code e605641426798 = 2804664682350 := by decide
theorem cert_e605641426798 : check e605641426798 [[],[]] .chain = true := by decide
def e605641426806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e605641426806 : Closed e605641426806 ∧ code e605641426806 = 2804664682358 := by decide
theorem cert_e605641426806 : check e605641426806 [[],[]] .chain = true := by decide
def e605641426870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e605641426870 : Closed e605641426870 ∧ code e605641426870 = 2804664682422 := by decide
theorem cert_e605641426870 : check e605641426870 [[],[]] .chain = true := by decide
def e605641428334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605641428334 : Closed e605641428334 ∧ code e605641428334 = 2804664683886 := by decide
theorem cert_e605641428334 : check e605641428334 [[],[]] .chain = true := by decide
def e605641428342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605641428342 : Closed e605641428342 ∧ code e605641428342 = 2804664683894 := by decide
theorem cert_e605641428342 : check e605641428342 [[],[]] .chain = true := by decide
def e605641428398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605641428398 : Closed e605641428398 ∧ code e605641428398 = 2804664683950 := by decide
theorem cert_e605641428398 : check e605641428398 [[],[]] .chain = true := by decide
def e605641428410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605641428410 : Closed e605641428410 ∧ code e605641428410 = 2804664683962 := by decide
theorem cert_e605641428410 : check e605641428410 [[],[]] .chain = true := by decide
def e605641428438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605641428438 : Closed e605641428438 ∧ code e605641428438 = 2804664683990 := by decide
theorem cert_e605641428438 : check e605641428438 [[],[]] .chain = true := by decide
def e605641428442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605641428442 : Closed e605641428442 ∧ code e605641428442 = 2804664683994 := by decide
theorem cert_e605641428442 : check e605641428442 [[],[]] .chain = true := by decide
def e605641428654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605641428654 : Closed e605641428654 ∧ code e605641428654 = 2804664684206 := by decide
theorem cert_e605641428654 : check e605641428654 [[],[]] .chain = true := by decide
def e605641428666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605641428666 : Closed e605641428666 ∧ code e605641428666 = 2804664684218 := by decide
theorem cert_e605641428666 : check e605641428666 [[],[]] .chain = true := by decide
def e605641428714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605641428714 : Closed e605641428714 ∧ code e605641428714 = 2804664684266 := by decide
theorem cert_e605641428714 : check e605641428714 [[],[]] .chain = true := by decide
def e605641428822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605641428822 : Closed e605641428822 ∧ code e605641428822 = 2804664684374 := by decide
theorem cert_e605641428822 : check e605641428822 [[],[]] .chain = true := by decide
def e605641428826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605641428826 : Closed e605641428826 ∧ code e605641428826 = 2804664684378 := by decide
theorem cert_e605641428826 : check e605641428826 [[],[]] .chain = true := by decide
def e605641428842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605641428842 : Closed e605641428842 ∧ code e605641428842 = 2804664684394 := by decide
theorem cert_e605641428842 : check e605641428842 [[],[]] .chain = true := by decide
def e605641429870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605641429870 : Closed e605641429870 ∧ code e605641429870 = 2804664685422 := by decide
theorem cert_e605641429870 : check e605641429870 [[],[]] .chain = true := by decide
def e605641429878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605641429878 : Closed e605641429878 ∧ code e605641429878 = 2804664685430 := by decide
theorem cert_e605641429878 : check e605641429878 [[],[]] .chain = true := by decide
def e605641429934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605641429934 : Closed e605641429934 ∧ code e605641429934 = 2804664685486 := by decide
theorem cert_e605641429934 : check e605641429934 [[],[]] .chain = true := by decide
def e605641429946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605641429946 : Closed e605641429946 ∧ code e605641429946 = 2804664685498 := by decide
theorem cert_e605641429946 : check e605641429946 [[],[]] .chain = true := by decide
def e605641429974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605641429974 : Closed e605641429974 ∧ code e605641429974 = 2804664685526 := by decide
theorem cert_e605641429974 : check e605641429974 [[],[]] .chain = true := by decide
def e605641429978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605641429978 : Closed e605641429978 ∧ code e605641429978 = 2804664685530 := by decide
theorem cert_e605641429978 : check e605641429978 [[],[]] .chain = true := by decide
def e605641430254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605641430254 : Closed e605641430254 ∧ code e605641430254 = 2804664685806 := by decide
theorem cert_e605641430254 : check e605641430254 [[],[]] .chain = true := by decide
def e605641430262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605641430262 : Closed e605641430262 ∧ code e605641430262 = 2804664685814 := by decide
theorem cert_e605641430262 : check e605641430262 [[],[]] .chain = true := by decide
def e605641430638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605641430638 : Closed e605641430638 ∧ code e605641430638 = 2804664686190 := by decide
theorem cert_e605641430638 : check e605641430638 [[],[]] .chain = true := by decide
def e605641430650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605641430650 : Closed e605641430650 ∧ code e605641430650 = 2804664686202 := by decide
theorem cert_e605641430650 : check e605641430650 [[],[]] .chain = true := by decide
def e605641430838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605641430838 : Closed e605641430838 ∧ code e605641430838 = 2804664686390 := by decide
theorem cert_e605641430838 : check e605641430838 [[],[]] .chain = true := by decide
def e605641430842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605641430842 : Closed e605641430842 ∧ code e605641430842 = 2804664686394 := by decide
theorem cert_e605641430842 : check e605641430842 [[],[]] .chain = true := by decide
def e605641431086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605641431086 : Closed e605641431086 ∧ code e605641431086 = 2804664686638 := by decide
theorem cert_e605641431086 : check e605641431086 [[],[]] .chain = true := by decide
end Blc.Floor41
