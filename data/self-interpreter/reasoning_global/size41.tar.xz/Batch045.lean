import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601359360410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601359360410 : Closed e601359360410 ∧ code e601359360410 = 2800382615962 := by decide
theorem cert_e601359360410 : check e601359360410 [[]] .width = true := by decide
def e601359364294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601359364294 : Closed e601359364294 ∧ code e601359364294 = 2800382619846 := by decide
theorem cert_e601359364294 : check e601359364294 [[]] .width = true := by decide
def e601360875718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601360875718 : Closed e601360875718 ∧ code e601360875718 = 2800384131270 := by decide
theorem cert_e601360875718 : check e601360875718 [[]] .width = true := by decide
def e601360883738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601360883738 : Closed e601360883738 ∧ code e601360883738 = 2800384139290 := by decide
theorem cert_e601360883738 : check e601360883738 [[]] .width = true := by decide
def e601360883830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601360883830 : Closed e601360883830 ∧ code e601360883830 = 2800384139382 := by decide
theorem cert_e601360883830 : check e601360883830 [[]] .width = true := by decide
def e601360884074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601360884074 : Closed e601360884074 ∧ code e601360884074 = 2800384139626 := by decide
theorem cert_e601360884074 : check e601360884074 [[]] .width = true := by decide
def e601360884122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601360884122 : Closed e601360884122 ∧ code e601360884122 = 2800384139674 := by decide
theorem cert_e601360884122 : check e601360884122 [[]] .width = true := by decide
def e601360908486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601360908486 : Closed e601360908486 ∧ code e601360908486 = 2800384164038 := by decide
theorem cert_e601360908486 : check e601360908486 [[]] .width = true := by decide
def e601360920774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601360920774 : Closed e601360920774 ∧ code e601360920774 = 2800384176326 := by decide
theorem cert_e601360920774 : check e601360920774 [[]] .width = true := by decide
def e601360932890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601360932890 : Closed e601360932890 ∧ code e601360932890 = 2800384188442 := by decide
theorem cert_e601360932890 : check e601360932890 [[]] .width = true := by decide
def e601360932982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601360932982 : Closed e601360932982 ∧ code e601360932982 = 2800384188534 := by decide
theorem cert_e601360932982 : check e601360932982 [[]] .width = true := by decide
def e601360933226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601360933226 : Closed e601360933226 ∧ code e601360933226 = 2800384188778 := by decide
theorem cert_e601360933226 : check e601360933226 [[]] .width = true := by decide
def e601360933274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601360933274 : Closed e601360933274 ∧ code e601360933274 = 2800384188826 := by decide
theorem cert_e601360933274 : check e601360933274 [[]] .width = true := by decide
def e601360937158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601360937158 : Closed e601360937158 ∧ code e601360937158 = 2800384192710 := by decide
theorem cert_e601360937158 : check e601360937158 [[]] .width = true := by decide
def e601476151322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601476151322 : Closed e601476151322 ∧ code e601476151322 = 2800499406874 := by decide
theorem cert_e601476151322 : check e601476151322 [[]] .width = true := by decide
def e601476159514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601476159514 : Closed e601476159514 ∧ code e601476159514 = 2800499415066 := by decide
theorem cert_e601476159514 : check e601476159514 [[]] .width = true := by decide
def e601477275674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477275674 : Closed e601477275674 ∧ code e601477275674 = 2800500531226 := by decide
theorem cert_e601477275674 : check e601477275674 [[]] .width = true := by decide
def e601477275766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601477275766 : Closed e601477275766 ∧ code e601477275766 = 2800500531318 := by decide
theorem cert_e601477275766 : check e601477275766 [[]] .width = true := by decide
def e601477276010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601477276010 : Closed e601477276010 ∧ code e601477276010 = 2800500531562 := by decide
theorem cert_e601477276010 : check e601477276010 [[]] .width = true := by decide
def e601477276058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601477276058 : Closed e601477276058 ∧ code e601477276058 = 2800500531610 := by decide
theorem cert_e601477276058 : check e601477276058 [[]] .width = true := by decide
def e601477308442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477308442 : Closed e601477308442 ∧ code e601477308442 = 2800500563994 := by decide
theorem cert_e601477308442 : check e601477308442 [[]] .width = true := by decide
def e601477308534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601477308534 : Closed e601477308534 ∧ code e601477308534 = 2800500564086 := by decide
theorem cert_e601477308534 : check e601477308534 [[]] .width = true := by decide
def e601477308778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601477308778 : Closed e601477308778 ∧ code e601477308778 = 2800500564330 := by decide
theorem cert_e601477308778 : check e601477308778 [[]] .width = true := by decide
def e601477308826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601477308826 : Closed e601477308826 ∧ code e601477308826 = 2800500564378 := by decide
theorem cert_e601477308826 : check e601477308826 [[]] .width = true := by decide
def e601477396506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477396506 : Closed e601477396506 ∧ code e601477396506 = 2800500652058 := by decide
theorem cert_e601477396506 : check e601477396506 [[]] .width = true := by decide
def e601477537818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477537818 : Closed e601477537818 ∧ code e601477537818 = 2800500793370 := by decide
theorem cert_e601477537818 : check e601477537818 [[]] .width = true := by decide
def e601477537910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601477537910 : Closed e601477537910 ∧ code e601477537910 = 2800500793462 := by decide
theorem cert_e601477537910 : check e601477537910 [[]] .width = true := by decide
def e601477538154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601477538154 : Closed e601477538154 ∧ code e601477538154 = 2800500793706 := by decide
theorem cert_e601477538154 : check e601477538154 [[]] .width = true := by decide
def e601477538202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601477538202 : Closed e601477538202 ∧ code e601477538202 = 2800500793754 := by decide
theorem cert_e601477538202 : check e601477538202 [[]] .width = true := by decide
def e601477574854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601477574854 : Closed e601477574854 ∧ code e601477574854 = 2800500830406 := by decide
theorem cert_e601477574854 : check e601477574854 [[]] .width = true := by decide
def e601477580826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477580826 : Closed e601477580826 ∧ code e601477580826 = 2800500836378 := by decide
theorem cert_e601477580826 : check e601477580826 [[]] .width = true := by decide
def e601477586970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477586970 : Closed e601477586970 ∧ code e601477586970 = 2800500842522 := by decide
theorem cert_e601477586970 : check e601477586970 [[]] .width = true := by decide
def e601477587062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601477587062 : Closed e601477587062 ∧ code e601477587062 = 2800500842614 := by decide
theorem cert_e601477587062 : check e601477587062 [[]] .width = true := by decide
def e601477587306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601477587306 : Closed e601477587306 ∧ code e601477587306 = 2800500842858 := by decide
theorem cert_e601477587306 : check e601477587306 [[]] .width = true := by decide
def e601477587354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601477587354 : Closed e601477587354 ∧ code e601477587354 = 2800500842906 := by decide
theorem cert_e601477587354 : check e601477587354 [[]] .width = true := by decide
def e601477591238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601477591238 : Closed e601477591238 ∧ code e601477591238 = 2800500846790 := by decide
theorem cert_e601477591238 : check e601477591238 [[]] .width = true := by decide
def e601477593114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477593114 : Closed e601477593114 ∧ code e601477593114 = 2800500848666 := by decide
theorem cert_e601477593114 : check e601477593114 [[]] .width = true := by decide
def e601477634074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477634074 : Closed e601477634074 ∧ code e601477634074 = 2800500889626 := by decide
theorem cert_e601477634074 : check e601477634074 [[]] .width = true := by decide
def e601477701658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477701658 : Closed e601477701658 ∧ code e601477701658 = 2800500957210 := by decide
theorem cert_e601477701658 : check e601477701658 [[]] .width = true := by decide
def e601477701750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601477701750 : Closed e601477701750 ∧ code e601477701750 = 2800500957302 := by decide
theorem cert_e601477701750 : check e601477701750 [[]] .width = true := by decide
def e601477701994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601477701994 : Closed e601477701994 ∧ code e601477701994 = 2800500957546 := by decide
theorem cert_e601477701994 : check e601477701994 [[]] .width = true := by decide
def e601477702042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601477702042 : Closed e601477702042 ∧ code e601477702042 = 2800500957594 := by decide
theorem cert_e601477702042 : check e601477702042 [[]] .width = true := by decide
def e601477711898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477711898 : Closed e601477711898 ∧ code e601477711898 = 2800500967450 := by decide
theorem cert_e601477711898 : check e601477711898 [[]] .width = true := by decide
def e601477718042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477718042 : Closed e601477718042 ∧ code e601477718042 = 2800500973594 := by decide
theorem cert_e601477718042 : check e601477718042 [[]] .width = true := by decide
def e601477718134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601477718134 : Closed e601477718134 ∧ code e601477718134 = 2800500973686 := by decide
theorem cert_e601477718134 : check e601477718134 [[]] .width = true := by decide
def e601477718378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601477718378 : Closed e601477718378 ∧ code e601477718378 = 2800500973930 := by decide
theorem cert_e601477718378 : check e601477718378 [[]] .width = true := by decide
def e601477718426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601477718426 : Closed e601477718426 ∧ code e601477718426 = 2800500973978 := by decide
theorem cert_e601477718426 : check e601477718426 [[]] .width = true := by decide
def e601477722310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601477722310 : Closed e601477722310 ∧ code e601477722310 = 2800500977862 := by decide
theorem cert_e601477722310 : check e601477722310 [[]] .width = true := by decide
def e601477724186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477724186 : Closed e601477724186 ∧ code e601477724186 = 2800500979738 := by decide
theorem cert_e601477724186 : check e601477724186 [[]] .width = true := by decide
def e601477732378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601477732378 : Closed e601477732378 ∧ code e601477732378 = 2800500987930 := by decide
theorem cert_e601477732378 : check e601477732378 [[]] .width = true := by decide
def e601478051866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478051866 : Closed e601478051866 ∧ code e601478051866 = 2800501307418 := by decide
theorem cert_e601478051866 : check e601478051866 [[]] .width = true := by decide
def e601478064154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478064154 : Closed e601478064154 ∧ code e601478064154 = 2800501319706 := by decide
theorem cert_e601478064154 : check e601478064154 [[]] .width = true := by decide
def e601478445082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478445082 : Closed e601478445082 ∧ code e601478445082 = 2800501700634 := by decide
theorem cert_e601478445082 : check e601478445082 [[]] .width = true := by decide
def e601478586394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601478586394 : Closed e601478586394 ∧ code e601478586394 = 2800501841946 := by decide
theorem cert_e601478586394 : check e601478586394 [[]] .width = true := by decide
def e601478586486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601478586486 : Closed e601478586486 ∧ code e601478586486 = 2800501842038 := by decide
theorem cert_e601478586486 : check e601478586486 [[]] .width = true := by decide
def e601478586730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601478586730 : Closed e601478586730 ∧ code e601478586730 = 2800501842282 := by decide
theorem cert_e601478586730 : check e601478586730 [[]] .width = true := by decide
def e601478586778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601478586778 : Closed e601478586778 ∧ code e601478586778 = 2800501842330 := by decide
theorem cert_e601478586778 : check e601478586778 [[]] .width = true := by decide
def e601478623430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601478623430 : Closed e601478623430 ∧ code e601478623430 = 2800501878982 := by decide
theorem cert_e601478623430 : check e601478623430 [[]] .width = true := by decide
def e601478629402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478629402 : Closed e601478629402 ∧ code e601478629402 = 2800501884954 := by decide
theorem cert_e601478629402 : check e601478629402 [[]] .width = true := by decide
def e601478635546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601478635546 : Closed e601478635546 ∧ code e601478635546 = 2800501891098 := by decide
theorem cert_e601478635546 : check e601478635546 [[]] .width = true := by decide
def e601478635638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601478635638 : Closed e601478635638 ∧ code e601478635638 = 2800501891190 := by decide
theorem cert_e601478635638 : check e601478635638 [[]] .width = true := by decide
def e601478635882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601478635882 : Closed e601478635882 ∧ code e601478635882 = 2800501891434 := by decide
theorem cert_e601478635882 : check e601478635882 [[]] .width = true := by decide
def e601478635930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601478635930 : Closed e601478635930 ∧ code e601478635930 = 2800501891482 := by decide
theorem cert_e601478635930 : check e601478635930 [[]] .width = true := by decide
def e601478639814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601478639814 : Closed e601478639814 ∧ code e601478639814 = 2800501895366 := by decide
theorem cert_e601478639814 : check e601478639814 [[]] .width = true := by decide
def e601478641690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478641690 : Closed e601478641690 ∧ code e601478641690 = 2800501897242 := by decide
theorem cert_e601478641690 : check e601478641690 [[]] .width = true := by decide
def e601478754502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601478754502 : Closed e601478754502 ∧ code e601478754502 = 2800502010054 := by decide
theorem cert_e601478754502 : check e601478754502 [[]] .width = true := by decide
def e601478779078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601478779078 : Closed e601478779078 ∧ code e601478779078 = 2800502034630 := by decide
theorem cert_e601478779078 : check e601478779078 [[]] .width = true := by decide
def e601478801434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478801434 : Closed e601478801434 ∧ code e601478801434 = 2800502056986 := by decide
theorem cert_e601478801434 : check e601478801434 [[]] .width = true := by decide
def e601478826010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478826010 : Closed e601478826010 ∧ code e601478826010 = 2800502081562 := by decide
theorem cert_e601478826010 : check e601478826010 [[]] .width = true := by decide
def e601478832154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601478832154 : Closed e601478832154 ∧ code e601478832154 = 2800502087706 := by decide
theorem cert_e601478832154 : check e601478832154 [[]] .width = true := by decide
def e601478832246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601478832246 : Closed e601478832246 ∧ code e601478832246 = 2800502087798 := by decide
private def t_e601478832246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e601478832246 : ¬ IsSelfInterpreter e601478832246 :=
  wSource (t := t_e601478832246) (replay_sound (ps := []) (t := e601478832246) (by decide)) (by decide)
def e601478832490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601478832490 : Closed e601478832490 ∧ code e601478832490 = 2800502088042 := by decide
private def t_e601478832490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e601478832490 : ¬ IsSelfInterpreter e601478832490 :=
  wSource (t := t_e601478832490) (replay_sound (ps := []) (t := e601478832490) (by decide)) (by decide)
def e601478832538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601478832538 : Closed e601478832538 ∧ code e601478832538 = 2800502088090 := by decide
private def t_e601478832538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e601478832538 : ¬ IsSelfInterpreter e601478832538 :=
  wSource (t := t_e601478832538) (replay_sound (ps := []) (t := e601478832538) (by decide)) (by decide)
def e601478836422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601478836422 : Closed e601478836422 ∧ code e601478836422 = 2800502091974 := by decide
theorem cert_e601478836422 : check e601478836422 [[]] .width = true := by decide
def e601478838298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478838298 : Closed e601478838298 ∧ code e601478838298 = 2800502093850 := by decide
theorem cert_e601478838298 : check e601478838298 [[]] .width = true := by decide
def e601478844614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601478844614 : Closed e601478844614 ∧ code e601478844614 = 2800502100166 := by decide
theorem cert_e601478844614 : check e601478844614 [[]] .width = true := by decide
def e601478850586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601478850586 : Closed e601478850586 ∧ code e601478850586 = 2800502106138 := by decide
theorem cert_e601478850586 : check e601478850586 [[]] .width = true := by decide
def e601479010330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479010330 : Closed e601479010330 ∧ code e601479010330 = 2800502265882 := by decide
theorem cert_e601479010330 : check e601479010330 [[]] .width = true := by decide
def e601479014426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479014426 : Closed e601479014426 ∧ code e601479014426 = 2800502269978 := by decide
theorem cert_e601479014426 : check e601479014426 [[]] .width = true := by decide
def e601479206938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479206938 : Closed e601479206938 ∧ code e601479206938 = 2800502462490 := by decide
theorem cert_e601479206938 : check e601479206938 [[]] .width = true := by decide
def e601479274522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601479274522 : Closed e601479274522 ∧ code e601479274522 = 2800502530074 := by decide
theorem cert_e601479274522 : check e601479274522 [[]] .width = true := by decide
def e601479274614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601479274614 : Closed e601479274614 ∧ code e601479274614 = 2800502530166 := by decide
theorem cert_e601479274614 : check e601479274614 [[]] .width = true := by decide
def e601479274858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601479274858 : Closed e601479274858 ∧ code e601479274858 = 2800502530410 := by decide
theorem cert_e601479274858 : check e601479274858 [[]] .width = true := by decide
def e601479274906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601479274906 : Closed e601479274906 ∧ code e601479274906 = 2800502530458 := by decide
theorem cert_e601479274906 : check e601479274906 [[]] .width = true := by decide
def e601479284762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479284762 : Closed e601479284762 ∧ code e601479284762 = 2800502540314 := by decide
theorem cert_e601479284762 : check e601479284762 [[]] .width = true := by decide
def e601479290906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601479290906 : Closed e601479290906 ∧ code e601479290906 = 2800502546458 := by decide
theorem cert_e601479290906 : check e601479290906 [[]] .width = true := by decide
def e601479290998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601479290998 : Closed e601479290998 ∧ code e601479290998 = 2800502546550 := by decide
theorem cert_e601479290998 : check e601479290998 [[]] .width = true := by decide
def e601479291242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601479291242 : Closed e601479291242 ∧ code e601479291242 = 2800502546794 := by decide
theorem cert_e601479291242 : check e601479291242 [[]] .width = true := by decide
def e601479291290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601479291290 : Closed e601479291290 ∧ code e601479291290 = 2800502546842 := by decide
theorem cert_e601479291290 : check e601479291290 [[]] .width = true := by decide
def e601479295174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601479295174 : Closed e601479295174 ∧ code e601479295174 = 2800502550726 := by decide
theorem cert_e601479295174 : check e601479295174 [[]] .width = true := by decide
def e601479297050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479297050 : Closed e601479297050 ∧ code e601479297050 = 2800502552602 := by decide
theorem cert_e601479297050 : check e601479297050 [[]] .width = true := by decide
def e601479305242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479305242 : Closed e601479305242 ∧ code e601479305242 = 2800502560794 := by decide
theorem cert_e601479305242 : check e601479305242 [[]] .width = true := by decide
def e601479325722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479325722 : Closed e601479325722 ∧ code e601479325722 = 2800502581274 := by decide
theorem cert_e601479325722 : check e601479325722 [[]] .width = true := by decide
def e601479350298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479350298 : Closed e601479350298 ∧ code e601479350298 = 2800502605850 := by decide
theorem cert_e601479350298 : check e601479350298 [[]] .width = true := by decide
def e601479356442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601479356442 : Closed e601479356442 ∧ code e601479356442 = 2800502611994 := by decide
theorem cert_e601479356442 : check e601479356442 [[]] .width = true := by decide
def e601479356534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601479356534 : Closed e601479356534 ∧ code e601479356534 = 2800502612086 := by decide
private def t_e601479356534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e601479356534 : ¬ IsSelfInterpreter e601479356534 :=
  wSource (t := t_e601479356534) (replay_sound (ps := []) (t := e601479356534) (by decide)) (by decide)
def e601479356778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601479356778 : Closed e601479356778 ∧ code e601479356778 = 2800502612330 := by decide
private def t_e601479356778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e601479356778 : ¬ IsSelfInterpreter e601479356778 :=
  wSource (t := t_e601479356778) (replay_sound (ps := []) (t := e601479356778) (by decide)) (by decide)
def e601479356826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601479356826 : Closed e601479356826 ∧ code e601479356826 = 2800502612378 := by decide
private def t_e601479356826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e601479356826 : ¬ IsSelfInterpreter e601479356826 :=
  wSource (t := t_e601479356826) (replay_sound (ps := []) (t := e601479356826) (by decide)) (by decide)
def e601479360710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601479360710 : Closed e601479360710 ∧ code e601479360710 = 2800502616262 := by decide
theorem cert_e601479360710 : check e601479360710 [[]] .width = true := by decide
def e601479362586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479362586 : Closed e601479362586 ∧ code e601479362586 = 2800502618138 := by decide
theorem cert_e601479362586 : check e601479362586 [[]] .width = true := by decide
def e601479368902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601479368902 : Closed e601479368902 ∧ code e601479368902 = 2800502624454 := by decide
theorem cert_e601479368902 : check e601479368902 [[]] .width = true := by decide
def e601479374874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479374874 : Closed e601479374874 ∧ code e601479374874 = 2800502630426 := by decide
theorem cert_e601479374874 : check e601479374874 [[]] .width = true := by decide
def e601479403546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479403546 : Closed e601479403546 ∧ code e601479403546 = 2800502659098 := by decide
theorem cert_e601479403546 : check e601479403546 [[]] .width = true := by decide
def e601479407642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601479407642 : Closed e601479407642 ∧ code e601479407642 = 2800502663194 := by decide
theorem cert_e601479407642 : check e601479407642 [[]] .width = true := by decide
def e601480476698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601480476698 : Closed e601480476698 ∧ code e601480476698 = 2800503732250 := by decide
theorem cert_e601480476698 : check e601480476698 [[]] .width = true := by decide
def e601481263130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601481263130 : Closed e601481263130 ∧ code e601481263130 = 2800504518682 := by decide
theorem cert_e601481263130 : check e601481263130 [[]] .width = true := by decide
def e601481271322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601481271322 : Closed e601481271322 ∧ code e601481271322 = 2800504526874 := by decide
theorem cert_e601481271322 : check e601481271322 [[]] .width = true := by decide
def e601481920710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601481920710 : Closed e601481920710 ∧ code e601481920710 = 2800505176262 := by decide
theorem cert_e601481920710 : check e601481920710 [[]] .width = true := by decide
def e601481986246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601481986246 : Closed e601481986246 ∧ code e601481986246 = 2800505241798 := by decide
theorem cert_e601481986246 : check e601481986246 [[]] .width = true := by decide
def e601483567130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483567130 : Closed e601483567130 ∧ code e601483567130 = 2800506822682 := by decide
theorem cert_e601483567130 : check e601483567130 [[]] .width = true := by decide
def e601483567222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601483567222 : Closed e601483567222 ∧ code e601483567222 = 2800506822774 := by decide
theorem cert_e601483567222 : check e601483567222 [[]] .width = true := by decide
def e601483567466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601483567466 : Closed e601483567466 ∧ code e601483567466 = 2800506823018 := by decide
theorem cert_e601483567466 : check e601483567466 [[]] .width = true := by decide
def e601483567514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601483567514 : Closed e601483567514 ∧ code e601483567514 = 2800506823066 := by decide
theorem cert_e601483567514 : check e601483567514 [[]] .width = true := by decide
def e601483599898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483599898 : Closed e601483599898 ∧ code e601483599898 = 2800506855450 := by decide
theorem cert_e601483599898 : check e601483599898 [[]] .width = true := by decide
def e601483599990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601483599990 : Closed e601483599990 ∧ code e601483599990 = 2800506855542 := by decide
theorem cert_e601483599990 : check e601483599990 [[]] .width = true := by decide
def e601483600234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601483600234 : Closed e601483600234 ∧ code e601483600234 = 2800506855786 := by decide
theorem cert_e601483600234 : check e601483600234 [[]] .width = true := by decide
def e601483600282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601483600282 : Closed e601483600282 ∧ code e601483600282 = 2800506855834 := by decide
theorem cert_e601483600282 : check e601483600282 [[]] .width = true := by decide
def e601483687962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601483687962 : Closed e601483687962 ∧ code e601483687962 = 2800506943514 := by decide
theorem cert_e601483687962 : check e601483687962 [[]] .width = true := by decide
def e601483829274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483829274 : Closed e601483829274 ∧ code e601483829274 = 2800507084826 := by decide
theorem cert_e601483829274 : check e601483829274 [[]] .width = true := by decide
def e601483829366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601483829366 : Closed e601483829366 ∧ code e601483829366 = 2800507084918 := by decide
theorem cert_e601483829366 : check e601483829366 [[]] .width = true := by decide
def e601483829610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601483829610 : Closed e601483829610 ∧ code e601483829610 = 2800507085162 := by decide
theorem cert_e601483829610 : check e601483829610 [[]] .width = true := by decide
def e601483829658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601483829658 : Closed e601483829658 ∧ code e601483829658 = 2800507085210 := by decide
theorem cert_e601483829658 : check e601483829658 [[]] .width = true := by decide
def e601483866310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601483866310 : Closed e601483866310 ∧ code e601483866310 = 2800507121862 := by decide
theorem cert_e601483866310 : check e601483866310 [[]] .width = true := by decide
def e601483872282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601483872282 : Closed e601483872282 ∧ code e601483872282 = 2800507127834 := by decide
theorem cert_e601483872282 : check e601483872282 [[]] .width = true := by decide
def e601483878426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483878426 : Closed e601483878426 ∧ code e601483878426 = 2800507133978 := by decide
theorem cert_e601483878426 : check e601483878426 [[]] .width = true := by decide
def e601483878518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601483878518 : Closed e601483878518 ∧ code e601483878518 = 2800507134070 := by decide
theorem cert_e601483878518 : check e601483878518 [[]] .width = true := by decide
def e601483878762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601483878762 : Closed e601483878762 ∧ code e601483878762 = 2800507134314 := by decide
theorem cert_e601483878762 : check e601483878762 [[]] .width = true := by decide
def e601483878810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601483878810 : Closed e601483878810 ∧ code e601483878810 = 2800507134362 := by decide
theorem cert_e601483878810 : check e601483878810 [[]] .width = true := by decide
def e601483882694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601483882694 : Closed e601483882694 ∧ code e601483882694 = 2800507138246 := by decide
theorem cert_e601483882694 : check e601483882694 [[]] .width = true := by decide
def e601483884570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601483884570 : Closed e601483884570 ∧ code e601483884570 = 2800507140122 := by decide
theorem cert_e601483884570 : check e601483884570 [[]] .width = true := by decide
def e601483925530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601483925530 : Closed e601483925530 ∧ code e601483925530 = 2800507181082 := by decide
theorem cert_e601483925530 : check e601483925530 [[]] .width = true := by decide
def e601483993114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483993114 : Closed e601483993114 ∧ code e601483993114 = 2800507248666 := by decide
theorem cert_e601483993114 : check e601483993114 [[]] .width = true := by decide
def e601483993206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601483993206 : Closed e601483993206 ∧ code e601483993206 = 2800507248758 := by decide
theorem cert_e601483993206 : check e601483993206 [[]] .width = true := by decide
def e601483993450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601483993450 : Closed e601483993450 ∧ code e601483993450 = 2800507249002 := by decide
theorem cert_e601483993450 : check e601483993450 [[]] .width = true := by decide
def e601483993498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601483993498 : Closed e601483993498 ∧ code e601483993498 = 2800507249050 := by decide
theorem cert_e601483993498 : check e601483993498 [[]] .width = true := by decide
def e601484003354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601484003354 : Closed e601484003354 ∧ code e601484003354 = 2800507258906 := by decide
theorem cert_e601484003354 : check e601484003354 [[]] .width = true := by decide
def e601484009498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601484009498 : Closed e601484009498 ∧ code e601484009498 = 2800507265050 := by decide
theorem cert_e601484009498 : check e601484009498 [[]] .width = true := by decide
def e601484009590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601484009590 : Closed e601484009590 ∧ code e601484009590 = 2800507265142 := by decide
theorem cert_e601484009590 : check e601484009590 [[]] .width = true := by decide
def e601484009834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601484009834 : Closed e601484009834 ∧ code e601484009834 = 2800507265386 := by decide
theorem cert_e601484009834 : check e601484009834 [[]] .width = true := by decide
def e601484009882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601484009882 : Closed e601484009882 ∧ code e601484009882 = 2800507265434 := by decide
theorem cert_e601484009882 : check e601484009882 [[]] .width = true := by decide
def e601484013766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601484013766 : Closed e601484013766 ∧ code e601484013766 = 2800507269318 := by decide
theorem cert_e601484013766 : check e601484013766 [[]] .width = true := by decide
def e601484015642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601484015642 : Closed e601484015642 ∧ code e601484015642 = 2800507271194 := by decide
theorem cert_e601484015642 : check e601484015642 [[]] .width = true := by decide
def e601484023834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601484023834 : Closed e601484023834 ∧ code e601484023834 = 2800507279386 := by decide
theorem cert_e601484023834 : check e601484023834 [[]] .width = true := by decide
def e601485139994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601485139994 : Closed e601485139994 ∧ code e601485139994 = 2800508395546 := by decide
theorem cert_e601485139994 : check e601485139994 [[]] .width = true := by decide
def e601485140086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601485140086 : Closed e601485140086 ∧ code e601485140086 = 2800508395638 := by decide
theorem cert_e601485140086 : check e601485140086 [[]] .width = true := by decide
def e601485140330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601485140330 : Closed e601485140330 ∧ code e601485140330 = 2800508395882 := by decide
theorem cert_e601485140330 : check e601485140330 [[]] .width = true := by decide
def e601485140378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601485140378 : Closed e601485140378 ∧ code e601485140378 = 2800508395930 := by decide
theorem cert_e601485140378 : check e601485140378 [[]] .width = true := by decide
def e601485172762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601485172762 : Closed e601485172762 ∧ code e601485172762 = 2800508428314 := by decide
theorem cert_e601485172762 : check e601485172762 [[]] .width = true := by decide
def e601485172854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601485172854 : Closed e601485172854 ∧ code e601485172854 = 2800508428406 := by decide
theorem cert_e601485172854 : check e601485172854 [[]] .width = true := by decide
def e601485173098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601485173098 : Closed e601485173098 ∧ code e601485173098 = 2800508428650 := by decide
theorem cert_e601485173098 : check e601485173098 [[]] .width = true := by decide
def e601485173146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601485173146 : Closed e601485173146 ∧ code e601485173146 = 2800508428698 := by decide
theorem cert_e601485173146 : check e601485173146 [[]] .width = true := by decide
def e601486508230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601486508230 : Closed e601486508230 ∧ code e601486508230 = 2800509763782 := by decide
theorem cert_e601486508230 : check e601486508230 [[]] .width = true := by decide
def e601486712858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601486712858 : Closed e601486712858 ∧ code e601486712858 = 2800509968410 := by decide
theorem cert_e601486712858 : check e601486712858 [[]] .width = true := by decide
def e601486712950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601486712950 : Closed e601486712950 ∧ code e601486712950 = 2800509968502 := by decide
theorem cert_e601486712950 : check e601486712950 [[]] .width = true := by decide
def e601486713194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601486713194 : Closed e601486713194 ∧ code e601486713194 = 2800509968746 := by decide
theorem cert_e601486713194 : check e601486713194 [[]] .width = true := by decide
def e601486713242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601486713242 : Closed e601486713242 ∧ code e601486713242 = 2800509968794 := by decide
theorem cert_e601486713242 : check e601486713242 [[]] .width = true := by decide
def e601486749894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601486749894 : Closed e601486749894 ∧ code e601486749894 = 2800510005446 := by decide
theorem cert_e601486749894 : check e601486749894 [[]] .width = true := by decide
def e601486755866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601486755866 : Closed e601486755866 ∧ code e601486755866 = 2800510011418 := by decide
theorem cert_e601486755866 : check e601486755866 [[]] .width = true := by decide
def e601486762010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601486762010 : Closed e601486762010 ∧ code e601486762010 = 2800510017562 := by decide
theorem cert_e601486762010 : check e601486762010 [[]] .width = true := by decide
def e601486762102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601486762102 : Closed e601486762102 ∧ code e601486762102 = 2800510017654 := by decide
theorem cert_e601486762102 : check e601486762102 [[]] .width = true := by decide
end Blc.Floor41
