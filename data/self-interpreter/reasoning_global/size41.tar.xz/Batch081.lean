import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593253102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593253102 : Closed e605593253102 ∧ code e605593253102 = 2804616508654 := by decide
theorem cert_e605593253102 : check e605593253102 [[],[]] .smaller = true := by decide
def e605593253110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593253110 : Closed e605593253110 ∧ code e605593253110 = 2804616508662 := by decide
theorem cert_e605593253110 : check e605593253110 [[],[]] .smaller = true := by decide
def e605593253114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e605593253114 : Closed e605593253114 ∧ code e605593253114 = 2804616508666 := by decide
theorem cert_e605593253114 : check e605593253114 [[],[]] .three = true := by decide
def e605593253486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593253486 : Closed e605593253486 ∧ code e605593253486 = 2804616509038 := by decide
theorem cert_e605593253486 : check e605593253486 [[],[]] .smaller = true := by decide
def e605593253498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593253498 : Closed e605593253498 ∧ code e605593253498 = 2804616509050 := by decide
theorem cert_e605593253498 : check e605593253498 [[],[]] .smaller = true := by decide
def e605593253686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593253686 : Closed e605593253686 ∧ code e605593253686 = 2804616509238 := by decide
theorem cert_e605593253686 : check e605593253686 [[],[]] .smaller = true := by decide
def e605593253690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593253690 : Closed e605593253690 ∧ code e605593253690 = 2804616509242 := by decide
theorem cert_e605593253690 : check e605593253690 [[],[]] .smaller = true := by decide
def e605593253786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593253786 : Closed e605593253786 ∧ code e605593253786 = 2804616509338 := by decide
theorem cert_e605593253786 : check e605593253786 [[],[]] .three = true := by decide
def e605593253946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605593253946 : Closed e605593253946 ∧ code e605593253946 = 2804616509498 := by decide
theorem cert_e605593253946 : check e605593253946 [[],[]] .smaller = true := by decide
def e605593253994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605593253994 : Closed e605593253994 ∧ code e605593253994 = 2804616509546 := by decide
theorem cert_e605593253994 : check e605593253994 [[],[]] .smaller = true := by decide
def e605593254042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593254042 : Closed e605593254042 ∧ code e605593254042 = 2804616509594 := by decide
theorem cert_e605593254042 : check e605593254042 [[],[]] .smaller = true := by decide
def e605593254086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e605593254086 : Closed e605593254086 ∧ code e605593254086 = 2804616509638 := by decide
theorem cert_e605593254086 : check e605593254086 [[],[]] .smaller = true := by decide
def e605593254282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593254282 : Closed e605593254282 ∧ code e605593254282 = 2804616509834 := by decide
theorem cert_e605593254282 : check e605593254282 [[],[]] .smaller = true := by decide
def e605593254306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593254306 : Closed e605593254306 ∧ code e605593254306 = 2804616509858 := by decide
theorem cert_e605593254306 : check e605593254306 [[],[]] .smaller = true := by decide
def e605593254318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605593254318 : Closed e605593254318 ∧ code e605593254318 = 2804616509870 := by decide
theorem cert_e605593254318 : check e605593254318 [[],[]] .smaller = true := by decide
def e605593254326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e605593254326 : Closed e605593254326 ∧ code e605593254326 = 2804616509878 := by decide
theorem cert_e605593254326 : check e605593254326 [[],[]] .smaller = true := by decide
def e605593254330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605593254330 : Closed e605593254330 ∧ code e605593254330 = 2804616509882 := by decide
theorem cert_e605593254330 : check e605593254330 [[],[]] .smaller = true := by decide
def e605593254358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e605593254358 : Closed e605593254358 ∧ code e605593254358 = 2804616509910 := by decide
theorem cert_e605593254358 : check e605593254358 [[],[]] .smaller = true := by decide
def e605593254362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e605593254362 : Closed e605593254362 ∧ code e605593254362 = 2804616509914 := by decide
theorem cert_e605593254362 : check e605593254362 [[],[]] .smaller = true := by decide
def e605593254378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605593254378 : Closed e605593254378 ∧ code e605593254378 = 2804616509930 := by decide
theorem cert_e605593254378 : check e605593254378 [[],[]] .smaller = true := by decide
def e605593254414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e605593254414 : Closed e605593254414 ∧ code e605593254414 = 2804616509966 := by decide
theorem cert_e605593254414 : check e605593254414 [[],[]] .smaller = true := by decide
def e605593254426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593254426 : Closed e605593254426 ∧ code e605593254426 = 2804616509978 := by decide
theorem cert_e605593254426 : check e605593254426 [[],[]] .smaller = true := by decide
def e605593254498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593254498 : Closed e605593254498 ∧ code e605593254498 = 2804616510050 := by decide
theorem cert_e605593254498 : check e605593254498 [[],[]] .smaller = true := by decide
def e605593254510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593254510 : Closed e605593254510 ∧ code e605593254510 = 2804616510062 := by decide
theorem cert_e605593254510 : check e605593254510 [[],[]] .smaller = true := by decide
def e605593254518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593254518 : Closed e605593254518 ∧ code e605593254518 = 2804616510070 := by decide
theorem cert_e605593254518 : check e605593254518 [[],[]] .smaller = true := by decide
def e605593254522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593254522 : Closed e605593254522 ∧ code e605593254522 = 2804616510074 := by decide
theorem cert_e605593254522 : check e605593254522 [[],[]] .smaller = true := by decide
def e605593254710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593254710 : Closed e605593254710 ∧ code e605593254710 = 2804616510262 := by decide
theorem cert_e605593254710 : check e605593254710 [[],[]] .smaller = true := by decide
def e605593254714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593254714 : Closed e605593254714 ∧ code e605593254714 = 2804616510266 := by decide
theorem cert_e605593254714 : check e605593254714 [[],[]] .smaller = true := by decide
def e605593254810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593254810 : Closed e605593254810 ∧ code e605593254810 = 2804616510362 := by decide
theorem cert_e605593254810 : check e605593254810 [[],[]] .smaller = true := by decide
def e605593254878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 3)))))))
theorem wire_e605593254878 : Closed e605593254878 ∧ code e605593254878 = 2804616510430 := by decide
theorem cert_e605593254878 : check e605593254878 [[],[]] .three = true := by decide
def e605593255126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605593255126 : Closed e605593255126 ∧ code e605593255126 = 2804616510678 := by decide
theorem cert_e605593255126 : check e605593255126 [[],[]] .three = true := by decide
def e605593255130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605593255130 : Closed e605593255130 ∧ code e605593255130 = 2804616510682 := by decide
theorem cert_e605593255130 : check e605593255130 [[],[]] .three = true := by decide
def e605593255146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605593255146 : Closed e605593255146 ∧ code e605593255146 = 2804616510698 := by decide
theorem cert_e605593255146 : check e605593255146 [[],[]] .three = true := by decide
def e605593255222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593255222 : Closed e605593255222 ∧ code e605593255222 = 2804616510774 := by decide
theorem cert_e605593255222 : check e605593255222 [[],[]] .three = true := by decide
def e605593255226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593255226 : Closed e605593255226 ∧ code e605593255226 = 2804616510778 := by decide
theorem cert_e605593255226 : check e605593255226 [[],[]] .three = true := by decide
def e605593255322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593255322 : Closed e605593255322 ∧ code e605593255322 = 2804616510874 := by decide
theorem cert_e605593255322 : check e605593255322 [[],[]] .three = true := by decide
def e605593255390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 3)))))))
theorem wire_e605593255390 : Closed e605593255390 ∧ code e605593255390 = 2804616510942 := by decide
theorem cert_e605593255390 : check e605593255390 [[],[]] .three = true := by decide
def e605593255406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 2)))))))
theorem wire_e605593255406 : Closed e605593255406 ∧ code e605593255406 = 2804616510958 := by decide
theorem cert_e605593255406 : check e605593255406 [[],[]] .three = true := by decide
def e605593256406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1)))))))
theorem wire_e605593256406 : Closed e605593256406 ∧ code e605593256406 = 2804616511958 := by decide
theorem cert_e605593256406 : check e605593256406 [[],[]] .smaller = true := by decide
def e605593256410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0)))))))
theorem wire_e605593256410 : Closed e605593256410 ∧ code e605593256410 = 2804616511962 := by decide
theorem cert_e605593256410 : check e605593256410 [[],[]] .smaller = true := by decide
def e605593256426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e605593256426 : Closed e605593256426 ∧ code e605593256426 = 2804616511978 := by decide
theorem cert_e605593256426 : check e605593256426 [[],[]] .smaller = true := by decide
def e605593256790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605593256790 : Closed e605593256790 ∧ code e605593256790 = 2804616512342 := by decide
theorem cert_e605593256790 : check e605593256790 [[],[]] .smaller = true := by decide
def e605593256794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605593256794 : Closed e605593256794 ∧ code e605593256794 = 2804616512346 := by decide
theorem cert_e605593256794 : check e605593256794 [[],[]] .smaller = true := by decide
def e605593257174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605593257174 : Closed e605593257174 ∧ code e605593257174 = 2804616512726 := by decide
theorem cert_e605593257174 : check e605593257174 [[],[]] .smaller = true := by decide
def e605593257178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605593257178 : Closed e605593257178 ∧ code e605593257178 = 2804616512730 := by decide
theorem cert_e605593257178 : check e605593257178 [[],[]] .smaller = true := by decide
def e605593257194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605593257194 : Closed e605593257194 ∧ code e605593257194 = 2804616512746 := by decide
theorem cert_e605593257194 : check e605593257194 [[],[]] .smaller = true := by decide
def e605593257270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593257270 : Closed e605593257270 ∧ code e605593257270 = 2804616512822 := by decide
theorem cert_e605593257270 : check e605593257270 [[],[]] .smaller = true := by decide
def e605593257274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593257274 : Closed e605593257274 ∧ code e605593257274 = 2804616512826 := by decide
theorem cert_e605593257274 : check e605593257274 [[],[]] .smaller = true := by decide
def e605593257370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593257370 : Closed e605593257370 ∧ code e605593257370 = 2804616512922 := by decide
theorem cert_e605593257370 : check e605593257370 [[],[]] .smaller = true := by decide
def e605593257526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605593257526 : Closed e605593257526 ∧ code e605593257526 = 2804616513078 := by decide
theorem cert_e605593257526 : check e605593257526 [[],[]] .smaller = true := by decide
def e605593257530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605593257530 : Closed e605593257530 ∧ code e605593257530 = 2804616513082 := by decide
theorem cert_e605593257530 : check e605593257530 [[],[]] .smaller = true := by decide
def e605593257614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605593257614 : Closed e605593257614 ∧ code e605593257614 = 2804616513166 := by decide
theorem cert_e605593257614 : check e605593257614 [[],[]] .smaller = true := by decide
def e605593257670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605593257670 : Closed e605593257670 ∧ code e605593257670 = 2804616513222 := by decide
theorem cert_e605593257670 : check e605593257670 [[],[]] .smaller = true := by decide
def e605593257754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605593257754 : Closed e605593257754 ∧ code e605593257754 = 2804616513306 := by decide
theorem cert_e605593257754 : check e605593257754 [[],[]] .smaller = true := by decide
def e605593257798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605593257798 : Closed e605593257798 ∧ code e605593257798 = 2804616513350 := by decide
theorem cert_e605593257798 : check e605593257798 [[],[]] .smaller = true := by decide
def e605593259094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605593259094 : Closed e605593259094 ∧ code e605593259094 = 2804616514646 := by decide
theorem cert_e605593259094 : check e605593259094 [[],[]] .smaller = true := by decide
def e605593259098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605593259098 : Closed e605593259098 ∧ code e605593259098 = 2804616514650 := by decide
theorem cert_e605593259098 : check e605593259098 [[],[]] .smaller = true := by decide
def e605593259286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605593259286 : Closed e605593259286 ∧ code e605593259286 = 2804616514838 := by decide
theorem cert_e605593259286 : check e605593259286 [[],[]] .smaller = true := by decide
def e605593259358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e605593259358 : Closed e605593259358 ∧ code e605593259358 = 2804616514910 := by decide
theorem cert_e605593259358 : check e605593259358 [[],[]] .three = true := by decide
def e605593259362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605593259362 : Closed e605593259362 ∧ code e605593259362 = 2804616514914 := by decide
theorem cert_e605593259362 : check e605593259362 [[],[]] .smaller = true := by decide
def e605593259374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605593259374 : Closed e605593259374 ∧ code e605593259374 = 2804616514926 := by decide
theorem cert_e605593259374 : check e605593259374 [[],[]] .smaller = true := by decide
def e605593259382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605593259382 : Closed e605593259382 ∧ code e605593259382 = 2804616514934 := by decide
theorem cert_e605593259382 : check e605593259382 [[],[]] .smaller = true := by decide
def e605593259386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e605593259386 : Closed e605593259386 ∧ code e605593259386 = 2804616514938 := by decide
theorem cert_e605593259386 : check e605593259386 [[],[]] .three = true := by decide
def e605593259402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593259402 : Closed e605593259402 ∧ code e605593259402 = 2804616514954 := by decide
theorem cert_e605593259402 : check e605593259402 [[],[]] .smaller = true := by decide
def e605593259426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593259426 : Closed e605593259426 ∧ code e605593259426 = 2804616514978 := by decide
theorem cert_e605593259426 : check e605593259426 [[],[]] .smaller = true := by decide
def e605593259438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605593259438 : Closed e605593259438 ∧ code e605593259438 = 2804616514990 := by decide
theorem cert_e605593259438 : check e605593259438 [[],[]] .smaller = true := by decide
def e605593259446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e605593259446 : Closed e605593259446 ∧ code e605593259446 = 2804616514998 := by decide
theorem cert_e605593259446 : check e605593259446 [[],[]] .smaller = true := by decide
def e605593259450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605593259450 : Closed e605593259450 ∧ code e605593259450 = 2804616515002 := by decide
theorem cert_e605593259450 : check e605593259450 [[],[]] .smaller = true := by decide
def e605593259478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605593259478 : Closed e605593259478 ∧ code e605593259478 = 2804616515030 := by decide
theorem cert_e605593259478 : check e605593259478 [[],[]] .smaller = true := by decide
def e605593259482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605593259482 : Closed e605593259482 ∧ code e605593259482 = 2804616515034 := by decide
theorem cert_e605593259482 : check e605593259482 [[],[]] .smaller = true := by decide
def e605593259498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e605593259498 : Closed e605593259498 ∧ code e605593259498 = 2804616515050 := by decide
theorem cert_e605593259498 : check e605593259498 [[],[]] .three = true := by decide
def e605593259562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e605593259562 : Closed e605593259562 ∧ code e605593259562 = 2804616515114 := by decide
theorem cert_e605593259562 : check e605593259562 [[],[]] .smaller = true := by decide
def e605593259658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593259658 : Closed e605593259658 ∧ code e605593259658 = 2804616515210 := by decide
theorem cert_e605593259658 : check e605593259658 [[],[]] .smaller = true := by decide
def e605593259682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593259682 : Closed e605593259682 ∧ code e605593259682 = 2804616515234 := by decide
theorem cert_e605593259682 : check e605593259682 [[],[]] .smaller = true := by decide
def e605593259694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605593259694 : Closed e605593259694 ∧ code e605593259694 = 2804616515246 := by decide
theorem cert_e605593259694 : check e605593259694 [[],[]] .smaller = true := by decide
def e605593259702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e605593259702 : Closed e605593259702 ∧ code e605593259702 = 2804616515254 := by decide
theorem cert_e605593259702 : check e605593259702 [[],[]] .smaller = true := by decide
def e605593259706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605593259706 : Closed e605593259706 ∧ code e605593259706 = 2804616515258 := by decide
theorem cert_e605593259706 : check e605593259706 [[],[]] .smaller = true := by decide
def e605593259734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605593259734 : Closed e605593259734 ∧ code e605593259734 = 2804616515286 := by decide
theorem cert_e605593259734 : check e605593259734 [[],[]] .smaller = true := by decide
def e605593259738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605593259738 : Closed e605593259738 ∧ code e605593259738 = 2804616515290 := by decide
theorem cert_e605593259738 : check e605593259738 [[],[]] .smaller = true := by decide
def e605593259754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605593259754 : Closed e605593259754 ∧ code e605593259754 = 2804616515306 := by decide
theorem cert_e605593259754 : check e605593259754 [[],[]] .smaller = true := by decide
def e605593259862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605593259862 : Closed e605593259862 ∧ code e605593259862 = 2804616515414 := by decide
theorem cert_e605593259862 : check e605593259862 [[],[]] .smaller = true := by decide
def e605593259866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605593259866 : Closed e605593259866 ∧ code e605593259866 = 2804616515418 := by decide
theorem cert_e605593259866 : check e605593259866 [[],[]] .smaller = true := by decide
def e605593259882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605593259882 : Closed e605593259882 ∧ code e605593259882 = 2804616515434 := by decide
theorem cert_e605593259882 : check e605593259882 [[],[]] .smaller = true := by decide
def e605593259946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605593259946 : Closed e605593259946 ∧ code e605593259946 = 2804616515498 := by decide
theorem cert_e605593259946 : check e605593259946 [[],[]] .three = true := by decide
def e605593260150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605593260150 : Closed e605593260150 ∧ code e605593260150 = 2804616515702 := by decide
theorem cert_e605593260150 : check e605593260150 [[],[]] .smaller = true := by decide
def e605593260154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605593260154 : Closed e605593260154 ∧ code e605593260154 = 2804616515706 := by decide
theorem cert_e605593260154 : check e605593260154 [[],[]] .smaller = true := by decide
def e605593260246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605593260246 : Closed e605593260246 ∧ code e605593260246 = 2804616515798 := by decide
theorem cert_e605593260246 : check e605593260246 [[],[]] .smaller = true := by decide
def e605593260342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593260342 : Closed e605593260342 ∧ code e605593260342 = 2804616515894 := by decide
theorem cert_e605593260342 : check e605593260342 [[],[]] .smaller = true := by decide
def e605593260346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593260346 : Closed e605593260346 ∧ code e605593260346 = 2804616515898 := by decide
theorem cert_e605593260346 : check e605593260346 [[],[]] .smaller = true := by decide
def e605593260430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e605593260430 : Closed e605593260430 ∧ code e605593260430 = 2804616515982 := by decide
theorem cert_e605593260430 : check e605593260430 [[],[]] .smaller = true := by decide
def e605593260486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e605593260486 : Closed e605593260486 ∧ code e605593260486 = 2804616516038 := by decide
theorem cert_e605593260486 : check e605593260486 [[],[]] .smaller = true := by decide
def e605593260822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605593260822 : Closed e605593260822 ∧ code e605593260822 = 2804616516374 := by decide
theorem cert_e605593260822 : check e605593260822 [[],[]] .smaller = true := by decide
def e605593260894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e605593260894 : Closed e605593260894 ∧ code e605593260894 = 2804616516446 := by decide
theorem cert_e605593260894 : check e605593260894 [[],[]] .three = true := by decide
def e605593260898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605593260898 : Closed e605593260898 ∧ code e605593260898 = 2804616516450 := by decide
theorem cert_e605593260898 : check e605593260898 [[],[]] .smaller = true := by decide
def e605593260910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605593260910 : Closed e605593260910 ∧ code e605593260910 = 2804616516462 := by decide
theorem cert_e605593260910 : check e605593260910 [[],[]] .smaller = true := by decide
def e605593260918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605593260918 : Closed e605593260918 ∧ code e605593260918 = 2804616516470 := by decide
theorem cert_e605593260918 : check e605593260918 [[],[]] .smaller = true := by decide
def e605593260922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e605593260922 : Closed e605593260922 ∧ code e605593260922 = 2804616516474 := by decide
theorem cert_e605593260922 : check e605593260922 [[],[]] .three = true := by decide
def e605593260938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593260938 : Closed e605593260938 ∧ code e605593260938 = 2804616516490 := by decide
theorem cert_e605593260938 : check e605593260938 [[],[]] .smaller = true := by decide
def e605593260962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593260962 : Closed e605593260962 ∧ code e605593260962 = 2804616516514 := by decide
theorem cert_e605593260962 : check e605593260962 [[],[]] .smaller = true := by decide
def e605593260974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605593260974 : Closed e605593260974 ∧ code e605593260974 = 2804616516526 := by decide
theorem cert_e605593260974 : check e605593260974 [[],[]] .smaller = true := by decide
def e605593260982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e605593260982 : Closed e605593260982 ∧ code e605593260982 = 2804616516534 := by decide
theorem cert_e605593260982 : check e605593260982 [[],[]] .smaller = true := by decide
def e605593260986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605593260986 : Closed e605593260986 ∧ code e605593260986 = 2804616516538 := by decide
theorem cert_e605593260986 : check e605593260986 [[],[]] .smaller = true := by decide
def e605593261014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605593261014 : Closed e605593261014 ∧ code e605593261014 = 2804616516566 := by decide
theorem cert_e605593261014 : check e605593261014 [[],[]] .smaller = true := by decide
def e605593261018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605593261018 : Closed e605593261018 ∧ code e605593261018 = 2804616516570 := by decide
theorem cert_e605593261018 : check e605593261018 [[],[]] .smaller = true := by decide
def e605593261034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e605593261034 : Closed e605593261034 ∧ code e605593261034 = 2804616516586 := by decide
theorem cert_e605593261034 : check e605593261034 [[],[]] .three = true := by decide
def e605593261086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e605593261086 : Closed e605593261086 ∧ code e605593261086 = 2804616516638 := by decide
theorem cert_e605593261086 : check e605593261086 [[],[]] .smaller = true := by decide
def e605593261278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e605593261278 : Closed e605593261278 ∧ code e605593261278 = 2804616516830 := by decide
theorem cert_e605593261278 : check e605593261278 [[],[]] .three = true := by decide
def e605593261282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605593261282 : Closed e605593261282 ∧ code e605593261282 = 2804616516834 := by decide
theorem cert_e605593261282 : check e605593261282 [[],[]] .smaller = true := by decide
def e605593261294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593261294 : Closed e605593261294 ∧ code e605593261294 = 2804616516846 := by decide
theorem cert_e605593261294 : check e605593261294 [[],[]] .smaller = true := by decide
def e605593261302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593261302 : Closed e605593261302 ∧ code e605593261302 = 2804616516854 := by decide
theorem cert_e605593261302 : check e605593261302 [[],[]] .smaller = true := by decide
def e605593261306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e605593261306 : Closed e605593261306 ∧ code e605593261306 = 2804616516858 := by decide
theorem cert_e605593261306 : check e605593261306 [[],[]] .three = true := by decide
def e605593261582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e605593261582 : Closed e605593261582 ∧ code e605593261582 = 2804616517134 := by decide
theorem cert_e605593261582 : check e605593261582 [[],[]] .smaller = true := by decide
def e605593261594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593261594 : Closed e605593261594 ∧ code e605593261594 = 2804616517146 := by decide
theorem cert_e605593261594 : check e605593261594 [[],[]] .smaller = true := by decide
def e605593261666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593261666 : Closed e605593261666 ∧ code e605593261666 = 2804616517218 := by decide
theorem cert_e605593261666 : check e605593261666 [[],[]] .smaller = true := by decide
def e605593261678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593261678 : Closed e605593261678 ∧ code e605593261678 = 2804616517230 := by decide
theorem cert_e605593261678 : check e605593261678 [[],[]] .smaller = true := by decide
def e605593261686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593261686 : Closed e605593261686 ∧ code e605593261686 = 2804616517238 := by decide
theorem cert_e605593261686 : check e605593261686 [[],[]] .smaller = true := by decide
def e605593261690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593261690 : Closed e605593261690 ∧ code e605593261690 = 2804616517242 := by decide
theorem cert_e605593261690 : check e605593261690 [[],[]] .smaller = true := by decide
def e605593261878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593261878 : Closed e605593261878 ∧ code e605593261878 = 2804616517430 := by decide
theorem cert_e605593261878 : check e605593261878 [[],[]] .smaller = true := by decide
def e605593261882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593261882 : Closed e605593261882 ∧ code e605593261882 = 2804616517434 := by decide
theorem cert_e605593261882 : check e605593261882 [[],[]] .smaller = true := by decide
def e605593261978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593261978 : Closed e605593261978 ∧ code e605593261978 = 2804616517530 := by decide
theorem cert_e605593261978 : check e605593261978 [[],[]] .three = true := by decide
def e605593262138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605593262138 : Closed e605593262138 ∧ code e605593262138 = 2804616517690 := by decide
theorem cert_e605593262138 : check e605593262138 [[],[]] .smaller = true := by decide
def e605593262186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605593262186 : Closed e605593262186 ∧ code e605593262186 = 2804616517738 := by decide
theorem cert_e605593262186 : check e605593262186 [[],[]] .smaller = true := by decide
def e605593262234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593262234 : Closed e605593262234 ∧ code e605593262234 = 2804616517786 := by decide
theorem cert_e605593262234 : check e605593262234 [[],[]] .smaller = true := by decide
def e605593262278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e605593262278 : Closed e605593262278 ∧ code e605593262278 = 2804616517830 := by decide
theorem cert_e605593262278 : check e605593262278 [[],[]] .smaller = true := by decide
def e605593262474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593262474 : Closed e605593262474 ∧ code e605593262474 = 2804616518026 := by decide
theorem cert_e605593262474 : check e605593262474 [[],[]] .smaller = true := by decide
def e605593262498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593262498 : Closed e605593262498 ∧ code e605593262498 = 2804616518050 := by decide
theorem cert_e605593262498 : check e605593262498 [[],[]] .smaller = true := by decide
def e605593262510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605593262510 : Closed e605593262510 ∧ code e605593262510 = 2804616518062 := by decide
theorem cert_e605593262510 : check e605593262510 [[],[]] .smaller = true := by decide
def e605593262518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e605593262518 : Closed e605593262518 ∧ code e605593262518 = 2804616518070 := by decide
theorem cert_e605593262518 : check e605593262518 [[],[]] .smaller = true := by decide
def e605593262522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605593262522 : Closed e605593262522 ∧ code e605593262522 = 2804616518074 := by decide
theorem cert_e605593262522 : check e605593262522 [[],[]] .smaller = true := by decide
def e605593262550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e605593262550 : Closed e605593262550 ∧ code e605593262550 = 2804616518102 := by decide
theorem cert_e605593262550 : check e605593262550 [[],[]] .smaller = true := by decide
def e605593262554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e605593262554 : Closed e605593262554 ∧ code e605593262554 = 2804616518106 := by decide
theorem cert_e605593262554 : check e605593262554 [[],[]] .smaller = true := by decide
def e605593262570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605593262570 : Closed e605593262570 ∧ code e605593262570 = 2804616518122 := by decide
theorem cert_e605593262570 : check e605593262570 [[],[]] .smaller = true := by decide
def e605593262606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e605593262606 : Closed e605593262606 ∧ code e605593262606 = 2804616518158 := by decide
theorem cert_e605593262606 : check e605593262606 [[],[]] .smaller = true := by decide
def e605593262618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593262618 : Closed e605593262618 ∧ code e605593262618 = 2804616518170 := by decide
theorem cert_e605593262618 : check e605593262618 [[],[]] .smaller = true := by decide
def e605593262690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593262690 : Closed e605593262690 ∧ code e605593262690 = 2804616518242 := by decide
theorem cert_e605593262690 : check e605593262690 [[],[]] .smaller = true := by decide
def e605593262702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593262702 : Closed e605593262702 ∧ code e605593262702 = 2804616518254 := by decide
theorem cert_e605593262702 : check e605593262702 [[],[]] .smaller = true := by decide
def e605593262710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593262710 : Closed e605593262710 ∧ code e605593262710 = 2804616518262 := by decide
theorem cert_e605593262710 : check e605593262710 [[],[]] .smaller = true := by decide
def e605593262714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593262714 : Closed e605593262714 ∧ code e605593262714 = 2804616518266 := by decide
theorem cert_e605593262714 : check e605593262714 [[],[]] .smaller = true := by decide
def e605593262902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593262902 : Closed e605593262902 ∧ code e605593262902 = 2804616518454 := by decide
theorem cert_e605593262902 : check e605593262902 [[],[]] .smaller = true := by decide
def e605593262906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593262906 : Closed e605593262906 ∧ code e605593262906 = 2804616518458 := by decide
theorem cert_e605593262906 : check e605593262906 [[],[]] .smaller = true := by decide
def e605593263002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593263002 : Closed e605593263002 ∧ code e605593263002 = 2804616518554 := by decide
theorem cert_e605593263002 : check e605593263002 [[],[]] .smaller = true := by decide
def e605593263070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 3)))))))
theorem wire_e605593263070 : Closed e605593263070 ∧ code e605593263070 = 2804616518622 := by decide
theorem cert_e605593263070 : check e605593263070 [[],[]] .three = true := by decide
def e605593263318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605593263318 : Closed e605593263318 ∧ code e605593263318 = 2804616518870 := by decide
theorem cert_e605593263318 : check e605593263318 [[],[]] .smaller = true := by decide
def e605593263322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605593263322 : Closed e605593263322 ∧ code e605593263322 = 2804616518874 := by decide
theorem cert_e605593263322 : check e605593263322 [[],[]] .smaller = true := by decide
def e605593263338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605593263338 : Closed e605593263338 ∧ code e605593263338 = 2804616518890 := by decide
theorem cert_e605593263338 : check e605593263338 [[],[]] .smaller = true := by decide
def e605593263414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593263414 : Closed e605593263414 ∧ code e605593263414 = 2804616518966 := by decide
theorem cert_e605593263414 : check e605593263414 [[],[]] .smaller = true := by decide
def e605593263418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593263418 : Closed e605593263418 ∧ code e605593263418 = 2804616518970 := by decide
theorem cert_e605593263418 : check e605593263418 [[],[]] .smaller = true := by decide
def e605593263514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593263514 : Closed e605593263514 ∧ code e605593263514 = 2804616519066 := by decide
theorem cert_e605593263514 : check e605593263514 [[],[]] .smaller = true := by decide
def e605593263722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605593263722 : Closed e605593263722 ∧ code e605593263722 = 2804616519274 := by decide
theorem cert_e605593263722 : check e605593263722 [[],[]] .three = true := by decide
def e605593263770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593263770 : Closed e605593263770 ∧ code e605593263770 = 2804616519322 := by decide
theorem cert_e605593263770 : check e605593263770 [[],[]] .three = true := by decide
def e605593263838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 3)))))))
theorem wire_e605593263838 : Closed e605593263838 ∧ code e605593263838 = 2804616519390 := by decide
theorem cert_e605593263838 : check e605593263838 [[],[]] .three = true := by decide
def e605593263862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 3)) (.var 1)))))))
theorem wire_e605593263862 : Closed e605593263862 ∧ code e605593263862 = 2804616519414 := by decide
theorem cert_e605593263862 : check e605593263862 [[],[]] .three = true := by decide
def e605593265838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605593265838 : Closed e605593265838 ∧ code e605593265838 = 2804616521390 := by decide
theorem cert_e605593265838 : check e605593265838 [[],[]] .three = true := by decide
def e605593265846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e605593265846 : Closed e605593265846 ∧ code e605593265846 = 2804616521398 := by decide
theorem cert_e605593265846 : check e605593265846 [[],[]] .three = true := by decide
def e605593265850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605593265850 : Closed e605593265850 ∧ code e605593265850 = 2804616521402 := by decide
theorem cert_e605593265850 : check e605593265850 [[],[]] .three = true := by decide
def e605593265878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605593265878 : Closed e605593265878 ∧ code e605593265878 = 2804616521430 := by decide
theorem cert_e605593265878 : check e605593265878 [[],[]] .three = true := by decide
def e605593265882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605593265882 : Closed e605593265882 ∧ code e605593265882 = 2804616521434 := by decide
theorem cert_e605593265882 : check e605593265882 [[],[]] .three = true := by decide
def e605593265898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605593265898 : Closed e605593265898 ∧ code e605593265898 = 2804616521450 := by decide
theorem cert_e605593265898 : check e605593265898 [[],[]] .three = true := by decide
def e605593266006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605593266006 : Closed e605593266006 ∧ code e605593266006 = 2804616521558 := by decide
theorem cert_e605593266006 : check e605593266006 [[],[]] .three = true := by decide
def e605593266010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605593266010 : Closed e605593266010 ∧ code e605593266010 = 2804616521562 := by decide
theorem cert_e605593266010 : check e605593266010 [[],[]] .three = true := by decide
end Blc.Floor41
