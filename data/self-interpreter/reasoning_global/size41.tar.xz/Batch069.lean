import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604786076502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e604786076502 : Closed e604786076502 ∧ code e604786076502 = 2803809332054 := by decide
theorem cert_e604786076502 : check e604786076502 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e604786076506 : Closed e604786076506 ∧ code e604786076506 = 2803809332058 := by decide
theorem cert_e604786076506 : check e604786076506 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e604786076522 : Closed e604786076522 ∧ code e604786076522 = 2803809332074 := by decide
theorem cert_e604786076522 : check e604786076522 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e604786076586 : Closed e604786076586 ∧ code e604786076586 = 2803809332138 := by decide
theorem cert_e604786076586 : check e604786076586 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e604786076790 : Closed e604786076790 ∧ code e604786076790 = 2803809332342 := by decide
theorem cert_e604786076790 : check e604786076790 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e604786076886 : Closed e604786076886 ∧ code e604786076886 = 2803809332438 := by decide
theorem cert_e604786076886 : check e604786076886 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e604786076890 : Closed e604786076890 ∧ code e604786076890 = 2803809332442 := by decide
theorem cert_e604786076890 : check e604786076890 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e604786076906 : Closed e604786076906 ∧ code e604786076906 = 2803809332458 := by decide
theorem cert_e604786076906 : check e604786076906 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e604786076982 : Closed e604786076982 ∧ code e604786076982 = 2803809332534 := by decide
theorem cert_e604786076982 : check e604786076982 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786076986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e604786076986 : Closed e604786076986 ∧ code e604786076986 = 2803809332538 := by decide
theorem cert_e604786076986 : check e604786076986 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e604786077070 : Closed e604786077070 ∧ code e604786077070 = 2803809332622 := by decide
theorem cert_e604786077070 : check e604786077070 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e604786077082 : Closed e604786077082 ∧ code e604786077082 = 2803809332634 := by decide
theorem cert_e604786077082 : check e604786077082 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e604786077238 : Closed e604786077238 ∧ code e604786077238 = 2803809332790 := by decide
theorem cert_e604786077238 : check e604786077238 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e604786077242 : Closed e604786077242 ∧ code e604786077242 = 2803809332794 := by decide
theorem cert_e604786077242 : check e604786077242 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e604786077290 : Closed e604786077290 ∧ code e604786077290 = 2803809332842 := by decide
theorem cert_e604786077290 : check e604786077290 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e604786077326 : Closed e604786077326 ∧ code e604786077326 = 2803809332878 := by decide
theorem cert_e604786077326 : check e604786077326 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e604786077338 : Closed e604786077338 ∧ code e604786077338 = 2803809332890 := by decide
theorem cert_e604786077338 : check e604786077338 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e604786077382 : Closed e604786077382 ∧ code e604786077382 = 2803809332934 := by decide
theorem cert_e604786077382 : check e604786077382 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e604786077934 : Closed e604786077934 ∧ code e604786077934 = 2803809333486 := by decide
theorem cert_e604786077934 : check e604786077934 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786077942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e604786077942 : Closed e604786077942 ∧ code e604786077942 = 2803809333494 := by decide
theorem cert_e604786077942 : check e604786077942 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e604786078422 : Closed e604786078422 ∧ code e604786078422 = 2803809333974 := by decide
theorem cert_e604786078422 : check e604786078422 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e604786078426 : Closed e604786078426 ∧ code e604786078426 = 2803809333978 := by decide
theorem cert_e604786078426 : check e604786078426 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e604786078442 : Closed e604786078442 ∧ code e604786078442 = 2803809333994 := by decide
theorem cert_e604786078442 : check e604786078442 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e604786078518 : Closed e604786078518 ∧ code e604786078518 = 2803809334070 := by decide
theorem cert_e604786078518 : check e604786078518 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e604786078522 : Closed e604786078522 ∧ code e604786078522 = 2803809334074 := by decide
theorem cert_e604786078522 : check e604786078522 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e604786078606 : Closed e604786078606 ∧ code e604786078606 = 2803809334158 := by decide
theorem cert_e604786078606 : check e604786078606 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786078618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e604786078618 : Closed e604786078618 ∧ code e604786078618 = 2803809334170 := by decide
theorem cert_e604786078618 : check e604786078618 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786079862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e604786079862 : Closed e604786079862 ∧ code e604786079862 = 2803809335414 := by decide
theorem cert_e604786079862 : check e604786079862 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786080106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e604786080106 : Closed e604786080106 ∧ code e604786080106 = 2803809335658 := by decide
theorem cert_e604786080106 : check e604786080106 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786080142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e604786080142 : Closed e604786080142 ∧ code e604786080142 = 2803809335694 := by decide
theorem cert_e604786080142 : check e604786080142 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786080154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e604786080154 : Closed e604786080154 ∧ code e604786080154 = 2803809335706 := by decide
theorem cert_e604786080154 : check e604786080154 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604786080198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e604786080198 : Closed e604786080198 ∧ code e604786080198 = 2803809335750 := by decide
theorem cert_e604786080198 : check e604786080198 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604787977658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e604787977658 : Closed e604787977658 ∧ code e604787977658 = 2803811233210 := by decide
theorem cert_e604787977658 : check e604787977658 [[],[]] .sourceHead = true := by decide
def e604787977690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e604787977690 : Closed e604787977690 ∧ code e604787977690 = 2803811233242 := by decide
theorem cert_e604787977690 : check e604787977690 [[],[]] .sourceHead = true := by decide
def e604787977914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e604787977914 : Closed e604787977914 ∧ code e604787977914 = 2803811233466 := by decide
theorem cert_e604787977914 : check e604787977914 [[],[]] .sourceHead = true := by decide
def e604787977962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e604787977962 : Closed e604787977962 ∧ code e604787977962 = 2803811233514 := by decide
theorem cert_e604787977962 : check e604787977962 [[],[]] .sourceHead = true := by decide
def e604787978074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e604787978074 : Closed e604787978074 ∧ code e604787978074 = 2803811233626 := by decide
theorem cert_e604787978074 : check e604787978074 [[],[]] .sourceHead = true := by decide
def e604787978090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e604787978090 : Closed e604787978090 ∧ code e604787978090 = 2803811233642 := by decide
theorem cert_e604787978090 : check e604787978090 [[],[]] .sourceHead = true := by decide
def e604787979194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e604787979194 : Closed e604787979194 ∧ code e604787979194 = 2803811234746 := by decide
theorem cert_e604787979194 : check e604787979194 [[],[]] .sourceHead = true := by decide
def e604787979226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e604787979226 : Closed e604787979226 ∧ code e604787979226 = 2803811234778 := by decide
theorem cert_e604787979226 : check e604787979226 [[],[]] .sourceHead = true := by decide
def e604787980730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e604787980730 : Closed e604787980730 ∧ code e604787980730 = 2803811236282 := by decide
theorem cert_e604787980730 : check e604787980730 [[],[]] .sourceHead = true := by decide
def e604787980778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e604787980778 : Closed e604787980778 ∧ code e604787980778 = 2803811236330 := by decide
theorem cert_e604787980778 : check e604787980778 [[],[]] .sourceHead = true := by decide
def e604787981530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e604787981530 : Closed e604787981530 ∧ code e604787981530 = 2803811237082 := by decide
theorem cert_e604787981530 : check e604787981530 [[],[]] .sourceHead = true := by decide
def e604787981546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e604787981546 : Closed e604787981546 ∧ code e604787981546 = 2803811237098 := by decide
theorem cert_e604787981546 : check e604787981546 [[],[]] .sourceHead = true := by decide
def e604788034414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604788034414 : Closed e604788034414 ∧ code e604788034414 = 2803811289966 := by decide
theorem cert_e604788034414 : check e604788034414 [[],[]] .sourceHead = true := by decide
def e604788034422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604788034422 : Closed e604788034422 ∧ code e604788034422 = 2803811289974 := by decide
theorem cert_e604788034422 : check e604788034422 [[],[]] .sourceHead = true := by decide
def e604788034478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604788034478 : Closed e604788034478 ∧ code e604788034478 = 2803811290030 := by decide
theorem cert_e604788034478 : check e604788034478 [[],[]] .sourceHead = true := by decide
def e604788034490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604788034490 : Closed e604788034490 ∧ code e604788034490 = 2803811290042 := by decide
theorem cert_e604788034490 : check e604788034490 [[],[]] .sourceHead = true := by decide
def e604788034518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604788034518 : Closed e604788034518 ∧ code e604788034518 = 2803811290070 := by decide
theorem cert_e604788034518 : check e604788034518 [[],[]] .sourceHead = true := by decide
def e604788034522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604788034522 : Closed e604788034522 ∧ code e604788034522 = 2803811290074 := by decide
theorem cert_e604788034522 : check e604788034522 [[],[]] .sourceHead = true := by decide
def e604788034798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604788034798 : Closed e604788034798 ∧ code e604788034798 = 2803811290350 := by decide
theorem cert_e604788034798 : check e604788034798 [[],[]] .sourceHead = true := by decide
def e604788034806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604788034806 : Closed e604788034806 ∧ code e604788034806 = 2803811290358 := by decide
theorem cert_e604788034806 : check e604788034806 [[],[]] .sourceHead = true := by decide
def e604788035182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604788035182 : Closed e604788035182 ∧ code e604788035182 = 2803811290734 := by decide
theorem cert_e604788035182 : check e604788035182 [[],[]] .sourceHead = true := by decide
def e604788035194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604788035194 : Closed e604788035194 ∧ code e604788035194 = 2803811290746 := by decide
theorem cert_e604788035194 : check e604788035194 [[],[]] .sourceHead = true := by decide
def e604788035382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604788035382 : Closed e604788035382 ∧ code e604788035382 = 2803811290934 := by decide
theorem cert_e604788035382 : check e604788035382 [[],[]] .sourceHead = true := by decide
def e604788035386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604788035386 : Closed e604788035386 ∧ code e604788035386 = 2803811290938 := by decide
theorem cert_e604788035386 : check e604788035386 [[],[]] .sourceHead = true := by decide
def e604788239838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e604788239838 : Closed e604788239838 ∧ code e604788239838 = 2803811495390 := by decide
theorem cert_e604788239838 : check e604788239838 [[],[]] .sourceHead = true := by decide
def e604788239854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e604788239854 : Closed e604788239854 ∧ code e604788239854 = 2803811495406 := by decide
theorem cert_e604788239854 : check e604788239854 [[],[]] .sourceHead = true := by decide
def e604788240222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e604788240222 : Closed e604788240222 ∧ code e604788240222 = 2803811495774 := by decide
theorem cert_e604788240222 : check e604788240222 [[],[]] .sourceHead = true := by decide
def e604788240250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e604788240250 : Closed e604788240250 ∧ code e604788240250 = 2803811495802 := by decide
theorem cert_e604788240250 : check e604788240250 [[],[]] .sourceHead = true := by decide
def e604788240302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e604788240302 : Closed e604788240302 ∧ code e604788240302 = 2803811495854 := by decide
theorem cert_e604788240302 : check e604788240302 [[],[]] .sourceHead = true := by decide
def e604788240314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e604788240314 : Closed e604788240314 ∧ code e604788240314 = 2803811495866 := by decide
theorem cert_e604788240314 : check e604788240314 [[],[]] .sourceHead = true := by decide
def e604788241374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e604788241374 : Closed e604788241374 ∧ code e604788241374 = 2803811496926 := by decide
theorem cert_e604788241374 : check e604788241374 [[],[]] .sourceHead = true := by decide
def e604788241390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e604788241390 : Closed e604788241390 ∧ code e604788241390 = 2803811496942 := by decide
theorem cert_e604788241390 : check e604788241390 [[],[]] .sourceHead = true := by decide
def e604788243678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e604788243678 : Closed e604788243678 ∧ code e604788243678 = 2803811499230 := by decide
theorem cert_e604788243678 : check e604788243678 [[],[]] .sourceHead = true := by decide
def e604788243706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e604788243706 : Closed e604788243706 ∧ code e604788243706 = 2803811499258 := by decide
theorem cert_e604788243706 : check e604788243706 [[],[]] .sourceHead = true := by decide
def e604788244078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e604788244078 : Closed e604788244078 ∧ code e604788244078 = 2803811499630 := by decide
theorem cert_e604788244078 : check e604788244078 [[],[]] .sourceHead = true := by decide
def e604788244090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e604788244090 : Closed e604788244090 ∧ code e604788244090 = 2803811499642 := by decide
theorem cert_e604788244090 : check e604788244090 [[],[]] .sourceHead = true := by decide
def e604788272494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e604788272494 : Closed e604788272494 ∧ code e604788272494 = 2803811528046 := by decide
theorem cert_e604788272494 : check e604788272494 [[],[]] .sourceHead = true := by decide
def e604788272502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e604788272502 : Closed e604788272502 ∧ code e604788272502 = 2803811528054 := by decide
theorem cert_e604788272502 : check e604788272502 [[],[]] .sourceHead = true := by decide
def e604788272558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e604788272558 : Closed e604788272558 ∧ code e604788272558 = 2803811528110 := by decide
theorem cert_e604788272558 : check e604788272558 [[],[]] .sourceHead = true := by decide
def e604788272570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e604788272570 : Closed e604788272570 ∧ code e604788272570 = 2803811528122 := by decide
theorem cert_e604788272570 : check e604788272570 [[],[]] .sourceHead = true := by decide
def e604788272598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e604788272598 : Closed e604788272598 ∧ code e604788272598 = 2803811528150 := by decide
theorem cert_e604788272598 : check e604788272598 [[],[]] .sourceHead = true := by decide
def e604788272602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e604788272602 : Closed e604788272602 ∧ code e604788272602 = 2803811528154 := by decide
theorem cert_e604788272602 : check e604788272602 [[],[]] .sourceHead = true := by decide
def e604788272814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604788272814 : Closed e604788272814 ∧ code e604788272814 = 2803811528366 := by decide
theorem cert_e604788272814 : check e604788272814 [[],[]] .sourceHead = true := by decide
def e604788272826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604788272826 : Closed e604788272826 ∧ code e604788272826 = 2803811528378 := by decide
theorem cert_e604788272826 : check e604788272826 [[],[]] .sourceHead = true := by decide
def e604788272874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604788272874 : Closed e604788272874 ∧ code e604788272874 = 2803811528426 := by decide
theorem cert_e604788272874 : check e604788272874 [[],[]] .sourceHead = true := by decide
def e604788272982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e604788272982 : Closed e604788272982 ∧ code e604788272982 = 2803811528534 := by decide
theorem cert_e604788272982 : check e604788272982 [[],[]] .sourceHead = true := by decide
def e604788272986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e604788272986 : Closed e604788272986 ∧ code e604788272986 = 2803811528538 := by decide
theorem cert_e604788272986 : check e604788272986 [[],[]] .sourceHead = true := by decide
def e604788273002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e604788273002 : Closed e604788273002 ∧ code e604788273002 = 2803811528554 := by decide
theorem cert_e604788273002 : check e604788273002 [[],[]] .sourceHead = true := by decide
def e604788274030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e604788274030 : Closed e604788274030 ∧ code e604788274030 = 2803811529582 := by decide
theorem cert_e604788274030 : check e604788274030 [[],[]] .sourceHead = true := by decide
def e604788274038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e604788274038 : Closed e604788274038 ∧ code e604788274038 = 2803811529590 := by decide
theorem cert_e604788274038 : check e604788274038 [[],[]] .sourceHead = true := by decide
def e604788274094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e604788274094 : Closed e604788274094 ∧ code e604788274094 = 2803811529646 := by decide
theorem cert_e604788274094 : check e604788274094 [[],[]] .sourceHead = true := by decide
def e604788274106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e604788274106 : Closed e604788274106 ∧ code e604788274106 = 2803811529658 := by decide
theorem cert_e604788274106 : check e604788274106 [[],[]] .sourceHead = true := by decide
def e604788274134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e604788274134 : Closed e604788274134 ∧ code e604788274134 = 2803811529686 := by decide
theorem cert_e604788274134 : check e604788274134 [[],[]] .sourceHead = true := by decide
def e604788274138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e604788274138 : Closed e604788274138 ∧ code e604788274138 = 2803811529690 := by decide
theorem cert_e604788274138 : check e604788274138 [[],[]] .sourceHead = true := by decide
def e604788274414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e604788274414 : Closed e604788274414 ∧ code e604788274414 = 2803811529966 := by decide
theorem cert_e604788274414 : check e604788274414 [[],[]] .sourceHead = true := by decide
def e604788274422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e604788274422 : Closed e604788274422 ∧ code e604788274422 = 2803811529974 := by decide
theorem cert_e604788274422 : check e604788274422 [[],[]] .sourceHead = true := by decide
def e604788274798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e604788274798 : Closed e604788274798 ∧ code e604788274798 = 2803811530350 := by decide
theorem cert_e604788274798 : check e604788274798 [[],[]] .sourceHead = true := by decide
def e604788274810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e604788274810 : Closed e604788274810 ∧ code e604788274810 = 2803811530362 := by decide
theorem cert_e604788274810 : check e604788274810 [[],[]] .sourceHead = true := by decide
def e604788274998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e604788274998 : Closed e604788274998 ∧ code e604788274998 = 2803811530550 := by decide
theorem cert_e604788274998 : check e604788274998 [[],[]] .sourceHead = true := by decide
def e604788275002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e604788275002 : Closed e604788275002 ∧ code e604788275002 = 2803811530554 := by decide
theorem cert_e604788275002 : check e604788275002 [[],[]] .sourceHead = true := by decide
def e604788275630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604788275630 : Closed e604788275630 ∧ code e604788275630 = 2803811531182 := by decide
theorem cert_e604788275630 : check e604788275630 [[],[]] .sourceHead = true := by decide
def e604788275642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604788275642 : Closed e604788275642 ∧ code e604788275642 = 2803811531194 := by decide
theorem cert_e604788275642 : check e604788275642 [[],[]] .sourceHead = true := by decide
def e604788275690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604788275690 : Closed e604788275690 ∧ code e604788275690 = 2803811531242 := by decide
theorem cert_e604788275690 : check e604788275690 [[],[]] .sourceHead = true := by decide
def e604788275822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604788275822 : Closed e604788275822 ∧ code e604788275822 = 2803811531374 := by decide
theorem cert_e604788275822 : check e604788275822 [[],[]] .sourceHead = true := by decide
def e604788275834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604788275834 : Closed e604788275834 ∧ code e604788275834 = 2803811531386 := by decide
theorem cert_e604788275834 : check e604788275834 [[],[]] .sourceHead = true := by decide
def e604788276122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604788276122 : Closed e604788276122 ∧ code e604788276122 = 2803811531674 := by decide
theorem cert_e604788276122 : check e604788276122 [[],[]] .sourceHead = true := by decide
def e604788276438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e604788276438 : Closed e604788276438 ∧ code e604788276438 = 2803811531990 := by decide
theorem cert_e604788276438 : check e604788276438 [[],[]] .sourceHead = true := by decide
def e604788276442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e604788276442 : Closed e604788276442 ∧ code e604788276442 = 2803811531994 := by decide
theorem cert_e604788276442 : check e604788276442 [[],[]] .sourceHead = true := by decide
def e604788276458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e604788276458 : Closed e604788276458 ∧ code e604788276458 = 2803811532010 := by decide
theorem cert_e604788276458 : check e604788276458 [[],[]] .sourceHead = true := by decide
def e604788276534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e604788276534 : Closed e604788276534 ∧ code e604788276534 = 2803811532086 := by decide
theorem cert_e604788276534 : check e604788276534 [[],[]] .sourceHead = true := by decide
def e604788276538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e604788276538 : Closed e604788276538 ∧ code e604788276538 = 2803811532090 := by decide
theorem cert_e604788276538 : check e604788276538 [[],[]] .sourceHead = true := by decide
def e604788276634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e604788276634 : Closed e604788276634 ∧ code e604788276634 = 2803811532186 := by decide
theorem cert_e604788276634 : check e604788276634 [[],[]] .sourceHead = true := by decide
def e604788278238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e604788278238 : Closed e604788278238 ∧ code e604788278238 = 2803811533790 := by decide
theorem cert_e604788278238 : check e604788278238 [[],[]] .sourceHead = true := by decide
def e604788278254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e604788278254 : Closed e604788278254 ∧ code e604788278254 = 2803811533806 := by decide
theorem cert_e604788278254 : check e604788278254 [[],[]] .sourceHead = true := by decide
def e604788280174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604788280174 : Closed e604788280174 ∧ code e604788280174 = 2803811535726 := by decide
theorem cert_e604788280174 : check e604788280174 [[],[]] .sourceHead = true := by decide
def e604788280182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604788280182 : Closed e604788280182 ∧ code e604788280182 = 2803811535734 := by decide
theorem cert_e604788280182 : check e604788280182 [[],[]] .sourceHead = true := by decide
def e604788280238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604788280238 : Closed e604788280238 ∧ code e604788280238 = 2803811535790 := by decide
theorem cert_e604788280238 : check e604788280238 [[],[]] .sourceHead = true := by decide
def e604788280250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604788280250 : Closed e604788280250 ∧ code e604788280250 = 2803811535802 := by decide
theorem cert_e604788280250 : check e604788280250 [[],[]] .sourceHead = true := by decide
def e604788280278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604788280278 : Closed e604788280278 ∧ code e604788280278 = 2803811535830 := by decide
theorem cert_e604788280278 : check e604788280278 [[],[]] .sourceHead = true := by decide
def e604788280282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604788280282 : Closed e604788280282 ∧ code e604788280282 = 2803811535834 := by decide
theorem cert_e604788280282 : check e604788280282 [[],[]] .sourceHead = true := by decide
def e604788280558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604788280558 : Closed e604788280558 ∧ code e604788280558 = 2803811536110 := by decide
theorem cert_e604788280558 : check e604788280558 [[],[]] .sourceHead = true := by decide
def e604788280566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604788280566 : Closed e604788280566 ∧ code e604788280566 = 2803811536118 := by decide
theorem cert_e604788280566 : check e604788280566 [[],[]] .sourceHead = true := by decide
def e604788280942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604788280942 : Closed e604788280942 ∧ code e604788280942 = 2803811536494 := by decide
theorem cert_e604788280942 : check e604788280942 [[],[]] .sourceHead = true := by decide
def e604788280954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604788280954 : Closed e604788280954 ∧ code e604788280954 = 2803811536506 := by decide
theorem cert_e604788280954 : check e604788280954 [[],[]] .sourceHead = true := by decide
def e604788281142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604788281142 : Closed e604788281142 ∧ code e604788281142 = 2803811536694 := by decide
theorem cert_e604788281142 : check e604788281142 [[],[]] .sourceHead = true := by decide
def e604788281146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604788281146 : Closed e604788281146 ∧ code e604788281146 = 2803811536698 := by decide
theorem cert_e604788281146 : check e604788281146 [[],[]] .sourceHead = true := by decide
def e604788285918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e604788285918 : Closed e604788285918 ∧ code e604788285918 = 2803811541470 := by decide
theorem cert_e604788285918 : check e604788285918 [[],[]] .sourceHead = true := by decide
def e604788285942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e604788285942 : Closed e604788285942 ∧ code e604788285942 = 2803811541494 := by decide
theorem cert_e604788285942 : check e604788285942 [[],[]] .sourceHead = true := by decide
def e604788286894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604788286894 : Closed e604788286894 ∧ code e604788286894 = 2803811542446 := by decide
theorem cert_e604788286894 : check e604788286894 [[],[]] .sourceHead = true := by decide
def e604788286906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604788286906 : Closed e604788286906 ∧ code e604788286906 = 2803811542458 := by decide
theorem cert_e604788286906 : check e604788286906 [[],[]] .sourceHead = true := by decide
def e604788286954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604788286954 : Closed e604788286954 ∧ code e604788286954 = 2803811542506 := by decide
theorem cert_e604788286954 : check e604788286954 [[],[]] .sourceHead = true := by decide
def e604788287086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604788287086 : Closed e604788287086 ∧ code e604788287086 = 2803811542638 := by decide
theorem cert_e604788287086 : check e604788287086 [[],[]] .sourceHead = true := by decide
def e604788287098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604788287098 : Closed e604788287098 ∧ code e604788287098 = 2803811542650 := by decide
theorem cert_e604788287098 : check e604788287098 [[],[]] .sourceHead = true := by decide
def e604788287386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604788287386 : Closed e604788287386 ∧ code e604788287386 = 2803811542938 := by decide
theorem cert_e604788287386 : check e604788287386 [[],[]] .sourceHead = true := by decide
def e604788289774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e604788289774 : Closed e604788289774 ∧ code e604788289774 = 2803811545326 := by decide
theorem cert_e604788289774 : check e604788289774 [[],[]] .sourceHead = true := by decide
def e604788289782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e604788289782 : Closed e604788289782 ∧ code e604788289782 = 2803811545334 := by decide
theorem cert_e604788289782 : check e604788289782 [[],[]] .sourceHead = true := by decide
def e604788290262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e604788290262 : Closed e604788290262 ∧ code e604788290262 = 2803811545814 := by decide
theorem cert_e604788290262 : check e604788290262 [[],[]] .sourceHead = true := by decide
def e604788290266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e604788290266 : Closed e604788290266 ∧ code e604788290266 = 2803811545818 := by decide
theorem cert_e604788290266 : check e604788290266 [[],[]] .sourceHead = true := by decide
def e604788290282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e604788290282 : Closed e604788290282 ∧ code e604788290282 = 2803811545834 := by decide
theorem cert_e604788290282 : check e604788290282 [[],[]] .sourceHead = true := by decide
def e604788290358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e604788290358 : Closed e604788290358 ∧ code e604788290358 = 2803811545910 := by decide
theorem cert_e604788290358 : check e604788290358 [[],[]] .sourceHead = true := by decide
def e604788290362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e604788290362 : Closed e604788290362 ∧ code e604788290362 = 2803811545914 := by decide
theorem cert_e604788290362 : check e604788290362 [[],[]] .sourceHead = true := by decide
def e604788290458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e604788290458 : Closed e604788290458 ∧ code e604788290458 = 2803811546010 := by decide
theorem cert_e604788290458 : check e604788290458 [[],[]] .sourceHead = true := by decide
def e604788427630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604788427630 : Closed e604788427630 ∧ code e604788427630 = 2803811683182 := by decide
theorem cert_e604788427630 : check e604788427630 [[],[]] .sourceHead = true := by decide
def e604788427638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604788427638 : Closed e604788427638 ∧ code e604788427638 = 2803811683190 := by decide
theorem cert_e604788427638 : check e604788427638 [[],[]] .sourceHead = true := by decide
def e604788427694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604788427694 : Closed e604788427694 ∧ code e604788427694 = 2803811683246 := by decide
theorem cert_e604788427694 : check e604788427694 [[],[]] .sourceHead = true := by decide
def e604788427706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604788427706 : Closed e604788427706 ∧ code e604788427706 = 2803811683258 := by decide
theorem cert_e604788427706 : check e604788427706 [[],[]] .sourceHead = true := by decide
def e604788427734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604788427734 : Closed e604788427734 ∧ code e604788427734 = 2803811683286 := by decide
theorem cert_e604788427734 : check e604788427734 [[],[]] .sourceHead = true := by decide
def e604788427738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604788427738 : Closed e604788427738 ∧ code e604788427738 = 2803811683290 := by decide
theorem cert_e604788427738 : check e604788427738 [[],[]] .sourceHead = true := by decide
def e604788428014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604788428014 : Closed e604788428014 ∧ code e604788428014 = 2803811683566 := by decide
theorem cert_e604788428014 : check e604788428014 [[],[]] .sourceHead = true := by decide
def e604788428022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604788428022 : Closed e604788428022 ∧ code e604788428022 = 2803811683574 := by decide
theorem cert_e604788428022 : check e604788428022 [[],[]] .sourceHead = true := by decide
def e604788428398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604788428398 : Closed e604788428398 ∧ code e604788428398 = 2803811683950 := by decide
theorem cert_e604788428398 : check e604788428398 [[],[]] .sourceHead = true := by decide
def e604788428410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604788428410 : Closed e604788428410 ∧ code e604788428410 = 2803811683962 := by decide
theorem cert_e604788428410 : check e604788428410 [[],[]] .sourceHead = true := by decide
def e604788428598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604788428598 : Closed e604788428598 ∧ code e604788428598 = 2803811684150 := by decide
theorem cert_e604788428598 : check e604788428598 [[],[]] .sourceHead = true := by decide
def e604788428602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604788428602 : Closed e604788428602 ∧ code e604788428602 = 2803811684154 := by decide
theorem cert_e604788428602 : check e604788428602 [[],[]] .sourceHead = true := by decide
def e604788758238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e604788758238 : Closed e604788758238 ∧ code e604788758238 = 2803812013790 := by decide
theorem cert_e604788758238 : check e604788758238 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788758262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e604788758262 : Closed e604788758262 ∧ code e604788758262 = 2803812013814 := by decide
theorem cert_e604788758262 : check e604788758262 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788758366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e604788758366 : Closed e604788758366 ∧ code e604788758366 = 2803812013918 := by decide
theorem cert_e604788758366 : check e604788758366 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788758394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e604788758394 : Closed e604788758394 ∧ code e604788758394 = 2803812013946 := by decide
private def t_e604788758394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e604788758394 : ¬ IsSelfInterpreter e604788758394 :=
  wSource (t := t_e604788758394) (replay_sound (ps := []) (t := e604788758394) (by decide)) (by decide)
def e604788758486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e604788758486 : Closed e604788758486 ∧ code e604788758486 = 2803812014038 := by decide
theorem cert_e604788758486 : check e604788758486 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788758490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e604788758490 : Closed e604788758490 ∧ code e604788758490 = 2803812014042 := by decide
private def t_e604788758490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e604788758490 : ¬ IsSelfInterpreter e604788758490 :=
  wSource (t := t_e604788758490) (replay_sound (ps := []) (t := e604788758490) (by decide)) (by decide)
def e604788759006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e604788759006 : Closed e604788759006 ∧ code e604788759006 = 2803812014558 := by decide
theorem cert_e604788759006 : check e604788759006 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788759030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e604788759030 : Closed e604788759030 ∧ code e604788759030 = 2803812014582 := by decide
theorem cert_e604788759030 : check e604788759030 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788759774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e604788759774 : Closed e604788759774 ∧ code e604788759774 = 2803812015326 := by decide
theorem cert_e604788759774 : check e604788759774 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788759802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e604788759802 : Closed e604788759802 ∧ code e604788759802 = 2803812015354 := by decide
theorem cert_e604788759802 : check e604788759802 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788760374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e604788760374 : Closed e604788760374 ∧ code e604788760374 = 2803812015926 := by decide
theorem cert_e604788760374 : check e604788760374 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788760378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e604788760378 : Closed e604788760378 ∧ code e604788760378 = 2803812015930 := by decide
theorem cert_e604788760378 : check e604788760378 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e604788775150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e604788775150 : Closed e604788775150 ∧ code e604788775150 = 2803812030702 := by decide
theorem cert_e604788775150 : check e604788775150 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e604788775158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e604788775158 : Closed e604788775158 ∧ code e604788775158 = 2803812030710 := by decide
theorem cert_e604788775158 : check e604788775158 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
end Blc.Floor41
