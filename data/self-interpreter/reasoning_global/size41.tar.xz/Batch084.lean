import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593376650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593376650 : Closed e605593376650 ∧ code e605593376650 = 2804616632202 := by decide
theorem cert_e605593376650 : check e605593376650 [[],[]] .smaller = true := by decide
def e605593376674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593376674 : Closed e605593376674 ∧ code e605593376674 = 2804616632226 := by decide
theorem cert_e605593376674 : check e605593376674 [[],[]] .smaller = true := by decide
def e605593376686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e605593376686 : Closed e605593376686 ∧ code e605593376686 = 2804616632238 := by decide
theorem cert_e605593376686 : check e605593376686 [[],[]] .smaller = true := by decide
def e605593376694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e605593376694 : Closed e605593376694 ∧ code e605593376694 = 2804616632246 := by decide
theorem cert_e605593376694 : check e605593376694 [[],[]] .smaller = true := by decide
def e605593376698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e605593376698 : Closed e605593376698 ∧ code e605593376698 = 2804616632250 := by decide
theorem cert_e605593376698 : check e605593376698 [[],[]] .smaller = true := by decide
def e605593376726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605593376726 : Closed e605593376726 ∧ code e605593376726 = 2804616632278 := by decide
theorem cert_e605593376726 : check e605593376726 [[],[]] .three = true := by decide
def e605593376730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605593376730 : Closed e605593376730 ∧ code e605593376730 = 2804616632282 := by decide
theorem cert_e605593376730 : check e605593376730 [[],[]] .three = true := by decide
def e605593376830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e605593376830 : Closed e605593376830 ∧ code e605593376830 = 2804616632382 := by decide
theorem cert_e605593376830 : check e605593376830 [[],[]] .smaller = true := by decide
def e605593377246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605593377246 : Closed e605593377246 ∧ code e605593377246 = 2804616632798 := by decide
theorem cert_e605593377246 : check e605593377246 [[],[]] .three = true := by decide
def e605593377250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605593377250 : Closed e605593377250 ∧ code e605593377250 = 2804616632802 := by decide
theorem cert_e605593377250 : check e605593377250 [[],[]] .smaller = true := by decide
def e605593377262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e605593377262 : Closed e605593377262 ∧ code e605593377262 = 2804616632814 := by decide
theorem cert_e605593377262 : check e605593377262 [[],[]] .smaller = true := by decide
def e605593377270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605593377270 : Closed e605593377270 ∧ code e605593377270 = 2804616632822 := by decide
theorem cert_e605593377270 : check e605593377270 [[],[]] .three = true := by decide
def e605593378014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593378014 : Closed e605593378014 ∧ code e605593378014 = 2804616633566 := by decide
theorem cert_e605593378014 : check e605593378014 [[],[]] .three = true := by decide
def e605593378030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593378030 : Closed e605593378030 ∧ code e605593378030 = 2804616633582 := by decide
theorem cert_e605593378030 : check e605593378030 [[],[]] .smaller = true := by decide
def e605593378038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593378038 : Closed e605593378038 ∧ code e605593378038 = 2804616633590 := by decide
theorem cert_e605593378038 : check e605593378038 [[],[]] .smaller = true := by decide
def e605593378042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593378042 : Closed e605593378042 ∧ code e605593378042 = 2804616633594 := by decide
theorem cert_e605593378042 : check e605593378042 [[],[]] .three = true := by decide
def e605593378318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e605593378318 : Closed e605593378318 ∧ code e605593378318 = 2804616633870 := by decide
theorem cert_e605593378318 : check e605593378318 [[],[]] .smaller = true := by decide
def e605593378330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593378330 : Closed e605593378330 ∧ code e605593378330 = 2804616633882 := by decide
theorem cert_e605593378330 : check e605593378330 [[],[]] .smaller = true := by decide
def e605593378402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593378402 : Closed e605593378402 ∧ code e605593378402 = 2804616633954 := by decide
theorem cert_e605593378402 : check e605593378402 [[],[]] .smaller = true := by decide
def e605593378414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593378414 : Closed e605593378414 ∧ code e605593378414 = 2804616633966 := by decide
theorem cert_e605593378414 : check e605593378414 [[],[]] .smaller = true := by decide
def e605593378422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593378422 : Closed e605593378422 ∧ code e605593378422 = 2804616633974 := by decide
theorem cert_e605593378422 : check e605593378422 [[],[]] .smaller = true := by decide
def e605593378426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593378426 : Closed e605593378426 ∧ code e605593378426 = 2804616633978 := by decide
theorem cert_e605593378426 : check e605593378426 [[],[]] .smaller = true := by decide
def e605593378614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593378614 : Closed e605593378614 ∧ code e605593378614 = 2804616634166 := by decide
theorem cert_e605593378614 : check e605593378614 [[],[]] .three = true := by decide
def e605593378618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593378618 : Closed e605593378618 ∧ code e605593378618 = 2804616634170 := by decide
theorem cert_e605593378618 : check e605593378618 [[],[]] .three = true := by decide
def e605593387966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e605593387966 : Closed e605593387966 ∧ code e605593387966 = 2804616643518 := by decide
theorem cert_e605593387966 : check e605593387966 [[],[]] .three = true := by decide
def e605593387998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605593387998 : Closed e605593387998 ∧ code e605593387998 = 2804616643550 := by decide
theorem cert_e605593387998 : check e605593387998 [[],[]] .smaller = true := by decide
def e605593388014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605593388014 : Closed e605593388014 ∧ code e605593388014 = 2804616643566 := by decide
theorem cert_e605593388014 : check e605593388014 [[],[]] .smaller = true := by decide
def e605593388022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e605593388022 : Closed e605593388022 ∧ code e605593388022 = 2804616643574 := by decide
theorem cert_e605593388022 : check e605593388022 [[],[]] .three = true := by decide
def e605593389846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605593389846 : Closed e605593389846 ∧ code e605593389846 = 2804616645398 := by decide
theorem cert_e605593389846 : check e605593389846 [[],[]] .smaller = true := by decide
def e605593389918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e605593389918 : Closed e605593389918 ∧ code e605593389918 = 2804616645470 := by decide
theorem cert_e605593389918 : check e605593389918 [[],[]] .three = true := by decide
def e605593389922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605593389922 : Closed e605593389922 ∧ code e605593389922 = 2804616645474 := by decide
theorem cert_e605593389922 : check e605593389922 [[],[]] .smaller = true := by decide
def e605593389934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605593389934 : Closed e605593389934 ∧ code e605593389934 = 2804616645486 := by decide
theorem cert_e605593389934 : check e605593389934 [[],[]] .smaller = true := by decide
def e605593389942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605593389942 : Closed e605593389942 ∧ code e605593389942 = 2804616645494 := by decide
theorem cert_e605593389942 : check e605593389942 [[],[]] .smaller = true := by decide
def e605593389946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e605593389946 : Closed e605593389946 ∧ code e605593389946 = 2804616645498 := by decide
theorem cert_e605593389946 : check e605593389946 [[],[]] .three = true := by decide
def e605593389962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593389962 : Closed e605593389962 ∧ code e605593389962 = 2804616645514 := by decide
theorem cert_e605593389962 : check e605593389962 [[],[]] .smaller = true := by decide
def e605593389986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593389986 : Closed e605593389986 ∧ code e605593389986 = 2804616645538 := by decide
theorem cert_e605593389986 : check e605593389986 [[],[]] .smaller = true := by decide
def e605593389998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605593389998 : Closed e605593389998 ∧ code e605593389998 = 2804616645550 := by decide
theorem cert_e605593389998 : check e605593389998 [[],[]] .smaller = true := by decide
def e605593390006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e605593390006 : Closed e605593390006 ∧ code e605593390006 = 2804616645558 := by decide
theorem cert_e605593390006 : check e605593390006 [[],[]] .smaller = true := by decide
def e605593390010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605593390010 : Closed e605593390010 ∧ code e605593390010 = 2804616645562 := by decide
theorem cert_e605593390010 : check e605593390010 [[],[]] .smaller = true := by decide
def e605593390038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605593390038 : Closed e605593390038 ∧ code e605593390038 = 2804616645590 := by decide
theorem cert_e605593390038 : check e605593390038 [[],[]] .smaller = true := by decide
def e605593390042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605593390042 : Closed e605593390042 ∧ code e605593390042 = 2804616645594 := by decide
theorem cert_e605593390042 : check e605593390042 [[],[]] .smaller = true := by decide
def e605593390058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e605593390058 : Closed e605593390058 ∧ code e605593390058 = 2804616645610 := by decide
theorem cert_e605593390058 : check e605593390058 [[],[]] .three = true := by decide
def e605593390110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e605593390110 : Closed e605593390110 ∧ code e605593390110 = 2804616645662 := by decide
theorem cert_e605593390110 : check e605593390110 [[],[]] .smaller = true := by decide
def e605593390302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593390302 : Closed e605593390302 ∧ code e605593390302 = 2804616645854 := by decide
theorem cert_e605593390302 : check e605593390302 [[],[]] .three = true := by decide
def e605593390306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605593390306 : Closed e605593390306 ∧ code e605593390306 = 2804616645858 := by decide
theorem cert_e605593390306 : check e605593390306 [[],[]] .smaller = true := by decide
def e605593390318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593390318 : Closed e605593390318 ∧ code e605593390318 = 2804616645870 := by decide
theorem cert_e605593390318 : check e605593390318 [[],[]] .smaller = true := by decide
def e605593390326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593390326 : Closed e605593390326 ∧ code e605593390326 = 2804616645878 := by decide
theorem cert_e605593390326 : check e605593390326 [[],[]] .smaller = true := by decide
def e605593390330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593390330 : Closed e605593390330 ∧ code e605593390330 = 2804616645882 := by decide
theorem cert_e605593390330 : check e605593390330 [[],[]] .three = true := by decide
def e605593390606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e605593390606 : Closed e605593390606 ∧ code e605593390606 = 2804616646158 := by decide
theorem cert_e605593390606 : check e605593390606 [[],[]] .smaller = true := by decide
def e605593390618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593390618 : Closed e605593390618 ∧ code e605593390618 = 2804616646170 := by decide
theorem cert_e605593390618 : check e605593390618 [[],[]] .smaller = true := by decide
def e605593390690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593390690 : Closed e605593390690 ∧ code e605593390690 = 2804616646242 := by decide
theorem cert_e605593390690 : check e605593390690 [[],[]] .smaller = true := by decide
def e605593390702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593390702 : Closed e605593390702 ∧ code e605593390702 = 2804616646254 := by decide
theorem cert_e605593390702 : check e605593390702 [[],[]] .smaller = true := by decide
def e605593390710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593390710 : Closed e605593390710 ∧ code e605593390710 = 2804616646262 := by decide
theorem cert_e605593390710 : check e605593390710 [[],[]] .smaller = true := by decide
def e605593390714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593390714 : Closed e605593390714 ∧ code e605593390714 = 2804616646266 := by decide
theorem cert_e605593390714 : check e605593390714 [[],[]] .smaller = true := by decide
def e605593390902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593390902 : Closed e605593390902 ∧ code e605593390902 = 2804616646454 := by decide
theorem cert_e605593390902 : check e605593390902 [[],[]] .smaller = true := by decide
def e605593390906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593390906 : Closed e605593390906 ∧ code e605593390906 = 2804616646458 := by decide
theorem cert_e605593390906 : check e605593390906 [[],[]] .smaller = true := by decide
def e605593391002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593391002 : Closed e605593391002 ∧ code e605593391002 = 2804616646554 := by decide
theorem cert_e605593391002 : check e605593391002 [[],[]] .three = true := by decide
def e605593395678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605593395678 : Closed e605593395678 ∧ code e605593395678 = 2804616651230 := by decide
theorem cert_e605593395678 : check e605593395678 [[],[]] .three = true := by decide
def e605593395694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e605593395694 : Closed e605593395694 ∧ code e605593395694 = 2804616651246 := by decide
theorem cert_e605593395694 : check e605593395694 [[],[]] .three = true := by decide
def e605593395702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605593395702 : Closed e605593395702 ∧ code e605593395702 = 2804616651254 := by decide
theorem cert_e605593395702 : check e605593395702 [[],[]] .three = true := by decide
def e605593396654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605593396654 : Closed e605593396654 ∧ code e605593396654 = 2804616652206 := by decide
theorem cert_e605593396654 : check e605593396654 [[],[]] .three = true := by decide
def e605593396662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605593396662 : Closed e605593396662 ∧ code e605593396662 = 2804616652214 := by decide
theorem cert_e605593396662 : check e605593396662 [[],[]] .three = true := by decide
def e605593396666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605593396666 : Closed e605593396666 ∧ code e605593396666 = 2804616652218 := by decide
theorem cert_e605593396666 : check e605593396666 [[],[]] .three = true := by decide
def e605593396694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605593396694 : Closed e605593396694 ∧ code e605593396694 = 2804616652246 := by decide
theorem cert_e605593396694 : check e605593396694 [[],[]] .three = true := by decide
def e605593396698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605593396698 : Closed e605593396698 ∧ code e605593396698 = 2804616652250 := by decide
theorem cert_e605593396698 : check e605593396698 [[],[]] .three = true := by decide
def e605593396714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605593396714 : Closed e605593396714 ∧ code e605593396714 = 2804616652266 := by decide
theorem cert_e605593396714 : check e605593396714 [[],[]] .three = true := by decide
def e605593396846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593396846 : Closed e605593396846 ∧ code e605593396846 = 2804616652398 := by decide
theorem cert_e605593396846 : check e605593396846 [[],[]] .three = true := by decide
def e605593396854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593396854 : Closed e605593396854 ∧ code e605593396854 = 2804616652406 := by decide
theorem cert_e605593396854 : check e605593396854 [[],[]] .three = true := by decide
def e605593396858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593396858 : Closed e605593396858 ∧ code e605593396858 = 2804616652410 := by decide
theorem cert_e605593396858 : check e605593396858 [[],[]] .three = true := by decide
def e605593397046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593397046 : Closed e605593397046 ∧ code e605593397046 = 2804616652598 := by decide
theorem cert_e605593397046 : check e605593397046 [[],[]] .three = true := by decide
def e605593397050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593397050 : Closed e605593397050 ∧ code e605593397050 = 2804616652602 := by decide
theorem cert_e605593397050 : check e605593397050 [[],[]] .three = true := by decide
def e605593397146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593397146 : Closed e605593397146 ∧ code e605593397146 = 2804616652698 := by decide
theorem cert_e605593397146 : check e605593397146 [[],[]] .three = true := by decide
def e605593407086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593407086 : Closed e605593407086 ∧ code e605593407086 = 2804616662638 := by decide
theorem cert_e605593407086 : check e605593407086 [[],[]] .smaller = true := by decide
def e605593407098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593407098 : Closed e605593407098 ∧ code e605593407098 = 2804616662650 := by decide
theorem cert_e605593407098 : check e605593407098 [[],[]] .smaller = true := by decide
def e605593407386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593407386 : Closed e605593407386 ∧ code e605593407386 = 2804616662938 := by decide
theorem cert_e605593407386 : check e605593407386 [[],[]] .smaller = true := by decide
def e605593410158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593410158 : Closed e605593410158 ∧ code e605593410158 = 2804616665710 := by decide
theorem cert_e605593410158 : check e605593410158 [[],[]] .smaller = true := by decide
def e605593410170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593410170 : Closed e605593410170 ∧ code e605593410170 = 2804616665722 := by decide
theorem cert_e605593410170 : check e605593410170 [[],[]] .smaller = true := by decide
def e605593411038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e605593411038 : Closed e605593411038 ∧ code e605593411038 = 2804616666590 := by decide
theorem cert_e605593411038 : check e605593411038 [[],[]] .three = true := by decide
def e605593411054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e605593411054 : Closed e605593411054 ∧ code e605593411054 = 2804616666606 := by decide
theorem cert_e605593411054 : check e605593411054 [[],[]] .smaller = true := by decide
def e605593411062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.var 1)))))))
theorem wire_e605593411062 : Closed e605593411062 ∧ code e605593411062 = 2804616666614 := by decide
theorem cert_e605593411062 : check e605593411062 [[],[]] .three = true := by decide
def e605593411294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e605593411294 : Closed e605593411294 ∧ code e605593411294 = 2804616666846 := by decide
theorem cert_e605593411294 : check e605593411294 [[],[]] .three = true := by decide
def e605593411322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 4)))) (.var 0)))))))
theorem wire_e605593411322 : Closed e605593411322 ∧ code e605593411322 = 2804616666874 := by decide
theorem cert_e605593411322 : check e605593411322 [[],[]] .three = true := by decide
def e605593411438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e605593411438 : Closed e605593411438 ∧ code e605593411438 = 2804616666990 := by decide
theorem cert_e605593411438 : check e605593411438 [[],[]] .smaller = true := by decide
def e605593411450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0)))))))
theorem wire_e605593411450 : Closed e605593411450 ∧ code e605593411450 = 2804616667002 := by decide
theorem cert_e605593411450 : check e605593411450 [[],[]] .smaller = true := by decide
def e605593411510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.var 1)))))))
theorem wire_e605593411510 : Closed e605593411510 ∧ code e605593411510 = 2804616667062 := by decide
theorem cert_e605593411510 : check e605593411510 [[],[]] .three = true := by decide
def e605593411514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 2)))) (.var 0)))))))
theorem wire_e605593411514 : Closed e605593411514 ∧ code e605593411514 = 2804616667066 := by decide
theorem cert_e605593411514 : check e605593411514 [[],[]] .three = true := by decide
def e605593413038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605593413038 : Closed e605593413038 ∧ code e605593413038 = 2804616668590 := by decide
theorem cert_e605593413038 : check e605593413038 [[],[]] .smaller = true := by decide
def e605593413050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605593413050 : Closed e605593413050 ∧ code e605593413050 = 2804616668602 := by decide
theorem cert_e605593413050 : check e605593413050 [[],[]] .smaller = true := by decide
def e605593413098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605593413098 : Closed e605593413098 ∧ code e605593413098 = 2804616668650 := by decide
theorem cert_e605593413098 : check e605593413098 [[],[]] .smaller = true := by decide
def e605593413230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593413230 : Closed e605593413230 ∧ code e605593413230 = 2804616668782 := by decide
theorem cert_e605593413230 : check e605593413230 [[],[]] .smaller = true := by decide
def e605593413242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593413242 : Closed e605593413242 ∧ code e605593413242 = 2804616668794 := by decide
theorem cert_e605593413242 : check e605593413242 [[],[]] .smaller = true := by decide
def e605593413530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593413530 : Closed e605593413530 ∧ code e605593413530 = 2804616669082 := by decide
theorem cert_e605593413530 : check e605593413530 [[],[]] .smaller = true := by decide
def e605593416478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605593416478 : Closed e605593416478 ∧ code e605593416478 = 2804616672030 := by decide
theorem cert_e605593416478 : check e605593416478 [[],[]] .smaller = true := by decide
def e605593416646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605593416646 : Closed e605593416646 ∧ code e605593416646 = 2804616672198 := by decide
theorem cert_e605593416646 : check e605593416646 [[],[]] .smaller = true := by decide
def e605593418950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605593418950 : Closed e605593418950 ∧ code e605593418950 = 2804616674502 := by decide
theorem cert_e605593418950 : check e605593418950 [[],[]] .smaller = true := by decide
def e605593426094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e605593426094 : Closed e605593426094 ∧ code e605593426094 = 2804616681646 := by decide
theorem cert_e605593426094 : check e605593426094 [[],[]] .smaller = true := by decide
def e605593426106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e605593426106 : Closed e605593426106 ∧ code e605593426106 = 2804616681658 := by decide
theorem cert_e605593426106 : check e605593426106 [[],[]] .smaller = true := by decide
def e605593426478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605593426478 : Closed e605593426478 ∧ code e605593426478 = 2804616682030 := by decide
theorem cert_e605593426478 : check e605593426478 [[],[]] .smaller = true := by decide
def e605593426654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e605593426654 : Closed e605593426654 ∧ code e605593426654 = 2804616682206 := by decide
theorem cert_e605593426654 : check e605593426654 [[],[]] .three = true := by decide
def e605593426658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605593426658 : Closed e605593426658 ∧ code e605593426658 = 2804616682210 := by decide
theorem cert_e605593426658 : check e605593426658 [[],[]] .smaller = true := by decide
def e605593426670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e605593426670 : Closed e605593426670 ∧ code e605593426670 = 2804616682222 := by decide
theorem cert_e605593426670 : check e605593426670 [[],[]] .smaller = true := by decide
def e605593426678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e605593426678 : Closed e605593426678 ∧ code e605593426678 = 2804616682230 := by decide
theorem cert_e605593426678 : check e605593426678 [[],[]] .three = true := by decide
def e605593426782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e605593426782 : Closed e605593426782 ∧ code e605593426782 = 2804616682334 := by decide
theorem cert_e605593426782 : check e605593426782 [[],[]] .three = true := by decide
def e605593426798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e605593426798 : Closed e605593426798 ∧ code e605593426798 = 2804616682350 := by decide
theorem cert_e605593426798 : check e605593426798 [[],[]] .smaller = true := by decide
def e605593426806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e605593426806 : Closed e605593426806 ∧ code e605593426806 = 2804616682358 := by decide
theorem cert_e605593426806 : check e605593426806 [[],[]] .smaller = true := by decide
def e605593426810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e605593426810 : Closed e605593426810 ∧ code e605593426810 = 2804616682362 := by decide
theorem cert_e605593426810 : check e605593426810 [[],[]] .three = true := by decide
def e605593426826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593426826 : Closed e605593426826 ∧ code e605593426826 = 2804616682378 := by decide
theorem cert_e605593426826 : check e605593426826 [[],[]] .smaller = true := by decide
def e605593426850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593426850 : Closed e605593426850 ∧ code e605593426850 = 2804616682402 := by decide
theorem cert_e605593426850 : check e605593426850 [[],[]] .smaller = true := by decide
def e605593426862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e605593426862 : Closed e605593426862 ∧ code e605593426862 = 2804616682414 := by decide
theorem cert_e605593426862 : check e605593426862 [[],[]] .smaller = true := by decide
def e605593426870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e605593426870 : Closed e605593426870 ∧ code e605593426870 = 2804616682422 := by decide
theorem cert_e605593426870 : check e605593426870 [[],[]] .smaller = true := by decide
def e605593426874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e605593426874 : Closed e605593426874 ∧ code e605593426874 = 2804616682426 := by decide
theorem cert_e605593426874 : check e605593426874 [[],[]] .smaller = true := by decide
def e605593426902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e605593426902 : Closed e605593426902 ∧ code e605593426902 = 2804616682454 := by decide
theorem cert_e605593426902 : check e605593426902 [[],[]] .three = true := by decide
def e605593426906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e605593426906 : Closed e605593426906 ∧ code e605593426906 = 2804616682458 := by decide
theorem cert_e605593426906 : check e605593426906 [[],[]] .three = true := by decide
def e605593427294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e605593427294 : Closed e605593427294 ∧ code e605593427294 = 2804616682846 := by decide
theorem cert_e605593427294 : check e605593427294 [[],[]] .three = true := by decide
def e605593427310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605593427310 : Closed e605593427310 ∧ code e605593427310 = 2804616682862 := by decide
theorem cert_e605593427310 : check e605593427310 [[],[]] .smaller = true := by decide
def e605593427318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605593427318 : Closed e605593427318 ∧ code e605593427318 = 2804616682870 := by decide
theorem cert_e605593427318 : check e605593427318 [[],[]] .smaller = true := by decide
def e605593427322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e605593427322 : Closed e605593427322 ∧ code e605593427322 = 2804616682874 := by decide
theorem cert_e605593427322 : check e605593427322 [[],[]] .three = true := by decide
def e605593427374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605593427374 : Closed e605593427374 ∧ code e605593427374 = 2804616682926 := by decide
theorem cert_e605593427374 : check e605593427374 [[],[]] .smaller = true := by decide
def e605593427386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605593427386 : Closed e605593427386 ∧ code e605593427386 = 2804616682938 := by decide
theorem cert_e605593427386 : check e605593427386 [[],[]] .smaller = true := by decide
def e605593427414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605593427414 : Closed e605593427414 ∧ code e605593427414 = 2804616682966 := by decide
theorem cert_e605593427414 : check e605593427414 [[],[]] .smaller = true := by decide
def e605593427418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605593427418 : Closed e605593427418 ∧ code e605593427418 = 2804616682970 := by decide
theorem cert_e605593427418 : check e605593427418 [[],[]] .smaller = true := by decide
def e605593427434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e605593427434 : Closed e605593427434 ∧ code e605593427434 = 2804616682986 := by decide
theorem cert_e605593427434 : check e605593427434 [[],[]] .three = true := by decide
def e605593427498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e605593427498 : Closed e605593427498 ∧ code e605593427498 = 2804616683050 := by decide
theorem cert_e605593427498 : check e605593427498 [[],[]] .smaller = true := by decide
def e605593427594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593427594 : Closed e605593427594 ∧ code e605593427594 = 2804616683146 := by decide
theorem cert_e605593427594 : check e605593427594 [[],[]] .smaller = true := by decide
def e605593427618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593427618 : Closed e605593427618 ∧ code e605593427618 = 2804616683170 := by decide
theorem cert_e605593427618 : check e605593427618 [[],[]] .smaller = true := by decide
def e605593427630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605593427630 : Closed e605593427630 ∧ code e605593427630 = 2804616683182 := by decide
theorem cert_e605593427630 : check e605593427630 [[],[]] .smaller = true := by decide
def e605593427638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e605593427638 : Closed e605593427638 ∧ code e605593427638 = 2804616683190 := by decide
theorem cert_e605593427638 : check e605593427638 [[],[]] .smaller = true := by decide
def e605593427642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605593427642 : Closed e605593427642 ∧ code e605593427642 = 2804616683194 := by decide
theorem cert_e605593427642 : check e605593427642 [[],[]] .smaller = true := by decide
def e605593427670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e605593427670 : Closed e605593427670 ∧ code e605593427670 = 2804616683222 := by decide
theorem cert_e605593427670 : check e605593427670 [[],[]] .smaller = true := by decide
def e605593427674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e605593427674 : Closed e605593427674 ∧ code e605593427674 = 2804616683226 := by decide
theorem cert_e605593427674 : check e605593427674 [[],[]] .smaller = true := by decide
def e605593427690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605593427690 : Closed e605593427690 ∧ code e605593427690 = 2804616683242 := by decide
theorem cert_e605593427690 : check e605593427690 [[],[]] .smaller = true := by decide
def e605593427798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605593427798 : Closed e605593427798 ∧ code e605593427798 = 2804616683350 := by decide
theorem cert_e605593427798 : check e605593427798 [[],[]] .three = true := by decide
def e605593427802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605593427802 : Closed e605593427802 ∧ code e605593427802 = 2804616683354 := by decide
theorem cert_e605593427802 : check e605593427802 [[],[]] .three = true := by decide
def e605593427818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605593427818 : Closed e605593427818 ∧ code e605593427818 = 2804616683370 := by decide
theorem cert_e605593427818 : check e605593427818 [[],[]] .three = true := by decide
def e605593428206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e605593428206 : Closed e605593428206 ∧ code e605593428206 = 2804616683758 := by decide
theorem cert_e605593428206 : check e605593428206 [[],[]] .smaller = true := by decide
def e605593428218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e605593428218 : Closed e605593428218 ∧ code e605593428218 = 2804616683770 := by decide
theorem cert_e605593428218 : check e605593428218 [[],[]] .smaller = true := by decide
def e605593428398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e605593428398 : Closed e605593428398 ∧ code e605593428398 = 2804616683950 := by decide
theorem cert_e605593428398 : check e605593428398 [[],[]] .smaller = true := by decide
def e605593428590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593428590 : Closed e605593428590 ∧ code e605593428590 = 2804616684142 := by decide
theorem cert_e605593428590 : check e605593428590 [[],[]] .smaller = true := by decide
def e605593428602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593428602 : Closed e605593428602 ∧ code e605593428602 = 2804616684154 := by decide
theorem cert_e605593428602 : check e605593428602 [[],[]] .smaller = true := by decide
def e605593428766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e605593428766 : Closed e605593428766 ∧ code e605593428766 = 2804616684318 := by decide
theorem cert_e605593428766 : check e605593428766 [[],[]] .smaller = true := by decide
def e605593428934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e605593428934 : Closed e605593428934 ∧ code e605593428934 = 2804616684486 := by decide
theorem cert_e605593428934 : check e605593428934 [[],[]] .smaller = true := by decide
def e605593429550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605593429550 : Closed e605593429550 ∧ code e605593429550 = 2804616685102 := by decide
theorem cert_e605593429550 : check e605593429550 [[],[]] .smaller = true := by decide
def e605593429726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e605593429726 : Closed e605593429726 ∧ code e605593429726 = 2804616685278 := by decide
theorem cert_e605593429726 : check e605593429726 [[],[]] .three = true := by decide
def e605593429730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e605593429730 : Closed e605593429730 ∧ code e605593429730 = 2804616685282 := by decide
theorem cert_e605593429730 : check e605593429730 [[],[]] .smaller = true := by decide
def e605593429742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e605593429742 : Closed e605593429742 ∧ code e605593429742 = 2804616685294 := by decide
theorem cert_e605593429742 : check e605593429742 [[],[]] .smaller = true := by decide
def e605593429750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605593429750 : Closed e605593429750 ∧ code e605593429750 = 2804616685302 := by decide
theorem cert_e605593429750 : check e605593429750 [[],[]] .three = true := by decide
def e605593429854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e605593429854 : Closed e605593429854 ∧ code e605593429854 = 2804616685406 := by decide
theorem cert_e605593429854 : check e605593429854 [[],[]] .three = true := by decide
def e605593429870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605593429870 : Closed e605593429870 ∧ code e605593429870 = 2804616685422 := by decide
theorem cert_e605593429870 : check e605593429870 [[],[]] .smaller = true := by decide
def e605593429878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e605593429878 : Closed e605593429878 ∧ code e605593429878 = 2804616685430 := by decide
theorem cert_e605593429878 : check e605593429878 [[],[]] .smaller = true := by decide
def e605593429882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605593429882 : Closed e605593429882 ∧ code e605593429882 = 2804616685434 := by decide
theorem cert_e605593429882 : check e605593429882 [[],[]] .three = true := by decide
def e605593429898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605593429898 : Closed e605593429898 ∧ code e605593429898 = 2804616685450 := by decide
theorem cert_e605593429898 : check e605593429898 [[],[]] .smaller = true := by decide
def e605593429922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e605593429922 : Closed e605593429922 ∧ code e605593429922 = 2804616685474 := by decide
theorem cert_e605593429922 : check e605593429922 [[],[]] .smaller = true := by decide
def e605593429934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e605593429934 : Closed e605593429934 ∧ code e605593429934 = 2804616685486 := by decide
theorem cert_e605593429934 : check e605593429934 [[],[]] .smaller = true := by decide
def e605593429942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e605593429942 : Closed e605593429942 ∧ code e605593429942 = 2804616685494 := by decide
theorem cert_e605593429942 : check e605593429942 [[],[]] .smaller = true := by decide
def e605593429946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e605593429946 : Closed e605593429946 ∧ code e605593429946 = 2804616685498 := by decide
theorem cert_e605593429946 : check e605593429946 [[],[]] .smaller = true := by decide
def e605593429974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605593429974 : Closed e605593429974 ∧ code e605593429974 = 2804616685526 := by decide
theorem cert_e605593429974 : check e605593429974 [[],[]] .three = true := by decide
def e605593429978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605593429978 : Closed e605593429978 ∧ code e605593429978 = 2804616685530 := by decide
theorem cert_e605593429978 : check e605593429978 [[],[]] .three = true := by decide
def e605593430078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e605593430078 : Closed e605593430078 ∧ code e605593430078 = 2804616685630 := by decide
theorem cert_e605593430078 : check e605593430078 [[],[]] .smaller = true := by decide
def e605593430494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e605593430494 : Closed e605593430494 ∧ code e605593430494 = 2804616686046 := by decide
theorem cert_e605593430494 : check e605593430494 [[],[]] .three = true := by decide
def e605593430498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605593430498 : Closed e605593430498 ∧ code e605593430498 = 2804616686050 := by decide
theorem cert_e605593430498 : check e605593430498 [[],[]] .smaller = true := by decide
end Blc.Floor41
