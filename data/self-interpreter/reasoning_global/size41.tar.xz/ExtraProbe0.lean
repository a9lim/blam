import Extra41
import Batch001
import Batch029
import Batch030
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness149686410606
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u10 u9
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
private def u29 := Term.var 3
private def u30 := Term.app u4 u29
private def u31 := Term.lam u30
private def u32 := Term.lam u31
private def u33 := Term.app u32 u9
private def u34 := Term.app u33 u25
theorem nege149686410606 : ¬ IsSelfInterpreter e149686410606 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e149686410606 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left],[.left]] (Floor40.call e149686410606 u0 u2 u1 []) = some u26 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u26) (u := u34) [] (by decide) (replay_sound (ps := [[.left],[],[.left,.left],[.left],[]]) (by decide)) j hj
#print axioms nege149686410606
end Witness149686410606
namespace Witness565605051866
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u1
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565605051866 : ¬ IsSelfInterpreter e565605051866 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565605051866 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565605051866 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565605051866
end Witness565605051866
namespace Witness565605052250
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u1
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565605052250 : ¬ IsSelfInterpreter e565605052250 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565605052250 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565605052250 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565605052250
end Witness565605052250
namespace Witness565605054906
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u0 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u1
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565605054906 : ¬ IsSelfInterpreter e565605054906 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565605054906 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565605054906 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565605054906
end Witness565605054906
namespace Witness565605054954
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u0 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u1
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565605054954 : ¬ IsSelfInterpreter e565605054954 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565605054954 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565605054954 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565605054954
end Witness565605054954
namespace Witness565606133206
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u1
private def u6 := Term.app u5 u0
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606133206 : ¬ IsSelfInterpreter e565606133206 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606133206 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606133206 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606133206
end Witness565606133206
namespace Witness565606133434
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u5 u1
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606133434 : ¬ IsSelfInterpreter e565606133434 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606133434 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606133434 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606133434
end Witness565606133434
namespace Witness565606137066
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u1
private def u5 := Term.app u3 u4
private def u6 := Term.app u5 u1
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606137066 : ¬ IsSelfInterpreter e565606137066 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606137066 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606137066 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606137066
end Witness565606137066
end Blc.Floor41
