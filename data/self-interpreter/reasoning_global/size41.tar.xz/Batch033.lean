import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e597271951386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597271951386 : Closed e597271951386 ∧ code e597271951386 = 2796295206938 := by decide
theorem cert_e597271951386 : check e597271951386 [[]] .width = true := by decide
def e597271963674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597271963674 : Closed e597271963674 ∧ code e597271963674 = 2796295219226 := by decide
theorem cert_e597271963674 : check e597271963674 [[]] .width = true := by decide
def e597271992346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597271992346 : Closed e597271992346 ∧ code e597271992346 = 2796295247898 := by decide
theorem cert_e597271992346 : check e597271992346 [[]] .width = true := by decide
def e597271996442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597271996442 : Closed e597271996442 ∧ code e597271996442 = 2796295251994 := by decide
theorem cert_e597271996442 : check e597271996442 [[]] .width = true := by decide
def e597272279066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597272279066 : Closed e597272279066 ∧ code e597272279066 = 2796295534618 := by decide
theorem cert_e597272279066 : check e597272279066 [[]] .width = true := by decide
def e597272287258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597272287258 : Closed e597272287258 ∧ code e597272287258 = 2796295542810 := by decide
theorem cert_e597272287258 : check e597272287258 [[]] .width = true := by decide
def e597272672282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597272672282 : Closed e597272672282 ∧ code e597272672282 = 2796295927834 := by decide
theorem cert_e597272672282 : check e597272672282 [[]] .width = true := by decide
def e597272684570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597272684570 : Closed e597272684570 ∧ code e597272684570 = 2796295940122 := by decide
theorem cert_e597272684570 : check e597272684570 [[]] .width = true := by decide
def e597272877082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597272877082 : Closed e597272877082 ∧ code e597272877082 = 2796296132634 := by decide
theorem cert_e597272877082 : check e597272877082 [[]] .width = true := by decide
def e597272881178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597272881178 : Closed e597272881178 ∧ code e597272881178 = 2796296136730 := by decide
theorem cert_e597272881178 : check e597272881178 [[]] .width = true := by decide
def e597336042862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e597336042862 : Closed e597336042862 ∧ code e597336042862 = 2796359298414 := by decide
theorem cert_e597336042862 : check e597336042862 [[],[.left],[]] .chain = true := by decide
def e597336042870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e597336042870 : Closed e597336042870 ∧ code e597336042870 = 2796359298422 := by decide
theorem cert_e597336042870 : check e597336042870 [[],[.left],[]] .chain = true := by decide
def e597336042926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e597336042926 : Closed e597336042926 ∧ code e597336042926 = 2796359298478 := by decide
theorem cert_e597336042926 : check e597336042926 [[],[.left],[]] .chain = true := by decide
def e597336042938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e597336042938 : Closed e597336042938 ∧ code e597336042938 = 2796359298490 := by decide
theorem cert_e597336042938 : check e597336042938 [[],[.left],[]] .chain = true := by decide
def e597336042966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e597336042966 : Closed e597336042966 ∧ code e597336042966 = 2796359298518 := by decide
theorem cert_e597336042966 : check e597336042966 [[],[.left],[]] .chain = true := by decide
def e597336042970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e597336042970 : Closed e597336042970 ∧ code e597336042970 = 2796359298522 := by decide
theorem cert_e597336042970 : check e597336042970 [[],[.left],[]] .chain = true := by decide
def e597336043182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e597336043182 : Closed e597336043182 ∧ code e597336043182 = 2796359298734 := by decide
theorem cert_e597336043182 : check e597336043182 [[],[.left],[]] .chain = true := by decide
def e597336043194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e597336043194 : Closed e597336043194 ∧ code e597336043194 = 2796359298746 := by decide
theorem cert_e597336043194 : check e597336043194 [[],[.left],[]] .chain = true := by decide
def e597336043242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e597336043242 : Closed e597336043242 ∧ code e597336043242 = 2796359298794 := by decide
theorem cert_e597336043242 : check e597336043242 [[],[.left],[]] .chain = true := by decide
def e597336043350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e597336043350 : Closed e597336043350 ∧ code e597336043350 = 2796359298902 := by decide
theorem cert_e597336043350 : check e597336043350 [[],[.left],[]] .chain = true := by decide
def e597336043354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e597336043354 : Closed e597336043354 ∧ code e597336043354 = 2796359298906 := by decide
theorem cert_e597336043354 : check e597336043354 [[],[.left],[]] .chain = true := by decide
def e597336043370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e597336043370 : Closed e597336043370 ∧ code e597336043370 = 2796359298922 := by decide
theorem cert_e597336043370 : check e597336043370 [[],[.left],[]] .chain = true := by decide
def e597336044398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e597336044398 : Closed e597336044398 ∧ code e597336044398 = 2796359299950 := by decide
theorem cert_e597336044398 : check e597336044398 [[],[.left],[]] .chain = true := by decide
def e597336044406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e597336044406 : Closed e597336044406 ∧ code e597336044406 = 2796359299958 := by decide
theorem cert_e597336044406 : check e597336044406 [[],[.left],[]] .chain = true := by decide
def e597336044462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e597336044462 : Closed e597336044462 ∧ code e597336044462 = 2796359300014 := by decide
theorem cert_e597336044462 : check e597336044462 [[],[.left],[]] .chain = true := by decide
def e597336044474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e597336044474 : Closed e597336044474 ∧ code e597336044474 = 2796359300026 := by decide
theorem cert_e597336044474 : check e597336044474 [[],[.left],[]] .chain = true := by decide
def e597336044502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e597336044502 : Closed e597336044502 ∧ code e597336044502 = 2796359300054 := by decide
theorem cert_e597336044502 : check e597336044502 [[],[.left],[]] .chain = true := by decide
def e597336044506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e597336044506 : Closed e597336044506 ∧ code e597336044506 = 2796359300058 := by decide
theorem cert_e597336044506 : check e597336044506 [[],[.left],[]] .chain = true := by decide
def e597336044782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e597336044782 : Closed e597336044782 ∧ code e597336044782 = 2796359300334 := by decide
theorem cert_e597336044782 : check e597336044782 [[],[.left],[]] .chain = true := by decide
def e597336044790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e597336044790 : Closed e597336044790 ∧ code e597336044790 = 2796359300342 := by decide
theorem cert_e597336044790 : check e597336044790 [[],[.left],[]] .chain = true := by decide
def e597336045166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e597336045166 : Closed e597336045166 ∧ code e597336045166 = 2796359300718 := by decide
theorem cert_e597336045166 : check e597336045166 [[],[.left],[]] .chain = true := by decide
def e597336045178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e597336045178 : Closed e597336045178 ∧ code e597336045178 = 2796359300730 := by decide
theorem cert_e597336045178 : check e597336045178 [[],[.left],[]] .chain = true := by decide
def e597336045366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e597336045366 : Closed e597336045366 ∧ code e597336045366 = 2796359300918 := by decide
theorem cert_e597336045366 : check e597336045366 [[],[.left],[]] .chain = true := by decide
def e597336045370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e597336045370 : Closed e597336045370 ∧ code e597336045370 = 2796359300922 := by decide
theorem cert_e597336045370 : check e597336045370 [[],[.left],[]] .chain = true := by decide
def e597336045998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e597336045998 : Closed e597336045998 ∧ code e597336045998 = 2796359301550 := by decide
theorem cert_e597336045998 : check e597336045998 [[],[.left],[]] .chain = true := by decide
def e597336046010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e597336046010 : Closed e597336046010 ∧ code e597336046010 = 2796359301562 := by decide
theorem cert_e597336046010 : check e597336046010 [[],[.left],[]] .chain = true := by decide
def e597336046058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e597336046058 : Closed e597336046058 ∧ code e597336046058 = 2796359301610 := by decide
theorem cert_e597336046058 : check e597336046058 [[],[.left],[]] .chain = true := by decide
def e597336046190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e597336046190 : Closed e597336046190 ∧ code e597336046190 = 2796359301742 := by decide
theorem cert_e597336046190 : check e597336046190 [[],[.left],[]] .chain = true := by decide
def e597336046202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e597336046202 : Closed e597336046202 ∧ code e597336046202 = 2796359301754 := by decide
theorem cert_e597336046202 : check e597336046202 [[],[.left],[]] .chain = true := by decide
def e597336046490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e597336046490 : Closed e597336046490 ∧ code e597336046490 = 2796359302042 := by decide
theorem cert_e597336046490 : check e597336046490 [[],[.left],[]] .chain = true := by decide
def e597336046806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e597336046806 : Closed e597336046806 ∧ code e597336046806 = 2796359302358 := by decide
theorem cert_e597336046806 : check e597336046806 [[],[.left],[]] .chain = true := by decide
def e597336046810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e597336046810 : Closed e597336046810 ∧ code e597336046810 = 2796359302362 := by decide
theorem cert_e597336046810 : check e597336046810 [[],[.left],[]] .chain = true := by decide
def e597336046826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e597336046826 : Closed e597336046826 ∧ code e597336046826 = 2796359302378 := by decide
theorem cert_e597336046826 : check e597336046826 [[],[.left],[]] .chain = true := by decide
def e597336046902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e597336046902 : Closed e597336046902 ∧ code e597336046902 = 2796359302454 := by decide
theorem cert_e597336046902 : check e597336046902 [[],[.left],[]] .chain = true := by decide
def e597336046906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e597336046906 : Closed e597336046906 ∧ code e597336046906 = 2796359302458 := by decide
theorem cert_e597336046906 : check e597336046906 [[],[.left],[]] .chain = true := by decide
def e597336047002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e597336047002 : Closed e597336047002 ∧ code e597336047002 = 2796359302554 := by decide
theorem cert_e597336047002 : check e597336047002 [[],[.left],[]] .chain = true := by decide
def e597336050542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597336050542 : Closed e597336050542 ∧ code e597336050542 = 2796359306094 := by decide
theorem cert_e597336050542 : check e597336050542 [[],[.left],[]] .chain = true := by decide
def e597336050550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597336050550 : Closed e597336050550 ∧ code e597336050550 = 2796359306102 := by decide
theorem cert_e597336050550 : check e597336050550 [[],[.left],[]] .chain = true := by decide
def e597336050606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597336050606 : Closed e597336050606 ∧ code e597336050606 = 2796359306158 := by decide
theorem cert_e597336050606 : check e597336050606 [[],[.left],[]] .chain = true := by decide
def e597336050618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597336050618 : Closed e597336050618 ∧ code e597336050618 = 2796359306170 := by decide
theorem cert_e597336050618 : check e597336050618 [[],[.left],[]] .chain = true := by decide
def e597336050646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597336050646 : Closed e597336050646 ∧ code e597336050646 = 2796359306198 := by decide
theorem cert_e597336050646 : check e597336050646 [[],[.left],[]] .chain = true := by decide
def e597336050650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597336050650 : Closed e597336050650 ∧ code e597336050650 = 2796359306202 := by decide
theorem cert_e597336050650 : check e597336050650 [[],[.left],[]] .chain = true := by decide
def e597336050926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597336050926 : Closed e597336050926 ∧ code e597336050926 = 2796359306478 := by decide
theorem cert_e597336050926 : check e597336050926 [[],[.left],[]] .chain = true := by decide
def e597336050934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597336050934 : Closed e597336050934 ∧ code e597336050934 = 2796359306486 := by decide
theorem cert_e597336050934 : check e597336050934 [[],[.left],[]] .chain = true := by decide
def e597336051310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597336051310 : Closed e597336051310 ∧ code e597336051310 = 2796359306862 := by decide
theorem cert_e597336051310 : check e597336051310 [[],[.left],[]] .chain = true := by decide
def e597336051322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597336051322 : Closed e597336051322 ∧ code e597336051322 = 2796359306874 := by decide
theorem cert_e597336051322 : check e597336051322 [[],[.left],[]] .chain = true := by decide
def e597336051510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597336051510 : Closed e597336051510 ∧ code e597336051510 = 2796359307062 := by decide
theorem cert_e597336051510 : check e597336051510 [[],[.left],[]] .chain = true := by decide
def e597336051514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597336051514 : Closed e597336051514 ∧ code e597336051514 = 2796359307066 := by decide
theorem cert_e597336051514 : check e597336051514 [[],[.left],[]] .chain = true := by decide
def e597336057262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e597336057262 : Closed e597336057262 ∧ code e597336057262 = 2796359312814 := by decide
theorem cert_e597336057262 : check e597336057262 [[],[.left],[]] .chain = true := by decide
def e597336057274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e597336057274 : Closed e597336057274 ∧ code e597336057274 = 2796359312826 := by decide
theorem cert_e597336057274 : check e597336057274 [[],[.left],[]] .chain = true := by decide
def e597336057322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e597336057322 : Closed e597336057322 ∧ code e597336057322 = 2796359312874 := by decide
theorem cert_e597336057322 : check e597336057322 [[],[.left],[]] .chain = true := by decide
def e597336057454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e597336057454 : Closed e597336057454 ∧ code e597336057454 = 2796359313006 := by decide
theorem cert_e597336057454 : check e597336057454 [[],[.left],[]] .chain = true := by decide
def e597336057466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e597336057466 : Closed e597336057466 ∧ code e597336057466 = 2796359313018 := by decide
theorem cert_e597336057466 : check e597336057466 [[],[.left],[]] .chain = true := by decide
def e597336057754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e597336057754 : Closed e597336057754 ∧ code e597336057754 = 2796359313306 := by decide
theorem cert_e597336057754 : check e597336057754 [[],[.left],[]] .chain = true := by decide
def e597336060630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e597336060630 : Closed e597336060630 ∧ code e597336060630 = 2796359316182 := by decide
theorem cert_e597336060630 : check e597336060630 [[],[.left],[]] .chain = true := by decide
def e597336060634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e597336060634 : Closed e597336060634 ∧ code e597336060634 = 2796359316186 := by decide
theorem cert_e597336060634 : check e597336060634 [[],[.left],[]] .chain = true := by decide
def e597336060650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e597336060650 : Closed e597336060650 ∧ code e597336060650 = 2796359316202 := by decide
theorem cert_e597336060650 : check e597336060650 [[],[.left],[]] .chain = true := by decide
def e597336060726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e597336060726 : Closed e597336060726 ∧ code e597336060726 = 2796359316278 := by decide
theorem cert_e597336060726 : check e597336060726 [[],[.left],[]] .chain = true := by decide
def e597336060730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e597336060730 : Closed e597336060730 ∧ code e597336060730 = 2796359316282 := by decide
theorem cert_e597336060730 : check e597336060730 [[],[.left],[]] .chain = true := by decide
def e597336060826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e597336060826 : Closed e597336060826 ∧ code e597336060826 = 2796359316378 := by decide
theorem cert_e597336060826 : check e597336060826 [[],[.left],[]] .chain = true := by decide
def e597336176366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e597336176366 : Closed e597336176366 ∧ code e597336176366 = 2796359431918 := by decide
theorem cert_e597336176366 : check e597336176366 [[],[.left]] .chain = true := by decide
def e597336176494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e597336176494 : Closed e597336176494 ∧ code e597336176494 = 2796359432046 := by decide
theorem cert_e597336176494 : check e597336176494 [[],[.left]] .chain = true := by decide
def e597336176502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e597336176502 : Closed e597336176502 ∧ code e597336176502 = 2796359432054 := by decide
theorem cert_e597336176502 : check e597336176502 [[],[.left]] .chain = true := by decide
def e597336177390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e597336177390 : Closed e597336177390 ∧ code e597336177390 = 2796359432942 := by decide
theorem cert_e597336177390 : check e597336177390 [[],[.left]] .chain = true := by decide
def e597336177582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e597336177582 : Closed e597336177582 ∧ code e597336177582 = 2796359433134 := by decide
theorem cert_e597336177582 : check e597336177582 [[],[.left]] .chain = true := by decide
def e597336177594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e597336177594 : Closed e597336177594 ∧ code e597336177594 = 2796359433146 := by decide
theorem cert_e597336177594 : check e597336177594 [[],[.left]] .chain = true := by decide
def e597336178030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e597336178030 : Closed e597336178030 ∧ code e597336178030 = 2796359433582 := by decide
theorem cert_e597336178030 : check e597336178030 [[],[.left]] .chain = true := by decide
def e597336178038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e597336178038 : Closed e597336178038 ∧ code e597336178038 = 2796359433590 := by decide
theorem cert_e597336178038 : check e597336178038 [[],[.left]] .chain = true := by decide
def e597336178094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e597336178094 : Closed e597336178094 ∧ code e597336178094 = 2796359433646 := by decide
theorem cert_e597336178094 : check e597336178094 [[],[.left]] .chain = true := by decide
def e597336178106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e597336178106 : Closed e597336178106 ∧ code e597336178106 = 2796359433658 := by decide
theorem cert_e597336178106 : check e597336178106 [[],[.left]] .chain = true := by decide
def e597336178134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e597336178134 : Closed e597336178134 ∧ code e597336178134 = 2796359433686 := by decide
theorem cert_e597336178134 : check e597336178134 [[],[.left]] .chain = true := by decide
def e597336178138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e597336178138 : Closed e597336178138 ∧ code e597336178138 = 2796359433690 := by decide
theorem cert_e597336178138 : check e597336178138 [[],[.left]] .chain = true := by decide
def e597336182510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e597336182510 : Closed e597336182510 ∧ code e597336182510 = 2796359438062 := by decide
theorem cert_e597336182510 : check e597336182510 [[],[.left]] .chain = true := by decide
def e597336182638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e597336182638 : Closed e597336182638 ∧ code e597336182638 = 2796359438190 := by decide
theorem cert_e597336182638 : check e597336182638 [[],[.left]] .chain = true := by decide
def e597336182646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e597336182646 : Closed e597336182646 ∧ code e597336182646 = 2796359438198 := by decide
theorem cert_e597336182646 : check e597336182646 [[],[.left]] .chain = true := by decide
def e597336185326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e597336185326 : Closed e597336185326 ∧ code e597336185326 = 2796359440878 := by decide
theorem cert_e597336185326 : check e597336185326 [[],[.left]] .chain = true := by decide
def e597336186094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e597336186094 : Closed e597336186094 ∧ code e597336186094 = 2796359441646 := by decide
theorem cert_e597336186094 : check e597336186094 [[],[.left]] .chain = true := by decide
def e597336186102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e597336186102 : Closed e597336186102 ∧ code e597336186102 = 2796359441654 := by decide
theorem cert_e597336186102 : check e597336186102 [[],[.left]] .chain = true := by decide
def e597336188654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e597336188654 : Closed e597336188654 ∧ code e597336188654 = 2796359444206 := by decide
theorem cert_e597336188654 : check e597336188654 [[],[.left]] .chain = true := by decide
def e597336188846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e597336188846 : Closed e597336188846 ∧ code e597336188846 = 2796359444398 := by decide
theorem cert_e597336188846 : check e597336188846 [[],[.left]] .chain = true := by decide
def e597336188858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e597336188858 : Closed e597336188858 ∧ code e597336188858 = 2796359444410 := by decide
theorem cert_e597336188858 : check e597336188858 [[],[.left]] .chain = true := by decide
def e597336189422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e597336189422 : Closed e597336189422 ∧ code e597336189422 = 2796359444974 := by decide
theorem cert_e597336189422 : check e597336189422 [[],[.left]] .chain = true := by decide
def e597336190574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e597336190574 : Closed e597336190574 ∧ code e597336190574 = 2796359446126 := by decide
theorem cert_e597336190574 : check e597336190574 [[],[.left]] .chain = true := by decide
def e597336190586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e597336190586 : Closed e597336190586 ∧ code e597336190586 = 2796359446138 := by decide
theorem cert_e597336190586 : check e597336190586 [[],[.left]] .chain = true := by decide
def e597336191854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e597336191854 : Closed e597336191854 ∧ code e597336191854 = 2796359447406 := by decide
theorem cert_e597336191854 : check e597336191854 [[],[.left]] .chain = true := by decide
def e597336191862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e597336191862 : Closed e597336191862 ∧ code e597336191862 = 2796359447414 := by decide
theorem cert_e597336191862 : check e597336191862 [[],[.left]] .chain = true := by decide
def e597336191918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e597336191918 : Closed e597336191918 ∧ code e597336191918 = 2796359447470 := by decide
theorem cert_e597336191918 : check e597336191918 [[],[.left]] .chain = true := by decide
def e597336191930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e597336191930 : Closed e597336191930 ∧ code e597336191930 = 2796359447482 := by decide
theorem cert_e597336191930 : check e597336191930 [[],[.left]] .chain = true := by decide
def e597336191958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e597336191958 : Closed e597336191958 ∧ code e597336191958 = 2796359447510 := by decide
theorem cert_e597336191958 : check e597336191958 [[],[.left]] .chain = true := by decide
def e597336191962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e597336191962 : Closed e597336191962 ∧ code e597336191962 = 2796359447514 := by decide
theorem cert_e597336191962 : check e597336191962 [[],[.left]] .chain = true := by decide
def e597336192238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e597336192238 : Closed e597336192238 ∧ code e597336192238 = 2796359447790 := by decide
theorem cert_e597336192238 : check e597336192238 [[],[.left]] .chain = true := by decide
def e597336192246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e597336192246 : Closed e597336192246 ∧ code e597336192246 = 2796359447798 := by decide
theorem cert_e597336192246 : check e597336192246 [[],[.left]] .chain = true := by decide
def e597336192622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e597336192622 : Closed e597336192622 ∧ code e597336192622 = 2796359448174 := by decide
theorem cert_e597336192622 : check e597336192622 [[],[.left]] .chain = true := by decide
def e597336192634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e597336192634 : Closed e597336192634 ∧ code e597336192634 = 2796359448186 := by decide
theorem cert_e597336192634 : check e597336192634 [[],[.left]] .chain = true := by decide
def e597336192822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e597336192822 : Closed e597336192822 ∧ code e597336192822 = 2796359448374 := by decide
theorem cert_e597336192822 : check e597336192822 [[],[.left]] .chain = true := by decide
def e597336192826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e597336192826 : Closed e597336192826 ∧ code e597336192826 = 2796359448378 := by decide
theorem cert_e597336192826 : check e597336192826 [[],[.left]] .chain = true := by decide
def e597336197998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597336197998 : Closed e597336197998 ∧ code e597336197998 = 2796359453550 := by decide
theorem cert_e597336197998 : check e597336197998 [[],[.left],[]] .chain = true := by decide
def e597336198006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597336198006 : Closed e597336198006 ∧ code e597336198006 = 2796359453558 := by decide
theorem cert_e597336198006 : check e597336198006 [[],[.left],[]] .chain = true := by decide
def e597336198062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597336198062 : Closed e597336198062 ∧ code e597336198062 = 2796359453614 := by decide
theorem cert_e597336198062 : check e597336198062 [[],[.left],[]] .chain = true := by decide
def e597336198074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597336198074 : Closed e597336198074 ∧ code e597336198074 = 2796359453626 := by decide
theorem cert_e597336198074 : check e597336198074 [[],[.left],[]] .chain = true := by decide
def e597336198102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597336198102 : Closed e597336198102 ∧ code e597336198102 = 2796359453654 := by decide
theorem cert_e597336198102 : check e597336198102 [[],[.left],[]] .chain = true := by decide
def e597336198106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597336198106 : Closed e597336198106 ∧ code e597336198106 = 2796359453658 := by decide
theorem cert_e597336198106 : check e597336198106 [[],[.left],[]] .chain = true := by decide
def e597336198382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597336198382 : Closed e597336198382 ∧ code e597336198382 = 2796359453934 := by decide
theorem cert_e597336198382 : check e597336198382 [[],[.left],[]] .chain = true := by decide
def e597336198390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597336198390 : Closed e597336198390 ∧ code e597336198390 = 2796359453942 := by decide
theorem cert_e597336198390 : check e597336198390 [[],[.left],[]] .chain = true := by decide
def e597336198766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597336198766 : Closed e597336198766 ∧ code e597336198766 = 2796359454318 := by decide
theorem cert_e597336198766 : check e597336198766 [[],[.left],[]] .chain = true := by decide
def e597336198778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597336198778 : Closed e597336198778 ∧ code e597336198778 = 2796359454330 := by decide
theorem cert_e597336198778 : check e597336198778 [[],[.left],[]] .chain = true := by decide
def e597336198966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597336198966 : Closed e597336198966 ∧ code e597336198966 = 2796359454518 := by decide
theorem cert_e597336198966 : check e597336198966 [[],[.left],[]] .chain = true := by decide
def e597336198970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597336198970 : Closed e597336198970 ∧ code e597336198970 = 2796359454522 := by decide
theorem cert_e597336198970 : check e597336198970 [[],[.left],[]] .chain = true := by decide
def e597336207086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e597336207086 : Closed e597336207086 ∧ code e597336207086 = 2796359462638 := by decide
theorem cert_e597336207086 : check e597336207086 [[],[.left]] .chain = true := by decide
def e597336207214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e597336207214 : Closed e597336207214 ∧ code e597336207214 = 2796359462766 := by decide
theorem cert_e597336207214 : check e597336207214 [[],[.left]] .chain = true := by decide
def e597336207222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e597336207222 : Closed e597336207222 ∧ code e597336207222 = 2796359462774 := by decide
theorem cert_e597336207222 : check e597336207222 [[],[.left]] .chain = true := by decide
def e597336209902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e597336209902 : Closed e597336209902 ∧ code e597336209902 = 2796359465454 := by decide
theorem cert_e597336209902 : check e597336209902 [[],[.left]] .chain = true := by decide
def e597336210670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e597336210670 : Closed e597336210670 ∧ code e597336210670 = 2796359466222 := by decide
theorem cert_e597336210670 : check e597336210670 [[],[.left]] .chain = true := by decide
def e597336210678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e597336210678 : Closed e597336210678 ∧ code e597336210678 = 2796359466230 := by decide
theorem cert_e597336210678 : check e597336210678 [[],[.left]] .chain = true := by decide
def e597336233710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e597336233710 : Closed e597336233710 ∧ code e597336233710 = 2796359489262 := by decide
theorem cert_e597336233710 : check e597336233710 [[],[.left]] .chain = true := by decide
def e597336233902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e597336233902 : Closed e597336233902 ∧ code e597336233902 = 2796359489454 := by decide
theorem cert_e597336233902 : check e597336233902 [[],[.left]] .chain = true := by decide
def e597336233914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e597336233914 : Closed e597336233914 ∧ code e597336233914 = 2796359489466 := by decide
theorem cert_e597336233914 : check e597336233914 [[],[.left]] .chain = true := by decide
def e597336234478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e597336234478 : Closed e597336234478 ∧ code e597336234478 = 2796359490030 := by decide
theorem cert_e597336234478 : check e597336234478 [[],[.left]] .chain = true := by decide
def e597336235630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e597336235630 : Closed e597336235630 ∧ code e597336235630 = 2796359491182 := by decide
theorem cert_e597336235630 : check e597336235630 [[],[.left]] .chain = true := by decide
def e597336235642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e597336235642 : Closed e597336235642 ∧ code e597336235642 = 2796359491194 := by decide
theorem cert_e597336235642 : check e597336235642 [[],[.left]] .chain = true := by decide
def e597336247150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597336247150 : Closed e597336247150 ∧ code e597336247150 = 2796359502702 := by decide
theorem cert_e597336247150 : check e597336247150 [[],[.left]] .chain = true := by decide
def e597336247158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597336247158 : Closed e597336247158 ∧ code e597336247158 = 2796359502710 := by decide
theorem cert_e597336247158 : check e597336247158 [[],[.left]] .chain = true := by decide
def e597336247214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597336247214 : Closed e597336247214 ∧ code e597336247214 = 2796359502766 := by decide
theorem cert_e597336247214 : check e597336247214 [[],[.left]] .chain = true := by decide
def e597336247226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597336247226 : Closed e597336247226 ∧ code e597336247226 = 2796359502778 := by decide
theorem cert_e597336247226 : check e597336247226 [[],[.left]] .chain = true := by decide
def e597336247254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597336247254 : Closed e597336247254 ∧ code e597336247254 = 2796359502806 := by decide
theorem cert_e597336247254 : check e597336247254 [[],[.left]] .chain = true := by decide
def e597336247258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597336247258 : Closed e597336247258 ∧ code e597336247258 = 2796359502810 := by decide
theorem cert_e597336247258 : check e597336247258 [[],[.left]] .chain = true := by decide
def e597336247534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597336247534 : Closed e597336247534 ∧ code e597336247534 = 2796359503086 := by decide
theorem cert_e597336247534 : check e597336247534 [[],[.left]] .chain = true := by decide
def e597336247542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597336247542 : Closed e597336247542 ∧ code e597336247542 = 2796359503094 := by decide
theorem cert_e597336247542 : check e597336247542 [[],[.left]] .chain = true := by decide
def e597336247918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597336247918 : Closed e597336247918 ∧ code e597336247918 = 2796359503470 := by decide
theorem cert_e597336247918 : check e597336247918 [[],[.left]] .chain = true := by decide
def e597336247930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597336247930 : Closed e597336247930 ∧ code e597336247930 = 2796359503482 := by decide
theorem cert_e597336247930 : check e597336247930 [[],[.left]] .chain = true := by decide
def e597336248118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597336248118 : Closed e597336248118 ∧ code e597336248118 = 2796359503670 := by decide
theorem cert_e597336248118 : check e597336248118 [[],[.left]] .chain = true := by decide
def e597336248122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597336248122 : Closed e597336248122 ∧ code e597336248122 = 2796359503674 := by decide
theorem cert_e597336248122 : check e597336248122 [[],[.left]] .chain = true := by decide
def e597336787822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597336787822 : Closed e597336787822 ∧ code e597336787822 = 2796360043374 := by decide
theorem cert_e597336787822 : check e597336787822 [[],[.left],[],[]] .smaller = true := by decide
def e597336787830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597336787830 : Closed e597336787830 ∧ code e597336787830 = 2796360043382 := by decide
theorem cert_e597336787830 : check e597336787830 [[],[.left],[],[]] .smaller = true := by decide
def e597336787886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597336787886 : Closed e597336787886 ∧ code e597336787886 = 2796360043438 := by decide
theorem cert_e597336787886 : check e597336787886 [[],[.left],[],[]] .smaller = true := by decide
def e597336787898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597336787898 : Closed e597336787898 ∧ code e597336787898 = 2796360043450 := by decide
theorem cert_e597336787898 : check e597336787898 [[],[.left],[],[]] .smaller = true := by decide
def e597336787926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597336787926 : Closed e597336787926 ∧ code e597336787926 = 2796360043478 := by decide
theorem cert_e597336787926 : check e597336787926 [[],[.left],[],[]] .smaller = true := by decide
def e597336787930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597336787930 : Closed e597336787930 ∧ code e597336787930 = 2796360043482 := by decide
theorem cert_e597336787930 : check e597336787930 [[],[.left],[],[]] .smaller = true := by decide
def e597336788206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597336788206 : Closed e597336788206 ∧ code e597336788206 = 2796360043758 := by decide
theorem cert_e597336788206 : check e597336788206 [[],[.left],[],[]] .smaller = true := by decide
def e597336788214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597336788214 : Closed e597336788214 ∧ code e597336788214 = 2796360043766 := by decide
theorem cert_e597336788214 : check e597336788214 [[],[.left],[],[]] .smaller = true := by decide
def e597336788590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597336788590 : Closed e597336788590 ∧ code e597336788590 = 2796360044142 := by decide
theorem cert_e597336788590 : check e597336788590 [[],[.left],[],[]] .smaller = true := by decide
def e597336788602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597336788602 : Closed e597336788602 ∧ code e597336788602 = 2796360044154 := by decide
theorem cert_e597336788602 : check e597336788602 [[],[.left],[],[]] .smaller = true := by decide
def e597336788790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597336788790 : Closed e597336788790 ∧ code e597336788790 = 2796360044342 := by decide
theorem cert_e597336788790 : check e597336788790 [[],[.left],[],[]] .smaller = true := by decide
def e597336788794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597336788794 : Closed e597336788794 ∧ code e597336788794 = 2796360044346 := by decide
theorem cert_e597336788794 : check e597336788794 [[],[.left],[],[]] .smaller = true := by decide
def e597436750702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e597436750702 : Closed e597436750702 ∧ code e597436750702 = 2796460006254 := by decide
theorem cert_e597436750702 : check e597436750702 [[],[.left],[]] .sourceHead = true := by decide
def e597436750710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e597436750710 : Closed e597436750710 ∧ code e597436750710 = 2796460006262 := by decide
theorem cert_e597436750710 : check e597436750710 [[],[.left],[]] .sourceHead = true := by decide
def e597436750774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e597436750774 : Closed e597436750774 ∧ code e597436750774 = 2796460006326 := by decide
theorem cert_e597436750774 : check e597436750774 [[],[.left],[]] .sourceHead = true := by decide
def e597436751214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e597436751214 : Closed e597436751214 ∧ code e597436751214 = 2796460006766 := by decide
def e597436751222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e597436751222 : Closed e597436751222 ∧ code e597436751222 = 2796460006774 := by decide
theorem cert_e597436751222 : check e597436751222 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436751278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e597436751278 : Closed e597436751278 ∧ code e597436751278 = 2796460006830 := by decide
theorem cert_e597436751278 : check e597436751278 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor41
