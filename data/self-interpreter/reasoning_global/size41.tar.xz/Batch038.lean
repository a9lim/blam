import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598276298266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276298266 : Closed e598276298266 ∧ code e598276298266 = 2797299553818 := by decide
private def t_e598276298266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276298266 : ¬ IsSelfInterpreter e598276298266 :=
  wSource (t := t_e598276298266) (replay_sound (ps := []) (t := e598276298266) (by decide)) (by decide)
def e598276299290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276299290 : Closed e598276299290 ∧ code e598276299290 = 2797299554842 := by decide
private def t_e598276299290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276299290 : ¬ IsSelfInterpreter e598276299290 :=
  wSource (t := t_e598276299290) (replay_sound (ps := []) (t := e598276299290) (by decide)) (by decide)
def e598276369946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276369946 : Closed e598276369946 ∧ code e598276369946 = 2797299625498 := by decide
private def t_e598276369946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276369946 : ¬ IsSelfInterpreter e598276369946 :=
  wSource (t := t_e598276369946) (replay_sound (ps := []) (t := e598276369946) (by decide)) (by decide)
def e598276371994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276371994 : Closed e598276371994 ∧ code e598276371994 = 2797299627546 := by decide
private def t_e598276371994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276371994 : ¬ IsSelfInterpreter e598276371994 :=
  wSource (t := t_e598276371994) (replay_sound (ps := []) (t := e598276371994) (by decide)) (by decide)
def e598276468250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276468250 : Closed e598276468250 ∧ code e598276468250 = 2797299723802 := by decide
private def t_e598276468250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276468250 : ¬ IsSelfInterpreter e598276468250 :=
  wSource (t := t_e598276468250) (replay_sound (ps := []) (t := e598276468250) (by decide)) (by decide)
def e598276471322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276471322 : Closed e598276471322 ∧ code e598276471322 = 2797299726874 := by decide
private def t_e598276471322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276471322 : ¬ IsSelfInterpreter e598276471322 :=
  wSource (t := t_e598276471322) (replay_sound (ps := []) (t := e598276471322) (by decide)) (by decide)
def e598276519450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276519450 : Closed e598276519450 ∧ code e598276519450 = 2797299775002 := by decide
private def t_e598276519450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276519450 : ¬ IsSelfInterpreter e598276519450 :=
  wSource (t := t_e598276519450) (replay_sound (ps := []) (t := e598276519450) (by decide)) (by decide)
def e598276520474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276520474 : Closed e598276520474 ∧ code e598276520474 = 2797299776026 := by decide
private def t_e598276520474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276520474 : ¬ IsSelfInterpreter e598276520474 :=
  wSource (t := t_e598276520474) (replay_sound (ps := []) (t := e598276520474) (by decide)) (by decide)
def e598292344174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e598292344174 : Closed e598292344174 ∧ code e598292344174 = 2797315599726 := by decide
theorem cert_e598292344174 : check e598292344174 [[],[.left],[]] .sourceHead = true := by decide
def e598292344182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e598292344182 : Closed e598292344182 ∧ code e598292344182 = 2797315599734 := by decide
theorem cert_e598292344182 : check e598292344182 [[],[.left],[]] .sourceHead = true := by decide
def e598292344238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e598292344238 : Closed e598292344238 ∧ code e598292344238 = 2797315599790 := by decide
theorem cert_e598292344238 : check e598292344238 [[],[.left],[]] .sourceHead = true := by decide
def e598292344250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e598292344250 : Closed e598292344250 ∧ code e598292344250 = 2797315599802 := by decide
theorem cert_e598292344250 : check e598292344250 [[],[.left],[]] .sourceHead = true := by decide
def e598292344278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e598292344278 : Closed e598292344278 ∧ code e598292344278 = 2797315599830 := by decide
theorem cert_e598292344278 : check e598292344278 [[],[.left],[]] .sourceHead = true := by decide
def e598292344282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e598292344282 : Closed e598292344282 ∧ code e598292344282 = 2797315599834 := by decide
theorem cert_e598292344282 : check e598292344282 [[],[.left],[]] .sourceHead = true := by decide
def e598292344494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e598292344494 : Closed e598292344494 ∧ code e598292344494 = 2797315600046 := by decide
theorem cert_e598292344494 : check e598292344494 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e598292344506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e598292344506 : Closed e598292344506 ∧ code e598292344506 = 2797315600058 := by decide
theorem cert_e598292344506 : check e598292344506 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e598292344554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e598292344554 : Closed e598292344554 ∧ code e598292344554 = 2797315600106 := by decide
theorem cert_e598292344554 : check e598292344554 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e598292344662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e598292344662 : Closed e598292344662 ∧ code e598292344662 = 2797315600214 := by decide
theorem cert_e598292344662 : check e598292344662 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292344666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e598292344666 : Closed e598292344666 ∧ code e598292344666 = 2797315600218 := by decide
theorem cert_e598292344666 : check e598292344666 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292344682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e598292344682 : Closed e598292344682 ∧ code e598292344682 = 2797315600234 := by decide
theorem cert_e598292344682 : check e598292344682 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left]] .chain = true := by decide
def e598292345710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e598292345710 : Closed e598292345710 ∧ code e598292345710 = 2797315601262 := by decide
theorem cert_e598292345710 : check e598292345710 [[],[.left],[]] .sourceHead = true := by decide
def e598292345718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e598292345718 : Closed e598292345718 ∧ code e598292345718 = 2797315601270 := by decide
theorem cert_e598292345718 : check e598292345718 [[],[.left],[]] .sourceHead = true := by decide
def e598292345774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e598292345774 : Closed e598292345774 ∧ code e598292345774 = 2797315601326 := by decide
theorem cert_e598292345774 : check e598292345774 [[],[.left],[]] .sourceHead = true := by decide
def e598292345786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e598292345786 : Closed e598292345786 ∧ code e598292345786 = 2797315601338 := by decide
theorem cert_e598292345786 : check e598292345786 [[],[.left],[]] .sourceHead = true := by decide
def e598292345814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e598292345814 : Closed e598292345814 ∧ code e598292345814 = 2797315601366 := by decide
theorem cert_e598292345814 : check e598292345814 [[],[.left],[]] .sourceHead = true := by decide
def e598292345818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e598292345818 : Closed e598292345818 ∧ code e598292345818 = 2797315601370 := by decide
theorem cert_e598292345818 : check e598292345818 [[],[.left],[]] .sourceHead = true := by decide
def e598292346094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e598292346094 : Closed e598292346094 ∧ code e598292346094 = 2797315601646 := by decide
theorem cert_e598292346094 : check e598292346094 [[],[.left],[]] .sourceHead = true := by decide
def e598292346102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e598292346102 : Closed e598292346102 ∧ code e598292346102 = 2797315601654 := by decide
theorem cert_e598292346102 : check e598292346102 [[],[.left],[]] .sourceHead = true := by decide
def e598292346478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e598292346478 : Closed e598292346478 ∧ code e598292346478 = 2797315602030 := by decide
theorem cert_e598292346478 : check e598292346478 [[],[.left],[]] .sourceHead = true := by decide
def e598292346490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e598292346490 : Closed e598292346490 ∧ code e598292346490 = 2797315602042 := by decide
theorem cert_e598292346490 : check e598292346490 [[],[.left],[]] .sourceHead = true := by decide
def e598292346678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e598292346678 : Closed e598292346678 ∧ code e598292346678 = 2797315602230 := by decide
theorem cert_e598292346678 : check e598292346678 [[],[.left],[]] .sourceHead = true := by decide
def e598292346682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e598292346682 : Closed e598292346682 ∧ code e598292346682 = 2797315602234 := by decide
theorem cert_e598292346682 : check e598292346682 [[],[.left],[]] .sourceHead = true := by decide
def e598292347310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e598292347310 : Closed e598292347310 ∧ code e598292347310 = 2797315602862 := by decide
theorem cert_e598292347310 : check e598292347310 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292347322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e598292347322 : Closed e598292347322 ∧ code e598292347322 = 2797315602874 := by decide
theorem cert_e598292347322 : check e598292347322 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292347370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e598292347370 : Closed e598292347370 ∧ code e598292347370 = 2797315602922 := by decide
theorem cert_e598292347370 : check e598292347370 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598292347502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e598292347502 : Closed e598292347502 ∧ code e598292347502 = 2797315603054 := by decide
theorem cert_e598292347502 : check e598292347502 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292347514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e598292347514 : Closed e598292347514 ∧ code e598292347514 = 2797315603066 := by decide
theorem cert_e598292347514 : check e598292347514 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292347802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e598292347802 : Closed e598292347802 ∧ code e598292347802 = 2797315603354 := by decide
theorem cert_e598292347802 : check e598292347802 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e598292348118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e598292348118 : Closed e598292348118 ∧ code e598292348118 = 2797315603670 := by decide
theorem cert_e598292348118 : check e598292348118 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292348122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e598292348122 : Closed e598292348122 ∧ code e598292348122 = 2797315603674 := by decide
theorem cert_e598292348122 : check e598292348122 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292348138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e598292348138 : Closed e598292348138 ∧ code e598292348138 = 2797315603690 := by decide
theorem cert_e598292348138 : check e598292348138 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e598292348214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e598292348214 : Closed e598292348214 ∧ code e598292348214 = 2797315603766 := by decide
theorem cert_e598292348214 : checkPay e598292348214 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598292348218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e598292348218 : Closed e598292348218 ∧ code e598292348218 = 2797315603770 := by decide
theorem cert_e598292348218 : checkPay e598292348218 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598292348314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e598292348314 : Closed e598292348314 ∧ code e598292348314 = 2797315603866 := by decide
theorem cert_e598292348314 : check e598292348314 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598292351854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598292351854 : Closed e598292351854 ∧ code e598292351854 = 2797315607406 := by decide
theorem cert_e598292351854 : check e598292351854 [[],[.left],[]] .sourceHead = true := by decide
def e598292351862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598292351862 : Closed e598292351862 ∧ code e598292351862 = 2797315607414 := by decide
theorem cert_e598292351862 : check e598292351862 [[],[.left],[]] .sourceHead = true := by decide
def e598292351918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598292351918 : Closed e598292351918 ∧ code e598292351918 = 2797315607470 := by decide
theorem cert_e598292351918 : check e598292351918 [[],[.left],[]] .sourceHead = true := by decide
def e598292351930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598292351930 : Closed e598292351930 ∧ code e598292351930 = 2797315607482 := by decide
theorem cert_e598292351930 : check e598292351930 [[],[.left],[]] .sourceHead = true := by decide
def e598292351958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598292351958 : Closed e598292351958 ∧ code e598292351958 = 2797315607510 := by decide
theorem cert_e598292351958 : check e598292351958 [[],[.left],[]] .sourceHead = true := by decide
def e598292351962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598292351962 : Closed e598292351962 ∧ code e598292351962 = 2797315607514 := by decide
theorem cert_e598292351962 : check e598292351962 [[],[.left],[]] .sourceHead = true := by decide
def e598292352238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598292352238 : Closed e598292352238 ∧ code e598292352238 = 2797315607790 := by decide
theorem cert_e598292352238 : check e598292352238 [[],[.left],[]] .sourceHead = true := by decide
def e598292352246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598292352246 : Closed e598292352246 ∧ code e598292352246 = 2797315607798 := by decide
theorem cert_e598292352246 : check e598292352246 [[],[.left],[]] .sourceHead = true := by decide
def e598292352622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598292352622 : Closed e598292352622 ∧ code e598292352622 = 2797315608174 := by decide
theorem cert_e598292352622 : check e598292352622 [[],[.left],[]] .sourceHead = true := by decide
def e598292352634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598292352634 : Closed e598292352634 ∧ code e598292352634 = 2797315608186 := by decide
theorem cert_e598292352634 : check e598292352634 [[],[.left],[]] .sourceHead = true := by decide
def e598292352822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598292352822 : Closed e598292352822 ∧ code e598292352822 = 2797315608374 := by decide
theorem cert_e598292352822 : check e598292352822 [[],[.left],[]] .sourceHead = true := by decide
def e598292352826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598292352826 : Closed e598292352826 ∧ code e598292352826 = 2797315608378 := by decide
theorem cert_e598292352826 : check e598292352826 [[],[.left],[]] .sourceHead = true := by decide
def e598292358574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e598292358574 : Closed e598292358574 ∧ code e598292358574 = 2797315614126 := by decide
theorem cert_e598292358574 : check e598292358574 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292358586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e598292358586 : Closed e598292358586 ∧ code e598292358586 = 2797315614138 := by decide
theorem cert_e598292358586 : check e598292358586 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598292358634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e598292358634 : Closed e598292358634 ∧ code e598292358634 = 2797315614186 := by decide
theorem cert_e598292358634 : check e598292358634 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e598292358766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e598292358766 : Closed e598292358766 ∧ code e598292358766 = 2797315614318 := by decide
theorem cert_e598292358766 : checkPay e598292358766 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598292358778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e598292358778 : Closed e598292358778 ∧ code e598292358778 = 2797315614330 := by decide
theorem cert_e598292358778 : checkPay e598292358778 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e598292359066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e598292359066 : Closed e598292359066 ∧ code e598292359066 = 2797315614618 := by decide
theorem cert_e598292359066 : check e598292359066 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598292361942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e598292361942 : Closed e598292361942 ∧ code e598292361942 = 2797315617494 := by decide
theorem cert_e598292361942 : check e598292361942 [[],[.left],[],[.under]] .three = true := by decide
def e598292361946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e598292361946 : Closed e598292361946 ∧ code e598292361946 = 2797315617498 := by decide
theorem cert_e598292361946 : check e598292361946 [[],[.left],[],[.under]] .three = true := by decide
def e598292361962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e598292361962 : Closed e598292361962 ∧ code e598292361962 = 2797315617514 := by decide
theorem cert_e598292361962 : check e598292361962 [[],[.left],[],[.under]] .three = true := by decide
def e598292362038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e598292362038 : Closed e598292362038 ∧ code e598292362038 = 2797315617590 := by decide
theorem cert_e598292362038 : check e598292362038 [[],[.left],[],[.under]] .three = true := by decide
def e598292362042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e598292362042 : Closed e598292362042 ∧ code e598292362042 = 2797315617594 := by decide
theorem cert_e598292362042 : check e598292362042 [[],[.left],[],[.under]] .three = true := by decide
def e598292362138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e598292362138 : Closed e598292362138 ∧ code e598292362138 = 2797315617690 := by decide
theorem cert_e598292362138 : check e598292362138 [[],[.left],[],[.under]] .three = true := by decide
def e598292499310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598292499310 : Closed e598292499310 ∧ code e598292499310 = 2797315754862 := by decide
def e598292499318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598292499318 : Closed e598292499318 ∧ code e598292499318 = 2797315754870 := by decide
def e598292499374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598292499374 : Closed e598292499374 ∧ code e598292499374 = 2797315754926 := by decide
def e598292499386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598292499386 : Closed e598292499386 ∧ code e598292499386 = 2797315754938 := by decide
def e598292499414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598292499414 : Closed e598292499414 ∧ code e598292499414 = 2797315754966 := by decide
def e598292499418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598292499418 : Closed e598292499418 ∧ code e598292499418 = 2797315754970 := by decide
def e598292499694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598292499694 : Closed e598292499694 ∧ code e598292499694 = 2797315755246 := by decide
def e598292499702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598292499702 : Closed e598292499702 ∧ code e598292499702 = 2797315755254 := by decide
def e598292500078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598292500078 : Closed e598292500078 ∧ code e598292500078 = 2797315755630 := by decide
def e598292500090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598292500090 : Closed e598292500090 ∧ code e598292500090 = 2797315755642 := by decide
def e598292500278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598292500278 : Closed e598292500278 ∧ code e598292500278 = 2797315755830 := by decide
theorem cert_e598292500278 : check e598292500278 [[],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e598292500282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598292500282 : Closed e598292500282 ∧ code e598292500282 = 2797315755834 := by decide
theorem cert_e598292500282 : check e598292500282 [[],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e598293089134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598293089134 : Closed e598293089134 ∧ code e598293089134 = 2797316344686 := by decide
def e598293089142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598293089142 : Closed e598293089142 ∧ code e598293089142 = 2797316344694 := by decide
def e598293089198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598293089198 : Closed e598293089198 ∧ code e598293089198 = 2797316344750 := by decide
def e598293089210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598293089210 : Closed e598293089210 ∧ code e598293089210 = 2797316344762 := by decide
private def t_e598293089210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e598293089210 : ¬ IsSelfInterpreter e598293089210 :=
  wSource (t := t_e598293089210) (replay_sound (ps := []) (t := e598293089210) (by decide)) (by decide)
def e598293089238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598293089238 : Closed e598293089238 ∧ code e598293089238 = 2797316344790 := by decide
def e598293089242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598293089242 : Closed e598293089242 ∧ code e598293089242 = 2797316344794 := by decide
private def t_e598293089242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e598293089242 : ¬ IsSelfInterpreter e598293089242 :=
  wSource (t := t_e598293089242) (replay_sound (ps := []) (t := e598293089242) (by decide)) (by decide)
def e598293089518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598293089518 : Closed e598293089518 ∧ code e598293089518 = 2797316345070 := by decide
def e598293089526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598293089526 : Closed e598293089526 ∧ code e598293089526 = 2797316345078 := by decide
def e598293089902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598293089902 : Closed e598293089902 ∧ code e598293089902 = 2797316345454 := by decide
theorem cert_e598293089902 : check e598293089902 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e598293089914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598293089914 : Closed e598293089914 ∧ code e598293089914 = 2797316345466 := by decide
theorem cert_e598293089914 : checkPay e598293089914 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left]] 1 [[],[.under,.left],[.under],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.right,.under,.under,.right,.left],[.under,.left,.right],[.under,.left,.right,.under],[.under,.left,.right,.under,.under]] = true := by decide
def e598293090102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598293090102 : Closed e598293090102 ∧ code e598293090102 = 2797316345654 := by decide
def e598293090106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598293090106 : Closed e598293090106 ∧ code e598293090106 = 2797316345658 := by decide
def e598342675822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e598342675822 : Closed e598342675822 ∧ code e598342675822 = 2797365931374 := by decide
theorem cert_e598342675822 : check e598342675822 [[],[.left],[]] .smaller = true := by decide
def e598342675830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e598342675830 : Closed e598342675830 ∧ code e598342675830 = 2797365931382 := by decide
theorem cert_e598342675830 : check e598342675830 [[],[.left],[]] .smaller = true := by decide
def e598342675886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e598342675886 : Closed e598342675886 ∧ code e598342675886 = 2797365931438 := by decide
theorem cert_e598342675886 : check e598342675886 [[],[.left],[]] .smaller = true := by decide
def e598342675898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e598342675898 : Closed e598342675898 ∧ code e598342675898 = 2797365931450 := by decide
theorem cert_e598342675898 : check e598342675898 [[],[.left],[]] .smaller = true := by decide
def e598342675926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e598342675926 : Closed e598342675926 ∧ code e598342675926 = 2797365931478 := by decide
theorem cert_e598342675926 : check e598342675926 [[],[.left],[]] .smaller = true := by decide
def e598342675930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e598342675930 : Closed e598342675930 ∧ code e598342675930 = 2797365931482 := by decide
theorem cert_e598342675930 : check e598342675930 [[],[.left],[]] .smaller = true := by decide
def e598342676142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e598342676142 : Closed e598342676142 ∧ code e598342676142 = 2797365931694 := by decide
theorem cert_e598342676142 : check e598342676142 [[],[.left],[]] .smaller = true := by decide
def e598342676154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e598342676154 : Closed e598342676154 ∧ code e598342676154 = 2797365931706 := by decide
theorem cert_e598342676154 : check e598342676154 [[],[.left],[]] .smaller = true := by decide
def e598342676202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e598342676202 : Closed e598342676202 ∧ code e598342676202 = 2797365931754 := by decide
theorem cert_e598342676202 : check e598342676202 [[],[.left],[]] .smaller = true := by decide
def e598342676310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e598342676310 : Closed e598342676310 ∧ code e598342676310 = 2797365931862 := by decide
theorem cert_e598342676310 : check e598342676310 [[],[.left],[]] .smaller = true := by decide
def e598342676314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e598342676314 : Closed e598342676314 ∧ code e598342676314 = 2797365931866 := by decide
theorem cert_e598342676314 : check e598342676314 [[],[.left],[]] .smaller = true := by decide
def e598342676330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e598342676330 : Closed e598342676330 ∧ code e598342676330 = 2797365931882 := by decide
theorem cert_e598342676330 : check e598342676330 [[],[.left],[]] .smaller = true := by decide
def e598342677358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e598342677358 : Closed e598342677358 ∧ code e598342677358 = 2797365932910 := by decide
theorem cert_e598342677358 : check e598342677358 [[],[.left],[]] .smaller = true := by decide
def e598342677366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e598342677366 : Closed e598342677366 ∧ code e598342677366 = 2797365932918 := by decide
theorem cert_e598342677366 : check e598342677366 [[],[.left],[]] .smaller = true := by decide
def e598342677422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e598342677422 : Closed e598342677422 ∧ code e598342677422 = 2797365932974 := by decide
theorem cert_e598342677422 : check e598342677422 [[],[.left],[]] .smaller = true := by decide
def e598342677434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e598342677434 : Closed e598342677434 ∧ code e598342677434 = 2797365932986 := by decide
theorem cert_e598342677434 : check e598342677434 [[],[.left],[]] .smaller = true := by decide
def e598342677462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e598342677462 : Closed e598342677462 ∧ code e598342677462 = 2797365933014 := by decide
theorem cert_e598342677462 : check e598342677462 [[],[.left],[]] .smaller = true := by decide
def e598342677466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e598342677466 : Closed e598342677466 ∧ code e598342677466 = 2797365933018 := by decide
theorem cert_e598342677466 : check e598342677466 [[],[.left],[]] .smaller = true := by decide
def e598342677742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e598342677742 : Closed e598342677742 ∧ code e598342677742 = 2797365933294 := by decide
theorem cert_e598342677742 : check e598342677742 [[],[.left],[]] .smaller = true := by decide
def e598342677750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e598342677750 : Closed e598342677750 ∧ code e598342677750 = 2797365933302 := by decide
theorem cert_e598342677750 : check e598342677750 [[],[.left],[]] .smaller = true := by decide
def e598342678126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e598342678126 : Closed e598342678126 ∧ code e598342678126 = 2797365933678 := by decide
theorem cert_e598342678126 : check e598342678126 [[],[.left],[]] .smaller = true := by decide
def e598342678138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e598342678138 : Closed e598342678138 ∧ code e598342678138 = 2797365933690 := by decide
theorem cert_e598342678138 : check e598342678138 [[],[.left],[]] .smaller = true := by decide
def e598342678326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598342678326 : Closed e598342678326 ∧ code e598342678326 = 2797365933878 := by decide
theorem cert_e598342678326 : check e598342678326 [[],[.left],[]] .smaller = true := by decide
def e598342678330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598342678330 : Closed e598342678330 ∧ code e598342678330 = 2797365933882 := by decide
theorem cert_e598342678330 : check e598342678330 [[],[.left],[]] .smaller = true := by decide
def e598342678958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e598342678958 : Closed e598342678958 ∧ code e598342678958 = 2797365934510 := by decide
theorem cert_e598342678958 : check e598342678958 [[],[.left],[]] .smaller = true := by decide
def e598342678970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e598342678970 : Closed e598342678970 ∧ code e598342678970 = 2797365934522 := by decide
theorem cert_e598342678970 : check e598342678970 [[],[.left],[]] .smaller = true := by decide
def e598342679018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e598342679018 : Closed e598342679018 ∧ code e598342679018 = 2797365934570 := by decide
theorem cert_e598342679018 : check e598342679018 [[],[.left],[]] .smaller = true := by decide
def e598342679150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e598342679150 : Closed e598342679150 ∧ code e598342679150 = 2797365934702 := by decide
theorem cert_e598342679150 : check e598342679150 [[],[.left],[]] .smaller = true := by decide
def e598342679162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e598342679162 : Closed e598342679162 ∧ code e598342679162 = 2797365934714 := by decide
theorem cert_e598342679162 : check e598342679162 [[],[.left],[]] .smaller = true := by decide
def e598342679450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598342679450 : Closed e598342679450 ∧ code e598342679450 = 2797365935002 := by decide
theorem cert_e598342679450 : check e598342679450 [[],[.left],[]] .smaller = true := by decide
def e598342679766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e598342679766 : Closed e598342679766 ∧ code e598342679766 = 2797365935318 := by decide
theorem cert_e598342679766 : check e598342679766 [[],[.left],[]] .smaller = true := by decide
def e598342679770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e598342679770 : Closed e598342679770 ∧ code e598342679770 = 2797365935322 := by decide
theorem cert_e598342679770 : check e598342679770 [[],[.left],[]] .smaller = true := by decide
def e598342679786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e598342679786 : Closed e598342679786 ∧ code e598342679786 = 2797365935338 := by decide
theorem cert_e598342679786 : check e598342679786 [[],[.left],[]] .smaller = true := by decide
def e598342679862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598342679862 : Closed e598342679862 ∧ code e598342679862 = 2797365935414 := by decide
theorem cert_e598342679862 : check e598342679862 [[],[.left],[]] .smaller = true := by decide
def e598342679866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598342679866 : Closed e598342679866 ∧ code e598342679866 = 2797365935418 := by decide
theorem cert_e598342679866 : check e598342679866 [[],[.left],[]] .smaller = true := by decide
def e598342679962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598342679962 : Closed e598342679962 ∧ code e598342679962 = 2797365935514 := by decide
theorem cert_e598342679962 : check e598342679962 [[],[.left],[]] .smaller = true := by decide
def e598342683502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598342683502 : Closed e598342683502 ∧ code e598342683502 = 2797365939054 := by decide
theorem cert_e598342683502 : check e598342683502 [[],[.left],[]] .smaller = true := by decide
def e598342683510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598342683510 : Closed e598342683510 ∧ code e598342683510 = 2797365939062 := by decide
theorem cert_e598342683510 : check e598342683510 [[],[.left],[]] .smaller = true := by decide
def e598342683566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598342683566 : Closed e598342683566 ∧ code e598342683566 = 2797365939118 := by decide
theorem cert_e598342683566 : check e598342683566 [[],[.left],[]] .smaller = true := by decide
def e598342683578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598342683578 : Closed e598342683578 ∧ code e598342683578 = 2797365939130 := by decide
theorem cert_e598342683578 : check e598342683578 [[],[.left],[]] .smaller = true := by decide
def e598342683606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598342683606 : Closed e598342683606 ∧ code e598342683606 = 2797365939158 := by decide
theorem cert_e598342683606 : check e598342683606 [[],[.left],[]] .smaller = true := by decide
def e598342683610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598342683610 : Closed e598342683610 ∧ code e598342683610 = 2797365939162 := by decide
theorem cert_e598342683610 : check e598342683610 [[],[.left],[]] .smaller = true := by decide
def e598342683886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598342683886 : Closed e598342683886 ∧ code e598342683886 = 2797365939438 := by decide
theorem cert_e598342683886 : check e598342683886 [[],[.left],[]] .smaller = true := by decide
def e598342683894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598342683894 : Closed e598342683894 ∧ code e598342683894 = 2797365939446 := by decide
theorem cert_e598342683894 : check e598342683894 [[],[.left],[]] .smaller = true := by decide
def e598342684270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598342684270 : Closed e598342684270 ∧ code e598342684270 = 2797365939822 := by decide
theorem cert_e598342684270 : check e598342684270 [[],[.left],[]] .smaller = true := by decide
def e598342684282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598342684282 : Closed e598342684282 ∧ code e598342684282 = 2797365939834 := by decide
theorem cert_e598342684282 : check e598342684282 [[],[.left],[]] .smaller = true := by decide
def e598342684470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598342684470 : Closed e598342684470 ∧ code e598342684470 = 2797365940022 := by decide
theorem cert_e598342684470 : check e598342684470 [[],[.left],[]] .smaller = true := by decide
def e598342684474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598342684474 : Closed e598342684474 ∧ code e598342684474 = 2797365940026 := by decide
theorem cert_e598342684474 : check e598342684474 [[],[.left],[]] .smaller = true := by decide
def e598342690222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e598342690222 : Closed e598342690222 ∧ code e598342690222 = 2797365945774 := by decide
theorem cert_e598342690222 : check e598342690222 [[],[.left],[]] .smaller = true := by decide
def e598342690234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e598342690234 : Closed e598342690234 ∧ code e598342690234 = 2797365945786 := by decide
theorem cert_e598342690234 : check e598342690234 [[],[.left],[]] .smaller = true := by decide
def e598342690282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e598342690282 : Closed e598342690282 ∧ code e598342690282 = 2797365945834 := by decide
theorem cert_e598342690282 : check e598342690282 [[],[.left],[]] .smaller = true := by decide
def e598342690414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e598342690414 : Closed e598342690414 ∧ code e598342690414 = 2797365945966 := by decide
theorem cert_e598342690414 : check e598342690414 [[],[.left],[]] .smaller = true := by decide
def e598342690426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e598342690426 : Closed e598342690426 ∧ code e598342690426 = 2797365945978 := by decide
theorem cert_e598342690426 : check e598342690426 [[],[.left],[]] .smaller = true := by decide
def e598342690714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e598342690714 : Closed e598342690714 ∧ code e598342690714 = 2797365946266 := by decide
theorem cert_e598342690714 : check e598342690714 [[],[.left],[]] .smaller = true := by decide
def e598342693590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e598342693590 : Closed e598342693590 ∧ code e598342693590 = 2797365949142 := by decide
theorem cert_e598342693590 : check e598342693590 [[],[.left],[]] .smaller = true := by decide
def e598342693594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e598342693594 : Closed e598342693594 ∧ code e598342693594 = 2797365949146 := by decide
theorem cert_e598342693594 : check e598342693594 [[],[.left],[]] .smaller = true := by decide
def e598342693610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e598342693610 : Closed e598342693610 ∧ code e598342693610 = 2797365949162 := by decide
theorem cert_e598342693610 : check e598342693610 [[],[.left],[]] .smaller = true := by decide
def e598342693686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e598342693686 : Closed e598342693686 ∧ code e598342693686 = 2797365949238 := by decide
theorem cert_e598342693686 : check e598342693686 [[],[.left],[]] .smaller = true := by decide
def e598342693690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e598342693690 : Closed e598342693690 ∧ code e598342693690 = 2797365949242 := by decide
theorem cert_e598342693690 : check e598342693690 [[],[.left],[]] .smaller = true := by decide
def e598342693786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e598342693786 : Closed e598342693786 ∧ code e598342693786 = 2797365949338 := by decide
theorem cert_e598342693786 : check e598342693786 [[],[.left],[]] .smaller = true := by decide
def e598342809054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e598342809054 : Closed e598342809054 ∧ code e598342809054 = 2797366064606 := by decide
theorem cert_e598342809054 : check e598342809054 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342809070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e598342809070 : Closed e598342809070 ∧ code e598342809070 = 2797366064622 := by decide
theorem cert_e598342809070 : check e598342809070 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342809310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e598342809310 : Closed e598342809310 ∧ code e598342809310 = 2797366064862 := by decide
theorem cert_e598342809310 : check e598342809310 [[],[.left],[]] .chain = true := by decide
def e598342809326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e598342809326 : Closed e598342809326 ∧ code e598342809326 = 2797366064878 := by decide
theorem cert_e598342809326 : check e598342809326 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e598342809334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e598342809334 : Closed e598342809334 ∧ code e598342809334 = 2797366064886 := by decide
theorem cert_e598342809334 : check e598342809334 [[],[.left],[]] .chain = true := by decide
def e598342809438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e598342809438 : Closed e598342809438 ∧ code e598342809438 = 2797366064990 := by decide
theorem cert_e598342809438 : check e598342809438 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342809454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e598342809454 : Closed e598342809454 ∧ code e598342809454 = 2797366065006 := by decide
theorem cert_e598342809454 : check e598342809454 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342809462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e598342809462 : Closed e598342809462 ∧ code e598342809462 = 2797366065014 := by decide
theorem cert_e598342809462 : check e598342809462 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
end Blc.Floor41
