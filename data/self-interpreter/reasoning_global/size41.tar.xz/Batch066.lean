import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604785291130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e604785291130 : Closed e604785291130 ∧ code e604785291130 = 2803808546682 := by decide
theorem cert_e604785291130 : check e604785291130 [[],[]] .three = true := by decide
def e604785291182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e604785291182 : Closed e604785291182 ∧ code e604785291182 = 2803808546734 := by decide
theorem cert_e604785291182 : check e604785291182 [[],[]] .three = true := by decide
def e604785291190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e604785291190 : Closed e604785291190 ∧ code e604785291190 = 2803808546742 := by decide
theorem cert_e604785291190 : check e604785291190 [[],[]] .three = true := by decide
def e604785291194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e604785291194 : Closed e604785291194 ∧ code e604785291194 = 2803808546746 := by decide
theorem cert_e604785291194 : check e604785291194 [[],[]] .three = true := by decide
def e604785292254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e604785292254 : Closed e604785292254 ∧ code e604785292254 = 2803808547806 := by decide
theorem cert_e604785292254 : check e604785292254 [[],[]] .three = true := by decide
def e604785292270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e604785292270 : Closed e604785292270 ∧ code e604785292270 = 2803808547822 := by decide
theorem cert_e604785292270 : check e604785292270 [[],[]] .three = true := by decide
def e604785293790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e604785293790 : Closed e604785293790 ∧ code e604785293790 = 2803808549342 := by decide
theorem cert_e604785293790 : check e604785293790 [[],[]] .three = true := by decide
def e604785293806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e604785293806 : Closed e604785293806 ∧ code e604785293806 = 2803808549358 := by decide
theorem cert_e604785293806 : check e604785293806 [[],[]] .smaller = true := by decide
def e604785293814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e604785293814 : Closed e604785293814 ∧ code e604785293814 = 2803808549366 := by decide
theorem cert_e604785293814 : check e604785293814 [[],[]] .three = true := by decide
def e604785294558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e604785294558 : Closed e604785294558 ∧ code e604785294558 = 2803808550110 := by decide
theorem cert_e604785294558 : check e604785294558 [[],[]] .three = true := by decide
def e604785294574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e604785294574 : Closed e604785294574 ∧ code e604785294574 = 2803808550126 := by decide
theorem cert_e604785294574 : check e604785294574 [[],[]] .smaller = true := by decide
def e604785294582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e604785294582 : Closed e604785294582 ∧ code e604785294582 = 2803808550134 := by decide
theorem cert_e604785294582 : check e604785294582 [[],[]] .smaller = true := by decide
def e604785294586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e604785294586 : Closed e604785294586 ∧ code e604785294586 = 2803808550138 := by decide
theorem cert_e604785294586 : check e604785294586 [[],[]] .three = true := by decide
def e604785294958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785294958 : Closed e604785294958 ∧ code e604785294958 = 2803808550510 := by decide
theorem cert_e604785294958 : check e604785294958 [[],[]] .three = true := by decide
def e604785294966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e604785294966 : Closed e604785294966 ∧ code e604785294966 = 2803808550518 := by decide
theorem cert_e604785294966 : check e604785294966 [[],[]] .three = true := by decide
def e604785294970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785294970 : Closed e604785294970 ∧ code e604785294970 = 2803808550522 := by decide
theorem cert_e604785294970 : check e604785294970 [[],[]] .three = true := by decide
def e604785317598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e604785317598 : Closed e604785317598 ∧ code e604785317598 = 2803808573150 := by decide
theorem cert_e604785317598 : check e604785317598 [[],[]] .three = true := by decide
def e604785317614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e604785317614 : Closed e604785317614 ∧ code e604785317614 = 2803808573166 := by decide
theorem cert_e604785317614 : check e604785317614 [[],[]] .smaller = true := by decide
def e604785317622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e604785317622 : Closed e604785317622 ∧ code e604785317622 = 2803808573174 := by decide
theorem cert_e604785317622 : check e604785317622 [[],[]] .three = true := by decide
def e604785317726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e604785317726 : Closed e604785317726 ∧ code e604785317726 = 2803808573278 := by decide
theorem cert_e604785317726 : check e604785317726 [[],[]] .three = true := by decide
def e604785317754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e604785317754 : Closed e604785317754 ∧ code e604785317754 = 2803808573306 := by decide
theorem cert_e604785317754 : check e604785317754 [[],[]] .three = true := by decide
def e604785317806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e604785317806 : Closed e604785317806 ∧ code e604785317806 = 2803808573358 := by decide
theorem cert_e604785317806 : check e604785317806 [[],[]] .smaller = true := by decide
def e604785317818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e604785317818 : Closed e604785317818 ∧ code e604785317818 = 2803808573370 := by decide
theorem cert_e604785317818 : check e604785317818 [[],[]] .smaller = true := by decide
def e604785317846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e604785317846 : Closed e604785317846 ∧ code e604785317846 = 2803808573398 := by decide
theorem cert_e604785317846 : check e604785317846 [[],[]] .three = true := by decide
def e604785317850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e604785317850 : Closed e604785317850 ∧ code e604785317850 = 2803808573402 := by decide
theorem cert_e604785317850 : check e604785317850 [[],[]] .three = true := by decide
def e604785318366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e604785318366 : Closed e604785318366 ∧ code e604785318366 = 2803808573918 := by decide
theorem cert_e604785318366 : check e604785318366 [[],[]] .three = true := by decide
def e604785318382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e604785318382 : Closed e604785318382 ∧ code e604785318382 = 2803808573934 := by decide
theorem cert_e604785318382 : check e604785318382 [[],[]] .smaller = true := by decide
def e604785318390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e604785318390 : Closed e604785318390 ∧ code e604785318390 = 2803808573942 := by decide
theorem cert_e604785318390 : check e604785318390 [[],[]] .three = true := by decide
def e604785319134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e604785319134 : Closed e604785319134 ∧ code e604785319134 = 2803808574686 := by decide
theorem cert_e604785319134 : check e604785319134 [[],[]] .three = true := by decide
def e604785319162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e604785319162 : Closed e604785319162 ∧ code e604785319162 = 2803808574714 := by decide
theorem cert_e604785319162 : check e604785319162 [[],[]] .three = true := by decide
def e604785319534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785319534 : Closed e604785319534 ∧ code e604785319534 = 2803808575086 := by decide
theorem cert_e604785319534 : check e604785319534 [[],[]] .smaller = true := by decide
def e604785319546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785319546 : Closed e604785319546 ∧ code e604785319546 = 2803808575098 := by decide
theorem cert_e604785319546 : check e604785319546 [[],[]] .smaller = true := by decide
def e604785319734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785319734 : Closed e604785319734 ∧ code e604785319734 = 2803808575286 := by decide
theorem cert_e604785319734 : check e604785319734 [[],[]] .three = true := by decide
def e604785319738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785319738 : Closed e604785319738 ∧ code e604785319738 = 2803808575290 := by decide
theorem cert_e604785319738 : check e604785319738 [[],[]] .three = true := by decide
def e604785331038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e604785331038 : Closed e604785331038 ∧ code e604785331038 = 2803808586590 := by decide
theorem cert_e604785331038 : check e604785331038 [[],[]] .three = true := by decide
def e604785331054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604785331054 : Closed e604785331054 ∧ code e604785331054 = 2803808586606 := by decide
theorem cert_e604785331054 : check e604785331054 [[],[]] .smaller = true := by decide
def e604785331062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604785331062 : Closed e604785331062 ∧ code e604785331062 = 2803808586614 := by decide
theorem cert_e604785331062 : check e604785331062 [[],[]] .smaller = true := by decide
def e604785331066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e604785331066 : Closed e604785331066 ∧ code e604785331066 = 2803808586618 := by decide
theorem cert_e604785331066 : check e604785331066 [[],[]] .three = true := by decide
def e604785331118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604785331118 : Closed e604785331118 ∧ code e604785331118 = 2803808586670 := by decide
theorem cert_e604785331118 : check e604785331118 [[],[]] .smaller = true := by decide
def e604785331130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604785331130 : Closed e604785331130 ∧ code e604785331130 = 2803808586682 := by decide
theorem cert_e604785331130 : check e604785331130 [[],[]] .smaller = true := by decide
def e604785331158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604785331158 : Closed e604785331158 ∧ code e604785331158 = 2803808586710 := by decide
theorem cert_e604785331158 : check e604785331158 [[],[]] .smaller = true := by decide
def e604785331162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604785331162 : Closed e604785331162 ∧ code e604785331162 = 2803808586714 := by decide
theorem cert_e604785331162 : check e604785331162 [[],[]] .smaller = true := by decide
def e604785331178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e604785331178 : Closed e604785331178 ∧ code e604785331178 = 2803808586730 := by decide
theorem cert_e604785331178 : check e604785331178 [[],[]] .three = true := by decide
def e604785331422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e604785331422 : Closed e604785331422 ∧ code e604785331422 = 2803808586974 := by decide
theorem cert_e604785331422 : check e604785331422 [[],[]] .three = true := by decide
def e604785331438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604785331438 : Closed e604785331438 ∧ code e604785331438 = 2803808586990 := by decide
theorem cert_e604785331438 : check e604785331438 [[],[]] .smaller = true := by decide
def e604785331446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604785331446 : Closed e604785331446 ∧ code e604785331446 = 2803808586998 := by decide
theorem cert_e604785331446 : check e604785331446 [[],[]] .smaller = true := by decide
def e604785331450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e604785331450 : Closed e604785331450 ∧ code e604785331450 = 2803808587002 := by decide
theorem cert_e604785331450 : check e604785331450 [[],[]] .three = true := by decide
def e604785331822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785331822 : Closed e604785331822 ∧ code e604785331822 = 2803808587374 := by decide
theorem cert_e604785331822 : check e604785331822 [[],[]] .smaller = true := by decide
def e604785331834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785331834 : Closed e604785331834 ∧ code e604785331834 = 2803808587386 := by decide
theorem cert_e604785331834 : check e604785331834 [[],[]] .smaller = true := by decide
def e604785332022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785332022 : Closed e604785332022 ∧ code e604785332022 = 2803808587574 := by decide
theorem cert_e604785332022 : check e604785332022 [[],[]] .smaller = true := by decide
def e604785332026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785332026 : Closed e604785332026 ∧ code e604785332026 = 2803808587578 := by decide
theorem cert_e604785332026 : check e604785332026 [[],[]] .smaller = true := by decide
def e604785332122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e604785332122 : Closed e604785332122 ∧ code e604785332122 = 2803808587674 := by decide
theorem cert_e604785332122 : check e604785332122 [[],[]] .three = true := by decide
def e604785337774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604785337774 : Closed e604785337774 ∧ code e604785337774 = 2803808593326 := by decide
theorem cert_e604785337774 : check e604785337774 [[],[]] .three = true := by decide
def e604785337782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e604785337782 : Closed e604785337782 ∧ code e604785337782 = 2803808593334 := by decide
theorem cert_e604785337782 : check e604785337782 [[],[]] .three = true := by decide
def e604785337786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604785337786 : Closed e604785337786 ∧ code e604785337786 = 2803808593338 := by decide
theorem cert_e604785337786 : check e604785337786 [[],[]] .three = true := by decide
def e604785337814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e604785337814 : Closed e604785337814 ∧ code e604785337814 = 2803808593366 := by decide
theorem cert_e604785337814 : check e604785337814 [[],[]] .three = true := by decide
def e604785337818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e604785337818 : Closed e604785337818 ∧ code e604785337818 = 2803808593370 := by decide
theorem cert_e604785337818 : check e604785337818 [[],[]] .three = true := by decide
def e604785337834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604785337834 : Closed e604785337834 ∧ code e604785337834 = 2803808593386 := by decide
theorem cert_e604785337834 : check e604785337834 [[],[]] .three = true := by decide
def e604785337966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785337966 : Closed e604785337966 ∧ code e604785337966 = 2803808593518 := by decide
theorem cert_e604785337966 : check e604785337966 [[],[]] .three = true := by decide
def e604785337974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e604785337974 : Closed e604785337974 ∧ code e604785337974 = 2803808593526 := by decide
theorem cert_e604785337974 : check e604785337974 [[],[]] .three = true := by decide
def e604785337978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785337978 : Closed e604785337978 ∧ code e604785337978 = 2803808593530 := by decide
theorem cert_e604785337978 : check e604785337978 [[],[]] .three = true := by decide
def e604785338166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785338166 : Closed e604785338166 ∧ code e604785338166 = 2803808593718 := by decide
theorem cert_e604785338166 : check e604785338166 [[],[]] .three = true := by decide
def e604785338170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785338170 : Closed e604785338170 ∧ code e604785338170 = 2803808593722 := by decide
theorem cert_e604785338170 : check e604785338170 [[],[]] .three = true := by decide
def e604785338266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604785338266 : Closed e604785338266 ∧ code e604785338266 = 2803808593818 := by decide
theorem cert_e604785338266 : check e604785338266 [[],[]] .three = true := by decide
def e604785784174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e604785784174 : Closed e604785784174 ∧ code e604785784174 = 2803809039726 := by decide
theorem cert_e604785784174 : check e604785784174 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785784182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e604785784182 : Closed e604785784182 ∧ code e604785784182 = 2803809039734 := by decide
theorem cert_e604785784182 : check e604785784182 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785784238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e604785784238 : Closed e604785784238 ∧ code e604785784238 = 2803809039790 := by decide
theorem cert_e604785784238 : check e604785784238 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785784250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e604785784250 : Closed e604785784250 ∧ code e604785784250 = 2803809039802 := by decide
theorem cert_e604785784250 : check e604785784250 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785784278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e604785784278 : Closed e604785784278 ∧ code e604785784278 = 2803809039830 := by decide
theorem cert_e604785784278 : check e604785784278 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785784282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e604785784282 : Closed e604785784282 ∧ code e604785784282 = 2803809039834 := by decide
theorem cert_e604785784282 : check e604785784282 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785784494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e604785784494 : Closed e604785784494 ∧ code e604785784494 = 2803809040046 := by decide
theorem cert_e604785784494 : check e604785784494 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785784506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e604785784506 : Closed e604785784506 ∧ code e604785784506 = 2803809040058 := by decide
theorem cert_e604785784506 : check e604785784506 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785784554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e604785784554 : Closed e604785784554 ∧ code e604785784554 = 2803809040106 := by decide
theorem cert_e604785784554 : check e604785784554 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785784662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e604785784662 : Closed e604785784662 ∧ code e604785784662 = 2803809040214 := by decide
theorem cert_e604785784662 : checkPay e604785784662 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785784666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e604785784666 : Closed e604785784666 ∧ code e604785784666 = 2803809040218 := by decide
theorem cert_e604785784666 : check e604785784666 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785784682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e604785784682 : Closed e604785784682 ∧ code e604785784682 = 2803809040234 := by decide
theorem cert_e604785784682 : check e604785784682 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785785518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e604785785518 : Closed e604785785518 ∧ code e604785785518 = 2803809041070 := by decide
theorem cert_e604785785518 : check e604785785518 [[],[]] .sourceHead = true := by decide
def e604785785530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e604785785530 : Closed e604785785530 ∧ code e604785785530 = 2803809041082 := by decide
theorem cert_e604785785530 : check e604785785530 [[],[]] .sourceHead = true := by decide
def e604785785578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e604785785578 : Closed e604785785578 ∧ code e604785785578 = 2803809041130 := by decide
theorem cert_e604785785578 : check e604785785578 [[],[]] .sourceHead = true := by decide
def e604785785770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e604785785770 : Closed e604785785770 ∧ code e604785785770 = 2803809041322 := by decide
theorem cert_e604785785770 : check e604785785770 [[],[]] .sourceHead = true := by decide
def e604785786198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e604785786198 : Closed e604785786198 ∧ code e604785786198 = 2803809041750 := by decide
theorem cert_e604785786198 : check e604785786198 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604785786202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e604785786202 : Closed e604785786202 ∧ code e604785786202 = 2803809041754 := by decide
theorem cert_e604785786202 : check e604785786202 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604785786218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e604785786218 : Closed e604785786218 ∧ code e604785786218 = 2803809041770 := by decide
theorem cert_e604785786218 : check e604785786218 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604785786282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e604785786282 : Closed e604785786282 ∧ code e604785786282 = 2803809041834 := by decide
theorem cert_e604785786282 : check e604785786282 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604785788782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e604785788782 : Closed e604785788782 ∧ code e604785788782 = 2803809044334 := by decide
theorem cert_e604785788782 : check e604785788782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785788790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e604785788790 : Closed e604785788790 ∧ code e604785788790 = 2803809044342 := by decide
theorem cert_e604785788790 : check e604785788790 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785788854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e604785788854 : Closed e604785788854 ∧ code e604785788854 = 2803809044406 := by decide
theorem cert_e604785788854 : check e604785788854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785790318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e604785790318 : Closed e604785790318 ∧ code e604785790318 = 2803809045870 := by decide
theorem cert_e604785790318 : check e604785790318 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785790326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e604785790326 : Closed e604785790326 ∧ code e604785790326 = 2803809045878 := by decide
theorem cert_e604785790326 : checkPay e604785790326 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e604785790382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e604785790382 : Closed e604785790382 ∧ code e604785790382 = 2803809045934 := by decide
theorem cert_e604785790382 : check e604785790382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785790394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e604785790394 : Closed e604785790394 ∧ code e604785790394 = 2803809045946 := by decide
theorem cert_e604785790394 : check e604785790394 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785790422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e604785790422 : Closed e604785790422 ∧ code e604785790422 = 2803809045974 := by decide
theorem cert_e604785790422 : check e604785790422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785790426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e604785790426 : Closed e604785790426 ∧ code e604785790426 = 2803809045978 := by decide
theorem cert_e604785790426 : check e604785790426 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785790638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e604785790638 : Closed e604785790638 ∧ code e604785790638 = 2803809046190 := by decide
theorem cert_e604785790638 : check e604785790638 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785790650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e604785790650 : Closed e604785790650 ∧ code e604785790650 = 2803809046202 := by decide
theorem cert_e604785790650 : check e604785790650 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785790698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e604785790698 : Closed e604785790698 ∧ code e604785790698 = 2803809046250 := by decide
theorem cert_e604785790698 : check e604785790698 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785790806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e604785790806 : Closed e604785790806 ∧ code e604785790806 = 2803809046358 := by decide
theorem cert_e604785790806 : checkPay e604785790806 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e604785790810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e604785790810 : Closed e604785790810 ∧ code e604785790810 = 2803809046362 := by decide
theorem cert_e604785790810 : check e604785790810 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785790826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e604785790826 : Closed e604785790826 ∧ code e604785790826 = 2803809046378 := by decide
theorem cert_e604785790826 : check e604785790826 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785791854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e604785791854 : Closed e604785791854 ∧ code e604785791854 = 2803809047406 := by decide
theorem cert_e604785791854 : check e604785791854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785791862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e604785791862 : Closed e604785791862 ∧ code e604785791862 = 2803809047414 := by decide
theorem cert_e604785791862 : checkPay e604785791862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785791918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e604785791918 : Closed e604785791918 ∧ code e604785791918 = 2803809047470 := by decide
theorem cert_e604785791918 : check e604785791918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785791930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e604785791930 : Closed e604785791930 ∧ code e604785791930 = 2803809047482 := by decide
theorem cert_e604785791930 : check e604785791930 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785791958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e604785791958 : Closed e604785791958 ∧ code e604785791958 = 2803809047510 := by decide
theorem cert_e604785791958 : checkPay e604785791958 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785791962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e604785791962 : Closed e604785791962 ∧ code e604785791962 = 2803809047514 := by decide
theorem cert_e604785791962 : check e604785791962 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785792238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e604785792238 : Closed e604785792238 ∧ code e604785792238 = 2803809047790 := by decide
theorem cert_e604785792238 : check e604785792238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785792246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e604785792246 : Closed e604785792246 ∧ code e604785792246 = 2803809047798 := by decide
theorem cert_e604785792246 : check e604785792246 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785792622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e604785792622 : Closed e604785792622 ∧ code e604785792622 = 2803809048174 := by decide
theorem cert_e604785792622 : check e604785792622 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785792634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e604785792634 : Closed e604785792634 ∧ code e604785792634 = 2803809048186 := by decide
theorem cert_e604785792634 : check e604785792634 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785792822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e604785792822 : Closed e604785792822 ∧ code e604785792822 = 2803809048374 := by decide
theorem cert_e604785792822 : check e604785792822 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785792826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e604785792826 : Closed e604785792826 ∧ code e604785792826 = 2803809048378 := by decide
theorem cert_e604785792826 : check e604785792826 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785793262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e604785793262 : Closed e604785793262 ∧ code e604785793262 = 2803809048814 := by decide
theorem cert_e604785793262 : check e604785793262 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e604785793270 : Closed e604785793270 ∧ code e604785793270 = 2803809048822 := by decide
theorem cert_e604785793270 : check e604785793270 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e604785793454 : Closed e604785793454 ∧ code e604785793454 = 2803809049006 := by decide
theorem cert_e604785793454 : check e604785793454 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e604785793466 : Closed e604785793466 ∧ code e604785793466 = 2803809049018 := by decide
theorem cert_e604785793466 : check e604785793466 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e604785793514 : Closed e604785793514 ∧ code e604785793514 = 2803809049066 := by decide
theorem cert_e604785793514 : check e604785793514 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e604785793646 : Closed e604785793646 ∧ code e604785793646 = 2803809049198 := by decide
theorem cert_e604785793646 : check e604785793646 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e604785793658 : Closed e604785793658 ∧ code e604785793658 = 2803809049210 := by decide
theorem cert_e604785793658 : check e604785793658 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e604785793822 : Closed e604785793822 ∧ code e604785793822 = 2803809049374 := by decide
theorem cert_e604785793822 : check e604785793822 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e604785793934 : Closed e604785793934 ∧ code e604785793934 = 2803809049486 := by decide
theorem cert_e604785793934 : check e604785793934 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785793946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e604785793946 : Closed e604785793946 ∧ code e604785793946 = 2803809049498 := by decide
theorem cert_e604785793946 : check e604785793946 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785794166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e604785794166 : Closed e604785794166 ∧ code e604785794166 = 2803809049718 := by decide
theorem cert_e604785794166 : checkPay e604785794166 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] 0 [] = true := by decide
def e604785794262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e604785794262 : Closed e604785794262 ∧ code e604785794262 = 2803809049814 := by decide
theorem cert_e604785794262 : check e604785794262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785794266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e604785794266 : Closed e604785794266 ∧ code e604785794266 = 2803809049818 := by decide
theorem cert_e604785794266 : checkPay e604785794266 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] 0 [] = true := by decide
def e604785794282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e604785794282 : Closed e604785794282 ∧ code e604785794282 = 2803809049834 := by decide
theorem cert_e604785794282 : check e604785794282 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785794358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e604785794358 : Closed e604785794358 ∧ code e604785794358 = 2803809049910 := by decide
theorem cert_e604785794358 : check e604785794358 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785794362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e604785794362 : Closed e604785794362 ∧ code e604785794362 = 2803809049914 := by decide
theorem cert_e604785794362 : check e604785794362 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785794446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e604785794446 : Closed e604785794446 ∧ code e604785794446 = 2803809049998 := by decide
theorem cert_e604785794446 : check e604785794446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785794458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e604785794458 : Closed e604785794458 ∧ code e604785794458 = 2803809050010 := by decide
theorem cert_e604785794458 : check e604785794458 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e604785795950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e604785795950 : Closed e604785795950 ∧ code e604785795950 = 2803809051502 := by decide
theorem cert_e604785795950 : check e604785795950 [[],[]] .sourceHead = true := by decide
def e604785795958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e604785795958 : Closed e604785795958 ∧ code e604785795958 = 2803809051510 := by decide
theorem cert_e604785795958 : check e604785795958 [[],[]] .sourceHead = true := by decide
def e604785796014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e604785796014 : Closed e604785796014 ∧ code e604785796014 = 2803809051566 := by decide
theorem cert_e604785796014 : check e604785796014 [[],[]] .sourceHead = true := by decide
def e604785796026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e604785796026 : Closed e604785796026 ∧ code e604785796026 = 2803809051578 := by decide
theorem cert_e604785796026 : check e604785796026 [[],[]] .sourceHead = true := by decide
def e604785796054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e604785796054 : Closed e604785796054 ∧ code e604785796054 = 2803809051606 := by decide
theorem cert_e604785796054 : check e604785796054 [[],[]] .sourceHead = true := by decide
def e604785796058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e604785796058 : Closed e604785796058 ∧ code e604785796058 = 2803809051610 := by decide
theorem cert_e604785796058 : check e604785796058 [[],[]] .sourceHead = true := by decide
def e604785796782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e604785796782 : Closed e604785796782 ∧ code e604785796782 = 2803809052334 := by decide
theorem cert_e604785796782 : check e604785796782 [[],[]] .sourceHead = true := by decide
def e604785796794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e604785796794 : Closed e604785796794 ∧ code e604785796794 = 2803809052346 := by decide
theorem cert_e604785796794 : check e604785796794 [[],[]] .sourceHead = true := by decide
def e604785796842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e604785796842 : Closed e604785796842 ∧ code e604785796842 = 2803809052394 := by decide
theorem cert_e604785796842 : check e604785796842 [[],[]] .sourceHead = true := by decide
def e604785797034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e604785797034 : Closed e604785797034 ∧ code e604785797034 = 2803809052586 := by decide
theorem cert_e604785797034 : check e604785797034 [[],[]] .sourceHead = true := by decide
def e604785797358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e604785797358 : Closed e604785797358 ∧ code e604785797358 = 2803809052910 := by decide
theorem cert_e604785797358 : check e604785797358 [[],[]] .sourceHead = true := by decide
def e604785797366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e604785797366 : Closed e604785797366 ∧ code e604785797366 = 2803809052918 := by decide
theorem cert_e604785797366 : check e604785797366 [[],[]] .sourceHead = true := by decide
def e604785797550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e604785797550 : Closed e604785797550 ∧ code e604785797550 = 2803809053102 := by decide
theorem cert_e604785797550 : check e604785797550 [[],[]] .sourceHead = true := by decide
def e604785797562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e604785797562 : Closed e604785797562 ∧ code e604785797562 = 2803809053114 := by decide
theorem cert_e604785797562 : check e604785797562 [[],[]] .sourceHead = true := by decide
def e604785797610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e604785797610 : Closed e604785797610 ∧ code e604785797610 = 2803809053162 := by decide
theorem cert_e604785797610 : check e604785797610 [[],[]] .sourceHead = true := by decide
def e604785797742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e604785797742 : Closed e604785797742 ∧ code e604785797742 = 2803809053294 := by decide
theorem cert_e604785797742 : check e604785797742 [[],[]] .sourceHead = true := by decide
def e604785797754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e604785797754 : Closed e604785797754 ∧ code e604785797754 = 2803809053306 := by decide
theorem cert_e604785797754 : check e604785797754 [[],[]] .sourceHead = true := by decide
def e604785797918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e604785797918 : Closed e604785797918 ∧ code e604785797918 = 2803809053470 := by decide
theorem cert_e604785797918 : check e604785797918 [[],[]] .sourceHead = true := by decide
def e604785798030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e604785798030 : Closed e604785798030 ∧ code e604785798030 = 2803809053582 := by decide
theorem cert_e604785798030 : check e604785798030 [[],[]] .sourceHead = true := by decide
def e604785798042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e604785798042 : Closed e604785798042 ∧ code e604785798042 = 2803809053594 := by decide
theorem cert_e604785798042 : check e604785798042 [[],[]] .sourceHead = true := by decide
def e604785798254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e604785798254 : Closed e604785798254 ∧ code e604785798254 = 2803809053806 := by decide
theorem cert_e604785798254 : check e604785798254 [[],[]] .sourceHead = true := by decide
def e604785798266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e604785798266 : Closed e604785798266 ∧ code e604785798266 = 2803809053818 := by decide
theorem cert_e604785798266 : check e604785798266 [[],[]] .sourceHead = true := by decide
def e604785798430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e604785798430 : Closed e604785798430 ∧ code e604785798430 = 2803809053982 := by decide
theorem cert_e604785798430 : check e604785798430 [[],[]] .sourceHead = true := by decide
def e604785798598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e604785798598 : Closed e604785798598 ∧ code e604785798598 = 2803809054150 := by decide
theorem cert_e604785798598 : check e604785798598 [[],[]] .sourceHead = true := by decide
def e604785798710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e604785798710 : Closed e604785798710 ∧ code e604785798710 = 2803809054262 := by decide
theorem cert_e604785798710 : check e604785798710 [[],[]] .sourceHead = true := by decide
def e604785798714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e604785798714 : Closed e604785798714 ∧ code e604785798714 = 2803809054266 := by decide
theorem cert_e604785798714 : check e604785798714 [[],[]] .sourceHead = true := by decide
def e604785798762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e604785798762 : Closed e604785798762 ∧ code e604785798762 = 2803809054314 := by decide
theorem cert_e604785798762 : check e604785798762 [[],[]] .sourceHead = true := by decide
def e604785798798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e604785798798 : Closed e604785798798 ∧ code e604785798798 = 2803809054350 := by decide
theorem cert_e604785798798 : check e604785798798 [[],[]] .sourceHead = true := by decide
def e604785798810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e604785798810 : Closed e604785798810 ∧ code e604785798810 = 2803809054362 := by decide
theorem cert_e604785798810 : check e604785798810 [[],[]] .sourceHead = true := by decide
def e604785798854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e604785798854 : Closed e604785798854 ∧ code e604785798854 = 2803809054406 := by decide
theorem cert_e604785798854 : check e604785798854 [[],[]] .sourceHead = true := by decide
def e604785799606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e604785799606 : Closed e604785799606 ∧ code e604785799606 = 2803809055158 := by decide
theorem cert_e604785799606 : check e604785799606 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
end Blc.Floor41
