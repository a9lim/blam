import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598141482734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e598141482734 : Closed e598141482734 ∧ code e598141482734 = 2797164738286 := by decide
theorem cert_e598141482734 : check e598141482734 [[],[.left],[]] .sourceHead = true := by decide
def e598141482862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e598141482862 : Closed e598141482862 ∧ code e598141482862 = 2797164738414 := by decide
theorem cert_e598141482862 : check e598141482862 [[],[.left],[]] .sourceHead = true := by decide
def e598141482870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e598141482870 : Closed e598141482870 ∧ code e598141482870 = 2797164738422 := by decide
theorem cert_e598141482870 : check e598141482870 [[],[.left],[]] .sourceHead = true := by decide
def e598141483758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e598141483758 : Closed e598141483758 ∧ code e598141483758 = 2797164739310 := by decide
theorem cert_e598141483758 : check e598141483758 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e598141483950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e598141483950 : Closed e598141483950 ∧ code e598141483950 = 2797164739502 := by decide
theorem cert_e598141483950 : check e598141483950 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598141483962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e598141483962 : Closed e598141483962 ∧ code e598141483962 = 2797164739514 := by decide
theorem cert_e598141483962 : check e598141483962 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598141484398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e598141484398 : Closed e598141484398 ∧ code e598141484398 = 2797164739950 := by decide
theorem cert_e598141484398 : check e598141484398 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598141484406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e598141484406 : Closed e598141484406 ∧ code e598141484406 = 2797164739958 := by decide
theorem cert_e598141484406 : check e598141484406 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598141484462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e598141484462 : Closed e598141484462 ∧ code e598141484462 = 2797164740014 := by decide
theorem cert_e598141484462 : check e598141484462 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598141484474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e598141484474 : Closed e598141484474 ∧ code e598141484474 = 2797164740026 := by decide
theorem cert_e598141484474 : check e598141484474 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598141484502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e598141484502 : Closed e598141484502 ∧ code e598141484502 = 2797164740054 := by decide
private def t_e598141484502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e598141484502 : ¬ IsSelfInterpreter e598141484502 :=
  wSource (t := t_e598141484502) (replay_sound (ps := []) (t := e598141484502) (by decide)) (by decide)
def e598141484506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e598141484506 : Closed e598141484506 ∧ code e598141484506 = 2797164740058 := by decide
private def t_e598141484506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e598141484506 : ¬ IsSelfInterpreter e598141484506 :=
  wSource (t := t_e598141484506) (replay_sound (ps := []) (t := e598141484506) (by decide)) (by decide)
def e598141488878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e598141488878 : Closed e598141488878 ∧ code e598141488878 = 2797164744430 := by decide
theorem cert_e598141488878 : check e598141488878 [[],[.left],[]] .sourceHead = true := by decide
def e598141489006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e598141489006 : Closed e598141489006 ∧ code e598141489006 = 2797164744558 := by decide
theorem cert_e598141489006 : check e598141489006 [[],[.left],[]] .sourceHead = true := by decide
def e598141489014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e598141489014 : Closed e598141489014 ∧ code e598141489014 = 2797164744566 := by decide
theorem cert_e598141489014 : check e598141489014 [[],[.left],[]] .sourceHead = true := by decide
def e598141491694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e598141491694 : Closed e598141491694 ∧ code e598141491694 = 2797164747246 := by decide
theorem cert_e598141491694 : check e598141491694 [[],[.left],[]] .sourceHead = true := by decide
def e598141492462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e598141492462 : Closed e598141492462 ∧ code e598141492462 = 2797164748014 := by decide
theorem cert_e598141492462 : check e598141492462 [[],[.left],[]] .sourceHead = true := by decide
def e598141492470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e598141492470 : Closed e598141492470 ∧ code e598141492470 = 2797164748022 := by decide
theorem cert_e598141492470 : check e598141492470 [[],[.left],[]] .sourceHead = true := by decide
def e598141495022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e598141495022 : Closed e598141495022 ∧ code e598141495022 = 2797164750574 := by decide
theorem cert_e598141495022 : check e598141495022 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e598141495214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e598141495214 : Closed e598141495214 ∧ code e598141495214 = 2797164750766 := by decide
theorem cert_e598141495214 : check e598141495214 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e598141495226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e598141495226 : Closed e598141495226 ∧ code e598141495226 = 2797164750778 := by decide
theorem cert_e598141495226 : checkPay e598141495226 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e598141495790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e598141495790 : Closed e598141495790 ∧ code e598141495790 = 2797164751342 := by decide
theorem cert_e598141495790 : check e598141495790 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e598141496942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e598141496942 : Closed e598141496942 ∧ code e598141496942 = 2797164752494 := by decide
theorem cert_e598141496942 : check e598141496942 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598141496954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e598141496954 : Closed e598141496954 ∧ code e598141496954 = 2797164752506 := by decide
theorem cert_e598141496954 : check e598141496954 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598141498222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e598141498222 : Closed e598141498222 ∧ code e598141498222 = 2797164753774 := by decide
theorem cert_e598141498222 : check e598141498222 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598141498230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e598141498230 : Closed e598141498230 ∧ code e598141498230 = 2797164753782 := by decide
theorem cert_e598141498230 : check e598141498230 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598141498286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e598141498286 : Closed e598141498286 ∧ code e598141498286 = 2797164753838 := by decide
theorem cert_e598141498286 : check e598141498286 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598141498298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e598141498298 : Closed e598141498298 ∧ code e598141498298 = 2797164753850 := by decide
theorem cert_e598141498298 : check e598141498298 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598141498326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e598141498326 : Closed e598141498326 ∧ code e598141498326 = 2797164753878 := by decide
theorem cert_e598141498326 : check e598141498326 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598141498330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e598141498330 : Closed e598141498330 ∧ code e598141498330 = 2797164753882 := by decide
theorem cert_e598141498330 : check e598141498330 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598141498606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e598141498606 : Closed e598141498606 ∧ code e598141498606 = 2797164754158 := by decide
theorem cert_e598141498606 : check e598141498606 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598141498614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e598141498614 : Closed e598141498614 ∧ code e598141498614 = 2797164754166 := by decide
theorem cert_e598141498614 : check e598141498614 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598141498990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e598141498990 : Closed e598141498990 ∧ code e598141498990 = 2797164754542 := by decide
theorem cert_e598141498990 : check e598141498990 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598141499002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e598141499002 : Closed e598141499002 ∧ code e598141499002 = 2797164754554 := by decide
theorem cert_e598141499002 : check e598141499002 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598141499190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e598141499190 : Closed e598141499190 ∧ code e598141499190 = 2797164754742 := by decide
private def t_e598141499190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e598141499190 : ¬ IsSelfInterpreter e598141499190 :=
  wSource (t := t_e598141499190) (replay_sound (ps := []) (t := e598141499190) (by decide)) (by decide)
def e598141499194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e598141499194 : Closed e598141499194 ∧ code e598141499194 = 2797164754746 := by decide
private def t_e598141499194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e598141499194 : ¬ IsSelfInterpreter e598141499194 :=
  wSource (t := t_e598141499194) (replay_sound (ps := []) (t := e598141499194) (by decide)) (by decide)
def e598141504366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598141504366 : Closed e598141504366 ∧ code e598141504366 = 2797164759918 := by decide
theorem cert_e598141504366 : check e598141504366 [[],[.left]] .smaller = true := by decide
def e598141504374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598141504374 : Closed e598141504374 ∧ code e598141504374 = 2797164759926 := by decide
theorem cert_e598141504374 : check e598141504374 [[],[.left]] .smaller = true := by decide
def e598141504430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598141504430 : Closed e598141504430 ∧ code e598141504430 = 2797164759982 := by decide
theorem cert_e598141504430 : check e598141504430 [[],[.left]] .smaller = true := by decide
def e598141504442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598141504442 : Closed e598141504442 ∧ code e598141504442 = 2797164759994 := by decide
theorem cert_e598141504442 : check e598141504442 [[],[.left]] .smaller = true := by decide
def e598141504470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598141504470 : Closed e598141504470 ∧ code e598141504470 = 2797164760022 := by decide
theorem cert_e598141504470 : check e598141504470 [[],[.left]] .smaller = true := by decide
def e598141504474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598141504474 : Closed e598141504474 ∧ code e598141504474 = 2797164760026 := by decide
theorem cert_e598141504474 : check e598141504474 [[],[.left]] .smaller = true := by decide
def e598141504750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598141504750 : Closed e598141504750 ∧ code e598141504750 = 2797164760302 := by decide
theorem cert_e598141504750 : check e598141504750 [[],[.left]] .smaller = true := by decide
def e598141504758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598141504758 : Closed e598141504758 ∧ code e598141504758 = 2797164760310 := by decide
theorem cert_e598141504758 : check e598141504758 [[],[.left]] .smaller = true := by decide
def e598141505134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598141505134 : Closed e598141505134 ∧ code e598141505134 = 2797164760686 := by decide
theorem cert_e598141505134 : check e598141505134 [[],[.left]] .smaller = true := by decide
def e598141505146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598141505146 : Closed e598141505146 ∧ code e598141505146 = 2797164760698 := by decide
theorem cert_e598141505146 : check e598141505146 [[],[.left]] .smaller = true := by decide
def e598141505334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598141505334 : Closed e598141505334 ∧ code e598141505334 = 2797164760886 := by decide
theorem cert_e598141505334 : check e598141505334 [[],[.left]] .smaller = true := by decide
def e598141505338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598141505338 : Closed e598141505338 ∧ code e598141505338 = 2797164760890 := by decide
theorem cert_e598141505338 : check e598141505338 [[],[.left]] .smaller = true := by decide
def e598141513454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e598141513454 : Closed e598141513454 ∧ code e598141513454 = 2797164769006 := by decide
theorem cert_e598141513454 : check e598141513454 [[],[.left],[]] .sourceHead = true := by decide
def e598141513582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e598141513582 : Closed e598141513582 ∧ code e598141513582 = 2797164769134 := by decide
theorem cert_e598141513582 : check e598141513582 [[],[.left],[]] .sourceHead = true := by decide
def e598141513590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e598141513590 : Closed e598141513590 ∧ code e598141513590 = 2797164769142 := by decide
theorem cert_e598141513590 : check e598141513590 [[],[.left],[]] .sourceHead = true := by decide
def e598141516270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e598141516270 : Closed e598141516270 ∧ code e598141516270 = 2797164771822 := by decide
theorem cert_e598141516270 : check e598141516270 [[],[.left],[]] .sourceHead = true := by decide
def e598141517038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e598141517038 : Closed e598141517038 ∧ code e598141517038 = 2797164772590 := by decide
theorem cert_e598141517038 : check e598141517038 [[],[.left],[]] .sourceHead = true := by decide
def e598141517046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e598141517046 : Closed e598141517046 ∧ code e598141517046 = 2797164772598 := by decide
theorem cert_e598141517046 : check e598141517046 [[],[.left],[]] .sourceHead = true := by decide
def e598141540078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e598141540078 : Closed e598141540078 ∧ code e598141540078 = 2797164795630 := by decide
theorem cert_e598141540078 : check e598141540078 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e598141540270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e598141540270 : Closed e598141540270 ∧ code e598141540270 = 2797164795822 := by decide
theorem cert_e598141540270 : check e598141540270 [[],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e598141540282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e598141540282 : Closed e598141540282 ∧ code e598141540282 = 2797164795834 := by decide
theorem cert_e598141540282 : check e598141540282 [[],[.left],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e598141540846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e598141540846 : Closed e598141540846 ∧ code e598141540846 = 2797164796398 := by decide
theorem cert_e598141540846 : check e598141540846 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e598141541998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e598141541998 : Closed e598141541998 ∧ code e598141541998 = 2797164797550 := by decide
theorem cert_e598141541998 : check e598141541998 [[],[.left],[],[.under],[.under]] .three = true := by decide
def e598141542010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e598141542010 : Closed e598141542010 ∧ code e598141542010 = 2797164797562 := by decide
theorem cert_e598141542010 : check e598141542010 [[],[.left],[],[.under],[.under]] .three = true := by decide
def e598141553518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598141553518 : Closed e598141553518 ∧ code e598141553518 = 2797164809070 := by decide
theorem cert_e598141553518 : check e598141553518 [[],[.left],[],[.under]] .three = true := by decide
def e598141553526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598141553526 : Closed e598141553526 ∧ code e598141553526 = 2797164809078 := by decide
theorem cert_e598141553526 : check e598141553526 [[],[.left],[],[.under]] .three = true := by decide
def e598141553582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598141553582 : Closed e598141553582 ∧ code e598141553582 = 2797164809134 := by decide
theorem cert_e598141553582 : check e598141553582 [[],[.left],[],[.under]] .three = true := by decide
def e598141553594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598141553594 : Closed e598141553594 ∧ code e598141553594 = 2797164809146 := by decide
theorem cert_e598141553594 : check e598141553594 [[],[.left],[],[.under]] .three = true := by decide
def e598141553622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598141553622 : Closed e598141553622 ∧ code e598141553622 = 2797164809174 := by decide
theorem cert_e598141553622 : check e598141553622 [[],[.left],[],[.under]] .three = true := by decide
def e598141553626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598141553626 : Closed e598141553626 ∧ code e598141553626 = 2797164809178 := by decide
theorem cert_e598141553626 : check e598141553626 [[],[.left],[],[.under]] .three = true := by decide
def e598141553902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598141553902 : Closed e598141553902 ∧ code e598141553902 = 2797164809454 := by decide
theorem cert_e598141553902 : check e598141553902 [[],[.left],[],[.under]] .three = true := by decide
def e598141553910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598141553910 : Closed e598141553910 ∧ code e598141553910 = 2797164809462 := by decide
theorem cert_e598141553910 : check e598141553910 [[],[.left],[],[.under]] .three = true := by decide
def e598141554286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598141554286 : Closed e598141554286 ∧ code e598141554286 = 2797164809838 := by decide
theorem cert_e598141554286 : check e598141554286 [[],[.left],[],[.under]] .three = true := by decide
def e598141554298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598141554298 : Closed e598141554298 ∧ code e598141554298 = 2797164809850 := by decide
theorem cert_e598141554298 : check e598141554298 [[],[.left],[],[.under]] .three = true := by decide
def e598141554486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598141554486 : Closed e598141554486 ∧ code e598141554486 = 2797164810038 := by decide
theorem cert_e598141554486 : check e598141554486 [[],[.left],[],[.under]] .three = true := by decide
def e598141554490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598141554490 : Closed e598141554490 ∧ code e598141554490 = 2797164810042 := by decide
theorem cert_e598141554490 : check e598141554490 [[],[.left],[],[.under]] .three = true := by decide
def e598142094190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598142094190 : Closed e598142094190 ∧ code e598142094190 = 2797165349742 := by decide
theorem cert_e598142094190 : check e598142094190 [[],[.left]] .smaller = true := by decide
def e598142094198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598142094198 : Closed e598142094198 ∧ code e598142094198 = 2797165349750 := by decide
theorem cert_e598142094198 : check e598142094198 [[],[.left]] .smaller = true := by decide
def e598142094254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598142094254 : Closed e598142094254 ∧ code e598142094254 = 2797165349806 := by decide
theorem cert_e598142094254 : check e598142094254 [[],[.left]] .smaller = true := by decide
def e598142094266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598142094266 : Closed e598142094266 ∧ code e598142094266 = 2797165349818 := by decide
theorem cert_e598142094266 : check e598142094266 [[],[.left]] .smaller = true := by decide
def e598142094294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598142094294 : Closed e598142094294 ∧ code e598142094294 = 2797165349846 := by decide
theorem cert_e598142094294 : check e598142094294 [[],[.left]] .smaller = true := by decide
def e598142094298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598142094298 : Closed e598142094298 ∧ code e598142094298 = 2797165349850 := by decide
theorem cert_e598142094298 : check e598142094298 [[],[.left]] .smaller = true := by decide
def e598142094574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598142094574 : Closed e598142094574 ∧ code e598142094574 = 2797165350126 := by decide
theorem cert_e598142094574 : check e598142094574 [[],[.left]] .smaller = true := by decide
def e598142094582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598142094582 : Closed e598142094582 ∧ code e598142094582 = 2797165350134 := by decide
theorem cert_e598142094582 : check e598142094582 [[],[.left]] .smaller = true := by decide
def e598142094958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598142094958 : Closed e598142094958 ∧ code e598142094958 = 2797165350510 := by decide
theorem cert_e598142094958 : check e598142094958 [[],[.left]] .smaller = true := by decide
def e598142094970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598142094970 : Closed e598142094970 ∧ code e598142094970 = 2797165350522 := by decide
theorem cert_e598142094970 : check e598142094970 [[],[.left]] .smaller = true := by decide
def e598142095158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598142095158 : Closed e598142095158 ∧ code e598142095158 = 2797165350710 := by decide
theorem cert_e598142095158 : check e598142095158 [[],[.left]] .smaller = true := by decide
def e598142095162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598142095162 : Closed e598142095162 ∧ code e598142095162 = 2797165350714 := by decide
theorem cert_e598142095162 : check e598142095162 [[],[.left]] .smaller = true := by decide
def e598174948206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e598174948206 : Closed e598174948206 ∧ code e598174948206 = 2797198203758 := by decide
theorem cert_e598174948206 : check e598174948206 [[],[.left],[]] .sourceHead = true := by decide
def e598174948214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e598174948214 : Closed e598174948214 ∧ code e598174948214 = 2797198203766 := by decide
theorem cert_e598174948214 : check e598174948214 [[],[.left],[]] .sourceHead = true := by decide
def e598174948278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e598174948278 : Closed e598174948278 ∧ code e598174948278 = 2797198203830 := by decide
theorem cert_e598174948278 : check e598174948278 [[],[.left],[]] .sourceHead = true := by decide
def e598174948718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e598174948718 : Closed e598174948718 ∧ code e598174948718 = 2797198204270 := by decide
def e598174948726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e598174948726 : Closed e598174948726 ∧ code e598174948726 = 2797198204278 := by decide
theorem cert_e598174948726 : check e598174948726 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598174948782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e598174948782 : Closed e598174948782 ∧ code e598174948782 = 2797198204334 := by decide
theorem cert_e598174948782 : check e598174948782 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598174948794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e598174948794 : Closed e598174948794 ∧ code e598174948794 = 2797198204346 := by decide
theorem cert_e598174948794 : check e598174948794 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598174948822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e598174948822 : Closed e598174948822 ∧ code e598174948822 = 2797198204374 := by decide
theorem cert_e598174948822 : check e598174948822 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598174948826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e598174948826 : Closed e598174948826 ∧ code e598174948826 = 2797198204378 := by decide
theorem cert_e598174948826 : check e598174948826 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598174949046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e598174949046 : Closed e598174949046 ∧ code e598174949046 = 2797198204598 := by decide
theorem cert_e598174949046 : check e598174949046 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598174949078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e598174949078 : Closed e598174949078 ∧ code e598174949078 = 2797198204630 := by decide
theorem cert_e598174949078 : check e598174949078 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598174949082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e598174949082 : Closed e598174949082 ∧ code e598174949082 = 2797198204634 := by decide
theorem cert_e598174949082 : check e598174949082 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598174951278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e598174951278 : Closed e598174951278 ∧ code e598174951278 = 2797198206830 := by decide
theorem cert_e598174951278 : check e598174951278 [[],[.left],[]] .sourceHead = true := by decide
def e598174951286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e598174951286 : Closed e598174951286 ∧ code e598174951286 = 2797198206838 := by decide
theorem cert_e598174951286 : check e598174951286 [[],[.left],[]] .sourceHead = true := by decide
def e598174951350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e598174951350 : Closed e598174951350 ∧ code e598174951350 = 2797198206902 := by decide
theorem cert_e598174951350 : check e598174951350 [[],[.left],[]] .sourceHead = true := by decide
def e598174952686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e598174952686 : Closed e598174952686 ∧ code e598174952686 = 2797198208238 := by decide
theorem cert_e598174952686 : check e598174952686 [[],[.left],[]] .sourceHead = true := by decide
def e598174952694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e598174952694 : Closed e598174952694 ∧ code e598174952694 = 2797198208246 := by decide
theorem cert_e598174952694 : check e598174952694 [[],[.left],[]] .sourceHead = true := by decide
def e598174953078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e598174953078 : Closed e598174953078 ∧ code e598174953078 = 2797198208630 := by decide
theorem cert_e598174953078 : check e598174953078 [[],[.left],[]] .sourceHead = true := by decide
def e598174954350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e598174954350 : Closed e598174954350 ∧ code e598174954350 = 2797198209902 := by decide
theorem cert_e598174954350 : check e598174954350 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174954358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e598174954358 : Closed e598174954358 ∧ code e598174954358 = 2797198209910 := by decide
theorem cert_e598174954358 : check e598174954358 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174954414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e598174954414 : Closed e598174954414 ∧ code e598174954414 = 2797198209966 := by decide
theorem cert_e598174954414 : check e598174954414 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174954426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e598174954426 : Closed e598174954426 ∧ code e598174954426 = 2797198209978 := by decide
theorem cert_e598174954426 : check e598174954426 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e598174954454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e598174954454 : Closed e598174954454 ∧ code e598174954454 = 2797198210006 := by decide
theorem cert_e598174954454 : check e598174954454 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174954458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e598174954458 : Closed e598174954458 ∧ code e598174954458 = 2797198210010 := by decide
theorem cert_e598174954458 : check e598174954458 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e598174954734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e598174954734 : Closed e598174954734 ∧ code e598174954734 = 2797198210286 := by decide
theorem cert_e598174954734 : check e598174954734 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174954742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e598174954742 : Closed e598174954742 ∧ code e598174954742 = 2797198210294 := by decide
theorem cert_e598174954742 : check e598174954742 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174955118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e598174955118 : Closed e598174955118 ∧ code e598174955118 = 2797198210670 := by decide
theorem cert_e598174955118 : check e598174955118 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174955130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e598174955130 : Closed e598174955130 ∧ code e598174955130 = 2797198210682 := by decide
theorem cert_e598174955130 : check e598174955130 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174955318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e598174955318 : Closed e598174955318 ∧ code e598174955318 = 2797198210870 := by decide
theorem cert_e598174955318 : check e598174955318 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174955322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e598174955322 : Closed e598174955322 ∧ code e598174955322 = 2797198210874 := by decide
theorem cert_e598174955322 : check e598174955322 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e598174955958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e598174955958 : Closed e598174955958 ∧ code e598174955958 = 2797198211510 := by decide
theorem cert_e598174955958 : check e598174955958 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598174955990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e598174955990 : Closed e598174955990 ∧ code e598174955990 = 2797198211542 := by decide
theorem cert_e598174955990 : check e598174955990 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598174955994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e598174955994 : Closed e598174955994 ∧ code e598174955994 = 2797198211546 := by decide
theorem cert_e598174955994 : check e598174955994 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598174956150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e598174956150 : Closed e598174956150 ∧ code e598174956150 = 2797198211702 := by decide
theorem cert_e598174956150 : checkPay e598174956150 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598174956342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e598174956342 : Closed e598174956342 ∧ code e598174956342 = 2797198211894 := by decide
theorem cert_e598174956342 : check e598174956342 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598174956346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e598174956346 : Closed e598174956346 ∧ code e598174956346 = 2797198211898 := by decide
theorem cert_e598174956346 : check e598174956346 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598174963566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e598174963566 : Closed e598174963566 ∧ code e598174963566 = 2797198219118 := by decide
theorem cert_e598174963566 : check e598174963566 [[],[.left],[]] .sourceHead = true := by decide
def e598174963574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e598174963574 : Closed e598174963574 ∧ code e598174963574 = 2797198219126 := by decide
theorem cert_e598174963574 : check e598174963574 [[],[.left],[]] .sourceHead = true := by decide
def e598174963638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e598174963638 : Closed e598174963638 ∧ code e598174963638 = 2797198219190 := by decide
theorem cert_e598174963638 : check e598174963638 [[],[.left],[]] .sourceHead = true := by decide
def e598174964974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e598174964974 : Closed e598174964974 ∧ code e598174964974 = 2797198220526 := by decide
theorem cert_e598174964974 : check e598174964974 [[],[.left],[]] .sourceHead = true := by decide
def e598174964982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e598174964982 : Closed e598174964982 ∧ code e598174964982 = 2797198220534 := by decide
theorem cert_e598174964982 : check e598174964982 [[],[.left],[]] .sourceHead = true := by decide
def e598174965366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e598174965366 : Closed e598174965366 ∧ code e598174965366 = 2797198220918 := by decide
theorem cert_e598174965366 : check e598174965366 [[],[.left],[]] .sourceHead = true := by decide
def e598174976878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598174976878 : Closed e598174976878 ∧ code e598174976878 = 2797198232430 := by decide
theorem cert_e598174976878 : check e598174976878 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174976886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598174976886 : Closed e598174976886 ∧ code e598174976886 = 2797198232438 := by decide
theorem cert_e598174976886 : check e598174976886 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174976942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598174976942 : Closed e598174976942 ∧ code e598174976942 = 2797198232494 := by decide
theorem cert_e598174976942 : check e598174976942 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174976954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598174976954 : Closed e598174976954 ∧ code e598174976954 = 2797198232506 := by decide
theorem cert_e598174976954 : check e598174976954 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174976982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598174976982 : Closed e598174976982 ∧ code e598174976982 = 2797198232534 := by decide
theorem cert_e598174976982 : check e598174976982 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174976986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598174976986 : Closed e598174976986 ∧ code e598174976986 = 2797198232538 := by decide
theorem cert_e598174976986 : check e598174976986 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174977262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598174977262 : Closed e598174977262 ∧ code e598174977262 = 2797198232814 := by decide
theorem cert_e598174977262 : check e598174977262 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174977270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598174977270 : Closed e598174977270 ∧ code e598174977270 = 2797198232822 := by decide
theorem cert_e598174977270 : check e598174977270 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174977646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598174977646 : Closed e598174977646 ∧ code e598174977646 = 2797198233198 := by decide
theorem cert_e598174977646 : check e598174977646 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174977658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598174977658 : Closed e598174977658 ∧ code e598174977658 = 2797198233210 := by decide
theorem cert_e598174977658 : check e598174977658 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174977846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598174977846 : Closed e598174977846 ∧ code e598174977846 = 2797198233398 := by decide
theorem cert_e598174977846 : check e598174977846 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174977850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598174977850 : Closed e598174977850 ∧ code e598174977850 = 2797198233402 := by decide
theorem cert_e598174977850 : check e598174977850 [[],[.left],[],[.under]] .smaller = true := by decide
def e598174983606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e598174983606 : Closed e598174983606 ∧ code e598174983606 = 2797198239158 := by decide
theorem cert_e598174983606 : check e598174983606 [[],[.left],[],[.under]] .three = true := by decide
def e598174983638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e598174983638 : Closed e598174983638 ∧ code e598174983638 = 2797198239190 := by decide
theorem cert_e598174983638 : check e598174983638 [[],[.left],[],[.under]] .three = true := by decide
def e598174983642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e598174983642 : Closed e598174983642 ∧ code e598174983642 = 2797198239194 := by decide
theorem cert_e598174983642 : check e598174983642 [[],[.left],[],[.under]] .three = true := by decide
def e598174983798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e598174983798 : Closed e598174983798 ∧ code e598174983798 = 2797198239350 := by decide
theorem cert_e598174983798 : check e598174983798 [[],[.left],[],[.under]] .three = true := by decide
def e598174983990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e598174983990 : Closed e598174983990 ∧ code e598174983990 = 2797198239542 := by decide
theorem cert_e598174983990 : check e598174983990 [[],[.left],[],[.under]] .three = true := by decide
def e598174983994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e598174983994 : Closed e598174983994 ∧ code e598174983994 = 2797198239546 := by decide
theorem cert_e598174983994 : check e598174983994 [[],[.left],[],[.under]] .three = true := by decide
def e598175320942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598175320942 : Closed e598175320942 ∧ code e598175320942 = 2797198576494 := by decide
def e598175320950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598175320950 : Closed e598175320950 ∧ code e598175320950 = 2797198576502 := by decide
private def t_e598175320950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e598175320950 : ¬ IsSelfInterpreter e598175320950 :=
  wSource (t := t_e598175320950) (replay_sound (ps := []) (t := e598175320950) (by decide)) (by decide)
def e598175321006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598175321006 : Closed e598175321006 ∧ code e598175321006 = 2797198576558 := by decide
theorem cert_e598175321006 : check e598175321006 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e598175321018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598175321018 : Closed e598175321018 ∧ code e598175321018 = 2797198576570 := by decide
theorem cert_e598175321018 : checkPay e598175321018 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[]] 0 [[.under,.left],[.under]] = true := by decide
def e598175321046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598175321046 : Closed e598175321046 ∧ code e598175321046 = 2797198576598 := by decide
private def t_e598175321046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e598175321046 : ¬ IsSelfInterpreter e598175321046 :=
  wSource (t := t_e598175321046) (replay_sound (ps := []) (t := e598175321046) (by decide)) (by decide)
def e598175321050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598175321050 : Closed e598175321050 ∧ code e598175321050 = 2797198576602 := by decide
theorem cert_e598175321050 : check e598175321050 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598175321326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598175321326 : Closed e598175321326 ∧ code e598175321326 = 2797198576878 := by decide
theorem cert_e598175321326 : checkPay e598175321326 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e598175321334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598175321334 : Closed e598175321334 ∧ code e598175321334 = 2797198576886 := by decide
theorem cert_e598175321334 : check e598175321334 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598175321710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598175321710 : Closed e598175321710 ∧ code e598175321710 = 2797198577262 := by decide
theorem cert_e598175321710 : check e598175321710 [[],[.left],[],[],[.under],[.under]] .smaller = true := by decide
def e598175321722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598175321722 : Closed e598175321722 ∧ code e598175321722 = 2797198577274 := by decide
theorem cert_e598175321722 : check e598175321722 [[],[.left],[],[],[.under],[.under]] .smaller = true := by decide
def e598175321910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598175321910 : Closed e598175321910 ∧ code e598175321910 = 2797198577462 := by decide
theorem cert_e598175321910 : check e598175321910 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e598175321914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598175321914 : Closed e598175321914 ∧ code e598175321914 = 2797198577466 := by decide
theorem cert_e598175321914 : check e598175321914 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598276271642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276271642 : Closed e598276271642 ∧ code e598276271642 = 2797299527194 := by decide
private def t_e598276271642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276271642 : ¬ IsSelfInterpreter e598276271642 :=
  wSource (t := t_e598276271642) (replay_sound (ps := []) (t := e598276271642) (by decide)) (by decide)
def e598276273690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276273690 : Closed e598276273690 ∧ code e598276273690 = 2797299529242 := by decide
private def t_e598276273690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276273690 : ¬ IsSelfInterpreter e598276273690 :=
  wSource (t := t_e598276273690) (replay_sound (ps := []) (t := e598276273690) (by decide)) (by decide)
def e598276288026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276288026 : Closed e598276288026 ∧ code e598276288026 = 2797299543578 := by decide
private def t_e598276288026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276288026 : ¬ IsSelfInterpreter e598276288026 :=
  wSource (t := t_e598276288026) (replay_sound (ps := []) (t := e598276288026) (by decide)) (by decide)
def e598276291098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598276291098 : Closed e598276291098 ∧ code e598276291098 = 2797299546650 := by decide
private def t_e598276291098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598276291098 : ¬ IsSelfInterpreter e598276291098 :=
  wSource (t := t_e598276291098) (replay_sound (ps := []) (t := e598276291098) (by decide)) (by decide)
end Blc.Floor41
