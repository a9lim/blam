import Extra41
import Batch147
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605804343130
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u0
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804343130 : ¬ IsSelfInterpreter e605804343130 := by
  intro he
  have h : replay [] e605804343130 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804343130
end Witness605804343130
namespace Witness605804344174
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.app u0 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804344174 : ¬ IsSelfInterpreter e605804344174 := by
  intro he
  have h : replay [] e605804344174 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804344174
end Witness605804344174
namespace Witness605804344238
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.app u0 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804344238 : ¬ IsSelfInterpreter e605804344238 := by
  intro he
  have h : replay [] e605804344238 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804344238
end Witness605804344238
namespace Witness605804344250
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u0 u3
private def u15 := Term.app u14 u0
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou14 : SO u14 := SO.app sou0 sou3
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605804344250 : ¬ IsSelfInterpreter e605804344250 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605804344250
end Witness605804344250
namespace Witness605804344282
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u4 u0
private def u15 := Term.app u0 u4
private def u16 := Term.app u15 u0
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou14 : SO u14 := SO.app sou4 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u16) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605804344282 : ¬ IsSelfInterpreter e605804344282 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605804344282
end Witness605804344282
namespace Witness605804344558
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u1 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u0 u3
private def u14 := Term.app u1 u3
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou1 sou5
private theorem sou13 : SO u13 := SO.app sou0 sou3
private theorem sou7 : SO u7 := SO.lam (r := u13) (g := u14) sou6 sou13 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605804344558 : ¬ IsSelfInterpreter e605804344558 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605804344558
end Witness605804344558
namespace Witness605804344566
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u3 u4
private def u6 := Term.app u1 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u4 u0
private def u14 := Term.app u1 u4
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou1 sou5
private theorem sou13 : SO u13 := SO.app sou4 sou0
private theorem sou7 : SO u7 := SO.lam (r := u13) (g := u14) sou6 sou13 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605804344566 : ¬ IsSelfInterpreter e605804344566 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605804344566
end Witness605804344566
namespace Witness605804344942
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804344942 : ¬ IsSelfInterpreter e605804344942 := by
  intro he
  have h : replay [] e605804344942 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804344942
end Witness605804344942
end Blc.Floor41
