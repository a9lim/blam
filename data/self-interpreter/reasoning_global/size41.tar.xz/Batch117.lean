import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603709918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605603709918 : Closed e605603709918 ∧ code e605603709918 = 2804626965470 := by decide
theorem cert_e605603709918 : check e605603709918 [[],[]] .chain = true := by decide
def e605603709934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605603709934 : Closed e605603709934 ∧ code e605603709934 = 2804626965486 := by decide
theorem cert_e605603709934 : check e605603709934 [[],[]] .chain = true := by decide
def e605603711854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605603711854 : Closed e605603711854 ∧ code e605603711854 = 2804626967406 := by decide
theorem cert_e605603711854 : check e605603711854 [[],[]] .chain = true := by decide
def e605603711862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605603711862 : Closed e605603711862 ∧ code e605603711862 = 2804626967414 := by decide
theorem cert_e605603711862 : check e605603711862 [[],[]] .chain = true := by decide
def e605603711918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605603711918 : Closed e605603711918 ∧ code e605603711918 = 2804626967470 := by decide
theorem cert_e605603711918 : check e605603711918 [[],[]] .chain = true := by decide
def e605603711930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605603711930 : Closed e605603711930 ∧ code e605603711930 = 2804626967482 := by decide
theorem cert_e605603711930 : check e605603711930 [[],[]] .chain = true := by decide
def e605603711958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605603711958 : Closed e605603711958 ∧ code e605603711958 = 2804626967510 := by decide
theorem cert_e605603711958 : check e605603711958 [[],[]] .chain = true := by decide
def e605603711962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605603711962 : Closed e605603711962 ∧ code e605603711962 = 2804626967514 := by decide
theorem cert_e605603711962 : check e605603711962 [[],[]] .chain = true := by decide
def e605603712238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603712238 : Closed e605603712238 ∧ code e605603712238 = 2804626967790 := by decide
theorem cert_e605603712238 : check e605603712238 [[],[]] .chain = true := by decide
def e605603712246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603712246 : Closed e605603712246 ∧ code e605603712246 = 2804626967798 := by decide
theorem cert_e605603712246 : check e605603712246 [[],[]] .chain = true := by decide
def e605603712622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603712622 : Closed e605603712622 ∧ code e605603712622 = 2804626968174 := by decide
theorem cert_e605603712622 : check e605603712622 [[],[]] .chain = true := by decide
def e605603712634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603712634 : Closed e605603712634 ∧ code e605603712634 = 2804626968186 := by decide
theorem cert_e605603712634 : check e605603712634 [[],[]] .chain = true := by decide
def e605603712822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603712822 : Closed e605603712822 ∧ code e605603712822 = 2804626968374 := by decide
theorem cert_e605603712822 : check e605603712822 [[],[]] .chain = true := by decide
def e605603712826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603712826 : Closed e605603712826 ∧ code e605603712826 = 2804626968378 := by decide
theorem cert_e605603712826 : check e605603712826 [[],[]] .chain = true := by decide
def e605603717598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605603717598 : Closed e605603717598 ∧ code e605603717598 = 2804626973150 := by decide
theorem cert_e605603717598 : check e605603717598 [[],[]] .chain = true := by decide
def e605603717622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605603717622 : Closed e605603717622 ∧ code e605603717622 = 2804626973174 := by decide
theorem cert_e605603717622 : check e605603717622 [[],[]] .chain = true := by decide
def e605603718574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605603718574 : Closed e605603718574 ∧ code e605603718574 = 2804626974126 := by decide
theorem cert_e605603718574 : check e605603718574 [[],[]] .chain = true := by decide
def e605603718586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605603718586 : Closed e605603718586 ∧ code e605603718586 = 2804626974138 := by decide
theorem cert_e605603718586 : check e605603718586 [[],[]] .chain = true := by decide
def e605603718634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605603718634 : Closed e605603718634 ∧ code e605603718634 = 2804626974186 := by decide
theorem cert_e605603718634 : check e605603718634 [[],[]] .chain = true := by decide
def e605603718766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603718766 : Closed e605603718766 ∧ code e605603718766 = 2804626974318 := by decide
theorem cert_e605603718766 : check e605603718766 [[],[]] .chain = true := by decide
def e605603718778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603718778 : Closed e605603718778 ∧ code e605603718778 = 2804626974330 := by decide
theorem cert_e605603718778 : check e605603718778 [[],[]] .chain = true := by decide
def e605603718942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605603718942 : Closed e605603718942 ∧ code e605603718942 = 2804626974494 := by decide
theorem cert_e605603718942 : check e605603718942 [[],[]] .chain = true := by decide
def e605603719042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605603719042 : Closed e605603719042 ∧ code e605603719042 = 2804626974594 := by decide
theorem cert_e605603719042 : check e605603719042 [[],[]] .chain = true := by decide
def e605603719054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605603719054 : Closed e605603719054 ∧ code e605603719054 = 2804626974606 := by decide
theorem cert_e605603719054 : check e605603719054 [[],[]] .chain = true := by decide
def e605603719066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603719066 : Closed e605603719066 ∧ code e605603719066 = 2804626974618 := by decide
theorem cert_e605603719066 : check e605603719066 [[],[]] .chain = true := by decide
def e605603721454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605603721454 : Closed e605603721454 ∧ code e605603721454 = 2804626977006 := by decide
theorem cert_e605603721454 : check e605603721454 [[],[]] .chain = true := by decide
def e605603721462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605603721462 : Closed e605603721462 ∧ code e605603721462 = 2804626977014 := by decide
theorem cert_e605603721462 : check e605603721462 [[],[]] .chain = true := by decide
def e605603721942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605603721942 : Closed e605603721942 ∧ code e605603721942 = 2804626977494 := by decide
theorem cert_e605603721942 : check e605603721942 [[],[]] .chain = true := by decide
def e605603721946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605603721946 : Closed e605603721946 ∧ code e605603721946 = 2804626977498 := by decide
theorem cert_e605603721946 : check e605603721946 [[],[]] .chain = true := by decide
def e605603721962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605603721962 : Closed e605603721962 ∧ code e605603721962 = 2804626977514 := by decide
theorem cert_e605603721962 : check e605603721962 [[],[]] .chain = true := by decide
def e605603722038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603722038 : Closed e605603722038 ∧ code e605603722038 = 2804626977590 := by decide
theorem cert_e605603722038 : check e605603722038 [[],[]] .chain = true := by decide
def e605603722042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603722042 : Closed e605603722042 ∧ code e605603722042 = 2804626977594 := by decide
theorem cert_e605603722042 : check e605603722042 [[],[]] .chain = true := by decide
def e605603722114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605603722114 : Closed e605603722114 ∧ code e605603722114 = 2804626977666 := by decide
theorem cert_e605603722114 : check e605603722114 [[],[]] .chain = true := by decide
def e605603722126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605603722126 : Closed e605603722126 ∧ code e605603722126 = 2804626977678 := by decide
theorem cert_e605603722126 : check e605603722126 [[],[]] .chain = true := by decide
def e605603722138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603722138 : Closed e605603722138 ∧ code e605603722138 = 2804626977690 := by decide
theorem cert_e605603722138 : check e605603722138 [[],[]] .chain = true := by decide
def e605603725742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e605603725742 : Closed e605603725742 ∧ code e605603725742 = 2804626981294 := by decide
theorem cert_e605603725742 : check e605603725742 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603725934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605603725934 : Closed e605603725934 ∧ code e605603725934 = 2804626981486 := by decide
theorem cert_e605603725934 : check e605603725934 [[],[]] .chain = true := by decide
def e605603725946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605603725946 : Closed e605603725946 ∧ code e605603725946 = 2804626981498 := by decide
theorem cert_e605603725946 : check e605603725946 [[],[]] .chain = true := by decide
def e605603726318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 2)))))))
theorem wire_e605603726318 : Closed e605603726318 ∧ code e605603726318 = 2804626981870 := by decide
theorem cert_e605603726318 : check e605603726318 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603727086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e605603727086 : Closed e605603727086 ∧ code e605603727086 = 2804626982638 := by decide
theorem cert_e605603727086 : check e605603727086 [[],[]] .chain = true := by decide
def e605603727094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605603727094 : Closed e605603727094 ∧ code e605603727094 = 2804626982646 := by decide
theorem cert_e605603727094 : check e605603727094 [[],[]] .chain = true := by decide
def e605603727214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605603727214 : Closed e605603727214 ∧ code e605603727214 = 2804626982766 := by decide
theorem cert_e605603727214 : check e605603727214 [[],[]] .chain = true := by decide
def e605603727226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605603727226 : Closed e605603727226 ∧ code e605603727226 = 2804626982778 := by decide
theorem cert_e605603727226 : check e605603727226 [[],[]] .chain = true := by decide
def e605603727278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e605603727278 : Closed e605603727278 ∧ code e605603727278 = 2804626982830 := by decide
theorem cert_e605603727278 : check e605603727278 [[],[]] .chain = true := by decide
def e605603727318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605603727318 : Closed e605603727318 ∧ code e605603727318 = 2804626982870 := by decide
theorem cert_e605603727318 : check e605603727318 [[],[]] .chain = true := by decide
def e605603727322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605603727322 : Closed e605603727322 ∧ code e605603727322 = 2804626982874 := by decide
theorem cert_e605603727322 : check e605603727322 [[],[]] .chain = true := by decide
def e605603727854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e605603727854 : Closed e605603727854 ∧ code e605603727854 = 2804626983406 := by decide
theorem cert_e605603727854 : check e605603727854 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603728622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605603728622 : Closed e605603728622 ∧ code e605603728622 = 2804626984174 := by decide
theorem cert_e605603728622 : check e605603728622 [[],[]] .chain = true := by decide
def e605603728630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605603728630 : Closed e605603728630 ∧ code e605603728630 = 2804626984182 := by decide
theorem cert_e605603728630 : check e605603728630 [[],[]] .chain = true := by decide
def e605603729006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605603729006 : Closed e605603729006 ∧ code e605603729006 = 2804626984558 := by decide
theorem cert_e605603729006 : check e605603729006 [[],[]] .chain = true := by decide
def e605603729018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605603729018 : Closed e605603729018 ∧ code e605603729018 = 2804626984570 := by decide
theorem cert_e605603729018 : check e605603729018 [[],[]] .chain = true := by decide
def e605603729182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 3))))))))
theorem wire_e605603729182 : Closed e605603729182 ∧ code e605603729182 = 2804626984734 := by decide
theorem cert_e605603729182 : check e605603729182 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603729206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605603729206 : Closed e605603729206 ∧ code e605603729206 = 2804626984758 := by decide
theorem cert_e605603729206 : check e605603729206 [[],[]] .chain = true := by decide
def e605603729210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605603729210 : Closed e605603729210 ∧ code e605603729210 = 2804626984762 := by decide
theorem cert_e605603729210 : check e605603729210 [[],[]] .chain = true := by decide
def e605603731118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605603731118 : Closed e605603731118 ∧ code e605603731118 = 2804626986670 := by decide
theorem cert_e605603731118 : check e605603731118 [[],[]] .chain = true := by decide
def e605603731130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605603731130 : Closed e605603731130 ∧ code e605603731130 = 2804626986682 := by decide
theorem cert_e605603731130 : check e605603731130 [[],[]] .chain = true := by decide
def e605603731178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605603731178 : Closed e605603731178 ∧ code e605603731178 = 2804626986730 := by decide
theorem cert_e605603731178 : check e605603731178 [[],[]] .chain = true := by decide
def e605603731370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605603731370 : Closed e605603731370 ∧ code e605603731370 = 2804626986922 := by decide
theorem cert_e605603731370 : check e605603731370 [[],[]] .chain = true := by decide
def e605603731502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605603731502 : Closed e605603731502 ∧ code e605603731502 = 2804626987054 := by decide
theorem cert_e605603731502 : check e605603731502 [[],[]] .chain = true := by decide
def e605603731694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605603731694 : Closed e605603731694 ∧ code e605603731694 = 2804626987246 := by decide
theorem cert_e605603731694 : check e605603731694 [[],[]] .chain = true := by decide
def e605603731702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605603731702 : Closed e605603731702 ∧ code e605603731702 = 2804626987254 := by decide
theorem cert_e605603731702 : check e605603731702 [[],[]] .chain = true := by decide
def e605603731886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605603731886 : Closed e605603731886 ∧ code e605603731886 = 2804626987438 := by decide
theorem cert_e605603731886 : check e605603731886 [[],[]] .chain = true := by decide
def e605603731898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605603731898 : Closed e605603731898 ∧ code e605603731898 = 2804626987450 := by decide
theorem cert_e605603731898 : check e605603731898 [[],[]] .chain = true := by decide
def e605603731946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605603731946 : Closed e605603731946 ∧ code e605603731946 = 2804626987498 := by decide
theorem cert_e605603731946 : check e605603731946 [[],[]] .chain = true := by decide
def e605603732078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605603732078 : Closed e605603732078 ∧ code e605603732078 = 2804626987630 := by decide
theorem cert_e605603732078 : check e605603732078 [[],[]] .chain = true := by decide
def e605603732090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605603732090 : Closed e605603732090 ∧ code e605603732090 = 2804626987642 := by decide
theorem cert_e605603732090 : check e605603732090 [[],[]] .chain = true := by decide
def e605603732254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605603732254 : Closed e605603732254 ∧ code e605603732254 = 2804626987806 := by decide
theorem cert_e605603732254 : check e605603732254 [[],[]] .chain = true := by decide
def e605603732354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605603732354 : Closed e605603732354 ∧ code e605603732354 = 2804626987906 := by decide
theorem cert_e605603732354 : check e605603732354 [[],[]] .chain = true := by decide
def e605603732366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605603732366 : Closed e605603732366 ∧ code e605603732366 = 2804626987918 := by decide
theorem cert_e605603732366 : check e605603732366 [[],[]] .chain = true := by decide
def e605603732378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605603732378 : Closed e605603732378 ∧ code e605603732378 = 2804626987930 := by decide
theorem cert_e605603732378 : check e605603732378 [[],[]] .chain = true := by decide
def e605603732590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605603732590 : Closed e605603732590 ∧ code e605603732590 = 2804626988142 := by decide
theorem cert_e605603732590 : check e605603732590 [[],[]] .chain = true := by decide
def e605603732602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605603732602 : Closed e605603732602 ∧ code e605603732602 = 2804626988154 := by decide
theorem cert_e605603732602 : check e605603732602 [[],[]] .chain = true := by decide
def e605603732766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605603732766 : Closed e605603732766 ∧ code e605603732766 = 2804626988318 := by decide
theorem cert_e605603732766 : check e605603732766 [[],[]] .chain = true := by decide
def e605603732934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605603732934 : Closed e605603732934 ∧ code e605603732934 = 2804626988486 := by decide
theorem cert_e605603732934 : check e605603732934 [[],[]] .chain = true := by decide
def e605603733002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605603733002 : Closed e605603733002 ∧ code e605603733002 = 2804626988554 := by decide
theorem cert_e605603733002 : check e605603733002 [[],[]] .chain = true := by decide
def e605603733038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605603733038 : Closed e605603733038 ∧ code e605603733038 = 2804626988590 := by decide
theorem cert_e605603733038 : check e605603733038 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603733046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605603733046 : Closed e605603733046 ∧ code e605603733046 = 2804626988598 := by decide
theorem cert_e605603733046 : check e605603733046 [[],[]] .chain = true := by decide
def e605603733050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605603733050 : Closed e605603733050 ∧ code e605603733050 = 2804626988602 := by decide
theorem cert_e605603733050 : check e605603733050 [[],[]] .chain = true := by decide
def e605603733098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605603733098 : Closed e605603733098 ∧ code e605603733098 = 2804626988650 := by decide
theorem cert_e605603733098 : check e605603733098 [[],[]] .chain = true := by decide
def e605603733122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605603733122 : Closed e605603733122 ∧ code e605603733122 = 2804626988674 := by decide
theorem cert_e605603733122 : check e605603733122 [[],[]] .chain = true := by decide
def e605603733134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605603733134 : Closed e605603733134 ∧ code e605603733134 = 2804626988686 := by decide
theorem cert_e605603733134 : check e605603733134 [[],[]] .chain = true := by decide
def e605603733146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605603733146 : Closed e605603733146 ∧ code e605603733146 = 2804626988698 := by decide
theorem cert_e605603733146 : check e605603733146 [[],[]] .chain = true := by decide
def e605603733190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605603733190 : Closed e605603733190 ∧ code e605603733190 = 2804626988742 := by decide
theorem cert_e605603733190 : check e605603733190 [[],[]] .chain = true := by decide
def e605603733218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605603733218 : Closed e605603733218 ∧ code e605603733218 = 2804626988770 := by decide
theorem cert_e605603733218 : check e605603733218 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603733230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 2)))))))
theorem wire_e605603733230 : Closed e605603733230 ∧ code e605603733230 = 2804626988782 := by decide
theorem cert_e605603733230 : check e605603733230 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603733982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605603733982 : Closed e605603733982 ∧ code e605603733982 = 2804626989534 := by decide
theorem cert_e605603733982 : check e605603733982 [[],[]] .chain = true := by decide
def e605603734006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605603734006 : Closed e605603734006 ∧ code e605603734006 = 2804626989558 := by decide
theorem cert_e605603734006 : check e605603734006 [[],[]] .chain = true := by decide
def e605603734958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605603734958 : Closed e605603734958 ∧ code e605603734958 = 2804626990510 := by decide
theorem cert_e605603734958 : check e605603734958 [[],[]] .chain = true := by decide
def e605603734970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605603734970 : Closed e605603734970 ∧ code e605603734970 = 2804626990522 := by decide
theorem cert_e605603734970 : check e605603734970 [[],[]] .chain = true := by decide
def e605603735018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605603735018 : Closed e605603735018 ∧ code e605603735018 = 2804626990570 := by decide
theorem cert_e605603735018 : check e605603735018 [[],[]] .chain = true := by decide
def e605603735150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603735150 : Closed e605603735150 ∧ code e605603735150 = 2804626990702 := by decide
theorem cert_e605603735150 : check e605603735150 [[],[]] .chain = true := by decide
def e605603735162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603735162 : Closed e605603735162 ∧ code e605603735162 = 2804626990714 := by decide
theorem cert_e605603735162 : check e605603735162 [[],[]] .chain = true := by decide
def e605603735326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605603735326 : Closed e605603735326 ∧ code e605603735326 = 2804626990878 := by decide
theorem cert_e605603735326 : check e605603735326 [[],[]] .chain = true := by decide
def e605603735426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605603735426 : Closed e605603735426 ∧ code e605603735426 = 2804626990978 := by decide
theorem cert_e605603735426 : check e605603735426 [[],[]] .chain = true := by decide
def e605603735438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605603735438 : Closed e605603735438 ∧ code e605603735438 = 2804626990990 := by decide
theorem cert_e605603735438 : check e605603735438 [[],[]] .chain = true := by decide
def e605603735450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603735450 : Closed e605603735450 ∧ code e605603735450 = 2804626991002 := by decide
theorem cert_e605603735450 : check e605603735450 [[],[]] .chain = true := by decide
def e605603737822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605603737822 : Closed e605603737822 ∧ code e605603737822 = 2804626993374 := by decide
theorem cert_e605603737822 : check e605603737822 [[],[]] .chain = true := by decide
def e605603737850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605603737850 : Closed e605603737850 ∧ code e605603737850 = 2804626993402 := by decide
theorem cert_e605603737850 : check e605603737850 [[],[]] .chain = true := by decide
def e605603738398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605603738398 : Closed e605603738398 ∧ code e605603738398 = 2804626993950 := by decide
theorem cert_e605603738398 : check e605603738398 [[],[]] .chain = true := by decide
def e605603738566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605603738566 : Closed e605603738566 ∧ code e605603738566 = 2804626994118 := by decide
theorem cert_e605603738566 : check e605603738566 [[],[]] .chain = true := by decide
def e605603739674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605603739674 : Closed e605603739674 ∧ code e605603739674 = 2804626995226 := by decide
theorem cert_e605603739674 : check e605603739674 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603739710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 4)))))))))
theorem wire_e605603739710 : Closed e605603739710 ∧ code e605603739710 = 2804626995262 := by decide
theorem cert_e605603739710 : check e605603739710 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603739758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605603739758 : Closed e605603739758 ∧ code e605603739758 = 2804626995310 := by decide
theorem cert_e605603739758 : check e605603739758 [[],[]] .chain = true := by decide
def e605603739766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605603739766 : Closed e605603739766 ∧ code e605603739766 = 2804626995318 := by decide
theorem cert_e605603739766 : check e605603739766 [[],[]] .chain = true := by decide
def e605603739770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605603739770 : Closed e605603739770 ∧ code e605603739770 = 2804626995322 := by decide
theorem cert_e605603739770 : check e605603739770 [[],[]] .chain = true := by decide
def e605603740010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605603740010 : Closed e605603740010 ∧ code e605603740010 = 2804626995562 := by decide
theorem cert_e605603740010 : check e605603740010 [[],[]] .chain = true := by decide
def e605603740034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605603740034 : Closed e605603740034 ∧ code e605603740034 = 2804626995586 := by decide
theorem cert_e605603740034 : check e605603740034 [[],[]] .chain = true := by decide
def e605603740046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605603740046 : Closed e605603740046 ∧ code e605603740046 = 2804626995598 := by decide
theorem cert_e605603740046 : check e605603740046 [[],[]] .chain = true := by decide
def e605603740058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603740058 : Closed e605603740058 ∧ code e605603740058 = 2804626995610 := by decide
theorem cert_e605603740058 : check e605603740058 [[],[]] .chain = true := by decide
def e605603740102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605603740102 : Closed e605603740102 ∧ code e605603740102 = 2804626995654 := by decide
theorem cert_e605603740102 : check e605603740102 [[],[]] .chain = true := by decide
def e605603740130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605603740130 : Closed e605603740130 ∧ code e605603740130 = 2804626995682 := by decide
theorem cert_e605603740130 : check e605603740130 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603740142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 2))))))))
theorem wire_e605603740142 : Closed e605603740142 ∧ code e605603740142 = 2804626995694 := by decide
theorem cert_e605603740142 : check e605603740142 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603741910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e605603741910 : Closed e605603741910 ∧ code e605603741910 = 2804626997462 := by decide
theorem cert_e605603741910 : check e605603741910 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603742006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605603742006 : Closed e605603742006 ∧ code e605603742006 = 2804626997558 := by decide
theorem cert_e605603742006 : check e605603742006 [[],[]] .chain = true := by decide
def e605603742010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605603742010 : Closed e605603742010 ∧ code e605603742010 = 2804626997562 := by decide
theorem cert_e605603742010 : check e605603742010 [[],[]] .chain = true := by decide
def e605603742190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e605603742190 : Closed e605603742190 ∧ code e605603742190 = 2804626997742 := by decide
theorem cert_e605603742190 : check e605603742190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603742198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e605603742198 : Closed e605603742198 ∧ code e605603742198 = 2804626997750 := by decide
theorem cert_e605603742198 : check e605603742198 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603742582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605603742582 : Closed e605603742582 ∧ code e605603742582 = 2804626998134 := by decide
theorem cert_e605603742582 : check e605603742582 [[],[]] .chain = true := by decide
def e605603742646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e605603742646 : Closed e605603742646 ∧ code e605603742646 = 2804626998198 := by decide
theorem cert_e605603742646 : check e605603742646 [[],[]] .chain = true := by decide
def e605603742650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605603742650 : Closed e605603742650 ∧ code e605603742650 = 2804626998202 := by decide
theorem cert_e605603742650 : check e605603742650 [[],[]] .chain = true := by decide
def e605603742678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605603742678 : Closed e605603742678 ∧ code e605603742678 = 2804626998230 := by decide
theorem cert_e605603742678 : check e605603742678 [[],[]] .chain = true := by decide
def e605603742682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605603742682 : Closed e605603742682 ∧ code e605603742682 = 2804626998234 := by decide
theorem cert_e605603742682 : check e605603742682 [[],[]] .chain = true := by decide
def e605603742958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605603742958 : Closed e605603742958 ∧ code e605603742958 = 2804626998510 := by decide
theorem cert_e605603742958 : checkPay e605603742958 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] 0 [] = true := by decide
def e605603742966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605603742966 : Closed e605603742966 ∧ code e605603742966 = 2804626998518 := by decide
theorem cert_e605603742966 : check e605603742966 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[]] .identityHead = true := by decide
def e605603743350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e605603743350 : Closed e605603743350 ∧ code e605603743350 = 2804626998902 := by decide
theorem cert_e605603743350 : check e605603743350 [[],[]] .chain = true := by decide
def e605603743518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e605603743518 : Closed e605603743518 ∧ code e605603743518 = 2804626999070 := by decide
theorem cert_e605603743518 : check e605603743518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e605603743542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605603743542 : Closed e605603743542 ∧ code e605603743542 = 2804626999094 := by decide
theorem cert_e605603743542 : check e605603743542 [[],[]] .chain = true := by decide
def e605603743546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605603743546 : Closed e605603743546 ∧ code e605603743546 = 2804626999098 := by decide
theorem cert_e605603743546 : check e605603743546 [[],[]] .chain = true := by decide
def e605603743630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e605603743630 : Closed e605603743630 ∧ code e605603743630 = 2804626999182 := by decide
theorem cert_e605603743630 : check e605603743630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603744598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605603744598 : Closed e605603744598 ∧ code e605603744598 = 2804627000150 := by decide
theorem cert_e605603744598 : check e605603744598 [[],[]] .chain = true := by decide
def e605603744602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605603744602 : Closed e605603744602 ∧ code e605603744602 = 2804627000154 := by decide
theorem cert_e605603744602 : check e605603744602 [[],[]] .chain = true := by decide
def e605603744618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605603744618 : Closed e605603744618 ∧ code e605603744618 = 2804627000170 := by decide
theorem cert_e605603744618 : check e605603744618 [[],[]] .chain = true := by decide
def e605603744682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605603744682 : Closed e605603744682 ∧ code e605603744682 = 2804627000234 := by decide
theorem cert_e605603744682 : check e605603744682 [[],[]] .chain = true := by decide
def e605603744790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605603744790 : Closed e605603744790 ∧ code e605603744790 = 2804627000342 := by decide
theorem cert_e605603744790 : check e605603744790 [[],[]] .chain = true := by decide
def e605603744886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605603744886 : Closed e605603744886 ∧ code e605603744886 = 2804627000438 := by decide
theorem cert_e605603744886 : check e605603744886 [[],[]] .chain = true := by decide
def e605603744982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605603744982 : Closed e605603744982 ∧ code e605603744982 = 2804627000534 := by decide
theorem cert_e605603744982 : check e605603744982 [[],[]] .chain = true := by decide
def e605603744986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605603744986 : Closed e605603744986 ∧ code e605603744986 = 2804627000538 := by decide
theorem cert_e605603744986 : check e605603744986 [[],[]] .chain = true := by decide
def e605603745002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605603745002 : Closed e605603745002 ∧ code e605603745002 = 2804627000554 := by decide
theorem cert_e605603745002 : check e605603745002 [[],[]] .chain = true := by decide
def e605603745078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605603745078 : Closed e605603745078 ∧ code e605603745078 = 2804627000630 := by decide
theorem cert_e605603745078 : check e605603745078 [[],[]] .chain = true := by decide
def e605603745082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605603745082 : Closed e605603745082 ∧ code e605603745082 = 2804627000634 := by decide
theorem cert_e605603745082 : check e605603745082 [[],[]] .chain = true := by decide
def e605603745154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605603745154 : Closed e605603745154 ∧ code e605603745154 = 2804627000706 := by decide
theorem cert_e605603745154 : check e605603745154 [[],[]] .chain = true := by decide
def e605603745166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605603745166 : Closed e605603745166 ∧ code e605603745166 = 2804627000718 := by decide
theorem cert_e605603745166 : check e605603745166 [[],[]] .chain = true := by decide
def e605603745178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605603745178 : Closed e605603745178 ∧ code e605603745178 = 2804627000730 := by decide
theorem cert_e605603745178 : check e605603745178 [[],[]] .chain = true := by decide
def e605603745290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605603745290 : Closed e605603745290 ∧ code e605603745290 = 2804627000842 := by decide
theorem cert_e605603745290 : check e605603745290 [[],[]] .chain = true := by decide
def e605603745326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605603745326 : Closed e605603745326 ∧ code e605603745326 = 2804627000878 := by decide
theorem cert_e605603745326 : check e605603745326 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e605603745334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605603745334 : Closed e605603745334 ∧ code e605603745334 = 2804627000886 := by decide
theorem cert_e605603745334 : check e605603745334 [[],[]] .chain = true := by decide
def e605603745338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605603745338 : Closed e605603745338 ∧ code e605603745338 = 2804627000890 := by decide
theorem cert_e605603745338 : check e605603745338 [[],[]] .chain = true := by decide
def e605603745386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605603745386 : Closed e605603745386 ∧ code e605603745386 = 2804627000938 := by decide
theorem cert_e605603745386 : check e605603745386 [[],[]] .chain = true := by decide
def e605603745410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605603745410 : Closed e605603745410 ∧ code e605603745410 = 2804627000962 := by decide
theorem cert_e605603745410 : check e605603745410 [[],[]] .chain = true := by decide
def e605603745422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605603745422 : Closed e605603745422 ∧ code e605603745422 = 2804627000974 := by decide
theorem cert_e605603745422 : check e605603745422 [[],[]] .chain = true := by decide
def e605603745434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605603745434 : Closed e605603745434 ∧ code e605603745434 = 2804627000986 := by decide
theorem cert_e605603745434 : check e605603745434 [[],[]] .chain = true := by decide
def e605603745478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605603745478 : Closed e605603745478 ∧ code e605603745478 = 2804627001030 := by decide
theorem cert_e605603745478 : check e605603745478 [[],[]] .chain = true := by decide
def e605603745506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605603745506 : Closed e605603745506 ∧ code e605603745506 = 2804627001058 := by decide
theorem cert_e605603745506 : check e605603745506 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e605603745518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e605603745518 : Closed e605603745518 ∧ code e605603745518 = 2804627001070 := by decide
theorem cert_e605603745518 : check e605603745518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e605603745558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605603745558 : Closed e605603745558 ∧ code e605603745558 = 2804627001110 := by decide
theorem cert_e605603745558 : check e605603745558 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605603745634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605603745634 : Closed e605603745634 ∧ code e605603745634 = 2804627001186 := by decide
theorem cert_e605603745634 : checkPay e605603745634 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[],[]] 0 [[.right,.left],[.right]] = true := by decide
def e605603745646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e605603745646 : Closed e605603745646 ∧ code e605603745646 = 2804627001198 := by decide
theorem cert_e605603745646 : check e605603745646 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603745654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e605603745654 : Closed e605603745654 ∧ code e605603745654 = 2804627001206 := by decide
theorem cert_e605603745654 : check e605603745654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605603746030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605603746030 : Closed e605603746030 ∧ code e605603746030 = 2804627001582 := by decide
theorem cert_e605603746030 : check e605603746030 [[],[]] .chain = true := by decide
def e605603746038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605603746038 : Closed e605603746038 ∧ code e605603746038 = 2804627001590 := by decide
theorem cert_e605603746038 : check e605603746038 [[],[]] .chain = true := by decide
end Blc.Floor41
