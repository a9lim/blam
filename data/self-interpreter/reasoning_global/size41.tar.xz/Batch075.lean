import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605591148266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e605591148266 : Closed e605591148266 ∧ code e605591148266 = 2804614403818 := by decide
theorem cert_e605591148266 : check e605591148266 [[],[]] .smaller = true := by decide
def e605591148458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e605591148458 : Closed e605591148458 ∧ code e605591148458 = 2804614404010 := by decide
theorem cert_e605591148458 : check e605591148458 [[],[]] .smaller = true := by decide
def e605591148766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e605591148766 : Closed e605591148766 ∧ code e605591148766 = 2804614404318 := by decide
theorem cert_e605591148766 : check e605591148766 [[],[]] .smaller = true := by decide
def e605591148782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605591148782 : Closed e605591148782 ∧ code e605591148782 = 2804614404334 := by decide
theorem cert_e605591148782 : check e605591148782 [[],[]] .smaller = true := by decide
def e605591148790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e605591148790 : Closed e605591148790 ∧ code e605591148790 = 2804614404342 := by decide
theorem cert_e605591148790 : check e605591148790 [[],[]] .smaller = true := by decide
def e605591148794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e605591148794 : Closed e605591148794 ∧ code e605591148794 = 2804614404346 := by decide
theorem cert_e605591148794 : check e605591148794 [[],[]] .smaller = true := by decide
def e605591148974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e605591148974 : Closed e605591148974 ∧ code e605591148974 = 2804614404526 := by decide
theorem cert_e605591148974 : check e605591148974 [[],[]] .smaller = true := by decide
def e605591148986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e605591148986 : Closed e605591148986 ∧ code e605591148986 = 2804614404538 := by decide
theorem cert_e605591148986 : check e605591148986 [[],[]] .smaller = true := by decide
def e605591149034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e605591149034 : Closed e605591149034 ∧ code e605591149034 = 2804614404586 := by decide
theorem cert_e605591149034 : check e605591149034 [[],[]] .smaller = true := by decide
def e605591149118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e605591149118 : Closed e605591149118 ∧ code e605591149118 = 2804614404670 := by decide
theorem cert_e605591149118 : check e605591149118 [[],[]] .smaller = true := by decide
def e605591149166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591149166 : Closed e605591149166 ∧ code e605591149166 = 2804614404718 := by decide
theorem cert_e605591149166 : check e605591149166 [[],[]] .smaller = true := by decide
def e605591149178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591149178 : Closed e605591149178 ∧ code e605591149178 = 2804614404730 := by decide
theorem cert_e605591149178 : check e605591149178 [[],[]] .smaller = true := by decide
def e605591149342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605591149342 : Closed e605591149342 ∧ code e605591149342 = 2804614404894 := by decide
theorem cert_e605591149342 : check e605591149342 [[],[]] .smaller = true := by decide
def e605591149454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e605591149454 : Closed e605591149454 ∧ code e605591149454 = 2804614405006 := by decide
theorem cert_e605591149454 : check e605591149454 [[],[]] .smaller = true := by decide
def e605591149466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591149466 : Closed e605591149466 ∧ code e605591149466 = 2804614405018 := by decide
theorem cert_e605591149466 : check e605591149466 [[],[]] .smaller = true := by decide
def e605591149510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e605591149510 : Closed e605591149510 ∧ code e605591149510 = 2804614405062 := by decide
theorem cert_e605591149510 : check e605591149510 [[],[]] .smaller = true := by decide
def e605591149534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3))))))))
theorem wire_e605591149534 : Closed e605591149534 ∧ code e605591149534 = 2804614405086 := by decide
theorem cert_e605591149534 : check e605591149534 [[],[]] .smaller = true := by decide
def e605591149678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e605591149678 : Closed e605591149678 ∧ code e605591149678 = 2804614405230 := by decide
theorem cert_e605591149678 : check e605591149678 [[],[]] .smaller = true := by decide
def e605591149690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605591149690 : Closed e605591149690 ∧ code e605591149690 = 2804614405242 := by decide
theorem cert_e605591149690 : check e605591149690 [[],[]] .smaller = true := by decide
def e605591149854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e605591149854 : Closed e605591149854 ∧ code e605591149854 = 2804614405406 := by decide
theorem cert_e605591149854 : check e605591149854 [[],[]] .smaller = true := by decide
def e605591150022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605591150022 : Closed e605591150022 ∧ code e605591150022 = 2804614405574 := by decide
theorem cert_e605591150022 : check e605591150022 [[],[]] .smaller = true := by decide
def e605591150046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e605591150046 : Closed e605591150046 ∧ code e605591150046 = 2804614405598 := by decide
theorem cert_e605591150046 : check e605591150046 [[],[]] .smaller = true := by decide
def e605591150062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e605591150062 : Closed e605591150062 ∧ code e605591150062 = 2804614405614 := by decide
theorem cert_e605591150062 : check e605591150062 [[],[]] .smaller = true := by decide
def e605591150134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e605591150134 : Closed e605591150134 ∧ code e605591150134 = 2804614405686 := by decide
theorem cert_e605591150134 : check e605591150134 [[],[]] .smaller = true := by decide
def e605591150138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605591150138 : Closed e605591150138 ∧ code e605591150138 = 2804614405690 := by decide
theorem cert_e605591150138 : check e605591150138 [[],[]] .smaller = true := by decide
def e605591150186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e605591150186 : Closed e605591150186 ∧ code e605591150186 = 2804614405738 := by decide
theorem cert_e605591150186 : check e605591150186 [[],[]] .smaller = true := by decide
def e605591150222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e605591150222 : Closed e605591150222 ∧ code e605591150222 = 2804614405774 := by decide
theorem cert_e605591150222 : check e605591150222 [[],[]] .smaller = true := by decide
def e605591150234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591150234 : Closed e605591150234 ∧ code e605591150234 = 2804614405786 := by decide
theorem cert_e605591150234 : check e605591150234 [[],[]] .smaller = true := by decide
def e605591150278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605591150278 : Closed e605591150278 ∧ code e605591150278 = 2804614405830 := by decide
theorem cert_e605591150278 : check e605591150278 [[],[]] .smaller = true := by decide
def e605591150302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e605591150302 : Closed e605591150302 ∧ code e605591150302 = 2804614405854 := by decide
theorem cert_e605591150302 : check e605591150302 [[],[]] .smaller = true := by decide
def e605591150326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e605591150326 : Closed e605591150326 ∧ code e605591150326 = 2804614405878 := by decide
theorem cert_e605591150326 : check e605591150326 [[],[]] .smaller = true := by decide
def e605591150362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e605591150362 : Closed e605591150362 ∧ code e605591150362 = 2804614405914 := by decide
theorem cert_e605591150362 : check e605591150362 [[],[]] .smaller = true := by decide
def e605591150406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e605591150406 : Closed e605591150406 ∧ code e605591150406 = 2804614405958 := by decide
theorem cert_e605591150406 : check e605591150406 [[],[]] .smaller = true := by decide
def e605591150430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3))))))))
theorem wire_e605591150430 : Closed e605591150430 ∧ code e605591150430 = 2804614405982 := by decide
theorem cert_e605591150430 : check e605591150430 [[],[]] .smaller = true := by decide
def e605591150446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e605591150446 : Closed e605591150446 ∧ code e605591150446 = 2804614405998 := by decide
theorem cert_e605591150446 : check e605591150446 [[],[]] .smaller = true := by decide
def e605591150454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e605591150454 : Closed e605591150454 ∧ code e605591150454 = 2804614406006 := by decide
theorem cert_e605591150454 : check e605591150454 [[],[]] .smaller = true := by decide
def e605591150458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0))))))))
theorem wire_e605591150458 : Closed e605591150458 ∧ code e605591150458 = 2804614406010 := by decide
theorem cert_e605591150458 : check e605591150458 [[],[]] .smaller = true := by decide
def e605591151070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605591151070 : Closed e605591151070 ∧ code e605591151070 = 2804614406622 := by decide
theorem cert_e605591151070 : check e605591151070 [[],[]] .smaller = true := by decide
def e605591151094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605591151094 : Closed e605591151094 ∧ code e605591151094 = 2804614406646 := by decide
theorem cert_e605591151094 : check e605591151094 [[],[]] .smaller = true := by decide
def e605591152046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605591152046 : Closed e605591152046 ∧ code e605591152046 = 2804614407598 := by decide
theorem cert_e605591152046 : check e605591152046 [[],[]] .smaller = true := by decide
def e605591152058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605591152058 : Closed e605591152058 ∧ code e605591152058 = 2804614407610 := by decide
theorem cert_e605591152058 : check e605591152058 [[],[]] .smaller = true := by decide
def e605591152106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605591152106 : Closed e605591152106 ∧ code e605591152106 = 2804614407658 := by decide
theorem cert_e605591152106 : check e605591152106 [[],[]] .smaller = true := by decide
def e605591152190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e605591152190 : Closed e605591152190 ∧ code e605591152190 = 2804614407742 := by decide
theorem cert_e605591152190 : check e605591152190 [[],[]] .smaller = true := by decide
def e605591152238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591152238 : Closed e605591152238 ∧ code e605591152238 = 2804614407790 := by decide
theorem cert_e605591152238 : check e605591152238 [[],[]] .smaller = true := by decide
def e605591152250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591152250 : Closed e605591152250 ∧ code e605591152250 = 2804614407802 := by decide
theorem cert_e605591152250 : check e605591152250 [[],[]] .smaller = true := by decide
def e605591152414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605591152414 : Closed e605591152414 ∧ code e605591152414 = 2804614407966 := by decide
theorem cert_e605591152414 : check e605591152414 [[],[]] .smaller = true := by decide
def e605591152526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605591152526 : Closed e605591152526 ∧ code e605591152526 = 2804614408078 := by decide
theorem cert_e605591152526 : check e605591152526 [[],[]] .smaller = true := by decide
def e605591152538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591152538 : Closed e605591152538 ∧ code e605591152538 = 2804614408090 := by decide
theorem cert_e605591152538 : check e605591152538 [[],[]] .smaller = true := by decide
def e605591152582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e605591152582 : Closed e605591152582 ∧ code e605591152582 = 2804614408134 := by decide
theorem cert_e605591152582 : check e605591152582 [[],[]] .smaller = true := by decide
def e605591152606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3)))))))))
theorem wire_e605591152606 : Closed e605591152606 ∧ code e605591152606 = 2804614408158 := by decide
theorem cert_e605591152606 : check e605591152606 [[],[]] .smaller = true := by decide
def e605591155486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605591155486 : Closed e605591155486 ∧ code e605591155486 = 2804614411038 := by decide
theorem cert_e605591155486 : check e605591155486 [[],[]] .smaller = true := by decide
def e605591155654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605591155654 : Closed e605591155654 ∧ code e605591155654 = 2804614411206 := by decide
theorem cert_e605591155654 : check e605591155654 [[],[]] .smaller = true := by decide
def e605591155678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605591155678 : Closed e605591155678 ∧ code e605591155678 = 2804614411230 := by decide
theorem cert_e605591155678 : check e605591155678 [[],[]] .smaller = true := by decide
def e605591155694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605591155694 : Closed e605591155694 ∧ code e605591155694 = 2804614411246 := by decide
theorem cert_e605591155694 : check e605591155694 [[],[]] .smaller = true := by decide
def e605591156854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605591156854 : Closed e605591156854 ∧ code e605591156854 = 2804614412406 := by decide
theorem cert_e605591156854 : check e605591156854 [[],[]] .smaller = true := by decide
def e605591157098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605591157098 : Closed e605591157098 ∧ code e605591157098 = 2804614412650 := by decide
theorem cert_e605591157098 : check e605591157098 [[],[]] .smaller = true := by decide
def e605591157134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605591157134 : Closed e605591157134 ∧ code e605591157134 = 2804614412686 := by decide
theorem cert_e605591157134 : check e605591157134 [[],[]] .smaller = true := by decide
def e605591157146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591157146 : Closed e605591157146 ∧ code e605591157146 = 2804614412698 := by decide
theorem cert_e605591157146 : check e605591157146 [[],[]] .smaller = true := by decide
def e605591157190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605591157190 : Closed e605591157190 ∧ code e605591157190 = 2804614412742 := by decide
theorem cert_e605591157190 : check e605591157190 [[],[]] .smaller = true := by decide
def e605591157214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605591157214 : Closed e605591157214 ∧ code e605591157214 = 2804614412766 := by decide
theorem cert_e605591157214 : check e605591157214 [[],[]] .smaller = true := by decide
def e605591157238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605591157238 : Closed e605591157238 ∧ code e605591157238 = 2804614412790 := by decide
theorem cert_e605591157238 : check e605591157238 [[],[]] .smaller = true := by decide
def e605591157958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605591157958 : Closed e605591157958 ∧ code e605591157958 = 2804614413510 := by decide
theorem cert_e605591157958 : check e605591157958 [[],[]] .smaller = true := by decide
def e605591157982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591157982 : Closed e605591157982 ∧ code e605591157982 = 2804614413534 := by decide
theorem cert_e605591157982 : check e605591157982 [[],[]] .smaller = true := by decide
def e605591157998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605591157998 : Closed e605591157998 ∧ code e605591157998 = 2804614413550 := by decide
theorem cert_e605591157998 : check e605591157998 [[],[]] .smaller = true := by decide
def e605591158006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605591158006 : Closed e605591158006 ∧ code e605591158006 = 2804614413558 := by decide
theorem cert_e605591158006 : check e605591158006 [[],[]] .smaller = true := by decide
def e605591158010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591158010 : Closed e605591158010 ∧ code e605591158010 = 2804614413562 := by decide
theorem cert_e605591158010 : check e605591158010 [[],[]] .smaller = true := by decide
def e605591159734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e605591159734 : Closed e605591159734 ∧ code e605591159734 = 2804614415286 := by decide
theorem cert_e605591159734 : check e605591159734 [[],[]] .smaller = true := by decide
def e605591159738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e605591159738 : Closed e605591159738 ∧ code e605591159738 = 2804614415290 := by decide
theorem cert_e605591159738 : check e605591159738 [[],[]] .smaller = true := by decide
def e605591159770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e605591159770 : Closed e605591159770 ∧ code e605591159770 = 2804614415322 := by decide
theorem cert_e605591159770 : check e605591159770 [[],[]] .smaller = true := by decide
def e605591160438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e605591160438 : Closed e605591160438 ∧ code e605591160438 = 2804614415990 := by decide
theorem cert_e605591160438 : check e605591160438 [[],[]] .smaller = true := by decide
def e605591160630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591160630 : Closed e605591160630 ∧ code e605591160630 = 2804614416182 := by decide
theorem cert_e605591160630 : check e605591160630 [[],[]] .smaller = true := by decide
def e605591160634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591160634 : Closed e605591160634 ∧ code e605591160634 = 2804614416186 := by decide
theorem cert_e605591160634 : check e605591160634 [[],[]] .smaller = true := by decide
def e605591161686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e605591161686 : Closed e605591161686 ∧ code e605591161686 = 2804614417238 := by decide
theorem cert_e605591161686 : check e605591161686 [[],[]] .smaller = true := by decide
def e605591161690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e605591161690 : Closed e605591161690 ∧ code e605591161690 = 2804614417242 := by decide
theorem cert_e605591161690 : check e605591161690 [[],[]] .smaller = true := by decide
def e605591161706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e605591161706 : Closed e605591161706 ∧ code e605591161706 = 2804614417258 := by decide
theorem cert_e605591161706 : check e605591161706 [[],[]] .smaller = true := by decide
def e605591161770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e605591161770 : Closed e605591161770 ∧ code e605591161770 = 2804614417322 := by decide
theorem cert_e605591161770 : check e605591161770 [[],[]] .smaller = true := by decide
def e605591161974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e605591161974 : Closed e605591161974 ∧ code e605591161974 = 2804614417526 := by decide
theorem cert_e605591161974 : check e605591161974 [[],[]] .smaller = true := by decide
def e605591162070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e605591162070 : Closed e605591162070 ∧ code e605591162070 = 2804614417622 := by decide
theorem cert_e605591162070 : check e605591162070 [[],[]] .smaller = true := by decide
def e605591162074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e605591162074 : Closed e605591162074 ∧ code e605591162074 = 2804614417626 := by decide
theorem cert_e605591162074 : check e605591162074 [[],[]] .smaller = true := by decide
def e605591162090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e605591162090 : Closed e605591162090 ∧ code e605591162090 = 2804614417642 := by decide
theorem cert_e605591162090 : check e605591162090 [[],[]] .smaller = true := by decide
def e605591162166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591162166 : Closed e605591162166 ∧ code e605591162166 = 2804614417718 := by decide
theorem cert_e605591162166 : check e605591162166 [[],[]] .smaller = true := by decide
def e605591162170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591162170 : Closed e605591162170 ∧ code e605591162170 = 2804614417722 := by decide
theorem cert_e605591162170 : check e605591162170 [[],[]] .smaller = true := by decide
def e605591162254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e605591162254 : Closed e605591162254 ∧ code e605591162254 = 2804614417806 := by decide
theorem cert_e605591162254 : check e605591162254 [[],[]] .smaller = true := by decide
def e605591162266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591162266 : Closed e605591162266 ∧ code e605591162266 = 2804614417818 := by decide
theorem cert_e605591162266 : check e605591162266 [[],[]] .smaller = true := by decide
def e605591162334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605591162334 : Closed e605591162334 ∧ code e605591162334 = 2804614417886 := by decide
theorem cert_e605591162334 : check e605591162334 [[],[]] .smaller = true := by decide
def e605591162350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605591162350 : Closed e605591162350 ∧ code e605591162350 = 2804614417902 := by decide
theorem cert_e605591162350 : check e605591162350 [[],[]] .smaller = true := by decide
def e605591162422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e605591162422 : Closed e605591162422 ∧ code e605591162422 = 2804614417974 := by decide
theorem cert_e605591162422 : check e605591162422 [[],[]] .smaller = true := by decide
def e605591162426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605591162426 : Closed e605591162426 ∧ code e605591162426 = 2804614417978 := by decide
theorem cert_e605591162426 : check e605591162426 [[],[]] .smaller = true := by decide
def e605591162474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e605591162474 : Closed e605591162474 ∧ code e605591162474 = 2804614418026 := by decide
theorem cert_e605591162474 : check e605591162474 [[],[]] .smaller = true := by decide
def e605591162510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e605591162510 : Closed e605591162510 ∧ code e605591162510 = 2804614418062 := by decide
theorem cert_e605591162510 : check e605591162510 [[],[]] .smaller = true := by decide
def e605591162522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591162522 : Closed e605591162522 ∧ code e605591162522 = 2804614418074 := by decide
theorem cert_e605591162522 : check e605591162522 [[],[]] .smaller = true := by decide
def e605591162566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605591162566 : Closed e605591162566 ∧ code e605591162566 = 2804614418118 := by decide
theorem cert_e605591162566 : check e605591162566 [[],[]] .smaller = true := by decide
def e605591162590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605591162590 : Closed e605591162590 ∧ code e605591162590 = 2804614418142 := by decide
theorem cert_e605591162590 : check e605591162590 [[],[]] .smaller = true := by decide
def e605591162614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605591162614 : Closed e605591162614 ∧ code e605591162614 = 2804614418166 := by decide
theorem cert_e605591162614 : check e605591162614 [[],[]] .smaller = true := by decide
def e605591162718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605591162718 : Closed e605591162718 ∧ code e605591162718 = 2804614418270 := by decide
theorem cert_e605591162718 : check e605591162718 [[],[]] .smaller = true := by decide
def e605591162746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605591162746 : Closed e605591162746 ∧ code e605591162746 = 2804614418298 := by decide
theorem cert_e605591162746 : check e605591162746 [[],[]] .smaller = true := by decide
def e605591162798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605591162798 : Closed e605591162798 ∧ code e605591162798 = 2804614418350 := by decide
theorem cert_e605591162798 : check e605591162798 [[],[]] .smaller = true := by decide
def e605591162806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605591162806 : Closed e605591162806 ∧ code e605591162806 = 2804614418358 := by decide
theorem cert_e605591162806 : check e605591162806 [[],[]] .smaller = true := by decide
def e605591162810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605591162810 : Closed e605591162810 ∧ code e605591162810 = 2804614418362 := by decide
theorem cert_e605591162810 : check e605591162810 [[],[]] .smaller = true := by decide
def e605591163118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605591163118 : Closed e605591163118 ∧ code e605591163118 = 2804614418670 := by decide
theorem cert_e605591163118 : check e605591163118 [[],[]] .smaller = true := by decide
def e605591163126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605591163126 : Closed e605591163126 ∧ code e605591163126 = 2804614418678 := by decide
theorem cert_e605591163126 : check e605591163126 [[],[]] .smaller = true := by decide
def e605591163606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605591163606 : Closed e605591163606 ∧ code e605591163606 = 2804614419158 := by decide
theorem cert_e605591163606 : check e605591163606 [[],[]] .smaller = true := by decide
def e605591163610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605591163610 : Closed e605591163610 ∧ code e605591163610 = 2804614419162 := by decide
theorem cert_e605591163610 : check e605591163610 [[],[]] .smaller = true := by decide
def e605591163626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605591163626 : Closed e605591163626 ∧ code e605591163626 = 2804614419178 := by decide
theorem cert_e605591163626 : check e605591163626 [[],[]] .smaller = true := by decide
def e605591163702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591163702 : Closed e605591163702 ∧ code e605591163702 = 2804614419254 := by decide
theorem cert_e605591163702 : check e605591163702 [[],[]] .smaller = true := by decide
def e605591163706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591163706 : Closed e605591163706 ∧ code e605591163706 = 2804614419258 := by decide
theorem cert_e605591163706 : check e605591163706 [[],[]] .smaller = true := by decide
def e605591163790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605591163790 : Closed e605591163790 ∧ code e605591163790 = 2804614419342 := by decide
theorem cert_e605591163790 : check e605591163790 [[],[]] .smaller = true := by decide
def e605591163802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591163802 : Closed e605591163802 ∧ code e605591163802 = 2804614419354 := by decide
theorem cert_e605591163802 : check e605591163802 [[],[]] .smaller = true := by decide
def e605591163870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605591163870 : Closed e605591163870 ∧ code e605591163870 = 2804614419422 := by decide
theorem cert_e605591163870 : check e605591163870 [[],[]] .smaller = true := by decide
def e605591163886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605591163886 : Closed e605591163886 ∧ code e605591163886 = 2804614419438 := by decide
theorem cert_e605591163886 : check e605591163886 [[],[]] .smaller = true := by decide
def e605591165046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605591165046 : Closed e605591165046 ∧ code e605591165046 = 2804614420598 := by decide
theorem cert_e605591165046 : check e605591165046 [[],[]] .smaller = true := by decide
def e605591165290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605591165290 : Closed e605591165290 ∧ code e605591165290 = 2804614420842 := by decide
theorem cert_e605591165290 : check e605591165290 [[],[]] .smaller = true := by decide
def e605591165326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605591165326 : Closed e605591165326 ∧ code e605591165326 = 2804614420878 := by decide
theorem cert_e605591165326 : check e605591165326 [[],[]] .smaller = true := by decide
def e605591165338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591165338 : Closed e605591165338 ∧ code e605591165338 = 2804614420890 := by decide
theorem cert_e605591165338 : check e605591165338 [[],[]] .smaller = true := by decide
def e605591165382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605591165382 : Closed e605591165382 ∧ code e605591165382 = 2804614420934 := by decide
theorem cert_e605591165382 : check e605591165382 [[],[]] .smaller = true := by decide
def e605591165406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605591165406 : Closed e605591165406 ∧ code e605591165406 = 2804614420958 := by decide
theorem cert_e605591165406 : check e605591165406 [[],[]] .smaller = true := by decide
def e605591165430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605591165430 : Closed e605591165430 ∧ code e605591165430 = 2804614420982 := by decide
theorem cert_e605591165430 : check e605591165430 [[],[]] .smaller = true := by decide
def e605591166174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591166174 : Closed e605591166174 ∧ code e605591166174 = 2804614421726 := by decide
theorem cert_e605591166174 : check e605591166174 [[],[]] .smaller = true := by decide
def e605591166202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591166202 : Closed e605591166202 ∧ code e605591166202 = 2804614421754 := by decide
theorem cert_e605591166202 : check e605591166202 [[],[]] .smaller = true := by decide
def e605591166574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591166574 : Closed e605591166574 ∧ code e605591166574 = 2804614422126 := by decide
theorem cert_e605591166574 : check e605591166574 [[],[]] .smaller = true := by decide
def e605591166582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605591166582 : Closed e605591166582 ∧ code e605591166582 = 2804614422134 := by decide
theorem cert_e605591166582 : check e605591166582 [[],[]] .smaller = true := by decide
def e605591166586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591166586 : Closed e605591166586 ∧ code e605591166586 = 2804614422138 := by decide
theorem cert_e605591166586 : check e605591166586 [[],[]] .smaller = true := by decide
def e605591167798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591167798 : Closed e605591167798 ∧ code e605591167798 = 2804614423350 := by decide
theorem cert_e605591167798 : check e605591167798 [[],[]] .smaller = true := by decide
def e605591167802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591167802 : Closed e605591167802 ∧ code e605591167802 = 2804614423354 := by decide
theorem cert_e605591167802 : check e605591167802 [[],[]] .smaller = true := by decide
def e605591167898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591167898 : Closed e605591167898 ∧ code e605591167898 = 2804614423450 := by decide
theorem cert_e605591167898 : check e605591167898 [[],[]] .smaller = true := by decide
def e605591168566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e605591168566 : Closed e605591168566 ∧ code e605591168566 = 2804614424118 := by decide
theorem cert_e605591168566 : check e605591168566 [[],[]] .smaller = true := by decide
def e605591168570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605591168570 : Closed e605591168570 ∧ code e605591168570 = 2804614424122 := by decide
theorem cert_e605591168570 : check e605591168570 [[],[]] .smaller = true := by decide
def e605591168654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e605591168654 : Closed e605591168654 ∧ code e605591168654 = 2804614424206 := by decide
theorem cert_e605591168654 : check e605591168654 [[],[]] .smaller = true := by decide
def e605591168702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e605591168702 : Closed e605591168702 ∧ code e605591168702 = 2804614424254 := by decide
theorem cert_e605591168702 : check e605591168702 [[],[]] .three = true := by decide
def e605591168710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605591168710 : Closed e605591168710 ∧ code e605591168710 = 2804614424262 := by decide
theorem cert_e605591168710 : check e605591168710 [[],[]] .smaller = true := by decide
def e605591168734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605591168734 : Closed e605591168734 ∧ code e605591168734 = 2804614424286 := by decide
theorem cert_e605591168734 : check e605591168734 [[],[]] .smaller = true := by decide
def e605591168750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605591168750 : Closed e605591168750 ∧ code e605591168750 = 2804614424302 := by decide
theorem cert_e605591168750 : check e605591168750 [[],[]] .smaller = true := by decide
def e605591168758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605591168758 : Closed e605591168758 ∧ code e605591168758 = 2804614424310 := by decide
theorem cert_e605591168758 : check e605591168758 [[],[]] .smaller = true := by decide
def e605591168762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e605591168762 : Closed e605591168762 ∧ code e605591168762 = 2804614424314 := by decide
theorem cert_e605591168762 : check e605591168762 [[],[]] .three = true := by decide
def e605591168794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e605591168794 : Closed e605591168794 ∧ code e605591168794 = 2804614424346 := by decide
theorem cert_e605591168794 : check e605591168794 [[],[]] .smaller = true := by decide
def e605591168838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e605591168838 : Closed e605591168838 ∧ code e605591168838 = 2804614424390 := by decide
theorem cert_e605591168838 : check e605591168838 [[],[]] .smaller = true := by decide
def e605591168862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605591168862 : Closed e605591168862 ∧ code e605591168862 = 2804614424414 := by decide
theorem cert_e605591168862 : check e605591168862 [[],[]] .smaller = true := by decide
def e605591168878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605591168878 : Closed e605591168878 ∧ code e605591168878 = 2804614424430 := by decide
theorem cert_e605591168878 : check e605591168878 [[],[]] .smaller = true := by decide
def e605591168886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605591168886 : Closed e605591168886 ∧ code e605591168886 = 2804614424438 := by decide
theorem cert_e605591168886 : check e605591168886 [[],[]] .smaller = true := by decide
def e605591168890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605591168890 : Closed e605591168890 ∧ code e605591168890 = 2804614424442 := by decide
theorem cert_e605591168890 : check e605591168890 [[],[]] .smaller = true := by decide
def e605591168942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605591168942 : Closed e605591168942 ∧ code e605591168942 = 2804614424494 := by decide
theorem cert_e605591168942 : check e605591168942 [[],[]] .smaller = true := by decide
def e605591168950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605591168950 : Closed e605591168950 ∧ code e605591168950 = 2804614424502 := by decide
theorem cert_e605591168950 : check e605591168950 [[],[]] .smaller = true := by decide
def e605591168954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605591168954 : Closed e605591168954 ∧ code e605591168954 = 2804614424506 := by decide
theorem cert_e605591168954 : check e605591168954 [[],[]] .smaller = true := by decide
def e605591168982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605591168982 : Closed e605591168982 ∧ code e605591168982 = 2804614424534 := by decide
theorem cert_e605591168982 : check e605591168982 [[],[]] .smaller = true := by decide
def e605591168986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605591168986 : Closed e605591168986 ∧ code e605591168986 = 2804614424538 := by decide
theorem cert_e605591168986 : check e605591168986 [[],[]] .smaller = true := by decide
def e605591169002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e605591169002 : Closed e605591169002 ∧ code e605591169002 = 2804614424554 := by decide
theorem cert_e605591169002 : check e605591169002 [[],[]] .three = true := by decide
def e605591169422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605591169422 : Closed e605591169422 ∧ code e605591169422 = 2804614424974 := by decide
theorem cert_e605591169422 : check e605591169422 [[],[]] .smaller = true := by decide
def e605591169470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e605591169470 : Closed e605591169470 ∧ code e605591169470 = 2804614425022 := by decide
theorem cert_e605591169470 : check e605591169470 [[],[]] .three = true := by decide
def e605591169478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605591169478 : Closed e605591169478 ∧ code e605591169478 = 2804614425030 := by decide
theorem cert_e605591169478 : check e605591169478 [[],[]] .smaller = true := by decide
def e605591169502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605591169502 : Closed e605591169502 ∧ code e605591169502 = 2804614425054 := by decide
theorem cert_e605591169502 : check e605591169502 [[],[]] .smaller = true := by decide
def e605591169518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605591169518 : Closed e605591169518 ∧ code e605591169518 = 2804614425070 := by decide
theorem cert_e605591169518 : check e605591169518 [[],[]] .smaller = true := by decide
def e605591169526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605591169526 : Closed e605591169526 ∧ code e605591169526 = 2804614425078 := by decide
theorem cert_e605591169526 : check e605591169526 [[],[]] .smaller = true := by decide
def e605591169530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e605591169530 : Closed e605591169530 ∧ code e605591169530 = 2804614425082 := by decide
theorem cert_e605591169530 : check e605591169530 [[],[]] .three = true := by decide
def e605591170246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605591170246 : Closed e605591170246 ∧ code e605591170246 = 2804614425798 := by decide
theorem cert_e605591170246 : check e605591170246 [[],[]] .smaller = true := by decide
def e605591170270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591170270 : Closed e605591170270 ∧ code e605591170270 = 2804614425822 := by decide
theorem cert_e605591170270 : check e605591170270 [[],[]] .smaller = true := by decide
def e605591170286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605591170286 : Closed e605591170286 ∧ code e605591170286 = 2804614425838 := by decide
theorem cert_e605591170286 : check e605591170286 [[],[]] .smaller = true := by decide
def e605591170294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605591170294 : Closed e605591170294 ∧ code e605591170294 = 2804614425846 := by decide
theorem cert_e605591170294 : check e605591170294 [[],[]] .smaller = true := by decide
def e605591170298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591170298 : Closed e605591170298 ∧ code e605591170298 = 2804614425850 := by decide
theorem cert_e605591170298 : check e605591170298 [[],[]] .smaller = true := by decide
def e605591170670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591170670 : Closed e605591170670 ∧ code e605591170670 = 2804614426222 := by decide
theorem cert_e605591170670 : check e605591170670 [[],[]] .smaller = true := by decide
def e605591170678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605591170678 : Closed e605591170678 ∧ code e605591170678 = 2804614426230 := by decide
theorem cert_e605591170678 : check e605591170678 [[],[]] .smaller = true := by decide
end Blc.Floor41
