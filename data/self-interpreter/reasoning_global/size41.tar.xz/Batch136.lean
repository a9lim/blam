import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605644413726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605644413726 : Closed e605644413726 ∧ code e605644413726 = 2804667669278 := by decide
theorem cert_e605644413726 : check e605644413726 [[],[]] .sourceHead = true := by decide
def e605644413838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605644413838 : Closed e605644413838 ∧ code e605644413838 = 2804667669390 := by decide
theorem cert_e605644413838 : check e605644413838 [[],[]] .sourceHead = true := by decide
def e605644414062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605644414062 : Closed e605644414062 ∧ code e605644414062 = 2804667669614 := by decide
theorem cert_e605644414062 : check e605644414062 [[],[]] .sourceHead = true := by decide
def e605644414074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605644414074 : Closed e605644414074 ∧ code e605644414074 = 2804667669626 := by decide
theorem cert_e605644414074 : check e605644414074 [[],[]] .sourceHead = true := by decide
def e605644414238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605644414238 : Closed e605644414238 ∧ code e605644414238 = 2804667669790 := by decide
theorem cert_e605644414238 : check e605644414238 [[],[]] .sourceHead = true := by decide
def e605644414406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605644414406 : Closed e605644414406 ∧ code e605644414406 = 2804667669958 := by decide
theorem cert_e605644414406 : check e605644414406 [[],[]] .sourceHead = true := by decide
def e605644414518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605644414518 : Closed e605644414518 ∧ code e605644414518 = 2804667670070 := by decide
theorem cert_e605644414518 : check e605644414518 [[],[]] .sourceHead = true := by decide
def e605644414522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605644414522 : Closed e605644414522 ∧ code e605644414522 = 2804667670074 := by decide
theorem cert_e605644414522 : check e605644414522 [[],[]] .sourceHead = true := by decide
def e605644414606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605644414606 : Closed e605644414606 ∧ code e605644414606 = 2804667670158 := by decide
theorem cert_e605644414606 : check e605644414606 [[],[]] .sourceHead = true := by decide
def e605644414662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605644414662 : Closed e605644414662 ∧ code e605644414662 = 2804667670214 := by decide
theorem cert_e605644414662 : check e605644414662 [[],[]] .sourceHead = true := by decide
def e605644416798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605644416798 : Closed e605644416798 ∧ code e605644416798 = 2804667672350 := by decide
theorem cert_e605644416798 : check e605644416798 [[],[]] .sourceHead = true := by decide
def e605644416910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605644416910 : Closed e605644416910 ∧ code e605644416910 = 2804667672462 := by decide
theorem cert_e605644416910 : check e605644416910 [[],[]] .sourceHead = true := by decide
def e605644419870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605644419870 : Closed e605644419870 ∧ code e605644419870 = 2804667675422 := by decide
theorem cert_e605644419870 : check e605644419870 [[],[]] .sourceHead = true := by decide
def e605644420038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605644420038 : Closed e605644420038 ∧ code e605644420038 = 2804667675590 := by decide
theorem cert_e605644420038 : check e605644420038 [[],[]] .sourceHead = true := by decide
def e605644421518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605644421518 : Closed e605644421518 ∧ code e605644421518 = 2804667677070 := by decide
theorem cert_e605644421518 : check e605644421518 [[],[]] .sourceHead = true := by decide
def e605644421574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605644421574 : Closed e605644421574 ∧ code e605644421574 = 2804667677126 := by decide
theorem cert_e605644421574 : check e605644421574 [[],[]] .sourceHead = true := by decide
def e605649132478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e605649132478 : Closed e605649132478 ∧ code e605649132478 = 2804672388030 := by decide
theorem cert_e605649132478 : check e605649132478 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649132526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e605649132526 : Closed e605649132526 ∧ code e605649132526 = 2804672388078 := by decide
theorem cert_e605649132526 : check e605649132526 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649133246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e605649133246 : Closed e605649133246 ∧ code e605649133246 = 2804672388798 := by decide
theorem cert_e605649133246 : check e605649133246 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649133306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e605649133306 : Closed e605649133306 ∧ code e605649133306 = 2804672388858 := by decide
private def t_e605649133306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem cert_e605649133306 : ¬ IsSelfInterpreter e605649133306 :=
  wSource (t := t_e605649133306) (replay_sound (ps := []) (t := e605649133306) (by decide)) (by decide)
def e605649133486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e605649133486 : Closed e605649133486 ∧ code e605649133486 = 2804672389038 := by decide
theorem cert_e605649133486 : check e605649133486 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649133498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e605649133498 : Closed e605649133498 ∧ code e605649133498 = 2804672389050 := by decide
private def t_e605649133498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem cert_e605649133498 : ¬ IsSelfInterpreter e605649133498 :=
  wSource (t := t_e605649133498) (replay_sound (ps := []) (t := e605649133498) (by decide)) (by decide)
def e605649135550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e605649135550 : Closed e605649135550 ∧ code e605649135550 = 2804672391102 := by decide
theorem cert_e605649135550 : check e605649135550 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649135598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e605649135598 : Closed e605649135598 ∧ code e605649135598 = 2804672391150 := by decide
theorem cert_e605649135598 : check e605649135598 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649140158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e605649140158 : Closed e605649140158 ∧ code e605649140158 = 2804672395710 := by decide
theorem cert_e605649140158 : check e605649140158 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649140218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e605649140218 : Closed e605649140218 ∧ code e605649140218 = 2804672395770 := by decide
theorem cert_e605649140218 : check e605649140218 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649141358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e605649141358 : Closed e605649141358 ∧ code e605649141358 = 2804672396910 := by decide
theorem cert_e605649141358 : check e605649141358 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649141370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e605649141370 : Closed e605649141370 ∧ code e605649141370 = 2804672396922 := by decide
theorem cert_e605649141370 : check e605649141370 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649197790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605649197790 : Closed e605649197790 ∧ code e605649197790 = 2804672453342 := by decide
theorem cert_e605649197790 : check e605649197790 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649197814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605649197814 : Closed e605649197814 ∧ code e605649197814 = 2804672453366 := by decide
theorem cert_e605649197814 : check e605649197814 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649197918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605649197918 : Closed e605649197918 ∧ code e605649197918 = 2804672453470 := by decide
theorem cert_e605649197918 : check e605649197918 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649197934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605649197934 : Closed e605649197934 ∧ code e605649197934 = 2804672453486 := by decide
theorem cert_e605649197934 : check e605649197934 [[],[],[.under]] .width = true := by decide
def e605649197942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605649197942 : Closed e605649197942 ∧ code e605649197942 = 2804672453494 := by decide
theorem cert_e605649197942 : check e605649197942 [[],[],[.under]] .width = true := by decide
def e605649197946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605649197946 : Closed e605649197946 ∧ code e605649197946 = 2804672453498 := by decide
theorem cert_e605649197946 : check e605649197946 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605649198006 : Closed e605649198006 ∧ code e605649198006 = 2804672453558 := by decide
theorem cert_e605649198006 : check e605649198006 [[],[],[.under]] .width = true := by decide
def e605649198038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605649198038 : Closed e605649198038 ∧ code e605649198038 = 2804672453590 := by decide
theorem cert_e605649198038 : check e605649198038 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605649198042 : Closed e605649198042 ∧ code e605649198042 = 2804672453594 := by decide
theorem cert_e605649198042 : check e605649198042 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605649198430 : Closed e605649198430 ∧ code e605649198430 = 2804672453982 := by decide
theorem cert_e605649198430 : check e605649198430 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605649198446 : Closed e605649198446 ∧ code e605649198446 = 2804672453998 := by decide
theorem cert_e605649198446 : check e605649198446 [[],[],[.under]] .width = true := by decide
def e605649198454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605649198454 : Closed e605649198454 ∧ code e605649198454 = 2804672454006 := by decide
theorem cert_e605649198454 : check e605649198454 [[],[],[.under]] .width = true := by decide
def e605649198458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605649198458 : Closed e605649198458 ∧ code e605649198458 = 2804672454010 := by decide
theorem cert_e605649198458 : check e605649198458 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605649198510 : Closed e605649198510 ∧ code e605649198510 = 2804672454062 := by decide
private def t_e605649198510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem cert_e605649198510 : ¬ IsSelfInterpreter e605649198510 :=
  wSource (t := t_e605649198510) (replay_sound (ps := []) (t := e605649198510) (by decide)) (by decide)
def e605649198522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605649198522 : Closed e605649198522 ∧ code e605649198522 = 2804672454074 := by decide
private def t_e605649198522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem cert_e605649198522 : ¬ IsSelfInterpreter e605649198522 :=
  wSource (t := t_e605649198522) (replay_sound (ps := []) (t := e605649198522) (by decide)) (by decide)
def e605649198550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605649198550 : Closed e605649198550 ∧ code e605649198550 = 2804672454102 := by decide
theorem cert_e605649198550 : check e605649198550 [[],[],[.under]] .width = true := by decide
def e605649198554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605649198554 : Closed e605649198554 ∧ code e605649198554 = 2804672454106 := by decide
theorem cert_e605649198554 : check e605649198554 [[],[],[.under]] .width = true := by decide
def e605649198570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605649198570 : Closed e605649198570 ∧ code e605649198570 = 2804672454122 := by decide
private def t_e605649198570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem cert_e605649198570 : ¬ IsSelfInterpreter e605649198570 :=
  wSource (t := t_e605649198570) (replay_sound (ps := []) (t := e605649198570) (by decide)) (by decide)
def e605649198774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605649198774 : Closed e605649198774 ∧ code e605649198774 = 2804672454326 := by decide
theorem cert_e605649198774 : check e605649198774 [[],[],[.under]] .width = true := by decide
def e605649198806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605649198806 : Closed e605649198806 ∧ code e605649198806 = 2804672454358 := by decide
theorem cert_e605649198806 : check e605649198806 [[],[],[.under]] .width = true := by decide
def e605649198810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605649198810 : Closed e605649198810 ∧ code e605649198810 = 2804672454362 := by decide
theorem cert_e605649198810 : check e605649198810 [[],[],[.under]] .width = true := by decide
def e605649198934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605649198934 : Closed e605649198934 ∧ code e605649198934 = 2804672454486 := by decide
theorem cert_e605649198934 : check e605649198934 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605649198938 : Closed e605649198938 ∧ code e605649198938 = 2804672454490 := by decide
theorem cert_e605649198938 : check e605649198938 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649198954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605649198954 : Closed e605649198954 ∧ code e605649198954 = 2804672454506 := by decide
private def t_e605649198954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem cert_e605649198954 : ¬ IsSelfInterpreter e605649198954 :=
  wSource (t := t_e605649198954) (replay_sound (ps := []) (t := e605649198954) (by decide)) (by decide)
def e605649200094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e605649200094 : Closed e605649200094 ∧ code e605649200094 = 2804672455646 := by decide
theorem cert_e605649200094 : check e605649200094 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649200110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e605649200110 : Closed e605649200110 ∧ code e605649200110 = 2804672455662 := by decide
theorem cert_e605649200110 : check e605649200110 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649200862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605649200862 : Closed e605649200862 ∧ code e605649200862 = 2804672456414 := by decide
theorem cert_e605649200862 : check e605649200862 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649200886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605649200886 : Closed e605649200886 ∧ code e605649200886 = 2804672456438 := by decide
theorem cert_e605649200886 : check e605649200886 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649200990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605649200990 : Closed e605649200990 ∧ code e605649200990 = 2804672456542 := by decide
theorem cert_e605649200990 : check e605649200990 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649201006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605649201006 : Closed e605649201006 ∧ code e605649201006 = 2804672456558 := by decide
theorem cert_e605649201006 : check e605649201006 [[],[],[.under]] .width = true := by decide
def e605649201014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605649201014 : Closed e605649201014 ∧ code e605649201014 = 2804672456566 := by decide
theorem cert_e605649201014 : check e605649201014 [[],[],[.under]] .width = true := by decide
def e605649201018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605649201018 : Closed e605649201018 ∧ code e605649201018 = 2804672456570 := by decide
theorem cert_e605649201018 : check e605649201018 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649201078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605649201078 : Closed e605649201078 ∧ code e605649201078 = 2804672456630 := by decide
theorem cert_e605649201078 : check e605649201078 [[],[],[.under]] .width = true := by decide
def e605649201110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605649201110 : Closed e605649201110 ∧ code e605649201110 = 2804672456662 := by decide
theorem cert_e605649201110 : check e605649201110 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649201114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605649201114 : Closed e605649201114 ∧ code e605649201114 = 2804672456666 := by decide
theorem cert_e605649201114 : check e605649201114 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649201630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605649201630 : Closed e605649201630 ∧ code e605649201630 = 2804672457182 := by decide
theorem cert_e605649201630 : check e605649201630 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649201654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605649201654 : Closed e605649201654 ∧ code e605649201654 = 2804672457206 := by decide
theorem cert_e605649201654 : check e605649201654 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649202398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605649202398 : Closed e605649202398 ∧ code e605649202398 = 2804672457950 := by decide
theorem cert_e605649202398 : check e605649202398 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649202414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605649202414 : Closed e605649202414 ∧ code e605649202414 = 2804672457966 := by decide
theorem cert_e605649202414 : check e605649202414 [[],[],[.under]] .width = true := by decide
def e605649202422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605649202422 : Closed e605649202422 ∧ code e605649202422 = 2804672457974 := by decide
theorem cert_e605649202422 : check e605649202422 [[],[],[.under]] .width = true := by decide
def e605649202426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605649202426 : Closed e605649202426 ∧ code e605649202426 = 2804672457978 := by decide
theorem cert_e605649202426 : check e605649202426 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649202750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e605649202750 : Closed e605649202750 ∧ code e605649202750 = 2804672458302 := by decide
theorem cert_e605649202750 : check e605649202750 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649202806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605649202806 : Closed e605649202806 ∧ code e605649202806 = 2804672458358 := by decide
theorem cert_e605649202806 : check e605649202806 [[],[],[.under]] .width = true := by decide
def e605649202974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e605649202974 : Closed e605649202974 ∧ code e605649202974 = 2804672458526 := by decide
theorem cert_e605649202974 : check e605649202974 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649202998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605649202998 : Closed e605649202998 ∧ code e605649202998 = 2804672458550 := by decide
theorem cert_e605649202998 : check e605649202998 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649203002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605649203002 : Closed e605649203002 ∧ code e605649203002 = 2804672458554 := by decide
theorem cert_e605649203002 : check e605649203002 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649204062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605649204062 : Closed e605649204062 ∧ code e605649204062 = 2804672459614 := by decide
theorem cert_e605649204062 : check e605649204062 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649204078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605649204078 : Closed e605649204078 ∧ code e605649204078 = 2804672459630 := by decide
theorem cert_e605649204078 : check e605649204078 [[],[],[.under]] .width = true := by decide
def e605649204086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605649204086 : Closed e605649204086 ∧ code e605649204086 = 2804672459638 := by decide
theorem cert_e605649204086 : check e605649204086 [[],[],[.under]] .width = true := by decide
def e605649204090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605649204090 : Closed e605649204090 ∧ code e605649204090 = 2804672459642 := by decide
theorem cert_e605649204090 : check e605649204090 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649204142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605649204142 : Closed e605649204142 ∧ code e605649204142 = 2804672459694 := by decide
theorem cert_e605649204142 : check e605649204142 [[],[],[.under]] .width = true := by decide
def e605649204154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605649204154 : Closed e605649204154 ∧ code e605649204154 = 2804672459706 := by decide
theorem cert_e605649204154 : check e605649204154 [[],[],[.under]] .width = true := by decide
def e605649204182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605649204182 : Closed e605649204182 ∧ code e605649204182 = 2804672459734 := by decide
theorem cert_e605649204182 : check e605649204182 [[],[],[.under]] .width = true := by decide
def e605649204186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605649204186 : Closed e605649204186 ∧ code e605649204186 = 2804672459738 := by decide
theorem cert_e605649204186 : check e605649204186 [[],[],[.under]] .width = true := by decide
def e605649204202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605649204202 : Closed e605649204202 ∧ code e605649204202 = 2804672459754 := by decide
theorem cert_e605649204202 : check e605649204202 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649204446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605649204446 : Closed e605649204446 ∧ code e605649204446 = 2804672459998 := by decide
theorem cert_e605649204446 : check e605649204446 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649204462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605649204462 : Closed e605649204462 ∧ code e605649204462 = 2804672460014 := by decide
theorem cert_e605649204462 : check e605649204462 [[],[],[.under]] .width = true := by decide
def e605649204470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605649204470 : Closed e605649204470 ∧ code e605649204470 = 2804672460022 := by decide
theorem cert_e605649204470 : check e605649204470 [[],[],[.under]] .width = true := by decide
def e605649204474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605649204474 : Closed e605649204474 ∧ code e605649204474 = 2804672460026 := by decide
theorem cert_e605649204474 : check e605649204474 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649204846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605649204846 : Closed e605649204846 ∧ code e605649204846 = 2804672460398 := by decide
private def t_e605649204846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem cert_e605649204846 : ¬ IsSelfInterpreter e605649204846 :=
  wSource (t := t_e605649204846) (replay_sound (ps := []) (t := e605649204846) (by decide)) (by decide)
def e605649204858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605649204858 : Closed e605649204858 ∧ code e605649204858 = 2804672460410 := by decide
private def t_e605649204858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem cert_e605649204858 : ¬ IsSelfInterpreter e605649204858 :=
  wSource (t := t_e605649204858) (replay_sound (ps := []) (t := e605649204858) (by decide)) (by decide)
def e605649205046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605649205046 : Closed e605649205046 ∧ code e605649205046 = 2804672460598 := by decide
theorem cert_e605649205046 : check e605649205046 [[],[],[.under]] .width = true := by decide
def e605649205050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605649205050 : Closed e605649205050 ∧ code e605649205050 = 2804672460602 := by decide
theorem cert_e605649205050 : check e605649205050 [[],[],[.under]] .width = true := by decide
def e605649205146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605649205146 : Closed e605649205146 ∧ code e605649205146 = 2804672460698 := by decide
private def t_e605649205146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605649205146 : ¬ IsSelfInterpreter e605649205146 :=
  wSource (t := t_e605649205146) (replay_sound (ps := []) (t := e605649205146) (by decide)) (by decide)
def e605649205470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e605649205470 : Closed e605649205470 ∧ code e605649205470 = 2804672461022 := by decide
theorem cert_e605649205470 : check e605649205470 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649205498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e605649205498 : Closed e605649205498 ∧ code e605649205498 = 2804672461050 := by decide
theorem cert_e605649205498 : check e605649205498 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649205686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605649205686 : Closed e605649205686 ∧ code e605649205686 = 2804672461238 := by decide
theorem cert_e605649205686 : check e605649205686 [[],[],[.under]] .width = true := by decide
def e605649205718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605649205718 : Closed e605649205718 ∧ code e605649205718 = 2804672461270 := by decide
theorem cert_e605649205718 : check e605649205718 [[],[],[.under]] .width = true := by decide
def e605649205722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605649205722 : Closed e605649205722 ∧ code e605649205722 = 2804672461274 := by decide
theorem cert_e605649205722 : check e605649205722 [[],[],[.under]] .width = true := by decide
def e605649205822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e605649205822 : Closed e605649205822 ∧ code e605649205822 = 2804672461374 := by decide
theorem cert_e605649205822 : check e605649205822 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649205878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605649205878 : Closed e605649205878 ∧ code e605649205878 = 2804672461430 := by decide
theorem cert_e605649205878 : check e605649205878 [[],[],[.under]] .width = true := by decide
def e605649206070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605649206070 : Closed e605649206070 ∧ code e605649206070 = 2804672461622 := by decide
theorem cert_e605649206070 : check e605649206070 [[],[],[.under]] .width = true := by decide
def e605649206074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605649206074 : Closed e605649206074 ∧ code e605649206074 = 2804672461626 := by decide
theorem cert_e605649206074 : check e605649206074 [[],[],[.under]] .width = true := by decide
def e605649206214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e605649206214 : Closed e605649206214 ∧ code e605649206214 = 2804672461766 := by decide
theorem cert_e605649206214 : check e605649206214 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605649206382 : Closed e605649206382 ∧ code e605649206382 = 2804672461934 := by decide
theorem cert_e605649206382 : check e605649206382 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605649206394 : Closed e605649206394 ∧ code e605649206394 = 2804672461946 := by decide
theorem cert_e605649206394 : check e605649206394 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605649206486 : Closed e605649206486 ∧ code e605649206486 = 2804672462038 := by decide
theorem cert_e605649206486 : check e605649206486 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605649206490 : Closed e605649206490 ∧ code e605649206490 = 2804672462042 := by decide
theorem cert_e605649206490 : check e605649206490 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605649206506 : Closed e605649206506 ∧ code e605649206506 = 2804672462058 := by decide
theorem cert_e605649206506 : check e605649206506 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605649206558 : Closed e605649206558 ∧ code e605649206558 = 2804672462110 := by decide
theorem cert_e605649206558 : check e605649206558 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605649206582 : Closed e605649206582 ∧ code e605649206582 = 2804672462134 := by decide
theorem cert_e605649206582 : check e605649206582 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605649206586 : Closed e605649206586 ∧ code e605649206586 = 2804672462138 := by decide
theorem cert_e605649206586 : check e605649206586 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649206682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605649206682 : Closed e605649206682 ∧ code e605649206682 = 2804672462234 := by decide
private def t_e605649206682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605649206682 : ¬ IsSelfInterpreter e605649206682 :=
  wSource (t := t_e605649206682) (replay_sound (ps := []) (t := e605649206682) (by decide)) (by decide)
def e605649206726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605649206726 : Closed e605649206726 ∧ code e605649206726 = 2804672462278 := by decide
theorem cert_e605649206726 : check e605649206726 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649209278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605649209278 : Closed e605649209278 ∧ code e605649209278 = 2804672464830 := by decide
theorem cert_e605649209278 : check e605649209278 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649209326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605649209326 : Closed e605649209326 ∧ code e605649209326 = 2804672464878 := by decide
theorem cert_e605649209326 : check e605649209326 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605649213150 : Closed e605649213150 ∧ code e605649213150 = 2804672468702 := by decide
theorem cert_e605649213150 : check e605649213150 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605649213174 : Closed e605649213174 ∧ code e605649213174 = 2804672468726 := by decide
theorem cert_e605649213174 : check e605649213174 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605649213278 : Closed e605649213278 ∧ code e605649213278 = 2804672468830 := by decide
theorem cert_e605649213278 : check e605649213278 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605649213294 : Closed e605649213294 ∧ code e605649213294 = 2804672468846 := by decide
theorem cert_e605649213294 : check e605649213294 [[],[],[.under]] .width = true := by decide
def e605649213302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605649213302 : Closed e605649213302 ∧ code e605649213302 = 2804672468854 := by decide
theorem cert_e605649213302 : check e605649213302 [[],[],[.under]] .width = true := by decide
def e605649213306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605649213306 : Closed e605649213306 ∧ code e605649213306 = 2804672468858 := by decide
theorem cert_e605649213306 : check e605649213306 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605649213366 : Closed e605649213366 ∧ code e605649213366 = 2804672468918 := by decide
theorem cert_e605649213366 : check e605649213366 [[],[],[.under]] .width = true := by decide
def e605649213398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605649213398 : Closed e605649213398 ∧ code e605649213398 = 2804672468950 := by decide
theorem cert_e605649213398 : check e605649213398 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605649213402 : Closed e605649213402 ∧ code e605649213402 = 2804672468954 := by decide
theorem cert_e605649213402 : check e605649213402 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605649213918 : Closed e605649213918 ∧ code e605649213918 = 2804672469470 := by decide
theorem cert_e605649213918 : check e605649213918 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649213942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605649213942 : Closed e605649213942 ∧ code e605649213942 = 2804672469494 := by decide
theorem cert_e605649213942 : check e605649213942 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649214686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605649214686 : Closed e605649214686 ∧ code e605649214686 = 2804672470238 := by decide
theorem cert_e605649214686 : check e605649214686 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649214702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605649214702 : Closed e605649214702 ∧ code e605649214702 = 2804672470254 := by decide
theorem cert_e605649214702 : check e605649214702 [[],[],[.under]] .width = true := by decide
def e605649214710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605649214710 : Closed e605649214710 ∧ code e605649214710 = 2804672470262 := by decide
theorem cert_e605649214710 : check e605649214710 [[],[],[.under]] .width = true := by decide
def e605649214714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605649214714 : Closed e605649214714 ∧ code e605649214714 = 2804672470266 := by decide
theorem cert_e605649214714 : check e605649214714 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649215038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605649215038 : Closed e605649215038 ∧ code e605649215038 = 2804672470590 := by decide
theorem cert_e605649215038 : check e605649215038 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649215094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605649215094 : Closed e605649215094 ∧ code e605649215094 = 2804672470646 := by decide
theorem cert_e605649215094 : check e605649215094 [[],[],[.under]] .width = true := by decide
def e605649215262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605649215262 : Closed e605649215262 ∧ code e605649215262 = 2804672470814 := by decide
theorem cert_e605649215262 : check e605649215262 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649215286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649215286 : Closed e605649215286 ∧ code e605649215286 = 2804672470838 := by decide
theorem cert_e605649215286 : check e605649215286 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649215290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649215290 : Closed e605649215290 ∧ code e605649215290 = 2804672470842 := by decide
theorem cert_e605649215290 : check e605649215290 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649224638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e605649224638 : Closed e605649224638 ∧ code e605649224638 = 2804672480190 := by decide
theorem cert_e605649224638 : check e605649224638 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649224694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e605649224694 : Closed e605649224694 ∧ code e605649224694 = 2804672480246 := by decide
theorem cert_e605649224694 : check e605649224694 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649226590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605649226590 : Closed e605649226590 ∧ code e605649226590 = 2804672482142 := by decide
theorem cert_e605649226590 : check e605649226590 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649226606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605649226606 : Closed e605649226606 ∧ code e605649226606 = 2804672482158 := by decide
theorem cert_e605649226606 : check e605649226606 [[],[],[.under]] .width = true := by decide
def e605649226614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605649226614 : Closed e605649226614 ∧ code e605649226614 = 2804672482166 := by decide
theorem cert_e605649226614 : check e605649226614 [[],[],[.under]] .width = true := by decide
def e605649226618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605649226618 : Closed e605649226618 ∧ code e605649226618 = 2804672482170 := by decide
theorem cert_e605649226618 : check e605649226618 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649226670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605649226670 : Closed e605649226670 ∧ code e605649226670 = 2804672482222 := by decide
theorem cert_e605649226670 : check e605649226670 [[],[],[.under]] .width = true := by decide
def e605649226682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605649226682 : Closed e605649226682 ∧ code e605649226682 = 2804672482234 := by decide
theorem cert_e605649226682 : check e605649226682 [[],[],[.under]] .width = true := by decide
def e605649226710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605649226710 : Closed e605649226710 ∧ code e605649226710 = 2804672482262 := by decide
theorem cert_e605649226710 : check e605649226710 [[],[],[.under]] .width = true := by decide
def e605649226714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605649226714 : Closed e605649226714 ∧ code e605649226714 = 2804672482266 := by decide
theorem cert_e605649226714 : check e605649226714 [[],[],[.under]] .width = true := by decide
def e605649226730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605649226730 : Closed e605649226730 ∧ code e605649226730 = 2804672482282 := by decide
theorem cert_e605649226730 : check e605649226730 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649226974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605649226974 : Closed e605649226974 ∧ code e605649226974 = 2804672482526 := by decide
theorem cert_e605649226974 : check e605649226974 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649226990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605649226990 : Closed e605649226990 ∧ code e605649226990 = 2804672482542 := by decide
theorem cert_e605649226990 : check e605649226990 [[],[],[.under]] .width = true := by decide
def e605649226998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605649226998 : Closed e605649226998 ∧ code e605649226998 = 2804672482550 := by decide
theorem cert_e605649226998 : check e605649226998 [[],[],[.under]] .width = true := by decide
def e605649227002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605649227002 : Closed e605649227002 ∧ code e605649227002 = 2804672482554 := by decide
theorem cert_e605649227002 : check e605649227002 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649227374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605649227374 : Closed e605649227374 ∧ code e605649227374 = 2804672482926 := by decide
theorem cert_e605649227374 : check e605649227374 [[],[],[.under]] .width = true := by decide
def e605649227386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605649227386 : Closed e605649227386 ∧ code e605649227386 = 2804672482938 := by decide
theorem cert_e605649227386 : check e605649227386 [[],[],[.under]] .width = true := by decide
def e605649227574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649227574 : Closed e605649227574 ∧ code e605649227574 = 2804672483126 := by decide
theorem cert_e605649227574 : check e605649227574 [[],[],[.under]] .width = true := by decide
def e605649227578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649227578 : Closed e605649227578 ∧ code e605649227578 = 2804672483130 := by decide
theorem cert_e605649227578 : check e605649227578 [[],[],[.under]] .width = true := by decide
def e605649227674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605649227674 : Closed e605649227674 ∧ code e605649227674 = 2804672483226 := by decide
theorem cert_e605649227674 : check e605649227674 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649233334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605649233334 : Closed e605649233334 ∧ code e605649233334 = 2804672488886 := by decide
theorem cert_e605649233334 : check e605649233334 [[],[],[.under]] .width = true := by decide
def e605649233366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605649233366 : Closed e605649233366 ∧ code e605649233366 = 2804672488918 := by decide
theorem cert_e605649233366 : check e605649233366 [[],[],[.under]] .width = true := by decide
def e605649233370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605649233370 : Closed e605649233370 ∧ code e605649233370 = 2804672488922 := by decide
theorem cert_e605649233370 : check e605649233370 [[],[],[.under]] .width = true := by decide
def e605649233470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e605649233470 : Closed e605649233470 ∧ code e605649233470 = 2804672489022 := by decide
theorem cert_e605649233470 : check e605649233470 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649233526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605649233526 : Closed e605649233526 ∧ code e605649233526 = 2804672489078 := by decide
theorem cert_e605649233526 : check e605649233526 [[],[],[.under]] .width = true := by decide
def e605649233718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649233718 : Closed e605649233718 ∧ code e605649233718 = 2804672489270 := by decide
theorem cert_e605649233718 : check e605649233718 [[],[],[.under]] .width = true := by decide
end Blc.Floor41
