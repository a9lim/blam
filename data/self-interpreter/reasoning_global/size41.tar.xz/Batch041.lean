import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598343364458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e598343364458 : Closed e598343364458 ∧ code e598343364458 = 2797366620010 := by decide
theorem cert_e598343364458 : check e598343364458 [[],[.left],[]] .sourceHead = true := by decide
def e598343365486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e598343365486 : Closed e598343365486 ∧ code e598343365486 = 2797366621038 := by decide
theorem cert_e598343365486 : check e598343365486 [[],[.left],[]] .sourceHead = true := by decide
def e598343365494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e598343365494 : Closed e598343365494 ∧ code e598343365494 = 2797366621046 := by decide
theorem cert_e598343365494 : check e598343365494 [[],[.left],[]] .sourceHead = true := by decide
def e598343365550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e598343365550 : Closed e598343365550 ∧ code e598343365550 = 2797366621102 := by decide
theorem cert_e598343365550 : check e598343365550 [[],[.left],[]] .sourceHead = true := by decide
def e598343365562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e598343365562 : Closed e598343365562 ∧ code e598343365562 = 2797366621114 := by decide
theorem cert_e598343365562 : check e598343365562 [[],[.left],[]] .sourceHead = true := by decide
def e598343365590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e598343365590 : Closed e598343365590 ∧ code e598343365590 = 2797366621142 := by decide
theorem cert_e598343365590 : check e598343365590 [[],[.left],[]] .sourceHead = true := by decide
def e598343365594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e598343365594 : Closed e598343365594 ∧ code e598343365594 = 2797366621146 := by decide
theorem cert_e598343365594 : check e598343365594 [[],[.left],[]] .sourceHead = true := by decide
def e598343365870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e598343365870 : Closed e598343365870 ∧ code e598343365870 = 2797366621422 := by decide
theorem cert_e598343365870 : check e598343365870 [[],[.left],[]] .sourceHead = true := by decide
def e598343365878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e598343365878 : Closed e598343365878 ∧ code e598343365878 = 2797366621430 := by decide
theorem cert_e598343365878 : check e598343365878 [[],[.left],[]] .sourceHead = true := by decide
def e598343366254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e598343366254 : Closed e598343366254 ∧ code e598343366254 = 2797366621806 := by decide
theorem cert_e598343366254 : check e598343366254 [[],[.left],[]] .sourceHead = true := by decide
def e598343366266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e598343366266 : Closed e598343366266 ∧ code e598343366266 = 2797366621818 := by decide
theorem cert_e598343366266 : check e598343366266 [[],[.left],[]] .sourceHead = true := by decide
def e598343366454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e598343366454 : Closed e598343366454 ∧ code e598343366454 = 2797366622006 := by decide
theorem cert_e598343366454 : check e598343366454 [[],[.left],[]] .sourceHead = true := by decide
def e598343366458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e598343366458 : Closed e598343366458 ∧ code e598343366458 = 2797366622010 := by decide
theorem cert_e598343366458 : check e598343366458 [[],[.left],[]] .sourceHead = true := by decide
def e598343366894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e598343366894 : Closed e598343366894 ∧ code e598343366894 = 2797366622446 := by decide
theorem cert_e598343366894 : check e598343366894 [[],[.left],[]] .sourceHead = true := by decide
def e598343366902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e598343366902 : Closed e598343366902 ∧ code e598343366902 = 2797366622454 := by decide
theorem cert_e598343366902 : check e598343366902 [[],[.left],[]] .sourceHead = true := by decide
def e598343367086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e598343367086 : Closed e598343367086 ∧ code e598343367086 = 2797366622638 := by decide
theorem cert_e598343367086 : check e598343367086 [[],[.left],[]] .sourceHead = true := by decide
def e598343367098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e598343367098 : Closed e598343367098 ∧ code e598343367098 = 2797366622650 := by decide
theorem cert_e598343367098 : check e598343367098 [[],[.left],[]] .sourceHead = true := by decide
def e598343367146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e598343367146 : Closed e598343367146 ∧ code e598343367146 = 2797366622698 := by decide
theorem cert_e598343367146 : check e598343367146 [[],[.left],[]] .sourceHead = true := by decide
def e598343367278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e598343367278 : Closed e598343367278 ∧ code e598343367278 = 2797366622830 := by decide
theorem cert_e598343367278 : check e598343367278 [[],[.left],[]] .sourceHead = true := by decide
def e598343367290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e598343367290 : Closed e598343367290 ∧ code e598343367290 = 2797366622842 := by decide
theorem cert_e598343367290 : check e598343367290 [[],[.left],[]] .sourceHead = true := by decide
def e598343367454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e598343367454 : Closed e598343367454 ∧ code e598343367454 = 2797366623006 := by decide
theorem cert_e598343367454 : check e598343367454 [[],[.left],[]] .sourceHead = true := by decide
def e598343367566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e598343367566 : Closed e598343367566 ∧ code e598343367566 = 2797366623118 := by decide
theorem cert_e598343367566 : check e598343367566 [[],[.left],[]] .sourceHead = true := by decide
def e598343367578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e598343367578 : Closed e598343367578 ∧ code e598343367578 = 2797366623130 := by decide
theorem cert_e598343367578 : check e598343367578 [[],[.left],[]] .sourceHead = true := by decide
def e598343367798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e598343367798 : Closed e598343367798 ∧ code e598343367798 = 2797366623350 := by decide
theorem cert_e598343367798 : check e598343367798 [[],[.left],[]] .sourceHead = true := by decide
def e598343367894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e598343367894 : Closed e598343367894 ∧ code e598343367894 = 2797366623446 := by decide
theorem cert_e598343367894 : check e598343367894 [[],[.left],[]] .sourceHead = true := by decide
def e598343367898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e598343367898 : Closed e598343367898 ∧ code e598343367898 = 2797366623450 := by decide
theorem cert_e598343367898 : check e598343367898 [[],[.left],[]] .sourceHead = true := by decide
def e598343367914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e598343367914 : Closed e598343367914 ∧ code e598343367914 = 2797366623466 := by decide
theorem cert_e598343367914 : check e598343367914 [[],[.left],[]] .sourceHead = true := by decide
def e598343367990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e598343367990 : Closed e598343367990 ∧ code e598343367990 = 2797366623542 := by decide
theorem cert_e598343367990 : check e598343367990 [[],[.left],[]] .sourceHead = true := by decide
def e598343367994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e598343367994 : Closed e598343367994 ∧ code e598343367994 = 2797366623546 := by decide
theorem cert_e598343367994 : check e598343367994 [[],[.left],[]] .sourceHead = true := by decide
def e598343368078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e598343368078 : Closed e598343368078 ∧ code e598343368078 = 2797366623630 := by decide
theorem cert_e598343368078 : check e598343368078 [[],[.left],[]] .sourceHead = true := by decide
def e598343368090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e598343368090 : Closed e598343368090 ∧ code e598343368090 = 2797366623642 := by decide
theorem cert_e598343368090 : check e598343368090 [[],[.left],[]] .sourceHead = true := by decide
def e598343369694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e598343369694 : Closed e598343369694 ∧ code e598343369694 = 2797366625246 := by decide
theorem cert_e598343369694 : check e598343369694 [[],[.left],[]] .sourceHead = true := by decide
def e598343369710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e598343369710 : Closed e598343369710 ∧ code e598343369710 = 2797366625262 := by decide
theorem cert_e598343369710 : check e598343369710 [[],[.left],[]] .sourceHead = true := by decide
def e598343371630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598343371630 : Closed e598343371630 ∧ code e598343371630 = 2797366627182 := by decide
theorem cert_e598343371630 : check e598343371630 [[],[.left],[]] .sourceHead = true := by decide
def e598343371638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598343371638 : Closed e598343371638 ∧ code e598343371638 = 2797366627190 := by decide
theorem cert_e598343371638 : check e598343371638 [[],[.left],[]] .sourceHead = true := by decide
def e598343371694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598343371694 : Closed e598343371694 ∧ code e598343371694 = 2797366627246 := by decide
theorem cert_e598343371694 : check e598343371694 [[],[.left],[]] .sourceHead = true := by decide
def e598343371706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598343371706 : Closed e598343371706 ∧ code e598343371706 = 2797366627258 := by decide
theorem cert_e598343371706 : check e598343371706 [[],[.left],[]] .sourceHead = true := by decide
def e598343371734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598343371734 : Closed e598343371734 ∧ code e598343371734 = 2797366627286 := by decide
theorem cert_e598343371734 : check e598343371734 [[],[.left],[]] .sourceHead = true := by decide
def e598343371738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598343371738 : Closed e598343371738 ∧ code e598343371738 = 2797366627290 := by decide
theorem cert_e598343371738 : check e598343371738 [[],[.left],[]] .sourceHead = true := by decide
def e598343372014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598343372014 : Closed e598343372014 ∧ code e598343372014 = 2797366627566 := by decide
theorem cert_e598343372014 : check e598343372014 [[],[.left],[]] .sourceHead = true := by decide
def e598343372022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598343372022 : Closed e598343372022 ∧ code e598343372022 = 2797366627574 := by decide
theorem cert_e598343372022 : check e598343372022 [[],[.left],[]] .sourceHead = true := by decide
def e598343372398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598343372398 : Closed e598343372398 ∧ code e598343372398 = 2797366627950 := by decide
theorem cert_e598343372398 : check e598343372398 [[],[.left],[]] .sourceHead = true := by decide
def e598343372410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598343372410 : Closed e598343372410 ∧ code e598343372410 = 2797366627962 := by decide
theorem cert_e598343372410 : check e598343372410 [[],[.left],[]] .sourceHead = true := by decide
def e598343372598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598343372598 : Closed e598343372598 ∧ code e598343372598 = 2797366628150 := by decide
theorem cert_e598343372598 : check e598343372598 [[],[.left],[]] .sourceHead = true := by decide
def e598343372602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598343372602 : Closed e598343372602 ∧ code e598343372602 = 2797366628154 := by decide
theorem cert_e598343372602 : check e598343372602 [[],[.left],[]] .sourceHead = true := by decide
def e598343377374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e598343377374 : Closed e598343377374 ∧ code e598343377374 = 2797366632926 := by decide
theorem cert_e598343377374 : check e598343377374 [[],[.left],[]] .sourceHead = true := by decide
def e598343377398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e598343377398 : Closed e598343377398 ∧ code e598343377398 = 2797366632950 := by decide
theorem cert_e598343377398 : check e598343377398 [[],[.left],[]] .sourceHead = true := by decide
def e598343378350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e598343378350 : Closed e598343378350 ∧ code e598343378350 = 2797366633902 := by decide
theorem cert_e598343378350 : check e598343378350 [[],[.left],[]] .sourceHead = true := by decide
def e598343378362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e598343378362 : Closed e598343378362 ∧ code e598343378362 = 2797366633914 := by decide
theorem cert_e598343378362 : check e598343378362 [[],[.left],[]] .sourceHead = true := by decide
def e598343378410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e598343378410 : Closed e598343378410 ∧ code e598343378410 = 2797366633962 := by decide
theorem cert_e598343378410 : check e598343378410 [[],[.left],[]] .sourceHead = true := by decide
def e598343378542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e598343378542 : Closed e598343378542 ∧ code e598343378542 = 2797366634094 := by decide
theorem cert_e598343378542 : check e598343378542 [[],[.left],[]] .sourceHead = true := by decide
def e598343378554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e598343378554 : Closed e598343378554 ∧ code e598343378554 = 2797366634106 := by decide
theorem cert_e598343378554 : check e598343378554 [[],[.left],[]] .sourceHead = true := by decide
def e598343378718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e598343378718 : Closed e598343378718 ∧ code e598343378718 = 2797366634270 := by decide
theorem cert_e598343378718 : check e598343378718 [[],[.left],[]] .sourceHead = true := by decide
def e598343378830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e598343378830 : Closed e598343378830 ∧ code e598343378830 = 2797366634382 := by decide
theorem cert_e598343378830 : check e598343378830 [[],[.left],[]] .sourceHead = true := by decide
def e598343378842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e598343378842 : Closed e598343378842 ∧ code e598343378842 = 2797366634394 := by decide
theorem cert_e598343378842 : check e598343378842 [[],[.left],[]] .sourceHead = true := by decide
def e598343381230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e598343381230 : Closed e598343381230 ∧ code e598343381230 = 2797366636782 := by decide
theorem cert_e598343381230 : check e598343381230 [[],[.left],[]] .sourceHead = true := by decide
def e598343381238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e598343381238 : Closed e598343381238 ∧ code e598343381238 = 2797366636790 := by decide
theorem cert_e598343381238 : check e598343381238 [[],[.left],[]] .sourceHead = true := by decide
def e598343381718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e598343381718 : Closed e598343381718 ∧ code e598343381718 = 2797366637270 := by decide
theorem cert_e598343381718 : check e598343381718 [[],[.left],[]] .sourceHead = true := by decide
def e598343381722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e598343381722 : Closed e598343381722 ∧ code e598343381722 = 2797366637274 := by decide
theorem cert_e598343381722 : check e598343381722 [[],[.left],[]] .sourceHead = true := by decide
def e598343381738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e598343381738 : Closed e598343381738 ∧ code e598343381738 = 2797366637290 := by decide
theorem cert_e598343381738 : check e598343381738 [[],[.left],[]] .sourceHead = true := by decide
def e598343381814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e598343381814 : Closed e598343381814 ∧ code e598343381814 = 2797366637366 := by decide
theorem cert_e598343381814 : check e598343381814 [[],[.left],[]] .sourceHead = true := by decide
def e598343381818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e598343381818 : Closed e598343381818 ∧ code e598343381818 = 2797366637370 := by decide
theorem cert_e598343381818 : check e598343381818 [[],[.left],[]] .sourceHead = true := by decide
def e598343381902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e598343381902 : Closed e598343381902 ∧ code e598343381902 = 2797366637454 := by decide
theorem cert_e598343381902 : check e598343381902 [[],[.left],[]] .sourceHead = true := by decide
def e598343381914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e598343381914 : Closed e598343381914 ∧ code e598343381914 = 2797366637466 := by decide
theorem cert_e598343381914 : check e598343381914 [[],[.left],[]] .sourceHead = true := by decide
def e598343386990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e598343386990 : Closed e598343386990 ∧ code e598343386990 = 2797366642542 := by decide
theorem cert_e598343386990 : check e598343386990 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343387002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e598343387002 : Closed e598343387002 ∧ code e598343387002 = 2797366642554 := by decide
theorem cert_e598343387002 : check e598343387002 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343387098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e598343387098 : Closed e598343387098 ∧ code e598343387098 = 2797366642650 := by decide
theorem cert_e598343387098 : check e598343387098 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343388398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e598343388398 : Closed e598343388398 ∧ code e598343388398 = 2797366643950 := by decide
theorem cert_e598343388398 : check e598343388398 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e598343388406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e598343388406 : Closed e598343388406 ∧ code e598343388406 = 2797366643958 := by decide
theorem cert_e598343388406 : check e598343388406 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e598343388782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e598343388782 : Closed e598343388782 ∧ code e598343388782 = 2797366644334 := by decide
theorem cert_e598343388782 : check e598343388782 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343388794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e598343388794 : Closed e598343388794 ∧ code e598343388794 = 2797366644346 := by decide
theorem cert_e598343388794 : check e598343388794 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343388982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e598343388982 : Closed e598343388982 ∧ code e598343388982 = 2797366644534 := by decide
theorem cert_e598343388982 : check e598343388982 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343388986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e598343388986 : Closed e598343388986 ∧ code e598343388986 = 2797366644538 := by decide
theorem cert_e598343388986 : check e598343388986 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e598343390894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e598343390894 : Closed e598343390894 ∧ code e598343390894 = 2797366646446 := by decide
theorem cert_e598343390894 : check e598343390894 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343390906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e598343390906 : Closed e598343390906 ∧ code e598343390906 = 2797366646458 := by decide
theorem cert_e598343390906 : check e598343390906 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343390954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e598343390954 : Closed e598343390954 ∧ code e598343390954 = 2797366646506 := by decide
theorem cert_e598343390954 : check e598343390954 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343391146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e598343391146 : Closed e598343391146 ∧ code e598343391146 = 2797366646698 := by decide
theorem cert_e598343391146 : check e598343391146 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343391470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e598343391470 : Closed e598343391470 ∧ code e598343391470 = 2797366647022 := by decide
theorem cert_e598343391470 : check e598343391470 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343391478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e598343391478 : Closed e598343391478 ∧ code e598343391478 = 2797366647030 := by decide
theorem cert_e598343391478 : check e598343391478 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343391662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e598343391662 : Closed e598343391662 ∧ code e598343391662 = 2797366647214 := by decide
theorem cert_e598343391662 : check e598343391662 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343391674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e598343391674 : Closed e598343391674 ∧ code e598343391674 = 2797366647226 := by decide
theorem cert_e598343391674 : check e598343391674 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343391722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e598343391722 : Closed e598343391722 ∧ code e598343391722 = 2797366647274 := by decide
theorem cert_e598343391722 : check e598343391722 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343391854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e598343391854 : Closed e598343391854 ∧ code e598343391854 = 2797366647406 := by decide
theorem cert_e598343391854 : check e598343391854 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343391866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e598343391866 : Closed e598343391866 ∧ code e598343391866 = 2797366647418 := by decide
theorem cert_e598343391866 : check e598343391866 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343392030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e598343392030 : Closed e598343392030 ∧ code e598343392030 = 2797366647582 := by decide
theorem cert_e598343392030 : check e598343392030 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343392142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e598343392142 : Closed e598343392142 ∧ code e598343392142 = 2797366647694 := by decide
theorem cert_e598343392142 : check e598343392142 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343392154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e598343392154 : Closed e598343392154 ∧ code e598343392154 = 2797366647706 := by decide
theorem cert_e598343392154 : check e598343392154 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343392366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e598343392366 : Closed e598343392366 ∧ code e598343392366 = 2797366647918 := by decide
theorem cert_e598343392366 : check e598343392366 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343392378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e598343392378 : Closed e598343392378 ∧ code e598343392378 = 2797366647930 := by decide
theorem cert_e598343392378 : checkPay e598343392378 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right,.under]] = true := by decide
def e598343392542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e598343392542 : Closed e598343392542 ∧ code e598343392542 = 2797366648094 := by decide
theorem cert_e598343392542 : check e598343392542 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343392710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e598343392710 : Closed e598343392710 ∧ code e598343392710 = 2797366648262 := by decide
theorem cert_e598343392710 : check e598343392710 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .smaller = true := by decide
def e598343392822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e598343392822 : Closed e598343392822 ∧ code e598343392822 = 2797366648374 := by decide
theorem cert_e598343392822 : check e598343392822 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343392826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e598343392826 : Closed e598343392826 ∧ code e598343392826 = 2797366648378 := by decide
theorem cert_e598343392826 : checkPay e598343392826 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left]] = true := by decide
def e598343392874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e598343392874 : Closed e598343392874 ∧ code e598343392874 = 2797366648426 := by decide
theorem cert_e598343392874 : check e598343392874 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343392910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e598343392910 : Closed e598343392910 ∧ code e598343392910 = 2797366648462 := by decide
theorem cert_e598343392910 : check e598343392910 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343392922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e598343392922 : Closed e598343392922 ∧ code e598343392922 = 2797366648474 := by decide
theorem cert_e598343392922 : check e598343392922 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343392966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e598343392966 : Closed e598343392966 ∧ code e598343392966 = 2797366648518 := by decide
theorem cert_e598343392966 : check e598343392966 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .smaller = true := by decide
def e598343393758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e598343393758 : Closed e598343393758 ∧ code e598343393758 = 2797366649310 := by decide
theorem cert_e598343393758 : check e598343393758 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343393782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e598343393782 : Closed e598343393782 ∧ code e598343393782 = 2797366649334 := by decide
theorem cert_e598343393782 : check e598343393782 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343394734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e598343394734 : Closed e598343394734 ∧ code e598343394734 = 2797366650286 := by decide
theorem cert_e598343394734 : check e598343394734 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343394746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e598343394746 : Closed e598343394746 ∧ code e598343394746 = 2797366650298 := by decide
theorem cert_e598343394746 : check e598343394746 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343394794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e598343394794 : Closed e598343394794 ∧ code e598343394794 = 2797366650346 := by decide
theorem cert_e598343394794 : check e598343394794 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343394926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e598343394926 : Closed e598343394926 ∧ code e598343394926 = 2797366650478 := by decide
theorem cert_e598343394926 : check e598343394926 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343394938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e598343394938 : Closed e598343394938 ∧ code e598343394938 = 2797366650490 := by decide
theorem cert_e598343394938 : check e598343394938 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343395102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e598343395102 : Closed e598343395102 ∧ code e598343395102 = 2797366650654 := by decide
theorem cert_e598343395102 : check e598343395102 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e598343395214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e598343395214 : Closed e598343395214 ∧ code e598343395214 = 2797366650766 := by decide
theorem cert_e598343395214 : check e598343395214 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e598343395226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e598343395226 : Closed e598343395226 ∧ code e598343395226 = 2797366650778 := by decide
theorem cert_e598343395226 : check e598343395226 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343398174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e598343398174 : Closed e598343398174 ∧ code e598343398174 = 2797366653726 := by decide
theorem cert_e598343398174 : check e598343398174 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343398342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e598343398342 : Closed e598343398342 ∧ code e598343398342 = 2797366653894 := by decide
def e598343399542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e598343399542 : Closed e598343399542 ∧ code e598343399542 = 2797366655094 := by decide
theorem cert_e598343399542 : check e598343399542 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343399786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e598343399786 : Closed e598343399786 ∧ code e598343399786 = 2797366655338 := by decide
theorem cert_e598343399786 : check e598343399786 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343399822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e598343399822 : Closed e598343399822 ∧ code e598343399822 = 2797366655374 := by decide
theorem cert_e598343399822 : check e598343399822 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343399834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e598343399834 : Closed e598343399834 ∧ code e598343399834 = 2797366655386 := by decide
theorem cert_e598343399834 : check e598343399834 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343399878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e598343399878 : Closed e598343399878 ∧ code e598343399878 = 2797366655430 := by decide
theorem cert_e598343399878 : check e598343399878 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343402422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e598343402422 : Closed e598343402422 ∧ code e598343402422 = 2797366657974 := by decide
theorem cert_e598343402422 : check e598343402422 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343402426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e598343402426 : Closed e598343402426 ∧ code e598343402426 = 2797366657978 := by decide
theorem cert_e598343402426 : check e598343402426 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343402458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e598343402458 : Closed e598343402458 ∧ code e598343402458 = 2797366658010 := by decide
theorem cert_e598343402458 : check e598343402458 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343403126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e598343403126 : Closed e598343403126 ∧ code e598343403126 = 2797366658678 := by decide
theorem cert_e598343403126 : check e598343403126 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e598343403318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e598343403318 : Closed e598343403318 ∧ code e598343403318 = 2797366658870 := by decide
theorem cert_e598343403318 : check e598343403318 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343403322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e598343403322 : Closed e598343403322 ∧ code e598343403322 = 2797366658874 := by decide
theorem cert_e598343403322 : check e598343403322 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343404374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e598343404374 : Closed e598343404374 ∧ code e598343404374 = 2797366659926 := by decide
theorem cert_e598343404374 : check e598343404374 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343404378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e598343404378 : Closed e598343404378 ∧ code e598343404378 = 2797366659930 := by decide
theorem cert_e598343404378 : check e598343404378 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343404394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e598343404394 : Closed e598343404394 ∧ code e598343404394 = 2797366659946 := by decide
theorem cert_e598343404394 : check e598343404394 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343404458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e598343404458 : Closed e598343404458 ∧ code e598343404458 = 2797366660010 := by decide
theorem cert_e598343404458 : check e598343404458 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343404662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e598343404662 : Closed e598343404662 ∧ code e598343404662 = 2797366660214 := by decide
theorem cert_e598343404662 : check e598343404662 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343404758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e598343404758 : Closed e598343404758 ∧ code e598343404758 = 2797366660310 := by decide
theorem cert_e598343404758 : check e598343404758 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343404762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e598343404762 : Closed e598343404762 ∧ code e598343404762 = 2797366660314 := by decide
theorem cert_e598343404762 : check e598343404762 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343404778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e598343404778 : Closed e598343404778 ∧ code e598343404778 = 2797366660330 := by decide
theorem cert_e598343404778 : check e598343404778 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343404854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e598343404854 : Closed e598343404854 ∧ code e598343404854 = 2797366660406 := by decide
theorem cert_e598343404854 : check e598343404854 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343404858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e598343404858 : Closed e598343404858 ∧ code e598343404858 = 2797366660410 := by decide
theorem cert_e598343404858 : check e598343404858 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343404942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e598343404942 : Closed e598343404942 ∧ code e598343404942 = 2797366660494 := by decide
theorem cert_e598343404942 : check e598343404942 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343404954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e598343404954 : Closed e598343404954 ∧ code e598343404954 = 2797366660506 := by decide
theorem cert_e598343404954 : check e598343404954 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343405110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e598343405110 : Closed e598343405110 ∧ code e598343405110 = 2797366660662 := by decide
theorem cert_e598343405110 : check e598343405110 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e598343405114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e598343405114 : Closed e598343405114 ∧ code e598343405114 = 2797366660666 := by decide
theorem cert_e598343405114 : check e598343405114 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598343405162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e598343405162 : Closed e598343405162 ∧ code e598343405162 = 2797366660714 := by decide
theorem cert_e598343405162 : check e598343405162 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343405198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e598343405198 : Closed e598343405198 ∧ code e598343405198 = 2797366660750 := by decide
theorem cert_e598343405198 : checkPay e598343405198 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left],[.under,.under]] = true := by decide
def e598343405210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e598343405210 : Closed e598343405210 ∧ code e598343405210 = 2797366660762 := by decide
theorem cert_e598343405210 : check e598343405210 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343405254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e598343405254 : Closed e598343405254 ∧ code e598343405254 = 2797366660806 := by decide
theorem cert_e598343405254 : check e598343405254 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598343405806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e598343405806 : Closed e598343405806 ∧ code e598343405806 = 2797366661358 := by decide
theorem cert_e598343405806 : check e598343405806 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343405814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e598343405814 : Closed e598343405814 ∧ code e598343405814 = 2797366661366 := by decide
theorem cert_e598343405814 : check e598343405814 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343406294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e598343406294 : Closed e598343406294 ∧ code e598343406294 = 2797366661846 := by decide
theorem cert_e598343406294 : check e598343406294 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343406298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e598343406298 : Closed e598343406298 ∧ code e598343406298 = 2797366661850 := by decide
theorem cert_e598343406298 : check e598343406298 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343406314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e598343406314 : Closed e598343406314 ∧ code e598343406314 = 2797366661866 := by decide
theorem cert_e598343406314 : check e598343406314 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343406390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e598343406390 : Closed e598343406390 ∧ code e598343406390 = 2797366661942 := by decide
theorem cert_e598343406390 : check e598343406390 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343406394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e598343406394 : Closed e598343406394 ∧ code e598343406394 = 2797366661946 := by decide
theorem cert_e598343406394 : check e598343406394 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343406478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e598343406478 : Closed e598343406478 ∧ code e598343406478 = 2797366662030 := by decide
theorem cert_e598343406478 : checkPay e598343406478 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598343406490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e598343406490 : Closed e598343406490 ∧ code e598343406490 = 2797366662042 := by decide
theorem cert_e598343406490 : check e598343406490 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598343407734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e598343407734 : Closed e598343407734 ∧ code e598343407734 = 2797366663286 := by decide
theorem cert_e598343407734 : check e598343407734 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343407978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e598343407978 : Closed e598343407978 ∧ code e598343407978 = 2797366663530 := by decide
theorem cert_e598343407978 : check e598343407978 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343408014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e598343408014 : Closed e598343408014 ∧ code e598343408014 = 2797366663566 := by decide
theorem cert_e598343408014 : check e598343408014 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343408026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e598343408026 : Closed e598343408026 ∧ code e598343408026 = 2797366663578 := by decide
theorem cert_e598343408026 : check e598343408026 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e598343408070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e598343408070 : Closed e598343408070 ∧ code e598343408070 = 2797366663622 := by decide
theorem cert_e598343408070 : check e598343408070 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343420782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598343420782 : Closed e598343420782 ∧ code e598343420782 = 2797366676334 := by decide
theorem cert_e598343420782 : check e598343420782 [[],[.left],[]] .smaller = true := by decide
def e598343420790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598343420790 : Closed e598343420790 ∧ code e598343420790 = 2797366676342 := by decide
theorem cert_e598343420790 : check e598343420790 [[],[.left],[]] .smaller = true := by decide
def e598343420846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598343420846 : Closed e598343420846 ∧ code e598343420846 = 2797366676398 := by decide
theorem cert_e598343420846 : check e598343420846 [[],[.left],[]] .smaller = true := by decide
def e598343420858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598343420858 : Closed e598343420858 ∧ code e598343420858 = 2797366676410 := by decide
theorem cert_e598343420858 : check e598343420858 [[],[.left],[]] .smaller = true := by decide
def e598343420886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598343420886 : Closed e598343420886 ∧ code e598343420886 = 2797366676438 := by decide
theorem cert_e598343420886 : check e598343420886 [[],[.left],[]] .smaller = true := by decide
def e598343420890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598343420890 : Closed e598343420890 ∧ code e598343420890 = 2797366676442 := by decide
theorem cert_e598343420890 : check e598343420890 [[],[.left],[]] .smaller = true := by decide
def e598343421166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598343421166 : Closed e598343421166 ∧ code e598343421166 = 2797366676718 := by decide
theorem cert_e598343421166 : check e598343421166 [[],[.left],[]] .smaller = true := by decide
def e598343421174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598343421174 : Closed e598343421174 ∧ code e598343421174 = 2797366676726 := by decide
theorem cert_e598343421174 : check e598343421174 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor41
