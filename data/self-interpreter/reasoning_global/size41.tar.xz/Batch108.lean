import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602499502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605602499502 : Closed e605602499502 ∧ code e605602499502 = 2804625755054 := by decide
theorem cert_e605602499502 : check e605602499502 [[],[]] .chain = true := by decide
def e605602499514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605602499514 : Closed e605602499514 ∧ code e605602499514 = 2804625755066 := by decide
theorem cert_e605602499514 : check e605602499514 [[],[]] .chain = true := by decide
def e605602499542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605602499542 : Closed e605602499542 ∧ code e605602499542 = 2804625755094 := by decide
theorem cert_e605602499542 : check e605602499542 [[],[]] .chain = true := by decide
def e605602499546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605602499546 : Closed e605602499546 ∧ code e605602499546 = 2804625755098 := by decide
theorem cert_e605602499546 : check e605602499546 [[],[]] .chain = true := by decide
def e605602499822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605602499822 : Closed e605602499822 ∧ code e605602499822 = 2804625755374 := by decide
theorem cert_e605602499822 : check e605602499822 [[],[]] .chain = true := by decide
def e605602499830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605602499830 : Closed e605602499830 ∧ code e605602499830 = 2804625755382 := by decide
theorem cert_e605602499830 : check e605602499830 [[],[]] .chain = true := by decide
def e605602500206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605602500206 : Closed e605602500206 ∧ code e605602500206 = 2804625755758 := by decide
theorem cert_e605602500206 : check e605602500206 [[],[]] .chain = true := by decide
def e605602500218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605602500218 : Closed e605602500218 ∧ code e605602500218 = 2804625755770 := by decide
theorem cert_e605602500218 : check e605602500218 [[],[]] .chain = true := by decide
def e605602500382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e605602500382 : Closed e605602500382 ∧ code e605602500382 = 2804625755934 := by decide
theorem cert_e605602500382 : checkPay e605602500382 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602500406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605602500406 : Closed e605602500406 ∧ code e605602500406 = 2804625755958 := by decide
theorem cert_e605602500406 : check e605602500406 [[],[]] .chain = true := by decide
def e605602500410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605602500410 : Closed e605602500410 ∧ code e605602500410 = 2804625755962 := by decide
theorem cert_e605602500410 : check e605602500410 [[],[]] .chain = true := by decide
def e605602505182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605602505182 : Closed e605602505182 ∧ code e605602505182 = 2804625760734 := by decide
theorem cert_e605602505182 : check e605602505182 [[],[]] .chain = true := by decide
def e605602505206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605602505206 : Closed e605602505206 ∧ code e605602505206 = 2804625760758 := by decide
theorem cert_e605602505206 : check e605602505206 [[],[]] .chain = true := by decide
def e605602506158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605602506158 : Closed e605602506158 ∧ code e605602506158 = 2804625761710 := by decide
theorem cert_e605602506158 : check e605602506158 [[],[]] .chain = true := by decide
def e605602506170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605602506170 : Closed e605602506170 ∧ code e605602506170 = 2804625761722 := by decide
theorem cert_e605602506170 : check e605602506170 [[],[]] .chain = true := by decide
def e605602506218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605602506218 : Closed e605602506218 ∧ code e605602506218 = 2804625761770 := by decide
theorem cert_e605602506218 : check e605602506218 [[],[]] .chain = true := by decide
def e605602506350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605602506350 : Closed e605602506350 ∧ code e605602506350 = 2804625761902 := by decide
theorem cert_e605602506350 : check e605602506350 [[],[]] .chain = true := by decide
def e605602506362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605602506362 : Closed e605602506362 ∧ code e605602506362 = 2804625761914 := by decide
theorem cert_e605602506362 : check e605602506362 [[],[]] .chain = true := by decide
def e605602506650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605602506650 : Closed e605602506650 ∧ code e605602506650 = 2804625762202 := by decide
theorem cert_e605602506650 : check e605602506650 [[],[]] .chain = true := by decide
def e605602509038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605602509038 : Closed e605602509038 ∧ code e605602509038 = 2804625764590 := by decide
theorem cert_e605602509038 : check e605602509038 [[],[]] .chain = true := by decide
def e605602509046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605602509046 : Closed e605602509046 ∧ code e605602509046 = 2804625764598 := by decide
theorem cert_e605602509046 : check e605602509046 [[],[]] .chain = true := by decide
def e605602509526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605602509526 : Closed e605602509526 ∧ code e605602509526 = 2804625765078 := by decide
theorem cert_e605602509526 : check e605602509526 [[],[]] .chain = true := by decide
def e605602509530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605602509530 : Closed e605602509530 ∧ code e605602509530 = 2804625765082 := by decide
theorem cert_e605602509530 : check e605602509530 [[],[]] .chain = true := by decide
def e605602509546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605602509546 : Closed e605602509546 ∧ code e605602509546 = 2804625765098 := by decide
theorem cert_e605602509546 : check e605602509546 [[],[]] .chain = true := by decide
def e605602509598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605602509598 : Closed e605602509598 ∧ code e605602509598 = 2804625765150 := by decide
theorem cert_e605602509598 : checkPay e605602509598 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602509622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605602509622 : Closed e605602509622 ∧ code e605602509622 = 2804625765174 := by decide
theorem cert_e605602509622 : check e605602509622 [[],[]] .chain = true := by decide
def e605602509626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605602509626 : Closed e605602509626 ∧ code e605602509626 = 2804625765178 := by decide
theorem cert_e605602509626 : check e605602509626 [[],[]] .chain = true := by decide
def e605602509722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605602509722 : Closed e605602509722 ∧ code e605602509722 = 2804625765274 := by decide
theorem cert_e605602509722 : check e605602509722 [[],[]] .chain = true := by decide
def e605602509766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605602509766 : Closed e605602509766 ∧ code e605602509766 = 2804625765318 := by decide
theorem cert_e605602509766 : checkPay e605602509766 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602536110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e605602536110 : Closed e605602536110 ∧ code e605602536110 = 2804625791662 := by decide
theorem cert_e605602536110 : check e605602536110 [[],[]] .chain = true := by decide
def e605602536122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e605602536122 : Closed e605602536122 ∧ code e605602536122 = 2804625791674 := by decide
theorem cert_e605602536122 : check e605602536122 [[],[]] .chain = true := by decide
def e605602536170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e605602536170 : Closed e605602536170 ∧ code e605602536170 = 2804625791722 := by decide
theorem cert_e605602536170 : check e605602536170 [[],[]] .chain = true := by decide
def e605602536362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605602536362 : Closed e605602536362 ∧ code e605602536362 = 2804625791914 := by decide
theorem cert_e605602536362 : check e605602536362 [[],[]] .chain = true := by decide
def e605602537130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605602537130 : Closed e605602537130 ∧ code e605602537130 = 2804625792682 := by decide
theorem cert_e605602537130 : check e605602537130 [[],[]] .chain = true := by decide
def e605602537646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.var 2))))))
theorem wire_e605602537646 : Closed e605602537646 ∧ code e605602537646 = 2804625793198 := by decide
theorem cert_e605602537646 : check e605602537646 [[],[]] .chain = true := by decide
def e605602537658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))) (.var 0))))))
theorem wire_e605602537658 : Closed e605602537658 ∧ code e605602537658 = 2804625793210 := by decide
theorem cert_e605602537658 : check e605602537658 [[],[]] .chain = true := by decide
def e605602538222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 2))))))
theorem wire_e605602538222 : Closed e605602538222 ∧ code e605602538222 = 2804625793774 := by decide
theorem cert_e605602538222 : checkPay e605602538222 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[]] = true := by decide
def e605602538350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e605602538350 : Closed e605602538350 ∧ code e605602538350 = 2804625793902 := by decide
theorem cert_e605602538350 : check e605602538350 [[],[]] .chain = true := by decide
def e605602538358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e605602538358 : Closed e605602538358 ∧ code e605602538358 = 2804625793910 := by decide
theorem cert_e605602538358 : check e605602538358 [[],[]] .chain = true := by decide
def e605602538414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e605602538414 : Closed e605602538414 ∧ code e605602538414 = 2804625793966 := by decide
theorem cert_e605602538414 : check e605602538414 [[],[]] .chain = true := by decide
def e605602538426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e605602538426 : Closed e605602538426 ∧ code e605602538426 = 2804625793978 := by decide
theorem cert_e605602538426 : check e605602538426 [[],[]] .chain = true := by decide
def e605602538454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e605602538454 : Closed e605602538454 ∧ code e605602538454 = 2804625794006 := by decide
theorem cert_e605602538454 : check e605602538454 [[],[]] .chain = true := by decide
def e605602538458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e605602538458 : Closed e605602538458 ∧ code e605602538458 = 2804625794010 := by decide
theorem cert_e605602538458 : check e605602538458 [[],[]] .chain = true := by decide
def e605602539182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e605602539182 : Closed e605602539182 ∧ code e605602539182 = 2804625794734 := by decide
theorem cert_e605602539182 : check e605602539182 [[],[]] .chain = true := by decide
def e605602539194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e605602539194 : Closed e605602539194 ∧ code e605602539194 = 2804625794746 := by decide
theorem cert_e605602539194 : check e605602539194 [[],[]] .chain = true := by decide
def e605602539242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e605602539242 : Closed e605602539242 ∧ code e605602539242 = 2804625794794 := by decide
theorem cert_e605602539242 : check e605602539242 [[],[]] .chain = true := by decide
def e605602539434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e605602539434 : Closed e605602539434 ∧ code e605602539434 = 2804625794986 := by decide
theorem cert_e605602539434 : check e605602539434 [[],[]] .chain = true := by decide
def e605602539566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602539566 : Closed e605602539566 ∧ code e605602539566 = 2804625795118 := by decide
theorem cert_e605602539566 : check e605602539566 [[],[]] .chain = true := by decide
def e605602539758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e605602539758 : Closed e605602539758 ∧ code e605602539758 = 2804625795310 := by decide
theorem cert_e605602539758 : check e605602539758 [[],[]] .chain = true := by decide
def e605602539766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e605602539766 : Closed e605602539766 ∧ code e605602539766 = 2804625795318 := by decide
theorem cert_e605602539766 : check e605602539766 [[],[]] .chain = true := by decide
def e605602539950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e605602539950 : Closed e605602539950 ∧ code e605602539950 = 2804625795502 := by decide
theorem cert_e605602539950 : check e605602539950 [[],[]] .chain = true := by decide
def e605602539962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605602539962 : Closed e605602539962 ∧ code e605602539962 = 2804625795514 := by decide
theorem cert_e605602539962 : check e605602539962 [[],[]] .chain = true := by decide
def e605602540010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605602540010 : Closed e605602540010 ∧ code e605602540010 = 2804625795562 := by decide
theorem cert_e605602540010 : check e605602540010 [[],[]] .chain = true := by decide
def e605602540142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602540142 : Closed e605602540142 ∧ code e605602540142 = 2804625795694 := by decide
theorem cert_e605602540142 : check e605602540142 [[],[]] .chain = true := by decide
def e605602540154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602540154 : Closed e605602540154 ∧ code e605602540154 = 2804625795706 := by decide
theorem cert_e605602540154 : check e605602540154 [[],[]] .chain = true := by decide
def e605602540318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e605602540318 : Closed e605602540318 ∧ code e605602540318 = 2804625795870 := by decide
theorem cert_e605602540318 : check e605602540318 [[],[]] .chain = true := by decide
def e605602540418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e605602540418 : Closed e605602540418 ∧ code e605602540418 = 2804625795970 := by decide
theorem cert_e605602540418 : check e605602540418 [[],[]] .chain = true := by decide
def e605602540430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e605602540430 : Closed e605602540430 ∧ code e605602540430 = 2804625795982 := by decide
theorem cert_e605602540430 : check e605602540430 [[],[]] .chain = true := by decide
def e605602540442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602540442 : Closed e605602540442 ∧ code e605602540442 = 2804625795994 := by decide
theorem cert_e605602540442 : check e605602540442 [[],[]] .chain = true := by decide
def e605602540654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e605602540654 : Closed e605602540654 ∧ code e605602540654 = 2804625796206 := by decide
theorem cert_e605602540654 : check e605602540654 [[],[]] .chain = true := by decide
def e605602540666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e605602540666 : Closed e605602540666 ∧ code e605602540666 = 2804625796218 := by decide
theorem cert_e605602540666 : check e605602540666 [[],[]] .chain = true := by decide
def e605602540830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e605602540830 : Closed e605602540830 ∧ code e605602540830 = 2804625796382 := by decide
theorem cert_e605602540830 : check e605602540830 [[],[]] .chain = true := by decide
def e605602540998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e605602540998 : Closed e605602540998 ∧ code e605602540998 = 2804625796550 := by decide
theorem cert_e605602540998 : check e605602540998 [[],[]] .chain = true := by decide
def e605602541066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602541066 : Closed e605602541066 ∧ code e605602541066 = 2804625796618 := by decide
theorem cert_e605602541066 : check e605602541066 [[],[]] .chain = true := by decide
def e605602541102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605602541102 : Closed e605602541102 ∧ code e605602541102 = 2804625796654 := by decide
theorem cert_e605602541102 : checkPay e605602541102 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602541110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605602541110 : Closed e605602541110 ∧ code e605602541110 = 2804625796662 := by decide
theorem cert_e605602541110 : check e605602541110 [[],[]] .chain = true := by decide
def e605602541114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605602541114 : Closed e605602541114 ∧ code e605602541114 = 2804625796666 := by decide
theorem cert_e605602541114 : check e605602541114 [[],[]] .chain = true := by decide
def e605602541162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605602541162 : Closed e605602541162 ∧ code e605602541162 = 2804625796714 := by decide
theorem cert_e605602541162 : check e605602541162 [[],[]] .chain = true := by decide
def e605602541186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605602541186 : Closed e605602541186 ∧ code e605602541186 = 2804625796738 := by decide
theorem cert_e605602541186 : check e605602541186 [[],[]] .chain = true := by decide
def e605602541198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605602541198 : Closed e605602541198 ∧ code e605602541198 = 2804625796750 := by decide
theorem cert_e605602541198 : check e605602541198 [[],[]] .chain = true := by decide
def e605602541210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602541210 : Closed e605602541210 ∧ code e605602541210 = 2804625796762 := by decide
theorem cert_e605602541210 : check e605602541210 [[],[]] .chain = true := by decide
def e605602541254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605602541254 : Closed e605602541254 ∧ code e605602541254 = 2804625796806 := by decide
theorem cert_e605602541254 : check e605602541254 [[],[]] .chain = true := by decide
def e605602541282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605602541282 : Closed e605602541282 ∧ code e605602541282 = 2804625796834 := by decide
theorem cert_e605602541282 : checkPay e605602541282 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e605602541294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 2))))))
theorem wire_e605602541294 : Closed e605602541294 ∧ code e605602541294 = 2804625796846 := by decide
theorem cert_e605602541294 : checkPay e605602541294 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e605602541998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e605602541998 : Closed e605602541998 ∧ code e605602541998 = 2804625797550 := by decide
theorem cert_e605602541998 : check e605602541998 [[],[]] .chain = true := by decide
def e605602542010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e605602542010 : Closed e605602542010 ∧ code e605602542010 = 2804625797562 := by decide
theorem cert_e605602542010 : check e605602542010 [[],[]] .chain = true := by decide
def e605602542058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e605602542058 : Closed e605602542058 ∧ code e605602542058 = 2804625797610 := by decide
theorem cert_e605602542058 : check e605602542058 [[],[]] .chain = true := by decide
def e605602542702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e605602542702 : Closed e605602542702 ∧ code e605602542702 = 2804625798254 := by decide
theorem cert_e605602542702 : check e605602542702 [[],[]] .chain = true := by decide
def e605602542714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e605602542714 : Closed e605602542714 ∧ code e605602542714 = 2804625798266 := by decide
theorem cert_e605602542714 : check e605602542714 [[],[]] .chain = true := by decide
def e605602542878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e605602542878 : Closed e605602542878 ∧ code e605602542878 = 2804625798430 := by decide
theorem cert_e605602542878 : check e605602542878 [[],[]] .chain = true := by decide
def e605602543046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e605602543046 : Closed e605602543046 ∧ code e605602543046 = 2804625798598 := by decide
theorem cert_e605602543046 : check e605602543046 [[],[]] .chain = true := by decide
def e605602543386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e605602543386 : Closed e605602543386 ∧ code e605602543386 = 2804625798938 := by decide
theorem cert_e605602543386 : check e605602543386 [[],[]] .chain = true := by decide
def e605602543430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e605602543430 : Closed e605602543430 ∧ code e605602543430 = 2804625798982 := by decide
theorem cert_e605602543430 : check e605602543430 [[],[]] .chain = true := by decide
def e605602543658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))) (.var 0))))))
theorem wire_e605602543658 : Closed e605602543658 ∧ code e605602543658 = 2804625799210 := by decide
theorem cert_e605602543658 : check e605602543658 [[],[]] .chain = true := by decide
def e605602543790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e605602543790 : Closed e605602543790 ∧ code e605602543790 = 2804625799342 := by decide
theorem cert_e605602543790 : checkPay e605602543790 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] = true := by decide
def e605602543802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e605602543802 : Closed e605602543802 ∧ code e605602543802 = 2804625799354 := by decide
theorem cert_e605602543802 : checkPay e605602543802 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right]] = true := by decide
def e605602543830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e605602543830 : Closed e605602543830 ∧ code e605602543830 = 2804625799382 := by decide
theorem cert_e605602543830 : check e605602543830 [[],[]] .chain = true := by decide
def e605602543834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e605602543834 : Closed e605602543834 ∧ code e605602543834 = 2804625799386 := by decide
theorem cert_e605602543834 : check e605602543834 [[],[]] .chain = true := by decide
def e605602543850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e605602543850 : Closed e605602543850 ∧ code e605602543850 = 2804625799402 := by decide
theorem cert_e605602543850 : check e605602543850 [[],[]] .chain = true := by decide
def e605602544042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e605602544042 : Closed e605602544042 ∧ code e605602544042 = 2804625799594 := by decide
theorem cert_e605602544042 : check e605602544042 [[],[]] .chain = true := by decide
def e605602544138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602544138 : Closed e605602544138 ∧ code e605602544138 = 2804625799690 := by decide
theorem cert_e605602544138 : check e605602544138 [[],[]] .chain = true := by decide
def e605602544174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605602544174 : Closed e605602544174 ∧ code e605602544174 = 2804625799726 := by decide
theorem cert_e605602544174 : checkPay e605602544174 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left]] = true := by decide
def e605602544182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605602544182 : Closed e605602544182 ∧ code e605602544182 = 2804625799734 := by decide
theorem cert_e605602544182 : check e605602544182 [[],[]] .chain = true := by decide
def e605602544186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605602544186 : Closed e605602544186 ∧ code e605602544186 = 2804625799738 := by decide
theorem cert_e605602544186 : check e605602544186 [[],[]] .chain = true := by decide
def e605602544234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605602544234 : Closed e605602544234 ∧ code e605602544234 = 2804625799786 := by decide
theorem cert_e605602544234 : check e605602544234 [[],[]] .chain = true := by decide
def e605602544258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605602544258 : Closed e605602544258 ∧ code e605602544258 = 2804625799810 := by decide
theorem cert_e605602544258 : check e605602544258 [[],[]] .chain = true := by decide
def e605602544270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605602544270 : Closed e605602544270 ∧ code e605602544270 = 2804625799822 := by decide
theorem cert_e605602544270 : check e605602544270 [[],[]] .chain = true := by decide
def e605602544282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602544282 : Closed e605602544282 ∧ code e605602544282 = 2804625799834 := by decide
theorem cert_e605602544282 : check e605602544282 [[],[]] .chain = true := by decide
def e605602544326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605602544326 : Closed e605602544326 ∧ code e605602544326 = 2804625799878 := by decide
theorem cert_e605602544326 : check e605602544326 [[],[]] .chain = true := by decide
def e605602544354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605602544354 : Closed e605602544354 ∧ code e605602544354 = 2804625799906 := by decide
theorem cert_e605602544354 : checkPay e605602544354 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.right,.left]] = true := by decide
def e605602544366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e605602544366 : Closed e605602544366 ∧ code e605602544366 = 2804625799918 := by decide
theorem cert_e605602544366 : checkPay e605602544366 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.right,.left],[.under,.under,.right,.left]] = true := by decide
def e605602544410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e605602544410 : Closed e605602544410 ∧ code e605602544410 = 2804625799962 := by decide
theorem cert_e605602544410 : check e605602544410 [[],[]] .chain = true := by decide
def e605602544454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e605602544454 : Closed e605602544454 ∧ code e605602544454 = 2804625800006 := by decide
theorem cert_e605602544454 : check e605602544454 [[],[]] .chain = true := by decide
def e605602544522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e605602544522 : Closed e605602544522 ∧ code e605602544522 = 2804625800074 := by decide
theorem cert_e605602544522 : checkPay e605602544522 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602544546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e605602544546 : Closed e605602544546 ∧ code e605602544546 = 2804625800098 := by decide
theorem cert_e605602544546 : checkPay e605602544546 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602544558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e605602544558 : Closed e605602544558 ∧ code e605602544558 = 2804625800110 := by decide
theorem cert_e605602544558 : checkPay e605602544558 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602544570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e605602544570 : Closed e605602544570 ∧ code e605602544570 = 2804625800122 := by decide
theorem cert_e605602544570 : checkPay e605602544570 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602546094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e605602546094 : Closed e605602546094 ∧ code e605602546094 = 2804625801646 := by decide
theorem cert_e605602546094 : checkPay e605602546094 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e605602546286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602546286 : Closed e605602546286 ∧ code e605602546286 = 2804625801838 := by decide
theorem cert_e605602546286 : check e605602546286 [[],[]] .chain = true := by decide
def e605602546298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602546298 : Closed e605602546298 ∧ code e605602546298 = 2804625801850 := by decide
theorem cert_e605602546298 : check e605602546298 [[],[]] .chain = true := by decide
def e605602546670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 2))))))
theorem wire_e605602546670 : Closed e605602546670 ∧ code e605602546670 = 2804625802222 := by decide
theorem cert_e605602546670 : checkPay e605602546670 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e605602547438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e605602547438 : Closed e605602547438 ∧ code e605602547438 = 2804625802990 := by decide
theorem cert_e605602547438 : check e605602547438 [[],[]] .chain = true := by decide
def e605602547446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e605602547446 : Closed e605602547446 ∧ code e605602547446 = 2804625802998 := by decide
theorem cert_e605602547446 : check e605602547446 [[],[]] .chain = true := by decide
def e605602547566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e605602547566 : Closed e605602547566 ∧ code e605602547566 = 2804625803118 := by decide
theorem cert_e605602547566 : check e605602547566 [[],[]] .chain = true := by decide
def e605602547578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e605602547578 : Closed e605602547578 ∧ code e605602547578 = 2804625803130 := by decide
theorem cert_e605602547578 : check e605602547578 [[],[]] .chain = true := by decide
def e605602547630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e605602547630 : Closed e605602547630 ∧ code e605602547630 = 2804625803182 := by decide
theorem cert_e605602547630 : check e605602547630 [[],[]] .chain = true := by decide
def e605602547670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e605602547670 : Closed e605602547670 ∧ code e605602547670 = 2804625803222 := by decide
theorem cert_e605602547670 : check e605602547670 [[],[]] .chain = true := by decide
def e605602547674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e605602547674 : Closed e605602547674 ∧ code e605602547674 = 2804625803226 := by decide
theorem cert_e605602547674 : check e605602547674 [[],[]] .chain = true := by decide
def e605602548206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602548206 : Closed e605602548206 ∧ code e605602548206 = 2804625803758 := by decide
theorem cert_e605602548206 : checkPay e605602548206 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e605602548974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602548974 : Closed e605602548974 ∧ code e605602548974 = 2804625804526 := by decide
theorem cert_e605602548974 : check e605602548974 [[],[]] .chain = true := by decide
def e605602548982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602548982 : Closed e605602548982 ∧ code e605602548982 = 2804625804534 := by decide
theorem cert_e605602548982 : check e605602548982 [[],[]] .chain = true := by decide
def e605602549358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602549358 : Closed e605602549358 ∧ code e605602549358 = 2804625804910 := by decide
theorem cert_e605602549358 : check e605602549358 [[],[]] .chain = true := by decide
def e605602549370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602549370 : Closed e605602549370 ∧ code e605602549370 = 2804625804922 := by decide
theorem cert_e605602549370 : check e605602549370 [[],[]] .chain = true := by decide
def e605602549534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 3)))))))
theorem wire_e605602549534 : Closed e605602549534 ∧ code e605602549534 = 2804625805086 := by decide
theorem cert_e605602549534 : checkPay e605602549534 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e605602549558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602549558 : Closed e605602549558 ∧ code e605602549558 = 2804625805110 := by decide
theorem cert_e605602549558 : check e605602549558 [[],[]] .chain = true := by decide
def e605602549562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602549562 : Closed e605602549562 ∧ code e605602549562 = 2804625805114 := by decide
theorem cert_e605602549562 : check e605602549562 [[],[]] .chain = true := by decide
def e605602551470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e605602551470 : Closed e605602551470 ∧ code e605602551470 = 2804625807022 := by decide
theorem cert_e605602551470 : check e605602551470 [[],[]] .chain = true := by decide
def e605602551482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605602551482 : Closed e605602551482 ∧ code e605602551482 = 2804625807034 := by decide
theorem cert_e605602551482 : check e605602551482 [[],[]] .chain = true := by decide
def e605602551530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605602551530 : Closed e605602551530 ∧ code e605602551530 = 2804625807082 := by decide
theorem cert_e605602551530 : check e605602551530 [[],[]] .chain = true := by decide
def e605602551722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e605602551722 : Closed e605602551722 ∧ code e605602551722 = 2804625807274 := by decide
theorem cert_e605602551722 : check e605602551722 [[],[]] .chain = true := by decide
def e605602551854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e605602551854 : Closed e605602551854 ∧ code e605602551854 = 2804625807406 := by decide
theorem cert_e605602551854 : check e605602551854 [[],[]] .chain = true := by decide
def e605602552046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e605602552046 : Closed e605602552046 ∧ code e605602552046 = 2804625807598 := by decide
theorem cert_e605602552046 : check e605602552046 [[],[]] .chain = true := by decide
def e605602552054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e605602552054 : Closed e605602552054 ∧ code e605602552054 = 2804625807606 := by decide
theorem cert_e605602552054 : check e605602552054 [[],[]] .chain = true := by decide
def e605602552238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e605602552238 : Closed e605602552238 ∧ code e605602552238 = 2804625807790 := by decide
theorem cert_e605602552238 : check e605602552238 [[],[]] .chain = true := by decide
def e605602552250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605602552250 : Closed e605602552250 ∧ code e605602552250 = 2804625807802 := by decide
theorem cert_e605602552250 : check e605602552250 [[],[]] .chain = true := by decide
def e605602552298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605602552298 : Closed e605602552298 ∧ code e605602552298 = 2804625807850 := by decide
theorem cert_e605602552298 : check e605602552298 [[],[]] .chain = true := by decide
def e605602552430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602552430 : Closed e605602552430 ∧ code e605602552430 = 2804625807982 := by decide
theorem cert_e605602552430 : check e605602552430 [[],[]] .chain = true := by decide
def e605602552442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602552442 : Closed e605602552442 ∧ code e605602552442 = 2804625807994 := by decide
theorem cert_e605602552442 : check e605602552442 [[],[]] .chain = true := by decide
def e605602552606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e605602552606 : Closed e605602552606 ∧ code e605602552606 = 2804625808158 := by decide
theorem cert_e605602552606 : check e605602552606 [[],[]] .chain = true := by decide
def e605602552706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602552706 : Closed e605602552706 ∧ code e605602552706 = 2804625808258 := by decide
theorem cert_e605602552706 : check e605602552706 [[],[]] .chain = true := by decide
def e605602552718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e605602552718 : Closed e605602552718 ∧ code e605602552718 = 2804625808270 := by decide
theorem cert_e605602552718 : check e605602552718 [[],[]] .chain = true := by decide
def e605602552730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602552730 : Closed e605602552730 ∧ code e605602552730 = 2804625808282 := by decide
theorem cert_e605602552730 : check e605602552730 [[],[]] .chain = true := by decide
def e605602552942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e605602552942 : Closed e605602552942 ∧ code e605602552942 = 2804625808494 := by decide
theorem cert_e605602552942 : check e605602552942 [[],[]] .chain = true := by decide
def e605602552954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e605602552954 : Closed e605602552954 ∧ code e605602552954 = 2804625808506 := by decide
theorem cert_e605602552954 : check e605602552954 [[],[]] .chain = true := by decide
def e605602553118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e605602553118 : Closed e605602553118 ∧ code e605602553118 = 2804625808670 := by decide
theorem cert_e605602553118 : check e605602553118 [[],[]] .chain = true := by decide
def e605602553286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e605602553286 : Closed e605602553286 ∧ code e605602553286 = 2804625808838 := by decide
theorem cert_e605602553286 : check e605602553286 [[],[]] .chain = true := by decide
def e605602553354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e605602553354 : Closed e605602553354 ∧ code e605602553354 = 2804625808906 := by decide
theorem cert_e605602553354 : check e605602553354 [[],[]] .chain = true := by decide
def e605602553390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602553390 : Closed e605602553390 ∧ code e605602553390 = 2804625808942 := by decide
theorem cert_e605602553390 : checkPay e605602553390 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[]] = true := by decide
def e605602553398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e605602553398 : Closed e605602553398 ∧ code e605602553398 = 2804625808950 := by decide
theorem cert_e605602553398 : check e605602553398 [[],[]] .chain = true := by decide
def e605602553402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e605602553402 : Closed e605602553402 ∧ code e605602553402 = 2804625808954 := by decide
theorem cert_e605602553402 : check e605602553402 [[],[]] .chain = true := by decide
def e605602553450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605602553450 : Closed e605602553450 ∧ code e605602553450 = 2804625809002 := by decide
theorem cert_e605602553450 : check e605602553450 [[],[]] .chain = true := by decide
def e605602553474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602553474 : Closed e605602553474 ∧ code e605602553474 = 2804625809026 := by decide
theorem cert_e605602553474 : check e605602553474 [[],[]] .chain = true := by decide
def e605602553486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e605602553486 : Closed e605602553486 ∧ code e605602553486 = 2804625809038 := by decide
theorem cert_e605602553486 : check e605602553486 [[],[]] .chain = true := by decide
def e605602553498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602553498 : Closed e605602553498 ∧ code e605602553498 = 2804625809050 := by decide
theorem cert_e605602553498 : check e605602553498 [[],[]] .chain = true := by decide
def e605602553542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e605602553542 : Closed e605602553542 ∧ code e605602553542 = 2804625809094 := by decide
theorem cert_e605602553542 : check e605602553542 [[],[]] .chain = true := by decide
def e605602553570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605602553570 : Closed e605602553570 ∧ code e605602553570 = 2804625809122 := by decide
theorem cert_e605602553570 : checkPay e605602553570 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e605602553582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e605602553582 : Closed e605602553582 ∧ code e605602553582 = 2804625809134 := by decide
theorem cert_e605602553582 : checkPay e605602553582 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e605602554334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605602554334 : Closed e605602554334 ∧ code e605602554334 = 2804625809886 := by decide
theorem cert_e605602554334 : check e605602554334 [[],[]] .chain = true := by decide
def e605602554358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605602554358 : Closed e605602554358 ∧ code e605602554358 = 2804625809910 := by decide
theorem cert_e605602554358 : check e605602554358 [[],[]] .chain = true := by decide
def e605602555310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605602555310 : Closed e605602555310 ∧ code e605602555310 = 2804625810862 := by decide
theorem cert_e605602555310 : check e605602555310 [[],[]] .chain = true := by decide
end Blc.Floor41
