import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602153082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602153082 : Closed e605602153082 ∧ code e605602153082 = 2804625408634 := by decide
theorem cert_e605602153082 : check e605602153082 [[],[]] .chain = true := by decide
def e605602153454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 2))))))
theorem wire_e605602153454 : Closed e605602153454 ∧ code e605602153454 = 2804625409006 := by decide
theorem cert_e605602153454 : check e605602153454 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602154222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e605602154222 : Closed e605602154222 ∧ code e605602154222 = 2804625409774 := by decide
theorem cert_e605602154222 : check e605602154222 [[],[]] .chain = true := by decide
def e605602154230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e605602154230 : Closed e605602154230 ∧ code e605602154230 = 2804625409782 := by decide
theorem cert_e605602154230 : check e605602154230 [[],[]] .chain = true := by decide
def e605602154350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e605602154350 : Closed e605602154350 ∧ code e605602154350 = 2804625409902 := by decide
theorem cert_e605602154350 : check e605602154350 [[],[]] .chain = true := by decide
def e605602154362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e605602154362 : Closed e605602154362 ∧ code e605602154362 = 2804625409914 := by decide
theorem cert_e605602154362 : check e605602154362 [[],[]] .chain = true := by decide
def e605602154414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e605602154414 : Closed e605602154414 ∧ code e605602154414 = 2804625409966 := by decide
theorem cert_e605602154414 : check e605602154414 [[],[]] .chain = true := by decide
def e605602154454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e605602154454 : Closed e605602154454 ∧ code e605602154454 = 2804625410006 := by decide
theorem cert_e605602154454 : check e605602154454 [[],[]] .chain = true := by decide
def e605602154458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e605602154458 : Closed e605602154458 ∧ code e605602154458 = 2804625410010 := by decide
theorem cert_e605602154458 : check e605602154458 [[],[]] .chain = true := by decide
def e605602154990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602154990 : Closed e605602154990 ∧ code e605602154990 = 2804625410542 := by decide
theorem cert_e605602154990 : check e605602154990 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602155758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602155758 : Closed e605602155758 ∧ code e605602155758 = 2804625411310 := by decide
theorem cert_e605602155758 : check e605602155758 [[],[]] .chain = true := by decide
def e605602155766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602155766 : Closed e605602155766 ∧ code e605602155766 = 2804625411318 := by decide
theorem cert_e605602155766 : check e605602155766 [[],[]] .chain = true := by decide
def e605602156142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602156142 : Closed e605602156142 ∧ code e605602156142 = 2804625411694 := by decide
theorem cert_e605602156142 : check e605602156142 [[],[]] .chain = true := by decide
def e605602156154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602156154 : Closed e605602156154 ∧ code e605602156154 = 2804625411706 := by decide
theorem cert_e605602156154 : check e605602156154 [[],[]] .chain = true := by decide
def e605602156318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 3)))))))
theorem wire_e605602156318 : Closed e605602156318 ∧ code e605602156318 = 2804625411870 := by decide
theorem cert_e605602156318 : check e605602156318 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602156342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602156342 : Closed e605602156342 ∧ code e605602156342 = 2804625411894 := by decide
theorem cert_e605602156342 : check e605602156342 [[],[]] .chain = true := by decide
def e605602156346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602156346 : Closed e605602156346 ∧ code e605602156346 = 2804625411898 := by decide
theorem cert_e605602156346 : check e605602156346 [[],[]] .chain = true := by decide
def e605602158254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e605602158254 : Closed e605602158254 ∧ code e605602158254 = 2804625413806 := by decide
theorem cert_e605602158254 : check e605602158254 [[],[]] .chain = true := by decide
def e605602158266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605602158266 : Closed e605602158266 ∧ code e605602158266 = 2804625413818 := by decide
theorem cert_e605602158266 : check e605602158266 [[],[]] .chain = true := by decide
def e605602158314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605602158314 : Closed e605602158314 ∧ code e605602158314 = 2804625413866 := by decide
theorem cert_e605602158314 : check e605602158314 [[],[]] .chain = true := by decide
def e605602158506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e605602158506 : Closed e605602158506 ∧ code e605602158506 = 2804625414058 := by decide
theorem cert_e605602158506 : check e605602158506 [[],[]] .chain = true := by decide
def e605602158638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e605602158638 : Closed e605602158638 ∧ code e605602158638 = 2804625414190 := by decide
theorem cert_e605602158638 : check e605602158638 [[],[]] .chain = true := by decide
def e605602158830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e605602158830 : Closed e605602158830 ∧ code e605602158830 = 2804625414382 := by decide
theorem cert_e605602158830 : check e605602158830 [[],[]] .chain = true := by decide
def e605602158838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e605602158838 : Closed e605602158838 ∧ code e605602158838 = 2804625414390 := by decide
theorem cert_e605602158838 : check e605602158838 [[],[]] .chain = true := by decide
def e605602159022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e605602159022 : Closed e605602159022 ∧ code e605602159022 = 2804625414574 := by decide
theorem cert_e605602159022 : check e605602159022 [[],[]] .chain = true := by decide
def e605602159034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605602159034 : Closed e605602159034 ∧ code e605602159034 = 2804625414586 := by decide
theorem cert_e605602159034 : check e605602159034 [[],[]] .chain = true := by decide
def e605602159082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605602159082 : Closed e605602159082 ∧ code e605602159082 = 2804625414634 := by decide
theorem cert_e605602159082 : check e605602159082 [[],[]] .chain = true := by decide
def e605602159214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602159214 : Closed e605602159214 ∧ code e605602159214 = 2804625414766 := by decide
theorem cert_e605602159214 : check e605602159214 [[],[]] .chain = true := by decide
def e605602159226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602159226 : Closed e605602159226 ∧ code e605602159226 = 2804625414778 := by decide
theorem cert_e605602159226 : check e605602159226 [[],[]] .chain = true := by decide
def e605602159390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e605602159390 : Closed e605602159390 ∧ code e605602159390 = 2804625414942 := by decide
theorem cert_e605602159390 : check e605602159390 [[],[]] .chain = true := by decide
def e605602159490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602159490 : Closed e605602159490 ∧ code e605602159490 = 2804625415042 := by decide
theorem cert_e605602159490 : check e605602159490 [[],[]] .chain = true := by decide
def e605602159502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e605602159502 : Closed e605602159502 ∧ code e605602159502 = 2804625415054 := by decide
theorem cert_e605602159502 : check e605602159502 [[],[]] .chain = true := by decide
def e605602159514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602159514 : Closed e605602159514 ∧ code e605602159514 = 2804625415066 := by decide
theorem cert_e605602159514 : check e605602159514 [[],[]] .chain = true := by decide
def e605602159726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e605602159726 : Closed e605602159726 ∧ code e605602159726 = 2804625415278 := by decide
theorem cert_e605602159726 : check e605602159726 [[],[]] .chain = true := by decide
def e605602159738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e605602159738 : Closed e605602159738 ∧ code e605602159738 = 2804625415290 := by decide
theorem cert_e605602159738 : check e605602159738 [[],[]] .chain = true := by decide
def e605602159902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e605602159902 : Closed e605602159902 ∧ code e605602159902 = 2804625415454 := by decide
theorem cert_e605602159902 : check e605602159902 [[],[]] .chain = true := by decide
def e605602160070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e605602160070 : Closed e605602160070 ∧ code e605602160070 = 2804625415622 := by decide
theorem cert_e605602160070 : check e605602160070 [[],[]] .chain = true := by decide
def e605602160138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e605602160138 : Closed e605602160138 ∧ code e605602160138 = 2804625415690 := by decide
theorem cert_e605602160138 : check e605602160138 [[],[]] .chain = true := by decide
def e605602160174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602160174 : Closed e605602160174 ∧ code e605602160174 = 2804625415726 := by decide
theorem cert_e605602160174 : check e605602160174 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602160182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e605602160182 : Closed e605602160182 ∧ code e605602160182 = 2804625415734 := by decide
theorem cert_e605602160182 : check e605602160182 [[],[]] .chain = true := by decide
def e605602160186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e605602160186 : Closed e605602160186 ∧ code e605602160186 = 2804625415738 := by decide
theorem cert_e605602160186 : check e605602160186 [[],[]] .chain = true := by decide
def e605602160234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605602160234 : Closed e605602160234 ∧ code e605602160234 = 2804625415786 := by decide
theorem cert_e605602160234 : check e605602160234 [[],[]] .chain = true := by decide
def e605602160258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602160258 : Closed e605602160258 ∧ code e605602160258 = 2804625415810 := by decide
theorem cert_e605602160258 : check e605602160258 [[],[]] .chain = true := by decide
def e605602160270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e605602160270 : Closed e605602160270 ∧ code e605602160270 = 2804625415822 := by decide
theorem cert_e605602160270 : check e605602160270 [[],[]] .chain = true := by decide
def e605602160282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602160282 : Closed e605602160282 ∧ code e605602160282 = 2804625415834 := by decide
theorem cert_e605602160282 : check e605602160282 [[],[]] .chain = true := by decide
def e605602160326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e605602160326 : Closed e605602160326 ∧ code e605602160326 = 2804625415878 := by decide
theorem cert_e605602160326 : check e605602160326 [[],[]] .chain = true := by decide
def e605602160354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605602160354 : Closed e605602160354 ∧ code e605602160354 = 2804625415906 := by decide
theorem cert_e605602160354 : check e605602160354 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602160366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e605602160366 : Closed e605602160366 ∧ code e605602160366 = 2804625415918 := by decide
theorem cert_e605602160366 : check e605602160366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602161118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605602161118 : Closed e605602161118 ∧ code e605602161118 = 2804625416670 := by decide
theorem cert_e605602161118 : check e605602161118 [[],[]] .chain = true := by decide
def e605602161142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605602161142 : Closed e605602161142 ∧ code e605602161142 = 2804625416694 := by decide
theorem cert_e605602161142 : check e605602161142 [[],[]] .chain = true := by decide
def e605602162094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605602162094 : Closed e605602162094 ∧ code e605602162094 = 2804625417646 := by decide
theorem cert_e605602162094 : check e605602162094 [[],[]] .chain = true := by decide
def e605602162106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605602162106 : Closed e605602162106 ∧ code e605602162106 = 2804625417658 := by decide
theorem cert_e605602162106 : check e605602162106 [[],[]] .chain = true := by decide
def e605602162154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605602162154 : Closed e605602162154 ∧ code e605602162154 = 2804625417706 := by decide
theorem cert_e605602162154 : check e605602162154 [[],[]] .chain = true := by decide
def e605602162286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605602162286 : Closed e605602162286 ∧ code e605602162286 = 2804625417838 := by decide
theorem cert_e605602162286 : check e605602162286 [[],[]] .chain = true := by decide
def e605602162298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605602162298 : Closed e605602162298 ∧ code e605602162298 = 2804625417850 := by decide
theorem cert_e605602162298 : check e605602162298 [[],[]] .chain = true := by decide
def e605602162462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605602162462 : Closed e605602162462 ∧ code e605602162462 = 2804625418014 := by decide
theorem cert_e605602162462 : check e605602162462 [[],[]] .chain = true := by decide
def e605602162562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e605602162562 : Closed e605602162562 ∧ code e605602162562 = 2804625418114 := by decide
theorem cert_e605602162562 : check e605602162562 [[],[]] .chain = true := by decide
def e605602162574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605602162574 : Closed e605602162574 ∧ code e605602162574 = 2804625418126 := by decide
theorem cert_e605602162574 : check e605602162574 [[],[]] .chain = true := by decide
def e605602162586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605602162586 : Closed e605602162586 ∧ code e605602162586 = 2804625418138 := by decide
theorem cert_e605602162586 : check e605602162586 [[],[]] .chain = true := by decide
def e605602164958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e605602164958 : Closed e605602164958 ∧ code e605602164958 = 2804625420510 := by decide
theorem cert_e605602164958 : check e605602164958 [[],[]] .chain = true := by decide
def e605602164986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e605602164986 : Closed e605602164986 ∧ code e605602164986 = 2804625420538 := by decide
theorem cert_e605602164986 : check e605602164986 [[],[]] .chain = true := by decide
def e605602165534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605602165534 : Closed e605602165534 ∧ code e605602165534 = 2804625421086 := by decide
theorem cert_e605602165534 : check e605602165534 [[],[]] .chain = true := by decide
def e605602165702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605602165702 : Closed e605602165702 ∧ code e605602165702 = 2804625421254 := by decide
theorem cert_e605602165702 : check e605602165702 [[],[]] .chain = true := by decide
def e605602166810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605602166810 : Closed e605602166810 ∧ code e605602166810 = 2804625422362 := by decide
theorem cert_e605602166810 : check e605602166810 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602166846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 4))))))))
theorem wire_e605602166846 : Closed e605602166846 ∧ code e605602166846 = 2804625422398 := by decide
theorem cert_e605602166846 : check e605602166846 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602166894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605602166894 : Closed e605602166894 ∧ code e605602166894 = 2804625422446 := by decide
theorem cert_e605602166894 : check e605602166894 [[],[]] .chain = true := by decide
def e605602166902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605602166902 : Closed e605602166902 ∧ code e605602166902 = 2804625422454 := by decide
theorem cert_e605602166902 : check e605602166902 [[],[]] .chain = true := by decide
def e605602166906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605602166906 : Closed e605602166906 ∧ code e605602166906 = 2804625422458 := by decide
theorem cert_e605602166906 : check e605602166906 [[],[]] .chain = true := by decide
def e605602167146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605602167146 : Closed e605602167146 ∧ code e605602167146 = 2804625422698 := by decide
theorem cert_e605602167146 : check e605602167146 [[],[]] .chain = true := by decide
def e605602167170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605602167170 : Closed e605602167170 ∧ code e605602167170 = 2804625422722 := by decide
theorem cert_e605602167170 : check e605602167170 [[],[]] .chain = true := by decide
def e605602167182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602167182 : Closed e605602167182 ∧ code e605602167182 = 2804625422734 := by decide
theorem cert_e605602167182 : check e605602167182 [[],[]] .chain = true := by decide
def e605602167194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605602167194 : Closed e605602167194 ∧ code e605602167194 = 2804625422746 := by decide
theorem cert_e605602167194 : check e605602167194 [[],[]] .chain = true := by decide
def e605602167238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602167238 : Closed e605602167238 ∧ code e605602167238 = 2804625422790 := by decide
theorem cert_e605602167238 : check e605602167238 [[],[]] .chain = true := by decide
def e605602167266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605602167266 : Closed e605602167266 ∧ code e605602167266 = 2804625422818 := by decide
theorem cert_e605602167266 : check e605602167266 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602167278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602167278 : Closed e605602167278 ∧ code e605602167278 = 2804625422830 := by decide
theorem cert_e605602167278 : check e605602167278 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602169046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e605602169046 : Closed e605602169046 ∧ code e605602169046 = 2804625424598 := by decide
theorem cert_e605602169046 : check e605602169046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602169142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602169142 : Closed e605602169142 ∧ code e605602169142 = 2804625424694 := by decide
theorem cert_e605602169142 : check e605602169142 [[],[]] .chain = true := by decide
def e605602169146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602169146 : Closed e605602169146 ∧ code e605602169146 = 2804625424698 := by decide
theorem cert_e605602169146 : check e605602169146 [[],[]] .chain = true := by decide
def e605602169326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e605602169326 : Closed e605602169326 ∧ code e605602169326 = 2804625424878 := by decide
theorem cert_e605602169326 : check e605602169326 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605602169334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e605602169334 : Closed e605602169334 ∧ code e605602169334 = 2804625424886 := by decide
theorem cert_e605602169334 : checkPay e605602169334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e605602169718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e605602169718 : Closed e605602169718 ∧ code e605602169718 = 2804625425270 := by decide
theorem cert_e605602169718 : check e605602169718 [[],[]] .chain = true := by decide
def e605602169782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e605602169782 : Closed e605602169782 ∧ code e605602169782 = 2804625425334 := by decide
theorem cert_e605602169782 : check e605602169782 [[],[]] .chain = true := by decide
def e605602169786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e605602169786 : Closed e605602169786 ∧ code e605602169786 = 2804625425338 := by decide
theorem cert_e605602169786 : check e605602169786 [[],[]] .chain = true := by decide
def e605602169814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e605602169814 : Closed e605602169814 ∧ code e605602169814 = 2804625425366 := by decide
theorem cert_e605602169814 : check e605602169814 [[],[]] .chain = true := by decide
def e605602169818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e605602169818 : Closed e605602169818 ∧ code e605602169818 = 2804625425370 := by decide
theorem cert_e605602169818 : check e605602169818 [[],[]] .chain = true := by decide
def e605602170094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602170094 : Closed e605602170094 ∧ code e605602170094 = 2804625425646 := by decide
theorem cert_e605602170094 : check e605602170094 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602170102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602170102 : Closed e605602170102 ∧ code e605602170102 = 2804625425654 := by decide
theorem cert_e605602170102 : check e605602170102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602170486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605602170486 : Closed e605602170486 ∧ code e605602170486 = 2804625426038 := by decide
theorem cert_e605602170486 : check e605602170486 [[],[]] .chain = true := by decide
def e605602170654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e605602170654 : Closed e605602170654 ∧ code e605602170654 = 2804625426206 := by decide
theorem cert_e605602170654 : check e605602170654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605602170678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602170678 : Closed e605602170678 ∧ code e605602170678 = 2804625426230 := by decide
theorem cert_e605602170678 : check e605602170678 [[],[]] .chain = true := by decide
def e605602170682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602170682 : Closed e605602170682 ∧ code e605602170682 = 2804625426234 := by decide
theorem cert_e605602170682 : check e605602170682 [[],[]] .chain = true := by decide
def e605602170766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e605602170766 : Closed e605602170766 ∧ code e605602170766 = 2804625426318 := by decide
theorem cert_e605602170766 : check e605602170766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602171734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e605602171734 : Closed e605602171734 ∧ code e605602171734 = 2804625427286 := by decide
theorem cert_e605602171734 : check e605602171734 [[],[]] .chain = true := by decide
def e605602171738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605602171738 : Closed e605602171738 ∧ code e605602171738 = 2804625427290 := by decide
theorem cert_e605602171738 : check e605602171738 [[],[]] .chain = true := by decide
def e605602171754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605602171754 : Closed e605602171754 ∧ code e605602171754 = 2804625427306 := by decide
theorem cert_e605602171754 : check e605602171754 [[],[]] .chain = true := by decide
def e605602171818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e605602171818 : Closed e605602171818 ∧ code e605602171818 = 2804625427370 := by decide
theorem cert_e605602171818 : check e605602171818 [[],[]] .chain = true := by decide
def e605602171926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e605602171926 : Closed e605602171926 ∧ code e605602171926 = 2804625427478 := by decide
theorem cert_e605602171926 : check e605602171926 [[],[]] .chain = true := by decide
def e605602172022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 1))))))
theorem wire_e605602172022 : Closed e605602172022 ∧ code e605602172022 = 2804625427574 := by decide
theorem cert_e605602172022 : check e605602172022 [[],[]] .chain = true := by decide
def e605602172118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e605602172118 : Closed e605602172118 ∧ code e605602172118 = 2804625427670 := by decide
theorem cert_e605602172118 : check e605602172118 [[],[]] .chain = true := by decide
def e605602172122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605602172122 : Closed e605602172122 ∧ code e605602172122 = 2804625427674 := by decide
theorem cert_e605602172122 : check e605602172122 [[],[]] .chain = true := by decide
def e605602172138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605602172138 : Closed e605602172138 ∧ code e605602172138 = 2804625427690 := by decide
theorem cert_e605602172138 : check e605602172138 [[],[]] .chain = true := by decide
def e605602172214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602172214 : Closed e605602172214 ∧ code e605602172214 = 2804625427766 := by decide
theorem cert_e605602172214 : check e605602172214 [[],[]] .chain = true := by decide
def e605602172218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602172218 : Closed e605602172218 ∧ code e605602172218 = 2804625427770 := by decide
theorem cert_e605602172218 : check e605602172218 [[],[]] .chain = true := by decide
def e605602172290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602172290 : Closed e605602172290 ∧ code e605602172290 = 2804625427842 := by decide
theorem cert_e605602172290 : check e605602172290 [[],[]] .chain = true := by decide
def e605602172302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e605602172302 : Closed e605602172302 ∧ code e605602172302 = 2804625427854 := by decide
theorem cert_e605602172302 : check e605602172302 [[],[]] .chain = true := by decide
def e605602172314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602172314 : Closed e605602172314 ∧ code e605602172314 = 2804625427866 := by decide
theorem cert_e605602172314 : check e605602172314 [[],[]] .chain = true := by decide
def e605602172426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e605602172426 : Closed e605602172426 ∧ code e605602172426 = 2804625427978 := by decide
theorem cert_e605602172426 : check e605602172426 [[],[]] .chain = true := by decide
def e605602172462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602172462 : Closed e605602172462 ∧ code e605602172462 = 2804625428014 := by decide
theorem cert_e605602172462 : check e605602172462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602172470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 1))))))
theorem wire_e605602172470 : Closed e605602172470 ∧ code e605602172470 = 2804625428022 := by decide
theorem cert_e605602172470 : check e605602172470 [[],[]] .chain = true := by decide
def e605602172474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))) (.var 0))))))
theorem wire_e605602172474 : Closed e605602172474 ∧ code e605602172474 = 2804625428026 := by decide
theorem cert_e605602172474 : check e605602172474 [[],[]] .chain = true := by decide
def e605602172522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605602172522 : Closed e605602172522 ∧ code e605602172522 = 2804625428074 := by decide
theorem cert_e605602172522 : check e605602172522 [[],[]] .chain = true := by decide
def e605602172546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602172546 : Closed e605602172546 ∧ code e605602172546 = 2804625428098 := by decide
theorem cert_e605602172546 : check e605602172546 [[],[]] .chain = true := by decide
def e605602172558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e605602172558 : Closed e605602172558 ∧ code e605602172558 = 2804625428110 := by decide
theorem cert_e605602172558 : check e605602172558 [[],[]] .chain = true := by decide
def e605602172570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602172570 : Closed e605602172570 ∧ code e605602172570 = 2804625428122 := by decide
theorem cert_e605602172570 : check e605602172570 [[],[]] .chain = true := by decide
def e605602172614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e605602172614 : Closed e605602172614 ∧ code e605602172614 = 2804625428166 := by decide
theorem cert_e605602172614 : check e605602172614 [[],[]] .chain = true := by decide
def e605602172642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605602172642 : Closed e605602172642 ∧ code e605602172642 = 2804625428194 := by decide
theorem cert_e605602172642 : check e605602172642 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602172654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e605602172654 : Closed e605602172654 ∧ code e605602172654 = 2804625428206 := by decide
theorem cert_e605602172654 : check e605602172654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602172694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e605602172694 : Closed e605602172694 ∧ code e605602172694 = 2804625428246 := by decide
theorem cert_e605602172694 : check e605602172694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602172770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e605602172770 : Closed e605602172770 ∧ code e605602172770 = 2804625428322 := by decide
theorem cert_e605602172770 : check e605602172770 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605602172782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e605602172782 : Closed e605602172782 ∧ code e605602172782 = 2804625428334 := by decide
theorem cert_e605602172782 : check e605602172782 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605602172790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e605602172790 : Closed e605602172790 ∧ code e605602172790 = 2804625428342 := by decide
def e605602173166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605602173166 : Closed e605602173166 ∧ code e605602173166 = 2804625428718 := by decide
theorem cert_e605602173166 : check e605602173166 [[],[]] .chain = true := by decide
def e605602173174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605602173174 : Closed e605602173174 ∧ code e605602173174 = 2804625428726 := by decide
theorem cert_e605602173174 : check e605602173174 [[],[]] .chain = true := by decide
def e605602173654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605602173654 : Closed e605602173654 ∧ code e605602173654 = 2804625429206 := by decide
theorem cert_e605602173654 : check e605602173654 [[],[]] .chain = true := by decide
def e605602173658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605602173658 : Closed e605602173658 ∧ code e605602173658 = 2804625429210 := by decide
theorem cert_e605602173658 : check e605602173658 [[],[]] .chain = true := by decide
def e605602173674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605602173674 : Closed e605602173674 ∧ code e605602173674 = 2804625429226 := by decide
theorem cert_e605602173674 : check e605602173674 [[],[]] .chain = true := by decide
def e605602173750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605602173750 : Closed e605602173750 ∧ code e605602173750 = 2804625429302 := by decide
theorem cert_e605602173750 : check e605602173750 [[],[]] .chain = true := by decide
def e605602173754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605602173754 : Closed e605602173754 ∧ code e605602173754 = 2804625429306 := by decide
theorem cert_e605602173754 : check e605602173754 [[],[]] .chain = true := by decide
def e605602173826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e605602173826 : Closed e605602173826 ∧ code e605602173826 = 2804625429378 := by decide
theorem cert_e605602173826 : check e605602173826 [[],[]] .chain = true := by decide
def e605602173838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e605602173838 : Closed e605602173838 ∧ code e605602173838 = 2804625429390 := by decide
theorem cert_e605602173838 : check e605602173838 [[],[]] .chain = true := by decide
def e605602173850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605602173850 : Closed e605602173850 ∧ code e605602173850 = 2804625429402 := by decide
theorem cert_e605602173850 : check e605602173850 [[],[]] .chain = true := by decide
def e605602175002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605602175002 : Closed e605602175002 ∧ code e605602175002 = 2804625430554 := by decide
theorem cert_e605602175002 : check e605602175002 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602175038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e605602175038 : Closed e605602175038 ∧ code e605602175038 = 2804625430590 := by decide
theorem cert_e605602175038 : check e605602175038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602175086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605602175086 : Closed e605602175086 ∧ code e605602175086 = 2804625430638 := by decide
theorem cert_e605602175086 : check e605602175086 [[],[]] .chain = true := by decide
def e605602175094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605602175094 : Closed e605602175094 ∧ code e605602175094 = 2804625430646 := by decide
theorem cert_e605602175094 : check e605602175094 [[],[]] .chain = true := by decide
def e605602175098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605602175098 : Closed e605602175098 ∧ code e605602175098 = 2804625430650 := by decide
theorem cert_e605602175098 : check e605602175098 [[],[]] .chain = true := by decide
def e605602175338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605602175338 : Closed e605602175338 ∧ code e605602175338 = 2804625430890 := by decide
theorem cert_e605602175338 : check e605602175338 [[],[]] .chain = true := by decide
def e605602175362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605602175362 : Closed e605602175362 ∧ code e605602175362 = 2804625430914 := by decide
theorem cert_e605602175362 : check e605602175362 [[],[]] .chain = true := by decide
def e605602175374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602175374 : Closed e605602175374 ∧ code e605602175374 = 2804625430926 := by decide
theorem cert_e605602175374 : check e605602175374 [[],[]] .chain = true := by decide
def e605602175386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605602175386 : Closed e605602175386 ∧ code e605602175386 = 2804625430938 := by decide
theorem cert_e605602175386 : check e605602175386 [[],[]] .chain = true := by decide
def e605602175430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602175430 : Closed e605602175430 ∧ code e605602175430 = 2804625430982 := by decide
theorem cert_e605602175430 : check e605602175430 [[],[]] .chain = true := by decide
def e605602175458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605602175458 : Closed e605602175458 ∧ code e605602175458 = 2804625431010 := by decide
theorem cert_e605602175458 : check e605602175458 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602175470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602175470 : Closed e605602175470 ∧ code e605602175470 = 2804625431022 := by decide
theorem cert_e605602175470 : check e605602175470 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605602176030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e605602176030 : Closed e605602176030 ∧ code e605602176030 = 2804625431582 := by decide
theorem cert_e605602176030 : check e605602176030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605602176226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e605602176226 : Closed e605602176226 ∧ code e605602176226 = 2804625431778 := by decide
theorem cert_e605602176226 : check e605602176226 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605602176238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602176238 : Closed e605602176238 ∧ code e605602176238 = 2804625431790 := by decide
theorem cert_e605602176238 : check e605602176238 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605602176246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602176246 : Closed e605602176246 ∧ code e605602176246 = 2804625431798 := by decide
theorem cert_e605602176246 : check e605602176246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605602188142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605602188142 : Closed e605602188142 ∧ code e605602188142 = 2804625443694 := by decide
theorem cert_e605602188142 : check e605602188142 [[],[]] .smaller = true := by decide
def e605602188150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605602188150 : Closed e605602188150 ∧ code e605602188150 = 2804625443702 := by decide
theorem cert_e605602188150 : check e605602188150 [[],[]] .smaller = true := by decide
def e605602188206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605602188206 : Closed e605602188206 ∧ code e605602188206 = 2804625443758 := by decide
theorem cert_e605602188206 : check e605602188206 [[],[]] .smaller = true := by decide
def e605602188218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605602188218 : Closed e605602188218 ∧ code e605602188218 = 2804625443770 := by decide
theorem cert_e605602188218 : check e605602188218 [[],[]] .smaller = true := by decide
def e605602188246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605602188246 : Closed e605602188246 ∧ code e605602188246 = 2804625443798 := by decide
theorem cert_e605602188246 : check e605602188246 [[],[]] .smaller = true := by decide
def e605602188250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605602188250 : Closed e605602188250 ∧ code e605602188250 = 2804625443802 := by decide
theorem cert_e605602188250 : check e605602188250 [[],[]] .smaller = true := by decide
def e605602188526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605602188526 : Closed e605602188526 ∧ code e605602188526 = 2804625444078 := by decide
theorem cert_e605602188526 : check e605602188526 [[],[]] .smaller = true := by decide
def e605602188534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605602188534 : Closed e605602188534 ∧ code e605602188534 = 2804625444086 := by decide
theorem cert_e605602188534 : check e605602188534 [[],[]] .smaller = true := by decide
def e605602188910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605602188910 : Closed e605602188910 ∧ code e605602188910 = 2804625444462 := by decide
theorem cert_e605602188910 : check e605602188910 [[],[]] .smaller = true := by decide
def e605602188922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605602188922 : Closed e605602188922 ∧ code e605602188922 = 2804625444474 := by decide
theorem cert_e605602188922 : check e605602188922 [[],[]] .smaller = true := by decide
def e605602189110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605602189110 : Closed e605602189110 ∧ code e605602189110 = 2804625444662 := by decide
theorem cert_e605602189110 : check e605602189110 [[],[]] .smaller = true := by decide
def e605602189114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605602189114 : Closed e605602189114 ∧ code e605602189114 = 2804625444666 := by decide
theorem cert_e605602189114 : check e605602189114 [[],[]] .smaller = true := by decide
def e605602189246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e605602189246 : Closed e605602189246 ∧ code e605602189246 = 2804625444798 := by decide
theorem cert_e605602189246 : check e605602189246 [[],[]] .chain = true := by decide
end Blc.Floor41
