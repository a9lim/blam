import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e597053848090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597053848090 : Closed e597053848090 ∧ code e597053848090 = 2796077103642 := by decide
theorem cert_e597053848090 : check e597053848090 [[]] .width = true := by decide
def e597053860378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597053860378 : Closed e597053860378 ∧ code e597053860378 = 2796077115930 := by decide
theorem cert_e597053860378 : check e597053860378 [[]] .width = true := by decide
def e597053889050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597053889050 : Closed e597053889050 ∧ code e597053889050 = 2796077144602 := by decide
theorem cert_e597053889050 : check e597053889050 [[]] .width = true := by decide
def e597053893146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597053893146 : Closed e597053893146 ∧ code e597053893146 = 2796077148698 := by decide
theorem cert_e597053893146 : check e597053893146 [[]] .width = true := by decide
def e597054175770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054175770 : Closed e597054175770 ∧ code e597054175770 = 2796077431322 := by decide
theorem cert_e597054175770 : check e597054175770 [[]] .width = true := by decide
def e597054183962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054183962 : Closed e597054183962 ∧ code e597054183962 = 2796077439514 := by decide
theorem cert_e597054183962 : check e597054183962 [[]] .width = true := by decide
def e597054568986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054568986 : Closed e597054568986 ∧ code e597054568986 = 2796077824538 := by decide
theorem cert_e597054568986 : check e597054568986 [[]] .width = true := by decide
def e597054581274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054581274 : Closed e597054581274 ∧ code e597054581274 = 2796077836826 := by decide
theorem cert_e597054581274 : check e597054581274 [[]] .width = true := by decide
def e597054687258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597054687258 : Closed e597054687258 ∧ code e597054687258 = 2796077942810 := by decide
theorem cert_e597054687258 : check e597054687258 [[]] .width = true := by decide
def e597054691866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054691866 : Closed e597054691866 ∧ code e597054691866 = 2796077947418 := by decide
theorem cert_e597054691866 : check e597054691866 [[]] .width = true := by decide
def e597054693402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597054693402 : Closed e597054693402 ∧ code e597054693402 = 2796077948954 := by decide
theorem cert_e597054693402 : check e597054693402 [[]] .width = true := by decide
def e597054693494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597054693494 : Closed e597054693494 ∧ code e597054693494 = 2796077949046 := by decide
theorem cert_e597054693494 : check e597054693494 [[]] .width = true := by decide
def e597054693738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597054693738 : Closed e597054693738 ∧ code e597054693738 = 2796077949290 := by decide
theorem cert_e597054693738 : check e597054693738 [[]] .width = true := by decide
def e597054693786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597054693786 : Closed e597054693786 ∧ code e597054693786 = 2796077949338 := by decide
theorem cert_e597054693786 : check e597054693786 [[]] .width = true := by decide
def e597054773786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054773786 : Closed e597054773786 ∧ code e597054773786 = 2796078029338 := by decide
theorem cert_e597054773786 : check e597054773786 [[]] .width = true := by decide
def e597054777882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054777882 : Closed e597054777882 ∧ code e597054777882 = 2796078033434 := by decide
theorem cert_e597054777882 : check e597054777882 [[]] .width = true := by decide
def e597054818330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597054818330 : Closed e597054818330 ∧ code e597054818330 = 2796078073882 := by decide
theorem cert_e597054818330 : check e597054818330 [[]] .width = true := by decide
def e597054822938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597054822938 : Closed e597054822938 ∧ code e597054822938 = 2796078078490 := by decide
theorem cert_e597054822938 : check e597054822938 [[]] .width = true := by decide
def e597054824474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597054824474 : Closed e597054824474 ∧ code e597054824474 = 2796078080026 := by decide
theorem cert_e597054824474 : check e597054824474 [[]] .width = true := by decide
def e597054824566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597054824566 : Closed e597054824566 ∧ code e597054824566 = 2796078080118 := by decide
theorem cert_e597054824566 : check e597054824566 [[]] .width = true := by decide
def e597054824810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597054824810 : Closed e597054824810 ∧ code e597054824810 = 2796078080362 := by decide
theorem cert_e597054824810 : check e597054824810 [[]] .width = true := by decide
def e597054824858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597054824858 : Closed e597054824858 ∧ code e597054824858 = 2796078080410 := by decide
theorem cert_e597054824858 : check e597054824858 [[]] .width = true := by decide
def e597059664410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597059664410 : Closed e597059664410 ∧ code e597059664410 = 2796082919962 := by decide
theorem cert_e597059664410 : check e597059664410 [[]] .width = true := by decide
def e597059688986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597059688986 : Closed e597059688986 ∧ code e597059688986 = 2796082944538 := by decide
theorem cert_e597059688986 : check e597059688986 [[]] .width = true := by decide
def e597060663834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597060663834 : Closed e597060663834 ∧ code e597060663834 = 2796083919386 := by decide
theorem cert_e597060663834 : check e597060663834 [[]] .width = true := by decide
def e597060676122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597060676122 : Closed e597060676122 ∧ code e597060676122 = 2796083931674 := by decide
theorem cert_e597060676122 : check e597060676122 [[]] .width = true := by decide
def e597060725274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597060725274 : Closed e597060725274 ∧ code e597060725274 = 2796083980826 := by decide
theorem cert_e597060725274 : check e597060725274 [[]] .width = true := by decide
def e597060860442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597060860442 : Closed e597060860442 ∧ code e597060860442 = 2796084115994 := by decide
theorem cert_e597060860442 : check e597060860442 [[]] .width = true := by decide
def e597060872730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597060872730 : Closed e597060872730 ∧ code e597060872730 = 2796084128282 := by decide
theorem cert_e597060872730 : check e597060872730 [[]] .width = true := by decide
def e597060978714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597060978714 : Closed e597060978714 ∧ code e597060978714 = 2796084234266 := by decide
theorem cert_e597060978714 : check e597060978714 [[]] .width = true := by decide
def e597060983322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597060983322 : Closed e597060983322 ∧ code e597060983322 = 2796084238874 := by decide
theorem cert_e597060983322 : check e597060983322 [[]] .width = true := by decide
def e597060984858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597060984858 : Closed e597060984858 ∧ code e597060984858 = 2796084240410 := by decide
theorem cert_e597060984858 : check e597060984858 [[]] .width = true := by decide
def e597060984950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597060984950 : Closed e597060984950 ∧ code e597060984950 = 2796084240502 := by decide
theorem cert_e597060984950 : check e597060984950 [[]] .width = true := by decide
def e597060985194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597060985194 : Closed e597060985194 ∧ code e597060985194 = 2796084240746 := by decide
theorem cert_e597060985194 : check e597060985194 [[]] .width = true := by decide
def e597060985242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597060985242 : Closed e597060985242 ∧ code e597060985242 = 2796084240794 := by decide
theorem cert_e597060985242 : check e597060985242 [[]] .width = true := by decide
def e597061167642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597061167642 : Closed e597061167642 ∧ code e597061167642 = 2796084423194 := by decide
theorem cert_e597061167642 : check e597061167642 [[]] .width = true := by decide
def e597061175322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597061175322 : Closed e597061175322 ∧ code e597061175322 = 2796084430874 := by decide
theorem cert_e597061175322 : check e597061175322 [[]] .width = true := by decide
def e597061179930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597061179930 : Closed e597061179930 ∧ code e597061179930 = 2796084435482 := by decide
theorem cert_e597061179930 : check e597061179930 [[]] .width = true := by decide
def e597061181466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597061181466 : Closed e597061181466 ∧ code e597061181466 = 2796084437018 := by decide
theorem cert_e597061181466 : check e597061181466 [[]] .width = true := by decide
def e597061181558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597061181558 : Closed e597061181558 ∧ code e597061181558 = 2796084437110 := by decide
theorem cert_e597061181558 : check e597061181558 [[]] .width = true := by decide
def e597061181802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597061181802 : Closed e597061181802 ∧ code e597061181802 = 2796084437354 := by decide
theorem cert_e597061181802 : check e597061181802 [[]] .width = true := by decide
def e597061181850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597061181850 : Closed e597061181850 ∧ code e597061181850 = 2796084437402 := by decide
theorem cert_e597061181850 : check e597061181850 [[]] .width = true := by decide
def e597063612954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597063612954 : Closed e597063612954 ∧ code e597063612954 = 2796086868506 := by decide
theorem cert_e597063612954 : check e597063612954 [[]] .width = true := by decide
def e597063621146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597063621146 : Closed e597063621146 ∧ code e597063621146 = 2796086876698 := by decide
theorem cert_e597063621146 : check e597063621146 [[]] .width = true := by decide
def e597064112666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064112666 : Closed e597064112666 ∧ code e597064112666 = 2796087368218 := by decide
theorem cert_e597064112666 : check e597064112666 [[]] .width = true := by decide
def e597064116762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064116762 : Closed e597064116762 ∧ code e597064116762 = 2796087372314 := by decide
theorem cert_e597064116762 : check e597064116762 [[]] .width = true := by decide
def e597064133146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064133146 : Closed e597064133146 ∧ code e597064133146 = 2796087388698 := by decide
theorem cert_e597064133146 : check e597064133146 [[]] .width = true := by decide
def e597064210970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064210970 : Closed e597064210970 ∧ code e597064210970 = 2796087466522 := by decide
theorem cert_e597064210970 : check e597064210970 [[]] .width = true := by decide
def e597064215066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064215066 : Closed e597064215066 ∧ code e597064215066 = 2796087470618 := by decide
theorem cert_e597064215066 : check e597064215066 [[]] .width = true := by decide
def e597064255514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597064255514 : Closed e597064255514 ∧ code e597064255514 = 2796087511066 := by decide
theorem cert_e597064255514 : check e597064255514 [[]] .width = true := by decide
def e597064260122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064260122 : Closed e597064260122 ∧ code e597064260122 = 2796087515674 := by decide
theorem cert_e597064260122 : check e597064260122 [[]] .width = true := by decide
def e597064261658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597064261658 : Closed e597064261658 ∧ code e597064261658 = 2796087517210 := by decide
theorem cert_e597064261658 : check e597064261658 [[]] .width = true := by decide
def e597064261750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597064261750 : Closed e597064261750 ∧ code e597064261750 = 2796087517302 := by decide
theorem cert_e597064261750 : check e597064261750 [[]] .width = true := by decide
def e597064261994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597064261994 : Closed e597064261994 ∧ code e597064261994 = 2796087517546 := by decide
theorem cert_e597064261994 : check e597064261994 [[]] .width = true := by decide
def e597064262042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597064262042 : Closed e597064262042 ∧ code e597064262042 = 2796087517594 := by decide
theorem cert_e597064262042 : check e597064262042 [[]] .width = true := by decide
def e597064313370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064313370 : Closed e597064313370 ∧ code e597064313370 = 2796087568922 := by decide
theorem cert_e597064313370 : check e597064313370 [[]] .width = true := by decide
def e597064321050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597064321050 : Closed e597064321050 ∧ code e597064321050 = 2796087576602 := by decide
theorem cert_e597064321050 : check e597064321050 [[]] .width = true := by decide
def e597064325658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597064325658 : Closed e597064325658 ∧ code e597064325658 = 2796087581210 := by decide
theorem cert_e597064325658 : check e597064325658 [[]] .width = true := by decide
def e597064327194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597064327194 : Closed e597064327194 ∧ code e597064327194 = 2796087582746 := by decide
theorem cert_e597064327194 : check e597064327194 [[]] .width = true := by decide
def e597064327286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597064327286 : Closed e597064327286 ∧ code e597064327286 = 2796087582838 := by decide
theorem cert_e597064327286 : check e597064327286 [[]] .width = true := by decide
def e597064327530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597064327530 : Closed e597064327530 ∧ code e597064327530 = 2796087583082 := by decide
theorem cert_e597064327530 : check e597064327530 [[]] .width = true := by decide
def e597064327578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597064327578 : Closed e597064327578 ∧ code e597064327578 = 2796087583130 := by decide
theorem cert_e597064327578 : check e597064327578 [[]] .width = true := by decide
def e597084384622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e597084384622 : Closed e597084384622 ∧ code e597084384622 = 2796107640174 := by decide
theorem cert_e597084384622 : check e597084384622 [[],[.left],[]] .chain = true := by decide
def e597084384630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e597084384630 : Closed e597084384630 ∧ code e597084384630 = 2796107640182 := by decide
theorem cert_e597084384630 : check e597084384630 [[],[.left],[]] .chain = true := by decide
def e597084384686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e597084384686 : Closed e597084384686 ∧ code e597084384686 = 2796107640238 := by decide
theorem cert_e597084384686 : check e597084384686 [[],[.left],[]] .chain = true := by decide
def e597084384698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e597084384698 : Closed e597084384698 ∧ code e597084384698 = 2796107640250 := by decide
theorem cert_e597084384698 : check e597084384698 [[],[.left],[]] .chain = true := by decide
def e597084384726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e597084384726 : Closed e597084384726 ∧ code e597084384726 = 2796107640278 := by decide
theorem cert_e597084384726 : check e597084384726 [[],[.left],[]] .chain = true := by decide
def e597084384730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e597084384730 : Closed e597084384730 ∧ code e597084384730 = 2796107640282 := by decide
theorem cert_e597084384730 : check e597084384730 [[],[.left],[]] .chain = true := by decide
def e597084384942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e597084384942 : Closed e597084384942 ∧ code e597084384942 = 2796107640494 := by decide
theorem cert_e597084384942 : check e597084384942 [[],[.left],[]] .chain = true := by decide
def e597084384954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e597084384954 : Closed e597084384954 ∧ code e597084384954 = 2796107640506 := by decide
theorem cert_e597084384954 : check e597084384954 [[],[.left],[]] .chain = true := by decide
def e597084385002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e597084385002 : Closed e597084385002 ∧ code e597084385002 = 2796107640554 := by decide
theorem cert_e597084385002 : check e597084385002 [[],[.left],[]] .chain = true := by decide
def e597084385110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e597084385110 : Closed e597084385110 ∧ code e597084385110 = 2796107640662 := by decide
theorem cert_e597084385110 : check e597084385110 [[],[.left],[]] .chain = true := by decide
def e597084385114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e597084385114 : Closed e597084385114 ∧ code e597084385114 = 2796107640666 := by decide
theorem cert_e597084385114 : check e597084385114 [[],[.left],[]] .chain = true := by decide
def e597084385130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e597084385130 : Closed e597084385130 ∧ code e597084385130 = 2796107640682 := by decide
theorem cert_e597084385130 : check e597084385130 [[],[.left],[]] .chain = true := by decide
def e597084386158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e597084386158 : Closed e597084386158 ∧ code e597084386158 = 2796107641710 := by decide
theorem cert_e597084386158 : check e597084386158 [[],[.left],[]] .chain = true := by decide
def e597084386166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e597084386166 : Closed e597084386166 ∧ code e597084386166 = 2796107641718 := by decide
theorem cert_e597084386166 : check e597084386166 [[],[.left],[]] .chain = true := by decide
def e597084386222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e597084386222 : Closed e597084386222 ∧ code e597084386222 = 2796107641774 := by decide
theorem cert_e597084386222 : check e597084386222 [[],[.left],[]] .chain = true := by decide
def e597084386234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e597084386234 : Closed e597084386234 ∧ code e597084386234 = 2796107641786 := by decide
theorem cert_e597084386234 : check e597084386234 [[],[.left],[]] .chain = true := by decide
def e597084386262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e597084386262 : Closed e597084386262 ∧ code e597084386262 = 2796107641814 := by decide
theorem cert_e597084386262 : check e597084386262 [[],[.left],[]] .chain = true := by decide
def e597084386266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e597084386266 : Closed e597084386266 ∧ code e597084386266 = 2796107641818 := by decide
theorem cert_e597084386266 : check e597084386266 [[],[.left],[]] .chain = true := by decide
def e597084386542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e597084386542 : Closed e597084386542 ∧ code e597084386542 = 2796107642094 := by decide
theorem cert_e597084386542 : check e597084386542 [[],[.left],[]] .chain = true := by decide
def e597084386550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e597084386550 : Closed e597084386550 ∧ code e597084386550 = 2796107642102 := by decide
theorem cert_e597084386550 : check e597084386550 [[],[.left],[]] .chain = true := by decide
def e597084386926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e597084386926 : Closed e597084386926 ∧ code e597084386926 = 2796107642478 := by decide
theorem cert_e597084386926 : check e597084386926 [[],[.left],[]] .chain = true := by decide
def e597084386938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e597084386938 : Closed e597084386938 ∧ code e597084386938 = 2796107642490 := by decide
theorem cert_e597084386938 : check e597084386938 [[],[.left],[]] .chain = true := by decide
def e597084387126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e597084387126 : Closed e597084387126 ∧ code e597084387126 = 2796107642678 := by decide
theorem cert_e597084387126 : check e597084387126 [[],[.left],[]] .chain = true := by decide
def e597084387130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e597084387130 : Closed e597084387130 ∧ code e597084387130 = 2796107642682 := by decide
theorem cert_e597084387130 : check e597084387130 [[],[.left],[]] .chain = true := by decide
def e597084387758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e597084387758 : Closed e597084387758 ∧ code e597084387758 = 2796107643310 := by decide
theorem cert_e597084387758 : check e597084387758 [[],[.left],[]] .chain = true := by decide
def e597084387770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e597084387770 : Closed e597084387770 ∧ code e597084387770 = 2796107643322 := by decide
theorem cert_e597084387770 : check e597084387770 [[],[.left],[]] .chain = true := by decide
def e597084387818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e597084387818 : Closed e597084387818 ∧ code e597084387818 = 2796107643370 := by decide
theorem cert_e597084387818 : check e597084387818 [[],[.left],[]] .chain = true := by decide
def e597084387950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e597084387950 : Closed e597084387950 ∧ code e597084387950 = 2796107643502 := by decide
theorem cert_e597084387950 : check e597084387950 [[],[.left],[]] .chain = true := by decide
def e597084387962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e597084387962 : Closed e597084387962 ∧ code e597084387962 = 2796107643514 := by decide
theorem cert_e597084387962 : check e597084387962 [[],[.left],[]] .chain = true := by decide
def e597084388250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e597084388250 : Closed e597084388250 ∧ code e597084388250 = 2796107643802 := by decide
theorem cert_e597084388250 : check e597084388250 [[],[.left],[]] .chain = true := by decide
def e597084388566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e597084388566 : Closed e597084388566 ∧ code e597084388566 = 2796107644118 := by decide
theorem cert_e597084388566 : check e597084388566 [[],[.left],[]] .chain = true := by decide
def e597084388570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e597084388570 : Closed e597084388570 ∧ code e597084388570 = 2796107644122 := by decide
theorem cert_e597084388570 : check e597084388570 [[],[.left],[]] .chain = true := by decide
def e597084388586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e597084388586 : Closed e597084388586 ∧ code e597084388586 = 2796107644138 := by decide
theorem cert_e597084388586 : check e597084388586 [[],[.left],[]] .chain = true := by decide
def e597084388662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e597084388662 : Closed e597084388662 ∧ code e597084388662 = 2796107644214 := by decide
theorem cert_e597084388662 : check e597084388662 [[],[.left],[]] .chain = true := by decide
def e597084388666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e597084388666 : Closed e597084388666 ∧ code e597084388666 = 2796107644218 := by decide
theorem cert_e597084388666 : check e597084388666 [[],[.left],[]] .chain = true := by decide
def e597084388762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e597084388762 : Closed e597084388762 ∧ code e597084388762 = 2796107644314 := by decide
theorem cert_e597084388762 : check e597084388762 [[],[.left],[]] .chain = true := by decide
def e597084392302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597084392302 : Closed e597084392302 ∧ code e597084392302 = 2796107647854 := by decide
theorem cert_e597084392302 : check e597084392302 [[],[.left],[]] .chain = true := by decide
def e597084392310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597084392310 : Closed e597084392310 ∧ code e597084392310 = 2796107647862 := by decide
theorem cert_e597084392310 : check e597084392310 [[],[.left],[]] .chain = true := by decide
def e597084392366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597084392366 : Closed e597084392366 ∧ code e597084392366 = 2796107647918 := by decide
theorem cert_e597084392366 : check e597084392366 [[],[.left],[]] .chain = true := by decide
def e597084392378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597084392378 : Closed e597084392378 ∧ code e597084392378 = 2796107647930 := by decide
theorem cert_e597084392378 : check e597084392378 [[],[.left],[]] .chain = true := by decide
def e597084392406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597084392406 : Closed e597084392406 ∧ code e597084392406 = 2796107647958 := by decide
theorem cert_e597084392406 : check e597084392406 [[],[.left],[]] .chain = true := by decide
def e597084392410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597084392410 : Closed e597084392410 ∧ code e597084392410 = 2796107647962 := by decide
theorem cert_e597084392410 : check e597084392410 [[],[.left],[]] .chain = true := by decide
def e597084392686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597084392686 : Closed e597084392686 ∧ code e597084392686 = 2796107648238 := by decide
theorem cert_e597084392686 : check e597084392686 [[],[.left],[]] .chain = true := by decide
def e597084392694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597084392694 : Closed e597084392694 ∧ code e597084392694 = 2796107648246 := by decide
theorem cert_e597084392694 : check e597084392694 [[],[.left],[]] .chain = true := by decide
def e597084393070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597084393070 : Closed e597084393070 ∧ code e597084393070 = 2796107648622 := by decide
theorem cert_e597084393070 : check e597084393070 [[],[.left],[]] .chain = true := by decide
def e597084393082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597084393082 : Closed e597084393082 ∧ code e597084393082 = 2796107648634 := by decide
theorem cert_e597084393082 : check e597084393082 [[],[.left],[]] .chain = true := by decide
def e597084393270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597084393270 : Closed e597084393270 ∧ code e597084393270 = 2796107648822 := by decide
theorem cert_e597084393270 : check e597084393270 [[],[.left],[]] .chain = true := by decide
def e597084393274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597084393274 : Closed e597084393274 ∧ code e597084393274 = 2796107648826 := by decide
theorem cert_e597084393274 : check e597084393274 [[],[.left],[]] .chain = true := by decide
def e597084399022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e597084399022 : Closed e597084399022 ∧ code e597084399022 = 2796107654574 := by decide
theorem cert_e597084399022 : check e597084399022 [[],[.left],[]] .chain = true := by decide
def e597084399034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e597084399034 : Closed e597084399034 ∧ code e597084399034 = 2796107654586 := by decide
theorem cert_e597084399034 : check e597084399034 [[],[.left],[]] .chain = true := by decide
def e597084399082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e597084399082 : Closed e597084399082 ∧ code e597084399082 = 2796107654634 := by decide
theorem cert_e597084399082 : check e597084399082 [[],[.left],[]] .chain = true := by decide
def e597084399214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e597084399214 : Closed e597084399214 ∧ code e597084399214 = 2796107654766 := by decide
theorem cert_e597084399214 : check e597084399214 [[],[.left],[]] .chain = true := by decide
def e597084399226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e597084399226 : Closed e597084399226 ∧ code e597084399226 = 2796107654778 := by decide
theorem cert_e597084399226 : check e597084399226 [[],[.left],[]] .chain = true := by decide
def e597084399514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e597084399514 : Closed e597084399514 ∧ code e597084399514 = 2796107655066 := by decide
theorem cert_e597084399514 : check e597084399514 [[],[.left],[]] .chain = true := by decide
def e597084402390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e597084402390 : Closed e597084402390 ∧ code e597084402390 = 2796107657942 := by decide
theorem cert_e597084402390 : check e597084402390 [[],[.left],[]] .chain = true := by decide
def e597084402394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e597084402394 : Closed e597084402394 ∧ code e597084402394 = 2796107657946 := by decide
theorem cert_e597084402394 : check e597084402394 [[],[.left],[]] .chain = true := by decide
def e597084402410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e597084402410 : Closed e597084402410 ∧ code e597084402410 = 2796107657962 := by decide
theorem cert_e597084402410 : check e597084402410 [[],[.left],[]] .chain = true := by decide
def e597084402486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e597084402486 : Closed e597084402486 ∧ code e597084402486 = 2796107658038 := by decide
theorem cert_e597084402486 : check e597084402486 [[],[.left],[]] .chain = true := by decide
def e597084402490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e597084402490 : Closed e597084402490 ∧ code e597084402490 = 2796107658042 := by decide
theorem cert_e597084402490 : check e597084402490 [[],[.left],[]] .chain = true := by decide
def e597084402586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e597084402586 : Closed e597084402586 ∧ code e597084402586 = 2796107658138 := by decide
theorem cert_e597084402586 : check e597084402586 [[],[.left],[]] .chain = true := by decide
def e597084539758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597084539758 : Closed e597084539758 ∧ code e597084539758 = 2796107795310 := by decide
theorem cert_e597084539758 : check e597084539758 [[],[.left],[],[]] .chain = true := by decide
def e597084539766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597084539766 : Closed e597084539766 ∧ code e597084539766 = 2796107795318 := by decide
theorem cert_e597084539766 : check e597084539766 [[],[.left],[],[]] .chain = true := by decide
def e597084539822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597084539822 : Closed e597084539822 ∧ code e597084539822 = 2796107795374 := by decide
theorem cert_e597084539822 : check e597084539822 [[],[.left],[],[]] .chain = true := by decide
def e597084539834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597084539834 : Closed e597084539834 ∧ code e597084539834 = 2796107795386 := by decide
theorem cert_e597084539834 : check e597084539834 [[],[.left],[],[]] .chain = true := by decide
def e597084539862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597084539862 : Closed e597084539862 ∧ code e597084539862 = 2796107795414 := by decide
theorem cert_e597084539862 : check e597084539862 [[],[.left],[],[]] .chain = true := by decide
def e597084539866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597084539866 : Closed e597084539866 ∧ code e597084539866 = 2796107795418 := by decide
theorem cert_e597084539866 : check e597084539866 [[],[.left],[],[]] .chain = true := by decide
def e597084540142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597084540142 : Closed e597084540142 ∧ code e597084540142 = 2796107795694 := by decide
theorem cert_e597084540142 : check e597084540142 [[],[.left],[],[]] .chain = true := by decide
def e597084540150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597084540150 : Closed e597084540150 ∧ code e597084540150 = 2796107795702 := by decide
theorem cert_e597084540150 : check e597084540150 [[],[.left],[],[]] .chain = true := by decide
def e597084540526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597084540526 : Closed e597084540526 ∧ code e597084540526 = 2796107796078 := by decide
theorem cert_e597084540526 : check e597084540526 [[],[.left],[],[]] .chain = true := by decide
def e597084540538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597084540538 : Closed e597084540538 ∧ code e597084540538 = 2796107796090 := by decide
theorem cert_e597084540538 : check e597084540538 [[],[.left],[],[]] .chain = true := by decide
def e597084540726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597084540726 : Closed e597084540726 ∧ code e597084540726 = 2796107796278 := by decide
theorem cert_e597084540726 : check e597084540726 [[],[.left],[],[]] .chain = true := by decide
def e597084540730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597084540730 : Closed e597084540730 ∧ code e597084540730 = 2796107796282 := by decide
theorem cert_e597084540730 : check e597084540730 [[],[.left],[],[]] .chain = true := by decide
def e597085129582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597085129582 : Closed e597085129582 ∧ code e597085129582 = 2796108385134 := by decide
theorem cert_e597085129582 : check e597085129582 [[],[.left]] .chain = true := by decide
def e597085129590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597085129590 : Closed e597085129590 ∧ code e597085129590 = 2796108385142 := by decide
theorem cert_e597085129590 : check e597085129590 [[],[.left]] .chain = true := by decide
def e597085129646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597085129646 : Closed e597085129646 ∧ code e597085129646 = 2796108385198 := by decide
theorem cert_e597085129646 : check e597085129646 [[],[.left]] .chain = true := by decide
def e597085129658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597085129658 : Closed e597085129658 ∧ code e597085129658 = 2796108385210 := by decide
theorem cert_e597085129658 : check e597085129658 [[],[.left]] .chain = true := by decide
def e597085129686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597085129686 : Closed e597085129686 ∧ code e597085129686 = 2796108385238 := by decide
theorem cert_e597085129686 : check e597085129686 [[],[.left]] .chain = true := by decide
def e597085129690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597085129690 : Closed e597085129690 ∧ code e597085129690 = 2796108385242 := by decide
theorem cert_e597085129690 : check e597085129690 [[],[.left]] .chain = true := by decide
def e597085129966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597085129966 : Closed e597085129966 ∧ code e597085129966 = 2796108385518 := by decide
theorem cert_e597085129966 : check e597085129966 [[],[.left]] .chain = true := by decide
def e597085129974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597085129974 : Closed e597085129974 ∧ code e597085129974 = 2796108385526 := by decide
theorem cert_e597085129974 : check e597085129974 [[],[.left]] .chain = true := by decide
def e597085130350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597085130350 : Closed e597085130350 ∧ code e597085130350 = 2796108385902 := by decide
theorem cert_e597085130350 : check e597085130350 [[],[.left]] .chain = true := by decide
def e597085130362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597085130362 : Closed e597085130362 ∧ code e597085130362 = 2796108385914 := by decide
theorem cert_e597085130362 : check e597085130362 [[],[.left]] .chain = true := by decide
def e597085130550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597085130550 : Closed e597085130550 ∧ code e597085130550 = 2796108386102 := by decide
theorem cert_e597085130550 : check e597085130550 [[],[.left]] .chain = true := by decide
def e597085130554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597085130554 : Closed e597085130554 ∧ code e597085130554 = 2796108386106 := by decide
theorem cert_e597085130554 : check e597085130554 [[],[.left]] .chain = true := by decide
def e597204777498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597204777498 : Closed e597204777498 ∧ code e597204777498 = 2796228033050 := by decide
private def t_e597204777498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597204777498 : ¬ IsSelfInterpreter e597204777498 :=
  wSource (t := t_e597204777498) (replay_sound (ps := []) (t := e597204777498) (by decide)) (by decide)
def e597204785690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597204785690 : Closed e597204785690 ∧ code e597204785690 = 2796228041242 := by decide
private def t_e597204785690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597204785690 : ¬ IsSelfInterpreter e597204785690 :=
  wSource (t := t_e597204785690) (replay_sound (ps := []) (t := e597204785690) (by decide)) (by decide)
def e597204843034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597204843034 : Closed e597204843034 ∧ code e597204843034 = 2796228098586 := by decide
private def t_e597204843034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597204843034 : ¬ IsSelfInterpreter e597204843034 :=
  wSource (t := t_e597204843034) (replay_sound (ps := []) (t := e597204843034) (by decide)) (by decide)
def e597204855322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597204855322 : Closed e597204855322 ∧ code e597204855322 = 2796228110874 := by decide
private def t_e597204855322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597204855322 : ¬ IsSelfInterpreter e597204855322 :=
  wSource (t := t_e597204855322) (replay_sound (ps := []) (t := e597204855322) (by decide)) (by decide)
def e597204883994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597204883994 : Closed e597204883994 ∧ code e597204883994 = 2796228139546 := by decide
private def t_e597204883994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597204883994 : ¬ IsSelfInterpreter e597204883994 :=
  wSource (t := t_e597204883994) (replay_sound (ps := []) (t := e597204883994) (by decide)) (by decide)
def e597204888090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597204888090 : Closed e597204888090 ∧ code e597204888090 = 2796228143642 := by decide
private def t_e597204888090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597204888090 : ¬ IsSelfInterpreter e597204888090 :=
  wSource (t := t_e597204888090) (replay_sound (ps := []) (t := e597204888090) (by decide)) (by decide)
def e597205170714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597205170714 : Closed e597205170714 ∧ code e597205170714 = 2796228426266 := by decide
private def t_e597205170714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597205170714 : ¬ IsSelfInterpreter e597205170714 :=
  wSource (t := t_e597205170714) (replay_sound (ps := []) (t := e597205170714) (by decide)) (by decide)
def e597205178906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597205178906 : Closed e597205178906 ∧ code e597205178906 = 2796228434458 := by decide
private def t_e597205178906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597205178906 : ¬ IsSelfInterpreter e597205178906 :=
  wSource (t := t_e597205178906) (replay_sound (ps := []) (t := e597205178906) (by decide)) (by decide)
def e597205563930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597205563930 : Closed e597205563930 ∧ code e597205563930 = 2796228819482 := by decide
private def t_e597205563930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597205563930 : ¬ IsSelfInterpreter e597205563930 :=
  wSource (t := t_e597205563930) (replay_sound (ps := []) (t := e597205563930) (by decide)) (by decide)
def e597205576218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597205576218 : Closed e597205576218 ∧ code e597205576218 = 2796228831770 := by decide
private def t_e597205576218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597205576218 : ¬ IsSelfInterpreter e597205576218 :=
  wSource (t := t_e597205576218) (replay_sound (ps := []) (t := e597205576218) (by decide)) (by decide)
def e597205768730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597205768730 : Closed e597205768730 ∧ code e597205768730 = 2796229024282 := by decide
private def t_e597205768730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597205768730 : ¬ IsSelfInterpreter e597205768730 :=
  wSource (t := t_e597205768730) (replay_sound (ps := []) (t := e597205768730) (by decide)) (by decide)
def e597205772826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597205772826 : Closed e597205772826 ∧ code e597205772826 = 2796229028378 := by decide
private def t_e597205772826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597205772826 : ¬ IsSelfInterpreter e597205772826 :=
  wSource (t := t_e597205772826) (replay_sound (ps := []) (t := e597205772826) (by decide)) (by decide)
def e597271885850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597271885850 : Closed e597271885850 ∧ code e597271885850 = 2796295141402 := by decide
theorem cert_e597271885850 : check e597271885850 [[]] .width = true := by decide
def e597271894042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597271894042 : Closed e597271894042 ∧ code e597271894042 = 2796295149594 := by decide
theorem cert_e597271894042 : check e597271894042 [[]] .width = true := by decide
end Blc.Floor41
