import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602907631326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e602907631326 : Closed e602907631326 ∧ code e602907631326 = 2801930886878 := by decide
theorem cert_e602907631326 : check e602907631326 [[],[]] .chain = true := by decide
def e602907631350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e602907631350 : Closed e602907631350 ∧ code e602907631350 = 2801930886902 := by decide
theorem cert_e602907631350 : check e602907631350 [[],[]] .chain = true := by decide
def e602907631470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e602907631470 : Closed e602907631470 ∧ code e602907631470 = 2801930887022 := by decide
theorem cert_e602907631470 : check e602907631470 [[],[]] .chain = true := by decide
def e602907631478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e602907631478 : Closed e602907631478 ∧ code e602907631478 = 2801930887030 := by decide
theorem cert_e602907631478 : check e602907631478 [[],[]] .chain = true := by decide
def e602907633438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e602907633438 : Closed e602907633438 ∧ code e602907633438 = 2801930888990 := by decide
theorem cert_e602907633438 : check e602907633438 [[],[]] .smaller = true := by decide
def e602907633550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e602907633550 : Closed e602907633550 ∧ code e602907633550 = 2801930889102 := by decide
theorem cert_e602907633550 : check e602907633550 [[],[]] .smaller = true := by decide
def e602907636510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e602907636510 : Closed e602907636510 ∧ code e602907636510 = 2801930892062 := by decide
theorem cert_e602907636510 : check e602907636510 [[],[]] .smaller = true := by decide
def e602907636678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e602907636678 : Closed e602907636678 ∧ code e602907636678 = 2801930892230 := by decide
theorem cert_e602907636678 : check e602907636678 [[],[]] .smaller = true := by decide
def e602907636702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e602907636702 : Closed e602907636702 ∧ code e602907636702 = 2801930892254 := by decide
theorem cert_e602907636702 : check e602907636702 [[],[]] .chain = true := by decide
def e602907636718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e602907636718 : Closed e602907636718 ∧ code e602907636718 = 2801930892270 := by decide
theorem cert_e602907636718 : check e602907636718 [[],[]] .chain = true := by decide
def e602907638158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e602907638158 : Closed e602907638158 ∧ code e602907638158 = 2801930893710 := by decide
theorem cert_e602907638158 : check e602907638158 [[],[]] .smaller = true := by decide
def e602907638214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e602907638214 : Closed e602907638214 ∧ code e602907638214 = 2801930893766 := by decide
theorem cert_e602907638214 : check e602907638214 [[],[]] .smaller = true := by decide
def e602907638238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e602907638238 : Closed e602907638238 ∧ code e602907638238 = 2801930893790 := by decide
theorem cert_e602907638238 : check e602907638238 [[],[]] .chain = true := by decide
def e602907638262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e602907638262 : Closed e602907638262 ∧ code e602907638262 = 2801930893814 := by decide
theorem cert_e602907638262 : check e602907638262 [[],[]] .chain = true := by decide
def e602907639022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e602907639022 : Closed e602907639022 ∧ code e602907639022 = 2801930894574 := by decide
theorem cert_e602907639022 : check e602907639022 [[],[]] .chain = true := by decide
def e602907639030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e602907639030 : Closed e602907639030 ∧ code e602907639030 = 2801930894582 := by decide
theorem cert_e602907639030 : check e602907639030 [[],[]] .chain = true := by decide
def e602907695982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e602907695982 : Closed e602907695982 ∧ code e602907695982 = 2801930951534 := by decide
theorem cert_e602907695982 : check e602907695982 [[],[]] .chain = true := by decide
def e602907695990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e602907695990 : Closed e602907695990 ∧ code e602907695990 = 2801930951542 := by decide
theorem cert_e602907695990 : check e602907695990 [[],[]] .chain = true := by decide
def e602907696054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e602907696054 : Closed e602907696054 ∧ code e602907696054 = 2801930951606 := by decide
theorem cert_e602907696054 : check e602907696054 [[],[]] .chain = true := by decide
def e602907696494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e602907696494 : Closed e602907696494 ∧ code e602907696494 = 2801930952046 := by decide
theorem cert_e602907696494 : check e602907696494 [[],[]] .chain = true := by decide
def e602907696502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e602907696502 : Closed e602907696502 ∧ code e602907696502 = 2801930952054 := by decide
theorem cert_e602907696502 : check e602907696502 [[],[]] .chain = true := by decide
def e602907696558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e602907696558 : Closed e602907696558 ∧ code e602907696558 = 2801930952110 := by decide
theorem cert_e602907696558 : check e602907696558 [[],[]] .chain = true := by decide
def e602907696570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e602907696570 : Closed e602907696570 ∧ code e602907696570 = 2801930952122 := by decide
theorem cert_e602907696570 : check e602907696570 [[],[]] .chain = true := by decide
def e602907696598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e602907696598 : Closed e602907696598 ∧ code e602907696598 = 2801930952150 := by decide
theorem cert_e602907696598 : check e602907696598 [[],[]] .chain = true := by decide
def e602907696602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e602907696602 : Closed e602907696602 ∧ code e602907696602 = 2801930952154 := by decide
theorem cert_e602907696602 : check e602907696602 [[],[]] .chain = true := by decide
def e602907696822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e602907696822 : Closed e602907696822 ∧ code e602907696822 = 2801930952374 := by decide
theorem cert_e602907696822 : check e602907696822 [[],[]] .chain = true := by decide
def e602907696854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e602907696854 : Closed e602907696854 ∧ code e602907696854 = 2801930952406 := by decide
theorem cert_e602907696854 : check e602907696854 [[],[]] .chain = true := by decide
def e602907696858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e602907696858 : Closed e602907696858 ∧ code e602907696858 = 2801930952410 := by decide
theorem cert_e602907696858 : check e602907696858 [[],[]] .chain = true := by decide
def e602907699054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e602907699054 : Closed e602907699054 ∧ code e602907699054 = 2801930954606 := by decide
theorem cert_e602907699054 : check e602907699054 [[],[]] .chain = true := by decide
def e602907699062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e602907699062 : Closed e602907699062 ∧ code e602907699062 = 2801930954614 := by decide
theorem cert_e602907699062 : check e602907699062 [[],[]] .chain = true := by decide
def e602907699126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e602907699126 : Closed e602907699126 ∧ code e602907699126 = 2801930954678 := by decide
theorem cert_e602907699126 : check e602907699126 [[],[]] .chain = true := by decide
def e602907700462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e602907700462 : Closed e602907700462 ∧ code e602907700462 = 2801930956014 := by decide
theorem cert_e602907700462 : check e602907700462 [[],[]] .chain = true := by decide
def e602907700470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e602907700470 : Closed e602907700470 ∧ code e602907700470 = 2801930956022 := by decide
theorem cert_e602907700470 : check e602907700470 [[],[]] .chain = true := by decide
def e602907700854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e602907700854 : Closed e602907700854 ∧ code e602907700854 = 2801930956406 := by decide
theorem cert_e602907700854 : check e602907700854 [[],[]] .chain = true := by decide
def e602907701742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2)))))))
theorem wire_e602907701742 : Closed e602907701742 ∧ code e602907701742 = 2801930957294 := by decide
theorem cert_e602907701742 : check e602907701742 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602907702126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e602907702126 : Closed e602907702126 ∧ code e602907702126 = 2801930957678 := by decide
theorem cert_e602907702126 : check e602907702126 [[],[]] .chain = true := by decide
def e602907702134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e602907702134 : Closed e602907702134 ∧ code e602907702134 = 2801930957686 := by decide
theorem cert_e602907702134 : check e602907702134 [[],[]] .chain = true := by decide
def e602907702190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e602907702190 : Closed e602907702190 ∧ code e602907702190 = 2801930957742 := by decide
theorem cert_e602907702190 : check e602907702190 [[],[]] .chain = true := by decide
def e602907702202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e602907702202 : Closed e602907702202 ∧ code e602907702202 = 2801930957754 := by decide
theorem cert_e602907702202 : check e602907702202 [[],[]] .chain = true := by decide
def e602907702230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e602907702230 : Closed e602907702230 ∧ code e602907702230 = 2801930957782 := by decide
theorem cert_e602907702230 : check e602907702230 [[],[]] .chain = true := by decide
def e602907702234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e602907702234 : Closed e602907702234 ∧ code e602907702234 = 2801930957786 := by decide
theorem cert_e602907702234 : check e602907702234 [[],[]] .chain = true := by decide
def e602907702510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e602907702510 : Closed e602907702510 ∧ code e602907702510 = 2801930958062 := by decide
theorem cert_e602907702510 : check e602907702510 [[],[]] .chain = true := by decide
def e602907702518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e602907702518 : Closed e602907702518 ∧ code e602907702518 = 2801930958070 := by decide
theorem cert_e602907702518 : check e602907702518 [[],[]] .chain = true := by decide
def e602907702894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e602907702894 : Closed e602907702894 ∧ code e602907702894 = 2801930958446 := by decide
theorem cert_e602907702894 : check e602907702894 [[],[]] .chain = true := by decide
def e602907702906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e602907702906 : Closed e602907702906 ∧ code e602907702906 = 2801930958458 := by decide
theorem cert_e602907702906 : check e602907702906 [[],[]] .chain = true := by decide
def e602907703070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3))))))))
theorem wire_e602907703070 : Closed e602907703070 ∧ code e602907703070 = 2801930958622 := by decide
theorem cert_e602907703070 : check e602907703070 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602907703094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e602907703094 : Closed e602907703094 ∧ code e602907703094 = 2801930958646 := by decide
theorem cert_e602907703094 : check e602907703094 [[],[]] .chain = true := by decide
def e602907703098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e602907703098 : Closed e602907703098 ∧ code e602907703098 = 2801930958650 := by decide
theorem cert_e602907703098 : check e602907703098 [[],[]] .chain = true := by decide
def e602907703534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2)))))))
theorem wire_e602907703534 : Closed e602907703534 ∧ code e602907703534 = 2801930959086 := by decide
theorem cert_e602907703534 : check e602907703534 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907703542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1)))))))
theorem wire_e602907703542 : Closed e602907703542 ∧ code e602907703542 = 2801930959094 := by decide
theorem cert_e602907703542 : check e602907703542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602907703734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e602907703734 : Closed e602907703734 ∧ code e602907703734 = 2801930959286 := by decide
theorem cert_e602907703734 : check e602907703734 [[],[]] .chain = true := by decide
def e602907703766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e602907703766 : Closed e602907703766 ∧ code e602907703766 = 2801930959318 := by decide
theorem cert_e602907703766 : check e602907703766 [[],[]] .chain = true := by decide
def e602907703770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e602907703770 : Closed e602907703770 ∧ code e602907703770 = 2801930959322 := by decide
theorem cert_e602907703770 : check e602907703770 [[],[]] .chain = true := by decide
def e602907703926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e602907703926 : Closed e602907703926 ∧ code e602907703926 = 2801930959478 := by decide
theorem cert_e602907703926 : check e602907703926 [[],[]] .chain = true := by decide
def e602907704094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3))))))))
theorem wire_e602907704094 : Closed e602907704094 ∧ code e602907704094 = 2801930959646 := by decide
theorem cert_e602907704094 : check e602907704094 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907704118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e602907704118 : Closed e602907704118 ∧ code e602907704118 = 2801930959670 := by decide
theorem cert_e602907704118 : check e602907704118 [[],[]] .chain = true := by decide
def e602907704122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e602907704122 : Closed e602907704122 ∧ code e602907704122 = 2801930959674 := by decide
theorem cert_e602907704122 : check e602907704122 [[],[]] .chain = true := by decide
def e602907704206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2))))))))
theorem wire_e602907704206 : Closed e602907704206 ∧ code e602907704206 = 2801930959758 := by decide
theorem cert_e602907704206 : check e602907704206 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e602907711342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e602907711342 : Closed e602907711342 ∧ code e602907711342 = 2801930966894 := by decide
theorem cert_e602907711342 : check e602907711342 [[],[]] .chain = true := by decide
def e602907711350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e602907711350 : Closed e602907711350 ∧ code e602907711350 = 2801930966902 := by decide
theorem cert_e602907711350 : check e602907711350 [[],[]] .chain = true := by decide
def e602907711414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e602907711414 : Closed e602907711414 ∧ code e602907711414 = 2801930966966 := by decide
theorem cert_e602907711414 : check e602907711414 [[],[]] .chain = true := by decide
def e602907712750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e602907712750 : Closed e602907712750 ∧ code e602907712750 = 2801930968302 := by decide
theorem cert_e602907712750 : check e602907712750 [[],[]] .chain = true := by decide
def e602907712758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e602907712758 : Closed e602907712758 ∧ code e602907712758 = 2801930968310 := by decide
theorem cert_e602907712758 : check e602907712758 [[],[]] .chain = true := by decide
def e602907713142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e602907713142 : Closed e602907713142 ∧ code e602907713142 = 2801930968694 := by decide
theorem cert_e602907713142 : check e602907713142 [[],[]] .chain = true := by decide
def e602907722718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e602907722718 : Closed e602907722718 ∧ code e602907722718 = 2801930978270 := by decide
theorem cert_e602907722718 : check e602907722718 [[],[]] .chain = true := by decide
def e602907722734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e602907722734 : Closed e602907722734 ∧ code e602907722734 = 2801930978286 := by decide
theorem cert_e602907722734 : check e602907722734 [[],[]] .chain = true := by decide
def e602907724654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602907724654 : Closed e602907724654 ∧ code e602907724654 = 2801930980206 := by decide
theorem cert_e602907724654 : check e602907724654 [[],[]] .chain = true := by decide
def e602907724662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602907724662 : Closed e602907724662 ∧ code e602907724662 = 2801930980214 := by decide
theorem cert_e602907724662 : check e602907724662 [[],[]] .chain = true := by decide
def e602907724718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602907724718 : Closed e602907724718 ∧ code e602907724718 = 2801930980270 := by decide
theorem cert_e602907724718 : check e602907724718 [[],[]] .chain = true := by decide
def e602907724730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602907724730 : Closed e602907724730 ∧ code e602907724730 = 2801930980282 := by decide
theorem cert_e602907724730 : check e602907724730 [[],[]] .chain = true := by decide
def e602907724758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602907724758 : Closed e602907724758 ∧ code e602907724758 = 2801930980310 := by decide
theorem cert_e602907724758 : check e602907724758 [[],[]] .chain = true := by decide
def e602907724762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602907724762 : Closed e602907724762 ∧ code e602907724762 = 2801930980314 := by decide
theorem cert_e602907724762 : check e602907724762 [[],[]] .chain = true := by decide
def e602907725038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602907725038 : Closed e602907725038 ∧ code e602907725038 = 2801930980590 := by decide
theorem cert_e602907725038 : check e602907725038 [[],[]] .chain = true := by decide
def e602907725046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602907725046 : Closed e602907725046 ∧ code e602907725046 = 2801930980598 := by decide
theorem cert_e602907725046 : check e602907725046 [[],[]] .chain = true := by decide
def e602907725422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602907725422 : Closed e602907725422 ∧ code e602907725422 = 2801930980974 := by decide
theorem cert_e602907725422 : check e602907725422 [[],[]] .chain = true := by decide
def e602907725434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602907725434 : Closed e602907725434 ∧ code e602907725434 = 2801930980986 := by decide
theorem cert_e602907725434 : check e602907725434 [[],[]] .chain = true := by decide
def e602907725598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e602907725598 : Closed e602907725598 ∧ code e602907725598 = 2801930981150 := by decide
theorem cert_e602907725598 : check e602907725598 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602907725622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602907725622 : Closed e602907725622 ∧ code e602907725622 = 2801930981174 := by decide
theorem cert_e602907725622 : check e602907725622 [[],[]] .chain = true := by decide
def e602907725626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602907725626 : Closed e602907725626 ∧ code e602907725626 = 2801930981178 := by decide
theorem cert_e602907725626 : check e602907725626 [[],[]] .chain = true := by decide
def e602907730414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e602907730414 : Closed e602907730414 ∧ code e602907730414 = 2801930985966 := by decide
theorem cert_e602907730414 : check e602907730414 [[],[]] .chain = true := by decide
def e602907731382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e602907731382 : Closed e602907731382 ∧ code e602907731382 = 2801930986934 := by decide
theorem cert_e602907731382 : check e602907731382 [[],[]] .chain = true := by decide
def e602907731414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e602907731414 : Closed e602907731414 ∧ code e602907731414 = 2801930986966 := by decide
theorem cert_e602907731414 : check e602907731414 [[],[]] .chain = true := by decide
def e602907731418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e602907731418 : Closed e602907731418 ∧ code e602907731418 = 2801930986970 := by decide
theorem cert_e602907731418 : check e602907731418 [[],[]] .chain = true := by decide
def e602907731574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e602907731574 : Closed e602907731574 ∧ code e602907731574 = 2801930987126 := by decide
theorem cert_e602907731574 : check e602907731574 [[],[]] .chain = true := by decide
def e602907731742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e602907731742 : Closed e602907731742 ∧ code e602907731742 = 2801930987294 := by decide
theorem cert_e602907731742 : check e602907731742 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907731766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e602907731766 : Closed e602907731766 ∧ code e602907731766 = 2801930987318 := by decide
theorem cert_e602907731766 : check e602907731766 [[],[]] .chain = true := by decide
def e602907731770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e602907731770 : Closed e602907731770 ∧ code e602907731770 = 2801930987322 := by decide
theorem cert_e602907731770 : check e602907731770 [[],[]] .chain = true := by decide
def e602907731854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e602907731854 : Closed e602907731854 ∧ code e602907731854 = 2801930987406 := by decide
theorem cert_e602907731854 : check e602907731854 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907880926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e602907880926 : Closed e602907880926 ∧ code e602907880926 = 2801931136478 := by decide
theorem cert_e602907880926 : check e602907880926 [[],[]] .chain = true := by decide
def e602907880942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e602907880942 : Closed e602907880942 ∧ code e602907880942 = 2801931136494 := by decide
theorem cert_e602907880942 : check e602907880942 [[],[]] .chain = true := by decide
def e602907881182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e602907881182 : Closed e602907881182 ∧ code e602907881182 = 2801931136734 := by decide
theorem cert_e602907881182 : check e602907881182 [[],[]] .chain = true := by decide
def e602907881206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e602907881206 : Closed e602907881206 ∧ code e602907881206 = 2801931136758 := by decide
theorem cert_e602907881206 : check e602907881206 [[],[]] .chain = true := by decide
def e602907881310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e602907881310 : Closed e602907881310 ∧ code e602907881310 = 2801931136862 := by decide
theorem cert_e602907881310 : check e602907881310 [[],[]] .chain = true := by decide
def e602907881338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e602907881338 : Closed e602907881338 ∧ code e602907881338 = 2801931136890 := by decide
theorem cert_e602907881338 : check e602907881338 [[],[]] .chain = true := by decide
def e602907881390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e602907881390 : Closed e602907881390 ∧ code e602907881390 = 2801931136942 := by decide
theorem cert_e602907881390 : check e602907881390 [[],[]] .chain = true := by decide
def e602907881398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e602907881398 : Closed e602907881398 ∧ code e602907881398 = 2801931136950 := by decide
theorem cert_e602907881398 : check e602907881398 [[],[]] .chain = true := by decide
def e602907881402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e602907881402 : Closed e602907881402 ∧ code e602907881402 = 2801931136954 := by decide
theorem cert_e602907881402 : check e602907881402 [[],[]] .chain = true := by decide
def e602907882462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e602907882462 : Closed e602907882462 ∧ code e602907882462 = 2801931138014 := by decide
theorem cert_e602907882462 : check e602907882462 [[],[]] .chain = true := by decide
def e602907882478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e602907882478 : Closed e602907882478 ∧ code e602907882478 = 2801931138030 := by decide
theorem cert_e602907882478 : check e602907882478 [[],[]] .chain = true := by decide
def e602907883998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e602907883998 : Closed e602907883998 ∧ code e602907883998 = 2801931139550 := by decide
theorem cert_e602907883998 : check e602907883998 [[],[]] .chain = true := by decide
def e602907884022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e602907884022 : Closed e602907884022 ∧ code e602907884022 = 2801931139574 := by decide
theorem cert_e602907884022 : check e602907884022 [[],[]] .chain = true := by decide
def e602907884766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e602907884766 : Closed e602907884766 ∧ code e602907884766 = 2801931140318 := by decide
theorem cert_e602907884766 : check e602907884766 [[],[]] .chain = true := by decide
def e602907884794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e602907884794 : Closed e602907884794 ∧ code e602907884794 = 2801931140346 := by decide
theorem cert_e602907884794 : check e602907884794 [[],[]] .chain = true := by decide
def e602907885166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e602907885166 : Closed e602907885166 ∧ code e602907885166 = 2801931140718 := by decide
theorem cert_e602907885166 : check e602907885166 [[],[]] .chain = true := by decide
def e602907885174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e602907885174 : Closed e602907885174 ∧ code e602907885174 = 2801931140726 := by decide
theorem cert_e602907885174 : check e602907885174 [[],[]] .chain = true := by decide
def e602907885178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e602907885178 : Closed e602907885178 ∧ code e602907885178 = 2801931140730 := by decide
theorem cert_e602907885178 : check e602907885178 [[],[]] .chain = true := by decide
def e602907913582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e602907913582 : Closed e602907913582 ∧ code e602907913582 = 2801931169134 := by decide
theorem cert_e602907913582 : check e602907913582 [[],[]] .chain = true := by decide
def e602907913590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e602907913590 : Closed e602907913590 ∧ code e602907913590 = 2801931169142 := by decide
theorem cert_e602907913590 : check e602907913590 [[],[]] .chain = true := by decide
def e602907913646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e602907913646 : Closed e602907913646 ∧ code e602907913646 = 2801931169198 := by decide
theorem cert_e602907913646 : check e602907913646 [[],[]] .chain = true := by decide
def e602907913658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e602907913658 : Closed e602907913658 ∧ code e602907913658 = 2801931169210 := by decide
theorem cert_e602907913658 : check e602907913658 [[],[]] .chain = true := by decide
def e602907913686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e602907913686 : Closed e602907913686 ∧ code e602907913686 = 2801931169238 := by decide
theorem cert_e602907913686 : check e602907913686 [[],[]] .chain = true := by decide
def e602907913690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e602907913690 : Closed e602907913690 ∧ code e602907913690 = 2801931169242 := by decide
theorem cert_e602907913690 : check e602907913690 [[],[]] .chain = true := by decide
def e602907913902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e602907913902 : Closed e602907913902 ∧ code e602907913902 = 2801931169454 := by decide
theorem cert_e602907913902 : check e602907913902 [[],[]] .chain = true := by decide
def e602907913914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e602907913914 : Closed e602907913914 ∧ code e602907913914 = 2801931169466 := by decide
theorem cert_e602907913914 : check e602907913914 [[],[]] .chain = true := by decide
def e602907913962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e602907913962 : Closed e602907913962 ∧ code e602907913962 = 2801931169514 := by decide
theorem cert_e602907913962 : check e602907913962 [[],[]] .chain = true := by decide
def e602907914070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e602907914070 : Closed e602907914070 ∧ code e602907914070 = 2801931169622 := by decide
theorem cert_e602907914070 : check e602907914070 [[],[]] .chain = true := by decide
def e602907914074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e602907914074 : Closed e602907914074 ∧ code e602907914074 = 2801931169626 := by decide
theorem cert_e602907914074 : check e602907914074 [[],[]] .chain = true := by decide
def e602907914090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e602907914090 : Closed e602907914090 ∧ code e602907914090 = 2801931169642 := by decide
theorem cert_e602907914090 : check e602907914090 [[],[]] .chain = true := by decide
def e602907914734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))))
theorem wire_e602907914734 : Closed e602907914734 ∧ code e602907914734 = 2801931170286 := by decide
theorem cert_e602907914734 : check e602907914734 [[],[]] .sourceHead = true := by decide
def e602907915118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e602907915118 : Closed e602907915118 ∧ code e602907915118 = 2801931170670 := by decide
theorem cert_e602907915118 : check e602907915118 [[],[]] .chain = true := by decide
def e602907915126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e602907915126 : Closed e602907915126 ∧ code e602907915126 = 2801931170678 := by decide
theorem cert_e602907915126 : check e602907915126 [[],[]] .chain = true := by decide
def e602907915182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e602907915182 : Closed e602907915182 ∧ code e602907915182 = 2801931170734 := by decide
theorem cert_e602907915182 : check e602907915182 [[],[]] .chain = true := by decide
def e602907915194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e602907915194 : Closed e602907915194 ∧ code e602907915194 = 2801931170746 := by decide
theorem cert_e602907915194 : check e602907915194 [[],[]] .chain = true := by decide
def e602907915222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e602907915222 : Closed e602907915222 ∧ code e602907915222 = 2801931170774 := by decide
theorem cert_e602907915222 : check e602907915222 [[],[]] .chain = true := by decide
def e602907915226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e602907915226 : Closed e602907915226 ∧ code e602907915226 = 2801931170778 := by decide
theorem cert_e602907915226 : check e602907915226 [[],[]] .chain = true := by decide
def e602907915502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e602907915502 : Closed e602907915502 ∧ code e602907915502 = 2801931171054 := by decide
theorem cert_e602907915502 : check e602907915502 [[],[]] .chain = true := by decide
def e602907915510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e602907915510 : Closed e602907915510 ∧ code e602907915510 = 2801931171062 := by decide
theorem cert_e602907915510 : check e602907915510 [[],[]] .chain = true := by decide
def e602907915886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e602907915886 : Closed e602907915886 ∧ code e602907915886 = 2801931171438 := by decide
theorem cert_e602907915886 : check e602907915886 [[],[]] .chain = true := by decide
def e602907915898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e602907915898 : Closed e602907915898 ∧ code e602907915898 = 2801931171450 := by decide
theorem cert_e602907915898 : check e602907915898 [[],[]] .chain = true := by decide
def e602907916062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))))
theorem wire_e602907916062 : Closed e602907916062 ∧ code e602907916062 = 2801931171614 := by decide
theorem cert_e602907916062 : check e602907916062 [[],[]] .sourceHead = true := by decide
def e602907916086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e602907916086 : Closed e602907916086 ∧ code e602907916086 = 2801931171638 := by decide
theorem cert_e602907916086 : check e602907916086 [[],[]] .chain = true := by decide
def e602907916090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e602907916090 : Closed e602907916090 ∧ code e602907916090 = 2801931171642 := by decide
theorem cert_e602907916090 : check e602907916090 [[],[]] .chain = true := by decide
def e602907916718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e602907916718 : Closed e602907916718 ∧ code e602907916718 = 2801931172270 := by decide
theorem cert_e602907916718 : check e602907916718 [[],[]] .chain = true := by decide
def e602907916730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e602907916730 : Closed e602907916730 ∧ code e602907916730 = 2801931172282 := by decide
theorem cert_e602907916730 : check e602907916730 [[],[]] .chain = true := by decide
def e602907916778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e602907916778 : Closed e602907916778 ∧ code e602907916778 = 2801931172330 := by decide
theorem cert_e602907916778 : check e602907916778 [[],[]] .chain = true := by decide
def e602907916910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e602907916910 : Closed e602907916910 ∧ code e602907916910 = 2801931172462 := by decide
theorem cert_e602907916910 : check e602907916910 [[],[]] .chain = true := by decide
def e602907916922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e602907916922 : Closed e602907916922 ∧ code e602907916922 = 2801931172474 := by decide
theorem cert_e602907916922 : check e602907916922 [[],[]] .chain = true := by decide
def e602907917210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e602907917210 : Closed e602907917210 ∧ code e602907917210 = 2801931172762 := by decide
theorem cert_e602907917210 : check e602907917210 [[],[]] .chain = true := by decide
def e602907917422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))))
theorem wire_e602907917422 : Closed e602907917422 ∧ code e602907917422 = 2801931172974 := by decide
theorem cert_e602907917422 : check e602907917422 [[],[]] .sourceHead = true := by decide
def e602907917434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))))
theorem wire_e602907917434 : Closed e602907917434 ∧ code e602907917434 = 2801931172986 := by decide
theorem cert_e602907917434 : check e602907917434 [[],[]] .sourceHead = true := by decide
def e602907917526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e602907917526 : Closed e602907917526 ∧ code e602907917526 = 2801931173078 := by decide
theorem cert_e602907917526 : check e602907917526 [[],[]] .chain = true := by decide
def e602907917530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e602907917530 : Closed e602907917530 ∧ code e602907917530 = 2801931173082 := by decide
theorem cert_e602907917530 : check e602907917530 [[],[]] .chain = true := by decide
def e602907917546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e602907917546 : Closed e602907917546 ∧ code e602907917546 = 2801931173098 := by decide
theorem cert_e602907917546 : check e602907917546 [[],[]] .chain = true := by decide
def e602907917598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))))
theorem wire_e602907917598 : Closed e602907917598 ∧ code e602907917598 = 2801931173150 := by decide
theorem cert_e602907917598 : check e602907917598 [[],[]] .sourceHead = true := by decide
def e602907917622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e602907917622 : Closed e602907917622 ∧ code e602907917622 = 2801931173174 := by decide
theorem cert_e602907917622 : check e602907917622 [[],[]] .chain = true := by decide
def e602907917626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e602907917626 : Closed e602907917626 ∧ code e602907917626 = 2801931173178 := by decide
theorem cert_e602907917626 : check e602907917626 [[],[]] .chain = true := by decide
def e602907917722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e602907917722 : Closed e602907917722 ∧ code e602907917722 = 2801931173274 := by decide
theorem cert_e602907917722 : check e602907917722 [[],[]] .chain = true := by decide
def e602907917766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1))))))))
theorem wire_e602907917766 : Closed e602907917766 ∧ code e602907917766 = 2801931173318 := by decide
theorem cert_e602907917766 : check e602907917766 [[],[]] .sourceHead = true := by decide
def e602907919326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e602907919326 : Closed e602907919326 ∧ code e602907919326 = 2801931174878 := by decide
theorem cert_e602907919326 : check e602907919326 [[],[]] .chain = true := by decide
def e602907919342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e602907919342 : Closed e602907919342 ∧ code e602907919342 = 2801931174894 := by decide
theorem cert_e602907919342 : check e602907919342 [[],[]] .chain = true := by decide
def e602907921262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602907921262 : Closed e602907921262 ∧ code e602907921262 = 2801931176814 := by decide
theorem cert_e602907921262 : check e602907921262 [[],[]] .chain = true := by decide
def e602907921270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602907921270 : Closed e602907921270 ∧ code e602907921270 = 2801931176822 := by decide
theorem cert_e602907921270 : check e602907921270 [[],[]] .chain = true := by decide
def e602907921326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602907921326 : Closed e602907921326 ∧ code e602907921326 = 2801931176878 := by decide
theorem cert_e602907921326 : check e602907921326 [[],[]] .chain = true := by decide
def e602907921338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602907921338 : Closed e602907921338 ∧ code e602907921338 = 2801931176890 := by decide
theorem cert_e602907921338 : check e602907921338 [[],[]] .chain = true := by decide
def e602907921366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602907921366 : Closed e602907921366 ∧ code e602907921366 = 2801931176918 := by decide
theorem cert_e602907921366 : check e602907921366 [[],[]] .chain = true := by decide
def e602907921370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602907921370 : Closed e602907921370 ∧ code e602907921370 = 2801931176922 := by decide
theorem cert_e602907921370 : check e602907921370 [[],[]] .chain = true := by decide
def e602907921646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602907921646 : Closed e602907921646 ∧ code e602907921646 = 2801931177198 := by decide
theorem cert_e602907921646 : check e602907921646 [[],[]] .chain = true := by decide
def e602907921654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602907921654 : Closed e602907921654 ∧ code e602907921654 = 2801931177206 := by decide
theorem cert_e602907921654 : check e602907921654 [[],[]] .chain = true := by decide
def e602907922030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602907922030 : Closed e602907922030 ∧ code e602907922030 = 2801931177582 := by decide
theorem cert_e602907922030 : check e602907922030 [[],[]] .chain = true := by decide
def e602907922042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602907922042 : Closed e602907922042 ∧ code e602907922042 = 2801931177594 := by decide
theorem cert_e602907922042 : check e602907922042 [[],[]] .chain = true := by decide
end Blc.Floor41
