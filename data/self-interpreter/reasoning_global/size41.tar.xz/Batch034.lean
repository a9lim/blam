import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e597436751290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e597436751290 : Closed e597436751290 ∧ code e597436751290 = 2796460006842 := by decide
theorem cert_e597436751290 : check e597436751290 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e597436751318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e597436751318 : Closed e597436751318 ∧ code e597436751318 = 2796460006870 := by decide
theorem cert_e597436751318 : check e597436751318 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e597436751322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e597436751322 : Closed e597436751322 ∧ code e597436751322 = 2796460006874 := by decide
def e597436751542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e597436751542 : Closed e597436751542 ∧ code e597436751542 = 2796460007094 := by decide
theorem cert_e597436751542 : check e597436751542 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e597436751574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e597436751574 : Closed e597436751574 ∧ code e597436751574 = 2796460007126 := by decide
theorem cert_e597436751574 : check e597436751574 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e597436751578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e597436751578 : Closed e597436751578 ∧ code e597436751578 = 2796460007130 := by decide
theorem cert_e597436751578 : check e597436751578 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e597436753774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e597436753774 : Closed e597436753774 ∧ code e597436753774 = 2796460009326 := by decide
theorem cert_e597436753774 : check e597436753774 [[],[.left],[]] .sourceHead = true := by decide
def e597436753782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e597436753782 : Closed e597436753782 ∧ code e597436753782 = 2796460009334 := by decide
theorem cert_e597436753782 : check e597436753782 [[],[.left],[]] .sourceHead = true := by decide
def e597436753846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e597436753846 : Closed e597436753846 ∧ code e597436753846 = 2796460009398 := by decide
theorem cert_e597436753846 : check e597436753846 [[],[.left],[]] .sourceHead = true := by decide
def e597436755182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e597436755182 : Closed e597436755182 ∧ code e597436755182 = 2796460010734 := by decide
theorem cert_e597436755182 : check e597436755182 [[],[.left],[]] .sourceHead = true := by decide
def e597436755190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e597436755190 : Closed e597436755190 ∧ code e597436755190 = 2796460010742 := by decide
theorem cert_e597436755190 : check e597436755190 [[],[.left],[]] .sourceHead = true := by decide
def e597436755574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e597436755574 : Closed e597436755574 ∧ code e597436755574 = 2796460011126 := by decide
theorem cert_e597436755574 : check e597436755574 [[],[.left],[]] .sourceHead = true := by decide
def e597436756846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e597436756846 : Closed e597436756846 ∧ code e597436756846 = 2796460012398 := by decide
theorem cert_e597436756846 : check e597436756846 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436756854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e597436756854 : Closed e597436756854 ∧ code e597436756854 = 2796460012406 := by decide
theorem cert_e597436756854 : check e597436756854 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436756910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e597436756910 : Closed e597436756910 ∧ code e597436756910 = 2796460012462 := by decide
theorem cert_e597436756910 : check e597436756910 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436756922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e597436756922 : Closed e597436756922 ∧ code e597436756922 = 2796460012474 := by decide
theorem cert_e597436756922 : checkPay e597436756922 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e597436756950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e597436756950 : Closed e597436756950 ∧ code e597436756950 = 2796460012502 := by decide
theorem cert_e597436756950 : check e597436756950 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436756954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e597436756954 : Closed e597436756954 ∧ code e597436756954 = 2796460012506 := by decide
theorem cert_e597436756954 : checkPay e597436756954 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e597436757230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e597436757230 : Closed e597436757230 ∧ code e597436757230 = 2796460012782 := by decide
theorem cert_e597436757230 : check e597436757230 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e597436757238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e597436757238 : Closed e597436757238 ∧ code e597436757238 = 2796460012790 := by decide
theorem cert_e597436757238 : check e597436757238 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436757614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e597436757614 : Closed e597436757614 ∧ code e597436757614 = 2796460013166 := by decide
theorem cert_e597436757614 : check e597436757614 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e597436757626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e597436757626 : Closed e597436757626 ∧ code e597436757626 = 2796460013178 := by decide
theorem cert_e597436757626 : check e597436757626 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436757814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e597436757814 : Closed e597436757814 ∧ code e597436757814 = 2796460013366 := by decide
theorem cert_e597436757814 : check e597436757814 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e597436757818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e597436757818 : Closed e597436757818 ∧ code e597436757818 = 2796460013370 := by decide
theorem cert_e597436757818 : check e597436757818 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e597436758454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e597436758454 : Closed e597436758454 ∧ code e597436758454 = 2796460014006 := by decide
theorem cert_e597436758454 : check e597436758454 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e597436758486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e597436758486 : Closed e597436758486 ∧ code e597436758486 = 2796460014038 := by decide
theorem cert_e597436758486 : check e597436758486 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e597436758490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e597436758490 : Closed e597436758490 ∧ code e597436758490 = 2796460014042 := by decide
theorem cert_e597436758490 : check e597436758490 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e597436758646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e597436758646 : Closed e597436758646 ∧ code e597436758646 = 2796460014198 := by decide
theorem cert_e597436758646 : check e597436758646 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e597436758838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e597436758838 : Closed e597436758838 ∧ code e597436758838 = 2796460014390 := by decide
theorem cert_e597436758838 : check e597436758838 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e597436758842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e597436758842 : Closed e597436758842 ∧ code e597436758842 = 2796460014394 := by decide
theorem cert_e597436758842 : check e597436758842 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e597436766062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e597436766062 : Closed e597436766062 ∧ code e597436766062 = 2796460021614 := by decide
theorem cert_e597436766062 : check e597436766062 [[],[.left],[]] .sourceHead = true := by decide
def e597436766070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e597436766070 : Closed e597436766070 ∧ code e597436766070 = 2796460021622 := by decide
theorem cert_e597436766070 : check e597436766070 [[],[.left],[]] .sourceHead = true := by decide
def e597436766134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e597436766134 : Closed e597436766134 ∧ code e597436766134 = 2796460021686 := by decide
theorem cert_e597436766134 : check e597436766134 [[],[.left],[]] .sourceHead = true := by decide
def e597436767470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e597436767470 : Closed e597436767470 ∧ code e597436767470 = 2796460023022 := by decide
theorem cert_e597436767470 : check e597436767470 [[],[.left],[]] .sourceHead = true := by decide
def e597436767478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e597436767478 : Closed e597436767478 ∧ code e597436767478 = 2796460023030 := by decide
theorem cert_e597436767478 : check e597436767478 [[],[.left],[]] .sourceHead = true := by decide
def e597436767862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e597436767862 : Closed e597436767862 ∧ code e597436767862 = 2796460023414 := by decide
theorem cert_e597436767862 : check e597436767862 [[],[.left],[]] .sourceHead = true := by decide
def e597436779374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597436779374 : Closed e597436779374 ∧ code e597436779374 = 2796460034926 := by decide
theorem cert_e597436779374 : check e597436779374 [[],[.left],[],[.under]] .three = true := by decide
def e597436779382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597436779382 : Closed e597436779382 ∧ code e597436779382 = 2796460034934 := by decide
theorem cert_e597436779382 : check e597436779382 [[],[.left],[],[.under]] .three = true := by decide
def e597436779438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597436779438 : Closed e597436779438 ∧ code e597436779438 = 2796460034990 := by decide
theorem cert_e597436779438 : check e597436779438 [[],[.left],[],[.under]] .three = true := by decide
def e597436779450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597436779450 : Closed e597436779450 ∧ code e597436779450 = 2796460035002 := by decide
theorem cert_e597436779450 : check e597436779450 [[],[.left],[],[.under]] .three = true := by decide
def e597436779478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597436779478 : Closed e597436779478 ∧ code e597436779478 = 2796460035030 := by decide
theorem cert_e597436779478 : check e597436779478 [[],[.left],[],[.under]] .three = true := by decide
def e597436779482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597436779482 : Closed e597436779482 ∧ code e597436779482 = 2796460035034 := by decide
theorem cert_e597436779482 : check e597436779482 [[],[.left],[],[.under]] .three = true := by decide
def e597436779758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597436779758 : Closed e597436779758 ∧ code e597436779758 = 2796460035310 := by decide
theorem cert_e597436779758 : check e597436779758 [[],[.left],[],[.under]] .three = true := by decide
def e597436779766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597436779766 : Closed e597436779766 ∧ code e597436779766 = 2796460035318 := by decide
theorem cert_e597436779766 : check e597436779766 [[],[.left],[],[.under]] .three = true := by decide
def e597436780142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597436780142 : Closed e597436780142 ∧ code e597436780142 = 2796460035694 := by decide
theorem cert_e597436780142 : check e597436780142 [[],[.left],[],[.under]] .three = true := by decide
def e597436780154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597436780154 : Closed e597436780154 ∧ code e597436780154 = 2796460035706 := by decide
theorem cert_e597436780154 : check e597436780154 [[],[.left],[],[.under]] .three = true := by decide
def e597436780342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597436780342 : Closed e597436780342 ∧ code e597436780342 = 2796460035894 := by decide
theorem cert_e597436780342 : check e597436780342 [[],[.left],[],[.under]] .three = true := by decide
def e597436780346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597436780346 : Closed e597436780346 ∧ code e597436780346 = 2796460035898 := by decide
theorem cert_e597436780346 : check e597436780346 [[],[.left],[],[.under]] .three = true := by decide
def e597436786102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e597436786102 : Closed e597436786102 ∧ code e597436786102 = 2796460041654 := by decide
theorem cert_e597436786102 : check e597436786102 [[],[.left],[],[.under]] .smaller = true := by decide
def e597436786134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e597436786134 : Closed e597436786134 ∧ code e597436786134 = 2796460041686 := by decide
theorem cert_e597436786134 : check e597436786134 [[],[.left],[],[.under]] .smaller = true := by decide
def e597436786138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e597436786138 : Closed e597436786138 ∧ code e597436786138 = 2796460041690 := by decide
theorem cert_e597436786138 : check e597436786138 [[],[.left],[],[.under]] .smaller = true := by decide
def e597436786294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e597436786294 : Closed e597436786294 ∧ code e597436786294 = 2796460041846 := by decide
theorem cert_e597436786294 : check e597436786294 [[],[.left],[],[.under]] .smaller = true := by decide
def e597436786486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e597436786486 : Closed e597436786486 ∧ code e597436786486 = 2796460042038 := by decide
theorem cert_e597436786486 : check e597436786486 [[],[.left],[],[.under]] .smaller = true := by decide
def e597436786490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e597436786490 : Closed e597436786490 ∧ code e597436786490 = 2796460042042 := by decide
theorem cert_e597436786490 : check e597436786490 [[],[.left],[],[.under]] .smaller = true := by decide
def e597437123438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597437123438 : Closed e597437123438 ∧ code e597437123438 = 2796460378990 := by decide
theorem cert_e597437123438 : check e597437123438 [[],[.left],[],[]] .smaller = true := by decide
def e597437123446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597437123446 : Closed e597437123446 ∧ code e597437123446 = 2796460378998 := by decide
theorem cert_e597437123446 : check e597437123446 [[],[.left],[],[]] .smaller = true := by decide
def e597437123502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597437123502 : Closed e597437123502 ∧ code e597437123502 = 2796460379054 := by decide
theorem cert_e597437123502 : check e597437123502 [[],[.left],[],[]] .smaller = true := by decide
def e597437123514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597437123514 : Closed e597437123514 ∧ code e597437123514 = 2796460379066 := by decide
theorem cert_e597437123514 : check e597437123514 [[],[.left],[],[]] .smaller = true := by decide
def e597437123542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597437123542 : Closed e597437123542 ∧ code e597437123542 = 2796460379094 := by decide
theorem cert_e597437123542 : check e597437123542 [[],[.left],[],[]] .smaller = true := by decide
def e597437123546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597437123546 : Closed e597437123546 ∧ code e597437123546 = 2796460379098 := by decide
theorem cert_e597437123546 : check e597437123546 [[],[.left],[],[]] .smaller = true := by decide
def e597437123822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597437123822 : Closed e597437123822 ∧ code e597437123822 = 2796460379374 := by decide
theorem cert_e597437123822 : check e597437123822 [[],[.left],[],[]] .smaller = true := by decide
def e597437123830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597437123830 : Closed e597437123830 ∧ code e597437123830 = 2796460379382 := by decide
theorem cert_e597437123830 : check e597437123830 [[],[.left],[],[]] .smaller = true := by decide
def e597437124206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597437124206 : Closed e597437124206 ∧ code e597437124206 = 2796460379758 := by decide
theorem cert_e597437124206 : check e597437124206 [[],[.left],[],[]] .smaller = true := by decide
def e597437124218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597437124218 : Closed e597437124218 ∧ code e597437124218 = 2796460379770 := by decide
theorem cert_e597437124218 : check e597437124218 [[],[.left],[],[]] .smaller = true := by decide
def e597437124406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597437124406 : Closed e597437124406 ∧ code e597437124406 = 2796460379958 := by decide
theorem cert_e597437124406 : check e597437124406 [[],[.left],[],[]] .smaller = true := by decide
def e597437124410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597437124410 : Closed e597437124410 ∧ code e597437124410 = 2796460379962 := by decide
theorem cert_e597437124410 : check e597437124410 [[],[.left],[],[]] .smaller = true := by decide
def e597808757274 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597808757274 : Closed e597808757274 ∧ code e597808757274 = 2796832012826 := by decide
theorem cert_e597808757274 : check e597808757274 [[]] .width = true := by decide
def e597808765466 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597808765466 : Closed e597808765466 ∧ code e597808765466 = 2796832021018 := by decide
theorem cert_e597808765466 : check e597808765466 [[]] .width = true := by decide
def e597808822810 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597808822810 : Closed e597808822810 ∧ code e597808822810 = 2796832078362 := by decide
theorem cert_e597808822810 : check e597808822810 [[]] .width = true := by decide
def e597808835098 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597808835098 : Closed e597808835098 ∧ code e597808835098 = 2796832090650 := by decide
private def t_e597808835098 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597808835098 : ¬ IsSelfInterpreter e597808835098 :=
  wSource (t := t_e597808835098) (replay_sound (ps := []) (t := e597808835098) (by decide)) (by decide)
def e597808863770 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597808863770 : Closed e597808863770 ∧ code e597808863770 = 2796832119322 := by decide
theorem cert_e597808863770 : check e597808863770 [[]] .width = true := by decide
def e597808867866 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597808867866 : Closed e597808867866 ∧ code e597808867866 = 2796832123418 := by decide
private def t_e597808867866 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597808867866 : ¬ IsSelfInterpreter e597808867866 :=
  wSource (t := t_e597808867866) (replay_sound (ps := []) (t := e597808867866) (by decide)) (by decide)
def e597809150490 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597809150490 : Closed e597809150490 ∧ code e597809150490 = 2796832406042 := by decide
theorem cert_e597809150490 : check e597809150490 [[]] .width = true := by decide
def e597809158682 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597809158682 : Closed e597809158682 ∧ code e597809158682 = 2796832414234 := by decide
theorem cert_e597809158682 : check e597809158682 [[]] .width = true := by decide
def e597809543706 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597809543706 : Closed e597809543706 ∧ code e597809543706 = 2796832799258 := by decide
theorem cert_e597809543706 : check e597809543706 [[]] .width = true := by decide
def e597809555994 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597809555994 : Closed e597809555994 ∧ code e597809555994 = 2796832811546 := by decide
theorem cert_e597809555994 : check e597809555994 [[]] .width = true := by decide
def e597809748506 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597809748506 : Closed e597809748506 ∧ code e597809748506 = 2796833004058 := by decide
theorem cert_e597809748506 : check e597809748506 [[]] .width = true := by decide
def e597809752602 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597809752602 : Closed e597809752602 ∧ code e597809752602 = 2796833008154 := by decide
theorem cert_e597809752602 : check e597809752602 [[]] .width = true := by decide
def e597873618458 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873618458 : Closed e597873618458 ∧ code e597873618458 = 2796896874010 := by decide
private def t_e597873618458 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873618458 : ¬ IsSelfInterpreter e597873618458 :=
  wSource (t := t_e597873618458) (replay_sound (ps := []) (t := e597873618458) (by decide)) (by decide)
def e597873620506 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873620506 : Closed e597873620506 ∧ code e597873620506 = 2796896876058 := by decide
private def t_e597873620506 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873620506 : ¬ IsSelfInterpreter e597873620506 :=
  wSource (t := t_e597873620506) (replay_sound (ps := []) (t := e597873620506) (by decide)) (by decide)
def e597873634842 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873634842 : Closed e597873634842 ∧ code e597873634842 = 2796896890394 := by decide
private def t_e597873634842 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873634842 : ¬ IsSelfInterpreter e597873634842 :=
  wSource (t := t_e597873634842) (replay_sound (ps := []) (t := e597873634842) (by decide)) (by decide)
def e597873637914 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873637914 : Closed e597873637914 ∧ code e597873637914 = 2796896893466 := by decide
private def t_e597873637914 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873637914 : ¬ IsSelfInterpreter e597873637914 :=
  wSource (t := t_e597873637914) (replay_sound (ps := []) (t := e597873637914) (by decide)) (by decide)
def e597873645082 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873645082 : Closed e597873645082 ∧ code e597873645082 = 2796896900634 := by decide
private def t_e597873645082 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873645082 : ¬ IsSelfInterpreter e597873645082 :=
  wSource (t := t_e597873645082) (replay_sound (ps := []) (t := e597873645082) (by decide)) (by decide)
def e597873646106 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873646106 : Closed e597873646106 ∧ code e597873646106 = 2796896901658 := by decide
private def t_e597873646106 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873646106 : ¬ IsSelfInterpreter e597873646106 :=
  wSource (t := t_e597873646106) (replay_sound (ps := []) (t := e597873646106) (by decide)) (by decide)
def e597873716762 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873716762 : Closed e597873716762 ∧ code e597873716762 = 2796896972314 := by decide
private def t_e597873716762 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873716762 : ¬ IsSelfInterpreter e597873716762 :=
  wSource (t := t_e597873716762) (replay_sound (ps := []) (t := e597873716762) (by decide)) (by decide)
def e597873718810 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873718810 : Closed e597873718810 ∧ code e597873718810 = 2796896974362 := by decide
private def t_e597873718810 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873718810 : ¬ IsSelfInterpreter e597873718810 :=
  wSource (t := t_e597873718810) (replay_sound (ps := []) (t := e597873718810) (by decide)) (by decide)
def e597873815066 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873815066 : Closed e597873815066 ∧ code e597873815066 = 2796897070618 := by decide
private def t_e597873815066 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873815066 : ¬ IsSelfInterpreter e597873815066 :=
  wSource (t := t_e597873815066) (replay_sound (ps := []) (t := e597873815066) (by decide)) (by decide)
def e597873818138 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873818138 : Closed e597873818138 ∧ code e597873818138 = 2796897073690 := by decide
private def t_e597873818138 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873818138 : ¬ IsSelfInterpreter e597873818138 :=
  wSource (t := t_e597873818138) (replay_sound (ps := []) (t := e597873818138) (by decide)) (by decide)
def e597873866266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873866266 : Closed e597873866266 ∧ code e597873866266 = 2796897121818 := by decide
private def t_e597873866266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873866266 : ¬ IsSelfInterpreter e597873866266 :=
  wSource (t := t_e597873866266) (replay_sound (ps := []) (t := e597873866266) (by decide)) (by decide)
def e597873867290 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597873867290 : Closed e597873867290 ∧ code e597873867290 = 2796897122842 := by decide
private def t_e597873867290 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597873867290 : ¬ IsSelfInterpreter e597873867290 :=
  wSource (t := t_e597873867290) (replay_sound (ps := []) (t := e597873867290) (by decide)) (by decide)
def e597889690990 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e597889690990 : Closed e597889690990 ∧ code e597889690990 = 2796912946542 := by decide
theorem cert_e597889690990 : check e597889690990 [[],[.left],[]] .sourceHead = true := by decide
def e597889690998 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e597889690998 : Closed e597889690998 ∧ code e597889690998 = 2796912946550 := by decide
theorem cert_e597889690998 : check e597889690998 [[],[.left],[]] .sourceHead = true := by decide
def e597889691054 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e597889691054 : Closed e597889691054 ∧ code e597889691054 = 2796912946606 := by decide
theorem cert_e597889691054 : check e597889691054 [[],[.left],[]] .sourceHead = true := by decide
def e597889691066 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e597889691066 : Closed e597889691066 ∧ code e597889691066 = 2796912946618 := by decide
theorem cert_e597889691066 : check e597889691066 [[],[.left],[]] .sourceHead = true := by decide
def e597889691094 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e597889691094 : Closed e597889691094 ∧ code e597889691094 = 2796912946646 := by decide
theorem cert_e597889691094 : check e597889691094 [[],[.left],[]] .sourceHead = true := by decide
def e597889691098 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e597889691098 : Closed e597889691098 ∧ code e597889691098 = 2796912946650 := by decide
theorem cert_e597889691098 : check e597889691098 [[],[.left],[]] .sourceHead = true := by decide
def e597889691310 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e597889691310 : Closed e597889691310 ∧ code e597889691310 = 2796912946862 := by decide
theorem cert_e597889691310 : check e597889691310 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e597889691322 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e597889691322 : Closed e597889691322 ∧ code e597889691322 = 2796912946874 := by decide
theorem cert_e597889691322 : check e597889691322 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left]] .chain = true := by decide
def e597889691370 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e597889691370 : Closed e597889691370 ∧ code e597889691370 = 2796912946922 := by decide
theorem cert_e597889691370 : check e597889691370 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e597889691478 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e597889691478 : Closed e597889691478 ∧ code e597889691478 = 2796912947030 := by decide
theorem cert_e597889691478 : check e597889691478 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e597889691482 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e597889691482 : Closed e597889691482 ∧ code e597889691482 = 2796912947034 := by decide
def e597889691498 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e597889691498 : Closed e597889691498 ∧ code e597889691498 = 2796912947050 := by decide
theorem cert_e597889691498 : check e597889691498 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e597889692526 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e597889692526 : Closed e597889692526 ∧ code e597889692526 = 2796912948078 := by decide
theorem cert_e597889692526 : check e597889692526 [[],[.left],[]] .sourceHead = true := by decide
def e597889692534 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e597889692534 : Closed e597889692534 ∧ code e597889692534 = 2796912948086 := by decide
theorem cert_e597889692534 : check e597889692534 [[],[.left],[]] .sourceHead = true := by decide
def e597889692590 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e597889692590 : Closed e597889692590 ∧ code e597889692590 = 2796912948142 := by decide
theorem cert_e597889692590 : check e597889692590 [[],[.left],[]] .sourceHead = true := by decide
def e597889692602 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e597889692602 : Closed e597889692602 ∧ code e597889692602 = 2796912948154 := by decide
theorem cert_e597889692602 : check e597889692602 [[],[.left],[]] .sourceHead = true := by decide
def e597889692630 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e597889692630 : Closed e597889692630 ∧ code e597889692630 = 2796912948182 := by decide
theorem cert_e597889692630 : check e597889692630 [[],[.left],[]] .sourceHead = true := by decide
def e597889692634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e597889692634 : Closed e597889692634 ∧ code e597889692634 = 2796912948186 := by decide
theorem cert_e597889692634 : check e597889692634 [[],[.left],[]] .sourceHead = true := by decide
def e597889692910 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e597889692910 : Closed e597889692910 ∧ code e597889692910 = 2796912948462 := by decide
theorem cert_e597889692910 : check e597889692910 [[],[.left],[]] .sourceHead = true := by decide
def e597889692918 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e597889692918 : Closed e597889692918 ∧ code e597889692918 = 2796912948470 := by decide
theorem cert_e597889692918 : check e597889692918 [[],[.left],[]] .sourceHead = true := by decide
def e597889693294 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e597889693294 : Closed e597889693294 ∧ code e597889693294 = 2796912948846 := by decide
theorem cert_e597889693294 : check e597889693294 [[],[.left],[]] .sourceHead = true := by decide
def e597889693306 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e597889693306 : Closed e597889693306 ∧ code e597889693306 = 2796912948858 := by decide
theorem cert_e597889693306 : check e597889693306 [[],[.left],[]] .sourceHead = true := by decide
def e597889693494 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e597889693494 : Closed e597889693494 ∧ code e597889693494 = 2796912949046 := by decide
theorem cert_e597889693494 : check e597889693494 [[],[.left],[]] .sourceHead = true := by decide
def e597889693498 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e597889693498 : Closed e597889693498 ∧ code e597889693498 = 2796912949050 := by decide
theorem cert_e597889693498 : check e597889693498 [[],[.left],[]] .sourceHead = true := by decide
def e597889694126 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e597889694126 : Closed e597889694126 ∧ code e597889694126 = 2796912949678 := by decide
theorem cert_e597889694126 : check e597889694126 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e597889694138 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e597889694138 : Closed e597889694138 ∧ code e597889694138 = 2796912949690 := by decide
theorem cert_e597889694138 : checkPay e597889694138 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.right]] = true := by decide
def e597889694186 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e597889694186 : Closed e597889694186 ∧ code e597889694186 = 2796912949738 := by decide
theorem cert_e597889694186 : checkPay e597889694186 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right],[.left,.right,.under,.under,.left,.right]] = true := by decide
def e597889694318 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e597889694318 : Closed e597889694318 ∧ code e597889694318 = 2796912949870 := by decide
theorem cert_e597889694318 : check e597889694318 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e597889694330 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e597889694330 : Closed e597889694330 ∧ code e597889694330 = 2796912949882 := by decide
theorem cert_e597889694330 : check e597889694330 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e597889694618 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e597889694618 : Closed e597889694618 ∧ code e597889694618 = 2796912950170 := by decide
theorem cert_e597889694618 : check e597889694618 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e597889694934 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e597889694934 : Closed e597889694934 ∧ code e597889694934 = 2796912950486 := by decide
theorem cert_e597889694934 : check e597889694934 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e597889694938 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e597889694938 : Closed e597889694938 ∧ code e597889694938 = 2796912950490 := by decide
theorem cert_e597889694938 : check e597889694938 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e597889694954 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e597889694954 : Closed e597889694954 ∧ code e597889694954 = 2796912950506 := by decide
theorem cert_e597889694954 : check e597889694954 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e597889695030 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e597889695030 : Closed e597889695030 ∧ code e597889695030 = 2796912950582 := by decide
theorem cert_e597889695030 : check e597889695030 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e597889695034 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e597889695034 : Closed e597889695034 ∧ code e597889695034 = 2796912950586 := by decide
theorem cert_e597889695034 : checkPay e597889695034 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.left,.right]] = true := by decide
def e597889695130 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e597889695130 : Closed e597889695130 ∧ code e597889695130 = 2796912950682 := by decide
theorem cert_e597889695130 : check e597889695130 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e597889698670 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597889698670 : Closed e597889698670 ∧ code e597889698670 = 2796912954222 := by decide
theorem cert_e597889698670 : check e597889698670 [[],[.left],[]] .sourceHead = true := by decide
def e597889698678 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597889698678 : Closed e597889698678 ∧ code e597889698678 = 2796912954230 := by decide
theorem cert_e597889698678 : check e597889698678 [[],[.left],[]] .sourceHead = true := by decide
def e597889698734 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597889698734 : Closed e597889698734 ∧ code e597889698734 = 2796912954286 := by decide
theorem cert_e597889698734 : check e597889698734 [[],[.left],[]] .sourceHead = true := by decide
def e597889698746 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597889698746 : Closed e597889698746 ∧ code e597889698746 = 2796912954298 := by decide
theorem cert_e597889698746 : check e597889698746 [[],[.left],[]] .sourceHead = true := by decide
def e597889698774 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597889698774 : Closed e597889698774 ∧ code e597889698774 = 2796912954326 := by decide
theorem cert_e597889698774 : check e597889698774 [[],[.left],[]] .sourceHead = true := by decide
def e597889698778 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597889698778 : Closed e597889698778 ∧ code e597889698778 = 2796912954330 := by decide
theorem cert_e597889698778 : check e597889698778 [[],[.left],[]] .sourceHead = true := by decide
def e597889699054 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597889699054 : Closed e597889699054 ∧ code e597889699054 = 2796912954606 := by decide
theorem cert_e597889699054 : check e597889699054 [[],[.left],[]] .sourceHead = true := by decide
def e597889699062 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597889699062 : Closed e597889699062 ∧ code e597889699062 = 2796912954614 := by decide
theorem cert_e597889699062 : check e597889699062 [[],[.left],[]] .sourceHead = true := by decide
def e597889699438 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597889699438 : Closed e597889699438 ∧ code e597889699438 = 2796912954990 := by decide
theorem cert_e597889699438 : check e597889699438 [[],[.left],[]] .sourceHead = true := by decide
def e597889699450 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597889699450 : Closed e597889699450 ∧ code e597889699450 = 2796912955002 := by decide
theorem cert_e597889699450 : check e597889699450 [[],[.left],[]] .sourceHead = true := by decide
def e597889699638 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597889699638 : Closed e597889699638 ∧ code e597889699638 = 2796912955190 := by decide
theorem cert_e597889699638 : check e597889699638 [[],[.left],[]] .sourceHead = true := by decide
def e597889699642 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597889699642 : Closed e597889699642 ∧ code e597889699642 = 2796912955194 := by decide
theorem cert_e597889699642 : check e597889699642 [[],[.left],[]] .sourceHead = true := by decide
def e597889705390 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e597889705390 : Closed e597889705390 ∧ code e597889705390 = 2796912960942 := by decide
theorem cert_e597889705390 : check e597889705390 [[],[.left],[],[.under]] .three = true := by decide
def e597889705402 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e597889705402 : Closed e597889705402 ∧ code e597889705402 = 2796912960954 := by decide
theorem cert_e597889705402 : check e597889705402 [[],[.left],[],[.under]] .three = true := by decide
def e597889705450 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e597889705450 : Closed e597889705450 ∧ code e597889705450 = 2796912961002 := by decide
theorem cert_e597889705450 : check e597889705450 [[],[.left],[],[.under]] .three = true := by decide
def e597889705582 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e597889705582 : Closed e597889705582 ∧ code e597889705582 = 2796912961134 := by decide
theorem cert_e597889705582 : check e597889705582 [[],[.left],[],[.under]] .three = true := by decide
def e597889705594 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e597889705594 : Closed e597889705594 ∧ code e597889705594 = 2796912961146 := by decide
theorem cert_e597889705594 : check e597889705594 [[],[.left],[],[.under]] .three = true := by decide
def e597889705882 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e597889705882 : Closed e597889705882 ∧ code e597889705882 = 2796912961434 := by decide
theorem cert_e597889705882 : check e597889705882 [[],[.left],[],[.under]] .three = true := by decide
def e597889708758 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e597889708758 : Closed e597889708758 ∧ code e597889708758 = 2796912964310 := by decide
theorem cert_e597889708758 : check e597889708758 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e597889708762 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e597889708762 : Closed e597889708762 ∧ code e597889708762 = 2796912964314 := by decide
theorem cert_e597889708762 : check e597889708762 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e597889708778 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e597889708778 : Closed e597889708778 ∧ code e597889708778 = 2796912964330 := by decide
theorem cert_e597889708778 : check e597889708778 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e597889708854 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e597889708854 : Closed e597889708854 ∧ code e597889708854 = 2796912964406 := by decide
theorem cert_e597889708854 : check e597889708854 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e597889708858 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e597889708858 : Closed e597889708858 ∧ code e597889708858 = 2796912964410 := by decide
theorem cert_e597889708858 : check e597889708858 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e597889708954 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e597889708954 : Closed e597889708954 ∧ code e597889708954 = 2796912964506 := by decide
theorem cert_e597889708954 : check e597889708954 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e597889846126 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597889846126 : Closed e597889846126 ∧ code e597889846126 = 2796913101678 := by decide
theorem cert_e597889846126 : check e597889846126 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846134 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597889846134 : Closed e597889846134 ∧ code e597889846134 = 2796913101686 := by decide
theorem cert_e597889846134 : check e597889846134 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846190 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597889846190 : Closed e597889846190 ∧ code e597889846190 = 2796913101742 := by decide
theorem cert_e597889846190 : check e597889846190 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846202 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597889846202 : Closed e597889846202 ∧ code e597889846202 = 2796913101754 := by decide
theorem cert_e597889846202 : check e597889846202 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846230 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597889846230 : Closed e597889846230 ∧ code e597889846230 = 2796913101782 := by decide
theorem cert_e597889846230 : check e597889846230 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846234 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597889846234 : Closed e597889846234 ∧ code e597889846234 = 2796913101786 := by decide
theorem cert_e597889846234 : check e597889846234 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846510 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597889846510 : Closed e597889846510 ∧ code e597889846510 = 2796913102062 := by decide
theorem cert_e597889846510 : check e597889846510 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846518 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597889846518 : Closed e597889846518 ∧ code e597889846518 = 2796913102070 := by decide
theorem cert_e597889846518 : check e597889846518 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846894 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597889846894 : Closed e597889846894 ∧ code e597889846894 = 2796913102446 := by decide
theorem cert_e597889846894 : check e597889846894 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889846906 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597889846906 : Closed e597889846906 ∧ code e597889846906 = 2796913102458 := by decide
theorem cert_e597889846906 : check e597889846906 [[],[.left],[],[]] .sourceHead = true := by decide
end Blc.Floor41
