import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e552926021002 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552926021002 : Closed e552926021002 ∧ code e552926021002 = 2751949276554 := by decide
theorem cert_e552926021002 : check e552926021002 [[]] .width = true := by decide
def e552926021026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552926021026 : Closed e552926021026 ∧ code e552926021026 = 2751949276578 := by decide
theorem cert_e552926021026 : check e552926021026 [[]] .width = true := by decide
def e552926021134 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552926021134 : Closed e552926021134 ∧ code e552926021134 = 2751949276686 := by decide
theorem cert_e552926021134 : check e552926021134 [[]] .width = true := by decide
def e552926021146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552926021146 : Closed e552926021146 ∧ code e552926021146 = 2751949276698 := by decide
theorem cert_e552926021146 : check e552926021146 [[]] .width = true := by decide
def e552926021218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552926021218 : Closed e552926021218 ∧ code e552926021218 = 2751949276770 := by decide
theorem cert_e552926021218 : check e552926021218 [[]] .width = true := by decide
def e552926080538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552926080538 : Closed e552926080538 ∧ code e552926080538 = 2751949336090 := by decide
theorem cert_e552926080538 : check e552926080538 [[]] .width = true := by decide
def e552926083610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552926083610 : Closed e552926083610 ∧ code e552926083610 = 2751949339162 := by decide
theorem cert_e552926083610 : check e552926083610 [[]] .width = true := by decide
def e552926085146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552926085146 : Closed e552926085146 ∧ code e552926085146 = 2751949340698 := by decide
theorem cert_e552926085146 : check e552926085146 [[]] .width = true := by decide
def e552926085238 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552926085238 : Closed e552926085238 ∧ code e552926085238 = 2751949340790 := by decide
theorem cert_e552926085238 : check e552926085238 [[]] .width = true := by decide
def e552926085482 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552926085482 : Closed e552926085482 ∧ code e552926085482 = 2751949341034 := by decide
theorem cert_e552926085482 : check e552926085482 [[]] .width = true := by decide
def e552926085530 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552926085530 : Closed e552926085530 ∧ code e552926085530 = 2751949341082 := by decide
theorem cert_e552926085530 : check e552926085530 [[]] .width = true := by decide
def e552926086538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552926086538 : Closed e552926086538 ∧ code e552926086538 = 2751949342090 := by decide
theorem cert_e552926086538 : check e552926086538 [[]] .width = true := by decide
def e552926086562 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552926086562 : Closed e552926086562 ∧ code e552926086562 = 2751949342114 := by decide
theorem cert_e552926086562 : check e552926086562 [[]] .width = true := by decide
def e552926086670 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552926086670 : Closed e552926086670 ∧ code e552926086670 = 2751949342222 := by decide
theorem cert_e552926086670 : check e552926086670 [[]] .width = true := by decide
def e552926086682 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552926086682 : Closed e552926086682 ∧ code e552926086682 = 2751949342234 := by decide
theorem cert_e552926086682 : check e552926086682 [[]] .width = true := by decide
def e552926086754 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552926086754 : Closed e552926086754 ∧ code e552926086754 = 2751949342306 := by decide
theorem cert_e552926086754 : check e552926086754 [[]] .width = true := by decide
def e552926131738 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552926131738 : Closed e552926131738 ∧ code e552926131738 = 2751949387290 := by decide
private def t_e552926131738 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552926131738 : ¬ IsSelfInterpreter e552926131738 :=
  wSource (t := t_e552926131738) (replay_sound (ps := []) (t := e552926131738) (by decide)) (by decide)
def e552926132762 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552926132762 : Closed e552926132762 ∧ code e552926132762 = 2751949388314 := by decide
private def t_e552926132762 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552926132762 : ¬ IsSelfInterpreter e552926132762 :=
  wSource (t := t_e552926132762) (replay_sound (ps := []) (t := e552926132762) (by decide)) (by decide)
def e552929783322 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552929783322 : Closed e552929783322 ∧ code e552929783322 = 2751953038874 := by decide
theorem cert_e552929783322 : check e552929783322 [[]] .width = true := by decide
def e552929816090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552929816090 : Closed e552929816090 ∧ code e552929816090 = 2751953071642 := by decide
theorem cert_e552929816090 : check e552929816090 [[]] .width = true := by decide
def e552929818138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552929818138 : Closed e552929818138 ∧ code e552929818138 = 2751953073690 := by decide
theorem cert_e552929818138 : check e552929818138 [[]] .width = true := by decide
def e552930504218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552930504218 : Closed e552930504218 ∧ code e552930504218 = 2751953759770 := by decide
theorem cert_e552930504218 : check e552930504218 [[]] .width = true := by decide
def e552930607130 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552930607130 : Closed e552930607130 ∧ code e552930607130 = 2751953862682 := by decide
theorem cert_e552930607130 : check e552930607130 [[]] .width = true := by decide
def e552930607222 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552930607222 : Closed e552930607222 ∧ code e552930607222 = 2751953862774 := by decide
theorem cert_e552930607222 : check e552930607222 [[]] .width = true := by decide
def e552930607466 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552930607466 : Closed e552930607466 ∧ code e552930607466 = 2751953863018 := by decide
theorem cert_e552930607466 : check e552930607466 [[]] .width = true := by decide
def e552930607514 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552930607514 : Closed e552930607514 ∧ code e552930607514 = 2751953863066 := by decide
theorem cert_e552930607514 : check e552930607514 [[]] .width = true := by decide
def e552930608522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552930608522 : Closed e552930608522 ∧ code e552930608522 = 2751953864074 := by decide
theorem cert_e552930608522 : check e552930608522 [[]] .width = true := by decide
def e552930608546 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552930608546 : Closed e552930608546 ∧ code e552930608546 = 2751953864098 := by decide
theorem cert_e552930608546 : check e552930608546 [[]] .width = true := by decide
def e552930608654 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552930608654 : Closed e552930608654 ∧ code e552930608654 = 2751953864206 := by decide
theorem cert_e552930608654 : check e552930608654 [[]] .width = true := by decide
def e552930608666 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552930608666 : Closed e552930608666 ∧ code e552930608666 = 2751953864218 := by decide
theorem cert_e552930608666 : check e552930608666 [[]] .width = true := by decide
def e552930608738 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552930608738 : Closed e552930608738 ∧ code e552930608738 = 2751953864290 := by decide
theorem cert_e552930608738 : check e552930608738 [[]] .width = true := by decide
def e552930700826 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552930700826 : Closed e552930700826 ∧ code e552930700826 = 2751953956378 := by decide
theorem cert_e552930700826 : check e552930700826 [[]] .width = true := by decide
def e552930702874 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552930702874 : Closed e552930702874 ∧ code e552930702874 = 2751953958426 := by decide
theorem cert_e552930702874 : check e552930702874 [[]] .width = true := by decide
def e552930738202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552930738202 : Closed e552930738202 ∧ code e552930738202 = 2751953993754 := by decide
theorem cert_e552930738202 : check e552930738202 [[]] .width = true := by decide
def e552930738294 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552930738294 : Closed e552930738294 ∧ code e552930738294 = 2751953993846 := by decide
theorem cert_e552930738294 : check e552930738294 [[]] .width = true := by decide
def e552930738538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552930738538 : Closed e552930738538 ∧ code e552930738538 = 2751953994090 := by decide
theorem cert_e552930738538 : check e552930738538 [[]] .width = true := by decide
def e552930738586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552930738586 : Closed e552930738586 ∧ code e552930738586 = 2751953994138 := by decide
theorem cert_e552930738586 : check e552930738586 [[]] .width = true := by decide
def e552930739594 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552930739594 : Closed e552930739594 ∧ code e552930739594 = 2751953995146 := by decide
theorem cert_e552930739594 : check e552930739594 [[]] .width = true := by decide
def e552930739618 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552930739618 : Closed e552930739618 ∧ code e552930739618 = 2751953995170 := by decide
theorem cert_e552930739618 : check e552930739618 [[]] .width = true := by decide
def e552930739726 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552930739726 : Closed e552930739726 ∧ code e552930739726 = 2751953995278 := by decide
theorem cert_e552930739726 : check e552930739726 [[]] .width = true := by decide
def e552930739738 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552930739738 : Closed e552930739738 ∧ code e552930739738 = 2751953995290 := by decide
theorem cert_e552930739738 : check e552930739738 [[]] .width = true := by decide
def e552930739810 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552930739810 : Closed e552930739810 ∧ code e552930739810 = 2751953995362 := by decide
theorem cert_e552930739810 : check e552930739810 [[]] .width = true := by decide
def e552936599066 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552936599066 : Closed e552936599066 ∧ code e552936599066 = 2751959854618 := by decide
theorem cert_e552936599066 : check e552936599066 [[]] .width = true := by decide
def e552936648218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552936648218 : Closed e552936648218 ∧ code e552936648218 = 2751959903770 := by decide
theorem cert_e552936648218 : check e552936648218 [[]] .width = true := by decide
def e552936651290 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552936651290 : Closed e552936651290 ∧ code e552936651290 = 2751959906842 := by decide
theorem cert_e552936651290 : check e552936651290 [[]] .width = true := by decide
def e552936795674 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552936795674 : Closed e552936795674 ∧ code e552936795674 = 2751960051226 := by decide
theorem cert_e552936795674 : check e552936795674 [[]] .width = true := by decide
def e552936898586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552936898586 : Closed e552936898586 ∧ code e552936898586 = 2751960154138 := by decide
theorem cert_e552936898586 : check e552936898586 [[]] .width = true := by decide
def e552936898678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552936898678 : Closed e552936898678 ∧ code e552936898678 = 2751960154230 := by decide
theorem cert_e552936898678 : check e552936898678 [[]] .width = true := by decide
def e552936898922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552936898922 : Closed e552936898922 ∧ code e552936898922 = 2751960154474 := by decide
theorem cert_e552936898922 : check e552936898922 [[]] .width = true := by decide
def e552936898970 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552936898970 : Closed e552936898970 ∧ code e552936898970 = 2751960154522 := by decide
theorem cert_e552936898970 : check e552936898970 [[]] .width = true := by decide
def e552936899978 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552936899978 : Closed e552936899978 ∧ code e552936899978 = 2751960155530 := by decide
theorem cert_e552936899978 : check e552936899978 [[]] .width = true := by decide
def e552936900002 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552936900002 : Closed e552936900002 ∧ code e552936900002 = 2751960155554 := by decide
theorem cert_e552936900002 : check e552936900002 [[]] .width = true := by decide
def e552936900110 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552936900110 : Closed e552936900110 ∧ code e552936900110 = 2751960155662 := by decide
theorem cert_e552936900110 : check e552936900110 [[]] .width = true := by decide
def e552936900122 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552936900122 : Closed e552936900122 ∧ code e552936900122 = 2751960155674 := by decide
theorem cert_e552936900122 : check e552936900122 [[]] .width = true := by decide
def e552936900194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552936900194 : Closed e552936900194 ∧ code e552936900194 = 2751960155746 := by decide
theorem cert_e552936900194 : check e552936900194 [[]] .width = true := by decide
def e552937090586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552937090586 : Closed e552937090586 ∧ code e552937090586 = 2751960346138 := by decide
theorem cert_e552937090586 : check e552937090586 [[]] .width = true := by decide
def e552937093658 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552937093658 : Closed e552937093658 ∧ code e552937093658 = 2751960349210 := by decide
theorem cert_e552937093658 : check e552937093658 [[]] .width = true := by decide
def e552937095194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552937095194 : Closed e552937095194 ∧ code e552937095194 = 2751960350746 := by decide
theorem cert_e552937095194 : check e552937095194 [[]] .width = true := by decide
def e552937095286 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552937095286 : Closed e552937095286 ∧ code e552937095286 = 2751960350838 := by decide
theorem cert_e552937095286 : check e552937095286 [[]] .width = true := by decide
def e552937095530 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552937095530 : Closed e552937095530 ∧ code e552937095530 = 2751960351082 := by decide
theorem cert_e552937095530 : check e552937095530 [[]] .width = true := by decide
def e552937095578 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552937095578 : Closed e552937095578 ∧ code e552937095578 = 2751960351130 := by decide
theorem cert_e552937095578 : check e552937095578 [[]] .width = true := by decide
def e552937096586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552937096586 : Closed e552937096586 ∧ code e552937096586 = 2751960352138 := by decide
theorem cert_e552937096586 : check e552937096586 [[]] .width = true := by decide
def e552937096610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552937096610 : Closed e552937096610 ∧ code e552937096610 = 2751960352162 := by decide
theorem cert_e552937096610 : check e552937096610 [[]] .width = true := by decide
def e552937096718 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552937096718 : Closed e552937096718 ∧ code e552937096718 = 2751960352270 := by decide
theorem cert_e552937096718 : check e552937096718 [[]] .width = true := by decide
def e552937096730 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552937096730 : Closed e552937096730 ∧ code e552937096730 = 2751960352282 := by decide
theorem cert_e552937096730 : check e552937096730 [[]] .width = true := by decide
def e552937096802 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552937096802 : Closed e552937096802 ∧ code e552937096802 = 2751960352354 := by decide
theorem cert_e552937096802 : check e552937096802 [[]] .width = true := by decide
def e552940039706 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940039706 : Closed e552940039706 ∧ code e552940039706 = 2751963295258 := by decide
private def t_e552940039706 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940039706 : ¬ IsSelfInterpreter e552940039706 :=
  wSource (t := t_e552940039706) (replay_sound (ps := []) (t := e552940039706) (by decide)) (by decide)
def e552940041754 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940041754 : Closed e552940041754 ∧ code e552940041754 = 2751963297306 := by decide
private def t_e552940041754 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940041754 : ¬ IsSelfInterpreter e552940041754 :=
  wSource (t := t_e552940041754) (replay_sound (ps := []) (t := e552940041754) (by decide)) (by decide)
def e552940056090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940056090 : Closed e552940056090 ∧ code e552940056090 = 2751963311642 := by decide
private def t_e552940056090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940056090 : ¬ IsSelfInterpreter e552940056090 :=
  wSource (t := t_e552940056090) (replay_sound (ps := []) (t := e552940056090) (by decide)) (by decide)
def e552940059162 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940059162 : Closed e552940059162 ∧ code e552940059162 = 2751963314714 := by decide
private def t_e552940059162 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940059162 : ¬ IsSelfInterpreter e552940059162 :=
  wSource (t := t_e552940059162) (replay_sound (ps := []) (t := e552940059162) (by decide)) (by decide)
def e552940066330 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940066330 : Closed e552940066330 ∧ code e552940066330 = 2751963321882 := by decide
private def t_e552940066330 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940066330 : ¬ IsSelfInterpreter e552940066330 :=
  wSource (t := t_e552940066330) (replay_sound (ps := []) (t := e552940066330) (by decide)) (by decide)
def e552940067354 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940067354 : Closed e552940067354 ∧ code e552940067354 = 2751963322906 := by decide
private def t_e552940067354 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940067354 : ¬ IsSelfInterpreter e552940067354 :=
  wSource (t := t_e552940067354) (replay_sound (ps := []) (t := e552940067354) (by decide)) (by decide)
def e552940138010 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940138010 : Closed e552940138010 ∧ code e552940138010 = 2751963393562 := by decide
private def t_e552940138010 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940138010 : ¬ IsSelfInterpreter e552940138010 :=
  wSource (t := t_e552940138010) (replay_sound (ps := []) (t := e552940138010) (by decide)) (by decide)
def e552940140058 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940140058 : Closed e552940140058 ∧ code e552940140058 = 2751963395610 := by decide
private def t_e552940140058 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940140058 : ¬ IsSelfInterpreter e552940140058 :=
  wSource (t := t_e552940140058) (replay_sound (ps := []) (t := e552940140058) (by decide)) (by decide)
def e552940175386 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552940175386 : Closed e552940175386 ∧ code e552940175386 = 2751963430938 := by decide
theorem cert_e552940175386 : check e552940175386 [[]] .width = true := by decide
def e552940175478 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552940175478 : Closed e552940175478 ∧ code e552940175478 = 2751963431030 := by decide
theorem cert_e552940175478 : check e552940175478 [[]] .width = true := by decide
def e552940175722 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552940175722 : Closed e552940175722 ∧ code e552940175722 = 2751963431274 := by decide
theorem cert_e552940175722 : check e552940175722 [[]] .width = true := by decide
def e552940175770 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552940175770 : Closed e552940175770 ∧ code e552940175770 = 2751963431322 := by decide
theorem cert_e552940175770 : check e552940175770 [[]] .width = true := by decide
def e552940176778 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552940176778 : Closed e552940176778 ∧ code e552940176778 = 2751963432330 := by decide
theorem cert_e552940176778 : check e552940176778 [[]] .width = true := by decide
def e552940176802 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552940176802 : Closed e552940176802 ∧ code e552940176802 = 2751963432354 := by decide
private def t_e552940176802 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e552940176802 : ¬ IsSelfInterpreter e552940176802 :=
  wSource (t := t_e552940176802) (replay_sound (ps := []) (t := e552940176802) (by decide)) (by decide)
def e552940176910 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552940176910 : Closed e552940176910 ∧ code e552940176910 = 2751963432462 := by decide
theorem cert_e552940176910 : check e552940176910 [[]] .width = true := by decide
def e552940176922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552940176922 : Closed e552940176922 ∧ code e552940176922 = 2751963432474 := by decide
private def t_e552940176922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e552940176922 : ¬ IsSelfInterpreter e552940176922 :=
  wSource (t := t_e552940176922) (replay_sound (ps := []) (t := e552940176922) (by decide)) (by decide)
def e552940176994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552940176994 : Closed e552940176994 ∧ code e552940176994 = 2751963432546 := by decide
theorem cert_e552940176994 : check e552940176994 [[]] .width = true := by decide
def e552940236314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940236314 : Closed e552940236314 ∧ code e552940236314 = 2751963491866 := by decide
private def t_e552940236314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940236314 : ¬ IsSelfInterpreter e552940236314 :=
  wSource (t := t_e552940236314) (replay_sound (ps := []) (t := e552940236314) (by decide)) (by decide)
def e552940239386 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940239386 : Closed e552940239386 ∧ code e552940239386 = 2751963494938 := by decide
private def t_e552940239386 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940239386 : ¬ IsSelfInterpreter e552940239386 :=
  wSource (t := t_e552940239386) (replay_sound (ps := []) (t := e552940239386) (by decide)) (by decide)
def e552940240922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552940240922 : Closed e552940240922 ∧ code e552940240922 = 2751963496474 := by decide
theorem cert_e552940240922 : check e552940240922 [[]] .width = true := by decide
def e552940241014 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552940241014 : Closed e552940241014 ∧ code e552940241014 = 2751963496566 := by decide
theorem cert_e552940241014 : check e552940241014 [[]] .width = true := by decide
def e552940241258 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552940241258 : Closed e552940241258 ∧ code e552940241258 = 2751963496810 := by decide
theorem cert_e552940241258 : check e552940241258 [[]] .width = true := by decide
def e552940241306 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552940241306 : Closed e552940241306 ∧ code e552940241306 = 2751963496858 := by decide
theorem cert_e552940241306 : check e552940241306 [[]] .width = true := by decide
def e552940242314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552940242314 : Closed e552940242314 ∧ code e552940242314 = 2751963497866 := by decide
theorem cert_e552940242314 : check e552940242314 [[]] .width = true := by decide
def e552940242338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552940242338 : Closed e552940242338 ∧ code e552940242338 = 2751963497890 := by decide
private def t_e552940242338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e552940242338 : ¬ IsSelfInterpreter e552940242338 :=
  wSource (t := t_e552940242338) (replay_sound (ps := []) (t := e552940242338) (by decide)) (by decide)
def e552940242446 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552940242446 : Closed e552940242446 ∧ code e552940242446 = 2751963497998 := by decide
theorem cert_e552940242446 : check e552940242446 [[]] .width = true := by decide
def e552940242458 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552940242458 : Closed e552940242458 ∧ code e552940242458 = 2751963498010 := by decide
private def t_e552940242458 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e552940242458 : ¬ IsSelfInterpreter e552940242458 :=
  wSource (t := t_e552940242458) (replay_sound (ps := []) (t := e552940242458) (by decide)) (by decide)
def e552940242530 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552940242530 : Closed e552940242530 ∧ code e552940242530 = 2751963498082 := by decide
theorem cert_e552940242530 : check e552940242530 [[]] .width = true := by decide
def e552940287514 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940287514 : Closed e552940287514 ∧ code e552940287514 = 2751963543066 := by decide
private def t_e552940287514 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940287514 : ¬ IsSelfInterpreter e552940287514 :=
  wSource (t := t_e552940287514) (replay_sound (ps := []) (t := e552940287514) (by decide)) (by decide)
def e552940288538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552940288538 : Closed e552940288538 ∧ code e552940288538 = 2751963544090 := by decide
private def t_e552940288538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552940288538 : ¬ IsSelfInterpreter e552940288538 :=
  wSource (t := t_e552940288538) (replay_sound (ps := []) (t := e552940288538) (by decide)) (by decide)
def e553160470042 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553160470042 : Closed e553160470042 ∧ code e553160470042 = 2752183725594 := by decide
theorem cert_e553160470042 : check e553160470042 [[]] .width = true := by decide
def e553160994330 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553160994330 : Closed e553160994330 ∧ code e553160994330 = 2752184249882 := by decide
theorem cert_e553160994330 : check e553160994330 [[]] .width = true := by decide
def e553161027098 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553161027098 : Closed e553161027098 ∧ code e553161027098 = 2752184282650 := by decide
theorem cert_e553161027098 : check e553161027098 [[]] .width = true := by decide
def e553161029146 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553161029146 : Closed e553161029146 ∧ code e553161029146 = 2752184284698 := by decide
theorem cert_e553161029146 : check e553161029146 [[]] .width = true := by decide
def e553172004378 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553172004378 : Closed e553172004378 ∧ code e553172004378 = 2752195259930 := by decide
theorem cert_e553172004378 : check e553172004378 [[]] .width = true := by decide
def e553173773850 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553173773850 : Closed e553173773850 ∧ code e553173773850 = 2752197029402 := by decide
theorem cert_e553173773850 : check e553173773850 [[]] .width = true := by decide
def e553173876762 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553173876762 : Closed e553173876762 ∧ code e553173876762 = 2752197132314 := by decide
theorem cert_e553173876762 : check e553173876762 [[]] .width = true := by decide
def e553173876854 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553173876854 : Closed e553173876854 ∧ code e553173876854 = 2752197132406 := by decide
theorem cert_e553173876854 : check e553173876854 [[]] .width = true := by decide
def e553173877098 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553173877098 : Closed e553173877098 ∧ code e553173877098 = 2752197132650 := by decide
theorem cert_e553173877098 : check e553173877098 [[]] .width = true := by decide
def e553173877146 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553173877146 : Closed e553173877146 ∧ code e553173877146 = 2752197132698 := by decide
theorem cert_e553173877146 : check e553173877146 [[]] .width = true := by decide
def e553173878154 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553173878154 : Closed e553173878154 ∧ code e553173878154 = 2752197133706 := by decide
theorem cert_e553173878154 : check e553173878154 [[]] .width = true := by decide
def e553173878178 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553173878178 : Closed e553173878178 ∧ code e553173878178 = 2752197133730 := by decide
theorem cert_e553173878178 : check e553173878178 [[]] .width = true := by decide
def e553173878286 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553173878286 : Closed e553173878286 ∧ code e553173878286 = 2752197133838 := by decide
theorem cert_e553173878286 : check e553173878286 [[]] .width = true := by decide
def e553173878298 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553173878298 : Closed e553173878298 ∧ code e553173878298 = 2752197133850 := by decide
theorem cert_e553173878298 : check e553173878298 [[]] .width = true := by decide
def e553173878370 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553173878370 : Closed e553173878370 ∧ code e553173878370 = 2752197133922 := by decide
theorem cert_e553173878370 : check e553173878370 [[]] .width = true := by decide
def e553175150106 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553175150106 : Closed e553175150106 ∧ code e553175150106 = 2752198405658 := by decide
theorem cert_e553175150106 : check e553175150106 [[]] .width = true := by decide
def e553175182874 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553175182874 : Closed e553175182874 ∧ code e553175182874 = 2752198438426 := by decide
theorem cert_e553175182874 : check e553175182874 [[]] .width = true := by decide
def e553175184922 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553175184922 : Closed e553175184922 ∧ code e553175184922 = 2752198440474 := by decide
theorem cert_e553175184922 : check e553175184922 [[]] .width = true := by decide
def e553175871002 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553175871002 : Closed e553175871002 ∧ code e553175871002 = 2752199126554 := by decide
theorem cert_e553175871002 : check e553175871002 [[]] .width = true := by decide
def e553175973914 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553175973914 : Closed e553175973914 ∧ code e553175973914 = 2752199229466 := by decide
theorem cert_e553175973914 : check e553175973914 [[]] .width = true := by decide
def e553175974006 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553175974006 : Closed e553175974006 ∧ code e553175974006 = 2752199229558 := by decide
theorem cert_e553175974006 : check e553175974006 [[]] .width = true := by decide
def e553175974250 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553175974250 : Closed e553175974250 ∧ code e553175974250 = 2752199229802 := by decide
theorem cert_e553175974250 : check e553175974250 [[]] .width = true := by decide
def e553175974298 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553175974298 : Closed e553175974298 ∧ code e553175974298 = 2752199229850 := by decide
theorem cert_e553175974298 : check e553175974298 [[]] .width = true := by decide
def e553175975306 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553175975306 : Closed e553175975306 ∧ code e553175975306 = 2752199230858 := by decide
theorem cert_e553175975306 : check e553175975306 [[]] .width = true := by decide
def e553175975330 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553175975330 : Closed e553175975330 ∧ code e553175975330 = 2752199230882 := by decide
theorem cert_e553175975330 : check e553175975330 [[]] .width = true := by decide
def e553175975438 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553175975438 : Closed e553175975438 ∧ code e553175975438 = 2752199230990 := by decide
theorem cert_e553175975438 : check e553175975438 [[]] .width = true := by decide
def e553175975450 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553175975450 : Closed e553175975450 ∧ code e553175975450 = 2752199231002 := by decide
theorem cert_e553175975450 : check e553175975450 [[]] .width = true := by decide
def e553175975522 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553175975522 : Closed e553175975522 ∧ code e553175975522 = 2752199231074 := by decide
theorem cert_e553175975522 : check e553175975522 [[]] .width = true := by decide
def e553176067610 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553176067610 : Closed e553176067610 ∧ code e553176067610 = 2752199323162 := by decide
theorem cert_e553176067610 : check e553176067610 [[]] .width = true := by decide
def e553176069658 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553176069658 : Closed e553176069658 ∧ code e553176069658 = 2752199325210 := by decide
theorem cert_e553176069658 : check e553176069658 [[]] .width = true := by decide
def e553176104986 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553176104986 : Closed e553176104986 ∧ code e553176104986 = 2752199360538 := by decide
theorem cert_e553176104986 : check e553176104986 [[]] .width = true := by decide
def e553176105078 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553176105078 : Closed e553176105078 ∧ code e553176105078 = 2752199360630 := by decide
theorem cert_e553176105078 : check e553176105078 [[]] .width = true := by decide
def e553176105322 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553176105322 : Closed e553176105322 ∧ code e553176105322 = 2752199360874 := by decide
theorem cert_e553176105322 : check e553176105322 [[]] .width = true := by decide
def e553176105370 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553176105370 : Closed e553176105370 ∧ code e553176105370 = 2752199360922 := by decide
theorem cert_e553176105370 : check e553176105370 [[]] .width = true := by decide
def e553176106378 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553176106378 : Closed e553176106378 ∧ code e553176106378 = 2752199361930 := by decide
theorem cert_e553176106378 : check e553176106378 [[]] .width = true := by decide
def e553176106402 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553176106402 : Closed e553176106402 ∧ code e553176106402 = 2752199361954 := by decide
theorem cert_e553176106402 : check e553176106402 [[]] .width = true := by decide
def e553176106510 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553176106510 : Closed e553176106510 ∧ code e553176106510 = 2752199362062 := by decide
theorem cert_e553176106510 : check e553176106510 [[]] .width = true := by decide
def e553176106522 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553176106522 : Closed e553176106522 ∧ code e553176106522 = 2752199362074 := by decide
theorem cert_e553176106522 : check e553176106522 [[]] .width = true := by decide
def e553176106594 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553176106594 : Closed e553176106594 ∧ code e553176106594 = 2752199362146 := by decide
theorem cert_e553176106594 : check e553176106594 [[]] .width = true := by decide
def e553218141722 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553218141722 : Closed e553218141722 ∧ code e553218141722 = 2752241397274 := by decide
theorem cert_e553218141722 : check e553218141722 [[]] .width = true := by decide
def e553219911194 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553219911194 : Closed e553219911194 ∧ code e553219911194 = 2752243166746 := by decide
theorem cert_e553219911194 : check e553219911194 [[]] .width = true := by decide
def e553220014106 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553220014106 : Closed e553220014106 ∧ code e553220014106 = 2752243269658 := by decide
theorem cert_e553220014106 : check e553220014106 [[]] .width = true := by decide
def e553220014198 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553220014198 : Closed e553220014198 ∧ code e553220014198 = 2752243269750 := by decide
theorem cert_e553220014198 : check e553220014198 [[]] .width = true := by decide
def e553220014442 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553220014442 : Closed e553220014442 ∧ code e553220014442 = 2752243269994 := by decide
theorem cert_e553220014442 : check e553220014442 [[]] .width = true := by decide
def e553220014490 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553220014490 : Closed e553220014490 ∧ code e553220014490 = 2752243270042 := by decide
theorem cert_e553220014490 : check e553220014490 [[]] .width = true := by decide
def e553220015498 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553220015498 : Closed e553220015498 ∧ code e553220015498 = 2752243271050 := by decide
theorem cert_e553220015498 : check e553220015498 [[]] .width = true := by decide
def e553220015522 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553220015522 : Closed e553220015522 ∧ code e553220015522 = 2752243271074 := by decide
theorem cert_e553220015522 : check e553220015522 [[]] .width = true := by decide
def e553220015630 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553220015630 : Closed e553220015630 ∧ code e553220015630 = 2752243271182 := by decide
theorem cert_e553220015630 : check e553220015630 [[]] .width = true := by decide
def e553220015642 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553220015642 : Closed e553220015642 ∧ code e553220015642 = 2752243271194 := by decide
theorem cert_e553220015642 : check e553220015642 [[]] .width = true := by decide
def e553220015714 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553220015714 : Closed e553220015714 ∧ code e553220015714 = 2752243271266 := by decide
theorem cert_e553220015714 : check e553220015714 [[]] .width = true := by decide
def e553231773210 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553231773210 : Closed e553231773210 ∧ code e553231773210 = 2752255028762 := by decide
theorem cert_e553231773210 : check e553231773210 [[]] .width = true := by decide
def e553231805978 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553231805978 : Closed e553231805978 ∧ code e553231805978 = 2752255061530 := by decide
theorem cert_e553231805978 : check e553231805978 [[]] .width = true := by decide
def e553231808026 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553231808026 : Closed e553231808026 ∧ code e553231808026 = 2752255063578 := by decide
theorem cert_e553231808026 : check e553231808026 [[]] .width = true := by decide
def e553232494106 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553232494106 : Closed e553232494106 ∧ code e553232494106 = 2752255749658 := by decide
theorem cert_e553232494106 : check e553232494106 [[]] .width = true := by decide
def e553232597018 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553232597018 : Closed e553232597018 ∧ code e553232597018 = 2752255852570 := by decide
theorem cert_e553232597018 : check e553232597018 [[]] .width = true := by decide
def e553232597110 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553232597110 : Closed e553232597110 ∧ code e553232597110 = 2752255852662 := by decide
theorem cert_e553232597110 : check e553232597110 [[]] .width = true := by decide
def e553232597354 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553232597354 : Closed e553232597354 ∧ code e553232597354 = 2752255852906 := by decide
theorem cert_e553232597354 : check e553232597354 [[]] .width = true := by decide
def e553232597402 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553232597402 : Closed e553232597402 ∧ code e553232597402 = 2752255852954 := by decide
theorem cert_e553232597402 : check e553232597402 [[]] .width = true := by decide
def e553232598410 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553232598410 : Closed e553232598410 ∧ code e553232598410 = 2752255853962 := by decide
theorem cert_e553232598410 : check e553232598410 [[]] .width = true := by decide
def e553232598434 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553232598434 : Closed e553232598434 ∧ code e553232598434 = 2752255853986 := by decide
theorem cert_e553232598434 : check e553232598434 [[]] .width = true := by decide
def e553232598542 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553232598542 : Closed e553232598542 ∧ code e553232598542 = 2752255854094 := by decide
theorem cert_e553232598542 : check e553232598542 [[]] .width = true := by decide
def e553232598554 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553232598554 : Closed e553232598554 ∧ code e553232598554 = 2752255854106 := by decide
theorem cert_e553232598554 : check e553232598554 [[]] .width = true := by decide
def e553232598626 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553232598626 : Closed e553232598626 ∧ code e553232598626 = 2752255854178 := by decide
theorem cert_e553232598626 : check e553232598626 [[]] .width = true := by decide
def e553232690714 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553232690714 : Closed e553232690714 ∧ code e553232690714 = 2752255946266 := by decide
theorem cert_e553232690714 : check e553232690714 [[]] .width = true := by decide
end Blc.Floor41
