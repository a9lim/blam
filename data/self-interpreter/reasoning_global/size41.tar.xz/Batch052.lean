import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602268591982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e602268591982 : Closed e602268591982 ∧ code e602268591982 = 2801291847534 := by decide
theorem cert_e602268591982 : check e602268591982 [[],[]] .chain = true := by decide
def e602268591990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e602268591990 : Closed e602268591990 ∧ code e602268591990 = 2801291847542 := by decide
theorem cert_e602268591990 : check e602268591990 [[],[]] .chain = true := by decide
def e602268592054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e602268592054 : Closed e602268592054 ∧ code e602268592054 = 2801291847606 := by decide
theorem cert_e602268592054 : check e602268592054 [[],[]] .chain = true := by decide
def e602268593390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e602268593390 : Closed e602268593390 ∧ code e602268593390 = 2801291848942 := by decide
theorem cert_e602268593390 : check e602268593390 [[],[]] .chain = true := by decide
def e602268593398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e602268593398 : Closed e602268593398 ∧ code e602268593398 = 2801291848950 := by decide
theorem cert_e602268593398 : check e602268593398 [[],[]] .chain = true := by decide
def e602268593782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e602268593782 : Closed e602268593782 ∧ code e602268593782 = 2801291849334 := by decide
theorem cert_e602268593782 : check e602268593782 [[],[]] .chain = true := by decide
def e602268595054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e602268595054 : Closed e602268595054 ∧ code e602268595054 = 2801291850606 := by decide
theorem cert_e602268595054 : check e602268595054 [[],[]] .chain = true := by decide
def e602268595062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e602268595062 : Closed e602268595062 ∧ code e602268595062 = 2801291850614 := by decide
theorem cert_e602268595062 : check e602268595062 [[],[]] .chain = true := by decide
def e602268595118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e602268595118 : Closed e602268595118 ∧ code e602268595118 = 2801291850670 := by decide
theorem cert_e602268595118 : check e602268595118 [[],[]] .chain = true := by decide
def e602268595130 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e602268595130 : Closed e602268595130 ∧ code e602268595130 = 2801291850682 := by decide
theorem cert_e602268595130 : check e602268595130 [[],[]] .chain = true := by decide
def e602268595158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e602268595158 : Closed e602268595158 ∧ code e602268595158 = 2801291850710 := by decide
theorem cert_e602268595158 : check e602268595158 [[],[]] .chain = true := by decide
def e602268595162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e602268595162 : Closed e602268595162 ∧ code e602268595162 = 2801291850714 := by decide
theorem cert_e602268595162 : check e602268595162 [[],[]] .chain = true := by decide
def e602268595438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e602268595438 : Closed e602268595438 ∧ code e602268595438 = 2801291850990 := by decide
theorem cert_e602268595438 : check e602268595438 [[],[]] .chain = true := by decide
def e602268595446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e602268595446 : Closed e602268595446 ∧ code e602268595446 = 2801291850998 := by decide
theorem cert_e602268595446 : check e602268595446 [[],[]] .chain = true := by decide
def e602268595822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e602268595822 : Closed e602268595822 ∧ code e602268595822 = 2801291851374 := by decide
theorem cert_e602268595822 : check e602268595822 [[],[]] .chain = true := by decide
def e602268595834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e602268595834 : Closed e602268595834 ∧ code e602268595834 = 2801291851386 := by decide
theorem cert_e602268595834 : check e602268595834 [[],[]] .chain = true := by decide
def e602268596022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e602268596022 : Closed e602268596022 ∧ code e602268596022 = 2801291851574 := by decide
theorem cert_e602268596022 : check e602268596022 [[],[]] .chain = true := by decide
def e602268596026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e602268596026 : Closed e602268596026 ∧ code e602268596026 = 2801291851578 := by decide
theorem cert_e602268596026 : check e602268596026 [[],[]] .chain = true := by decide
def e602268596662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e602268596662 : Closed e602268596662 ∧ code e602268596662 = 2801291852214 := by decide
theorem cert_e602268596662 : check e602268596662 [[],[]] .chain = true := by decide
def e602268596694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e602268596694 : Closed e602268596694 ∧ code e602268596694 = 2801291852246 := by decide
theorem cert_e602268596694 : check e602268596694 [[],[]] .chain = true := by decide
def e602268596698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e602268596698 : Closed e602268596698 ∧ code e602268596698 = 2801291852250 := by decide
theorem cert_e602268596698 : check e602268596698 [[],[]] .chain = true := by decide
def e602268596854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e602268596854 : Closed e602268596854 ∧ code e602268596854 = 2801291852406 := by decide
theorem cert_e602268596854 : check e602268596854 [[],[]] .chain = true := by decide
def e602268597046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e602268597046 : Closed e602268597046 ∧ code e602268597046 = 2801291852598 := by decide
theorem cert_e602268597046 : check e602268597046 [[],[]] .chain = true := by decide
def e602268597050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e602268597050 : Closed e602268597050 ∧ code e602268597050 = 2801291852602 := by decide
theorem cert_e602268597050 : check e602268597050 [[],[]] .chain = true := by decide
def e602268604270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e602268604270 : Closed e602268604270 ∧ code e602268604270 = 2801291859822 := by decide
theorem cert_e602268604270 : check e602268604270 [[],[]] .chain = true := by decide
def e602268604278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e602268604278 : Closed e602268604278 ∧ code e602268604278 = 2801291859830 := by decide
theorem cert_e602268604278 : check e602268604278 [[],[]] .chain = true := by decide
def e602268604342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e602268604342 : Closed e602268604342 ∧ code e602268604342 = 2801291859894 := by decide
theorem cert_e602268604342 : check e602268604342 [[],[]] .chain = true := by decide
def e602268605678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e602268605678 : Closed e602268605678 ∧ code e602268605678 = 2801291861230 := by decide
theorem cert_e602268605678 : check e602268605678 [[],[]] .chain = true := by decide
def e602268605686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e602268605686 : Closed e602268605686 ∧ code e602268605686 = 2801291861238 := by decide
theorem cert_e602268605686 : check e602268605686 [[],[]] .chain = true := by decide
def e602268606070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e602268606070 : Closed e602268606070 ∧ code e602268606070 = 2801291861622 := by decide
theorem cert_e602268606070 : check e602268606070 [[],[]] .chain = true := by decide
def e602268617582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602268617582 : Closed e602268617582 ∧ code e602268617582 = 2801291873134 := by decide
theorem cert_e602268617582 : check e602268617582 [[],[]] .chain = true := by decide
def e602268617590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602268617590 : Closed e602268617590 ∧ code e602268617590 = 2801291873142 := by decide
theorem cert_e602268617590 : check e602268617590 [[],[]] .chain = true := by decide
def e602268617646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602268617646 : Closed e602268617646 ∧ code e602268617646 = 2801291873198 := by decide
theorem cert_e602268617646 : check e602268617646 [[],[]] .chain = true := by decide
def e602268617658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602268617658 : Closed e602268617658 ∧ code e602268617658 = 2801291873210 := by decide
theorem cert_e602268617658 : check e602268617658 [[],[]] .chain = true := by decide
def e602268617686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602268617686 : Closed e602268617686 ∧ code e602268617686 = 2801291873238 := by decide
theorem cert_e602268617686 : check e602268617686 [[],[]] .chain = true := by decide
def e602268617690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602268617690 : Closed e602268617690 ∧ code e602268617690 = 2801291873242 := by decide
theorem cert_e602268617690 : check e602268617690 [[],[]] .chain = true := by decide
def e602268617966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602268617966 : Closed e602268617966 ∧ code e602268617966 = 2801291873518 := by decide
theorem cert_e602268617966 : check e602268617966 [[],[]] .chain = true := by decide
def e602268617974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602268617974 : Closed e602268617974 ∧ code e602268617974 = 2801291873526 := by decide
theorem cert_e602268617974 : check e602268617974 [[],[]] .chain = true := by decide
def e602268618350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602268618350 : Closed e602268618350 ∧ code e602268618350 = 2801291873902 := by decide
theorem cert_e602268618350 : check e602268618350 [[],[]] .chain = true := by decide
def e602268618362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602268618362 : Closed e602268618362 ∧ code e602268618362 = 2801291873914 := by decide
theorem cert_e602268618362 : check e602268618362 [[],[]] .chain = true := by decide
def e602268618550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602268618550 : Closed e602268618550 ∧ code e602268618550 = 2801291874102 := by decide
theorem cert_e602268618550 : check e602268618550 [[],[]] .chain = true := by decide
def e602268618554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602268618554 : Closed e602268618554 ∧ code e602268618554 = 2801291874106 := by decide
theorem cert_e602268618554 : check e602268618554 [[],[]] .chain = true := by decide
def e602268624310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e602268624310 : Closed e602268624310 ∧ code e602268624310 = 2801291879862 := by decide
theorem cert_e602268624310 : check e602268624310 [[],[]] .chain = true := by decide
def e602268624342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e602268624342 : Closed e602268624342 ∧ code e602268624342 = 2801291879894 := by decide
theorem cert_e602268624342 : check e602268624342 [[],[]] .chain = true := by decide
def e602268624346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e602268624346 : Closed e602268624346 ∧ code e602268624346 = 2801291879898 := by decide
theorem cert_e602268624346 : check e602268624346 [[],[]] .chain = true := by decide
def e602268624502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e602268624502 : Closed e602268624502 ∧ code e602268624502 = 2801291880054 := by decide
theorem cert_e602268624502 : check e602268624502 [[],[]] .chain = true := by decide
def e602268624694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e602268624694 : Closed e602268624694 ∧ code e602268624694 = 2801291880246 := by decide
theorem cert_e602268624694 : check e602268624694 [[],[]] .chain = true := by decide
def e602268624698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e602268624698 : Closed e602268624698 ∧ code e602268624698 = 2801291880250 := by decide
theorem cert_e602268624698 : check e602268624698 [[],[]] .chain = true := by decide
def e602268961646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602268961646 : Closed e602268961646 ∧ code e602268961646 = 2801292217198 := by decide
theorem cert_e602268961646 : check e602268961646 [[],[],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e602268961654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602268961654 : Closed e602268961654 ∧ code e602268961654 = 2801292217206 := by decide
private def t_e602268961654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e602268961654 : ¬ IsSelfInterpreter e602268961654 :=
  wSource (t := t_e602268961654) (replay_sound (ps := []) (t := e602268961654) (by decide)) (by decide)
def e602268961710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602268961710 : Closed e602268961710 ∧ code e602268961710 = 2801292217262 := by decide
theorem cert_e602268961710 : checkPay e602268961710 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right,.under,.right,.under]] = true := by decide
def e602268961722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602268961722 : Closed e602268961722 ∧ code e602268961722 = 2801292217274 := by decide
theorem cert_e602268961722 : checkPay e602268961722 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[]] 0 [[.under]] = true := by decide
def e602268961750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602268961750 : Closed e602268961750 ∧ code e602268961750 = 2801292217302 := by decide
private def t_e602268961750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e602268961750 : ¬ IsSelfInterpreter e602268961750 :=
  wSource (t := t_e602268961750) (replay_sound (ps := []) (t := e602268961750) (by decide)) (by decide)
def e602268961754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602268961754 : Closed e602268961754 ∧ code e602268961754 = 2801292217306 := by decide
theorem cert_e602268961754 : check e602268961754 [[],[],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602268962030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602268962030 : Closed e602268962030 ∧ code e602268962030 = 2801292217582 := by decide
theorem cert_e602268962030 : checkPay e602268962030 [[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[]] 0 [[.under]] = true := by decide
def e602268962038 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602268962038 : Closed e602268962038 ∧ code e602268962038 = 2801292217590 := by decide
theorem cert_e602268962038 : check e602268962038 [[],[],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602268962414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602268962414 : Closed e602268962414 ∧ code e602268962414 = 2801292217966 := by decide
theorem cert_e602268962414 : check e602268962414 [[],[],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e602268962426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602268962426 : Closed e602268962426 ∧ code e602268962426 = 2801292217978 := by decide
theorem cert_e602268962426 : check e602268962426 [[],[],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e602268962614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602268962614 : Closed e602268962614 ∧ code e602268962614 = 2801292218166 := by decide
theorem cert_e602268962614 : check e602268962614 [[],[],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e602268962618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602268962618 : Closed e602268962618 ∧ code e602268962618 = 2801292218170 := by decide
theorem cert_e602268962618 : check e602268962618 [[],[],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e602285321582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e602285321582 : Closed e602285321582 ∧ code e602285321582 = 2801308577134 := by decide
theorem cert_e602285321582 : check e602285321582 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e602285321590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e602285321590 : Closed e602285321590 ∧ code e602285321590 = 2801308577142 := by decide
theorem cert_e602285321590 : checkPay e602285321590 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602285321646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e602285321646 : Closed e602285321646 ∧ code e602285321646 = 2801308577198 := by decide
theorem cert_e602285321646 : check e602285321646 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e602285321658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e602285321658 : Closed e602285321658 ∧ code e602285321658 = 2801308577210 := by decide
theorem cert_e602285321658 : check e602285321658 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e602285321686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e602285321686 : Closed e602285321686 ∧ code e602285321686 = 2801308577238 := by decide
theorem cert_e602285321686 : check e602285321686 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285321690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e602285321690 : Closed e602285321690 ∧ code e602285321690 = 2801308577242 := by decide
theorem cert_e602285321690 : check e602285321690 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e602285321902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e602285321902 : Closed e602285321902 ∧ code e602285321902 = 2801308577454 := by decide
theorem cert_e602285321902 : check e602285321902 [[],[]] .sourceHead = true := by decide
def e602285321914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e602285321914 : Closed e602285321914 ∧ code e602285321914 = 2801308577466 := by decide
theorem cert_e602285321914 : check e602285321914 [[],[]] .sourceHead = true := by decide
def e602285321962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e602285321962 : Closed e602285321962 ∧ code e602285321962 = 2801308577514 := by decide
theorem cert_e602285321962 : check e602285321962 [[],[]] .sourceHead = true := by decide
def e602285322070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e602285322070 : Closed e602285322070 ∧ code e602285322070 = 2801308577622 := by decide
theorem cert_e602285322070 : check e602285322070 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e602285322074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e602285322074 : Closed e602285322074 ∧ code e602285322074 = 2801308577626 := by decide
theorem cert_e602285322074 : check e602285322074 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e602285322090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e602285322090 : Closed e602285322090 ∧ code e602285322090 = 2801308577642 := by decide
theorem cert_e602285322090 : check e602285322090 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e602285323118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e602285323118 : Closed e602285323118 ∧ code e602285323118 = 2801308578670 := by decide
theorem cert_e602285323118 : check e602285323118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e602285323126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e602285323126 : Closed e602285323126 ∧ code e602285323126 = 2801308578678 := by decide
theorem cert_e602285323126 : check e602285323126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285323182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e602285323182 : Closed e602285323182 ∧ code e602285323182 = 2801308578734 := by decide
theorem cert_e602285323182 : check e602285323182 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602285323194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e602285323194 : Closed e602285323194 ∧ code e602285323194 = 2801308578746 := by decide
theorem cert_e602285323194 : check e602285323194 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602285323222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e602285323222 : Closed e602285323222 ∧ code e602285323222 = 2801308578774 := by decide
theorem cert_e602285323222 : check e602285323222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285323226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e602285323226 : Closed e602285323226 ∧ code e602285323226 = 2801308578778 := by decide
theorem cert_e602285323226 : check e602285323226 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285323502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e602285323502 : Closed e602285323502 ∧ code e602285323502 = 2801308579054 := by decide
theorem cert_e602285323502 : check e602285323502 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285323510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e602285323510 : Closed e602285323510 ∧ code e602285323510 = 2801308579062 := by decide
theorem cert_e602285323510 : check e602285323510 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285323886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e602285323886 : Closed e602285323886 ∧ code e602285323886 = 2801308579438 := by decide
theorem cert_e602285323886 : check e602285323886 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602285323898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e602285323898 : Closed e602285323898 ∧ code e602285323898 = 2801308579450 := by decide
theorem cert_e602285323898 : check e602285323898 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602285324086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e602285324086 : Closed e602285324086 ∧ code e602285324086 = 2801308579638 := by decide
theorem cert_e602285324086 : check e602285324086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e602285324090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e602285324090 : Closed e602285324090 ∧ code e602285324090 = 2801308579642 := by decide
theorem cert_e602285324090 : check e602285324090 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285324718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e602285324718 : Closed e602285324718 ∧ code e602285324718 = 2801308580270 := by decide
theorem cert_e602285324718 : checkPay e602285324718 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e602285324730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e602285324730 : Closed e602285324730 ∧ code e602285324730 = 2801308580282 := by decide
theorem cert_e602285324730 : checkPay e602285324730 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e602285324778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e602285324778 : Closed e602285324778 ∧ code e602285324778 = 2801308580330 := by decide
theorem cert_e602285324778 : checkPay e602285324778 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.under,.under,.left,.right]] = true := by decide
def e602285324910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e602285324910 : Closed e602285324910 ∧ code e602285324910 = 2801308580462 := by decide
theorem cert_e602285324910 : checkPay e602285324910 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602285324922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e602285324922 : Closed e602285324922 ∧ code e602285324922 = 2801308580474 := by decide
theorem cert_e602285324922 : checkPay e602285324922 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602285325210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e602285325210 : Closed e602285325210 ∧ code e602285325210 = 2801308580762 := by decide
theorem cert_e602285325210 : checkPay e602285325210 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e602285325526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e602285325526 : Closed e602285325526 ∧ code e602285325526 = 2801308581078 := by decide
theorem cert_e602285325526 : check e602285325526 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602285325530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e602285325530 : Closed e602285325530 ∧ code e602285325530 = 2801308581082 := by decide
theorem cert_e602285325530 : check e602285325530 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602285325546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e602285325546 : Closed e602285325546 ∧ code e602285325546 = 2801308581098 := by decide
theorem cert_e602285325546 : check e602285325546 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602285325622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e602285325622 : Closed e602285325622 ∧ code e602285325622 = 2801308581174 := by decide
theorem cert_e602285325622 : check e602285325622 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602285325626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e602285325626 : Closed e602285325626 ∧ code e602285325626 = 2801308581178 := by decide
theorem cert_e602285325626 : check e602285325626 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602285325722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e602285325722 : Closed e602285325722 ∧ code e602285325722 = 2801308581274 := by decide
theorem cert_e602285325722 : check e602285325722 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e602285329262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602285329262 : Closed e602285329262 ∧ code e602285329262 = 2801308584814 := by decide
theorem cert_e602285329262 : check e602285329262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e602285329270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602285329270 : Closed e602285329270 ∧ code e602285329270 = 2801308584822 := by decide
theorem cert_e602285329270 : check e602285329270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e602285329326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602285329326 : Closed e602285329326 ∧ code e602285329326 = 2801308584878 := by decide
theorem cert_e602285329326 : check e602285329326 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602285329338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602285329338 : Closed e602285329338 ∧ code e602285329338 = 2801308584890 := by decide
theorem cert_e602285329338 : check e602285329338 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602285329366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602285329366 : Closed e602285329366 ∧ code e602285329366 = 2801308584918 := by decide
theorem cert_e602285329366 : check e602285329366 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e602285329370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602285329370 : Closed e602285329370 ∧ code e602285329370 = 2801308584922 := by decide
theorem cert_e602285329370 : check e602285329370 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e602285329646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602285329646 : Closed e602285329646 ∧ code e602285329646 = 2801308585198 := by decide
theorem cert_e602285329646 : check e602285329646 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e602285329654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602285329654 : Closed e602285329654 ∧ code e602285329654 = 2801308585206 := by decide
theorem cert_e602285329654 : check e602285329654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e602285330030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602285330030 : Closed e602285330030 ∧ code e602285330030 = 2801308585582 := by decide
theorem cert_e602285330030 : check e602285330030 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602285330042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602285330042 : Closed e602285330042 ∧ code e602285330042 = 2801308585594 := by decide
theorem cert_e602285330042 : check e602285330042 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e602285330230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602285330230 : Closed e602285330230 ∧ code e602285330230 = 2801308585782 := by decide
theorem cert_e602285330230 : check e602285330230 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602285330234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602285330234 : Closed e602285330234 ∧ code e602285330234 = 2801308585786 := by decide
theorem cert_e602285330234 : check e602285330234 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e602285335982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e602285335982 : Closed e602285335982 ∧ code e602285335982 = 2801308591534 := by decide
theorem cert_e602285335982 : check e602285335982 [[],[]] .sourceHead = true := by decide
def e602285335994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e602285335994 : Closed e602285335994 ∧ code e602285335994 = 2801308591546 := by decide
theorem cert_e602285335994 : check e602285335994 [[],[]] .sourceHead = true := by decide
def e602285336042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e602285336042 : Closed e602285336042 ∧ code e602285336042 = 2801308591594 := by decide
theorem cert_e602285336042 : check e602285336042 [[],[]] .sourceHead = true := by decide
def e602285336174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e602285336174 : Closed e602285336174 ∧ code e602285336174 = 2801308591726 := by decide
theorem cert_e602285336174 : check e602285336174 [[],[]] .sourceHead = true := by decide
def e602285336186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e602285336186 : Closed e602285336186 ∧ code e602285336186 = 2801308591738 := by decide
theorem cert_e602285336186 : check e602285336186 [[],[]] .sourceHead = true := by decide
def e602285336474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e602285336474 : Closed e602285336474 ∧ code e602285336474 = 2801308592026 := by decide
theorem cert_e602285336474 : check e602285336474 [[],[]] .sourceHead = true := by decide
def e602285339350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e602285339350 : Closed e602285339350 ∧ code e602285339350 = 2801308594902 := by decide
theorem cert_e602285339350 : check e602285339350 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e602285339354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e602285339354 : Closed e602285339354 ∧ code e602285339354 = 2801308594906 := by decide
theorem cert_e602285339354 : check e602285339354 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e602285339370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e602285339370 : Closed e602285339370 ∧ code e602285339370 = 2801308594922 := by decide
theorem cert_e602285339370 : check e602285339370 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e602285339446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e602285339446 : Closed e602285339446 ∧ code e602285339446 = 2801308594998 := by decide
theorem cert_e602285339446 : check e602285339446 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e602285339450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e602285339450 : Closed e602285339450 ∧ code e602285339450 = 2801308595002 := by decide
theorem cert_e602285339450 : check e602285339450 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e602285339546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e602285339546 : Closed e602285339546 ∧ code e602285339546 = 2801308595098 := by decide
theorem cert_e602285339546 : check e602285339546 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e602285476718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602285476718 : Closed e602285476718 ∧ code e602285476718 = 2801308732270 := by decide
theorem cert_e602285476718 : check e602285476718 [[],[]] .sourceHead = true := by decide
def e602285476726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602285476726 : Closed e602285476726 ∧ code e602285476726 = 2801308732278 := by decide
theorem cert_e602285476726 : check e602285476726 [[],[]] .sourceHead = true := by decide
def e602285476782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602285476782 : Closed e602285476782 ∧ code e602285476782 = 2801308732334 := by decide
theorem cert_e602285476782 : check e602285476782 [[],[]] .sourceHead = true := by decide
def e602285476794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602285476794 : Closed e602285476794 ∧ code e602285476794 = 2801308732346 := by decide
theorem cert_e602285476794 : check e602285476794 [[],[]] .sourceHead = true := by decide
def e602285476822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602285476822 : Closed e602285476822 ∧ code e602285476822 = 2801308732374 := by decide
theorem cert_e602285476822 : check e602285476822 [[],[]] .sourceHead = true := by decide
def e602285476826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602285476826 : Closed e602285476826 ∧ code e602285476826 = 2801308732378 := by decide
theorem cert_e602285476826 : check e602285476826 [[],[]] .sourceHead = true := by decide
def e602285477102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602285477102 : Closed e602285477102 ∧ code e602285477102 = 2801308732654 := by decide
theorem cert_e602285477102 : check e602285477102 [[],[]] .sourceHead = true := by decide
def e602285477110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602285477110 : Closed e602285477110 ∧ code e602285477110 = 2801308732662 := by decide
theorem cert_e602285477110 : check e602285477110 [[],[]] .sourceHead = true := by decide
def e602285477486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602285477486 : Closed e602285477486 ∧ code e602285477486 = 2801308733038 := by decide
theorem cert_e602285477486 : check e602285477486 [[],[]] .sourceHead = true := by decide
def e602285477498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602285477498 : Closed e602285477498 ∧ code e602285477498 = 2801308733050 := by decide
theorem cert_e602285477498 : check e602285477498 [[],[]] .sourceHead = true := by decide
def e602285477686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602285477686 : Closed e602285477686 ∧ code e602285477686 = 2801308733238 := by decide
theorem cert_e602285477686 : check e602285477686 [[],[]] .sourceHead = true := by decide
def e602285477690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602285477690 : Closed e602285477690 ∧ code e602285477690 = 2801308733242 := by decide
theorem cert_e602285477690 : check e602285477690 [[],[]] .sourceHead = true := by decide
def e602286066542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602286066542 : Closed e602286066542 ∧ code e602286066542 = 2801309322094 := by decide
theorem cert_e602286066542 : check e602286066542 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e602286066550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602286066550 : Closed e602286066550 ∧ code e602286066550 = 2801309322102 := by decide
theorem cert_e602286066550 : check e602286066550 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e602286066606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602286066606 : Closed e602286066606 ∧ code e602286066606 = 2801309322158 := by decide
theorem cert_e602286066606 : check e602286066606 [[],[],[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e602286066618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602286066618 : Closed e602286066618 ∧ code e602286066618 = 2801309322170 := by decide
private def t_e602286066618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e602286066618 : ¬ IsSelfInterpreter e602286066618 :=
  wSource (t := t_e602286066618) (replay_sound (ps := []) (t := e602286066618) (by decide)) (by decide)
def e602286066646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602286066646 : Closed e602286066646 ∧ code e602286066646 = 2801309322198 := by decide
theorem cert_e602286066646 : check e602286066646 [[],[],[],[],[],[],[.under,.left]] .chain = true := by decide
def e602286066650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602286066650 : Closed e602286066650 ∧ code e602286066650 = 2801309322202 := by decide
private def t_e602286066650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e602286066650 : ¬ IsSelfInterpreter e602286066650 :=
  wSource (t := t_e602286066650) (replay_sound (ps := []) (t := e602286066650) (by decide)) (by decide)
def e602286066926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602286066926 : Closed e602286066926 ∧ code e602286066926 = 2801309322478 := by decide
theorem cert_e602286066926 : check e602286066926 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e602286066934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602286066934 : Closed e602286066934 ∧ code e602286066934 = 2801309322486 := by decide
theorem cert_e602286066934 : check e602286066934 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e602286067310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602286067310 : Closed e602286067310 ∧ code e602286067310 = 2801309322862 := by decide
theorem cert_e602286067310 : checkPay e602286067310 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e602286067322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602286067322 : Closed e602286067322 ∧ code e602286067322 = 2801309322874 := by decide
theorem cert_e602286067322 : check e602286067322 [[],[],[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e602286067510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602286067510 : Closed e602286067510 ∧ code e602286067510 = 2801309323062 := by decide
theorem cert_e602286067510 : check e602286067510 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e602286067514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602286067514 : Closed e602286067514 ∧ code e602286067514 = 2801309323066 := by decide
theorem cert_e602286067514 : check e602286067514 [[],[],[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e602906122974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e602906122974 : Closed e602906122974 ∧ code e602906122974 = 2801929378526 := by decide
theorem cert_e602906122974 : check e602906122974 [[],[]] .smaller = true := by decide
def e602906122998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e602906122998 : Closed e602906122998 ∧ code e602906122998 = 2801929378550 := by decide
theorem cert_e602906122998 : check e602906122998 [[],[]] .smaller = true := by decide
def e602906123102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e602906123102 : Closed e602906123102 ∧ code e602906123102 = 2801929378654 := by decide
theorem cert_e602906123102 : check e602906123102 [[],[]] .smaller = true := by decide
def e602906123118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e602906123118 : Closed e602906123118 ∧ code e602906123118 = 2801929378670 := by decide
theorem cert_e602906123118 : check e602906123118 [[],[]] .smaller = true := by decide
def e602906123126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e602906123126 : Closed e602906123126 ∧ code e602906123126 = 2801929378678 := by decide
theorem cert_e602906123126 : check e602906123126 [[],[]] .smaller = true := by decide
def e602906123130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e602906123130 : Closed e602906123130 ∧ code e602906123130 = 2801929378682 := by decide
theorem cert_e602906123130 : check e602906123130 [[],[]] .smaller = true := by decide
def e602906123190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e602906123190 : Closed e602906123190 ∧ code e602906123190 = 2801929378742 := by decide
theorem cert_e602906123190 : check e602906123190 [[],[]] .smaller = true := by decide
def e602906123222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e602906123222 : Closed e602906123222 ∧ code e602906123222 = 2801929378774 := by decide
theorem cert_e602906123222 : check e602906123222 [[],[]] .smaller = true := by decide
def e602906123226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e602906123226 : Closed e602906123226 ∧ code e602906123226 = 2801929378778 := by decide
theorem cert_e602906123226 : check e602906123226 [[],[]] .smaller = true := by decide
def e602906123614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e602906123614 : Closed e602906123614 ∧ code e602906123614 = 2801929379166 := by decide
theorem cert_e602906123614 : check e602906123614 [[],[]] .smaller = true := by decide
def e602906123630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e602906123630 : Closed e602906123630 ∧ code e602906123630 = 2801929379182 := by decide
theorem cert_e602906123630 : check e602906123630 [[],[]] .smaller = true := by decide
def e602906123638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e602906123638 : Closed e602906123638 ∧ code e602906123638 = 2801929379190 := by decide
theorem cert_e602906123638 : check e602906123638 [[],[]] .smaller = true := by decide
def e602906123642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e602906123642 : Closed e602906123642 ∧ code e602906123642 = 2801929379194 := by decide
theorem cert_e602906123642 : check e602906123642 [[],[]] .smaller = true := by decide
def e602906123694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e602906123694 : Closed e602906123694 ∧ code e602906123694 = 2801929379246 := by decide
theorem cert_e602906123694 : check e602906123694 [[],[]] .smaller = true := by decide
def e602906123706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e602906123706 : Closed e602906123706 ∧ code e602906123706 = 2801929379258 := by decide
theorem cert_e602906123706 : check e602906123706 [[],[]] .smaller = true := by decide
def e602906123734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e602906123734 : Closed e602906123734 ∧ code e602906123734 = 2801929379286 := by decide
theorem cert_e602906123734 : check e602906123734 [[],[]] .smaller = true := by decide
end Blc.Floor41
