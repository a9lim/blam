import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e562288438638 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e562288438638 : Closed e562288438638 ∧ code e562288438638 = 2761311694190 := by decide
theorem cert_e562288438638 : check e562288438638 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e562288438646 : Closed e562288438646 ∧ code e562288438646 = 2761311694198 := by decide
theorem cert_e562288438646 : check e562288438646 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e562288438702 : Closed e562288438702 ∧ code e562288438702 = 2761311694254 := by decide
theorem cert_e562288438702 : check e562288438702 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e562288438714 : Closed e562288438714 ∧ code e562288438714 = 2761311694266 := by decide
theorem cert_e562288438714 : check e562288438714 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e562288438742 : Closed e562288438742 ∧ code e562288438742 = 2761311694294 := by decide
theorem cert_e562288438742 : check e562288438742 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438746 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e562288438746 : Closed e562288438746 ∧ code e562288438746 = 2761311694298 := by decide
theorem cert_e562288438746 : check e562288438746 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e562288438958 : Closed e562288438958 ∧ code e562288438958 = 2761311694510 := by decide
theorem cert_e562288438958 : check e562288438958 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288438970 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e562288438970 : Closed e562288438970 ∧ code e562288438970 = 2761311694522 := by decide
theorem cert_e562288438970 : check e562288438970 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288439018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e562288439018 : Closed e562288439018 ∧ code e562288439018 = 2761311694570 := by decide
theorem cert_e562288439018 : check e562288439018 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288439126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e562288439126 : Closed e562288439126 ∧ code e562288439126 = 2761311694678 := by decide
theorem cert_e562288439126 : check e562288439126 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288439130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e562288439130 : Closed e562288439130 ∧ code e562288439130 = 2761311694682 := by decide
theorem cert_e562288439130 : check e562288439130 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288439146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e562288439146 : Closed e562288439146 ∧ code e562288439146 = 2761311694698 := by decide
theorem cert_e562288439146 : check e562288439146 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e562288440174 : Closed e562288440174 ∧ code e562288440174 = 2761311695726 := by decide
theorem cert_e562288440174 : check e562288440174 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440182 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e562288440182 : Closed e562288440182 ∧ code e562288440182 = 2761311695734 := by decide
theorem cert_e562288440182 : check e562288440182 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440238 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e562288440238 : Closed e562288440238 ∧ code e562288440238 = 2761311695790 := by decide
theorem cert_e562288440238 : check e562288440238 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440250 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e562288440250 : Closed e562288440250 ∧ code e562288440250 = 2761311695802 := by decide
theorem cert_e562288440250 : check e562288440250 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440278 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e562288440278 : Closed e562288440278 ∧ code e562288440278 = 2761311695830 := by decide
theorem cert_e562288440278 : check e562288440278 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e562288440282 : Closed e562288440282 ∧ code e562288440282 = 2761311695834 := by decide
theorem cert_e562288440282 : check e562288440282 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e562288440558 : Closed e562288440558 ∧ code e562288440558 = 2761311696110 := by decide
theorem cert_e562288440558 : check e562288440558 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e562288440566 : Closed e562288440566 ∧ code e562288440566 = 2761311696118 := by decide
theorem cert_e562288440566 : check e562288440566 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440942 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e562288440942 : Closed e562288440942 ∧ code e562288440942 = 2761311696494 := by decide
theorem cert_e562288440942 : check e562288440942 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288440954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e562288440954 : Closed e562288440954 ∧ code e562288440954 = 2761311696506 := by decide
theorem cert_e562288440954 : check e562288440954 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e562288441142 : Closed e562288441142 ∧ code e562288441142 = 2761311696694 := by decide
theorem cert_e562288441142 : check e562288441142 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e562288441146 : Closed e562288441146 ∧ code e562288441146 = 2761311696698 := by decide
theorem cert_e562288441146 : check e562288441146 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441774 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e562288441774 : Closed e562288441774 ∧ code e562288441774 = 2761311697326 := by decide
theorem cert_e562288441774 : check e562288441774 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e562288441786 : Closed e562288441786 ∧ code e562288441786 = 2761311697338 := by decide
theorem cert_e562288441786 : check e562288441786 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e562288441834 : Closed e562288441834 ∧ code e562288441834 = 2761311697386 := by decide
theorem cert_e562288441834 : check e562288441834 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441966 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e562288441966 : Closed e562288441966 ∧ code e562288441966 = 2761311697518 := by decide
theorem cert_e562288441966 : check e562288441966 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288441978 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e562288441978 : Closed e562288441978 ∧ code e562288441978 = 2761311697530 := by decide
theorem cert_e562288441978 : check e562288441978 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e562288442266 : Closed e562288442266 ∧ code e562288442266 = 2761311697818 := by decide
theorem cert_e562288442266 : check e562288442266 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442582 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e562288442582 : Closed e562288442582 ∧ code e562288442582 = 2761311698134 := by decide
theorem cert_e562288442582 : check e562288442582 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e562288442586 : Closed e562288442586 ∧ code e562288442586 = 2761311698138 := by decide
theorem cert_e562288442586 : check e562288442586 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e562288442602 : Closed e562288442602 ∧ code e562288442602 = 2761311698154 := by decide
theorem cert_e562288442602 : check e562288442602 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e562288442678 : Closed e562288442678 ∧ code e562288442678 = 2761311698230 := by decide
theorem cert_e562288442678 : check e562288442678 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442682 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e562288442682 : Closed e562288442682 ∧ code e562288442682 = 2761311698234 := by decide
theorem cert_e562288442682 : check e562288442682 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288442778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e562288442778 : Closed e562288442778 ∧ code e562288442778 = 2761311698330 := by decide
theorem cert_e562288442778 : check e562288442778 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562288446318 : Closed e562288446318 ∧ code e562288446318 = 2761311701870 := by decide
theorem cert_e562288446318 : check e562288446318 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446326 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562288446326 : Closed e562288446326 ∧ code e562288446326 = 2761311701878 := by decide
theorem cert_e562288446326 : check e562288446326 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446382 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562288446382 : Closed e562288446382 ∧ code e562288446382 = 2761311701934 := by decide
theorem cert_e562288446382 : check e562288446382 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562288446394 : Closed e562288446394 ∧ code e562288446394 = 2761311701946 := by decide
theorem cert_e562288446394 : check e562288446394 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562288446422 : Closed e562288446422 ∧ code e562288446422 = 2761311701974 := by decide
theorem cert_e562288446422 : check e562288446422 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562288446426 : Closed e562288446426 ∧ code e562288446426 = 2761311701978 := by decide
theorem cert_e562288446426 : check e562288446426 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562288446702 : Closed e562288446702 ∧ code e562288446702 = 2761311702254 := by decide
theorem cert_e562288446702 : check e562288446702 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288446710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562288446710 : Closed e562288446710 ∧ code e562288446710 = 2761311702262 := by decide
theorem cert_e562288446710 : check e562288446710 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288447086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562288447086 : Closed e562288447086 ∧ code e562288447086 = 2761311702638 := by decide
theorem cert_e562288447086 : check e562288447086 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288447098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562288447098 : Closed e562288447098 ∧ code e562288447098 = 2761311702650 := by decide
theorem cert_e562288447098 : check e562288447098 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288447286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562288447286 : Closed e562288447286 ∧ code e562288447286 = 2761311702838 := by decide
theorem cert_e562288447286 : check e562288447286 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288447290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562288447290 : Closed e562288447290 ∧ code e562288447290 = 2761311702842 := by decide
theorem cert_e562288447290 : check e562288447290 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288453038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e562288453038 : Closed e562288453038 ∧ code e562288453038 = 2761311708590 := by decide
theorem cert_e562288453038 : check e562288453038 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288453050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e562288453050 : Closed e562288453050 ∧ code e562288453050 = 2761311708602 := by decide
theorem cert_e562288453050 : check e562288453050 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288453098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e562288453098 : Closed e562288453098 ∧ code e562288453098 = 2761311708650 := by decide
theorem cert_e562288453098 : check e562288453098 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288453230 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e562288453230 : Closed e562288453230 ∧ code e562288453230 = 2761311708782 := by decide
theorem cert_e562288453230 : check e562288453230 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288453242 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e562288453242 : Closed e562288453242 ∧ code e562288453242 = 2761311708794 := by decide
theorem cert_e562288453242 : check e562288453242 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288453530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e562288453530 : Closed e562288453530 ∧ code e562288453530 = 2761311709082 := by decide
theorem cert_e562288453530 : check e562288453530 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288456406 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e562288456406 : Closed e562288456406 ∧ code e562288456406 = 2761311711958 := by decide
theorem cert_e562288456406 : check e562288456406 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288456410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e562288456410 : Closed e562288456410 ∧ code e562288456410 = 2761311711962 := by decide
theorem cert_e562288456410 : check e562288456410 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288456426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e562288456426 : Closed e562288456426 ∧ code e562288456426 = 2761311711978 := by decide
theorem cert_e562288456426 : check e562288456426 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288456502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e562288456502 : Closed e562288456502 ∧ code e562288456502 = 2761311712054 := by decide
theorem cert_e562288456502 : check e562288456502 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288456506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e562288456506 : Closed e562288456506 ∧ code e562288456506 = 2761311712058 := by decide
theorem cert_e562288456506 : check e562288456506 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288456602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e562288456602 : Closed e562288456602 ∧ code e562288456602 = 2761311712154 := by decide
theorem cert_e562288456602 : check e562288456602 [[],[.under,.left],[.under]] .smaller = true := by decide
def e562288593774 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562288593774 : Closed e562288593774 ∧ code e562288593774 = 2761311849326 := by decide
theorem cert_e562288593774 : check e562288593774 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288593782 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562288593782 : Closed e562288593782 ∧ code e562288593782 = 2761311849334 := by decide
theorem cert_e562288593782 : check e562288593782 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288593838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562288593838 : Closed e562288593838 ∧ code e562288593838 = 2761311849390 := by decide
theorem cert_e562288593838 : check e562288593838 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288593850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562288593850 : Closed e562288593850 ∧ code e562288593850 = 2761311849402 := by decide
theorem cert_e562288593850 : check e562288593850 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288593878 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562288593878 : Closed e562288593878 ∧ code e562288593878 = 2761311849430 := by decide
theorem cert_e562288593878 : check e562288593878 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288593882 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562288593882 : Closed e562288593882 ∧ code e562288593882 = 2761311849434 := by decide
theorem cert_e562288593882 : check e562288593882 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288594158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562288594158 : Closed e562288594158 ∧ code e562288594158 = 2761311849710 := by decide
theorem cert_e562288594158 : check e562288594158 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288594166 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562288594166 : Closed e562288594166 ∧ code e562288594166 = 2761311849718 := by decide
theorem cert_e562288594166 : check e562288594166 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288594542 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562288594542 : Closed e562288594542 ∧ code e562288594542 = 2761311850094 := by decide
theorem cert_e562288594542 : check e562288594542 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288594554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562288594554 : Closed e562288594554 ∧ code e562288594554 = 2761311850106 := by decide
theorem cert_e562288594554 : check e562288594554 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288594742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562288594742 : Closed e562288594742 ∧ code e562288594742 = 2761311850294 := by decide
theorem cert_e562288594742 : check e562288594742 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562288594746 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562288594746 : Closed e562288594746 ∧ code e562288594746 = 2761311850298 := by decide
theorem cert_e562288594746 : check e562288594746 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e562289183598 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562289183598 : Closed e562289183598 ∧ code e562289183598 = 2761312439150 := by decide
theorem cert_e562289183598 : check e562289183598 [[],[.under,.left]] .chain = true := by decide
def e562289183606 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562289183606 : Closed e562289183606 ∧ code e562289183606 = 2761312439158 := by decide
theorem cert_e562289183606 : check e562289183606 [[],[.under,.left]] .chain = true := by decide
def e562289183662 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562289183662 : Closed e562289183662 ∧ code e562289183662 = 2761312439214 := by decide
theorem cert_e562289183662 : check e562289183662 [[],[.under,.left]] .chain = true := by decide
def e562289183674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562289183674 : Closed e562289183674 ∧ code e562289183674 = 2761312439226 := by decide
theorem cert_e562289183674 : check e562289183674 [[],[.under,.left]] .chain = true := by decide
def e562289183702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562289183702 : Closed e562289183702 ∧ code e562289183702 = 2761312439254 := by decide
theorem cert_e562289183702 : check e562289183702 [[],[.under,.left]] .chain = true := by decide
def e562289183706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562289183706 : Closed e562289183706 ∧ code e562289183706 = 2761312439258 := by decide
theorem cert_e562289183706 : check e562289183706 [[],[.under,.left]] .chain = true := by decide
def e562289183982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562289183982 : Closed e562289183982 ∧ code e562289183982 = 2761312439534 := by decide
theorem cert_e562289183982 : check e562289183982 [[],[.under,.left]] .chain = true := by decide
def e562289183990 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562289183990 : Closed e562289183990 ∧ code e562289183990 = 2761312439542 := by decide
theorem cert_e562289183990 : check e562289183990 [[],[.under,.left]] .chain = true := by decide
def e562289184366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562289184366 : Closed e562289184366 ∧ code e562289184366 = 2761312439918 := by decide
theorem cert_e562289184366 : check e562289184366 [[],[.under,.left]] .chain = true := by decide
def e562289184378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562289184378 : Closed e562289184378 ∧ code e562289184378 = 2761312439930 := by decide
theorem cert_e562289184378 : check e562289184378 [[],[.under,.left]] .chain = true := by decide
def e562289184566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562289184566 : Closed e562289184566 ∧ code e562289184566 = 2761312440118 := by decide
theorem cert_e562289184566 : check e562289184566 [[],[.under,.left]] .chain = true := by decide
def e562289184570 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562289184570 : Closed e562289184570 ∧ code e562289184570 = 2761312440122 := by decide
theorem cert_e562289184570 : check e562289184570 [[],[.under,.left]] .chain = true := by decide
def e562308167706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308167706 : Closed e562308167706 ∧ code e562308167706 = 2761331423258 := by decide
theorem cert_e562308167706 : check e562308167706 [[]] .width = true := by decide
def e562308175898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308175898 : Closed e562308175898 ∧ code e562308175898 = 2761331431450 := by decide
theorem cert_e562308175898 : check e562308175898 [[]] .width = true := by decide
def e562308233242 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308233242 : Closed e562308233242 ∧ code e562308233242 = 2761331488794 := by decide
theorem cert_e562308233242 : check e562308233242 [[]] .width = true := by decide
def e562308245530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308245530 : Closed e562308245530 ∧ code e562308245530 = 2761331501082 := by decide
theorem cert_e562308245530 : check e562308245530 [[]] .width = true := by decide
def e562308274202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308274202 : Closed e562308274202 ∧ code e562308274202 = 2761331529754 := by decide
theorem cert_e562308274202 : check e562308274202 [[]] .width = true := by decide
def e562308278298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308278298 : Closed e562308278298 ∧ code e562308278298 = 2761331533850 := by decide
theorem cert_e562308278298 : check e562308278298 [[]] .width = true := by decide
def e562308560922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308560922 : Closed e562308560922 ∧ code e562308560922 = 2761331816474 := by decide
theorem cert_e562308560922 : check e562308560922 [[]] .width = true := by decide
def e562308569114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308569114 : Closed e562308569114 ∧ code e562308569114 = 2761331824666 := by decide
theorem cert_e562308569114 : check e562308569114 [[]] .width = true := by decide
def e562308954138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308954138 : Closed e562308954138 ∧ code e562308954138 = 2761332209690 := by decide
theorem cert_e562308954138 : check e562308954138 [[]] .width = true := by decide
def e562308966426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562308966426 : Closed e562308966426 ∧ code e562308966426 = 2761332221978 := by decide
theorem cert_e562308966426 : check e562308966426 [[]] .width = true := by decide
def e562309158938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562309158938 : Closed e562309158938 ∧ code e562309158938 = 2761332414490 := by decide
theorem cert_e562309158938 : check e562309158938 [[]] .width = true := by decide
def e562309163034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562309163034 : Closed e562309163034 ∧ code e562309163034 = 2761332418586 := by decide
theorem cert_e562309163034 : check e562309163034 [[]] .width = true := by decide
def e562321993070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e562321993070 : Closed e562321993070 ∧ code e562321993070 = 2761345248622 := by decide
theorem cert_e562321993070 : check e562321993070 [[],[.under,.left]] .chain = true := by decide
def e562321993078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e562321993078 : Closed e562321993078 ∧ code e562321993078 = 2761345248630 := by decide
theorem cert_e562321993078 : check e562321993078 [[],[.under,.left]] .chain = true := by decide
def e562321993134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e562321993134 : Closed e562321993134 ∧ code e562321993134 = 2761345248686 := by decide
theorem cert_e562321993134 : check e562321993134 [[],[.under,.left]] .chain = true := by decide
def e562321993146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e562321993146 : Closed e562321993146 ∧ code e562321993146 = 2761345248698 := by decide
theorem cert_e562321993146 : check e562321993146 [[],[.under,.left]] .chain = true := by decide
def e562321993174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e562321993174 : Closed e562321993174 ∧ code e562321993174 = 2761345248726 := by decide
theorem cert_e562321993174 : check e562321993174 [[],[.under,.left]] .chain = true := by decide
def e562321993178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e562321993178 : Closed e562321993178 ∧ code e562321993178 = 2761345248730 := by decide
theorem cert_e562321993178 : check e562321993178 [[],[.under,.left]] .chain = true := by decide
def e562321993390 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e562321993390 : Closed e562321993390 ∧ code e562321993390 = 2761345248942 := by decide
theorem cert_e562321993390 : check e562321993390 [[],[.under,.left]] .chain = true := by decide
def e562321993402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e562321993402 : Closed e562321993402 ∧ code e562321993402 = 2761345248954 := by decide
theorem cert_e562321993402 : check e562321993402 [[],[.under,.left]] .chain = true := by decide
def e562321993450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e562321993450 : Closed e562321993450 ∧ code e562321993450 = 2761345249002 := by decide
theorem cert_e562321993450 : check e562321993450 [[],[.under,.left]] .chain = true := by decide
def e562321993558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e562321993558 : Closed e562321993558 ∧ code e562321993558 = 2761345249110 := by decide
theorem cert_e562321993558 : check e562321993558 [[],[.under,.left]] .chain = true := by decide
def e562321993562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e562321993562 : Closed e562321993562 ∧ code e562321993562 = 2761345249114 := by decide
theorem cert_e562321993562 : check e562321993562 [[],[.under,.left]] .chain = true := by decide
def e562321993578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e562321993578 : Closed e562321993578 ∧ code e562321993578 = 2761345249130 := by decide
theorem cert_e562321993578 : check e562321993578 [[],[.under,.left]] .chain = true := by decide
def e562321994606 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e562321994606 : Closed e562321994606 ∧ code e562321994606 = 2761345250158 := by decide
theorem cert_e562321994606 : check e562321994606 [[],[.under,.left]] .chain = true := by decide
def e562321994614 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e562321994614 : Closed e562321994614 ∧ code e562321994614 = 2761345250166 := by decide
theorem cert_e562321994614 : check e562321994614 [[],[.under,.left]] .chain = true := by decide
def e562321994670 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e562321994670 : Closed e562321994670 ∧ code e562321994670 = 2761345250222 := by decide
theorem cert_e562321994670 : check e562321994670 [[],[.under,.left]] .chain = true := by decide
def e562321994682 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e562321994682 : Closed e562321994682 ∧ code e562321994682 = 2761345250234 := by decide
theorem cert_e562321994682 : check e562321994682 [[],[.under,.left]] .chain = true := by decide
def e562321994710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e562321994710 : Closed e562321994710 ∧ code e562321994710 = 2761345250262 := by decide
theorem cert_e562321994710 : check e562321994710 [[],[.under,.left]] .chain = true := by decide
def e562321994714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e562321994714 : Closed e562321994714 ∧ code e562321994714 = 2761345250266 := by decide
theorem cert_e562321994714 : check e562321994714 [[],[.under,.left]] .chain = true := by decide
def e562321994990 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e562321994990 : Closed e562321994990 ∧ code e562321994990 = 2761345250542 := by decide
theorem cert_e562321994990 : check e562321994990 [[],[.under,.left]] .chain = true := by decide
def e562321994998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e562321994998 : Closed e562321994998 ∧ code e562321994998 = 2761345250550 := by decide
theorem cert_e562321994998 : check e562321994998 [[],[.under,.left]] .chain = true := by decide
def e562321995374 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e562321995374 : Closed e562321995374 ∧ code e562321995374 = 2761345250926 := by decide
theorem cert_e562321995374 : check e562321995374 [[],[.under,.left]] .chain = true := by decide
def e562321995386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e562321995386 : Closed e562321995386 ∧ code e562321995386 = 2761345250938 := by decide
theorem cert_e562321995386 : check e562321995386 [[],[.under,.left]] .chain = true := by decide
def e562321995574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e562321995574 : Closed e562321995574 ∧ code e562321995574 = 2761345251126 := by decide
theorem cert_e562321995574 : check e562321995574 [[],[.under,.left]] .chain = true := by decide
def e562321995578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e562321995578 : Closed e562321995578 ∧ code e562321995578 = 2761345251130 := by decide
theorem cert_e562321995578 : check e562321995578 [[],[.under,.left]] .chain = true := by decide
def e562321996206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e562321996206 : Closed e562321996206 ∧ code e562321996206 = 2761345251758 := by decide
theorem cert_e562321996206 : check e562321996206 [[],[.under,.left]] .chain = true := by decide
def e562321996218 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e562321996218 : Closed e562321996218 ∧ code e562321996218 = 2761345251770 := by decide
theorem cert_e562321996218 : check e562321996218 [[],[.under,.left]] .chain = true := by decide
def e562321996266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e562321996266 : Closed e562321996266 ∧ code e562321996266 = 2761345251818 := by decide
theorem cert_e562321996266 : check e562321996266 [[],[.under,.left]] .chain = true := by decide
def e562321996398 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e562321996398 : Closed e562321996398 ∧ code e562321996398 = 2761345251950 := by decide
theorem cert_e562321996398 : check e562321996398 [[],[.under,.left]] .chain = true := by decide
def e562321996410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e562321996410 : Closed e562321996410 ∧ code e562321996410 = 2761345251962 := by decide
theorem cert_e562321996410 : check e562321996410 [[],[.under,.left]] .chain = true := by decide
def e562321996698 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e562321996698 : Closed e562321996698 ∧ code e562321996698 = 2761345252250 := by decide
theorem cert_e562321996698 : check e562321996698 [[],[.under,.left]] .chain = true := by decide
def e562321997014 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e562321997014 : Closed e562321997014 ∧ code e562321997014 = 2761345252566 := by decide
theorem cert_e562321997014 : check e562321997014 [[],[.under,.left]] .chain = true := by decide
def e562321997018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e562321997018 : Closed e562321997018 ∧ code e562321997018 = 2761345252570 := by decide
theorem cert_e562321997018 : check e562321997018 [[],[.under,.left]] .chain = true := by decide
def e562321997034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e562321997034 : Closed e562321997034 ∧ code e562321997034 = 2761345252586 := by decide
theorem cert_e562321997034 : check e562321997034 [[],[.under,.left]] .chain = true := by decide
def e562321997110 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e562321997110 : Closed e562321997110 ∧ code e562321997110 = 2761345252662 := by decide
theorem cert_e562321997110 : check e562321997110 [[],[.under,.left]] .chain = true := by decide
def e562321997114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e562321997114 : Closed e562321997114 ∧ code e562321997114 = 2761345252666 := by decide
theorem cert_e562321997114 : check e562321997114 [[],[.under,.left]] .chain = true := by decide
def e562321997210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e562321997210 : Closed e562321997210 ∧ code e562321997210 = 2761345252762 := by decide
theorem cert_e562321997210 : check e562321997210 [[],[.under,.left]] .chain = true := by decide
def e562322000750 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562322000750 : Closed e562322000750 ∧ code e562322000750 = 2761345256302 := by decide
theorem cert_e562322000750 : check e562322000750 [[],[.under,.left]] .chain = true := by decide
def e562322000758 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562322000758 : Closed e562322000758 ∧ code e562322000758 = 2761345256310 := by decide
theorem cert_e562322000758 : check e562322000758 [[],[.under,.left]] .chain = true := by decide
def e562322000814 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562322000814 : Closed e562322000814 ∧ code e562322000814 = 2761345256366 := by decide
theorem cert_e562322000814 : check e562322000814 [[],[.under,.left]] .chain = true := by decide
def e562322000826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562322000826 : Closed e562322000826 ∧ code e562322000826 = 2761345256378 := by decide
theorem cert_e562322000826 : check e562322000826 [[],[.under,.left]] .chain = true := by decide
def e562322000854 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562322000854 : Closed e562322000854 ∧ code e562322000854 = 2761345256406 := by decide
theorem cert_e562322000854 : check e562322000854 [[],[.under,.left]] .chain = true := by decide
def e562322000858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562322000858 : Closed e562322000858 ∧ code e562322000858 = 2761345256410 := by decide
theorem cert_e562322000858 : check e562322000858 [[],[.under,.left]] .chain = true := by decide
def e562322001134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562322001134 : Closed e562322001134 ∧ code e562322001134 = 2761345256686 := by decide
theorem cert_e562322001134 : check e562322001134 [[],[.under,.left]] .chain = true := by decide
def e562322001142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562322001142 : Closed e562322001142 ∧ code e562322001142 = 2761345256694 := by decide
theorem cert_e562322001142 : check e562322001142 [[],[.under,.left]] .chain = true := by decide
def e562322001518 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562322001518 : Closed e562322001518 ∧ code e562322001518 = 2761345257070 := by decide
theorem cert_e562322001518 : check e562322001518 [[],[.under,.left]] .chain = true := by decide
def e562322001530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562322001530 : Closed e562322001530 ∧ code e562322001530 = 2761345257082 := by decide
theorem cert_e562322001530 : check e562322001530 [[],[.under,.left]] .chain = true := by decide
def e562322001718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562322001718 : Closed e562322001718 ∧ code e562322001718 = 2761345257270 := by decide
theorem cert_e562322001718 : check e562322001718 [[],[.under,.left]] .chain = true := by decide
def e562322001722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562322001722 : Closed e562322001722 ∧ code e562322001722 = 2761345257274 := by decide
theorem cert_e562322001722 : check e562322001722 [[],[.under,.left]] .chain = true := by decide
def e562322007470 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e562322007470 : Closed e562322007470 ∧ code e562322007470 = 2761345263022 := by decide
theorem cert_e562322007470 : check e562322007470 [[],[.under,.left]] .chain = true := by decide
def e562322007482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e562322007482 : Closed e562322007482 ∧ code e562322007482 = 2761345263034 := by decide
theorem cert_e562322007482 : check e562322007482 [[],[.under,.left]] .chain = true := by decide
def e562322007530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e562322007530 : Closed e562322007530 ∧ code e562322007530 = 2761345263082 := by decide
theorem cert_e562322007530 : check e562322007530 [[],[.under,.left]] .chain = true := by decide
def e562322007662 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e562322007662 : Closed e562322007662 ∧ code e562322007662 = 2761345263214 := by decide
theorem cert_e562322007662 : check e562322007662 [[],[.under,.left]] .chain = true := by decide
def e562322007674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e562322007674 : Closed e562322007674 ∧ code e562322007674 = 2761345263226 := by decide
theorem cert_e562322007674 : check e562322007674 [[],[.under,.left]] .chain = true := by decide
def e562322007962 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e562322007962 : Closed e562322007962 ∧ code e562322007962 = 2761345263514 := by decide
theorem cert_e562322007962 : check e562322007962 [[],[.under,.left]] .chain = true := by decide
def e562322010838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e562322010838 : Closed e562322010838 ∧ code e562322010838 = 2761345266390 := by decide
theorem cert_e562322010838 : check e562322010838 [[],[.under,.left]] .chain = true := by decide
def e562322010842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e562322010842 : Closed e562322010842 ∧ code e562322010842 = 2761345266394 := by decide
theorem cert_e562322010842 : check e562322010842 [[],[.under,.left]] .chain = true := by decide
def e562322010858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e562322010858 : Closed e562322010858 ∧ code e562322010858 = 2761345266410 := by decide
theorem cert_e562322010858 : check e562322010858 [[],[.under,.left]] .chain = true := by decide
def e562322010934 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e562322010934 : Closed e562322010934 ∧ code e562322010934 = 2761345266486 := by decide
theorem cert_e562322010934 : check e562322010934 [[],[.under,.left]] .chain = true := by decide
def e562322010938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e562322010938 : Closed e562322010938 ∧ code e562322010938 = 2761345266490 := by decide
theorem cert_e562322010938 : check e562322010938 [[],[.under,.left]] .chain = true := by decide
def e562322011034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e562322011034 : Closed e562322011034 ∧ code e562322011034 = 2761345266586 := by decide
theorem cert_e562322011034 : check e562322011034 [[],[.under,.left]] .chain = true := by decide
def e562322148206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562322148206 : Closed e562322148206 ∧ code e562322148206 = 2761345403758 := by decide
theorem cert_e562322148206 : check e562322148206 [[],[.under,.left]] .chain = true := by decide
def e562322148214 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562322148214 : Closed e562322148214 ∧ code e562322148214 = 2761345403766 := by decide
theorem cert_e562322148214 : check e562322148214 [[],[.under,.left]] .chain = true := by decide
def e562322148270 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562322148270 : Closed e562322148270 ∧ code e562322148270 = 2761345403822 := by decide
theorem cert_e562322148270 : check e562322148270 [[],[.under,.left]] .chain = true := by decide
def e562322148282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562322148282 : Closed e562322148282 ∧ code e562322148282 = 2761345403834 := by decide
theorem cert_e562322148282 : check e562322148282 [[],[.under,.left]] .chain = true := by decide
end Blc.Floor41
