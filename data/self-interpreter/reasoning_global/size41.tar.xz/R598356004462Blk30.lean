import R598356004462Data
namespace Certgen.R598356004462
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl360 : FloorIndex.rangeOK validState 360 12 = true := by decide +kernel
theorem bl372 : FloorIndex.rangeOK validState 372 12 = true := by decide +kernel
theorem bl384 : FloorIndex.rangeOK validState 384 9 = true := by decide +kernel
end Certgen.R598356004462
