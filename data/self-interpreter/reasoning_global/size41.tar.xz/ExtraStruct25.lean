import Extra41
import Batch143
import Batch144
import Batch145
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605792433066
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private def u14 := Term.app u13 u2
theorem nege605792433066 : ¬ IsSelfInterpreter e605792433066 := by
  intro he
  have h : replay [] (.app e605792433066 diag) = some u14 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u14) (by decide) (by decide) hj
#print axioms nege605792433066
end Witness605792433066
namespace Witness605792476282
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 3
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u3 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.lam u3
private def u15 := Term.var 2
private def u16 := Term.app u3 u15
private def u17 := Term.app u3 u16
private def u18 := Term.app u17 u0
private def u19 := Term.lam u18
private def u20 := Term.lam u15
private def u21 := Term.app u0 u20
private def u22 := Term.app u0 u21
private def u23 := Term.app u3 u0
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 3
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou3 sou5
private theorem sou7 : SO u7 := SO.app sou3 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou15 : SO u15 := SO.var 2
private theorem sou20 : SO u20 := so_dead (by decide) sou15
private theorem sou21 : SO u21 := SO.app sou0 sou20
private theorem sou22 : SO u22 := SO.app sou0 sou21
private theorem sou9 : SO u9 := SO.lam (r := u22) (g := u23) sou8 sou22 (by decide) (by decide)
private theorem sou14 : SO u14 := so_dead (by decide) sou3
private theorem sou10 : SO u10 := SO.lam (r := u14) (g := u19) sou9 sou14 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605792476282 : ¬ IsSelfInterpreter e605792476282 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605792476282
end Witness605792476282
namespace Witness605792476730
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u4
private def u6 := Term.app u4 u5
private def u7 := Term.app u3 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.lam u3
private def u15 := Term.app u3 u14
private def u16 := Term.app u0 u15
private def u17 := Term.app u3 u0
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou3 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou14 : SO u14 := so_dead (by decide) sou3
private theorem sou15 : SO u15 := SO.app sou3 sou14
private theorem sou16 : SO u16 := SO.app sou0 sou15
private theorem sou9 : SO u9 := SO.lam (r := u16) (g := u17) sou8 sou16 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605792476730 : ¬ IsSelfInterpreter e605792476730 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605792476730
end Witness605792476730
namespace Witness605792489018
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.lam u3
private def u6 := Term.app u4 u5
private def u7 := Term.app u3 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.lam u4
private def u15 := Term.app u0 u14
private def u16 := Term.app u4 u15
private def u17 := Term.app u4 u0
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := so_dead (by decide) sou3
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou3 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou14 : SO u14 := so_dead (by decide) sou4
private theorem sou15 : SO u15 := SO.app sou0 sou14
private theorem sou16 : SO u16 := SO.app sou4 sou15
private theorem sou9 : SO u9 := SO.lam (r := u16) (g := u17) sou8 sou16 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605792489018 : ¬ IsSelfInterpreter e605792489018 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605792489018
end Witness605792489018
namespace Witness605792489066
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u4 u1
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private def u13 := Term.app u12 u2
theorem nege605792489066 : ¬ IsSelfInterpreter e605792489066 := by
  intro he
  have h : replay [] (.app e605792489066 diag) = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605792489066
end Witness605792489066
namespace Witness605792489114
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u1
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private def u13 := Term.app u12 u2
theorem nege605792489114 : ¬ IsSelfInterpreter e605792489114 := by
  intro he
  have h : replay [] (.app e605792489114 diag) = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605792489114
end Witness605792489114
namespace Witness605792710250
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.app u1 u1
private def u3 := Term.app u0 u2
private def u4 := Term.app u3 u1
private def u5 := Term.lam u4
private def u6 := Term.lam u5
private theorem sou0 : SO u0 := SO.var 1
private theorem sou1 : SO u1 := SO.var 0
private theorem sou2 : SO u2 := SO.app sou1 sou1
private theorem sou3 : SO u3 := SO.app sou0 sou2
private theorem sou4 : SO u4 := SO.app sou3 sou1
private theorem sou5 : SO u5 := SO.lam (r := u1) (g := u4) sou4 sou1 (by decide) (by decide)
private theorem sou6 : SO u6 := so_closed_lam (by decide) sou5
theorem nege605792710250 : ¬ IsSelfInterpreter e605792710250 := by
  exact kSO [[.left],[.left],[.left],[.left],[.left,.under,.right,.left],[.left,.under,.right],[.left,.under,.right],[],[.right,.under,.right,.left,.left,.left,.left],[.right,.under,.right,.left,.left,.left],[.right,.under,.right,.left,.left],[.right,.under,.right,.left],[.right,.under,.right],[],[],[.right,.under,.under,.under],[],[],[.under,.under],[.under,.under]] (t := u6) (by decide) sou6
#print axioms nege605792710250
end Witness605792710250
namespace Witness605792713114
private def u0 := Term.var 1
private def u1 := Term.lam u0
private def u2 := Term.lam u1
private def u3 := Term.var 0
private def u4 := Term.app u3 u3
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u2 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u2 u9
private def u11 := Term.lam u10
private theorem sou0 : SO u0 := SO.var 1
private theorem sou1 : SO u1 := so_dead (by decide) sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private theorem sou3 : SO u3 := SO.var 0
private theorem sou4 : SO u4 := SO.app sou3 sou3
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou7 : SO u7 := SO.app sou2 sou6
private theorem sou8 : SO u8 := SO.lam (r := u3) (g := u7) sou7 sou3 (by decide) (by decide)
private theorem sou9 : SO u9 := so_closed_lam (by decide) sou8
private theorem sou10 : SO u10 := SO.app sou2 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
theorem nege605792713114 : ¬ IsSelfInterpreter e605792713114 := by
  exact kSO [[.left],[.left],[.left],[.left],[.left,.under,.right],[.left,.under,.right,.under],[],[.right,.under,.under,.right,.left,.left],[.right,.under,.under,.right,.left],[.right,.under,.under,.right,.left],[.right,.under,.under,.right],[],[],[.under]] (t := u11) (by decide) sou11
#print axioms nege605792713114
end Witness605792713114
end Blc.Floor41
