import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602189278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e605602189278 : Closed e605602189278 ∧ code e605602189278 = 2804625444830 := by decide
theorem cert_e605602189278 : check e605602189278 [[],[]] .chain = true := by decide
def e605602196958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e605602196958 : Closed e605602196958 ∧ code e605602196958 = 2804625452510 := by decide
theorem cert_e605602196958 : check e605602196958 [[],[]] .chain = true := by decide
def e605602196974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e605602196974 : Closed e605602196974 ∧ code e605602196974 = 2804625452526 := by decide
theorem cert_e605602196974 : check e605602196974 [[],[]] .chain = true := by decide
def e605602197342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e605602197342 : Closed e605602197342 ∧ code e605602197342 = 2804625452894 := by decide
theorem cert_e605602197342 : check e605602197342 [[],[]] .chain = true := by decide
def e605602197370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e605602197370 : Closed e605602197370 ∧ code e605602197370 = 2804625452922 := by decide
theorem cert_e605602197370 : check e605602197370 [[],[]] .chain = true := by decide
def e605602197422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e605602197422 : Closed e605602197422 ∧ code e605602197422 = 2804625452974 := by decide
theorem cert_e605602197422 : check e605602197422 [[],[]] .chain = true := by decide
def e605602197434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e605602197434 : Closed e605602197434 ∧ code e605602197434 = 2804625452986 := by decide
theorem cert_e605602197434 : check e605602197434 [[],[]] .chain = true := by decide
def e605602198494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e605602198494 : Closed e605602198494 ∧ code e605602198494 = 2804625454046 := by decide
theorem cert_e605602198494 : check e605602198494 [[],[]] .chain = true := by decide
def e605602198510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e605602198510 : Closed e605602198510 ∧ code e605602198510 = 2804625454062 := by decide
theorem cert_e605602198510 : check e605602198510 [[],[]] .chain = true := by decide
def e605602200798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e605602200798 : Closed e605602200798 ∧ code e605602200798 = 2804625456350 := by decide
theorem cert_e605602200798 : check e605602200798 [[],[]] .chain = true := by decide
def e605602200826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e605602200826 : Closed e605602200826 ∧ code e605602200826 = 2804625456378 := by decide
theorem cert_e605602200826 : check e605602200826 [[],[]] .chain = true := by decide
def e605602201198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602201198 : Closed e605602201198 ∧ code e605602201198 = 2804625456750 := by decide
theorem cert_e605602201198 : check e605602201198 [[],[]] .chain = true := by decide
def e605602201210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602201210 : Closed e605602201210 ∧ code e605602201210 = 2804625456762 := by decide
theorem cert_e605602201210 : check e605602201210 [[],[]] .chain = true := by decide
def e605602229614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605602229614 : Closed e605602229614 ∧ code e605602229614 = 2804625485166 := by decide
theorem cert_e605602229614 : check e605602229614 [[],[]] .chain = true := by decide
def e605602229622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605602229622 : Closed e605602229622 ∧ code e605602229622 = 2804625485174 := by decide
theorem cert_e605602229622 : check e605602229622 [[],[]] .chain = true := by decide
def e605602229678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605602229678 : Closed e605602229678 ∧ code e605602229678 = 2804625485230 := by decide
theorem cert_e605602229678 : check e605602229678 [[],[]] .chain = true := by decide
def e605602229690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605602229690 : Closed e605602229690 ∧ code e605602229690 = 2804625485242 := by decide
theorem cert_e605602229690 : check e605602229690 [[],[]] .chain = true := by decide
def e605602229718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605602229718 : Closed e605602229718 ∧ code e605602229718 = 2804625485270 := by decide
theorem cert_e605602229718 : check e605602229718 [[],[]] .chain = true := by decide
def e605602229722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605602229722 : Closed e605602229722 ∧ code e605602229722 = 2804625485274 := by decide
theorem cert_e605602229722 : check e605602229722 [[],[]] .chain = true := by decide
def e605602229934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605602229934 : Closed e605602229934 ∧ code e605602229934 = 2804625485486 := by decide
theorem cert_e605602229934 : check e605602229934 [[],[]] .chain = true := by decide
def e605602229946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605602229946 : Closed e605602229946 ∧ code e605602229946 = 2804625485498 := by decide
theorem cert_e605602229946 : check e605602229946 [[],[]] .chain = true := by decide
def e605602229994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605602229994 : Closed e605602229994 ∧ code e605602229994 = 2804625485546 := by decide
theorem cert_e605602229994 : check e605602229994 [[],[]] .chain = true := by decide
def e605602230102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605602230102 : Closed e605602230102 ∧ code e605602230102 = 2804625485654 := by decide
theorem cert_e605602230102 : check e605602230102 [[],[]] .chain = true := by decide
def e605602230106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605602230106 : Closed e605602230106 ∧ code e605602230106 = 2804625485658 := by decide
theorem cert_e605602230106 : check e605602230106 [[],[]] .chain = true := by decide
def e605602230122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605602230122 : Closed e605602230122 ∧ code e605602230122 = 2804625485674 := by decide
theorem cert_e605602230122 : check e605602230122 [[],[]] .chain = true := by decide
def e605602231150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605602231150 : Closed e605602231150 ∧ code e605602231150 = 2804625486702 := by decide
theorem cert_e605602231150 : check e605602231150 [[],[]] .chain = true := by decide
def e605602231158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605602231158 : Closed e605602231158 ∧ code e605602231158 = 2804625486710 := by decide
theorem cert_e605602231158 : check e605602231158 [[],[]] .chain = true := by decide
def e605602231214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605602231214 : Closed e605602231214 ∧ code e605602231214 = 2804625486766 := by decide
theorem cert_e605602231214 : check e605602231214 [[],[]] .chain = true := by decide
def e605602231226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605602231226 : Closed e605602231226 ∧ code e605602231226 = 2804625486778 := by decide
theorem cert_e605602231226 : check e605602231226 [[],[]] .chain = true := by decide
def e605602231254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605602231254 : Closed e605602231254 ∧ code e605602231254 = 2804625486806 := by decide
theorem cert_e605602231254 : check e605602231254 [[],[]] .chain = true := by decide
def e605602231258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605602231258 : Closed e605602231258 ∧ code e605602231258 = 2804625486810 := by decide
theorem cert_e605602231258 : check e605602231258 [[],[]] .chain = true := by decide
def e605602231534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605602231534 : Closed e605602231534 ∧ code e605602231534 = 2804625487086 := by decide
theorem cert_e605602231534 : check e605602231534 [[],[]] .chain = true := by decide
def e605602231542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605602231542 : Closed e605602231542 ∧ code e605602231542 = 2804625487094 := by decide
theorem cert_e605602231542 : check e605602231542 [[],[]] .chain = true := by decide
def e605602231918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605602231918 : Closed e605602231918 ∧ code e605602231918 = 2804625487470 := by decide
theorem cert_e605602231918 : check e605602231918 [[],[]] .chain = true := by decide
def e605602231930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605602231930 : Closed e605602231930 ∧ code e605602231930 = 2804625487482 := by decide
theorem cert_e605602231930 : check e605602231930 [[],[]] .chain = true := by decide
def e605602232118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605602232118 : Closed e605602232118 ∧ code e605602232118 = 2804625487670 := by decide
theorem cert_e605602232118 : check e605602232118 [[],[]] .chain = true := by decide
def e605602232122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605602232122 : Closed e605602232122 ∧ code e605602232122 = 2804625487674 := by decide
theorem cert_e605602232122 : check e605602232122 [[],[]] .chain = true := by decide
def e605602232366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605602232366 : Closed e605602232366 ∧ code e605602232366 = 2804625487918 := by decide
theorem cert_e605602232366 : check e605602232366 [[],[]] .chain = true := by decide
def e605602232558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605602232558 : Closed e605602232558 ∧ code e605602232558 = 2804625488110 := by decide
theorem cert_e605602232558 : check e605602232558 [[],[]] .chain = true := by decide
def e605602232566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605602232566 : Closed e605602232566 ∧ code e605602232566 = 2804625488118 := by decide
theorem cert_e605602232566 : check e605602232566 [[],[]] .chain = true := by decide
def e605602232750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605602232750 : Closed e605602232750 ∧ code e605602232750 = 2804625488302 := by decide
theorem cert_e605602232750 : check e605602232750 [[],[]] .chain = true := by decide
def e605602232762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605602232762 : Closed e605602232762 ∧ code e605602232762 = 2804625488314 := by decide
theorem cert_e605602232762 : check e605602232762 [[],[]] .chain = true := by decide
def e605602232810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605602232810 : Closed e605602232810 ∧ code e605602232810 = 2804625488362 := by decide
theorem cert_e605602232810 : check e605602232810 [[],[]] .chain = true := by decide
def e605602232942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605602232942 : Closed e605602232942 ∧ code e605602232942 = 2804625488494 := by decide
theorem cert_e605602232942 : check e605602232942 [[],[]] .chain = true := by decide
def e605602232954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605602232954 : Closed e605602232954 ∧ code e605602232954 = 2804625488506 := by decide
theorem cert_e605602232954 : check e605602232954 [[],[]] .chain = true := by decide
def e605602233118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605602233118 : Closed e605602233118 ∧ code e605602233118 = 2804625488670 := by decide
theorem cert_e605602233118 : check e605602233118 [[],[]] .chain = true := by decide
def e605602233218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602233218 : Closed e605602233218 ∧ code e605602233218 = 2804625488770 := by decide
theorem cert_e605602233218 : check e605602233218 [[],[]] .chain = true := by decide
def e605602233230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605602233230 : Closed e605602233230 ∧ code e605602233230 = 2804625488782 := by decide
theorem cert_e605602233230 : check e605602233230 [[],[]] .chain = true := by decide
def e605602233242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602233242 : Closed e605602233242 ∧ code e605602233242 = 2804625488794 := by decide
theorem cert_e605602233242 : check e605602233242 [[],[]] .chain = true := by decide
def e605602233366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605602233366 : Closed e605602233366 ∧ code e605602233366 = 2804625488918 := by decide
theorem cert_e605602233366 : check e605602233366 [[],[]] .chain = true := by decide
def e605602233462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605602233462 : Closed e605602233462 ∧ code e605602233462 = 2804625489014 := by decide
theorem cert_e605602233462 : check e605602233462 [[],[]] .chain = true := by decide
def e605602233558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605602233558 : Closed e605602233558 ∧ code e605602233558 = 2804625489110 := by decide
theorem cert_e605602233558 : check e605602233558 [[],[]] .chain = true := by decide
def e605602233562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605602233562 : Closed e605602233562 ∧ code e605602233562 = 2804625489114 := by decide
theorem cert_e605602233562 : check e605602233562 [[],[]] .chain = true := by decide
def e605602233578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605602233578 : Closed e605602233578 ∧ code e605602233578 = 2804625489130 := by decide
theorem cert_e605602233578 : check e605602233578 [[],[]] .chain = true := by decide
def e605602233654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605602233654 : Closed e605602233654 ∧ code e605602233654 = 2804625489206 := by decide
theorem cert_e605602233654 : check e605602233654 [[],[]] .chain = true := by decide
def e605602233658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605602233658 : Closed e605602233658 ∧ code e605602233658 = 2804625489210 := by decide
theorem cert_e605602233658 : check e605602233658 [[],[]] .chain = true := by decide
def e605602233730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602233730 : Closed e605602233730 ∧ code e605602233730 = 2804625489282 := by decide
theorem cert_e605602233730 : check e605602233730 [[],[]] .chain = true := by decide
def e605602233742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605602233742 : Closed e605602233742 ∧ code e605602233742 = 2804625489294 := by decide
theorem cert_e605602233742 : check e605602233742 [[],[]] .chain = true := by decide
def e605602233754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602233754 : Closed e605602233754 ∧ code e605602233754 = 2804625489306 := by decide
theorem cert_e605602233754 : check e605602233754 [[],[]] .chain = true := by decide
def e605602235358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605602235358 : Closed e605602235358 ∧ code e605602235358 = 2804625490910 := by decide
theorem cert_e605602235358 : check e605602235358 [[],[]] .chain = true := by decide
def e605602235374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605602235374 : Closed e605602235374 ∧ code e605602235374 = 2804625490926 := by decide
theorem cert_e605602235374 : check e605602235374 [[],[]] .chain = true := by decide
def e605602237294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605602237294 : Closed e605602237294 ∧ code e605602237294 = 2804625492846 := by decide
theorem cert_e605602237294 : check e605602237294 [[],[]] .chain = true := by decide
def e605602237302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605602237302 : Closed e605602237302 ∧ code e605602237302 = 2804625492854 := by decide
theorem cert_e605602237302 : check e605602237302 [[],[]] .chain = true := by decide
def e605602237358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605602237358 : Closed e605602237358 ∧ code e605602237358 = 2804625492910 := by decide
theorem cert_e605602237358 : check e605602237358 [[],[]] .chain = true := by decide
def e605602237370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605602237370 : Closed e605602237370 ∧ code e605602237370 = 2804625492922 := by decide
theorem cert_e605602237370 : check e605602237370 [[],[]] .chain = true := by decide
def e605602237398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605602237398 : Closed e605602237398 ∧ code e605602237398 = 2804625492950 := by decide
theorem cert_e605602237398 : check e605602237398 [[],[]] .chain = true := by decide
def e605602237402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605602237402 : Closed e605602237402 ∧ code e605602237402 = 2804625492954 := by decide
theorem cert_e605602237402 : check e605602237402 [[],[]] .chain = true := by decide
def e605602237678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602237678 : Closed e605602237678 ∧ code e605602237678 = 2804625493230 := by decide
theorem cert_e605602237678 : check e605602237678 [[],[]] .chain = true := by decide
def e605602237686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602237686 : Closed e605602237686 ∧ code e605602237686 = 2804625493238 := by decide
theorem cert_e605602237686 : check e605602237686 [[],[]] .chain = true := by decide
def e605602238062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602238062 : Closed e605602238062 ∧ code e605602238062 = 2804625493614 := by decide
theorem cert_e605602238062 : check e605602238062 [[],[]] .chain = true := by decide
def e605602238074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602238074 : Closed e605602238074 ∧ code e605602238074 = 2804625493626 := by decide
theorem cert_e605602238074 : check e605602238074 [[],[]] .chain = true := by decide
def e605602238262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602238262 : Closed e605602238262 ∧ code e605602238262 = 2804625493814 := by decide
theorem cert_e605602238262 : check e605602238262 [[],[]] .chain = true := by decide
def e605602238266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602238266 : Closed e605602238266 ∧ code e605602238266 = 2804625493818 := by decide
theorem cert_e605602238266 : check e605602238266 [[],[]] .chain = true := by decide
def e605602243038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605602243038 : Closed e605602243038 ∧ code e605602243038 = 2804625498590 := by decide
theorem cert_e605602243038 : check e605602243038 [[],[]] .chain = true := by decide
def e605602243062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605602243062 : Closed e605602243062 ∧ code e605602243062 = 2804625498614 := by decide
theorem cert_e605602243062 : check e605602243062 [[],[]] .chain = true := by decide
def e605602244014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605602244014 : Closed e605602244014 ∧ code e605602244014 = 2804625499566 := by decide
theorem cert_e605602244014 : check e605602244014 [[],[]] .chain = true := by decide
def e605602244026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605602244026 : Closed e605602244026 ∧ code e605602244026 = 2804625499578 := by decide
theorem cert_e605602244026 : check e605602244026 [[],[]] .chain = true := by decide
def e605602244074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605602244074 : Closed e605602244074 ∧ code e605602244074 = 2804625499626 := by decide
theorem cert_e605602244074 : check e605602244074 [[],[]] .chain = true := by decide
def e605602244206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602244206 : Closed e605602244206 ∧ code e605602244206 = 2804625499758 := by decide
theorem cert_e605602244206 : check e605602244206 [[],[]] .chain = true := by decide
def e605602244218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602244218 : Closed e605602244218 ∧ code e605602244218 = 2804625499770 := by decide
theorem cert_e605602244218 : check e605602244218 [[],[]] .chain = true := by decide
def e605602244382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605602244382 : Closed e605602244382 ∧ code e605602244382 = 2804625499934 := by decide
theorem cert_e605602244382 : check e605602244382 [[],[]] .chain = true := by decide
def e605602244482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605602244482 : Closed e605602244482 ∧ code e605602244482 = 2804625500034 := by decide
theorem cert_e605602244482 : check e605602244482 [[],[]] .chain = true := by decide
def e605602244494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605602244494 : Closed e605602244494 ∧ code e605602244494 = 2804625500046 := by decide
theorem cert_e605602244494 : check e605602244494 [[],[]] .chain = true := by decide
def e605602244506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602244506 : Closed e605602244506 ∧ code e605602244506 = 2804625500058 := by decide
theorem cert_e605602244506 : check e605602244506 [[],[]] .chain = true := by decide
def e605602246894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605602246894 : Closed e605602246894 ∧ code e605602246894 = 2804625502446 := by decide
theorem cert_e605602246894 : check e605602246894 [[],[]] .chain = true := by decide
def e605602246902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605602246902 : Closed e605602246902 ∧ code e605602246902 = 2804625502454 := by decide
theorem cert_e605602246902 : check e605602246902 [[],[]] .chain = true := by decide
def e605602247382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605602247382 : Closed e605602247382 ∧ code e605602247382 = 2804625502934 := by decide
theorem cert_e605602247382 : check e605602247382 [[],[]] .chain = true := by decide
def e605602247386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605602247386 : Closed e605602247386 ∧ code e605602247386 = 2804625502938 := by decide
theorem cert_e605602247386 : check e605602247386 [[],[]] .chain = true := by decide
def e605602247402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605602247402 : Closed e605602247402 ∧ code e605602247402 = 2804625502954 := by decide
theorem cert_e605602247402 : check e605602247402 [[],[]] .chain = true := by decide
def e605602247478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602247478 : Closed e605602247478 ∧ code e605602247478 = 2804625503030 := by decide
theorem cert_e605602247478 : check e605602247478 [[],[]] .chain = true := by decide
def e605602247482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602247482 : Closed e605602247482 ∧ code e605602247482 = 2804625503034 := by decide
theorem cert_e605602247482 : check e605602247482 [[],[]] .chain = true := by decide
def e605602247554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605602247554 : Closed e605602247554 ∧ code e605602247554 = 2804625503106 := by decide
theorem cert_e605602247554 : check e605602247554 [[],[]] .chain = true := by decide
def e605602247566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605602247566 : Closed e605602247566 ∧ code e605602247566 = 2804625503118 := by decide
theorem cert_e605602247566 : check e605602247566 [[],[]] .chain = true := by decide
def e605602247578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602247578 : Closed e605602247578 ∧ code e605602247578 = 2804625503130 := by decide
theorem cert_e605602247578 : check e605602247578 [[],[]] .chain = true := by decide
def e605602318270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e605602318270 : Closed e605602318270 ∧ code e605602318270 = 2804625573822 := by decide
theorem cert_e605602318270 : check e605602318270 [[],[]] .chain = true := by decide
def e605602318318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e605602318318 : Closed e605602318318 ∧ code e605602318318 = 2804625573870 := by decide
theorem cert_e605602318318 : check e605602318318 [[],[]] .chain = true := by decide
def e605602322142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605602322142 : Closed e605602322142 ∧ code e605602322142 = 2804625577694 := by decide
theorem cert_e605602322142 : check e605602322142 [[],[]] .chain = true := by decide
def e605602322166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605602322166 : Closed e605602322166 ∧ code e605602322166 = 2804625577718 := by decide
theorem cert_e605602322166 : check e605602322166 [[],[]] .chain = true := by decide
def e605602322270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605602322270 : Closed e605602322270 ∧ code e605602322270 = 2804625577822 := by decide
theorem cert_e605602322270 : check e605602322270 [[],[]] .chain = true := by decide
def e605602322298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605602322298 : Closed e605602322298 ∧ code e605602322298 = 2804625577850 := by decide
theorem cert_e605602322298 : check e605602322298 [[],[]] .chain = true := by decide
def e605602322390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605602322390 : Closed e605602322390 ∧ code e605602322390 = 2804625577942 := by decide
theorem cert_e605602322390 : check e605602322390 [[],[]] .chain = true := by decide
def e605602322394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605602322394 : Closed e605602322394 ∧ code e605602322394 = 2804625577946 := by decide
theorem cert_e605602322394 : check e605602322394 [[],[]] .chain = true := by decide
def e605602322910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602322910 : Closed e605602322910 ∧ code e605602322910 = 2804625578462 := by decide
theorem cert_e605602322910 : check e605602322910 [[],[]] .chain = true := by decide
def e605602322934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602322934 : Closed e605602322934 ∧ code e605602322934 = 2804625578486 := by decide
theorem cert_e605602322934 : check e605602322934 [[],[]] .chain = true := by decide
def e605602323678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605602323678 : Closed e605602323678 ∧ code e605602323678 = 2804625579230 := by decide
theorem cert_e605602323678 : check e605602323678 [[],[]] .chain = true := by decide
def e605602323706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605602323706 : Closed e605602323706 ∧ code e605602323706 = 2804625579258 := by decide
theorem cert_e605602323706 : check e605602323706 [[],[]] .chain = true := by decide
def e605602324030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e605602324030 : Closed e605602324030 ∧ code e605602324030 = 2804625579582 := by decide
theorem cert_e605602324030 : check e605602324030 [[],[]] .chain = true := by decide
def e605602324254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e605602324254 : Closed e605602324254 ∧ code e605602324254 = 2804625579806 := by decide
theorem cert_e605602324254 : check e605602324254 [[],[]] .chain = true := by decide
def e605602324278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602324278 : Closed e605602324278 ∧ code e605602324278 = 2804625579830 := by decide
theorem cert_e605602324278 : check e605602324278 [[],[]] .chain = true := by decide
def e605602324282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602324282 : Closed e605602324282 ∧ code e605602324282 = 2804625579834 := by decide
theorem cert_e605602324282 : check e605602324282 [[],[]] .chain = true := by decide
def e605602338478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605602338478 : Closed e605602338478 ∧ code e605602338478 = 2804625594030 := by decide
theorem cert_e605602338478 : check e605602338478 [[],[]] .chain = true := by decide
def e605602338490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605602338490 : Closed e605602338490 ∧ code e605602338490 = 2804625594042 := by decide
theorem cert_e605602338490 : check e605602338490 [[],[]] .chain = true := by decide
def e605602338538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605602338538 : Closed e605602338538 ∧ code e605602338538 = 2804625594090 := by decide
theorem cert_e605602338538 : check e605602338538 [[],[]] .chain = true := by decide
def e605602338730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605602338730 : Closed e605602338730 ∧ code e605602338730 = 2804625594282 := by decide
theorem cert_e605602338730 : check e605602338730 [[],[]] .chain = true := by decide
def e605602338862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605602338862 : Closed e605602338862 ∧ code e605602338862 = 2804625594414 := by decide
theorem cert_e605602338862 : check e605602338862 [[],[]] .chain = true := by decide
def e605602339054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605602339054 : Closed e605602339054 ∧ code e605602339054 = 2804625594606 := by decide
theorem cert_e605602339054 : check e605602339054 [[],[]] .chain = true := by decide
def e605602339062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605602339062 : Closed e605602339062 ∧ code e605602339062 = 2804625594614 := by decide
theorem cert_e605602339062 : check e605602339062 [[],[]] .chain = true := by decide
def e605602339246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605602339246 : Closed e605602339246 ∧ code e605602339246 = 2804625594798 := by decide
theorem cert_e605602339246 : check e605602339246 [[],[]] .chain = true := by decide
def e605602339258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605602339258 : Closed e605602339258 ∧ code e605602339258 = 2804625594810 := by decide
theorem cert_e605602339258 : check e605602339258 [[],[]] .chain = true := by decide
def e605602339306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605602339306 : Closed e605602339306 ∧ code e605602339306 = 2804625594858 := by decide
theorem cert_e605602339306 : check e605602339306 [[],[]] .chain = true := by decide
def e605602339438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605602339438 : Closed e605602339438 ∧ code e605602339438 = 2804625594990 := by decide
theorem cert_e605602339438 : check e605602339438 [[],[]] .chain = true := by decide
def e605602339450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605602339450 : Closed e605602339450 ∧ code e605602339450 = 2804625595002 := by decide
theorem cert_e605602339450 : check e605602339450 [[],[]] .chain = true := by decide
def e605602339614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605602339614 : Closed e605602339614 ∧ code e605602339614 = 2804625595166 := by decide
theorem cert_e605602339614 : check e605602339614 [[],[]] .chain = true := by decide
def e605602339714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602339714 : Closed e605602339714 ∧ code e605602339714 = 2804625595266 := by decide
theorem cert_e605602339714 : check e605602339714 [[],[]] .chain = true := by decide
def e605602339726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605602339726 : Closed e605602339726 ∧ code e605602339726 = 2804625595278 := by decide
theorem cert_e605602339726 : check e605602339726 [[],[]] .chain = true := by decide
def e605602339738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602339738 : Closed e605602339738 ∧ code e605602339738 = 2804625595290 := by decide
theorem cert_e605602339738 : check e605602339738 [[],[]] .chain = true := by decide
def e605602339950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605602339950 : Closed e605602339950 ∧ code e605602339950 = 2804625595502 := by decide
theorem cert_e605602339950 : check e605602339950 [[],[]] .chain = true := by decide
def e605602339962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605602339962 : Closed e605602339962 ∧ code e605602339962 = 2804625595514 := by decide
theorem cert_e605602339962 : check e605602339962 [[],[]] .chain = true := by decide
def e605602340126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605602340126 : Closed e605602340126 ∧ code e605602340126 = 2804625595678 := by decide
theorem cert_e605602340126 : check e605602340126 [[],[]] .chain = true := by decide
def e605602340294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605602340294 : Closed e605602340294 ∧ code e605602340294 = 2804625595846 := by decide
theorem cert_e605602340294 : check e605602340294 [[],[]] .chain = true := by decide
def e605602340362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605602340362 : Closed e605602340362 ∧ code e605602340362 = 2804625595914 := by decide
theorem cert_e605602340362 : check e605602340362 [[],[]] .chain = true := by decide
def e605602340398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605602340398 : Closed e605602340398 ∧ code e605602340398 = 2804625595950 := by decide
theorem cert_e605602340398 : check e605602340398 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602340406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605602340406 : Closed e605602340406 ∧ code e605602340406 = 2804625595958 := by decide
theorem cert_e605602340406 : check e605602340406 [[],[]] .chain = true := by decide
def e605602340410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605602340410 : Closed e605602340410 ∧ code e605602340410 = 2804625595962 := by decide
theorem cert_e605602340410 : check e605602340410 [[],[]] .chain = true := by decide
def e605602340458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605602340458 : Closed e605602340458 ∧ code e605602340458 = 2804625596010 := by decide
theorem cert_e605602340458 : check e605602340458 [[],[]] .chain = true := by decide
def e605602340482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602340482 : Closed e605602340482 ∧ code e605602340482 = 2804625596034 := by decide
theorem cert_e605602340482 : check e605602340482 [[],[]] .chain = true := by decide
def e605602340494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605602340494 : Closed e605602340494 ∧ code e605602340494 = 2804625596046 := by decide
theorem cert_e605602340494 : check e605602340494 [[],[]] .chain = true := by decide
def e605602340506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602340506 : Closed e605602340506 ∧ code e605602340506 = 2804625596058 := by decide
theorem cert_e605602340506 : check e605602340506 [[],[]] .chain = true := by decide
def e605602340550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605602340550 : Closed e605602340550 ∧ code e605602340550 = 2804625596102 := by decide
theorem cert_e605602340550 : check e605602340550 [[],[]] .chain = true := by decide
def e605602340578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605602340578 : Closed e605602340578 ∧ code e605602340578 = 2804625596130 := by decide
theorem cert_e605602340578 : check e605602340578 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602340590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 2)))))))
theorem wire_e605602340590 : Closed e605602340590 ∧ code e605602340590 = 2804625596142 := by decide
theorem cert_e605602340590 : check e605602340590 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602341342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605602341342 : Closed e605602341342 ∧ code e605602341342 = 2804625596894 := by decide
theorem cert_e605602341342 : check e605602341342 [[],[]] .chain = true := by decide
def e605602341366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605602341366 : Closed e605602341366 ∧ code e605602341366 = 2804625596918 := by decide
theorem cert_e605602341366 : check e605602341366 [[],[]] .chain = true := by decide
def e605602342318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605602342318 : Closed e605602342318 ∧ code e605602342318 = 2804625597870 := by decide
theorem cert_e605602342318 : check e605602342318 [[],[]] .chain = true := by decide
def e605602342330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605602342330 : Closed e605602342330 ∧ code e605602342330 = 2804625597882 := by decide
theorem cert_e605602342330 : check e605602342330 [[],[]] .chain = true := by decide
def e605602342378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605602342378 : Closed e605602342378 ∧ code e605602342378 = 2804625597930 := by decide
theorem cert_e605602342378 : check e605602342378 [[],[]] .chain = true := by decide
def e605602342510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602342510 : Closed e605602342510 ∧ code e605602342510 = 2804625598062 := by decide
theorem cert_e605602342510 : check e605602342510 [[],[]] .chain = true := by decide
def e605602342522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602342522 : Closed e605602342522 ∧ code e605602342522 = 2804625598074 := by decide
theorem cert_e605602342522 : check e605602342522 [[],[]] .chain = true := by decide
def e605602342686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605602342686 : Closed e605602342686 ∧ code e605602342686 = 2804625598238 := by decide
theorem cert_e605602342686 : check e605602342686 [[],[]] .chain = true := by decide
def e605602342786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605602342786 : Closed e605602342786 ∧ code e605602342786 = 2804625598338 := by decide
theorem cert_e605602342786 : check e605602342786 [[],[]] .chain = true := by decide
def e605602342798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605602342798 : Closed e605602342798 ∧ code e605602342798 = 2804625598350 := by decide
theorem cert_e605602342798 : check e605602342798 [[],[]] .chain = true := by decide
def e605602342810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602342810 : Closed e605602342810 ∧ code e605602342810 = 2804625598362 := by decide
theorem cert_e605602342810 : check e605602342810 [[],[]] .chain = true := by decide
def e605602345182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605602345182 : Closed e605602345182 ∧ code e605602345182 = 2804625600734 := by decide
theorem cert_e605602345182 : check e605602345182 [[],[]] .chain = true := by decide
def e605602345210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605602345210 : Closed e605602345210 ∧ code e605602345210 = 2804625600762 := by decide
theorem cert_e605602345210 : check e605602345210 [[],[]] .chain = true := by decide
def e605602345758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605602345758 : Closed e605602345758 ∧ code e605602345758 = 2804625601310 := by decide
theorem cert_e605602345758 : check e605602345758 [[],[]] .chain = true := by decide
def e605602345926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605602345926 : Closed e605602345926 ∧ code e605602345926 = 2804625601478 := by decide
theorem cert_e605602345926 : check e605602345926 [[],[]] .chain = true := by decide
def e605602347034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605602347034 : Closed e605602347034 ∧ code e605602347034 = 2804625602586 := by decide
theorem cert_e605602347034 : check e605602347034 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602347070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 4)))))))))
theorem wire_e605602347070 : Closed e605602347070 ∧ code e605602347070 = 2804625602622 := by decide
theorem cert_e605602347070 : check e605602347070 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602347118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605602347118 : Closed e605602347118 ∧ code e605602347118 = 2804625602670 := by decide
theorem cert_e605602347118 : check e605602347118 [[],[]] .chain = true := by decide
def e605602347126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605602347126 : Closed e605602347126 ∧ code e605602347126 = 2804625602678 := by decide
theorem cert_e605602347126 : check e605602347126 [[],[]] .chain = true := by decide
end Blc.Floor41
