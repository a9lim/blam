import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604785799638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e604785799638 : Closed e604785799638 ∧ code e604785799638 = 2803809055190 := by decide
theorem cert_e604785799638 : check e604785799638 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785799642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e604785799642 : Closed e604785799642 ∧ code e604785799642 = 2803809055194 := by decide
theorem cert_e604785799642 : check e604785799642 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e604785800022 : Closed e604785800022 ∧ code e604785800022 = 2803809055574 := by decide
theorem cert_e604785800022 : check e604785800022 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e604785800026 : Closed e604785800026 ∧ code e604785800026 = 2803809055578 := by decide
theorem cert_e604785800026 : check e604785800026 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e604785800042 : Closed e604785800042 ∧ code e604785800042 = 2803809055594 := by decide
theorem cert_e604785800042 : check e604785800042 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e604785800106 : Closed e604785800106 ∧ code e604785800106 = 2803809055658 := by decide
theorem cert_e604785800106 : check e604785800106 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e604785800310 : Closed e604785800310 ∧ code e604785800310 = 2803809055862 := by decide
theorem cert_e604785800310 : check e604785800310 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e604785800406 : Closed e604785800406 ∧ code e604785800406 = 2803809055958 := by decide
theorem cert_e604785800406 : check e604785800406 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e604785800410 : Closed e604785800410 ∧ code e604785800410 = 2803809055962 := by decide
theorem cert_e604785800410 : check e604785800410 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e604785800426 : Closed e604785800426 ∧ code e604785800426 = 2803809055978 := by decide
theorem cert_e604785800426 : check e604785800426 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e604785800502 : Closed e604785800502 ∧ code e604785800502 = 2803809056054 := by decide
theorem cert_e604785800502 : check e604785800502 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e604785800506 : Closed e604785800506 ∧ code e604785800506 = 2803809056058 := by decide
theorem cert_e604785800506 : check e604785800506 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e604785800590 : Closed e604785800590 ∧ code e604785800590 = 2803809056142 := by decide
theorem cert_e604785800590 : check e604785800590 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e604785800602 : Closed e604785800602 ∧ code e604785800602 = 2803809056154 := by decide
theorem cert_e604785800602 : check e604785800602 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e604785800758 : Closed e604785800758 ∧ code e604785800758 = 2803809056310 := by decide
theorem cert_e604785800758 : check e604785800758 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e604785800762 : Closed e604785800762 ∧ code e604785800762 = 2803809056314 := by decide
theorem cert_e604785800762 : check e604785800762 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e604785800810 : Closed e604785800810 ∧ code e604785800810 = 2803809056362 := by decide
theorem cert_e604785800810 : check e604785800810 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e604785800846 : Closed e604785800846 ∧ code e604785800846 = 2803809056398 := by decide
theorem cert_e604785800846 : check e604785800846 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e604785800858 : Closed e604785800858 ∧ code e604785800858 = 2803809056410 := by decide
theorem cert_e604785800858 : check e604785800858 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785800902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e604785800902 : Closed e604785800902 ∧ code e604785800902 = 2803809056454 := by decide
theorem cert_e604785800902 : check e604785800902 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604785807086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e604785807086 : Closed e604785807086 ∧ code e604785807086 = 2803809062638 := by decide
theorem cert_e604785807086 : check e604785807086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785807094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e604785807094 : Closed e604785807094 ∧ code e604785807094 = 2803809062646 := by decide
theorem cert_e604785807094 : check e604785807094 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785807214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e604785807214 : Closed e604785807214 ∧ code e604785807214 = 2803809062766 := by decide
theorem cert_e604785807214 : check e604785807214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e604785807226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e604785807226 : Closed e604785807226 ∧ code e604785807226 = 2803809062778 := by decide
theorem cert_e604785807226 : check e604785807226 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e604785807286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e604785807286 : Closed e604785807286 ∧ code e604785807286 = 2803809062838 := by decide
theorem cert_e604785807286 : check e604785807286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785807290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e604785807290 : Closed e604785807290 ∧ code e604785807290 = 2803809062842 := by decide
theorem cert_e604785807290 : check e604785807290 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785810670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e604785810670 : Closed e604785810670 ∧ code e604785810670 = 2803809066222 := by decide
theorem cert_e604785810670 : checkPay e604785810670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e604785810678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e604785810678 : Closed e604785810678 ∧ code e604785810678 = 2803809066230 := by decide
theorem cert_e604785810678 : checkPay e604785810678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e604785811062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e604785811062 : Closed e604785811062 ∧ code e604785811062 = 2803809066614 := by decide
theorem cert_e604785811062 : check e604785811062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785814894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e604785814894 : Closed e604785814894 ∧ code e604785814894 = 2803809070446 := by decide
theorem cert_e604785814894 : check e604785814894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785814902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e604785814902 : Closed e604785814902 ∧ code e604785814902 = 2803809070454 := by decide
theorem cert_e604785814902 : check e604785814902 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785814958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e604785814958 : Closed e604785814958 ∧ code e604785814958 = 2803809070510 := by decide
theorem cert_e604785814958 : check e604785814958 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785814970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e604785814970 : Closed e604785814970 ∧ code e604785814970 = 2803809070522 := by decide
theorem cert_e604785814970 : check e604785814970 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785814998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e604785814998 : Closed e604785814998 ∧ code e604785814998 = 2803809070550 := by decide
theorem cert_e604785814998 : check e604785814998 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785815002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e604785815002 : Closed e604785815002 ∧ code e604785815002 = 2803809070554 := by decide
theorem cert_e604785815002 : check e604785815002 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785815214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e604785815214 : Closed e604785815214 ∧ code e604785815214 = 2803809070766 := by decide
theorem cert_e604785815214 : check e604785815214 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785815226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e604785815226 : Closed e604785815226 ∧ code e604785815226 = 2803809070778 := by decide
theorem cert_e604785815226 : check e604785815226 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785815274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e604785815274 : Closed e604785815274 ∧ code e604785815274 = 2803809070826 := by decide
theorem cert_e604785815274 : check e604785815274 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785815382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e604785815382 : Closed e604785815382 ∧ code e604785815382 = 2803809070934 := by decide
theorem cert_e604785815382 : check e604785815382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785815386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e604785815386 : Closed e604785815386 ∧ code e604785815386 = 2803809070938 := by decide
theorem cert_e604785815386 : check e604785815386 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785815402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e604785815402 : Closed e604785815402 ∧ code e604785815402 = 2803809070954 := by decide
theorem cert_e604785815402 : check e604785815402 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785816430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e604785816430 : Closed e604785816430 ∧ code e604785816430 = 2803809071982 := by decide
theorem cert_e604785816430 : check e604785816430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785816438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e604785816438 : Closed e604785816438 ∧ code e604785816438 = 2803809071990 := by decide
theorem cert_e604785816438 : check e604785816438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785816494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e604785816494 : Closed e604785816494 ∧ code e604785816494 = 2803809072046 := by decide
theorem cert_e604785816494 : check e604785816494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785816506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e604785816506 : Closed e604785816506 ∧ code e604785816506 = 2803809072058 := by decide
theorem cert_e604785816506 : check e604785816506 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785816534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e604785816534 : Closed e604785816534 ∧ code e604785816534 = 2803809072086 := by decide
theorem cert_e604785816534 : checkPay e604785816534 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e604785816538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e604785816538 : Closed e604785816538 ∧ code e604785816538 = 2803809072090 := by decide
theorem cert_e604785816538 : check e604785816538 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785816814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e604785816814 : Closed e604785816814 ∧ code e604785816814 = 2803809072366 := by decide
theorem cert_e604785816814 : check e604785816814 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785816822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e604785816822 : Closed e604785816822 ∧ code e604785816822 = 2803809072374 := by decide
theorem cert_e604785816822 : check e604785816822 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785817198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e604785817198 : Closed e604785817198 ∧ code e604785817198 = 2803809072750 := by decide
theorem cert_e604785817198 : check e604785817198 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785817210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e604785817210 : Closed e604785817210 ∧ code e604785817210 = 2803809072762 := by decide
theorem cert_e604785817210 : check e604785817210 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785817398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e604785817398 : Closed e604785817398 ∧ code e604785817398 = 2803809072950 := by decide
theorem cert_e604785817398 : check e604785817398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785817402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e604785817402 : Closed e604785817402 ∧ code e604785817402 = 2803809072954 := by decide
theorem cert_e604785817402 : check e604785817402 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785817838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e604785817838 : Closed e604785817838 ∧ code e604785817838 = 2803809073390 := by decide
theorem cert_e604785817838 : check e604785817838 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785817846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e604785817846 : Closed e604785817846 ∧ code e604785817846 = 2803809073398 := by decide
theorem cert_e604785817846 : check e604785817846 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e604785818030 : Closed e604785818030 ∧ code e604785818030 = 2803809073582 := by decide
theorem cert_e604785818030 : check e604785818030 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e604785818042 : Closed e604785818042 ∧ code e604785818042 = 2803809073594 := by decide
theorem cert_e604785818042 : check e604785818042 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e604785818090 : Closed e604785818090 ∧ code e604785818090 = 2803809073642 := by decide
theorem cert_e604785818090 : check e604785818090 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e604785818222 : Closed e604785818222 ∧ code e604785818222 = 2803809073774 := by decide
theorem cert_e604785818222 : check e604785818222 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e604785818234 : Closed e604785818234 ∧ code e604785818234 = 2803809073786 := by decide
theorem cert_e604785818234 : check e604785818234 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e604785818398 : Closed e604785818398 ∧ code e604785818398 = 2803809073950 := by decide
theorem cert_e604785818398 : check e604785818398 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e604785818510 : Closed e604785818510 ∧ code e604785818510 = 2803809074062 := by decide
theorem cert_e604785818510 : check e604785818510 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e604785818522 : Closed e604785818522 ∧ code e604785818522 = 2803809074074 := by decide
theorem cert_e604785818522 : check e604785818522 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e604785818742 : Closed e604785818742 ∧ code e604785818742 = 2803809074294 := by decide
theorem cert_e604785818742 : checkPay e604785818742 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785818838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e604785818838 : Closed e604785818838 ∧ code e604785818838 = 2803809074390 := by decide
theorem cert_e604785818838 : checkPay e604785818838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e604785818842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e604785818842 : Closed e604785818842 ∧ code e604785818842 = 2803809074394 := by decide
theorem cert_e604785818842 : check e604785818842 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785818858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e604785818858 : Closed e604785818858 ∧ code e604785818858 = 2803809074410 := by decide
theorem cert_e604785818858 : check e604785818858 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785818934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e604785818934 : Closed e604785818934 ∧ code e604785818934 = 2803809074486 := by decide
theorem cert_e604785818934 : check e604785818934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604785818938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e604785818938 : Closed e604785818938 ∧ code e604785818938 = 2803809074490 := by decide
theorem cert_e604785818938 : check e604785818938 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785819022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e604785819022 : Closed e604785819022 ∧ code e604785819022 = 2803809074574 := by decide
theorem cert_e604785819022 : check e604785819022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785819034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e604785819034 : Closed e604785819034 ∧ code e604785819034 = 2803809074586 := by decide
theorem cert_e604785819034 : check e604785819034 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785820638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e604785820638 : Closed e604785820638 ∧ code e604785820638 = 2803809076190 := by decide
theorem cert_e604785820638 : check e604785820638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785820654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e604785820654 : Closed e604785820654 ∧ code e604785820654 = 2803809076206 := by decide
theorem cert_e604785820654 : check e604785820654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604785822574 : Closed e604785822574 ∧ code e604785822574 = 2803809078126 := by decide
theorem cert_e604785822574 : check e604785822574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604785822582 : Closed e604785822582 ∧ code e604785822582 = 2803809078134 := by decide
theorem cert_e604785822582 : check e604785822582 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604785822638 : Closed e604785822638 ∧ code e604785822638 = 2803809078190 := by decide
theorem cert_e604785822638 : check e604785822638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604785822650 : Closed e604785822650 ∧ code e604785822650 = 2803809078202 := by decide
theorem cert_e604785822650 : check e604785822650 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604785822678 : Closed e604785822678 ∧ code e604785822678 = 2803809078230 := by decide
theorem cert_e604785822678 : check e604785822678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604785822682 : Closed e604785822682 ∧ code e604785822682 = 2803809078234 := by decide
theorem cert_e604785822682 : check e604785822682 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604785822958 : Closed e604785822958 ∧ code e604785822958 = 2803809078510 := by decide
theorem cert_e604785822958 : check e604785822958 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785822966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604785822966 : Closed e604785822966 ∧ code e604785822966 = 2803809078518 := by decide
theorem cert_e604785822966 : check e604785822966 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785823342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604785823342 : Closed e604785823342 ∧ code e604785823342 = 2803809078894 := by decide
theorem cert_e604785823342 : check e604785823342 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785823354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604785823354 : Closed e604785823354 ∧ code e604785823354 = 2803809078906 := by decide
theorem cert_e604785823354 : check e604785823354 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785823542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604785823542 : Closed e604785823542 ∧ code e604785823542 = 2803809079094 := by decide
theorem cert_e604785823542 : check e604785823542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785823546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604785823546 : Closed e604785823546 ∧ code e604785823546 = 2803809079098 := by decide
theorem cert_e604785823546 : check e604785823546 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785828318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e604785828318 : Closed e604785828318 ∧ code e604785828318 = 2803809083870 := by decide
theorem cert_e604785828318 : check e604785828318 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785828342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e604785828342 : Closed e604785828342 ∧ code e604785828342 = 2803809083894 := by decide
theorem cert_e604785828342 : check e604785828342 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e604785829294 : Closed e604785829294 ∧ code e604785829294 = 2803809084846 := by decide
theorem cert_e604785829294 : check e604785829294 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e604785829306 : Closed e604785829306 ∧ code e604785829306 = 2803809084858 := by decide
theorem cert_e604785829306 : check e604785829306 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e604785829354 : Closed e604785829354 ∧ code e604785829354 = 2803809084906 := by decide
theorem cert_e604785829354 : check e604785829354 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e604785829486 : Closed e604785829486 ∧ code e604785829486 = 2803809085038 := by decide
theorem cert_e604785829486 : check e604785829486 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e604785829498 : Closed e604785829498 ∧ code e604785829498 = 2803809085050 := by decide
theorem cert_e604785829498 : check e604785829498 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e604785829662 : Closed e604785829662 ∧ code e604785829662 = 2803809085214 := by decide
theorem cert_e604785829662 : check e604785829662 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e604785829774 : Closed e604785829774 ∧ code e604785829774 = 2803809085326 := by decide
theorem cert_e604785829774 : check e604785829774 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785829786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e604785829786 : Closed e604785829786 ∧ code e604785829786 = 2803809085338 := by decide
theorem cert_e604785829786 : check e604785829786 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604785832174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e604785832174 : Closed e604785832174 ∧ code e604785832174 = 2803809087726 := by decide
theorem cert_e604785832174 : check e604785832174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e604785832182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e604785832182 : Closed e604785832182 ∧ code e604785832182 = 2803809087734 := by decide
theorem cert_e604785832182 : checkPay e604785832182 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e604785832662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e604785832662 : Closed e604785832662 ∧ code e604785832662 = 2803809088214 := by decide
theorem cert_e604785832662 : check e604785832662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785832666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e604785832666 : Closed e604785832666 ∧ code e604785832666 = 2803809088218 := by decide
theorem cert_e604785832666 : check e604785832666 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785832682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e604785832682 : Closed e604785832682 ∧ code e604785832682 = 2803809088234 := by decide
theorem cert_e604785832682 : check e604785832682 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785832758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e604785832758 : Closed e604785832758 ∧ code e604785832758 = 2803809088310 := by decide
theorem cert_e604785832758 : check e604785832758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left]] .identityHead = true := by decide
def e604785832762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e604785832762 : Closed e604785832762 ∧ code e604785832762 = 2803809088314 := by decide
theorem cert_e604785832762 : check e604785832762 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785832846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e604785832846 : Closed e604785832846 ∧ code e604785832846 = 2803809088398 := by decide
theorem cert_e604785832846 : check e604785832846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785832858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e604785832858 : Closed e604785832858 ∧ code e604785832858 = 2803809088410 := by decide
theorem cert_e604785832858 : check e604785832858 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785837934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e604785837934 : Closed e604785837934 ∧ code e604785837934 = 2803809093486 := by decide
theorem cert_e604785837934 : checkPay e604785837934 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e604785837946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e604785837946 : Closed e604785837946 ∧ code e604785837946 = 2803809093498 := by decide
theorem cert_e604785837946 : checkPay e604785837946 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.under,.left],[.under,.under,.under,.left,.left]] = true := by decide
def e604785838042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e604785838042 : Closed e604785838042 ∧ code e604785838042 = 2803809093594 := by decide
theorem cert_e604785838042 : checkPay e604785838042 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e604785839342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e604785839342 : Closed e604785839342 ∧ code e604785839342 = 2803809094894 := by decide
theorem cert_e604785839342 : checkPay e604785839342 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785839350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e604785839350 : Closed e604785839350 ∧ code e604785839350 = 2803809094902 := by decide
theorem cert_e604785839350 : checkPay e604785839350 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785839726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e604785839726 : Closed e604785839726 ∧ code e604785839726 = 2803809095278 := by decide
theorem cert_e604785839726 : checkPay e604785839726 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785839738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e604785839738 : Closed e604785839738 ∧ code e604785839738 = 2803809095290 := by decide
theorem cert_e604785839738 : checkPay e604785839738 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785839926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e604785839926 : Closed e604785839926 ∧ code e604785839926 = 2803809095478 := by decide
theorem cert_e604785839926 : checkPay e604785839926 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e604785839930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e604785839930 : Closed e604785839930 ∧ code e604785839930 = 2803809095482 := by decide
theorem cert_e604785839930 : checkPay e604785839930 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e604785841838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e604785841838 : Closed e604785841838 ∧ code e604785841838 = 2803809097390 := by decide
theorem cert_e604785841838 : checkPay e604785841838 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e604785841850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e604785841850 : Closed e604785841850 ∧ code e604785841850 = 2803809097402 := by decide
theorem cert_e604785841850 : checkPay e604785841850 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e604785841898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e604785841898 : Closed e604785841898 ∧ code e604785841898 = 2803809097450 := by decide
theorem cert_e604785841898 : checkPay e604785841898 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e604785842090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e604785842090 : Closed e604785842090 ∧ code e604785842090 = 2803809097642 := by decide
theorem cert_e604785842090 : checkPay e604785842090 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e604785842414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e604785842414 : Closed e604785842414 ∧ code e604785842414 = 2803809097966 := by decide
theorem cert_e604785842414 : checkPay e604785842414 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left]] = true := by decide
def e604785842422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e604785842422 : Closed e604785842422 ∧ code e604785842422 = 2803809097974 := by decide
theorem cert_e604785842422 : checkPay e604785842422 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e604785842606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e604785842606 : Closed e604785842606 ∧ code e604785842606 = 2803809098158 := by decide
theorem cert_e604785842606 : checkPay e604785842606 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e604785842618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e604785842618 : Closed e604785842618 ∧ code e604785842618 = 2803809098170 := by decide
theorem cert_e604785842618 : checkPay e604785842618 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e604785842666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e604785842666 : Closed e604785842666 ∧ code e604785842666 = 2803809098218 := by decide
theorem cert_e604785842666 : checkPay e604785842666 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e604785842798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e604785842798 : Closed e604785842798 ∧ code e604785842798 = 2803809098350 := by decide
theorem cert_e604785842798 : checkPay e604785842798 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e604785842810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e604785842810 : Closed e604785842810 ∧ code e604785842810 = 2803809098362 := by decide
theorem cert_e604785842810 : checkPay e604785842810 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e604785842974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e604785842974 : Closed e604785842974 ∧ code e604785842974 = 2803809098526 := by decide
theorem cert_e604785842974 : checkPay e604785842974 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785843086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e604785843086 : Closed e604785843086 ∧ code e604785843086 = 2803809098638 := by decide
theorem cert_e604785843086 : checkPay e604785843086 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e604785843098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e604785843098 : Closed e604785843098 ∧ code e604785843098 = 2803809098650 := by decide
theorem cert_e604785843098 : checkPay e604785843098 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e604785843310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e604785843310 : Closed e604785843310 ∧ code e604785843310 = 2803809098862 := by decide
theorem cert_e604785843310 : checkPay e604785843310 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785843322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e604785843322 : Closed e604785843322 ∧ code e604785843322 = 2803809098874 := by decide
theorem cert_e604785843322 : checkPay e604785843322 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.under]] = true := by decide
def e604785843486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e604785843486 : Closed e604785843486 ∧ code e604785843486 = 2803809099038 := by decide
theorem cert_e604785843486 : checkPay e604785843486 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785843654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e604785843654 : Closed e604785843654 ∧ code e604785843654 = 2803809099206 := by decide
theorem cert_e604785843654 : checkPay e604785843654 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e604785843766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e604785843766 : Closed e604785843766 ∧ code e604785843766 = 2803809099318 := by decide
theorem cert_e604785843766 : checkPay e604785843766 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e604785843770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e604785843770 : Closed e604785843770 ∧ code e604785843770 = 2803809099322 := by decide
theorem cert_e604785843770 : checkPay e604785843770 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left]] = true := by decide
def e604785843818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e604785843818 : Closed e604785843818 ∧ code e604785843818 = 2803809099370 := by decide
theorem cert_e604785843818 : checkPay e604785843818 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e604785843854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e604785843854 : Closed e604785843854 ∧ code e604785843854 = 2803809099406 := by decide
theorem cert_e604785843854 : checkPay e604785843854 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e604785843866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e604785843866 : Closed e604785843866 ∧ code e604785843866 = 2803809099418 := by decide
theorem cert_e604785843866 : checkPay e604785843866 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e604785843910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e604785843910 : Closed e604785843910 ∧ code e604785843910 = 2803809099462 := by decide
theorem cert_e604785843910 : checkPay e604785843910 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e604785844702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e604785844702 : Closed e604785844702 ∧ code e604785844702 = 2803809100254 := by decide
theorem cert_e604785844702 : checkPay e604785844702 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785844726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e604785844726 : Closed e604785844726 ∧ code e604785844726 = 2803809100278 := by decide
theorem cert_e604785844726 : checkPay e604785844726 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785845678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e604785845678 : Closed e604785845678 ∧ code e604785845678 = 2803809101230 := by decide
theorem cert_e604785845678 : checkPay e604785845678 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785845690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e604785845690 : Closed e604785845690 ∧ code e604785845690 = 2803809101242 := by decide
theorem cert_e604785845690 : checkPay e604785845690 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785845738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e604785845738 : Closed e604785845738 ∧ code e604785845738 = 2803809101290 := by decide
theorem cert_e604785845738 : checkPay e604785845738 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785845870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e604785845870 : Closed e604785845870 ∧ code e604785845870 = 2803809101422 := by decide
theorem cert_e604785845870 : checkPay e604785845870 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785845882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e604785845882 : Closed e604785845882 ∧ code e604785845882 = 2803809101434 := by decide
theorem cert_e604785845882 : checkPay e604785845882 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785846046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e604785846046 : Closed e604785846046 ∧ code e604785846046 = 2803809101598 := by decide
theorem cert_e604785846046 : checkPay e604785846046 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785846158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e604785846158 : Closed e604785846158 ∧ code e604785846158 = 2803809101710 := by decide
theorem cert_e604785846158 : checkPay e604785846158 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785846170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e604785846170 : Closed e604785846170 ∧ code e604785846170 = 2803809101722 := by decide
theorem cert_e604785846170 : checkPay e604785846170 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785849118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e604785849118 : Closed e604785849118 ∧ code e604785849118 = 2803809104670 := by decide
theorem cert_e604785849118 : checkPay e604785849118 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785849286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e604785849286 : Closed e604785849286 ∧ code e604785849286 = 2803809104838 := by decide
theorem cert_e604785849286 : checkPay e604785849286 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604785850486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e604785850486 : Closed e604785850486 ∧ code e604785850486 = 2803809106038 := by decide
theorem cert_e604785850486 : checkPay e604785850486 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785850730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e604785850730 : Closed e604785850730 ∧ code e604785850730 = 2803809106282 := by decide
theorem cert_e604785850730 : checkPay e604785850730 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785850766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e604785850766 : Closed e604785850766 ∧ code e604785850766 = 2803809106318 := by decide
theorem cert_e604785850766 : checkPay e604785850766 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785850778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e604785850778 : Closed e604785850778 ∧ code e604785850778 = 2803809106330 := by decide
theorem cert_e604785850778 : checkPay e604785850778 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785850822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e604785850822 : Closed e604785850822 ∧ code e604785850822 = 2803809106374 := by decide
theorem cert_e604785850822 : checkPay e604785850822 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604785853366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e604785853366 : Closed e604785853366 ∧ code e604785853366 = 2803809108918 := by decide
theorem cert_e604785853366 : check e604785853366 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785853370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e604785853370 : Closed e604785853370 ∧ code e604785853370 = 2803809108922 := by decide
theorem cert_e604785853370 : check e604785853370 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785853402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e604785853402 : Closed e604785853402 ∧ code e604785853402 = 2803809108954 := by decide
theorem cert_e604785853402 : check e604785853402 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785854070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e604785854070 : Closed e604785854070 ∧ code e604785854070 = 2803809109622 := by decide
theorem cert_e604785854070 : check e604785854070 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785854262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e604785854262 : Closed e604785854262 ∧ code e604785854262 = 2803809109814 := by decide
theorem cert_e604785854262 : check e604785854262 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785854266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e604785854266 : Closed e604785854266 ∧ code e604785854266 = 2803809109818 := by decide
theorem cert_e604785854266 : check e604785854266 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
end Blc.Floor41
