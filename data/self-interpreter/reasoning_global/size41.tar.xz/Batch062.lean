import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604530175514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530175514 : Closed e604530175514 ∧ code e604530175514 = 2803553431066 := by decide
theorem cert_e604530175514 : check e604530175514 [[]] .width = true := by decide
def e604530178586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530178586 : Closed e604530178586 ∧ code e604530178586 = 2803553434138 := by decide
theorem cert_e604530178586 : check e604530178586 [[]] .width = true := by decide
def e604530204698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604530204698 : Closed e604530204698 ∧ code e604530204698 = 2803553460250 := by decide
theorem cert_e604530204698 : check e604530204698 [[]] .width = true := by decide
def e604530204790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604530204790 : Closed e604530204790 ∧ code e604530204790 = 2803553460342 := by decide
theorem cert_e604530204790 : check e604530204790 [[]] .width = true := by decide
def e604530205034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604530205034 : Closed e604530205034 ∧ code e604530205034 = 2803553460586 := by decide
theorem cert_e604530205034 : check e604530205034 [[]] .width = true := by decide
def e604530205082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604530205082 : Closed e604530205082 ∧ code e604530205082 = 2803553460634 := by decide
theorem cert_e604530205082 : check e604530205082 [[]] .width = true := by decide
def e604530226714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530226714 : Closed e604530226714 ∧ code e604530226714 = 2803553482266 := by decide
theorem cert_e604530226714 : check e604530226714 [[]] .width = true := by decide
def e604530227738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530227738 : Closed e604530227738 ∧ code e604530227738 = 2803553483290 := by decide
theorem cert_e604530227738 : check e604530227738 [[]] .width = true := by decide
def e604530237466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604530237466 : Closed e604530237466 ∧ code e604530237466 = 2803553493018 := by decide
theorem cert_e604530237466 : check e604530237466 [[]] .width = true := by decide
def e604530237558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604530237558 : Closed e604530237558 ∧ code e604530237558 = 2803553493110 := by decide
theorem cert_e604530237558 : check e604530237558 [[]] .width = true := by decide
def e604530237802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604530237802 : Closed e604530237802 ∧ code e604530237802 = 2803553493354 := by decide
theorem cert_e604530237802 : check e604530237802 [[]] .width = true := by decide
def e604530237850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604530237850 : Closed e604530237850 ∧ code e604530237850 = 2803553493402 := by decide
theorem cert_e604530237850 : check e604530237850 [[]] .width = true := by decide
def e604531449370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531449370 : Closed e604531449370 ∧ code e604531449370 = 2803554704922 := by decide
theorem cert_e604531449370 : check e604531449370 [[]] .width = true := by decide
def e604531455514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531455514 : Closed e604531455514 ∧ code e604531455514 = 2803554711066 := by decide
theorem cert_e604531455514 : check e604531455514 [[]] .width = true := by decide
def e604531699226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531699226 : Closed e604531699226 ∧ code e604531699226 = 2803554954778 := by decide
theorem cert_e604531699226 : check e604531699226 [[]] .width = true := by decide
def e604531702298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531702298 : Closed e604531702298 ∧ code e604531702298 = 2803554957850 := by decide
theorem cert_e604531702298 : check e604531702298 [[]] .width = true := by decide
def e604531714586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531714586 : Closed e604531714586 ∧ code e604531714586 = 2803554970138 := by decide
theorem cert_e604531714586 : check e604531714586 [[]] .width = true := by decide
def e604531748378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531748378 : Closed e604531748378 ∧ code e604531748378 = 2803555003930 := by decide
theorem cert_e604531748378 : check e604531748378 [[]] .width = true := by decide
def e604531751450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531751450 : Closed e604531751450 ∧ code e604531751450 = 2803555007002 := by decide
theorem cert_e604531751450 : check e604531751450 [[]] .width = true := by decide
def e604531777562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604531777562 : Closed e604531777562 ∧ code e604531777562 = 2803555033114 := by decide
theorem cert_e604531777562 : check e604531777562 [[]] .width = true := by decide
def e604531777654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604531777654 : Closed e604531777654 ∧ code e604531777654 = 2803555033206 := by decide
theorem cert_e604531777654 : check e604531777654 [[]] .width = true := by decide
def e604531777898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604531777898 : Closed e604531777898 ∧ code e604531777898 = 2803555033450 := by decide
theorem cert_e604531777898 : check e604531777898 [[]] .width = true := by decide
def e604531777946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604531777946 : Closed e604531777946 ∧ code e604531777946 = 2803555033498 := by decide
theorem cert_e604531777946 : check e604531777946 [[]] .width = true := by decide
def e604531825178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604531825178 : Closed e604531825178 ∧ code e604531825178 = 2803555080730 := by decide
theorem cert_e604531825178 : check e604531825178 [[]] .width = true := by decide
def e604531826714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604531826714 : Closed e604531826714 ∧ code e604531826714 = 2803555082266 := by decide
theorem cert_e604531826714 : check e604531826714 [[]] .width = true := by decide
def e604531826806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604531826806 : Closed e604531826806 ∧ code e604531826806 = 2803555082358 := by decide
theorem cert_e604531826806 : check e604531826806 [[]] .width = true := by decide
def e604531827050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604531827050 : Closed e604531827050 ∧ code e604531827050 = 2803555082602 := by decide
theorem cert_e604531827050 : check e604531827050 [[]] .width = true := by decide
def e604531827098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604531827098 : Closed e604531827098 ∧ code e604531827098 = 2803555082650 := by decide
theorem cert_e604531827098 : check e604531827098 [[]] .width = true := by decide
def e604532436506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532436506 : Closed e604532436506 ∧ code e604532436506 = 2803555692058 := by decide
theorem cert_e604532436506 : check e604532436506 [[]] .width = true := by decide
def e604532438554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532438554 : Closed e604532438554 ∧ code e604532438554 = 2803555694106 := by decide
theorem cert_e604532438554 : check e604532438554 [[]] .width = true := by decide
def e604532561434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532561434 : Closed e604532561434 ∧ code e604532561434 = 2803555816986 := by decide
theorem cert_e604532561434 : check e604532561434 [[]] .width = true := by decide
def e604532562458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532562458 : Closed e604532562458 ∧ code e604532562458 = 2803555818010 := by decide
theorem cert_e604532562458 : check e604532562458 [[]] .width = true := by decide
def e604532566554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532566554 : Closed e604532566554 ∧ code e604532566554 = 2803555822106 := by decide
theorem cert_e604532566554 : check e604532566554 [[]] .width = true := by decide
def e604532586010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532586010 : Closed e604532586010 ∧ code e604532586010 = 2803555841562 := by decide
theorem cert_e604532586010 : check e604532586010 [[]] .width = true := by decide
def e604532587034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532587034 : Closed e604532587034 ∧ code e604532587034 = 2803555842586 := by decide
theorem cert_e604532587034 : check e604532587034 [[]] .width = true := by decide
def e604532596762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604532596762 : Closed e604532596762 ∧ code e604532596762 = 2803555852314 := by decide
theorem cert_e604532596762 : check e604532596762 [[]] .width = true := by decide
def e604532596854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604532596854 : Closed e604532596854 ∧ code e604532596854 = 2803555852406 := by decide
theorem cert_e604532596854 : check e604532596854 [[]] .width = true := by decide
def e604532597098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604532597098 : Closed e604532597098 ∧ code e604532597098 = 2803555852650 := by decide
theorem cert_e604532597098 : check e604532597098 [[]] .width = true := by decide
def e604532597146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604532597146 : Closed e604532597146 ∧ code e604532597146 = 2803555852698 := by decide
theorem cert_e604532597146 : check e604532597146 [[]] .width = true := by decide
def e604532611610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604532611610 : Closed e604532611610 ∧ code e604532611610 = 2803555867162 := by decide
theorem cert_e604532611610 : check e604532611610 [[]] .width = true := by decide
def e604532613146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604532613146 : Closed e604532613146 ∧ code e604532613146 = 2803555868698 := by decide
theorem cert_e604532613146 : check e604532613146 [[]] .width = true := by decide
def e604532613238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604532613238 : Closed e604532613238 ∧ code e604532613238 = 2803555868790 := by decide
theorem cert_e604532613238 : check e604532613238 [[]] .width = true := by decide
def e604532613482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604532613482 : Closed e604532613482 ∧ code e604532613482 = 2803555869034 := by decide
theorem cert_e604532613482 : check e604532613482 [[]] .width = true := by decide
def e604532613530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604532613530 : Closed e604532613530 ∧ code e604532613530 = 2803555869082 := by decide
theorem cert_e604532613530 : check e604532613530 [[]] .width = true := by decide
def e604533468526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e604533468526 : Closed e604533468526 ∧ code e604533468526 = 2803556724078 := by decide
theorem cert_e604533468526 : check e604533468526 [[],[]] .chain = true := by decide
def e604533468534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e604533468534 : Closed e604533468534 ∧ code e604533468534 = 2803556724086 := by decide
theorem cert_e604533468534 : check e604533468534 [[],[]] .chain = true := by decide
def e604533468590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e604533468590 : Closed e604533468590 ∧ code e604533468590 = 2803556724142 := by decide
theorem cert_e604533468590 : check e604533468590 [[],[]] .chain = true := by decide
def e604533468602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e604533468602 : Closed e604533468602 ∧ code e604533468602 = 2803556724154 := by decide
theorem cert_e604533468602 : check e604533468602 [[],[]] .chain = true := by decide
def e604533468630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e604533468630 : Closed e604533468630 ∧ code e604533468630 = 2803556724182 := by decide
theorem cert_e604533468630 : check e604533468630 [[],[]] .chain = true := by decide
def e604533468634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e604533468634 : Closed e604533468634 ∧ code e604533468634 = 2803556724186 := by decide
theorem cert_e604533468634 : check e604533468634 [[],[]] .chain = true := by decide
def e604533468846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e604533468846 : Closed e604533468846 ∧ code e604533468846 = 2803556724398 := by decide
theorem cert_e604533468846 : check e604533468846 [[],[]] .chain = true := by decide
def e604533468858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e604533468858 : Closed e604533468858 ∧ code e604533468858 = 2803556724410 := by decide
theorem cert_e604533468858 : check e604533468858 [[],[]] .chain = true := by decide
def e604533468906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e604533468906 : Closed e604533468906 ∧ code e604533468906 = 2803556724458 := by decide
theorem cert_e604533468906 : check e604533468906 [[],[]] .chain = true := by decide
def e604533469014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e604533469014 : Closed e604533469014 ∧ code e604533469014 = 2803556724566 := by decide
theorem cert_e604533469014 : check e604533469014 [[],[]] .chain = true := by decide
def e604533469018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e604533469018 : Closed e604533469018 ∧ code e604533469018 = 2803556724570 := by decide
theorem cert_e604533469018 : check e604533469018 [[],[]] .chain = true := by decide
def e604533469034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e604533469034 : Closed e604533469034 ∧ code e604533469034 = 2803556724586 := by decide
theorem cert_e604533469034 : check e604533469034 [[],[]] .chain = true := by decide
def e604533470062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e604533470062 : Closed e604533470062 ∧ code e604533470062 = 2803556725614 := by decide
theorem cert_e604533470062 : check e604533470062 [[],[]] .chain = true := by decide
def e604533470070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e604533470070 : Closed e604533470070 ∧ code e604533470070 = 2803556725622 := by decide
theorem cert_e604533470070 : check e604533470070 [[],[]] .chain = true := by decide
def e604533470126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e604533470126 : Closed e604533470126 ∧ code e604533470126 = 2803556725678 := by decide
theorem cert_e604533470126 : check e604533470126 [[],[]] .chain = true := by decide
def e604533470138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e604533470138 : Closed e604533470138 ∧ code e604533470138 = 2803556725690 := by decide
theorem cert_e604533470138 : check e604533470138 [[],[]] .chain = true := by decide
def e604533470166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e604533470166 : Closed e604533470166 ∧ code e604533470166 = 2803556725718 := by decide
theorem cert_e604533470166 : check e604533470166 [[],[]] .chain = true := by decide
def e604533470170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e604533470170 : Closed e604533470170 ∧ code e604533470170 = 2803556725722 := by decide
theorem cert_e604533470170 : check e604533470170 [[],[]] .chain = true := by decide
def e604533470446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e604533470446 : Closed e604533470446 ∧ code e604533470446 = 2803556725998 := by decide
theorem cert_e604533470446 : check e604533470446 [[],[]] .chain = true := by decide
def e604533470454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e604533470454 : Closed e604533470454 ∧ code e604533470454 = 2803556726006 := by decide
theorem cert_e604533470454 : check e604533470454 [[],[]] .chain = true := by decide
def e604533470830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e604533470830 : Closed e604533470830 ∧ code e604533470830 = 2803556726382 := by decide
theorem cert_e604533470830 : check e604533470830 [[],[]] .chain = true := by decide
def e604533470842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e604533470842 : Closed e604533470842 ∧ code e604533470842 = 2803556726394 := by decide
theorem cert_e604533470842 : check e604533470842 [[],[]] .chain = true := by decide
def e604533471030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e604533471030 : Closed e604533471030 ∧ code e604533471030 = 2803556726582 := by decide
theorem cert_e604533471030 : check e604533471030 [[],[]] .chain = true := by decide
def e604533471034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e604533471034 : Closed e604533471034 ∧ code e604533471034 = 2803556726586 := by decide
theorem cert_e604533471034 : check e604533471034 [[],[]] .chain = true := by decide
def e604533471662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e604533471662 : Closed e604533471662 ∧ code e604533471662 = 2803556727214 := by decide
theorem cert_e604533471662 : check e604533471662 [[],[]] .chain = true := by decide
def e604533471674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e604533471674 : Closed e604533471674 ∧ code e604533471674 = 2803556727226 := by decide
theorem cert_e604533471674 : check e604533471674 [[],[]] .chain = true := by decide
def e604533471722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e604533471722 : Closed e604533471722 ∧ code e604533471722 = 2803556727274 := by decide
theorem cert_e604533471722 : check e604533471722 [[],[]] .chain = true := by decide
def e604533471854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e604533471854 : Closed e604533471854 ∧ code e604533471854 = 2803556727406 := by decide
theorem cert_e604533471854 : check e604533471854 [[],[]] .chain = true := by decide
def e604533471866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e604533471866 : Closed e604533471866 ∧ code e604533471866 = 2803556727418 := by decide
theorem cert_e604533471866 : check e604533471866 [[],[]] .chain = true := by decide
def e604533472154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e604533472154 : Closed e604533472154 ∧ code e604533472154 = 2803556727706 := by decide
theorem cert_e604533472154 : check e604533472154 [[],[]] .chain = true := by decide
def e604533472470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e604533472470 : Closed e604533472470 ∧ code e604533472470 = 2803556728022 := by decide
theorem cert_e604533472470 : check e604533472470 [[],[]] .chain = true := by decide
def e604533472474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e604533472474 : Closed e604533472474 ∧ code e604533472474 = 2803556728026 := by decide
theorem cert_e604533472474 : check e604533472474 [[],[]] .chain = true := by decide
def e604533472490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e604533472490 : Closed e604533472490 ∧ code e604533472490 = 2803556728042 := by decide
theorem cert_e604533472490 : check e604533472490 [[],[]] .chain = true := by decide
def e604533472566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e604533472566 : Closed e604533472566 ∧ code e604533472566 = 2803556728118 := by decide
theorem cert_e604533472566 : check e604533472566 [[],[]] .chain = true := by decide
def e604533472570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e604533472570 : Closed e604533472570 ∧ code e604533472570 = 2803556728122 := by decide
theorem cert_e604533472570 : check e604533472570 [[],[]] .chain = true := by decide
def e604533472666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e604533472666 : Closed e604533472666 ∧ code e604533472666 = 2803556728218 := by decide
theorem cert_e604533472666 : check e604533472666 [[],[]] .chain = true := by decide
def e604533476206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604533476206 : Closed e604533476206 ∧ code e604533476206 = 2803556731758 := by decide
theorem cert_e604533476206 : check e604533476206 [[],[]] .chain = true := by decide
def e604533476214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604533476214 : Closed e604533476214 ∧ code e604533476214 = 2803556731766 := by decide
theorem cert_e604533476214 : check e604533476214 [[],[]] .chain = true := by decide
def e604533476270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604533476270 : Closed e604533476270 ∧ code e604533476270 = 2803556731822 := by decide
theorem cert_e604533476270 : check e604533476270 [[],[]] .chain = true := by decide
def e604533476282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604533476282 : Closed e604533476282 ∧ code e604533476282 = 2803556731834 := by decide
theorem cert_e604533476282 : check e604533476282 [[],[]] .chain = true := by decide
def e604533476310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604533476310 : Closed e604533476310 ∧ code e604533476310 = 2803556731862 := by decide
theorem cert_e604533476310 : check e604533476310 [[],[]] .chain = true := by decide
def e604533476314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604533476314 : Closed e604533476314 ∧ code e604533476314 = 2803556731866 := by decide
theorem cert_e604533476314 : check e604533476314 [[],[]] .chain = true := by decide
def e604533476590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604533476590 : Closed e604533476590 ∧ code e604533476590 = 2803556732142 := by decide
theorem cert_e604533476590 : check e604533476590 [[],[]] .chain = true := by decide
def e604533476598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604533476598 : Closed e604533476598 ∧ code e604533476598 = 2803556732150 := by decide
theorem cert_e604533476598 : check e604533476598 [[],[]] .chain = true := by decide
def e604533476974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604533476974 : Closed e604533476974 ∧ code e604533476974 = 2803556732526 := by decide
theorem cert_e604533476974 : check e604533476974 [[],[]] .chain = true := by decide
def e604533476986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604533476986 : Closed e604533476986 ∧ code e604533476986 = 2803556732538 := by decide
theorem cert_e604533476986 : check e604533476986 [[],[]] .chain = true := by decide
def e604533477174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604533477174 : Closed e604533477174 ∧ code e604533477174 = 2803556732726 := by decide
theorem cert_e604533477174 : check e604533477174 [[],[]] .chain = true := by decide
def e604533477178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604533477178 : Closed e604533477178 ∧ code e604533477178 = 2803556732730 := by decide
theorem cert_e604533477178 : check e604533477178 [[],[]] .chain = true := by decide
def e604533482926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e604533482926 : Closed e604533482926 ∧ code e604533482926 = 2803556738478 := by decide
theorem cert_e604533482926 : check e604533482926 [[],[]] .chain = true := by decide
def e604533482938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e604533482938 : Closed e604533482938 ∧ code e604533482938 = 2803556738490 := by decide
theorem cert_e604533482938 : check e604533482938 [[],[]] .chain = true := by decide
def e604533482986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e604533482986 : Closed e604533482986 ∧ code e604533482986 = 2803556738538 := by decide
theorem cert_e604533482986 : check e604533482986 [[],[]] .chain = true := by decide
def e604533483118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e604533483118 : Closed e604533483118 ∧ code e604533483118 = 2803556738670 := by decide
theorem cert_e604533483118 : check e604533483118 [[],[]] .chain = true := by decide
def e604533483130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e604533483130 : Closed e604533483130 ∧ code e604533483130 = 2803556738682 := by decide
theorem cert_e604533483130 : check e604533483130 [[],[]] .chain = true := by decide
def e604533483418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e604533483418 : Closed e604533483418 ∧ code e604533483418 = 2803556738970 := by decide
theorem cert_e604533483418 : check e604533483418 [[],[]] .chain = true := by decide
def e604533486294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e604533486294 : Closed e604533486294 ∧ code e604533486294 = 2803556741846 := by decide
theorem cert_e604533486294 : check e604533486294 [[],[]] .chain = true := by decide
def e604533486298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e604533486298 : Closed e604533486298 ∧ code e604533486298 = 2803556741850 := by decide
theorem cert_e604533486298 : check e604533486298 [[],[]] .chain = true := by decide
def e604533486314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e604533486314 : Closed e604533486314 ∧ code e604533486314 = 2803556741866 := by decide
theorem cert_e604533486314 : check e604533486314 [[],[]] .chain = true := by decide
def e604533486390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e604533486390 : Closed e604533486390 ∧ code e604533486390 = 2803556741942 := by decide
theorem cert_e604533486390 : check e604533486390 [[],[]] .chain = true := by decide
def e604533486394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e604533486394 : Closed e604533486394 ∧ code e604533486394 = 2803556741946 := by decide
theorem cert_e604533486394 : check e604533486394 [[],[]] .chain = true := by decide
def e604533486490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e604533486490 : Closed e604533486490 ∧ code e604533486490 = 2803556742042 := by decide
theorem cert_e604533486490 : check e604533486490 [[],[]] .chain = true := by decide
def e604533623662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604533623662 : Closed e604533623662 ∧ code e604533623662 = 2803556879214 := by decide
theorem cert_e604533623662 : check e604533623662 [[],[]] .chain = true := by decide
def e604533623670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604533623670 : Closed e604533623670 ∧ code e604533623670 = 2803556879222 := by decide
theorem cert_e604533623670 : check e604533623670 [[],[]] .chain = true := by decide
def e604533623726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604533623726 : Closed e604533623726 ∧ code e604533623726 = 2803556879278 := by decide
theorem cert_e604533623726 : check e604533623726 [[],[]] .chain = true := by decide
def e604533623738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604533623738 : Closed e604533623738 ∧ code e604533623738 = 2803556879290 := by decide
theorem cert_e604533623738 : check e604533623738 [[],[]] .chain = true := by decide
def e604533623766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604533623766 : Closed e604533623766 ∧ code e604533623766 = 2803556879318 := by decide
theorem cert_e604533623766 : check e604533623766 [[],[]] .chain = true := by decide
def e604533623770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604533623770 : Closed e604533623770 ∧ code e604533623770 = 2803556879322 := by decide
theorem cert_e604533623770 : check e604533623770 [[],[]] .chain = true := by decide
def e604533624046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604533624046 : Closed e604533624046 ∧ code e604533624046 = 2803556879598 := by decide
theorem cert_e604533624046 : check e604533624046 [[],[]] .chain = true := by decide
def e604533624054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604533624054 : Closed e604533624054 ∧ code e604533624054 = 2803556879606 := by decide
theorem cert_e604533624054 : check e604533624054 [[],[]] .chain = true := by decide
def e604533624430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604533624430 : Closed e604533624430 ∧ code e604533624430 = 2803556879982 := by decide
theorem cert_e604533624430 : check e604533624430 [[],[]] .chain = true := by decide
def e604533624442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604533624442 : Closed e604533624442 ∧ code e604533624442 = 2803556879994 := by decide
theorem cert_e604533624442 : check e604533624442 [[],[]] .chain = true := by decide
def e604533624630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604533624630 : Closed e604533624630 ∧ code e604533624630 = 2803556880182 := by decide
theorem cert_e604533624630 : check e604533624630 [[],[]] .chain = true := by decide
def e604533624634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604533624634 : Closed e604533624634 ∧ code e604533624634 = 2803556880186 := by decide
theorem cert_e604533624634 : check e604533624634 [[],[]] .chain = true := by decide
def e604534213486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604534213486 : Closed e604534213486 ∧ code e604534213486 = 2803557469038 := by decide
theorem cert_e604534213486 : check e604534213486 [[],[],[.left]] .chain = true := by decide
def e604534213494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604534213494 : Closed e604534213494 ∧ code e604534213494 = 2803557469046 := by decide
theorem cert_e604534213494 : check e604534213494 [[],[],[.left]] .chain = true := by decide
def e604534213550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604534213550 : Closed e604534213550 ∧ code e604534213550 = 2803557469102 := by decide
theorem cert_e604534213550 : check e604534213550 [[],[],[.left]] .chain = true := by decide
def e604534213562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604534213562 : Closed e604534213562 ∧ code e604534213562 = 2803557469114 := by decide
theorem cert_e604534213562 : check e604534213562 [[],[],[.left]] .chain = true := by decide
def e604534213590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604534213590 : Closed e604534213590 ∧ code e604534213590 = 2803557469142 := by decide
theorem cert_e604534213590 : check e604534213590 [[],[],[.left]] .chain = true := by decide
def e604534213594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604534213594 : Closed e604534213594 ∧ code e604534213594 = 2803557469146 := by decide
theorem cert_e604534213594 : check e604534213594 [[],[],[.left]] .chain = true := by decide
def e604534213870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604534213870 : Closed e604534213870 ∧ code e604534213870 = 2803557469422 := by decide
theorem cert_e604534213870 : check e604534213870 [[],[],[.left]] .chain = true := by decide
def e604534213878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604534213878 : Closed e604534213878 ∧ code e604534213878 = 2803557469430 := by decide
theorem cert_e604534213878 : check e604534213878 [[],[],[.left]] .chain = true := by decide
def e604534214254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604534214254 : Closed e604534214254 ∧ code e604534214254 = 2803557469806 := by decide
theorem cert_e604534214254 : check e604534214254 [[],[],[.left]] .chain = true := by decide
def e604534214266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604534214266 : Closed e604534214266 ∧ code e604534214266 = 2803557469818 := by decide
theorem cert_e604534214266 : check e604534214266 [[],[],[.left]] .chain = true := by decide
def e604534214454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604534214454 : Closed e604534214454 ∧ code e604534214454 = 2803557470006 := by decide
theorem cert_e604534214454 : check e604534214454 [[],[],[.left]] .chain = true := by decide
def e604534214458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604534214458 : Closed e604534214458 ∧ code e604534214458 = 2803557470010 := by decide
theorem cert_e604534214458 : check e604534214458 [[],[],[.left]] .chain = true := by decide
def e604567727642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567727642 : Closed e604567727642 ∧ code e604567727642 = 2803590983194 := by decide
private def t_e604567727642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567727642 : ¬ IsSelfInterpreter e604567727642 :=
  wSource (t := t_e604567727642) (replay_sound (ps := []) (t := e604567727642) (by decide)) (by decide)
def e604567729690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567729690 : Closed e604567729690 ∧ code e604567729690 = 2803590985242 := by decide
private def t_e604567729690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567729690 : ¬ IsSelfInterpreter e604567729690 :=
  wSource (t := t_e604567729690) (replay_sound (ps := []) (t := e604567729690) (by decide)) (by decide)
def e604567744026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567744026 : Closed e604567744026 ∧ code e604567744026 = 2803590999578 := by decide
private def t_e604567744026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567744026 : ¬ IsSelfInterpreter e604567744026 :=
  wSource (t := t_e604567744026) (replay_sound (ps := []) (t := e604567744026) (by decide)) (by decide)
def e604567747098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567747098 : Closed e604567747098 ∧ code e604567747098 = 2803591002650 := by decide
private def t_e604567747098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567747098 : ¬ IsSelfInterpreter e604567747098 :=
  wSource (t := t_e604567747098) (replay_sound (ps := []) (t := e604567747098) (by decide)) (by decide)
def e604567754266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567754266 : Closed e604567754266 ∧ code e604567754266 = 2803591009818 := by decide
private def t_e604567754266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567754266 : ¬ IsSelfInterpreter e604567754266 :=
  wSource (t := t_e604567754266) (replay_sound (ps := []) (t := e604567754266) (by decide)) (by decide)
def e604567755290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567755290 : Closed e604567755290 ∧ code e604567755290 = 2803591010842 := by decide
private def t_e604567755290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567755290 : ¬ IsSelfInterpreter e604567755290 :=
  wSource (t := t_e604567755290) (replay_sound (ps := []) (t := e604567755290) (by decide)) (by decide)
def e604567825946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567825946 : Closed e604567825946 ∧ code e604567825946 = 2803591081498 := by decide
private def t_e604567825946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567825946 : ¬ IsSelfInterpreter e604567825946 :=
  wSource (t := t_e604567825946) (replay_sound (ps := []) (t := e604567825946) (by decide)) (by decide)
def e604567827994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567827994 : Closed e604567827994 ∧ code e604567827994 = 2803591083546 := by decide
private def t_e604567827994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567827994 : ¬ IsSelfInterpreter e604567827994 :=
  wSource (t := t_e604567827994) (replay_sound (ps := []) (t := e604567827994) (by decide)) (by decide)
def e604567924250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567924250 : Closed e604567924250 ∧ code e604567924250 = 2803591179802 := by decide
private def t_e604567924250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567924250 : ¬ IsSelfInterpreter e604567924250 :=
  wSource (t := t_e604567924250) (replay_sound (ps := []) (t := e604567924250) (by decide)) (by decide)
def e604567927322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567927322 : Closed e604567927322 ∧ code e604567927322 = 2803591182874 := by decide
private def t_e604567927322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567927322 : ¬ IsSelfInterpreter e604567927322 :=
  wSource (t := t_e604567927322) (replay_sound (ps := []) (t := e604567927322) (by decide)) (by decide)
def e604567975450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567975450 : Closed e604567975450 ∧ code e604567975450 = 2803591231002 := by decide
private def t_e604567975450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567975450 : ¬ IsSelfInterpreter e604567975450 :=
  wSource (t := t_e604567975450) (replay_sound (ps := []) (t := e604567975450) (by decide)) (by decide)
def e604567976474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604567976474 : Closed e604567976474 ∧ code e604567976474 = 2803591232026 := by decide
private def t_e604567976474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604567976474 : ¬ IsSelfInterpreter e604567976474 :=
  wSource (t := t_e604567976474) (replay_sound (ps := []) (t := e604567976474) (by decide)) (by decide)
def e604583800174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e604583800174 : Closed e604583800174 ∧ code e604583800174 = 2803607055726 := by decide
theorem cert_e604583800174 : check e604583800174 [[],[]] .smaller = true := by decide
def e604583800182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e604583800182 : Closed e604583800182 ∧ code e604583800182 = 2803607055734 := by decide
theorem cert_e604583800182 : check e604583800182 [[],[]] .smaller = true := by decide
def e604583800238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e604583800238 : Closed e604583800238 ∧ code e604583800238 = 2803607055790 := by decide
theorem cert_e604583800238 : check e604583800238 [[],[]] .smaller = true := by decide
def e604583800250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e604583800250 : Closed e604583800250 ∧ code e604583800250 = 2803607055802 := by decide
theorem cert_e604583800250 : check e604583800250 [[],[]] .smaller = true := by decide
def e604583800278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e604583800278 : Closed e604583800278 ∧ code e604583800278 = 2803607055830 := by decide
theorem cert_e604583800278 : check e604583800278 [[],[]] .smaller = true := by decide
def e604583800282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e604583800282 : Closed e604583800282 ∧ code e604583800282 = 2803607055834 := by decide
theorem cert_e604583800282 : check e604583800282 [[],[]] .smaller = true := by decide
def e604583800494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604583800494 : Closed e604583800494 ∧ code e604583800494 = 2803607056046 := by decide
theorem cert_e604583800494 : check e604583800494 [[],[]] .smaller = true := by decide
def e604583800506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604583800506 : Closed e604583800506 ∧ code e604583800506 = 2803607056058 := by decide
theorem cert_e604583800506 : check e604583800506 [[],[]] .smaller = true := by decide
def e604583800554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604583800554 : Closed e604583800554 ∧ code e604583800554 = 2803607056106 := by decide
theorem cert_e604583800554 : check e604583800554 [[],[]] .smaller = true := by decide
def e604583800662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e604583800662 : Closed e604583800662 ∧ code e604583800662 = 2803607056214 := by decide
theorem cert_e604583800662 : check e604583800662 [[],[]] .smaller = true := by decide
def e604583800666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e604583800666 : Closed e604583800666 ∧ code e604583800666 = 2803607056218 := by decide
theorem cert_e604583800666 : check e604583800666 [[],[]] .smaller = true := by decide
def e604583800682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e604583800682 : Closed e604583800682 ∧ code e604583800682 = 2803607056234 := by decide
theorem cert_e604583800682 : check e604583800682 [[],[]] .smaller = true := by decide
def e604583801710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e604583801710 : Closed e604583801710 ∧ code e604583801710 = 2803607057262 := by decide
theorem cert_e604583801710 : check e604583801710 [[],[]] .smaller = true := by decide
def e604583801718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e604583801718 : Closed e604583801718 ∧ code e604583801718 = 2803607057270 := by decide
theorem cert_e604583801718 : check e604583801718 [[],[]] .smaller = true := by decide
def e604583801774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e604583801774 : Closed e604583801774 ∧ code e604583801774 = 2803607057326 := by decide
theorem cert_e604583801774 : check e604583801774 [[],[]] .smaller = true := by decide
def e604583801786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e604583801786 : Closed e604583801786 ∧ code e604583801786 = 2803607057338 := by decide
theorem cert_e604583801786 : check e604583801786 [[],[]] .smaller = true := by decide
def e604583801814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e604583801814 : Closed e604583801814 ∧ code e604583801814 = 2803607057366 := by decide
theorem cert_e604583801814 : check e604583801814 [[],[]] .smaller = true := by decide
def e604583801818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e604583801818 : Closed e604583801818 ∧ code e604583801818 = 2803607057370 := by decide
theorem cert_e604583801818 : check e604583801818 [[],[]] .smaller = true := by decide
def e604583802094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e604583802094 : Closed e604583802094 ∧ code e604583802094 = 2803607057646 := by decide
theorem cert_e604583802094 : check e604583802094 [[],[]] .smaller = true := by decide
def e604583802102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e604583802102 : Closed e604583802102 ∧ code e604583802102 = 2803607057654 := by decide
theorem cert_e604583802102 : check e604583802102 [[],[]] .smaller = true := by decide
end Blc.Floor41
