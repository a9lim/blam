import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605649233722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649233722 : Closed e605649233722 ∧ code e605649233722 = 2804672489274 := by decide
theorem cert_e605649233722 : check e605649233722 [[],[],[.under]] .width = true := by decide
def e605649233862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e605649233862 : Closed e605649233862 ∧ code e605649233862 = 2804672489414 := by decide
theorem cert_e605649233862 : check e605649233862 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605649236206 : Closed e605649236206 ∧ code e605649236206 = 2804672491758 := by decide
theorem cert_e605649236206 : check e605649236206 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605649236214 : Closed e605649236214 ∧ code e605649236214 = 2804672491766 := by decide
theorem cert_e605649236214 : check e605649236214 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605649236694 : Closed e605649236694 ∧ code e605649236694 = 2804672492246 := by decide
theorem cert_e605649236694 : check e605649236694 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605649236698 : Closed e605649236698 ∧ code e605649236698 = 2804672492250 := by decide
theorem cert_e605649236698 : check e605649236698 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605649236714 : Closed e605649236714 ∧ code e605649236714 = 2804672492266 := by decide
theorem cert_e605649236714 : check e605649236714 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605649236766 : Closed e605649236766 ∧ code e605649236766 = 2804672492318 := by decide
theorem cert_e605649236766 : check e605649236766 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649236790 : Closed e605649236790 ∧ code e605649236790 = 2804672492342 := by decide
theorem cert_e605649236790 : check e605649236790 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649236794 : Closed e605649236794 ∧ code e605649236794 = 2804672492346 := by decide
theorem cert_e605649236794 : check e605649236794 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605649236890 : Closed e605649236890 ∧ code e605649236890 = 2804672492442 := by decide
theorem cert_e605649236890 : check e605649236890 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649236934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605649236934 : Closed e605649236934 ∧ code e605649236934 = 2804672492486 := by decide
theorem cert_e605649236934 : check e605649236934 [[],[],[.under],[.under,.under]] .three = true := by decide
def e605649462126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605649462126 : Closed e605649462126 ∧ code e605649462126 = 2804672717678 := by decide
theorem cert_e605649462126 : check e605649462126 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605649462134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605649462134 : Closed e605649462134 ∧ code e605649462134 = 2804672717686 := by decide
theorem cert_e605649462134 : check e605649462134 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605649462190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605649462190 : Closed e605649462190 ∧ code e605649462190 = 2804672717742 := by decide
theorem cert_e605649462190 : check e605649462190 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605649462202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605649462202 : Closed e605649462202 ∧ code e605649462202 = 2804672717754 := by decide
theorem cert_e605649462202 : check e605649462202 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605649462230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605649462230 : Closed e605649462230 ∧ code e605649462230 = 2804672717782 := by decide
def e605649462234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605649462234 : Closed e605649462234 ∧ code e605649462234 = 2804672717786 := by decide
theorem cert_e605649462234 : check e605649462234 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605649463534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605649463534 : Closed e605649463534 ∧ code e605649463534 = 2804672719086 := by decide
private def t_e605649463534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem cert_e605649463534 : ¬ IsSelfInterpreter e605649463534 :=
  wSource (t := t_e605649463534) (replay_sound (ps := []) (t := e605649463534) (by decide)) (by decide)
def e605649463542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605649463542 : Closed e605649463542 ∧ code e605649463542 = 2804672719094 := by decide
private def t_e605649463542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem cert_e605649463542 : ¬ IsSelfInterpreter e605649463542 :=
  wSource (t := t_e605649463542) (replay_sound (ps := []) (t := e605649463542) (by decide)) (by decide)
def e605649464094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605649464094 : Closed e605649464094 ∧ code e605649464094 = 2804672719646 := by decide
private def t_e605649464094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem cert_e605649464094 : ¬ IsSelfInterpreter e605649464094 :=
  wSource (t := t_e605649464094) (replay_sound (ps := []) (t := e605649464094) (by decide)) (by decide)
def e605649464206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605649464206 : Closed e605649464206 ∧ code e605649464206 = 2804672719758 := by decide
private def t_e605649464206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem cert_e605649464206 : ¬ IsSelfInterpreter e605649464206 :=
  wSource (t := t_e605649464206) (replay_sound (ps := []) (t := e605649464206) (by decide)) (by decide)
def e605649464430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605649464430 : Closed e605649464430 ∧ code e605649464430 = 2804672719982 := by decide
theorem cert_e605649464430 : check e605649464430 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649464442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605649464442 : Closed e605649464442 ∧ code e605649464442 = 2804672719994 := by decide
theorem cert_e605649464442 : check e605649464442 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649464606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605649464606 : Closed e605649464606 ∧ code e605649464606 = 2804672720158 := by decide
theorem cert_e605649464606 : check e605649464606 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649464774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605649464774 : Closed e605649464774 ∧ code e605649464774 = 2804672720326 := by decide
theorem cert_e605649464774 : check e605649464774 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649464886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605649464886 : Closed e605649464886 ∧ code e605649464886 = 2804672720438 := by decide
private def t_e605649464886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem cert_e605649464886 : ¬ IsSelfInterpreter e605649464886 :=
  wSource (t := t_e605649464886) (replay_sound (ps := []) (t := e605649464886) (by decide)) (by decide)
def e605649464890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605649464890 : Closed e605649464890 ∧ code e605649464890 = 2804672720442 := by decide
private def t_e605649464890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem cert_e605649464890 : ¬ IsSelfInterpreter e605649464890 :=
  wSource (t := t_e605649464890) (replay_sound (ps := []) (t := e605649464890) (by decide)) (by decide)
def e605649464974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605649464974 : Closed e605649464974 ∧ code e605649464974 = 2804672720526 := by decide
private def t_e605649464974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem cert_e605649464974 : ¬ IsSelfInterpreter e605649464974 :=
  wSource (t := t_e605649464974) (replay_sound (ps := []) (t := e605649464974) (by decide)) (by decide)
def e605649465030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605649465030 : Closed e605649465030 ∧ code e605649465030 = 2804672720582 := by decide
private def t_e605649465030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem cert_e605649465030 : ¬ IsSelfInterpreter e605649465030 :=
  wSource (t := t_e605649465030) (replay_sound (ps := []) (t := e605649465030) (by decide)) (by decide)
def e605649465774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605649465774 : Closed e605649465774 ∧ code e605649465774 = 2804672721326 := by decide
theorem cert_e605649465774 : check e605649465774 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649465786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605649465786 : Closed e605649465786 ∧ code e605649465786 = 2804672721338 := by decide
theorem cert_e605649465786 : check e605649465786 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649465834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e605649465834 : Closed e605649465834 ∧ code e605649465834 = 2804672721386 := by decide
theorem cert_e605649465834 : check e605649465834 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649466478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605649466478 : Closed e605649466478 ∧ code e605649466478 = 2804672722030 := by decide
theorem cert_e605649466478 : check e605649466478 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649466490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605649466490 : Closed e605649466490 ∧ code e605649466490 = 2804672722042 := by decide
theorem cert_e605649466490 : check e605649466490 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649466654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605649466654 : Closed e605649466654 ∧ code e605649466654 = 2804672722206 := by decide
theorem cert_e605649466654 : check e605649466654 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649466822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605649466822 : Closed e605649466822 ∧ code e605649466822 = 2804672722374 := by decide
theorem cert_e605649466822 : check e605649466822 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649467162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605649467162 : Closed e605649467162 ∧ code e605649467162 = 2804672722714 := by decide
theorem cert_e605649467162 : check e605649467162 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649467206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605649467206 : Closed e605649467206 ∧ code e605649467206 = 2804672722758 := by decide
theorem cert_e605649467206 : check e605649467206 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649467606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605649467606 : Closed e605649467606 ∧ code e605649467606 = 2804672723158 := by decide
theorem cert_e605649467606 : check e605649467606 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e605649467610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605649467610 : Closed e605649467610 ∧ code e605649467610 = 2804672723162 := by decide
theorem cert_e605649467610 : check e605649467610 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e605649467626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605649467626 : Closed e605649467626 ∧ code e605649467626 = 2804672723178 := by decide
theorem cert_e605649467626 : check e605649467626 [[],[],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e605649467958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605649467958 : Closed e605649467958 ∧ code e605649467958 = 2804672723510 := by decide
private def t_e605649467958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem cert_e605649467958 : ¬ IsSelfInterpreter e605649467958 :=
  wSource (t := t_e605649467958) (replay_sound (ps := []) (t := e605649467958) (by decide)) (by decide)
def e605649467962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605649467962 : Closed e605649467962 ∧ code e605649467962 = 2804672723514 := by decide
private def t_e605649467962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem cert_e605649467962 : ¬ IsSelfInterpreter e605649467962 :=
  wSource (t := t_e605649467962) (replay_sound (ps := []) (t := e605649467962) (by decide)) (by decide)
def e605649468046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605649468046 : Closed e605649468046 ∧ code e605649468046 = 2804672723598 := by decide
private def t_e605649468046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem cert_e605649468046 : ¬ IsSelfInterpreter e605649468046 :=
  wSource (t := t_e605649468046) (replay_sound (ps := []) (t := e605649468046) (by decide)) (by decide)
def e605649468102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605649468102 : Closed e605649468102 ∧ code e605649468102 = 2804672723654 := by decide
private def t_e605649468102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem cert_e605649468102 : ¬ IsSelfInterpreter e605649468102 :=
  wSource (t := t_e605649468102) (replay_sound (ps := []) (t := e605649468102) (by decide)) (by decide)
def e605649468186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605649468186 : Closed e605649468186 ∧ code e605649468186 = 2804672723738 := by decide
theorem cert_e605649468186 : checkPay e605649468186 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [[.under,.left,.left,.right,.under,.under,.left,.left],[.under,.left,.left,.right,.under,.under,.left,.left,.left,.left],[.under,.left,.left,.right,.under,.under,.left,.left,.left]] = true := by decide
def e605649468230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605649468230 : Closed e605649468230 ∧ code e605649468230 = 2804672723782 := by decide
theorem cert_e605649468230 : checkPay e605649468230 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [[.under,.left,.left,.right,.under,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left]] = true := by decide
def e605649471214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e605649471214 : Closed e605649471214 ∧ code e605649471214 = 2804672726766 := by decide
theorem cert_e605649471214 : check e605649471214 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649471222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605649471222 : Closed e605649471222 ∧ code e605649471222 = 2804672726774 := by decide
private def t_e605649471222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem cert_e605649471222 : ¬ IsSelfInterpreter e605649471222 :=
  wSource (t := t_e605649471222) (replay_sound (ps := []) (t := e605649471222) (by decide)) (by decide)
def e605649471406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e605649471406 : Closed e605649471406 ∧ code e605649471406 = 2804672726958 := by decide
theorem cert_e605649471406 : check e605649471406 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649471446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605649471446 : Closed e605649471446 ∧ code e605649471446 = 2804672726998 := by decide
private def t_e605649471446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem cert_e605649471446 : ¬ IsSelfInterpreter e605649471446 :=
  wSource (t := t_e605649471446) (replay_sound (ps := []) (t := e605649471446) (by decide)) (by decide)
def e605649472750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605649472750 : Closed e605649472750 ∧ code e605649472750 = 2804672728302 := by decide
theorem cert_e605649472750 : check e605649472750 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605649472758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605649472758 : Closed e605649472758 ∧ code e605649472758 = 2804672728310 := by decide
theorem cert_e605649472758 : checkPay e605649472758 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left]] 0 [] = true := by decide
def e605649473134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605649473134 : Closed e605649473134 ∧ code e605649473134 = 2804672728686 := by decide
theorem cert_e605649473134 : checkPay e605649473134 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [[]] = true := by decide
def e605649473146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605649473146 : Closed e605649473146 ∧ code e605649473146 = 2804672728698 := by decide
theorem cert_e605649473146 : checkPay e605649473146 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [[],[.left],[.right],[.right,.under]] = true := by decide
def e605649473334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605649473334 : Closed e605649473334 ∧ code e605649473334 = 2804672728886 := by decide
theorem cert_e605649473334 : check e605649473334 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605649473338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605649473338 : Closed e605649473338 ∧ code e605649473338 = 2804672728890 := by decide
theorem cert_e605649473338 : check e605649473338 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605649475822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605649475822 : Closed e605649475822 ∧ code e605649475822 = 2804672731374 := by decide
theorem cert_e605649475822 : check e605649475822 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605649475830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605649475830 : Closed e605649475830 ∧ code e605649475830 = 2804672731382 := by decide
theorem cert_e605649475830 : checkPay e605649475830 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605649476382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605649476382 : Closed e605649476382 ∧ code e605649476382 = 2804672731934 := by decide
theorem cert_e605649476382 : check e605649476382 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e605649476494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605649476494 : Closed e605649476494 ∧ code e605649476494 = 2804672732046 := by decide
private def t_e605649476494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem cert_e605649476494 : ¬ IsSelfInterpreter e605649476494 :=
  wSource (t := t_e605649476494) (replay_sound (ps := []) (t := e605649476494) (by decide)) (by decide)
def e605649476718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605649476718 : Closed e605649476718 ∧ code e605649476718 = 2804672732270 := by decide
theorem cert_e605649476718 : check e605649476718 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649476730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605649476730 : Closed e605649476730 ∧ code e605649476730 = 2804672732282 := by decide
theorem cert_e605649476730 : check e605649476730 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649476894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605649476894 : Closed e605649476894 ∧ code e605649476894 = 2804672732446 := by decide
theorem cert_e605649476894 : check e605649476894 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649477062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605649477062 : Closed e605649477062 ∧ code e605649477062 = 2804672732614 := by decide
theorem cert_e605649477062 : check e605649477062 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649477174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605649477174 : Closed e605649477174 ∧ code e605649477174 = 2804672732726 := by decide
theorem cert_e605649477174 : check e605649477174 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e605649477178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605649477178 : Closed e605649477178 ∧ code e605649477178 = 2804672732730 := by decide
theorem cert_e605649477178 : checkPay e605649477178 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [[],[.under]] = true := by decide
def e605649477262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605649477262 : Closed e605649477262 ∧ code e605649477262 = 2804672732814 := by decide
private def t_e605649477262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem cert_e605649477262 : ¬ IsSelfInterpreter e605649477262 :=
  wSource (t := t_e605649477262) (replay_sound (ps := []) (t := e605649477262) (by decide)) (by decide)
def e605649477318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605649477318 : Closed e605649477318 ∧ code e605649477318 = 2804672732870 := by decide
theorem cert_e605649477318 : check e605649477318 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649479454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605649479454 : Closed e605649479454 ∧ code e605649479454 = 2804672735006 := by decide
private def t_e605649479454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem cert_e605649479454 : ¬ IsSelfInterpreter e605649479454 :=
  wSource (t := t_e605649479454) (replay_sound (ps := []) (t := e605649479454) (by decide)) (by decide)
def e605649479566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605649479566 : Closed e605649479566 ∧ code e605649479566 = 2804672735118 := by decide
private def t_e605649479566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem cert_e605649479566 : ¬ IsSelfInterpreter e605649479566 :=
  wSource (t := t_e605649479566) (replay_sound (ps := []) (t := e605649479566) (by decide)) (by decide)
def e605649481950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605649481950 : Closed e605649481950 ∧ code e605649481950 = 2804672737502 := by decide
theorem cert_e605649481950 : check e605649481950 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649481978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605649481978 : Closed e605649481978 ∧ code e605649481978 = 2804672737530 := by decide
theorem cert_e605649481978 : check e605649481978 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649482526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605649482526 : Closed e605649482526 ∧ code e605649482526 = 2804672738078 := by decide
theorem cert_e605649482526 : check e605649482526 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649482694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605649482694 : Closed e605649482694 ∧ code e605649482694 = 2804672738246 := by decide
theorem cert_e605649482694 : check e605649482694 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649483886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605649483886 : Closed e605649483886 ∧ code e605649483886 = 2804672739438 := by decide
private def t_e605649483886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem cert_e605649483886 : ¬ IsSelfInterpreter e605649483886 :=
  wSource (t := t_e605649483886) (replay_sound (ps := []) (t := e605649483886) (by decide)) (by decide)
def e605649483898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605649483898 : Closed e605649483898 ∧ code e605649483898 = 2804672739450 := by decide
private def t_e605649483898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem cert_e605649483898 : ¬ IsSelfInterpreter e605649483898 :=
  wSource (t := t_e605649483898) (replay_sound (ps := []) (t := e605649483898) (by decide)) (by decide)
def e605649484174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605649484174 : Closed e605649484174 ∧ code e605649484174 = 2804672739726 := by decide
private def t_e605649484174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e605649484174 : ¬ IsSelfInterpreter e605649484174 :=
  wSource (t := t_e605649484174) (replay_sound (ps := []) (t := e605649484174) (by decide)) (by decide)
def e605649484230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605649484230 : Closed e605649484230 ∧ code e605649484230 = 2804672739782 := by decide
private def t_e605649484230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e605649484230 : ¬ IsSelfInterpreter e605649484230 :=
  wSource (t := t_e605649484230) (replay_sound (ps := []) (t := e605649484230) (by decide)) (by decide)
def e605649486702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605649486702 : Closed e605649486702 ∧ code e605649486702 = 2804672742254 := by decide
theorem cert_e605649486702 : checkPay e605649486702 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.right,.under,.left],[.under,.right,.under,.left,.left],[.under,.right,.under,.left,.left],[.under,.right,.under,.left]] = true := by decide
def e605649486714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e605649486714 : Closed e605649486714 ∧ code e605649486714 = 2804672742266 := by decide
theorem cert_e605649486714 : checkPay e605649486714 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e605649486766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605649486766 : Closed e605649486766 ∧ code e605649486766 = 2804672742318 := by decide
theorem cert_e605649486766 : checkPay e605649486766 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under],[.under,.left],[.under,.left,.left]] = true := by decide
def e605649486826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e605649486826 : Closed e605649486826 ∧ code e605649486826 = 2804672742378 := by decide
theorem cert_e605649486826 : checkPay e605649486826 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under]] = true := by decide
def e605649487470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605649487470 : Closed e605649487470 ∧ code e605649487470 = 2804672743022 := by decide
theorem cert_e605649487470 : checkPay e605649487470 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e605649487482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605649487482 : Closed e605649487482 ∧ code e605649487482 = 2804672743034 := by decide
theorem cert_e605649487482 : checkPay e605649487482 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.right],[.under,.under,.right,.right]] = true := by decide
def e605649487770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e605649487770 : Closed e605649487770 ∧ code e605649487770 = 2804672743322 := by decide
theorem cert_e605649487770 : checkPay e605649487770 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e605649489006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605649489006 : Closed e605649489006 ∧ code e605649489006 = 2804672744558 := by decide
theorem cert_e605649489006 : checkPay e605649489006 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.right],[.left,.right,.left,.right]] = true := by decide
def e605649489018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605649489018 : Closed e605649489018 ∧ code e605649489018 = 2804672744570 := by decide
theorem cert_e605649489018 : checkPay e605649489018 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left]] = true := by decide
def e605649489182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605649489182 : Closed e605649489182 ∧ code e605649489182 = 2804672744734 := by decide
theorem cert_e605649489182 : checkPay e605649489182 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e605649489350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605649489350 : Closed e605649489350 ∧ code e605649489350 = 2804672744902 := by decide
theorem cert_e605649489350 : checkPay e605649489350 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.under,.left]] = true := by decide
def e605649489690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605649489690 : Closed e605649489690 ∧ code e605649489690 = 2804672745242 := by decide
theorem cert_e605649489690 : checkPay e605649489690 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.right],[.under,.under,.left,.left,.left,.left,.right,.under]] = true := by decide
def e605649489734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605649489734 : Closed e605649489734 ∧ code e605649489734 = 2804672745286 := by decide
theorem cert_e605649489734 : checkPay e605649489734 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.right]] = true := by decide
def e605649490142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605649490142 : Closed e605649490142 ∧ code e605649490142 = 2804672745694 := by decide
theorem cert_e605649490142 : checkPay e605649490142 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e605649490170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605649490170 : Closed e605649490170 ∧ code e605649490170 = 2804672745722 := by decide
theorem cert_e605649490170 : checkPay e605649490170 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right,.under],[.under,.right,.under,.right,.under]] = true := by decide
def e605649490718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605649490718 : Closed e605649490718 ∧ code e605649490718 = 2804672746270 := by decide
theorem cert_e605649490718 : checkPay e605649490718 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e605649490886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605649490886 : Closed e605649490886 ∧ code e605649490886 = 2804672746438 := by decide
theorem cert_e605649490886 : checkPay e605649490886 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right],[.under,.right,.right],[.under,.right,.right,.under]] = true := by decide
def e605649493046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605649493046 : Closed e605649493046 ∧ code e605649493046 = 2804672748598 := by decide
theorem cert_e605649493046 : checkPay e605649493046 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e605649493050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605649493050 : Closed e605649493050 ∧ code e605649493050 = 2804672748602 := by decide
theorem cert_e605649493050 : checkPay e605649493050 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e605649493190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605649493190 : Closed e605649493190 ∧ code e605649493190 = 2804672748742 := by decide
theorem cert_e605649493190 : checkPay e605649493190 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e605649494454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605649494454 : Closed e605649494454 ∧ code e605649494454 = 2804672750006 := by decide
private def t_e605649494454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem cert_e605649494454 : ¬ IsSelfInterpreter e605649494454 :=
  wSource (t := t_e605649494454) (replay_sound (ps := []) (t := e605649494454) (by decide)) (by decide)
def e605649494458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605649494458 : Closed e605649494458 ∧ code e605649494458 = 2804672750010 := by decide
theorem cert_e605649494458 : check e605649494458 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605649494486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605649494486 : Closed e605649494486 ∧ code e605649494486 = 2804672750038 := by decide
private def t_e605649494486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem cert_e605649494486 : ¬ IsSelfInterpreter e605649494486 :=
  wSource (t := t_e605649494486) (replay_sound (ps := []) (t := e605649494486) (by decide)) (by decide)
def e605649494506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605649494506 : Closed e605649494506 ∧ code e605649494506 = 2804672750058 := by decide
theorem cert_e605649494506 : check e605649494506 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605649494838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605649494838 : Closed e605649494838 ∧ code e605649494838 = 2804672750390 := by decide
theorem cert_e605649494838 : check e605649494838 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e605649494842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605649494842 : Closed e605649494842 ∧ code e605649494842 = 2804672750394 := by decide
theorem cert_e605649494842 : check e605649494842 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e605649494938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605649494938 : Closed e605649494938 ∧ code e605649494938 = 2804672750490 := by decide
theorem cert_e605649494938 : check e605649494938 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e605649495606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605649495606 : Closed e605649495606 ∧ code e605649495606 = 2804672751158 := by decide
def e605649495610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605649495610 : Closed e605649495610 ∧ code e605649495610 = 2804672751162 := by decide
theorem cert_e605649495610 : check e605649495610 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605649495694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605649495694 : Closed e605649495694 ∧ code e605649495694 = 2804672751246 := by decide
private def t_e605649495694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem cert_e605649495694 : ¬ IsSelfInterpreter e605649495694 :=
  wSource (t := t_e605649495694) (replay_sound (ps := []) (t := e605649495694) (by decide)) (by decide)
def e605649495750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605649495750 : Closed e605649495750 ∧ code e605649495750 = 2804672751302 := by decide
theorem cert_e605649495750 : check e605649495750 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649495834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605649495834 : Closed e605649495834 ∧ code e605649495834 = 2804672751386 := by decide
theorem cert_e605649495834 : checkPay e605649495834 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.right,.under],[.under,.under,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.under],[.under,.under,.left,.right,.under,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.right,.left],[.under,.under,.left,.right,.under,.left,.right,.left,.left]] = true := by decide
def e605649495878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605649495878 : Closed e605649495878 ∧ code e605649495878 = 2804672751430 := by decide
theorem cert_e605649495878 : checkPay e605649495878 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right],[.under,.left,.right,.under,.left,.left,.right],[.under,.left,.right,.under,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e605649496174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605649496174 : Closed e605649496174 ∧ code e605649496174 = 2804672751726 := by decide
private def t_e605649496174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem cert_e605649496174 : ¬ IsSelfInterpreter e605649496174 :=
  wSource (t := t_e605649496174) (replay_sound (ps := []) (t := e605649496174) (by decide)) (by decide)
def e605649496186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605649496186 : Closed e605649496186 ∧ code e605649496186 = 2804672751738 := by decide
private def t_e605649496186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem cert_e605649496186 : ¬ IsSelfInterpreter e605649496186 :=
  wSource (t := t_e605649496186) (replay_sound (ps := []) (t := e605649496186) (by decide)) (by decide)
def e605649496462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605649496462 : Closed e605649496462 ∧ code e605649496462 = 2804672752014 := by decide
private def t_e605649496462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e605649496462 : ¬ IsSelfInterpreter e605649496462 :=
  wSource (t := t_e605649496462) (replay_sound (ps := []) (t := e605649496462) (by decide)) (by decide)
def e605649496518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605649496518 : Closed e605649496518 ∧ code e605649496518 = 2804672752070 := by decide
private def t_e605649496518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e605649496518 : ¬ IsSelfInterpreter e605649496518 :=
  wSource (t := t_e605649496518) (replay_sound (ps := []) (t := e605649496518) (by decide)) (by decide)
def e605649497142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605649497142 : Closed e605649497142 ∧ code e605649497142 = 2804672752694 := by decide
theorem cert_e605649497142 : check e605649497142 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605649497146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605649497146 : Closed e605649497146 ∧ code e605649497146 = 2804672752698 := by decide
theorem cert_e605649497146 : check e605649497146 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605649497286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605649497286 : Closed e605649497286 ∧ code e605649497286 = 2804672752838 := by decide
theorem cert_e605649497286 : check e605649497286 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605649508062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605649508062 : Closed e605649508062 ∧ code e605649508062 = 2804672763614 := by decide
private def t_e605649508062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem cert_e605649508062 : ¬ IsSelfInterpreter e605649508062 :=
  wSource (t := t_e605649508062) (replay_sound (ps := []) (t := e605649508062) (by decide)) (by decide)
def e605649508086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605649508086 : Closed e605649508086 ∧ code e605649508086 = 2804672763638 := by decide
private def t_e605649508086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem cert_e605649508086 : ¬ IsSelfInterpreter e605649508086 :=
  wSource (t := t_e605649508086) (replay_sound (ps := []) (t := e605649508086) (by decide)) (by decide)
def e605649508190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605649508190 : Closed e605649508190 ∧ code e605649508190 = 2804672763742 := by decide
private def t_e605649508190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem cert_e605649508190 : ¬ IsSelfInterpreter e605649508190 :=
  wSource (t := t_e605649508190) (replay_sound (ps := []) (t := e605649508190) (by decide)) (by decide)
def e605649508218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605649508218 : Closed e605649508218 ∧ code e605649508218 = 2804672763770 := by decide
private def t_e605649508218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem cert_e605649508218 : ¬ IsSelfInterpreter e605649508218 :=
  wSource (t := t_e605649508218) (replay_sound (ps := []) (t := e605649508218) (by decide)) (by decide)
def e605649508310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605649508310 : Closed e605649508310 ∧ code e605649508310 = 2804672763862 := by decide
private def t_e605649508310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem cert_e605649508310 : ¬ IsSelfInterpreter e605649508310 :=
  wSource (t := t_e605649508310) (replay_sound (ps := []) (t := e605649508310) (by decide)) (by decide)
def e605649508314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605649508314 : Closed e605649508314 ∧ code e605649508314 = 2804672763866 := by decide
private def t_e605649508314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem cert_e605649508314 : ¬ IsSelfInterpreter e605649508314 :=
  wSource (t := t_e605649508314) (replay_sound (ps := []) (t := e605649508314) (by decide)) (by decide)
def e605649508830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605649508830 : Closed e605649508830 ∧ code e605649508830 = 2804672764382 := by decide
private def t_e605649508830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem cert_e605649508830 : ¬ IsSelfInterpreter e605649508830 :=
  wSource (t := t_e605649508830) (replay_sound (ps := []) (t := e605649508830) (by decide)) (by decide)
def e605649508854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605649508854 : Closed e605649508854 ∧ code e605649508854 = 2804672764406 := by decide
private def t_e605649508854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem cert_e605649508854 : ¬ IsSelfInterpreter e605649508854 :=
  wSource (t := t_e605649508854) (replay_sound (ps := []) (t := e605649508854) (by decide)) (by decide)
def e605649509598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605649509598 : Closed e605649509598 ∧ code e605649509598 = 2804672765150 := by decide
private def t_e605649509598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem cert_e605649509598 : ¬ IsSelfInterpreter e605649509598 :=
  wSource (t := t_e605649509598) (replay_sound (ps := []) (t := e605649509598) (by decide)) (by decide)
def e605649509626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605649509626 : Closed e605649509626 ∧ code e605649509626 = 2804672765178 := by decide
private def t_e605649509626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem cert_e605649509626 : ¬ IsSelfInterpreter e605649509626 :=
  wSource (t := t_e605649509626) (replay_sound (ps := []) (t := e605649509626) (by decide)) (by decide)
def e605649509950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605649509950 : Closed e605649509950 ∧ code e605649509950 = 2804672765502 := by decide
theorem cert_e605649509950 : check e605649509950 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .chain = true := by decide
def e605649510174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605649510174 : Closed e605649510174 ∧ code e605649510174 = 2804672765726 := by decide
theorem cert_e605649510174 : check e605649510174 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under]] .chain = true := by decide
def e605649510198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649510198 : Closed e605649510198 ∧ code e605649510198 = 2804672765750 := by decide
private def t_e605649510198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem cert_e605649510198 : ¬ IsSelfInterpreter e605649510198 :=
  wSource (t := t_e605649510198) (replay_sound (ps := []) (t := e605649510198) (by decide)) (by decide)
def e605649510202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649510202 : Closed e605649510202 ∧ code e605649510202 = 2804672765754 := by decide
private def t_e605649510202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem cert_e605649510202 : ¬ IsSelfInterpreter e605649510202 :=
  wSource (t := t_e605649510202) (replay_sound (ps := []) (t := e605649510202) (by decide)) (by decide)
def e605649524974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605649524974 : Closed e605649524974 ∧ code e605649524974 = 2804672780526 := by decide
theorem cert_e605649524974 : checkPay e605649524974 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e605649524982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605649524982 : Closed e605649524982 ∧ code e605649524982 = 2804672780534 := by decide
theorem cert_e605649524982 : check e605649524982 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605649525534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605649525534 : Closed e605649525534 ∧ code e605649525534 = 2804672781086 := by decide
theorem cert_e605649525534 : check e605649525534 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605649525646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605649525646 : Closed e605649525646 ∧ code e605649525646 = 2804672781198 := by decide
private def t_e605649525646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem cert_e605649525646 : ¬ IsSelfInterpreter e605649525646 :=
  wSource (t := t_e605649525646) (replay_sound (ps := []) (t := e605649525646) (by decide)) (by decide)
def e605649525870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605649525870 : Closed e605649525870 ∧ code e605649525870 = 2804672781422 := by decide
theorem cert_e605649525870 : check e605649525870 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e605649525882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605649525882 : Closed e605649525882 ∧ code e605649525882 = 2804672781434 := by decide
theorem cert_e605649525882 : check e605649525882 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e605649526046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605649526046 : Closed e605649526046 ∧ code e605649526046 = 2804672781598 := by decide
theorem cert_e605649526046 : check e605649526046 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e605649526214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605649526214 : Closed e605649526214 ∧ code e605649526214 = 2804672781766 := by decide
theorem cert_e605649526214 : check e605649526214 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e605649526326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605649526326 : Closed e605649526326 ∧ code e605649526326 = 2804672781878 := by decide
def e605649526330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605649526330 : Closed e605649526330 ∧ code e605649526330 = 2804672781882 := by decide
theorem cert_e605649526330 : check e605649526330 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605649526414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605649526414 : Closed e605649526414 ∧ code e605649526414 = 2804672781966 := by decide
private def t_e605649526414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e605649526414 : ¬ IsSelfInterpreter e605649526414 :=
  wSource (t := t_e605649526414) (replay_sound (ps := []) (t := e605649526414) (by decide)) (by decide)
def e605649526470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605649526470 : Closed e605649526470 ∧ code e605649526470 = 2804672782022 := by decide
theorem cert_e605649526470 : checkPay e605649526470 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left,.left],[.left]] 0 [[.under,.right,.left,.right,.under,.under,.right,.left],[.under,.right,.left,.right,.under,.under,.right,.left],[.under,.right,.left,.right,.under,.under,.right,.left,.left,.left,.left],[.under,.right,.left,.right,.under,.under,.right,.left,.left,.left]] = true := by decide
def e605649528606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605649528606 : Closed e605649528606 ∧ code e605649528606 = 2804672784158 := by decide
theorem cert_e605649528606 : check e605649528606 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605649528718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605649528718 : Closed e605649528718 ∧ code e605649528718 = 2804672784270 := by decide
theorem cert_e605649528718 : check e605649528718 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605649531102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e605649531102 : Closed e605649531102 ∧ code e605649531102 = 2804672786654 := by decide
theorem cert_e605649531102 : checkPay e605649531102 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e605649531130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e605649531130 : Closed e605649531130 ∧ code e605649531130 = 2804672786682 := by decide
theorem cert_e605649531130 : checkPay e605649531130 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [[.under]] = true := by decide
def e605649531678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605649531678 : Closed e605649531678 ∧ code e605649531678 = 2804672787230 := by decide
theorem cert_e605649531678 : checkPay e605649531678 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [[],[]] = true := by decide
def e605649531846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605649531846 : Closed e605649531846 ∧ code e605649531846 = 2804672787398 := by decide
theorem cert_e605649531846 : checkPay e605649531846 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [[],[.under],[.under,.under,.right],[.under,.under,.right,.left,.left],[.under,.under,.right,.left,.left]] = true := by decide
def e605649533038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605649533038 : Closed e605649533038 ∧ code e605649533038 = 2804672788590 := by decide
theorem cert_e605649533038 : check e605649533038 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605649533050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605649533050 : Closed e605649533050 ∧ code e605649533050 = 2804672788602 := by decide
theorem cert_e605649533050 : check e605649533050 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605649533326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605649533326 : Closed e605649533326 ∧ code e605649533326 = 2804672788878 := by decide
theorem cert_e605649533326 : check e605649533326 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605649533382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605649533382 : Closed e605649533382 ∧ code e605649533382 = 2804672788934 := by decide
def e605649570670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605649570670 : Closed e605649570670 ∧ code e605649570670 = 2804672826222 := by decide
theorem cert_e605649570670 : check e605649570670 [[],[]] .chain = true := by decide
def e605649570678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605649570678 : Closed e605649570678 ∧ code e605649570678 = 2804672826230 := by decide
theorem cert_e605649570678 : check e605649570678 [[],[]] .chain = true := by decide
def e605649570734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605649570734 : Closed e605649570734 ∧ code e605649570734 = 2804672826286 := by decide
theorem cert_e605649570734 : check e605649570734 [[],[]] .chain = true := by decide
def e605649570746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605649570746 : Closed e605649570746 ∧ code e605649570746 = 2804672826298 := by decide
theorem cert_e605649570746 : check e605649570746 [[],[]] .chain = true := by decide
end Blc.Floor41
